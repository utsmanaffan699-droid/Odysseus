"""FastAPI routers for Odysseus."""

from __future__ import annotations
