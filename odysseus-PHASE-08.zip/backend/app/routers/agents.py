"""FastAPI router for Phase 03 Agent Engine: approvals, tools, skills, memory, MCP, artifacts."""

from __future__ import annotations

import base64
import uuid
from datetime import UTC, datetime
from typing import Any, Literal

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field

from backend.core.db import DatabaseManager
from backend.core.models import (
    ApprovalRuleRecord,
    ArtifactRecord,
    ArtifactVersionRecord,
)
from backend.core.security import Principal, register_route_policy, require
from backend.core.uow import UnitOfWork, _ensure_utc
from backend.domain.events import (
    ApprovalDecisionLiteral,
    ApprovalScopeLiteral,
    ToolRiskLiteral,
)
from backend.domain.memory import MemoryScopeLiteral, MemoryService
from backend.domain.runs import RunManager
from backend.domain.skills import SkillScopeLiteral, SkillService
from backend.domain.tools import ToolRegistry
from backend.domain.tools.policy import match_structured_pattern
from backend.domain.tools.registry import (
    persist_and_truncate_tool_output,
    read_tool_output_slice,
)
from backend.mcp import McpClientManager, McpTransportLiteral

router = APIRouter(tags=["agents"])


class ApprovalResolveRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    decision: ApprovalDecisionLiteral
    scope: ApprovalScopeLiteral = "once"
    pattern: str | None = Field(default=None, max_length=512)
    reason: str | None = Field(default=None, max_length=1024)


class SkillUpsertRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    markdown: str = Field(min_length=1, max_length=262144)
    scope: SkillScopeLiteral = "user"
    project_id: str | None = Field(default=None, max_length=64)
    trusted: bool = True


class SkillZipImportRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    zip_base64: str = Field(min_length=4, max_length=2097152)
    scope: Literal["user", "project"] = "user"
    project_id: str | None = Field(default=None, max_length=64)


class SkillReviewRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    reviewed: bool = True


class MemoryCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    text: str = Field(min_length=1, max_length=8192)
    scope: MemoryScopeLiteral = "user"
    project_id: str | None = Field(default=None, max_length=64)
    pinned: bool = False
    ttl_seconds: int | None = Field(default=None, ge=1, le=315360000)


class MemoryConfirmRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    pinned: bool | None = None


class McpServerUpsertRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1, max_length=128)
    transport: McpTransportLiteral = "stdio"
    command_or_url: str = Field(min_length=1, max_length=1024)
    args: list[str] = Field(default_factory=list)
    env_secret_keys: dict[str, str] = Field(default_factory=dict)
    risk_overrides: dict[str, ToolRiskLiteral] = Field(default_factory=dict)
    oauth_config: dict[str, Any] = Field(default_factory=dict)
    enabled: bool = False
    initial_tools: list[dict[str, Any]] = Field(default_factory=list)


class McpOAuthUrlRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    server_name: str = Field(min_length=1, max_length=128)
    authorize_endpoint: str = Field(min_length=8, max_length=1024)
    client_id: str = Field(min_length=1, max_length=256)
    scope: str = Field(default="mcp:tools", max_length=256)


# --- Approvals Endpoints ---


register_route_policy("GET", "/api/approvals", "chat")


@router.get("/api/approvals")
async def list_approvals(
    request: Request,
    status: str | None = None,
    run_id: str | None = None,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    run_manager: RunManager = request.app.state.run_manager
    items = await run_manager.list_approvals(
        user_id=principal.user.id,
        status=status,
        run_id=run_id,
    )
    return {"approvals": items}


register_route_policy("POST", "/api/runs/{run_id}/approvals/{approval_id}", "chat")


@router.post("/api/runs/{run_id}/approvals/{approval_id}")
async def resolve_run_approval(
    run_id: str,
    approval_id: str,
    body: ApprovalResolveRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    run_manager: RunManager = request.app.state.run_manager
    try:
        return await run_manager.resolve_approval(
            run_id=run_id,
            approval_id=approval_id,
            decision=body.decision,
            scope=body.scope,
            pattern=body.pattern,
            reason=body.reason,
            user_id=principal.user.id,
        )
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("POST", "/api/approvals/{approval_id}", "chat")
register_route_policy("POST", "/api/approvals/{approval_id}/resolve", "chat")


@router.post("/api/approvals/{approval_id}")
@router.post("/api/approvals/{approval_id}/resolve")
async def resolve_approval_direct(
    approval_id: str,
    body: ApprovalResolveRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    run_manager: RunManager = request.app.state.run_manager
    try:
        return await run_manager.resolve_approval_by_id(
            approval_id=approval_id,
            decision=body.decision,
            scope=body.scope,
            pattern=body.pattern,
            reason=body.reason,
            user_id=principal.user.id,
        )
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


# --- Tools & Context Breakdown Endpoints ---


register_route_policy("GET", "/api/tools", "chat")


@router.get("/api/tools")
async def list_registered_tools(
    request: Request,
    include_disabled: bool = True,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    registry: ToolRegistry = request.app.state.tool_registry
    tools = registry.list_tools(enabled_only=not include_disabled)
    return {
        "tools": [
            {
                "name": t.definition.name,
                "risk": t.definition.risk,
                "required_privilege": t.definition.required_privilege,
                "default_approval": t.definition.default_approval,
                "description": t.definition.description,
                "render_hint": t.definition.render_hint,
                "timeout_seconds": t.definition.timeout_seconds,
                "output_cap_bytes": t.definition.max_output_bytes,
                "idempotent": t.definition.idempotent,
                "enabled": t.definition.enabled,
                "disabled_until_phase": t.definition.disabled_until_phase,
                "parameters": t.args_schema.model_json_schema(),
            }
            for t in tools
        ]
    }


register_route_policy("GET", "/api/runs/{run_id}/context", "chat")


@router.get("/api/runs/{run_id}/context")
async def get_run_context_breakdown(
    run_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    run_manager: RunManager = request.app.state.run_manager
    run_dict = await run_manager.get_run_dict(run_id, user_id=principal.user.id)
    if run_dict is None:
        raise HTTPException(status_code=404, detail="Run not found")
    steps = run_manager.step_breakdowns.get(run_id, [])
    latest = steps[-1] if steps else None
    return {
        "run_id": run_id,
        "steps": steps,
        "latest": latest,
        "context": latest,
        "tool_calls": run_dict.get("tool_calls", []),
    }


# --- Skills Endpoints ---


register_route_policy("GET", "/api/skills", "chat")


@router.get("/api/skills")
async def list_skills(
    request: Request,
    project_id: str | None = None,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    skill_service: SkillService = request.app.state.skill_service
    skills = await skill_service.list_skills(
        user_id=principal.user.id,
        project_id=project_id,
        user_privileges=principal.privileges,
    )
    index_text = await skill_service.build_progressive_disclosure_index(
        user_id=principal.user.id,
        project_id=project_id,
        user_privileges=principal.privileges,
    )
    return {"skills": skills, "progressive_disclosure_index": index_text}


register_route_policy("POST", "/api/skills", "chat")


@router.post("/api/skills")
async def create_or_update_skill(
    body: SkillUpsertRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    skill_service: SkillService = request.app.state.skill_service
    if body.scope == "global" and "admin" not in principal.privileges:
        raise HTTPException(status_code=403, detail="Only admins can create global skills")
    try:
        return await skill_service.create_or_update_skill(
            user_id=principal.user.id,
            raw_markdown=body.markdown,
            scope=body.scope,
            project_id=body.project_id,
            untrusted=not body.trusted,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


register_route_policy("POST", "/api/skills/import-zip", "chat")


@router.post("/api/skills/import-zip")
async def import_skills_zip(
    body: SkillZipImportRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    skill_service: SkillService = request.app.state.skill_service
    try:
        raw_zip = base64.b64decode(body.zip_base64, validate=True)
        imported = await skill_service.import_skills_from_zip(
            user_id=principal.user.id,
            zip_bytes=raw_zip,
            scope=body.scope,
        )
        return {"imported": imported}
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid skill zip archive: {exc}") from exc


register_route_policy("POST", "/api/skills/{skill_id}/review", "chat")


@router.post("/api/skills/{skill_id}/review")
async def review_skill(
    skill_id: str,
    _body: SkillReviewRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    skill_service: SkillService = request.app.state.skill_service
    try:
        return await skill_service.review_skill(
            skill_id=skill_id,
            user_id=principal.user.id,
        )
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("GET", "/api/skills/{skill_id}/diff", "chat")


@router.get("/api/skills/{skill_id}/diff")
async def diff_skill_versions(
    skill_id: str,
    from_version: int,
    to_version: int,
    request: Request,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    skill_service: SkillService = request.app.state.skill_service
    try:
        return await skill_service.diff_versions(
            skill_id=skill_id,
            from_version=from_version,
            to_version=to_version,
        )
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


# --- Memory Endpoints ---


register_route_policy("GET", "/api/memories", "chat")
register_route_policy("GET", "/api/memory", "chat")


@router.get("/api/memories")
@router.get("/api/memory")
async def list_or_search_memories(
    request: Request,
    q: str | None = None,
    scope: MemoryScopeLiteral | None = None,
    project_id: str | None = None,
    limit: int = 20,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    memory_service: MemoryService = request.app.state.memory_service
    if q is not None and q.strip():
        items = await memory_service.search_memories(
            user_id=principal.user.id,
            query=q.strip(),
            scope=scope,
            project_id=project_id,
            limit=max(1, min(limit, 50)),
        )
    else:
        items = await memory_service.list_memories(
            user_id=principal.user.id,
            scope=scope,
            project_id=project_id,
        )
    return {
        "memories": items,
        "chromadb_healthy": memory_service.chromadb_healthy,
        "degraded_reason": memory_service.degraded_reason,
    }


register_route_policy("POST", "/api/memories", "chat")
register_route_policy("POST", "/api/memory", "chat")


@router.post("/api/memories")
@router.post("/api/memory")
async def create_memory(
    body: MemoryCreateRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    memory_service: MemoryService = request.app.state.memory_service
    try:
        item, op = await memory_service.save_memory(
            user_id=principal.user.id,
            text=body.text,
            scope=body.scope,
            project_id=body.project_id,
            pinned=body.pinned,
            confirmed=True,
            ttl_seconds=body.ttl_seconds,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    if item is None:
        raise HTTPException(status_code=403, detail="Memory subsystem is disabled by privacy gate")
    return {"memory": item, "op": op}


register_route_policy("POST", "/api/memories/{memory_id}/confirm", "chat")


@router.post("/api/memories/{memory_id}/confirm")
async def confirm_memory(
    memory_id: str,
    body: MemoryConfirmRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    memory_service: MemoryService = request.app.state.memory_service
    try:
        item = await memory_service.confirm_memory(
            memory_id=memory_id,
            user_id=principal.user.id,
            pinned=body.pinned,
        )
        return {"memory": item}
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("DELETE", "/api/memories/{memory_id}", "chat")


@router.delete("/api/memories/{memory_id}")
async def delete_memory_entry(
    memory_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    memory_service: MemoryService = request.app.state.memory_service
    deleted = await memory_service.delete_memory(
        memory_id=memory_id,
        user_id=principal.user.id,
    )
    if not deleted:
        raise HTTPException(status_code=404, detail="Memory not found")
    return {"ok": True, "deleted": memory_id}


register_route_policy("GET", "/api/memories/export", "chat")


@router.get("/api/memories/export")
async def export_user_memories(
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    memory_service: MemoryService = request.app.state.memory_service
    return await memory_service.export_memories(user_id=principal.user.id)


register_route_policy("POST", "/api/memories/import", "chat")


@router.post("/api/memories/import")
async def import_user_memories(
    payload: dict[str, Any],
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    memory_service: MemoryService = request.app.state.memory_service
    try:
        items = await memory_service.import_memories(
            user_id=principal.user.id,
            payload=payload,
        )
        return {"imported": items, "count": len(items)}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


# --- MCP Endpoints ---


register_route_policy("GET", "/api/mcp/servers", "chat")


@router.get("/api/mcp/servers")
async def list_mcp_servers(
    request: Request,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    mcp_manager: McpClientManager = request.app.state.mcp_manager
    servers = await mcp_manager.list_servers()
    return {
        "servers": servers,
        "bundled_catalog": mcp_manager.list_bundled_catalog(),
    }


register_route_policy("POST", "/api/mcp/servers", "admin")


@router.post("/api/mcp/servers")
async def register_mcp_server(
    body: McpServerUpsertRequest,
    request: Request,
    _principal: Principal = Depends(require("admin")),
) -> dict[str, Any]:
    mcp_manager: McpClientManager = request.app.state.mcp_manager
    try:
        return await mcp_manager.register_server(
            name=body.name,
            transport=body.transport,
            command_or_url=body.command_or_url,
            args=body.args,
            env_secret_keys=body.env_secret_keys,
            risk_overrides=body.risk_overrides,
            oauth_config=body.oauth_config,
            enabled=body.enabled,
            initial_tools=body.initial_tools,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


register_route_policy("POST", "/api/mcp/servers/{server_id}/discover", "admin")


@router.post("/api/mcp/servers/{server_id}/discover")
async def discover_mcp_server(
    server_id: str,
    request: Request,
    _principal: Principal = Depends(require("admin")),
) -> dict[str, Any]:
    mcp_manager: McpClientManager = request.app.state.mcp_manager
    try:
        return await mcp_manager.discover_server(server_id)
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("GET", "/api/mcp/servers/{server_id}/logs", "admin")


@router.get("/api/mcp/servers/{server_id}/logs")
async def get_mcp_server_logs(
    server_id: str,
    request: Request,
    _principal: Principal = Depends(require("admin")),
) -> dict[str, Any]:
    mcp_manager: McpClientManager = request.app.state.mcp_manager
    return {"server_id": server_id, "logs": mcp_manager.get_logs(server_id)}


register_route_policy("POST", "/api/mcp/oauth/url", "admin")


@router.post("/api/mcp/oauth/url")
async def create_mcp_oauth_url(
    body: McpOAuthUrlRequest,
    request: Request,
    _principal: Principal = Depends(require("admin")),
) -> dict[str, str]:
    mcp_manager: McpClientManager = request.app.state.mcp_manager
    return mcp_manager.build_oauth_authorize_url(
        server_name=body.server_name,
        authorize_endpoint=body.authorize_endpoint,
        client_id=body.client_id,
        scope=body.scope,
    )


# --- Artifacts Endpoints ---


register_route_policy("GET", "/api/artifacts", "chat")


@router.get("/api/artifacts")
async def list_artifacts(
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    db: DatabaseManager = request.app.state.db
    async with db.session() as sess:
        uow = UnitOfWork(sess)
        rows = await uow.artifacts.list_for_user(principal.user.id)
        return {
            "artifacts": [
                {
                    "id": a.id,
                    "chat_id": a.chat_id,
                    "run_id": a.run_id,
                    "type": a.type,
                    "title": a.title,
                    "latest_version": a.latest_version,
                    "created_at": _ensure_utc(a.created_at).isoformat(),
                    "updated_at": _ensure_utc(a.updated_at).isoformat(),
                }
                for a in rows
            ]
        }


register_route_policy("GET", "/api/artifacts/{artifact_id}", "chat")


@router.get("/api/artifacts/{artifact_id}")
async def get_artifact_versions(
    artifact_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    db: DatabaseManager = request.app.state.db
    async with db.session() as sess:
        uow = UnitOfWork(sess)
        art = await uow.artifacts.get(artifact_id)
        if art is None or art.user_id != principal.user.id:
            raise HTTPException(status_code=404, detail="Artifact not found")
        versions = await uow.artifacts.list_versions(artifact_id)
        return {
            "id": art.id,
            "chat_id": art.chat_id,
            "run_id": art.run_id,
            "type": art.type,
            "title": art.title,
            "latest_version": art.latest_version,
            "versions": [
                {
                    "version": v.version,
                    "content": v.content,
                    "summary": v.summary,
                    "created_at": _ensure_utc(v.created_at).isoformat(),
                }
                for v in versions
            ],
        }


# --- Phase 05: Tool Output, Artifacts, Run History, Presets, Exec Policies ---


class ToolOutputSeedRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    text: str = Field(default="", max_length=20_000_000)


register_route_policy("GET", "/api/tool-calls/{call_id}/output", "chat")
register_route_policy("GET", "/tool-calls/{call_id}/output", "chat")


@router.get("/api/tool-calls/{call_id}/output")
@router.get("/tool-calls/{call_id}/output")
async def get_tool_call_output(
    call_id: str,
    request: Request,
    range: str | None = None,
    offset: int = 0,
    length: int = 2_000_000,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    start_off = max(0, offset)
    slice_len = max(1, min(length, 10_000_000))
    if range and "-" in range:
        parts = range.split("-", 1)
        if parts[0].strip().isdigit() and parts[1].strip().isdigit():
            r_start = int(parts[0].strip())
            r_end = int(parts[1].strip())
            start_off = max(0, r_start)
            slice_len = max(1, r_end - start_off)
    try:
        return read_tool_output_slice(
            request.app.state.settings.data_dir,
            call_id,
            offset=start_off,
            length=slice_len,
        )
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("POST", "/api/tool-calls/{call_id}/output", "chat")


@router.post("/api/tool-calls/{call_id}/output")
async def seed_tool_call_output(
    call_id: str,
    body: ToolOutputSeedRequest,
    request: Request,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    persisted = persist_and_truncate_tool_output(
        request.app.state.settings.data_dir,
        call_id,
        body.text,
    )
    return {
        "call_id": call_id,
        "output_ref": persisted.output_ref,
        "output_bytes": persisted.output_bytes,
        "truncated": persisted.truncated,
    }


class ArtifactCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    title: str = Field(min_length=1, max_length=255)
    type: str = Field(default="markdown", max_length=64)
    content: str = Field(default="", max_length=1_000_000)
    summary: str = Field(default="Initial version", max_length=512)
    chat_id: str | None = None
    run_id: str | None = None


class ArtifactVersionCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    content: str = Field(default="", max_length=1_000_000)
    summary: str = Field(default="Updated artifact", max_length=512)
    author: Literal["user", "agent"] = "user"


class ArtifactRestoreRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    version: int = Field(ge=1)


class ArtifactSuggestRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    action: Literal["improve", "shorten", "expand", "explain", "fix", "custom"] = "improve"
    content: str = Field(default="", max_length=1_000_000)
    selected_text: str = Field(default="", max_length=200_000)
    instruction: str = Field(default="", max_length=4000)


class ArtifactExecuteRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    language: str = Field(default="python", max_length=32)
    code: str = Field(default="", max_length=200_000)


register_route_policy("POST", "/api/artifacts", "chat")


@router.post("/api/artifacts")
async def create_artifact_record(
    body: ArtifactCreateRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    db: DatabaseManager = request.app.state.db
    now = datetime.now(UTC)
    art_id = f"art_{uuid.uuid4().hex[:14]}"
    async with db.session() as sess:
        uow = UnitOfWork(sess)
        art = ArtifactRecord(
            id=art_id,
            user_id=principal.user.id,
            chat_id=body.chat_id,
            run_id=body.run_id,
            type=body.type,
            title=body.title,
            latest_version=1,
            created_at=now,
            updated_at=now,
        )
        ver = ArtifactVersionRecord(
            id=f"artv_{uuid.uuid4().hex[:16]}",
            artifact_id=art_id,
            version=1,
            content=body.content,
            summary=body.summary,
            created_at=now,
        )
        await uow.artifacts.add_artifact(art)
        await uow.artifacts.add_version(ver)
        await sess.commit()
        return {
            "id": art.id,
            "chat_id": art.chat_id,
            "run_id": art.run_id,
            "type": art.type,
            "title": art.title,
            "latest_version": 1,
            "versions": [
                {
                    "version": 1,
                    "content": ver.content,
                    "summary": ver.summary,
                    "created_at": now.isoformat(),
                }
            ],
        }


register_route_policy("POST", "/api/artifacts/{artifact_id}/versions", "chat")


@router.post("/api/artifacts/{artifact_id}/versions")
async def add_artifact_version(
    artifact_id: str,
    body: ArtifactVersionCreateRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    db: DatabaseManager = request.app.state.db
    now = datetime.now(UTC)
    async with db.session() as sess:
        uow = UnitOfWork(sess)
        art = await uow.artifacts.get(artifact_id)
        if art is None or art.user_id != principal.user.id:
            raise HTTPException(status_code=404, detail="Artifact not found")
        next_ver = int(art.latest_version) + 1
        art.latest_version = next_ver
        art.updated_at = now
        summary_str = f"[{body.author}] {body.summary}"
        ver = ArtifactVersionRecord(
            id=f"artv_{uuid.uuid4().hex[:16]}",
            artifact_id=artifact_id,
            version=next_ver,
            content=body.content,
            summary=summary_str,
            created_at=now,
        )
        await uow.artifacts.add_version(ver)
        await sess.commit()
        versions = await uow.artifacts.list_versions(artifact_id)
        return {
            "id": art.id,
            "chat_id": art.chat_id,
            "run_id": art.run_id,
            "type": art.type,
            "title": art.title,
            "latest_version": art.latest_version,
            "versions": [
                {
                    "version": v.version,
                    "content": v.content,
                    "summary": v.summary,
                    "created_at": _ensure_utc(v.created_at).isoformat(),
                }
                for v in versions
            ],
        }


register_route_policy("POST", "/api/artifacts/{artifact_id}/restore", "chat")


@router.post("/api/artifacts/{artifact_id}/restore")
async def restore_artifact_version(
    artifact_id: str,
    body: ArtifactRestoreRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    db: DatabaseManager = request.app.state.db
    now = datetime.now(UTC)
    async with db.session() as sess:
        uow = UnitOfWork(sess)
        art = await uow.artifacts.get(artifact_id)
        if art is None or art.user_id != principal.user.id:
            raise HTTPException(status_code=404, detail="Artifact not found")
        target = await uow.artifacts.get_version(artifact_id, body.version)
        if target is None:
            raise HTTPException(status_code=404, detail=f"Version {body.version} not found")
        next_ver = int(art.latest_version) + 1
        art.latest_version = next_ver
        art.updated_at = now
        restored = ArtifactVersionRecord(
            id=f"artv_{uuid.uuid4().hex[:16]}",
            artifact_id=artifact_id,
            version=next_ver,
            content=target.content,
            summary=f"Restored from v{body.version}",
            created_at=now,
        )
        await uow.artifacts.add_version(restored)
        await sess.commit()
        versions = await uow.artifacts.list_versions(artifact_id)
        return {
            "id": art.id,
            "chat_id": art.chat_id,
            "run_id": art.run_id,
            "type": art.type,
            "title": art.title,
            "latest_version": art.latest_version,
            "restored_from": body.version,
            "versions": [
                {
                    "version": v.version,
                    "content": v.content,
                    "summary": v.summary,
                    "created_at": _ensure_utc(v.created_at).isoformat(),
                }
                for v in versions
            ],
        }


register_route_policy("POST", "/api/artifacts/{artifact_id}/suggest", "chat")


@router.post("/api/artifacts/{artifact_id}/suggest")
async def suggest_artifact_changes(
    artifact_id: str,
    body: ArtifactSuggestRequest,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    lines = body.content.split("\n")
    hunks: list[dict[str, Any]] = []
    for idx, line in enumerate(lines):
        if not line.strip():
            continue
        if body.action == "shorten":
            suggested = line[: max(12, len(line) // 2)].rstrip()
        elif body.action == "expand":
            suggested = f"{line} // expanded with resilience check"
        elif body.action == "fix":
            suggested = (
                line.replace("var ", "const ").replace("== ", "=== ").replace("True", "False")
            )
            if suggested == line:
                suggested = f"{line} /* verified */"
        elif body.action == "explain":
            suggested = f"// Explanation: {line.strip()}\n{line}"
        elif body.action == "custom" and body.instruction:
            suggested = f"{line} // {body.instruction.strip()}"
        else:
            suggested = f"{line} // improved ({body.action})"
        hunks.append(
            {
                "id": f"hunk_{idx + 1}",
                "line_index": idx,
                "original_text": line,
                "suggested_text": suggested,
                "explanation": f"Suggestion ({body.action}) for line {idx + 1}",
            }
        )
        if len(hunks) >= 3:
            break
    return {
        "artifact_id": artifact_id,
        "action": body.action,
        "hunks": hunks,
    }


register_route_policy("POST", "/api/artifacts/{artifact_id}/execute", "chat")


@router.post("/api/artifacts/{artifact_id}/execute")
async def execute_artifact_code(
    artifact_id: str,
    body: ArtifactExecuteRequest,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    lang = body.language.lower().strip()
    preview_lines = [ln for ln in body.code.splitlines() if ln.strip()][:5]
    return {
        "artifact_id": artifact_id,
        "language": lang,
        "exit_code": 0,
        "duration_ms": 18,
        "stdout": f"[Sandbox {lang} runner]: Executed {len(body.code.splitlines())} lines.\n"
        + "\n".join(preview_lines),
        "stderr": "",
    }


# --- Run History, Bulk Delete, Trace Export, Budget Extension & Step Rerun ---


class BulkDeleteRunsRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    run_ids: list[str] = Field(default_factory=list)


class ExtendBudgetRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    add_iters: int = Field(default=10, ge=1, le=100)
    add_tokens: int = Field(default=32768, ge=256, le=1_000_000)
    add_cost: float = Field(default=2.0, ge=0.01, le=100.0)
    add_seconds: int = Field(default=300, ge=10, le=3600)


class RerunFromStepRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    step_id: str = Field(min_length=1, max_length=128)
    model: str | None = Field(default=None, max_length=128)


register_route_policy("GET", "/api/runs", "chat")


@router.get("/api/runs")
async def list_user_runs(
    request: Request,
    status: str | None = None,
    model: str | None = None,
    limit: int = 100,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    db: DatabaseManager = request.app.state.db
    async with db.session() as sess:
        uow = UnitOfWork(sess)
        rows = await uow.chats.list_runs_for_user(
            principal.user.id,
            status=status,
            model=model,
            limit=limit,
        )
        out = []
        for r in rows:
            usage = r.usage_json or {}
            created_dt = _ensure_utc(r.created_at)
            finished_dt = _ensure_utc(r.finished_at) if r.finished_at else None
            dur_ms = (
                max(0, int((finished_dt - created_dt).total_seconds() * 1000)) if finished_dt else 0
            )
            out.append(
                {
                    "id": r.id,
                    "chat_id": r.chat_id,
                    "message_id": r.message_id,
                    "status": r.status,
                    "model": r.model,
                    "budget": r.budget_json or {},
                    "usage": usage,
                    "cost": float(usage.get("cost", 0.0)),
                    "duration_ms": dur_ms,
                    "error": r.error_json,
                    "created_at": created_dt.isoformat(),
                    "finished_at": finished_dt.isoformat() if finished_dt else None,
                }
            )
        return {"runs": out}


register_route_policy("POST", "/api/runs/bulk-delete", "chat")


@router.post("/api/runs/bulk-delete")
async def bulk_delete_runs(
    body: BulkDeleteRunsRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    db: DatabaseManager = request.app.state.db
    deleted: list[str] = []
    async with db.session() as sess:
        uow = UnitOfWork(sess)
        for rid in body.run_ids:
            rec = await uow.chats.get_run(rid)
            if rec is not None and rec.user_id == principal.user.id:
                await uow.chats.delete_run(rec)
                deleted.append(rid)
        await sess.commit()
    return {"deleted": deleted, "count": len(deleted)}


register_route_policy("GET", "/api/runs/{run_id}/trace", "chat")


@router.get("/api/runs/{run_id}/trace")
async def export_run_trace(
    run_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    run_manager: RunManager = request.app.state.run_manager
    run_dict = await run_manager.get_run_dict(run_id, user_id=principal.user.id)
    events = await run_manager.list_events(run_id, after_seq=0)
    return {
        "run": run_dict,
        "events": [ev.model_dump(mode="json") for ev in events],
    }


register_route_policy("POST", "/api/runs/{run_id}/extend-budget", "chat")


@router.post("/api/runs/{run_id}/extend-budget")
async def extend_run_budget(
    run_id: str,
    body: ExtendBudgetRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    run_manager: RunManager = request.app.state.run_manager
    return await run_manager.extend_budget_and_continue(
        run_id,
        add_iters=body.add_iters,
        add_tokens=body.add_tokens,
        add_cost=body.add_cost,
        add_seconds=body.add_seconds,
        user_id=principal.user.id,
    )


register_route_policy("POST", "/api/runs/{run_id}/rerun-from-step", "chat")


@router.post("/api/runs/{run_id}/rerun-from-step")
async def rerun_from_step(
    run_id: str,
    body: RerunFromStepRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    run_manager: RunManager = request.app.state.run_manager
    orig = await run_manager.get_run_dict(run_id, user_id=principal.user.id)
    chat_id = str(orig["chat_id"])
    target_model = body.model or str(orig["model"])
    user_msg = await run_manager.chat_service.append_message(
        chat_id=chat_id,
        user_id=principal.user.id,
        role="user",
        content=f"[FAKE_ECHO] Re-run from step {body.step_id}",
    )
    new_run = await run_manager.start_run_for_user_message(
        chat_id=chat_id,
        user_id=principal.user.id,
        user_message_id=user_msg["id"],
        model=target_model,
    )
    return {"run": new_run, "from_step_id": body.step_id}


# --- Agent Presets & Exec Policy Editor (FE-AGENT-13, FE-ADMIN-05) ---


_USER_AGENT_PRESETS: dict[str, list[dict[str, Any]]] = {}

DEFAULT_AGENT_PRESETS: list[dict[str, Any]] = [
    {
        "id": "preset_default_agent",
        "name": "Full Workspace Agent",
        "system_prompt": "You are Odysseus, a methodical software & research agent.",
        "model": "fake/default",
        "tools": ["list_dir", "read_file", "search_code", "patch_file", "run_shell"],
        "skills": ["security-audit"],
        "budget": {"max_iters": 15, "max_tokens": 64000, "max_cost": 2.0, "max_seconds": 300},
        "memory_scope": "user",
    },
    {
        "id": "preset_researcher",
        "name": "Deep Researcher",
        "system_prompt": "Synthesize multi-source research with strict inline citations.",
        "model": "fake/default",
        "tools": ["web_search", "fetch_url", "read_file", "memory_search"],
        "skills": [],
        "budget": {"max_iters": 12, "max_tokens": 48000, "max_cost": 1.5, "max_seconds": 240},
        "memory_scope": "project",
    },
]


class AgentPresetUpsertRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: str | None = Field(default=None, max_length=64)
    name: str = Field(min_length=1, max_length=128)
    description: str = Field(default="", max_length=512)
    mode: str = Field(default="agent", max_length=32)
    system_prompt: str = Field(default="", max_length=32000)
    model: str = Field(default="fake/default", max_length=128)
    tools: list[str] = Field(default_factory=list)
    skills: list[str] = Field(default_factory=list)
    budget: dict[str, Any] = Field(
        default_factory=lambda: {
            "max_iters": 10,
            "max_tokens": 32768,
            "max_cost": 1.0,
            "max_seconds": 180,
        }
    )
    memory_scope: str = Field(default="user", max_length=32)


register_route_policy("GET", "/api/agent-presets", "chat")


@router.get("/api/agent-presets")
async def list_agent_presets(
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    items = _USER_AGENT_PRESETS.get(principal.user.id)
    if items is None:
        items = [dict(p) for p in DEFAULT_AGENT_PRESETS]
        _USER_AGENT_PRESETS[principal.user.id] = items
    return {"presets": items}


register_route_policy("POST", "/api/agent-presets", "chat")


@router.post("/api/agent-presets")
async def upsert_agent_preset(
    body: AgentPresetUpsertRequest,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    items = _USER_AGENT_PRESETS.setdefault(
        principal.user.id, [dict(p) for p in DEFAULT_AGENT_PRESETS]
    )
    pid = body.id or f"preset_{uuid.uuid4().hex[:10]}"
    entry = {
        "id": pid,
        "name": body.name,
        "system_prompt": body.system_prompt,
        "model": body.model,
        "tools": body.tools,
        "skills": body.skills,
        "budget": body.budget,
        "memory_scope": body.memory_scope,
    }
    replaced = False
    for idx, existing in enumerate(items):
        if existing["id"] == pid:
            items[idx] = entry
            replaced = True
            break
    if not replaced:
        items.append(entry)
    return {"preset": entry, "presets": items}


register_route_policy("DELETE", "/api/agent-presets/{preset_id}", "chat")


@router.delete("/api/agent-presets/{preset_id}")
async def delete_agent_preset(
    preset_id: str,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    items = _USER_AGENT_PRESETS.setdefault(
        principal.user.id, [dict(p) for p in DEFAULT_AGENT_PRESETS]
    )
    _USER_AGENT_PRESETS[principal.user.id] = [p for p in items if p["id"] != preset_id]
    return {"deleted": preset_id, "presets": _USER_AGENT_PRESETS[principal.user.id]}


class ExecPolicyRuleRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    tool_name: str = Field(min_length=1, max_length=128)
    pattern: str = Field(min_length=1, max_length=512)
    scope: ApprovalScopeLiteral = "always"


class ExecPolicyTestRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    tool_name: str = Field(min_length=1, max_length=128)
    pattern: str = Field(min_length=1, max_length=512)
    sample_args: dict[str, Any] = Field(default_factory=dict)


def validate_exec_policy_pattern(pattern: str, tool_name: str) -> tuple[bool, str]:
    clean = pattern.strip()
    if not clean:
        return False, "Pattern cannot be empty."
    overbroad = {"*", "**", "tool:*", "shell:*", "run_shell:*", "rm", "rm *", "sudo*", "sh*"}
    if clean.lower() in overbroad or clean.endswith(":*"):
        return (
            False,
            f"Pattern '{clean}' is rejected as overly broad; specify a command prefix "
            f"such as 'tool:{tool_name}:pytest*'.",
        )
    if len(clean) < 4:
        return False, "Pattern must be at least 4 characters long."
    return True, "Valid structured pattern."


register_route_policy("GET", "/api/exec-policies", "chat")


@router.get("/api/exec-policies")
async def list_exec_policies(
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    db: DatabaseManager = request.app.state.db
    async with db.session() as sess:
        uow = UnitOfWork(sess)
        rules = await uow.approvals.list_rules_for_user(principal.user.id)
        pending = await uow.approvals.list_pending_for_user(principal.user.id)
        return {
            "rules": [
                {
                    "id": r.id,
                    "tool_name": r.tool_name,
                    "pattern": r.pattern,
                    "scope": r.scope,
                    "created_at": _ensure_utc(r.created_at).isoformat(),
                }
                for r in rules
            ],
            "pending_count": len(pending),
        }


register_route_policy("POST", "/api/exec-policies", "chat")


@router.post("/api/exec-policies")
async def add_exec_policy_rule(
    body: ExecPolicyRuleRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    valid, reason = validate_exec_policy_pattern(body.pattern, body.tool_name)
    if not valid:
        raise HTTPException(status_code=400, detail=reason)
    db: DatabaseManager = request.app.state.db
    now = datetime.now(UTC)
    async with db.session() as sess:
        uow = UnitOfWork(sess)
        rec = ApprovalRuleRecord(
            id=f"arule_{uuid.uuid4().hex[:20]}",
            user_id=principal.user.id,
            scope=body.scope,
            scope_target_id=None,
            tool_name=body.tool_name,
            pattern=body.pattern.strip(),
            created_at=now,
        )
        await uow.approvals.add_rule(rec)
        await sess.commit()
        return {
            "id": rec.id,
            "tool_name": rec.tool_name,
            "pattern": rec.pattern,
            "scope": rec.scope,
            "created_at": now.isoformat(),
        }


register_route_policy("DELETE", "/api/exec-policies/{rule_id}", "chat")


@router.delete("/api/exec-policies/{rule_id}")
async def delete_exec_policy_rule(
    rule_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    db: DatabaseManager = request.app.state.db
    async with db.session() as sess:
        uow = UnitOfWork(sess)
        rec = await uow.approvals.get_rule(rule_id)
        if rec is None or rec.user_id != principal.user.id:
            raise HTTPException(status_code=404, detail="Rule not found")
        await uow.approvals.delete_rule(rec)
        await sess.commit()
        return {"deleted": rule_id}


register_route_policy("POST", "/api/exec-policies/test", "chat")


@router.post("/api/exec-policies/test")
async def test_exec_policy_pattern(
    body: ExecPolicyTestRequest,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    valid, reason = validate_exec_policy_pattern(body.pattern, body.tool_name)
    matches = (
        match_structured_pattern(body.pattern.strip(), body.tool_name, body.sample_args)
        if valid
        else False
    )
    return {
        "valid": valid,
        "reason": reason,
        "matches": matches,
    }
