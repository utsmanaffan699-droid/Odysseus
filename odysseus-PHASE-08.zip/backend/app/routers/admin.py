"""Admin console endpoints: users, privileges, settings, secrets, audit log, jobs, and bundle."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.auth import ALL_PRIVILEGES, DEFAULT_USER_PRIVILEGES, hash_password
from backend.core.db import DatabaseManager
from backend.core.logging import (
    get_recent_sanitized_logs,
    register_secret_for_redaction,
    scrub_value,
)
from backend.core.middleware import resolve_client_ip
from backend.core.models import User
from backend.core.security import Principal, register_route_policy, require
from backend.core.settings import Settings
from backend.core.uow import UnitOfWork

router = APIRouter(tags=["admin"])


class CreateUserRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    username: str = Field(min_length=2, max_length=64)
    email: str = Field(min_length=3, max_length=255)
    password: str = Field(min_length=10, max_length=256)
    privileges: list[str] = Field(default_factory=lambda: list(DEFAULT_USER_PRIVILEGES))
    must_change_password: bool = True


class UpdatePrivilegesRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    privileges: list[str]


class RuntimeSettingsUpdateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    overrides: dict[str, Any]


class SecretUpsertRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    key: str = Field(min_length=2, max_length=128)
    value: str = Field(min_length=1, max_length=8192)


class EnqueueJobRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    kind: str = Field(min_length=1, max_length=64)
    payload: dict[str, Any] = Field(default_factory=dict)
    max_attempts: int = Field(default=3, ge=1, le=20)


register_route_policy("GET", "/api/admin/users", "admin")


@router.get("/api/admin/users")
async def admin_list_users(
    request: Request,
    _principal: Principal = Depends(require("admin")),
) -> list[dict[str, Any]]:
    """List all user accounts and their granted privileges."""
    db = request.app.state.db
    async with db.session() as sess:
        uow = UnitOfWork(sess)
        users = await uow.users.list_users()
        return [
            {
                "id": u.id,
                "username": u.username,
                "email": u.email,
                "is_active": u.is_active,
                "must_change_password": u.must_change_password,
                "totp_enabled": u.totp_enabled,
                "privileges": sorted(p.privilege for p in u.privileges),
                "created_at": u.created_at.isoformat(),
            }
            for u in users
        ]


register_route_policy("POST", "/api/admin/users", "admin")


@router.post("/api/admin/users", status_code=status.HTTP_201_CREATED)
async def admin_create_user(
    body: CreateUserRequest,
    request: Request,
    principal: Principal = Depends(require("admin")),
) -> dict[str, Any]:
    """Create a new user account with explicit capability privileges."""
    settings = request.app.state.settings
    db: DatabaseManager = request.app.state.db
    client_ip = resolve_client_ip(request, settings)

    unknown = [p for p in body.privileges if p not in ALL_PRIVILEGES]
    if unknown:
        raise HTTPException(status_code=400, detail=f"Unknown privilege(s): {', '.join(unknown)}")

    async def _op(sess: AsyncSession) -> dict[str, Any]:
        uow = UnitOfWork(sess)
        if await uow.users.get_by_username(body.username) is not None:
            raise HTTPException(status_code=409, detail="Username already exists")
        now = datetime.now(UTC)
        user = User(
            id=f"u_{uuid.uuid4().hex[:16]}",
            username=body.username,
            email=body.email,
            password_hash=hash_password(body.password),
            must_change_password=body.must_change_password,
            totp_secret_encrypted=None,
            totp_enabled=False,
            recovery_codes_hashes=[],
            is_active=True,
            created_at=now,
            updated_at=now,
        )
        await uow.users.add(user)
        await uow.users.set_privileges(user, body.privileges, granted_by=principal.user.id)
        await uow.audit.record(
            action="admin.user_created",
            resource_type="user",
            actor_user_id=principal.user.id,
            actor_ip=client_ip,
            resource_id=user.id,
            details={"username": user.username, "privileges": sorted(body.privileges)},
        )
        return {
            "id": user.id,
            "username": user.username,
            "email": user.email,
            "privileges": sorted(body.privileges),
            "must_change_password": user.must_change_password,
        }

    return await db.execute_write(_op)


register_route_policy("PATCH", "/api/admin/users/{user_id}/privileges", "admin")


@router.patch("/api/admin/users/{user_id}/privileges")
async def admin_update_privileges(
    user_id: str,
    body: UpdatePrivilegesRequest,
    request: Request,
    principal: Principal = Depends(require("admin")),
) -> dict[str, Any]:
    """Update a user's capability privilege flags and append an audit log entry."""
    settings = request.app.state.settings
    db: DatabaseManager = request.app.state.db
    client_ip = resolve_client_ip(request, settings)

    unknown = [p for p in body.privileges if p not in ALL_PRIVILEGES]
    if unknown:
        raise HTTPException(status_code=400, detail=f"Unknown privilege(s): {', '.join(unknown)}")

    async def _op(sess: AsyncSession) -> dict[str, Any]:
        uow = UnitOfWork(sess)
        user = await uow.users.get_by_id(user_id)
        if user is None:
            raise HTTPException(status_code=404, detail="User not found")
        await uow.users.set_privileges(user, body.privileges, granted_by=principal.user.id)
        await uow.audit.record(
            action="admin.privileges_updated",
            resource_type="user",
            actor_user_id=principal.user.id,
            actor_ip=client_ip,
            resource_id=user.id,
            details={"privileges": sorted(body.privileges)},
        )
        return {"id": user.id, "privileges": sorted(body.privileges)}

    return await db.execute_write(_op)


register_route_policy("GET", "/api/admin/settings", "admin")


@router.get("/api/admin/settings")
async def admin_get_settings(
    request: Request,
    _principal: Principal = Depends(require("admin")),
) -> dict[str, Any]:
    """Return redacted effective settings, runtime DB overrides, and JSON Schema."""
    settings: Settings = request.app.state.settings
    db = request.app.state.db
    async with db.session() as sess:
        uow = UnitOfWork(sess)
        runtime_overrides = await uow.settings.get_all_runtime()

    return {
        "effective": settings.redacted_dict(),
        "runtime_overrides": runtime_overrides,
        "editable_keys": sorted(Settings.RUNTIME_EDITABLE_KEYS),
        "json_schema": Settings.model_json_schema(),
    }


register_route_policy("PATCH", "/api/admin/settings", "admin")


@router.patch("/api/admin/settings")
async def admin_update_settings(
    body: RuntimeSettingsUpdateRequest,
    request: Request,
    principal: Principal = Depends(require("admin")),
) -> dict[str, Any]:
    """Update runtime-editable non-secret settings stored in the database."""
    settings: Settings = request.app.state.settings
    db = request.app.state.db
    client_ip = resolve_client_ip(request, settings)

    try:
        updated_settings = settings.apply_runtime_overrides(body.overrides)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    async def _op(sess: Any) -> None:
        uow = UnitOfWork(sess)
        for k, v in body.overrides.items():
            await uow.settings.set_runtime(k, v, updated_by=principal.user.id)
        await uow.audit.record(
            action="admin.settings_updated",
            resource_type="settings",
            actor_user_id=principal.user.id,
            actor_ip=client_ip,
            details={"updated_keys": sorted(body.overrides.keys())},
        )

    await db.execute_write(_op)
    request.app.state.settings = updated_settings
    return {"effective": updated_settings.redacted_dict()}


register_route_policy("POST", "/api/admin/secrets", "admin")


@router.post("/api/admin/secrets")
async def admin_upsert_secret(
    body: SecretUpsertRequest,
    request: Request,
    principal: Principal = Depends(require("admin")),
) -> dict[str, Any]:
    """Encrypt a secret at rest using EnvelopeVault and register it for log redaction."""
    settings: Settings = request.app.state.settings
    db = request.app.state.db
    vault = request.app.state.vault
    client_ip = resolve_client_ip(request, settings)

    register_secret_for_redaction(body.value)
    ciphertext = vault.encrypt(body.value, associated_data=f"secret:{body.key}")

    async def _op(sess: Any) -> None:
        uow = UnitOfWork(sess)
        await uow.settings.set_secret(body.key, ciphertext, updated_by=principal.user.id)
        await uow.audit.record(
            action="admin.secret_upserted",
            resource_type="secret",
            actor_user_id=principal.user.id,
            actor_ip=client_ip,
            resource_id=body.key,
            details={"key": body.key},
        )

    await db.execute_write(_op)
    return {"ok": True, "key": body.key, "encrypted": True}


register_route_policy("GET", "/api/admin/audit", "admin")


@router.get("/api/admin/audit")
async def admin_list_audit(
    request: Request,
    _principal: Principal = Depends(require("admin")),
) -> dict[str, Any]:
    """List recent audit log entries and verify hash-chain integrity."""
    db = request.app.state.db
    async with db.session() as sess:
        uow = UnitOfWork(sess)
        valid, count = await uow.audit.verify_chain()
        entries = await uow.audit.list_recent(limit=100)
        return {
            "chain_valid": valid,
            "verified_records": count,
            "entries": [
                {
                    "id": e.id,
                    "timestamp": e.timestamp,
                    "actor_user_id": e.actor_user_id,
                    "actor_ip": e.actor_ip,
                    "action": e.action,
                    "resource_type": e.resource_type,
                    "resource_id": e.resource_id,
                    "details": scrub_value(None, e.details_json),
                    "prev_hash": e.prev_hash,
                    "record_hash": e.record_hash,
                }
                for e in entries
            ],
        }


register_route_policy("POST", "/api/admin/jobs", "admin")


@router.post("/api/admin/jobs", status_code=status.HTTP_201_CREATED)
async def admin_enqueue_job(
    body: EnqueueJobRequest,
    request: Request,
    principal: Principal = Depends(require("admin")),
) -> dict[str, Any]:
    """Enqueue a durable background job managed by JobSupervisor."""
    supervisor = request.app.state.job_supervisor
    job = await supervisor.enqueue(
        body.kind,
        body.payload,
        max_attempts=body.max_attempts,
    )
    return {
        "id": job.id,
        "kind": job.kind,
        "status": job.status,
        "max_attempts": job.max_attempts,
        "requested_by": principal.user.id,
    }


register_route_policy("GET", "/api/admin/diagnostics/support-bundle", "admin")


@router.get("/api/admin/diagnostics/support-bundle")
async def admin_support_bundle(
    request: Request,
    _principal: Principal = Depends(require("admin")),
) -> dict[str, Any]:
    """Export a sanitized diagnostic support bundle with all secrets scrubbed."""
    settings: Settings = request.app.state.settings
    db = request.app.state.db
    ok_db, db_msg = await db.check_health()

    return {
        "generated_at": datetime.now(UTC).isoformat(),
        "version": "0.1.0",
        "database": {"healthy": ok_db, "message": scrub_value("db", db_msg)},
        "settings": settings.redacted_dict(),
        "recent_logs": get_recent_sanitized_logs(),
    }
