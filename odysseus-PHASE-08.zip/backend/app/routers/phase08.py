"""FastAPI router for Phase 08: Cookbook, Gallery & Editor, Voice Mode, and Admin Operations."""

from __future__ import annotations

import base64
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field

from backend.core.security import Principal, register_route_policy, require
from backend.domain.admin_ops.service import AdminOpsService
from backend.domain.cookbook.service import CookbookService, classify_cookbook_failure
from backend.domain.gallery.service import GalleryService
from backend.domain.voice.service import VoiceService

router = APIRouter(tags=["phase08"])


def _cookbook(request: Request) -> CookbookService:
    svc = getattr(request.app.state, "cookbook_service", None)
    if svc is None:
        svc = CookbookService()
        request.app.state.cookbook_service = svc
    assert isinstance(svc, CookbookService)
    return svc


def _gallery(request: Request) -> GalleryService:
    svc = getattr(request.app.state, "gallery_service", None)
    if svc is None:
        svc = GalleryService()
        request.app.state.gallery_service = svc
    assert isinstance(svc, GalleryService)
    return svc


def _voice(request: Request) -> VoiceService:
    svc = getattr(request.app.state, "voice_service", None)
    if svc is None:
        svc = VoiceService()
        request.app.state.voice_service = svc
    assert isinstance(svc, VoiceService)
    return svc


def _admin_ops(request: Request) -> AdminOpsService:
    svc = getattr(request.app.state, "admin_ops_service", None)
    if svc is None:
        svc = AdminOpsService()
        request.app.state.admin_ops_service = svc
    assert isinstance(svc, AdminOpsService)
    return svc


# --- Request Schemas ---


class HardwareRefreshRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    fixture_id: str | None = Field(default=None, max_length=64)


class CookbookDownloadRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    model_id: str = Field(min_length=1, max_length=128)
    filename: str = Field(default="model-q4_k_m.gguf", min_length=1, max_length=128)
    total_bytes: int = Field(default=2_147_483_648, ge=1024)
    disk_free_bytes: int = Field(default=50_000_000_000, ge=0)
    interrupt_offsets: list[int] = Field(default_factory=list)


class EngineInstallRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    engine_name: str = Field(default="llama.cpp", min_length=1, max_length=64)
    version: str = Field(default="b4150", min_length=1, max_length=64)
    variant: str = Field(default="cpu", min_length=1, max_length=32)
    expected_sha256: str = Field(default="valid_sha256", max_length=128)
    actual_sha256: str = Field(default="valid_sha256", max_length=128)
    dry_run: bool = False


class ServeStartRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    model_id: str = Field(default="Qwen/Qwen2.5-0.5B-Instruct-GGUF", min_length=1, max_length=128)
    engine_name: str = Field(default="llama.cpp", min_length=1, max_length=64)
    vram_required_mb: int = Field(default=800, ge=64)
    vram_budget_mb: int = Field(default=24000, ge=64)
    crash_on_start: bool = False
    spawn_real_process: bool = False


class BenchmarkRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    model_id: str = Field(min_length=1, max_length=128)
    engine_name: str = Field(default="llama.cpp", min_length=1, max_length=64)
    context_sizes: list[int] = Field(default_factory=lambda: [2048, 8192, 32768])


class RemoteHostCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1, max_length=128)
    hostname: str = Field(min_length=1, max_length=128)
    username: str = Field(default="ubuntu", min_length=1, max_length=64)
    port: int = Field(default=22, ge=1, le=65535)
    presented_fingerprint: str = Field(default="SHA256:OdysseusRemoteHostKeyPin001", max_length=128)


class RemoteTofuConfirmRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    fingerprint: str = Field(min_length=1, max_length=128)


class RemoteExecuteRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    template_name: str = Field(min_length=1, max_length=64)
    presented_fingerprint: str | None = Field(default=None, max_length=128)
    model_id: str = Field(default="Qwen/Qwen2.5-7B-Instruct-GGUF", max_length=128)


class FailureClassifyRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    log_text: str = Field(min_length=1, max_length=65536)
    exit_code: int = Field(default=1)


class GalleryUploadRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    filename: str = Field(default="upload.png", min_length=1, max_length=128)
    declared_content_type: str = Field(default="image/png", min_length=1, max_length=64)
    data_base64: str = Field(min_length=1, max_length=524288)


class GalleryGenerateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    prompt: str = Field(min_length=1, max_length=2000)
    negative_prompt: str = Field(default="", max_length=1000)
    width: int = Field(default=1024, ge=64, le=16384)
    height: int = Field(default=1024, ge=64, le=16384)
    steps: int = Field(default=25, ge=1, le=150)
    cfg_scale: float = Field(default=7.0, ge=1.0, le=30.0)
    seed: int = Field(default=42)
    model_id: str = Field(default="flux-1-schnell-q4", max_length=128)


class GalleryEditOpRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    type: str = Field(min_length=1, max_length=64)
    value: float | int | str | dict[str, Any] = Field(default=0.0)


class GalleryExportRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    export_format: str = Field(default="png", max_length=16)
    strip_exif: bool = True
    save_as_copy: bool = True


class VoiceTranscribeRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    audio_base64: str = Field(min_length=1, max_length=524288)
    mime_type: str = Field(default="audio/wav", max_length=64)
    duration_seconds: float = Field(default=4.2, gt=0.0, le=600.0)
    language: str = Field(default="en", max_length=16)


class VoiceSynthesizeStreamRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    token_chunks: list[str] = Field(min_length=1)
    voice_id: str = Field(default="af_bella", max_length=64)


class VoiceTurnRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    transcript: str = Field(min_length=1, max_length=4000)


class ProviderAdvancedUpdateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    priority: int | None = Field(default=None, ge=1, le=100)
    fallback_chain: list[str] | None = None
    supports_tools: str | None = Field(default=None, max_length=16)
    daily_cost_limit_usd: float | None = Field(default=None, ge=0.0)
    new_api_key: str | None = Field(default=None, max_length=512)


class ExecPolicyTestRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    command: str = Field(min_length=1, max_length=2048)


class BackupCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    passphrase: str = Field(default="", max_length=256)


class BackupRestoreRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    archive_base64: str = Field(min_length=1, max_length=524288)
    passphrase: str = Field(default="", max_length=256)
    dry_run: bool = True


class PrivacyDeleteRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    confirmation_phrase: str = Field(min_length=1, max_length=128)


# ============================================================================
# 1. Cookbook Routes
# ============================================================================

register_route_policy("GET", "/api/cookbook/hardware", "cookbook")


@router.get("/api/cookbook/hardware")
async def get_cookbook_hardware(
    request: Request,
    _principal: Principal = Depends(require("cookbook")),
) -> dict[str, Any]:
    return _cookbook(request).get_hardware_snapshot()


register_route_policy("POST", "/api/cookbook/hardware/refresh", "cookbook")


@router.post("/api/cookbook/hardware/refresh")
async def refresh_cookbook_hardware(
    body: HardwareRefreshRequest,
    request: Request,
    _principal: Principal = Depends(require("cookbook")),
) -> dict[str, Any]:
    return _cookbook(request).refresh_hardware_snapshot(fixture_id=body.fixture_id)


register_route_policy("GET", "/api/cookbook/models", "cookbook")


@router.get("/api/cookbook/models")
async def list_cookbook_models(
    request: Request,
    query: str = "",
    fit: str = "",
    backend: str = "",
    hw_fixture_id: str | None = None,
    _principal: Principal = Depends(require("cookbook")),
) -> dict[str, Any]:
    return _cookbook(request).list_models(
        query=query,
        fit_filter=fit,
        backend_filter=backend,
        hw_fixture_id=hw_fixture_id,
    )


register_route_policy("POST", "/api/cookbook/downloads", "cookbook")


@router.post("/api/cookbook/downloads")
async def start_cookbook_download(
    body: CookbookDownloadRequest,
    request: Request,
    _principal: Principal = Depends(require("cookbook")),
) -> dict[str, Any]:
    try:
        return _cookbook(request).start_download(
            model_id=body.model_id,
            filename=body.filename,
            total_bytes=body.total_bytes,
            disk_free_bytes=body.disk_free_bytes,
            interrupt_offsets=body.interrupt_offsets,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


register_route_policy("GET", "/api/cookbook/downloads/{download_id}", "cookbook")


@router.get("/api/cookbook/downloads/{download_id}")
async def get_cookbook_download(
    download_id: str,
    request: Request,
    _principal: Principal = Depends(require("cookbook")),
) -> dict[str, Any]:
    try:
        job = _cookbook(request).get_download(download_id)
        events = _cookbook(request).get_download_events(download_id)
        return {**job, "events": events}
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("POST", "/api/cookbook/engines/install", "cookbook")


@router.post("/api/cookbook/engines/install")
async def install_cookbook_engine(
    body: EngineInstallRequest,
    request: Request,
    _principal: Principal = Depends(require("cookbook")),
) -> dict[str, Any]:
    try:
        return _cookbook(request).install_engine(
            body.engine_name,
            version=body.version,
            variant=body.variant,
            expected_sha256=body.expected_sha256,
            actual_sha256=body.actual_sha256,
            dry_run=body.dry_run,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


register_route_policy("POST", "/api/cookbook/serves", "cookbook")


@router.post("/api/cookbook/serves")
async def start_cookbook_serve(
    body: ServeStartRequest,
    request: Request,
    _principal: Principal = Depends(require("cookbook")),
) -> dict[str, Any]:
    try:
        return _cookbook(request).start_serve(
            model_id=body.model_id,
            engine_name=body.engine_name,
            vram_required_mb=body.vram_required_mb,
            vram_budget_mb=body.vram_budget_mb,
            crash_on_start=body.crash_on_start,
            spawn_real_process=body.spawn_real_process,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


register_route_policy("GET", "/api/cookbook/serves", "cookbook")


@router.get("/api/cookbook/serves")
async def list_cookbook_serves(
    request: Request,
    _principal: Principal = Depends(require("cookbook")),
) -> dict[str, Any]:
    svc = _cookbook(request)
    return {
        "serves": svc.list_serves(),
        "registered_providers": svc.list_registered_local_providers(),
    }


register_route_policy("POST", "/api/cookbook/serves/{serve_id}/stop", "cookbook")


@router.post("/api/cookbook/serves/{serve_id}/stop")
async def stop_cookbook_serve(
    serve_id: str,
    request: Request,
    _principal: Principal = Depends(require("cookbook")),
) -> dict[str, Any]:
    try:
        return _cookbook(request).stop_serve(serve_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("POST", "/api/cookbook/benchmarks", "cookbook")


@router.post("/api/cookbook/benchmarks")
async def run_cookbook_benchmark(
    body: BenchmarkRequest,
    request: Request,
    _principal: Principal = Depends(require("cookbook")),
) -> dict[str, Any]:
    try:
        return _cookbook(request).run_benchmark(
            model_id=body.model_id,
            engine_name=body.engine_name,
            context_sizes=body.context_sizes,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


register_route_policy("POST", "/api/cookbook/remotes", "cookbook")


@router.post("/api/cookbook/remotes")
async def register_cookbook_remote(
    body: RemoteHostCreateRequest,
    request: Request,
    _principal: Principal = Depends(require("cookbook")),
) -> dict[str, Any]:
    try:
        return _cookbook(request).register_remote_host(
            name=body.name,
            hostname=body.hostname,
            username=body.username,
            port=body.port,
            presented_fingerprint=body.presented_fingerprint,
        )
    except (ValueError, PermissionError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


register_route_policy("POST", "/api/cookbook/remotes/{remote_id}/confirm-tofu", "cookbook")


@router.post("/api/cookbook/remotes/{remote_id}/confirm-tofu")
async def confirm_cookbook_remote_tofu(
    remote_id: str,
    body: RemoteTofuConfirmRequest,
    request: Request,
    _principal: Principal = Depends(require("cookbook")),
) -> dict[str, Any]:
    try:
        return _cookbook(request).confirm_remote_tofu(remote_id, fingerprint=body.fingerprint)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


register_route_policy("POST", "/api/cookbook/remotes/{remote_id}/execute", "cookbook")


@router.post("/api/cookbook/remotes/{remote_id}/execute")
async def execute_cookbook_remote_template(
    remote_id: str,
    body: RemoteExecuteRequest,
    request: Request,
    _principal: Principal = Depends(require("cookbook")),
) -> dict[str, Any]:
    try:
        return _cookbook(request).execute_remote_template(
            remote_id,
            template_name=body.template_name,
            presented_fingerprint=body.presented_fingerprint,
            model_id=body.model_id,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


register_route_policy("POST", "/api/cookbook/failures/classify", "cookbook")


@router.post("/api/cookbook/failures/classify")
async def classify_cookbook_failure_endpoint(
    body: FailureClassifyRequest,
    _principal: Principal = Depends(require("cookbook")),
) -> dict[str, Any]:
    return classify_cookbook_failure(body.log_text, exit_code=body.exit_code)


# ============================================================================
# 2. Gallery & Non-Destructive Tiled Image Editor Routes
# ============================================================================

register_route_policy("GET", "/api/gallery/items", "files")


@router.get("/api/gallery/items")
async def list_gallery_items(
    request: Request,
    query: str = "",
    model_id: str = "",
    _principal: Principal = Depends(require("files")),
) -> dict[str, Any]:
    return {"items": _gallery(request).list_media(query=query, model_id=model_id)}


register_route_policy("POST", "/api/gallery/upload", "files")


@router.post("/api/gallery/upload")
async def upload_gallery_media(
    body: GalleryUploadRequest,
    request: Request,
    _principal: Principal = Depends(require("files")),
) -> dict[str, Any]:
    try:
        raw = base64.b64decode(body.data_base64)
        return _gallery(request).upload_media(
            raw,
            declared_content_type=body.declared_content_type,
            filename=body.filename,
        )
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


register_route_policy("POST", "/api/gallery/generate", "files")


@router.post("/api/gallery/generate")
async def generate_gallery_image(
    body: GalleryGenerateRequest,
    request: Request,
    _principal: Principal = Depends(require("files")),
) -> dict[str, Any]:
    try:
        return _gallery(request).generate_image(
            prompt=body.prompt,
            negative_prompt=body.negative_prompt,
            width=body.width,
            height=body.height,
            steps=body.steps,
            cfg_scale=body.cfg_scale,
            seed=body.seed,
            model_id=body.model_id,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


register_route_policy("POST", "/api/gallery/items/{media_id}/ops", "files")


@router.post("/api/gallery/items/{media_id}/ops")
async def apply_gallery_edit_op(
    media_id: str,
    body: GalleryEditOpRequest,
    request: Request,
    _principal: Principal = Depends(require("files")),
) -> dict[str, Any]:
    try:
        return _gallery(request).apply_edit_op(media_id, {"type": body.type, "value": body.value})
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


register_route_policy("POST", "/api/gallery/items/{media_id}/undo", "files")


@router.post("/api/gallery/items/{media_id}/undo")
async def undo_gallery_edit_op(
    media_id: str,
    request: Request,
    _principal: Principal = Depends(require("files")),
) -> dict[str, Any]:
    try:
        return _gallery(request).undo_edit_op(media_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("POST", "/api/gallery/items/{media_id}/redo", "files")


@router.post("/api/gallery/items/{media_id}/redo")
async def redo_gallery_edit_op(
    media_id: str,
    request: Request,
    _principal: Principal = Depends(require("files")),
) -> dict[str, Any]:
    try:
        return _gallery(request).redo_edit_op(media_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("POST", "/api/gallery/items/{media_id}/export", "files")


@router.post("/api/gallery/items/{media_id}/export")
async def export_gallery_media(
    media_id: str,
    body: GalleryExportRequest,
    request: Request,
    _principal: Principal = Depends(require("files")),
) -> dict[str, Any]:
    try:
        res = _gallery(request).export_media(
            media_id,
            export_format=body.export_format,
            strip_exif=body.strip_exif,
            save_as_copy=body.save_as_copy,
        )
        out = {k: v for k, v in res.items() if k != "payload_bytes"}
        out["payload_base64"] = base64.b64encode(res["payload_bytes"]).decode("ascii")
        return out
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


# ============================================================================
# 3. Voice (STT, Streaming Sentence TTS, Barge-In, Voice Mode) Routes
# ============================================================================

register_route_policy("POST", "/api/voice/transcribe", "chat")


@router.post("/api/voice/transcribe")
async def transcribe_voice_audio(
    body: VoiceTranscribeRequest,
    request: Request,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    try:
        raw = base64.b64decode(body.audio_base64)
        return _voice(request).transcribe_audio(
            raw,
            mime_type=body.mime_type,
            duration_seconds=body.duration_seconds,
            language=body.language,
        )
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


register_route_policy("POST", "/api/voice/synthesize-stream", "chat")


@router.post("/api/voice/synthesize-stream")
async def synthesize_voice_stream(
    body: VoiceSynthesizeStreamRequest,
    request: Request,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    return _voice(request).synthesize_streaming_tokens(
        body.token_chunks,
        voice_id=body.voice_id,
    )


register_route_policy("POST", "/api/voice/sessions", "chat")


@router.post("/api/voice/sessions")
async def create_voice_session(
    request: Request,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    return _voice(request).create_session()


register_route_policy("POST", "/api/voice/sessions/{session_id}/turn", "chat")


@router.post("/api/voice/sessions/{session_id}/turn")
async def start_voice_turn(
    session_id: str,
    body: VoiceTurnRequest,
    request: Request,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    try:
        return _voice(request).start_speaking_turn(session_id, body.transcript)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("POST", "/api/voice/sessions/{session_id}/barge-in", "chat")


@router.post("/api/voice/sessions/{session_id}/barge-in")
async def trigger_voice_barge_in(
    session_id: str,
    request: Request,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    try:
        return _voice(request).trigger_barge_in(session_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


# ============================================================================
# 4. Admin Console & Operations + Guided Tours Routes
# ============================================================================

register_route_policy("GET", "/api/admin/ops/providers", "admin")


@router.get("/api/admin/ops/providers")
async def list_admin_ops_providers(
    request: Request,
    _principal: Principal = Depends(require("admin")),
) -> dict[str, Any]:
    return {"providers": _admin_ops(request).list_providers_advanced()}


register_route_policy("PATCH", "/api/admin/ops/providers/{provider_id}", "admin")


@router.patch("/api/admin/ops/providers/{provider_id}")
async def update_admin_ops_provider(
    provider_id: str,
    body: ProviderAdvancedUpdateRequest,
    request: Request,
    _principal: Principal = Depends(require("admin")),
) -> dict[str, Any]:
    try:
        return _admin_ops(request).update_provider_advanced(
            provider_id,
            priority=body.priority,
            fallback_chain=body.fallback_chain,
            supports_tools=body.supports_tools,
            daily_cost_limit_usd=body.daily_cost_limit_usd,
            new_api_key=body.new_api_key,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


register_route_policy("GET", "/api/admin/ops/usage", "admin")


@router.get("/api/admin/ops/usage")
async def get_admin_ops_usage(
    request: Request,
    demo_mode: bool = False,
    _principal: Principal = Depends(require("admin")),
) -> dict[str, Any]:
    return _admin_ops(request).get_usage_dashboard(demo_mode=demo_mode)


register_route_policy("POST", "/api/admin/ops/exec-policy/test", "admin")


@router.post("/api/admin/ops/exec-policy/test")
async def test_admin_exec_policy(
    body: ExecPolicyTestRequest,
    request: Request,
    _principal: Principal = Depends(require("admin")),
) -> dict[str, Any]:
    return _admin_ops(request).test_exec_policy_pattern(body.command)


register_route_policy("POST", "/api/admin/ops/support-bundle", "admin")


@router.post("/api/admin/ops/support-bundle")
async def generate_admin_support_bundle(
    request: Request,
    _principal: Principal = Depends(require("admin")),
) -> dict[str, Any]:
    bundle = _admin_ops(request).generate_support_bundle()
    return {
        "bundle_id": bundle["bundle_id"],
        "scrubbed_log_text": bundle["scrubbed_log_text"],
        "zip_sha256": bundle["zip_sha256"],
        "planted_formats_tested": bundle["planted_formats_tested"],
    }


register_route_policy("POST", "/api/admin/ops/backups", "admin")


@router.post("/api/admin/ops/backups")
async def create_admin_backup(
    body: BackupCreateRequest,
    request: Request,
    _principal: Principal = Depends(require("admin")),
) -> dict[str, Any]:
    bkp = _admin_ops(request).create_backup(passphrase=body.passphrase)
    return {
        "backup_id": bkp["backup_id"],
        "manifest": bkp["manifest"],
        "archive_sha256": bkp["archive_sha256"],
        "size_bytes": bkp["size_bytes"],
        "archive_base64": base64.b64encode(bkp["archive_bytes"]).decode("ascii"),
    }


register_route_policy("POST", "/api/admin/ops/backups/restore", "admin")


@router.post("/api/admin/ops/backups/restore")
async def restore_admin_backup(
    body: BackupRestoreRequest,
    request: Request,
    _principal: Principal = Depends(require("admin")),
) -> dict[str, Any]:
    try:
        raw = base64.b64decode(body.archive_base64)
        return _admin_ops(request).verify_or_restore_backup(
            raw,
            passphrase=body.passphrase,
            dry_run=body.dry_run,
        )
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


register_route_policy("GET", "/api/admin/ops/privacy", "authenticated")


@router.get("/api/admin/ops/privacy")
async def get_privacy_inventory(
    request: Request,
    _principal: Principal = Depends(require("authenticated")),
) -> dict[str, Any]:
    return _admin_ops(request).get_privacy_residency_inventory()


register_route_policy("POST", "/api/admin/ops/privacy/export", "authenticated")


@router.post("/api/admin/ops/privacy/export")
async def export_my_privacy_data(
    request: Request,
    principal: Principal = Depends(require("authenticated")),
) -> dict[str, Any]:
    res = _admin_ops(request).export_all_my_data(user_id=principal.user.id)
    return {
        "user_id": res["user_id"],
        "sha256": res["sha256"],
        "byte_length": res["byte_length"],
        "zip_base64": base64.b64encode(res["zip_bytes"]).decode("ascii"),
    }


register_route_policy("POST", "/api/admin/ops/privacy/delete", "authenticated")


@router.post("/api/admin/ops/privacy/delete")
async def delete_my_privacy_data(
    body: PrivacyDeleteRequest,
    request: Request,
    _principal: Principal = Depends(require("authenticated")),
) -> dict[str, Any]:
    try:
        return _admin_ops(request).delete_all_my_data(confirmation_phrase=body.confirmation_phrase)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


register_route_policy("GET", "/api/guided-tours", "authenticated")


@router.get("/api/guided-tours")
async def list_guided_tours_endpoint(
    request: Request,
    _principal: Principal = Depends(require("authenticated")),
) -> dict[str, Any]:
    return {"tours": _admin_ops(request).list_guided_tours()}


register_route_policy("POST", "/api/guided-tours/{module_id}/complete", "authenticated")


@router.post("/api/guided-tours/{module_id}/complete")
async def complete_guided_tour_endpoint(
    module_id: str,
    request: Request,
    _principal: Principal = Depends(require("authenticated")),
) -> dict[str, Any]:
    return _admin_ops(request).complete_guided_tour(module_id)
