"""FastAPI router for Phase 06 Knowledge & Creation: RAG, Research, Compare, Documents."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, ConfigDict, Field

from backend.core.db import DatabaseManager
from backend.core.security import Principal, register_route_policy, require
from backend.core.uow import UnitOfWork
from backend.domain.compare import CompareService
from backend.domain.documents import DocumentsService
from backend.domain.documents.service import AiAuthoringActionLiteral, DocFormatLiteral
from backend.domain.rag import RagService, evaluate_hybrid_retrieval_benchmark
from backend.domain.research import (
    REPORT_STRICT_CSP,
    DeepResearchService,
    verify_citations_and_quotes,
)
from backend.domain.research.service import ResearchDepthLiteral, ResearchModelProfileLiteral
from backend.domain.tools.web_tools import execute_web_search, render_domain_favicon_svg

router = APIRouter(tags=["knowledge"])


# --- Request Schemas ---


class WebSearchRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    query: str = Field(min_length=1, max_length=512)
    max_results: int = Field(default=5, ge=1, le=20)


class CitationVerifyRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    answer_text: str = Field(min_length=1, max_length=65536)
    sources: list[dict[str, Any]] = Field(default_factory=list)


class RagIngestRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    title: str = Field(min_length=1, max_length=256)
    text: str = Field(min_length=1, max_length=524288)
    doc_id: str | None = Field(default=None, max_length=64)
    project_id: str | None = Field(default=None, max_length=64)
    chunk_size: int = Field(default=512, ge=128, le=4096)
    chunk_overlap: int = Field(default=64, ge=0, le=512)


class RagQueryRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    query: str = Field(min_length=1, max_length=1024)
    project_id: str | None = Field(default=None, max_length=64)
    top_k: int = Field(default=5, ge=1, le=20)
    mode: str = Field(default="hybrid", max_length=16)


class ResearchStartRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    topic: str = Field(min_length=1, max_length=1024)
    depth: ResearchDepthLiteral = "standard"
    model_profile: ResearchModelProfileLiteral = "medium"
    max_sources_override: int | None = Field(default=None, ge=1, le=32)
    max_tokens_override: int | None = Field(default=None, ge=64, le=131072)
    seed_urls: list[str] | None = None
    draft_override: str | None = Field(default=None, max_length=65536)


class ResearchSteerRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    guidance: str = Field(min_length=1, max_length=1024)


class CompareStartRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    prompt: str = Field(min_length=1, max_length=8192)
    models: list[str] = Field(default_factory=lambda: ["fake/reasoning", "fake/fast"])
    blind: bool = True
    simulate_failure_models: list[str] | None = None


class CompareVoteRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    winner_slot: str = Field(min_length=1, max_length=8)


class DocumentCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    title: str = Field(min_length=1, max_length=256)
    content: str = Field(default="", max_length=8_388_608)
    format: DocFormatLiteral = "markdown"
    folder: str = Field(default="/", max_length=128)
    tags: list[str] = Field(default_factory=list)
    project_id: str | None = Field(default=None, max_length=64)


class DocumentUpdateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    title: str | None = Field(default=None, max_length=256)
    content: str | None = Field(default=None, max_length=8_388_608)
    folder: str | None = Field(default=None, max_length=128)
    tags: list[str] | None = None
    expected_version: int | None = None
    expected_etag: str | None = Field(default=None, max_length=128)
    force_merge: bool = False
    summary: str = Field(default="Updated document", max_length=256)


class DocumentAiSuggestRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    selection_text: str = Field(default="", max_length=16384)
    action: AiAuthoringActionLiteral = "rewrite"
    target_language: str = Field(default="Indonesian", max_length=64)


class DocumentSuggestionResolveRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    accept: bool = True


class DocumentQaRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    question: str = Field(min_length=1, max_length=1024)


# --- 1. Search, Favicon Proxy & Citation Verifier ---


register_route_policy("GET", "/api/knowledge/favicon", "chat")


@router.get("/api/knowledge/favicon")
async def get_domain_favicon(
    domain: str = "odysseus.local",
    _principal: Principal = Depends(require("chat")),
) -> Response:
    svg_body = render_domain_favicon_svg(domain)
    return Response(content=svg_body, media_type="image/svg+xml")


register_route_policy("POST", "/api/knowledge/search", "chat")


@router.post("/api/knowledge/search")
async def search_web_sources(
    body: WebSearchRequest,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    results = await execute_web_search(body.query, max_results=body.max_results)
    return {"query": body.query, "results": results}


register_route_policy("POST", "/api/knowledge/verify-citations", "chat")


@router.post("/api/knowledge/verify-citations")
async def verify_citations_endpoint(
    body: CitationVerifyRequest,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    sources_by_id: dict[int, dict[str, Any]] = {}
    for idx, src in enumerate(body.sources, start=1):
        cid = int(src.get("id", idx))
        sources_by_id[cid] = src
    report = verify_citations_and_quotes(body.answer_text, sources_by_id)
    return report.to_dict()


# --- 2. Knowledge Base / Hybrid RAG ---


register_route_policy("GET", "/api/rag/documents", "chat")


@router.get("/api/rag/documents")
async def list_rag_documents(
    request: Request,
    project_id: str | None = None,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    rag: RagService = request.app.state.rag_service
    docs = rag.list_documents(requesting_user_id=principal.user.id, project_id=project_id)
    return {"documents": docs, "vector_store_online": rag.vector_store_online}


register_route_policy("POST", "/api/rag/documents", "chat")


@router.post("/api/rag/documents")
async def ingest_rag_document(
    body: RagIngestRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    rag: RagService = request.app.state.rag_service
    doc = rag.ingest_document(
        owner_user_id=principal.user.id,
        title=body.title,
        text=body.text,
        doc_id=body.doc_id,
        project_id=body.project_id,
        chunk_size=body.chunk_size,
        chunk_overlap=body.chunk_overlap,
    )
    return {
        "doc_id": doc.doc_id,
        "title": doc.title,
        "owner_user_id": doc.owner_user_id,
        "project_id": doc.project_id,
        "content_hash": doc.content_hash,
        "chunk_count": doc.chunk_count,
        "created_at": doc.created_at,
    }


register_route_policy("DELETE", "/api/rag/documents/{doc_id}", "chat")


@router.delete("/api/rag/documents/{doc_id}")
async def delete_rag_document(
    doc_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    rag: RagService = request.app.state.rag_service
    removed = rag.delete_document(doc_id, requesting_user_id=principal.user.id)
    if not removed:
        raise HTTPException(status_code=404, detail="RAG document not found")
    return {"deleted": True, "doc_id": doc_id}


register_route_policy("POST", "/api/rag/query", "chat")


@router.post("/api/rag/query")
async def query_rag_knowledge_base(
    body: RagQueryRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    rag: RagService = request.app.state.rag_service
    res = rag.query(
        body.query,
        requesting_user_id=principal.user.id,
        project_id=body.project_id,
        top_k=body.top_k,
        mode=body.mode,
    )
    return res.to_dict()


register_route_policy("GET", "/api/rag/eval", "chat")


@router.get("/api/rag/eval")
async def evaluate_rag_benchmark(
    num_pairs: int = 100,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    summary = evaluate_hybrid_retrieval_benchmark(max(100, min(num_pairs, 200)))
    return summary.to_dict()


# --- 3. Deep Research ---


register_route_policy("GET", "/api/research/runs", "chat")


@router.get("/api/research/runs")
async def list_research_runs(
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    research: DeepResearchService = request.app.state.research_service
    return {"runs": research.list_runs(user_id=principal.user.id)}


register_route_policy("POST", "/api/research/runs", "chat")


@router.post("/api/research/runs")
async def start_research_run(
    body: ResearchStartRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    research: DeepResearchService = request.app.state.research_service
    rec = await research.execute_research(
        user_id=principal.user.id,
        topic=body.topic,
        depth=body.depth,
        model_profile=body.model_profile,
        max_sources_override=body.max_sources_override,
        max_tokens_override=body.max_tokens_override,
        seed_urls=body.seed_urls,
        draft_override=body.draft_override,
    )
    return rec.to_dict()


register_route_policy("GET", "/api/research/runs/{research_id}", "chat")


@router.get("/api/research/runs/{research_id}")
async def get_research_run(
    research_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    research: DeepResearchService = request.app.state.research_service
    rec = research.get_run(research_id)
    if rec is None or rec.user_id != principal.user.id:
        raise HTTPException(status_code=404, detail="Research run not found")
    return rec.to_dict()


register_route_policy("GET", "/api/research/runs/{research_id}/report.html", "chat")


@router.get("/api/research/runs/{research_id}/report.html")
async def get_research_sanitized_html_report(
    research_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> Response:
    research: DeepResearchService = request.app.state.research_service
    rec = research.get_run(research_id)
    if rec is None or rec.user_id != principal.user.id:
        raise HTTPException(status_code=404, detail="Research run not found")
    return Response(
        content=rec.report_html,
        media_type="text/html; charset=utf-8",
        headers={"Content-Security-Policy": REPORT_STRICT_CSP},
    )


register_route_policy("POST", "/api/research/runs/{research_id}/steer", "chat")


@router.post("/api/research/runs/{research_id}/steer")
async def steer_research_run(
    research_id: str,
    body: ResearchSteerRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    research: DeepResearchService = request.app.state.research_service
    rec = research.get_run(research_id)
    if rec is None or rec.user_id != principal.user.id:
        raise HTTPException(status_code=404, detail="Research run not found")
    updated = research.steer_run(research_id, body.guidance)
    assert updated is not None
    return updated.to_dict()


register_route_policy("POST", "/api/research/runs/{research_id}/send-to-documents", "chat")


@router.post("/api/research/runs/{research_id}/send-to-documents")
async def send_research_to_documents(
    research_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    research: DeepResearchService = request.app.state.research_service
    docs: DocumentsService = request.app.state.documents_service
    rec = research.get_run(research_id)
    if rec is None or rec.user_id != principal.user.id:
        raise HTTPException(status_code=404, detail="Research run not found")
    doc = docs.create_document(
        owner_user_id=principal.user.id,
        title=f"Research Report: {rec.topic}",
        content=rec.report_markdown,
        doc_format="markdown",
        folder="/research",
        tags=["research", rec.depth],
    )
    return doc.to_dict()


# --- 4. Multi-Model Compare ---


register_route_policy("POST", "/api/compare/runs", "chat")


@router.post("/api/compare/runs")
async def start_compare_run(
    body: CompareStartRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    compare: CompareService = request.app.state.compare_service
    rec = await compare.create_compare_run(
        user_id=principal.user.id,
        prompt=body.prompt,
        models=body.models,
        blind=body.blind,
        simulate_failure_models=body.simulate_failure_models,
    )
    return rec.to_public_dict()


register_route_policy("GET", "/api/compare/runs/{compare_id}", "chat")


@router.get("/api/compare/runs/{compare_id}")
async def get_compare_run(
    compare_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    compare: CompareService = request.app.state.compare_service
    rec = compare.get_run(compare_id)
    if rec is None or rec.user_id != principal.user.id:
        raise HTTPException(status_code=404, detail="Compare run not found")
    return rec.to_public_dict()


register_route_policy("POST", "/api/compare/runs/{compare_id}/vote", "chat")


@router.post("/api/compare/runs/{compare_id}/vote")
async def vote_compare_run(
    compare_id: str,
    body: CompareVoteRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    compare: CompareService = request.app.state.compare_service
    rec = compare.get_run(compare_id)
    if rec is None or rec.user_id != principal.user.id:
        raise HTTPException(status_code=404, detail="Compare run not found")
    updated = compare.submit_vote(compare_id, winner_slot=body.winner_slot)
    assert updated is not None
    return updated.to_public_dict()


register_route_policy("POST", "/api/compare/runs/{compare_id}/judge", "chat")


@router.post("/api/compare/runs/{compare_id}/judge")
async def judge_compare_run(
    compare_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    compare: CompareService = request.app.state.compare_service
    rec = compare.get_run(compare_id)
    if rec is None or rec.user_id != principal.user.id:
        raise HTTPException(status_code=404, detail="Compare run not found")
    verdict = compare.judge_run(compare_id)
    if verdict is None:
        raise HTTPException(status_code=400, detail="Requires at least 2 completed columns")
    return {"compare_id": compare_id, "judge_result": verdict}


register_route_policy("GET", "/api/compare/leaderboard", "chat")


@router.get("/api/compare/leaderboard")
async def get_compare_leaderboard(
    request: Request,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    compare: CompareService = request.app.state.compare_service
    return {"leaderboard": compare.get_leaderboard()}


# --- 5. Documents & Spreadsheet Workspace ---


register_route_policy("GET", "/api/documents", "chat")


@router.get("/api/documents")
async def list_workspace_documents(
    request: Request,
    folder: str | None = None,
    tag: str | None = None,
    q: str | None = None,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    docs: DocumentsService = request.app.state.documents_service
    items = docs.list_documents(
        requesting_user_id=principal.user.id,
        folder=folder,
        tag=tag,
        search_query=q,
    )
    return {"documents": items}


register_route_policy("POST", "/api/documents", "chat")


@router.post("/api/documents")
async def create_workspace_document(
    body: DocumentCreateRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    docs: DocumentsService = request.app.state.documents_service
    rag: RagService = request.app.state.rag_service
    doc = docs.create_document(
        owner_user_id=principal.user.id,
        title=body.title,
        content=body.content,
        doc_format=body.format,
        folder=body.folder,
        tags=body.tags,
        project_id=body.project_id,
    )
    if body.content.strip():
        rag.ingest_document(
            owner_user_id=principal.user.id,
            title=doc.title,
            text=doc.content,
            doc_id=doc.id,
            project_id=doc.project_id,
        )
    return doc.to_dict(include_content=True)


register_route_policy("GET", "/api/documents/{doc_id}", "chat")


@router.get("/api/documents/{doc_id}")
async def get_workspace_document(
    doc_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    docs: DocumentsService = request.app.state.documents_service
    doc = docs.get_document(doc_id, requesting_user_id=principal.user.id)
    if doc is None:
        raise HTTPException(status_code=404, detail="Document not found")
    return doc.to_dict(include_content=True)


register_route_policy("PUT", "/api/documents/{doc_id}", "chat")


@router.put("/api/documents/{doc_id}")
async def update_workspace_document(
    doc_id: str,
    body: DocumentUpdateRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    docs: DocumentsService = request.app.state.documents_service
    rag: RagService = request.app.state.rag_service
    try:
        outcome = docs.update_document(
            doc_id,
            requesting_user_id=principal.user.id,
            content=body.content,
            title=body.title,
            folder=body.folder,
            tags=body.tags,
            expected_version=body.expected_version,
            expected_etag=body.expected_etag,
            force_merge=body.force_merge,
            summary=body.summary,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    if outcome.get("status") == "ok":
        doc_dict = outcome["document"]
        if str(doc_dict.get("content", "")).strip():
            rag.ingest_document(
                owner_user_id=principal.user.id,
                title=str(doc_dict["title"]),
                text=str(doc_dict["content"]),
                doc_id=str(doc_dict["id"]),
                project_id=doc_dict.get("project_id"),
            )
    return outcome


register_route_policy("DELETE", "/api/documents/{doc_id}", "chat")


@router.delete("/api/documents/{doc_id}")
async def delete_workspace_document(
    doc_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    docs: DocumentsService = request.app.state.documents_service
    rag: RagService = request.app.state.rag_service
    removed = docs.soft_delete_document(doc_id, requesting_user_id=principal.user.id)
    if not removed:
        raise HTTPException(status_code=404, detail="Document not found")
    rag.delete_document(doc_id, requesting_user_id=principal.user.id)
    return {"deleted": True, "doc_id": doc_id}


register_route_policy("GET", "/api/documents/{doc_id}/diff", "chat")


@router.get("/api/documents/{doc_id}/diff")
async def diff_workspace_document_versions(
    doc_id: str,
    from_version: int,
    to_version: int,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    docs: DocumentsService = request.app.state.documents_service
    try:
        return docs.diff_versions(
            doc_id,
            requesting_user_id=principal.user.id,
            from_version=from_version,
            to_version=to_version,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


register_route_policy("POST", "/api/documents/{doc_id}/suggestions", "chat")


@router.post("/api/documents/{doc_id}/suggestions")
async def propose_document_ai_suggestion(
    doc_id: str,
    body: DocumentAiSuggestRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    docs: DocumentsService = request.app.state.documents_service
    try:
        sug = docs.propose_ai_suggestion(
            doc_id,
            requesting_user_id=principal.user.id,
            selection_text=body.selection_text,
            action=body.action,
            target_language=body.target_language,
        )
        return sug.to_dict()
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("POST", "/api/documents/{doc_id}/suggestions/{suggestion_id}/resolve", "chat")


@router.post("/api/documents/{doc_id}/suggestions/{suggestion_id}/resolve")
async def resolve_document_ai_suggestion(
    doc_id: str,
    suggestion_id: str,
    body: DocumentSuggestionResolveRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    docs: DocumentsService = request.app.state.documents_service
    try:
        return docs.resolve_suggestion(
            doc_id,
            suggestion_id,
            requesting_user_id=principal.user.id,
            accept=body.accept,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("POST", "/api/documents/{doc_id}/qa", "chat")


@router.post("/api/documents/{doc_id}/qa")
async def ask_document_question(
    doc_id: str,
    body: DocumentQaRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    docs: DocumentsService = request.app.state.documents_service
    try:
        return docs.ask_document_qa(
            doc_id,
            requesting_user_id=principal.user.id,
            question=body.question,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("GET", "/api/documents/{doc_id}/export", "chat")


@router.get("/api/documents/{doc_id}/export")
async def export_workspace_document(
    doc_id: str,
    request: Request,
    format: str = "md",
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    docs: DocumentsService = request.app.state.documents_service
    try:
        return docs.export_document(
            doc_id,
            requesting_user_id=principal.user.id,
            export_format=format,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("POST", "/api/artifacts/{artifact_id}/send-to-documents", "chat")


@router.post("/api/artifacts/{artifact_id}/send-to-documents")
async def send_artifact_to_documents(
    artifact_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    """Send an artifact (`FE-ART-06`) into the Documents workspace."""
    db: DatabaseManager = request.app.state.db
    docs: DocumentsService = request.app.state.documents_service
    async with db.session() as sess:
        uow = UnitOfWork(sess)
        art = await uow.artifacts.get(artifact_id)
        if art is None or art.user_id != principal.user.id:
            raise HTTPException(status_code=404, detail="Artifact not found")
        ver = await uow.artifacts.get_version(artifact_id, art.latest_version)
        content = ver.content if ver is not None else ""

    fmt_map: dict[str, DocFormatLiteral] = {
        "markdown": "markdown",
        "html": "html",
        "csv": "csv",
        "code": "code",
    }
    doc = docs.create_document(
        owner_user_id=principal.user.id,
        title=art.title,
        content=content,
        doc_format=fmt_map.get(art.type, "markdown"),
        folder="/artifacts",
        tags=["artifact", art.type],
    )
    return doc.to_dict(include_content=True)
