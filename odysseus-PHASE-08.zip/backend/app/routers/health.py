"""Health, readiness, degraded-service diagnostics, and Prometheus metrics endpoints."""

from __future__ import annotations

import os

import httpx
from fastapi import APIRouter, Request, Response
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from backend.core.db import get_disk_degraded
from backend.core.metrics import render_prometheus_metrics
from backend.core.migrations import get_current_revision_async, get_head_revision
from backend.core.security import register_route_policy

router = APIRouter(tags=["health"])


class LiveResponse(BaseModel):
    status: str


class ReadyResponse(BaseModel):
    status: str
    database: str
    migrations: str
    revision: str | None = None


class DegradedServiceItem(BaseModel):
    service: str
    status: str
    reason: str
    fix_hint: str


class DegradedResponse(BaseModel):
    degraded: bool
    services: list[DegradedServiceItem]


register_route_policy("GET", "/api/health/live", "public")


@router.get("/api/health/live", response_model=LiveResponse)
async def health_live() -> LiveResponse:
    """Liveness probe: returns 200 if process event loop is responsive."""
    return LiveResponse(status="live")


register_route_policy("GET", "/api/health/ready", "public")


@router.get("/api/health/ready", response_model=ReadyResponse)
async def health_ready(request: Request) -> Response:
    """Readiness probe: verifies database connectivity, migration head, and storage health."""
    db = request.app.state.db
    ok_db, db_reason = await db.check_health()
    disk_reason = get_disk_degraded()

    current_rev: str | None = None
    migrations_ok = False
    if ok_db:
        try:
            head_rev = get_head_revision(db.database_url)
            current_rev = await get_current_revision_async(db.engine)
            migrations_ok = current_rev == head_rev
        except Exception:
            migrations_ok = False

    if not ok_db or not migrations_ok or disk_reason is not None:
        return JSONResponse(
            status_code=503,
            content={
                "status": "not_ready",
                "database": "ok" if ok_db else db_reason,
                "migrations": "ok" if migrations_ok else f"expected head, got {current_rev}",
                "revision": current_rev,
                "storage": disk_reason or "ok",
            },
        )

    return JSONResponse(
        status_code=200,
        content={
            "status": "ready",
            "database": "ok",
            "migrations": "ok",
            "revision": current_rev,
        },
    )


register_route_policy("GET", "/api/health/degraded", "public")


@router.get("/api/health/degraded", response_model=DegradedResponse)
async def health_degraded(request: Request) -> DegradedResponse:
    """Report optional dependencies and storage state with reasons and actionable fix hints."""
    settings = request.app.state.settings
    items: list[DegradedServiceItem] = []

    # 1. Check storage / disk-full state
    disk_reason = get_disk_degraded()
    if disk_reason is None and settings.data_dir.exists():
        try:
            st = os.statvfs(settings.data_dir)
            free_bytes = st.f_bavail * st.f_frsize
            if free_bytes < 64 * 1024:
                disk_reason = f"Low disk space on {settings.data_dir}: {free_bytes} bytes free"
        except OSError as exc:
            disk_reason = f"statvfs failed on {settings.data_dir}: {exc}"

    if disk_reason:
        items.append(
            DegradedServiceItem(
                service="storage",
                status="degraded",
                reason=disk_reason,
                fix_hint=(
                    "Free disk space in ODYSSEUS_DATA_DIR or increase persistent volume capacity."
                ),
            )
        )

    # 2. Check if memory service detected ChromaDB outage / fallback
    mem_svc = getattr(request.app.state, "memory_service", None)
    if mem_svc is not None and getattr(mem_svc, "degraded_reason", None):
        items.append(
            DegradedServiceItem(
                service="chromadb",
                status="degraded",
                reason=str(mem_svc.degraded_reason),
                fix_hint=(
                    "Vector memory falls back to BM25/keyword search. "
                    "Start ChromaDB or check ODYSSEUS_CHROMADB_URL."
                ),
            )
        )

    # 3. Probe optional services if requested or configured
    probe_external = request.query_params.get("probe", "false").lower() == "true"
    optional_targets = [
        (
            "chromadb",
            f"{settings.chromadb_url.rstrip('/')}/api/v1/heartbeat",
            (
                "Vector memory falls back to BM25/keyword search. "
                "Start ChromaDB or check ODYSSEUS_CHROMADB_URL."
            ),
        ),
        (
            "searxng",
            f"{settings.searxng_url.rstrip('/')}/healthz",
            ("Web search unavailable. Start SearXNG or verify ODYSSEUS_SEARXNG_URL."),
        ),
        (
            "ntfy",
            f"{settings.ntfy_url.rstrip('/')}/v1/health",
            ("Push notifications disabled. Start ntfy or verify ODYSSEUS_NTFY_URL."),
        ),
    ]

    if probe_external:
        async with httpx.AsyncClient(timeout=0.35) as client:
            for svc_name, url, hint in optional_targets:
                try:
                    resp = await client.get(url)
                    if resp.status_code >= 400:
                        items.append(
                            DegradedServiceItem(
                                service=svc_name,
                                status="degraded",
                                reason=f"HTTP {resp.status_code} from {url}",
                                fix_hint=hint,
                            )
                        )
                except Exception as exc:
                    items.append(
                        DegradedServiceItem(
                            service=svc_name,
                            status="degraded",
                            reason=f"Unreachable ({type(exc).__name__})",
                            fix_hint=hint,
                        )
                    )

    return DegradedResponse(degraded=len(items) > 0, services=items)


register_route_policy("GET", "/metrics", "public")


@router.get("/metrics")
async def metrics_endpoint() -> Response:
    """Expose Prometheus metrics series."""
    payload, content_type = render_prometheus_metrics()
    return Response(content=payload, media_type=content_type)
