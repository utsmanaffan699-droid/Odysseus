"""Deterministic, scriptable FakeProvider and OpenAI-compatible mock server."""

from __future__ import annotations

import argparse
import asyncio
import json
import time
from collections.abc import AsyncIterator
from pathlib import Path
from typing import Any, Literal

import uvicorn
import yaml
from fastapi import FastAPI, Request, Response
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel, ConfigDict, Field

from backend.core.metrics import PROVIDER_ERRORS, PROVIDER_LATENCY
from backend.core.parsers import ToolCallParseResult, parse_tool_call_arguments

StepActionLiteral = Literal[
    "text",
    "thinking",
    "tool_call",
    "usage",
    "disconnect",
    "http_error",
    "long_output",
    "unclosed_fence",
    "unicode_edge",
]


class FakeHttpError(RuntimeError):
    """Simulated provider HTTP error (e.g., 429 rate limit or 500 server error)."""

    def __init__(
        self,
        status_code: int,
        message: str,
        *,
        retry_after: int | None = None,
    ) -> None:
        self.status_code = status_code
        self.message = message
        self.retry_after = retry_after
        super().__init__(f"HTTP {status_code}: {message}")


class FakeStreamDisconnectedError(ConnectionResetError):
    """Simulated mid-stream TCP/SSE drop."""


class FakeScriptStep(BaseModel):
    """Single step in a FakeProvider YAML/JSON script."""

    model_config = ConfigDict(extra="forbid")

    kind: StepActionLiteral
    text: str = ""
    delay_ms: int = Field(default=0, ge=0, le=60000)
    chunk_size: int | None = Field(default=None, gt=0)
    signature: str | None = None
    duration_ms: int = Field(default=0, ge=0)
    call_id: str = "call_1"
    tool_name: str = "noop"
    args: dict[str, Any] | None = None
    malformed_json: str | None = None
    status_code: int = Field(default=429, ge=400, le=599)
    retry_after: int | None = Field(default=None, ge=1)
    error_message: str = "Provider rate limit or server error"
    lines: int = Field(default=50, gt=0, le=50000)
    language: str = "python"
    input_tokens: int = Field(default=16, ge=0)
    output_tokens: int = Field(default=32, ge=0)
    cached_tokens: int = Field(default=0, ge=0)
    reasoning_tokens: int = Field(default=0, ge=0)
    cost: float = Field(default=0.0001, ge=0.0)


class FakeScript(BaseModel):
    """Full deterministic script for FakeProvider."""

    model_config = ConfigDict(extra="forbid")

    name: str = "default-fake-script"
    model: str = "fake/default"
    steps: list[FakeScriptStep] = Field(default_factory=list)


class FakeStreamChunk(BaseModel):
    """Normalized chunk emitted by FakeProvider.stream_completion."""

    kind: Literal["text", "thinking", "tool_call", "usage"]
    text: str = ""
    signature: str | None = None
    duration_ms: int = 0
    call_id: str | None = None
    tool_name: str | None = None
    tool_args_parsed: dict[str, Any] | None = None
    tool_args_raw: str | None = None
    tool_args_valid: bool = True
    usage: dict[str, Any] | None = None


UNICODE_EDGE_CORPUS = (
    "Emoji ZWJ: 👨‍👩‍👧‍👦 🏳️‍🌈 👩🏽‍🔬 | "
    "RTL Arabic/Hebrew: مرحبا بالعالم שָׁלוֹם עוֹלָם | "
    "Combining diacritics: Z̸̢̛͚̯̣̯͌̈́͑å̴̡̯̪̱l̵̛̪g̷̨̛͚ơ̵̡ text e\u0301 a\u0308 | "
    "CJK: こんにちは世界 안녕하세요"
)


def load_fake_script(source: Path | str | dict[str, Any]) -> FakeScript:
    """Load and validate a FakeScript from a YAML/JSON file path, YAML string, or dict."""
    if isinstance(source, dict):
        return FakeScript.model_validate(source)
    if isinstance(source, Path) or (
        isinstance(source, str) and "\n" not in source and Path(source).exists()
    ):
        path = Path(source)
        raw = yaml.safe_load(path.read_text(encoding="utf-8"))
        return FakeScript.model_validate(raw)
    raw_str = str(source)
    parsed = yaml.safe_load(raw_str)
    return FakeScript.model_validate(parsed)


class FakeProvider:
    """Scriptable, deterministic LLM provider for unit, integration, e2e, and load tests."""

    def __init__(
        self,
        script: FakeScript | None = None,
        *,
        script_selector: Any = None,
    ) -> None:
        self.script = script or FakeScript(
            name="default",
            model="fake/default",
            steps=[
                FakeScriptStep(kind="text", text="Hello from Odysseus FakeProvider!"),
                FakeScriptStep(kind="usage", input_tokens=10, output_tokens=8, cost=0.0),
            ],
        )
        self.script_queue: list[FakeScript] = []
        self.recorded_messages: list[list[dict[str, Any]]] = []
        self.recorded_requests: list[Any] = []
        self.script_selector: Any = script_selector
        self.active_streams_count: int = 0
        self.closed_streams_count: int = 0
        self.total_requests_count: int = 0
        self.probe_variant: str = "default"

    def enqueue_script(self, script: FakeScript) -> None:
        """Enqueue a one-shot script to be consumed by the next request before default script."""
        self.script_queue.append(script)

    def next_script(self) -> FakeScript:
        """Pop the next queued script or return the default script."""
        if self.script_queue:
            return self.script_queue.pop(0)
        return self.script

    async def probe(self) -> dict[str, Any]:
        """Return deterministic provider capabilities and health."""
        return {
            "provider": "fake",
            "healthy": True,
            "models": [
                {
                    "id": self.script.model,
                    "supports_tools": True,
                    "supports_vision": True,
                    "supports_thinking": True,
                    "context_window": 128000,
                    "cost_tier": "free",
                }
            ],
        }

    async def stream_completion(
        self,
        messages: list[dict[str, Any]],
        *,
        script_override: FakeScript | None = None,
    ) -> AsyncIterator[FakeStreamChunk]:
        """Execute the configured script deterministically, yielding normalized stream chunks."""
        call_idx = len(self.recorded_messages)
        self.recorded_messages.append(list(messages))
        selected_by_fn = None
        if callable(self.script_selector):
            import inspect

            sig = inspect.signature(self.script_selector)
            if len(sig.parameters) >= 2:
                req_obj = self.recorded_requests[-1] if self.recorded_requests else messages
                selected_by_fn = self.script_selector(req_obj, call_idx)
            else:
                selected_by_fn = self.script_selector(messages)
        active_script = script_override or selected_by_fn or self.next_script()
        if (
            script_override is None
            and selected_by_fn is None
            and active_script.name == "default"
            and messages
        ):
            last_user = ""
            for m in reversed(messages):
                if m.get("role") == "user":
                    last_user = str(m.get("content", ""))
                    break
            if "[FAKE_SLOW]" in last_user:
                active_script = FakeScript(
                    name="prompt_slow",
                    model=active_script.model,
                    steps=[
                        *[
                            FakeScriptStep(
                                kind="text",
                                text=f"Chunk_{idx}_steady ",
                                delay_ms=65,
                            )
                            for idx in range(1, 21)
                        ],
                        FakeScriptStep(kind="usage", input_tokens=20, output_tokens=40, cost=0.001),
                    ],
                )
            elif "[FAKE_ECHO]" in last_user:
                cleaned = last_user.replace("[FAKE_ECHO]", "").strip()
                active_script = FakeScript(
                    name="prompt_echo",
                    model=active_script.model,
                    steps=[
                        FakeScriptStep(kind="text", text=f"Echo reply: {cleaned}"),
                        FakeScriptStep(kind="usage", input_tokens=12, output_tokens=14, cost=0.0),
                    ],
                )
            elif "[FAKE_RICH]" in last_user:
                rich_md = (
                    "### Streaming Analysis [1]\n\n"
                    "| Metric | Value |\n| --- | --- |\n| Latency | 12ms |\n\n"
                    "- [x] Task completed\n"
                    "- [ ] Pending verification\n\n"
                    '```python title="fibonacci.py"\n'
                    "def fib(n: int) -> int:\n"
                    "    return n if n <= 1 else fib(n - 1) + fib(n - 2)\n"
                    "```\n\n"
                    "Inline math $E = mc^2$ and display math:\n\n"
                    "$$\n\\int_0^\\infty e^{-x^2} dx = \\frac{\\sqrt{\\pi}}{2}\n$$\n\n"
                    "```mermaid\ngraph TD\n  A[Prompt] --> B[Odysseus]\n```\n"
                )
                active_script = FakeScript(
                    name="prompt_rich",
                    model=active_script.model,
                    steps=[
                        FakeScriptStep(
                            kind="thinking",
                            text="Analyzing structure and math blocks...",
                            duration_ms=1200,
                        ),
                        FakeScriptStep(kind="text", text=rich_md, chunk_size=24, delay_ms=5),
                        FakeScriptStep(
                            kind="usage",
                            input_tokens=32,
                            output_tokens=96,
                            reasoning_tokens=18,
                            cost=0.0024,
                        ),
                    ],
                )
        start = time.perf_counter()
        self.total_requests_count += 1
        self.active_streams_count += 1

        try:
            for step in active_script.steps:
                if step.delay_ms > 0:
                    await asyncio.sleep(step.delay_ms / 1000.0)

                if step.kind == "http_error":
                    PROVIDER_ERRORS.labels(provider="fake", code=str(step.status_code)).inc()
                    raise FakeHttpError(
                        step.status_code,
                        step.error_message,
                        retry_after=step.retry_after,
                    )

                if step.kind == "disconnect":
                    PROVIDER_ERRORS.labels(provider="fake", code="disconnect").inc()
                    raise FakeStreamDisconnectedError(
                        "Simulated mid-stream connection drop by FakeProvider"
                    )

                if step.kind == "text":
                    for sub in _chunk_text(step.text, step.chunk_size):
                        yield FakeStreamChunk(kind="text", text=sub)

                elif step.kind == "thinking":
                    for sub in _chunk_text(step.text, step.chunk_size):
                        yield FakeStreamChunk(
                            kind="thinking",
                            text=sub,
                            signature=step.signature,
                            duration_ms=step.duration_ms,
                        )

                elif step.kind == "tool_call":
                    if step.malformed_json is not None:
                        parsed_res: ToolCallParseResult = parse_tool_call_arguments(
                            step.malformed_json
                        )
                    else:
                        parsed_res = parse_tool_call_arguments(step.args or {})
                    yield FakeStreamChunk(
                        kind="tool_call",
                        call_id=step.call_id,
                        tool_name=step.tool_name,
                        tool_args_parsed=parsed_res.args,
                        tool_args_raw=parsed_res.raw,
                        tool_args_valid=parsed_res.ok,
                    )

                elif step.kind == "long_output":
                    lines = [
                        f"Line {i:04d}: Deterministic long output payload for streaming."
                        for i in range(1, step.lines + 1)
                    ]
                    full_text = "\n".join(lines) + "\n"
                    for sub in _chunk_text(full_text, step.chunk_size or 256):
                        yield FakeStreamChunk(kind="text", text=sub)

                elif step.kind == "unclosed_fence":
                    fence_text = (
                        f"Here is an unclosed code block:\n```{step.language}\n"
                        f"def example():\n    return {step.text!r}\n"
                    )
                    for sub in _chunk_text(fence_text, step.chunk_size or 32):
                        yield FakeStreamChunk(kind="text", text=sub)

                elif step.kind == "unicode_edge":
                    payload = step.text or UNICODE_EDGE_CORPUS
                    for sub in _chunk_text(payload, step.chunk_size):
                        yield FakeStreamChunk(kind="text", text=sub)

                elif step.kind == "usage":
                    yield FakeStreamChunk(
                        kind="usage",
                        usage={
                            "input": step.input_tokens,
                            "output": step.output_tokens,
                            "cached": step.cached_tokens,
                            "reasoning": step.reasoning_tokens,
                            "cost": step.cost,
                        },
                    )
        finally:
            self.active_streams_count = max(0, self.active_streams_count - 1)
            self.closed_streams_count += 1
            PROVIDER_LATENCY.labels(provider="fake", model=active_script.model).observe(
                max(0.0, time.perf_counter() - start)
            )


def _chunk_text(text: str, chunk_size: int | None) -> list[str]:
    if not chunk_size or chunk_size <= 0 or len(text) <= chunk_size:
        return [text]
    return [text[i : i + chunk_size] for i in range(0, len(text), chunk_size)]


def create_fake_openai_app(initial_script: FakeScript | None = None) -> FastAPI:
    """Create an OpenAI-compatible HTTP server backed by FakeProvider."""
    app = FastAPI(title="Odysseus FakeProvider OpenAI Server", version="0.1.0")
    provider = FakeProvider(initial_script)
    app.state.provider = provider

    @app.get("/health")
    async def health() -> dict[str, Any]:
        return {"ok": True, "script": provider.script.name}

    @app.get("/v1/models")
    async def list_models() -> dict[str, Any]:
        return {
            "object": "list",
            "data": [
                {
                    "id": provider.script.model,
                    "object": "model",
                    "created": 1700000000,
                    "owned_by": "odysseus-fake",
                }
            ],
        }

    @app.post("/v1/admin/script")
    async def update_script(request: Request) -> dict[str, Any]:
        body = await request.json()
        provider.script = load_fake_script(body)
        return {"ok": True, "script": provider.script.name}

    @app.post("/v1/chat/completions", response_model=None)
    async def chat_completions(request: Request) -> Response:
        body = await request.json()
        messages = body.get("messages", [])
        stream = bool(body.get("stream", False))

        # Handle capability probing variants when non-streaming canary requests arrive
        if not stream:
            has_tools = bool(body.get("tools"))
            has_image = any(
                isinstance(m.get("content"), list)
                and any(isinstance(p, dict) and p.get("type") == "image_url" for p in m["content"])
                for m in messages
                if isinstance(m, dict)
            )
            if has_tools and provider.probe_variant in (
                "no_tools",
                "tools_broken",
                "vision_capable",
            ):
                if provider.probe_variant == "no_tools":
                    return JSONResponse(
                        status_code=400,
                        content={"error": {"message": "Tools not supported by endpoint"}},
                    )
                if provider.probe_variant == "tools_broken":
                    return JSONResponse(
                        content={
                            "id": "chatcmpl_probe",
                            "object": "chat.completion",
                            "model": provider.script.model,
                            "choices": [
                                {
                                    "index": 0,
                                    "message": {
                                        "role": "assistant",
                                        "content": "",
                                        "tool_calls": [
                                            {
                                                "id": "call_broken",
                                                "type": "function",
                                                "function": {
                                                    "name": "canary_ping",
                                                    "arguments": "{broken_json",
                                                },
                                            }
                                        ],
                                    },
                                    "finish_reason": "tool_calls",
                                }
                            ],
                        }
                    )
                if provider.probe_variant == "vision_capable":
                    return JSONResponse(
                        content={
                            "id": "chatcmpl_probe",
                            "object": "chat.completion",
                            "model": provider.script.model,
                            "choices": [
                                {
                                    "index": 0,
                                    "message": {
                                        "role": "assistant",
                                        "content": "",
                                        "tool_calls": [
                                            {
                                                "id": "call_ok",
                                                "type": "function",
                                                "function": {
                                                    "name": "canary_ping",
                                                    "arguments": '{"x": 1}',
                                                },
                                            }
                                        ],
                                    },
                                    "finish_reason": "tool_calls",
                                }
                            ],
                        }
                    )
            if has_image and provider.probe_variant in (
                "no_tools",
                "tools_broken",
                "vision_capable",
            ):
                if provider.probe_variant == "vision_capable":
                    return JSONResponse(
                        content={
                            "id": "chatcmpl_vis",
                            "object": "chat.completion",
                            "model": provider.script.model,
                            "choices": [
                                {
                                    "index": 0,
                                    "message": {"role": "assistant", "content": "1x1 pixel"},
                                    "finish_reason": "stop",
                                }
                            ],
                        }
                    )
                return JSONResponse(
                    status_code=400,
                    content={"error": {"message": "Vision not supported"}},
                )

        active_script = provider.next_script()

        # Check if the first step is an immediate HTTP error before streaming starts
        if active_script.steps and active_script.steps[0].kind == "http_error":
            first = active_script.steps[0]
            headers: dict[str, str] = {}
            if first.retry_after is not None:
                headers["Retry-After"] = str(first.retry_after)
            return JSONResponse(
                status_code=first.status_code,
                content={"error": {"message": first.error_message, "type": "fake_error"}},
                headers=headers,
            )

        if not stream:
            text_parts: list[str] = []
            tool_calls: list[dict[str, Any]] = []
            usage_data = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
            try:
                async for chunk in provider.stream_completion(
                    messages, script_override=active_script
                ):
                    if chunk.kind == "text":
                        text_parts.append(chunk.text)
                    elif chunk.kind == "tool_call":
                        tool_calls.append(
                            {
                                "id": chunk.call_id,
                                "type": "function",
                                "function": {
                                    "name": chunk.tool_name,
                                    "arguments": chunk.tool_args_raw or "{}",
                                },
                            }
                        )
                    elif chunk.kind == "usage" and chunk.usage:
                        inp = int(chunk.usage.get("input", 0))
                        out = int(chunk.usage.get("output", 0))
                        usage_data = {
                            "prompt_tokens": inp,
                            "completion_tokens": out,
                            "total_tokens": inp + out,
                        }
            except FakeHttpError as exc:
                hdrs = {"Retry-After": str(exc.retry_after)} if exc.retry_after else {}
                return JSONResponse(
                    status_code=exc.status_code,
                    content={"error": {"message": exc.message}},
                    headers=hdrs,
                )

            msg_obj: dict[str, Any] = {
                "role": "assistant",
                "content": "".join(text_parts),
            }
            if tool_calls:
                msg_obj["tool_calls"] = tool_calls

            return JSONResponse(
                content={
                    "id": "chatcmpl_fake_001",
                    "object": "chat.completion",
                    "model": active_script.model,
                    "choices": [
                        {
                            "index": 0,
                            "message": msg_obj,
                            "finish_reason": "tool_calls" if tool_calls else "stop",
                        }
                    ],
                    "usage": usage_data,
                }
            )

        async def _sse_generator() -> AsyncIterator[bytes]:
            async for chunk in provider.stream_completion(messages, script_override=active_script):
                frame: dict[str, Any]
                if chunk.kind == "text":
                    frame = {
                        "id": "chatcmpl_fake_001",
                        "object": "chat.completion.chunk",
                        "model": active_script.model,
                        "choices": [
                            {
                                "index": 0,
                                "delta": {"content": chunk.text},
                                "finish_reason": None,
                            }
                        ],
                    }
                    yield f"data: {json.dumps(frame)}\n\n".encode()
                elif chunk.kind == "thinking":
                    frame = {
                        "id": "chatcmpl_fake_001",
                        "object": "chat.completion.chunk",
                        "model": active_script.model,
                        "choices": [
                            {
                                "index": 0,
                                "delta": {"reasoning_content": chunk.text},
                                "finish_reason": None,
                            }
                        ],
                    }
                    yield f"data: {json.dumps(frame)}\n\n".encode()
                elif chunk.kind == "tool_call":
                    frame = {
                        "id": "chatcmpl_fake_001",
                        "object": "chat.completion.chunk",
                        "model": active_script.model,
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "tool_calls": [
                                        {
                                            "index": 0,
                                            "id": chunk.call_id,
                                            "type": "function",
                                            "function": {
                                                "name": chunk.tool_name,
                                                "arguments": chunk.tool_args_raw or "{}",
                                            },
                                        }
                                    ]
                                },
                                "finish_reason": None,
                            }
                        ],
                    }
                    yield f"data: {json.dumps(frame)}\n\n".encode()
                elif chunk.kind == "usage" and chunk.usage:
                    frame = {
                        "id": "chatcmpl_fake_001",
                        "object": "chat.completion.chunk",
                        "model": active_script.model,
                        "choices": [],
                        "usage": {
                            "prompt_tokens": int(chunk.usage.get("input", 0)),
                            "completion_tokens": int(chunk.usage.get("output", 0)),
                            "prompt_tokens_details": {
                                "cached_tokens": int(chunk.usage.get("cached", 0))
                            },
                            "completion_tokens_details": {
                                "reasoning_tokens": int(chunk.usage.get("reasoning", 0))
                            },
                        },
                    }
                    yield f"data: {json.dumps(frame)}\n\n".encode()
            yield b"data: [DONE]\n\n"

        return StreamingResponse(_sse_generator(), media_type="text/event-stream")

    @app.post("/v1/messages", response_model=None)
    async def anthropic_messages(request: Request) -> Response:
        """Anthropic Messages SSE endpoint for contract-testing AnthropicMessagesAdapter."""
        body = await request.json()
        messages = body.get("messages", [])
        active_script = provider.next_script()
        if active_script.steps and active_script.steps[0].kind == "http_error":
            first = active_script.steps[0]
            headers = {"Retry-After": str(first.retry_after)} if first.retry_after else {}
            return JSONResponse(
                status_code=first.status_code,
                content={"type": "error", "error": {"message": first.error_message}},
                headers=headers,
            )

        async def _anth_sse() -> AsyncIterator[bytes]:
            msg_start = {
                "type": "message_start",
                "message": {
                    "id": "msg_fake_01",
                    "usage": {"input_tokens": 12, "cache_read_input_tokens": 4, "output_tokens": 0},
                },
            }

            def _sse_data(payload: dict[str, Any]) -> bytes:
                return f"data: {json.dumps(payload)}\n\n".encode()

            yield f"event: message_start\ndata: {json.dumps(msg_start)}\n\n".encode()
            block_idx = 0
            stop_reason = "end_turn"
            async for chunk in provider.stream_completion(messages, script_override=active_script):
                if chunk.kind == "thinking":
                    yield _sse_data(
                        {
                            "type": "content_block_start",
                            "index": block_idx,
                            "content_block": {"type": "thinking"},
                        }
                    )
                    yield _sse_data(
                        {
                            "type": "content_block_delta",
                            "index": block_idx,
                            "delta": {"type": "thinking_delta", "thinking": chunk.text},
                        }
                    )
                    yield _sse_data({"type": "content_block_stop", "index": block_idx})
                    block_idx += 1
                elif chunk.kind == "text":
                    yield _sse_data(
                        {
                            "type": "content_block_start",
                            "index": block_idx,
                            "content_block": {"type": "text"},
                        }
                    )
                    yield _sse_data(
                        {
                            "type": "content_block_delta",
                            "index": block_idx,
                            "delta": {"type": "text_delta", "text": chunk.text},
                        }
                    )
                    yield _sse_data({"type": "content_block_stop", "index": block_idx})
                    block_idx += 1
                elif chunk.kind == "tool_call":
                    stop_reason = "tool_use"
                    yield _sse_data(
                        {
                            "type": "content_block_start",
                            "index": block_idx,
                            "content_block": {
                                "type": "tool_use",
                                "id": chunk.call_id,
                                "name": chunk.tool_name,
                            },
                        }
                    )
                    yield _sse_data(
                        {
                            "type": "content_block_delta",
                            "index": block_idx,
                            "delta": {
                                "type": "input_json_delta",
                                "partial_json": chunk.tool_args_raw or "{}",
                            },
                        }
                    )
                    yield _sse_data({"type": "content_block_stop", "index": block_idx})
                    block_idx += 1
                elif chunk.kind == "usage" and chunk.usage:
                    out_tok = int(chunk.usage.get("output", 10))
                    yield _sse_data(
                        {
                            "type": "message_delta",
                            "delta": {"stop_reason": stop_reason},
                            "usage": {"output_tokens": out_tok},
                        }
                    )
            yield _sse_data({"type": "message_stop"})

        return StreamingResponse(_anth_sse(), media_type="text/event-stream")

    @app.post("/v1beta/models/{model_action:path}", response_model=None)
    async def gemini_stream(model_action: str, request: Request) -> Response:
        """Gemini SSE endpoint for contract-testing GeminiAdapter."""
        _ = model_action
        body = await request.json()
        contents = body.get("contents", [])
        active_script = provider.next_script()
        if active_script.steps and active_script.steps[0].kind == "http_error":
            first = active_script.steps[0]
            headers = {"Retry-After": str(first.retry_after)} if first.retry_after else {}
            return JSONResponse(
                status_code=first.status_code,
                content={"error": {"code": first.status_code, "message": first.error_message}},
                headers=headers,
            )

        async def _gem_sse() -> AsyncIterator[bytes]:
            async for chunk in provider.stream_completion(contents, script_override=active_script):
                frame: dict[str, Any]
                if chunk.kind == "thinking":
                    frame = {
                        "candidates": [
                            {"content": {"parts": [{"thought": True, "text": chunk.text}]}}
                        ]
                    }
                    yield f"data: {json.dumps(frame)}\n\n".encode()
                elif chunk.kind == "text":
                    frame = {"candidates": [{"content": {"parts": [{"text": chunk.text}]}}]}
                    yield f"data: {json.dumps(frame)}\n\n".encode()
                elif chunk.kind == "tool_call":
                    frame = {
                        "candidates": [
                            {
                                "content": {
                                    "parts": [
                                        {
                                            "functionCall": {
                                                "name": chunk.tool_name,
                                                "args": chunk.tool_args_parsed or {},
                                            }
                                        }
                                    ]
                                }
                            }
                        ]
                    }
                    yield f"data: {json.dumps(frame)}\n\n".encode()
                elif chunk.kind == "usage" and chunk.usage:
                    frame = {
                        "usageMetadata": {
                            "promptTokenCount": int(chunk.usage.get("input", 10)),
                            "candidatesTokenCount": int(chunk.usage.get("output", 8)),
                            "cachedContentTokenCount": int(chunk.usage.get("cached", 0)),
                            "thoughtsTokenCount": int(chunk.usage.get("reasoning", 0)),
                        }
                    }
                    yield f"data: {json.dumps(frame)}\n\n".encode()

        return StreamingResponse(_gem_sse(), media_type="text/event-stream")

    return app


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m providers.fake",
        description="Odysseus deterministic FakeProvider CLI & OpenAI-compatible mock server",
    )
    sub = parser.add_subparsers(dest="command", required=True)
    serve_p = sub.add_parser("serve", help="Serve an OpenAI-compatible HTTP endpoint")
    serve_p.add_argument("--script", required=True, help="Path to YAML/JSON script file")
    serve_p.add_argument("--host", default="127.0.0.1", help="Bind host (default 127.0.0.1)")
    serve_p.add_argument("--port", type=int, default=8099, help="Bind port (default 8099)")
    args = parser.parse_args(argv)

    if args.command == "serve":
        script = load_fake_script(Path(args.script))
        app = create_fake_openai_app(script)
        uvicorn.run(app, host=args.host, port=args.port, log_level="warning")
        return 0
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
