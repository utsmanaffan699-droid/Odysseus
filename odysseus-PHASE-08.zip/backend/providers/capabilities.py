"""Model capabilities registry, Decimal cost calculation, and live endpoint auto-probing."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import ROUND_HALF_UP, Decimal
from typing import Any, Literal

import httpx

ToolsCapabilityMode = Literal["native", "text_fenced", "none"]


@dataclass(frozen=True)
class ModelCapabilities:
    """Capabilities and pricing metadata for a specific provider + model."""

    model_id: str
    provider: str
    tools: ToolsCapabilityMode = "text_fenced"
    supports_tools: bool | None = None
    vision: bool = False
    thinking: bool = False
    context_window: int = 32768
    max_output: int = 4096
    cost_per_mtok_in: Decimal = Decimal("0.00")
    cost_per_mtok_out: Decimal = Decimal("0.00")
    cost_per_mtok_cached: Decimal = Decimal("0.00")
    supports_json_mode: bool = False

    def to_dict(self) -> dict[str, Any]:
        supports_tools_val = (
            bool(self.supports_tools) if self.supports_tools is not None else (self.tools != "none")
        )
        return {
            "model_id": self.model_id,
            "model": self.model_id,
            "provider": self.provider,
            "tools": self.tools,
            "tool_transport": self.tools,
            "supports_tools": supports_tools_val,
            "vision": self.vision,
            "supports_vision": self.vision,
            "thinking": self.thinking,
            "supports_thinking": self.thinking,
            "context_window": self.context_window,
            "max_output": self.max_output,
            "max_output_tokens": self.max_output,
            "cost_tier": "free" if self.cost_per_mtok_in == Decimal("0.00") else "standard",
            "cost_per_mtok_in": str(self.cost_per_mtok_in),
            "cost_per_mtok_out": str(self.cost_per_mtok_out),
            "cost_per_mtok_cached": str(self.cost_per_mtok_cached),
            "supports_json_mode": self.supports_json_mode,
            "supports_json_schema": self.supports_json_mode,
            "supports_prompt_caching": False,
        }


BUILTIN_CAPABILITY_TABLE: dict[str, ModelCapabilities] = {
    "fake/default": ModelCapabilities(
        model_id="fake/default",
        provider="fake",
        tools="native",
        supports_tools=True,
        vision=True,
        thinking=True,
        context_window=128000,
        max_output=8192,
        cost_per_mtok_in=Decimal("1.00"),
        cost_per_mtok_out=Decimal("3.00"),
        cost_per_mtok_cached=Decimal("0.25"),
        supports_json_mode=True,
    ),
    "fake/fallback": ModelCapabilities(
        model_id="fake/fallback",
        provider="fake",
        tools="native",
        supports_tools=True,
        vision=False,
        thinking=False,
        context_window=64000,
        max_output=4096,
        cost_per_mtok_in=Decimal("0.50"),
        cost_per_mtok_out=Decimal("1.50"),
        cost_per_mtok_cached=Decimal("0.10"),
        supports_json_mode=True,
    ),
    "fake/cheap-title": ModelCapabilities(
        model_id="fake/cheap-title",
        provider="fake",
        tools="none",
        supports_tools=False,
        vision=False,
        thinking=False,
        context_window=16384,
        max_output=256,
        cost_per_mtok_in=Decimal("0.10"),
        cost_per_mtok_out=Decimal("0.20"),
        cost_per_mtok_cached=Decimal("0.02"),
        supports_json_mode=False,
    ),
    "fake/small-4k": ModelCapabilities(
        model_id="fake/small-4k",
        provider="fake",
        tools="text_fenced",
        supports_tools=False,
        vision=False,
        thinking=False,
        context_window=4096,
        max_output=1024,
        cost_per_mtok_in=Decimal("0.05"),
        cost_per_mtok_out=Decimal("0.10"),
        cost_per_mtok_cached=Decimal("0.01"),
        supports_json_mode=False,
    ),
    "fake/fenced": ModelCapabilities(
        model_id="fake/fenced",
        provider="fake",
        tools="text_fenced",
        supports_tools=False,
        vision=False,
        thinking=False,
        context_window=8192,
        max_output=2048,
        cost_per_mtok_in=Decimal("0.10"),
        cost_per_mtok_out=Decimal("0.20"),
        cost_per_mtok_cached=Decimal("0.02"),
        supports_json_mode=False,
    ),
    "openai/gpt-4o": ModelCapabilities(
        model_id="openai/gpt-4o",
        provider="openai",
        tools="native",
        supports_tools=True,
        vision=True,
        thinking=False,
        context_window=128000,
        max_output=16384,
        cost_per_mtok_in=Decimal("2.50"),
        cost_per_mtok_out=Decimal("10.00"),
        cost_per_mtok_cached=Decimal("1.25"),
        supports_json_mode=True,
    ),
    "anthropic/claude-3-7-sonnet": ModelCapabilities(
        model_id="anthropic/claude-3-7-sonnet",
        provider="anthropic",
        tools="native",
        supports_tools=True,
        vision=True,
        thinking=True,
        context_window=200000,
        max_output=8192,
        cost_per_mtok_in=Decimal("3.00"),
        cost_per_mtok_out=Decimal("15.00"),
        cost_per_mtok_cached=Decimal("0.30"),
        supports_json_mode=True,
    ),
    "gemini/gemini-2.5-pro": ModelCapabilities(
        model_id="gemini/gemini-2.5-pro",
        provider="gemini",
        tools="native",
        supports_tools=True,
        vision=True,
        thinking=True,
        context_window=1048576,
        max_output=8192,
        cost_per_mtok_in=Decimal("1.25"),
        cost_per_mtok_out=Decimal("5.00"),
        cost_per_mtok_cached=Decimal("0.3125"),
        supports_json_mode=True,
    ),
}

# 1x1 transparent PNG data URI for vision canary probing
CANARY_1X1_PNG_DATA_URI = (
    "data:image/png;base64,"
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII="
)


def resolve_model_capabilities(
    model_id: str,
    *,
    is_local_v1: bool = False,
    supports_tools_override: bool | None = None,
    probed: dict[str, Any] | None = None,
    override: dict[str, Any] | None = None,
) -> ModelCapabilities:
    """Resolve effective capabilities for a model, honoring local defaults and overrides."""
    base = BUILTIN_CAPABILITY_TABLE.get(model_id)
    if base is None:
        provider_prefix = model_id.split("/", 1)[0] if "/" in model_id else "local"
        # Conservative default for local /v1 endpoints = text-based fenced tool calling
        is_local_family = is_local_v1 or provider_prefix in ("local", "ollama", "vllm")
        default_tools: ToolsCapabilityMode = "text_fenced" if is_local_family else "native"
        base = ModelCapabilities(
            model_id=model_id,
            provider=provider_prefix,
            tools=default_tools,
            supports_tools=None,
            vision=False,
            thinking=False,
            context_window=32768,
            max_output=4096,
            cost_per_mtok_in=Decimal("0.00"),
            cost_per_mtok_out=Decimal("0.00"),
            cost_per_mtok_cached=Decimal("0.00"),
            supports_json_mode=not is_local_v1,
        )

    tools_mode = base.tools
    vision = base.vision
    thinking = base.thinking
    ctx_win = base.context_window
    max_out = base.max_output
    json_mode = base.supports_json_mode
    cost_in = base.cost_per_mtok_in
    cost_out = base.cost_per_mtok_out
    cost_cached = base.cost_per_mtok_cached

    if probed:
        if "tools" in probed and probed["tools"] in ("native", "text_fenced", "none"):
            tools_mode = probed["tools"]
        if "vision" in probed:
            vision = bool(probed["vision"])
        if "thinking" in probed:
            thinking = bool(probed["thinking"])
        if "supports_json_mode" in probed:
            json_mode = bool(probed["supports_json_mode"])

    if override:
        if "tools" in override and override["tools"] in ("native", "text_fenced", "none"):
            tools_mode = override["tools"]
        if "vision" in override:
            vision = bool(override["vision"])
        if "thinking" in override:
            thinking = bool(override["thinking"])
        if "context_window" in override:
            ctx_win = int(override["context_window"])
        if "max_output" in override:
            max_out = int(override["max_output"])
        if "cost_per_mtok_in" in override:
            cost_in = Decimal(str(override["cost_per_mtok_in"]))
        if "cost_per_mtok_out" in override:
            cost_out = Decimal(str(override["cost_per_mtok_out"]))
        if "cost_per_mtok_cached" in override:
            cost_cached = Decimal(str(override["cost_per_mtok_cached"]))
        if "supports_tools" in override and override["supports_tools"] is not None:
            supports_tools_override = bool(override["supports_tools"])

    # Apply tri-state `supports_tools: true | false | null(auto)`
    if supports_tools_override is True:
        tools_mode = "native"
    elif supports_tools_override is False:
        tools_mode = "none"

    return ModelCapabilities(
        model_id=model_id,
        provider=base.provider,
        tools=tools_mode,
        supports_tools=supports_tools_override,
        vision=vision,
        thinking=thinking,
        context_window=ctx_win,
        max_output=max_out,
        cost_per_mtok_in=cost_in,
        cost_per_mtok_out=cost_out,
        cost_per_mtok_cached=cost_cached,
        supports_json_mode=json_mode,
    )


def compute_cost_decimal(
    caps: ModelCapabilities,
    *,
    input_tokens: int,
    output_tokens: int,
    cached_tokens: int = 0,
    reasoning_tokens: int = 0,
) -> Decimal:
    """Compute exact USD cost using Decimal arithmetic (per 1,000,000 tokens)."""
    million = Decimal("1000000")
    uncached_in = max(0, input_tokens - cached_tokens)
    total_out = max(0, output_tokens) + max(0, reasoning_tokens)
    cost = (
        (Decimal(uncached_in) * caps.cost_per_mtok_in / million)
        + (Decimal(max(0, cached_tokens)) * caps.cost_per_mtok_cached / million)
        + (Decimal(total_out) * caps.cost_per_mtok_out / million)
    )
    return cost.quantize(Decimal("0.00000001"), rounding=ROUND_HALF_UP)


def format_cost_usd(cost: Decimal) -> str:
    """Format a Decimal cost to a canonical 8-decimal-place string."""
    return str(cost.quantize(Decimal("0.00000001"), rounding=ROUND_HALF_UP))


async def probe_openai_compatible_endpoint(
    base_url: str,
    *,
    api_key: str | None = None,
    model_id: str | None = None,
    supports_tools_override: bool | None = None,
    is_local_v1: bool = True,
    timeout_seconds: float = 5.0,
) -> dict[str, Any]:
    """Auto-probe an OpenAI-compatible endpoint: list models, ping, tool canary, vision canary."""
    headers: dict[str, str] = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    base = base_url.rstrip("/")
    discovered_models: list[str] = []
    ping_ok = False
    native_tools_ok = False
    tools_http_200 = False
    vision_ok = False

    async with httpx.AsyncClient(timeout=timeout_seconds) as client:
        # 1. List models
        try:
            r_models = await client.get(f"{base}/v1/models", headers=headers)
            if r_models.status_code == 200:
                body = r_models.json()
                for item in body.get("data", []):
                    if isinstance(item, dict) and isinstance(item.get("id"), str):
                        discovered_models.append(item["id"])
        except httpx.HTTPError:
            discovered_models = []

        target_model = model_id or (discovered_models[0] if discovered_models else "default")

        # 2. Ping basic chat completion
        try:
            r_ping = await client.post(
                f"{base}/v1/chat/completions",
                headers=headers,
                json={
                    "model": target_model,
                    "messages": [{"role": "user", "content": "ping"}],
                    "max_tokens": 8,
                    "stream": False,
                },
            )
            ping_ok = r_ping.status_code == 200
        except Exception:
            ping_ok = False

        # 3. Tool-call canary probe
        try:
            r_tools = await client.post(
                f"{base}/v1/chat/completions",
                headers=headers,
                json={
                    "model": target_model,
                    "messages": [{"role": "user", "content": "Call canary_ping with x=1"}],
                    "tools": [
                        {
                            "type": "function",
                            "function": {
                                "name": "canary_ping",
                                "description": "Canary tool probe",
                                "parameters": {
                                    "type": "object",
                                    "properties": {"x": {"type": "integer"}},
                                    "required": ["x"],
                                },
                            },
                        }
                    ],
                    "tool_choice": "auto",
                    "max_tokens": 32,
                    "stream": False,
                },
            )
            if r_tools.status_code == 200:
                tools_http_200 = True
                resp_json = r_tools.json()
                choices = resp_json.get("choices") or []
                if choices:
                    msg = choices[0].get("message") or {}
                    tcs = msg.get("tool_calls") or []
                    if isinstance(tcs, list) and len(tcs) > 0:
                        tc0 = tcs[0]
                        fn = tc0.get("function") or {}
                        args_str = fn.get("arguments", "")
                        if fn.get("name") == "canary_ping" and isinstance(args_str, str):
                            import json

                            try:
                                parsed_args = json.loads(args_str)
                                if isinstance(parsed_args, dict):
                                    native_tools_ok = True
                            except Exception:
                                native_tools_ok = False
        except Exception:
            native_tools_ok = False

        # 4. Vision canary probe
        try:
            r_vis = await client.post(
                f"{base}/v1/chat/completions",
                headers=headers,
                json={
                    "model": target_model,
                    "messages": [
                        {
                            "role": "user",
                            "content": [
                                {"type": "text", "text": "What is in this 1x1 pixel?"},
                                {
                                    "type": "image_url",
                                    "image_url": {"url": CANARY_1X1_PNG_DATA_URI},
                                },
                            ],
                        }
                    ],
                    "max_tokens": 16,
                    "stream": False,
                },
            )
            if r_vis.status_code == 200:
                vis_json = r_vis.json()
                if vis_json.get("choices"):
                    vision_ok = True
        except Exception:
            vision_ok = False

    if native_tools_ok:
        probe_status = "native"
    elif tools_http_200:
        probe_status = "tools_broken"
    else:
        probe_status = "no_tools"

    if supports_tools_override is True:
        tools_mode: ToolsCapabilityMode = "native"
    elif supports_tools_override is False:
        tools_mode = "none"
    else:
        if native_tools_ok:
            tools_mode = "native"
        elif tools_http_200 and is_local_v1:
            tools_mode = "text_fenced"
        else:
            tools_mode = "none"

    return {
        "reachable": ping_ok,
        "models": discovered_models,
        "probed_model": target_model,
        "native_tools_supported": native_tools_ok,
        "tools_probe_status": probe_status,
        "tools": tools_mode,
        "supports_tools": supports_tools_override,
        "vision": vision_ok,
    }
