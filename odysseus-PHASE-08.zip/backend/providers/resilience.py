"""Resilient provider router: circuit breakers, retries, backoff, caps, and fallbacks."""

from __future__ import annotations

import asyncio
import json
import secrets
import time
import uuid
from collections.abc import AsyncIterator, Awaitable, Callable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Any, Literal

from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.crypto import EnvelopeVault
from backend.core.db import DatabaseManager
from backend.core.logging import get_logger
from backend.core.metrics import PROVIDER_ERRORS, PROVIDER_LATENCY
from backend.core.models import RawExchangeRecord
from backend.core.settings import Settings
from backend.providers.adapters import (
    AnthropicMessagesAdapter,
    FakeProviderAdapter,
    GeminiAdapter,
    OpenAICompatibleAdapter,
)
from backend.providers.base import (
    ClassifiedProviderError,
    LLMProviderAdapter,
    ProviderChatRequest,
    ProviderEvent,
)
from backend.providers.fake import FakeProvider

logger = get_logger("odysseus.providers")

NoticeCallback = Callable[[str, str, str], Awaitable[None]]


@dataclass
class CircuitBreaker:
    """Per-provider circuit breaker using monotonic time (immune to wall-clock jumps)."""

    failure_threshold: int = 3
    cooldown_seconds: float = 30.0
    consecutive_failures: int = 0
    opened_at_monotonic: float | None = None
    clock: Callable[[], float] = time.monotonic

    @property
    def state(self) -> Literal["closed", "open", "half_open"]:
        if self.opened_at_monotonic is None:
            return "closed"
        elapsed = self.clock() - self.opened_at_monotonic
        if elapsed >= self.cooldown_seconds:
            return "half_open"
        return "open"

    def allow_request(self) -> bool:
        st = self.state
        return st in ("closed", "half_open")

    def record_success(self) -> None:
        self.consecutive_failures = 0
        self.opened_at_monotonic = None

    def record_failure(self) -> None:
        self.consecutive_failures += 1
        if self.consecutive_failures >= self.failure_threshold:
            self.opened_at_monotonic = self.clock()

    def force_open(self) -> None:
        self.consecutive_failures = self.failure_threshold
        self.opened_at_monotonic = self.clock()


class ResilientProviderRouter:
    """Routes LLM requests across providers with retries, circuit breakers, and fallbacks."""

    def __init__(
        self,
        settings: Settings,
        *,
        db: DatabaseManager | None = None,
        vault: EnvelopeVault | None = None,
        default_fake: FakeProvider | None = None,
        clock: Callable[[], float] = time.monotonic,
        sleep_fn: Callable[[float], Awaitable[None]] = asyncio.sleep,
    ) -> None:
        self.settings = settings
        self.db = db
        self.vault = vault
        self.clock = clock
        self.sleep_fn = sleep_fn
        self._adapters: dict[str, LLMProviderAdapter] = {}
        self._breakers: dict[str, CircuitBreaker] = {}
        self._semaphores: dict[str, asyncio.Semaphore] = {}
        self._fallback_chains: dict[str, list[str]] = {}

        fake_instance = default_fake or FakeProvider()
        self.register_adapter("fake", FakeProviderAdapter(fake_instance), max_concurrency=64)
        self.register_adapter(
            "openai",
            OpenAICompatibleAdapter(
                base_url="https://api.openai.com",
                api_key=settings.openai_api_key,
                provider_id="openai",
                connect_timeout=settings.provider_connect_timeout_seconds,
                read_timeout=settings.provider_read_timeout_seconds,
            ),
            max_concurrency=16,
        )
        self.register_adapter(
            "anthropic",
            AnthropicMessagesAdapter(
                api_key=settings.anthropic_api_key,
                connect_timeout=settings.provider_connect_timeout_seconds,
                read_timeout=settings.provider_read_timeout_seconds,
            ),
            max_concurrency=16,
        )
        self.register_adapter(
            "gemini",
            GeminiAdapter(
                api_key=settings.gemini_api_key,
                connect_timeout=settings.provider_connect_timeout_seconds,
                read_timeout=settings.provider_read_timeout_seconds,
            ),
            max_concurrency=16,
        )

    def register_adapter(
        self,
        provider_id: str,
        adapter: LLMProviderAdapter,
        *,
        max_concurrency: int = 8,
    ) -> None:
        self._adapters[provider_id] = adapter
        self._breakers[provider_id] = CircuitBreaker(
            failure_threshold=self.settings.provider_circuit_breaker_threshold,
            cooldown_seconds=self.settings.provider_circuit_breaker_cooldown_seconds,
            clock=self.clock,
        )
        self._semaphores[provider_id] = asyncio.Semaphore(max(1, max_concurrency))

    def set_fallback_chain(self, model: str, fallbacks: list[str]) -> None:
        """Configure fallback models when primary model fails or circuit is open."""
        self._fallback_chains[model] = list(fallbacks)

    def get_breaker(self, provider_id: str) -> CircuitBreaker:
        if provider_id not in self._breakers:
            self._breakers[provider_id] = CircuitBreaker(
                failure_threshold=self.settings.provider_circuit_breaker_threshold,
                cooldown_seconds=self.settings.provider_circuit_breaker_cooldown_seconds,
                clock=self.clock,
            )
        return self._breakers[provider_id]

    def _resolve_provider_id(self, model: str) -> str:
        if "/" in model:
            prefix = model.split("/", 1)[0]
            if prefix in self._adapters:
                return prefix
        if "fake" in self._adapters:
            return "fake"
        return next(iter(self._adapters.keys()))

    async def _maybe_record_raw_exchange(
        self,
        *,
        run_id: str | None,
        provider_id: str,
        model: str,
        events_summary: list[dict[str, Any]],
    ) -> None:
        if (
            not self.settings.capture_raw_exchanges
            or self.settings.environment != "development"
            or self.db is None
            or self.vault is None
        ):
            return
        now = datetime.now(UTC)
        expires = now + timedelta(seconds=self.settings.raw_exchange_ttl_seconds)
        raw_json = json.dumps(
            {
                "provider": provider_id,
                "model": model,
                "captured_at": now.isoformat(),
                "events": events_summary,
            }
        )
        ciphertext = self.vault.encrypt(
            raw_json, associated_data=f"raw_exchange:{run_id or 'none'}"
        )

        async def _save(sess: AsyncSession) -> None:
            sess.add(
                RawExchangeRecord(
                    id=f"rex_{uuid.uuid4().hex[:16]}",
                    run_id=run_id or "none",
                    provider=provider_id,
                    model=model,
                    ciphertext=ciphertext,
                    expires_at=expires,
                    created_at=now,
                )
            )

        await self.db.execute_write(_save)

    async def stream_with_resilience(
        self,
        request: ProviderChatRequest,
        *,
        on_notice: NoticeCallback | None = None,
    ) -> AsyncIterator[ProviderEvent]:
        """Stream from primary model with retry/backoff, circuit breaker, and fallback chain."""
        candidates = [request.model, *self._fallback_chains.get(request.model, [])]
        last_error: ClassifiedProviderError | None = None

        for idx_cand, candidate_model in enumerate(candidates):
            provider_id = self._resolve_provider_id(candidate_model)
            adapter = self._adapters[provider_id]
            breaker = self.get_breaker(provider_id)
            sem = self._semaphores.get(provider_id) or asyncio.Semaphore(8)

            if not breaker.allow_request():
                last_error = ClassifiedProviderError(
                    category="overloaded",
                    message=f"Circuit breaker open for provider '{provider_id}'",
                    retryable=True,
                    provider=provider_id,
                )
                if idx_cand + 1 < len(candidates) and on_notice is not None:
                    next_model = candidates[idx_cand + 1]
                    await on_notice(
                        "warning",
                        "provider_fallback",
                        f"Circuit breaker open for {candidate_model}; falling back to {next_model}",
                    )
                continue

            if idx_cand > 0 and on_notice is not None:
                await on_notice(
                    "warning",
                    "provider_fallback",
                    f"Falling back from {request.model} to {candidate_model}",
                )

            max_retries = self.settings.provider_max_retries
            attempt = 0

            while attempt <= max_retries:
                attempt += 1
                emitted_content = False
                start_mono = self.clock()
                captured_events: list[dict[str, Any]] = []

                try:
                    async with sem:
                        cand_req = ProviderChatRequest(
                            model=candidate_model,
                            messages=request.messages,
                            tools=request.tools,
                            temperature=request.temperature,
                            max_tokens=request.max_tokens,
                            thinking_enabled=request.thinking_enabled,
                            json_mode=request.json_mode,
                            run_id=request.run_id,
                            metadata=request.metadata,
                        )
                        async for ev in adapter.stream_chat(cand_req):
                            if (
                                self.clock() - start_mono
                                > self.settings.provider_total_timeout_seconds
                            ):
                                raise ClassifiedProviderError(
                                    category="timeout",
                                    message="Provider total stream timeout exceeded",
                                    retryable=False,
                                    provider=provider_id,
                                )
                            if ev.type in ("text_delta", "thinking_delta", "tool_call_start"):
                                emitted_content = True
                            if self.settings.capture_raw_exchanges:
                                captured_events.append({"type": ev.type, "len": len(ev.text)})
                            yield ev

                    breaker.record_success()
                    PROVIDER_LATENCY.labels(provider=provider_id, model=candidate_model).observe(
                        max(0.0, self.clock() - start_mono)
                    )
                    await self._maybe_record_raw_exchange(
                        run_id=request.run_id,
                        provider_id=provider_id,
                        model=candidate_model,
                        events_summary=captured_events,
                    )
                    return

                except ClassifiedProviderError as err:
                    last_error = err
                    PROVIDER_ERRORS.labels(provider=provider_id, code=err.category).inc()
                    if err.category in ("rate_limit", "overloaded", "network", "timeout"):
                        breaker.record_failure()

                    # Only retry if no partial content was emitted yet and error is retryable
                    if (
                        not emitted_content
                        and err.retryable
                        and attempt <= max_retries
                        and breaker.allow_request()
                    ):
                        if err.retry_after is not None and err.retry_after > 0:
                            wait_sec = min(float(err.retry_after), 10.0)
                        else:
                            base_backoff = min(4.0, 0.2 * (2 ** (attempt - 1)))
                            wait_sec = secrets.SystemRandom().uniform(0.05, max(0.06, base_backoff))
                        logger.warning(
                            "provider_retry_scheduled",
                            provider=provider_id,
                            model=candidate_model,
                            category=err.category,
                            attempt=attempt,
                            wait_seconds=round(wait_sec, 3),
                        )
                        if on_notice is not None:
                            notice_msg = (
                                f"Provider {provider_id} returned {err.category}; "
                                f"retrying ({attempt}/{max_retries}) after {wait_sec:.2f}s"
                            )
                            await on_notice("warning", "provider_retry", notice_msg)
                        await self.sleep_fn(wait_sec)
                        continue
                    break

        if last_error is not None:
            raise last_error
        raise ClassifiedProviderError(
            category="unknown",
            message="No provider candidates available",
            retryable=False,
        )
