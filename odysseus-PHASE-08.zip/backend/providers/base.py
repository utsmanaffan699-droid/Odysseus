"""Provider-agnostic LLM streaming interface, normalized events, and error classification."""

from __future__ import annotations

import json
from collections.abc import AsyncIterator, Mapping
from dataclasses import dataclass, field
from typing import Any, Literal, Protocol

ProviderErrorCategory = Literal[
    "auth",
    "rate_limit",
    "overloaded",
    "context_length",
    "content_filter",
    "invalid_request",
    "network",
    "timeout",
    "unknown",
]

ProviderEventType = Literal[
    "text_delta",
    "thinking_delta",
    "tool_call_start",
    "tool_call_args_delta",
    "tool_call_end",
    "usage",
    "stop",
    "error",
]


@dataclass
class ClassifiedProviderError(Exception):
    """Normalized provider failure with retryability and Retry-After metadata."""

    category: ProviderErrorCategory
    message: str
    retryable: bool
    retry_after: float | None = None
    status_code: int | None = None
    provider: str = ""

    def __str__(self) -> str:
        return f"[{self.provider or 'provider'}:{self.category}] {self.message}"


@dataclass(frozen=True)
class ProviderMessage:
    """Normalized input message sent to an LLM provider."""

    role: Literal["system", "user", "assistant", "tool"]
    content: str
    images: list[dict[str, Any]] = field(default_factory=list)
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    tool_call_id: str | None = None
    cache_ephemeral: bool = False


@dataclass(frozen=True)
class ProviderToolSpec:
    """Tool definition passed to a provider."""

    name: str
    description: str
    parameters: dict[str, Any]


@dataclass(frozen=True)
class ProviderChatRequest:
    """Normalized chat completion streaming request."""

    model: str
    messages: list[ProviderMessage]
    tools: list[ProviderToolSpec] = field(default_factory=list)
    temperature: float = 0.0
    max_tokens: int = 4096
    thinking_enabled: bool = False
    json_mode: bool = False
    run_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ProviderEvent:
    """Normalized streaming event yielded by any LLM provider adapter."""

    type: ProviderEventType
    text: str = ""
    signature: str | None = None
    duration_ms: int | None = None
    call_id: str = ""
    tool_name: str = ""
    args_delta: str = ""
    input_tokens: int = 0
    output_tokens: int = 0
    cached_tokens: int = 0
    reasoning_tokens: int = 0
    stop_reason: str = "end_turn"
    error: ClassifiedProviderError | None = None


class LLMProviderAdapter(Protocol):
    """Protocol implemented by all concrete LLM provider adapters."""

    provider_id: str

    def stream_chat(self, request: ProviderChatRequest) -> AsyncIterator[ProviderEvent]:
        """Stream normalized provider events for a chat request."""
        ...


def sanitize_stream_text(raw: str) -> str:
    """Remove null bytes (`\\u0000`) from streamed provider text."""
    if "\x00" in raw:
        return raw.replace("\x00", "")
    return raw


def strict_json_loads(raw_text: str, *, max_bytes: int = 262_144) -> dict[str, Any]:
    """Parse JSON frame while enforcing size cap, null-byte checks, and duplicate key rejection."""
    raw_bytes = raw_text.encode("utf-8", errors="strict")
    if len(raw_bytes) > max_bytes:
        raise ClassifiedProviderError(
            category="invalid_request",
            message=f"Provider JSON frame size ({len(raw_bytes)} B) exceeds limit ({max_bytes} B)",
            retryable=False,
        )
    if "\x00" in raw_text or "\\u0000" in raw_text:
        raise ClassifiedProviderError(
            category="invalid_request",
            message="Provider JSON frame contains disallowed null byte (\\u0000)",
            retryable=False,
        )

    def _no_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for k, v in pairs:
            if k in result:
                raise ClassifiedProviderError(
                    category="invalid_request",
                    message=f"Duplicate JSON key '{k}' in provider frame",
                    retryable=False,
                )
            result[k] = v
        return result

    try:
        parsed = json.loads(raw_text, object_pairs_hook=_no_duplicate_keys)
    except ClassifiedProviderError:
        raise
    except Exception as exc:
        raise ClassifiedProviderError(
            category="invalid_request",
            message=f"Malformed JSON in provider frame: {exc}",
            retryable=False,
        ) from exc

    if not isinstance(parsed, dict):
        raise ClassifiedProviderError(
            category="invalid_request",
            message="Provider JSON frame root must be an object",
            retryable=False,
        )
    return parsed


def classify_provider_error(
    status_code: int | None,
    body_or_message: str,
    headers: Mapping[str, str] | None = None,
    *,
    provider: str = "",
    is_timeout: bool = False,
    is_network: bool = False,
) -> ClassifiedProviderError:
    """Classify any HTTP/network/stream error into the 9 canonical categories."""
    msg_clean = sanitize_stream_text(body_or_message).strip()[:500] or "Provider error"
    lower = msg_clean.lower()

    retry_after: float | None = None
    if headers:
        for k, v in headers.items():
            if k.lower() == "retry-after":
                try:
                    retry_after = max(0.0, float(v.strip()))
                except ValueError:
                    retry_after = None
                break

    if is_timeout or "timed out" in lower or "timeout" in lower:
        return ClassifiedProviderError(
            category="timeout",
            message=msg_clean,
            retryable=True,
            retry_after=retry_after,
            status_code=status_code,
            provider=provider,
        )

    if is_network or "connection" in lower or "incomplete chunked read" in lower or "eof" in lower:
        return ClassifiedProviderError(
            category="network",
            message=msg_clean,
            retryable=True,
            retry_after=retry_after,
            status_code=status_code,
            provider=provider,
        )

    if status_code in (401, 403) or "invalid api key" in lower or "unauthorized" in lower:
        return ClassifiedProviderError(
            category="auth",
            message=msg_clean,
            retryable=False,
            status_code=status_code,
            provider=provider,
        )

    if status_code == 429 or "rate limit" in lower or "rate_limit" in lower:
        return ClassifiedProviderError(
            category="rate_limit",
            message=msg_clean,
            retryable=True,
            retry_after=retry_after if retry_after is not None else 1.0,
            status_code=status_code or 429,
            provider=provider,
        )

    if (
        status_code in (502, 503, 529)
        or "overloaded" in lower
        or "capacity" in lower
        or "server is busy" in lower
    ):
        return ClassifiedProviderError(
            category="overloaded",
            message=msg_clean,
            retryable=True,
            retry_after=retry_after if retry_after is not None else 1.0,
            status_code=status_code,
            provider=provider,
        )

    if (
        "context_length" in lower
        or "maximum context length" in lower
        or "prompt is too long" in lower
        or "too many tokens" in lower
    ):
        return ClassifiedProviderError(
            category="context_length",
            message=msg_clean,
            retryable=False,
            status_code=status_code,
            provider=provider,
        )

    if (
        "content_filter" in lower
        or "content_policy" in lower
        or "safety" in lower
        or "blocked by safety" in lower
    ):
        return ClassifiedProviderError(
            category="content_filter",
            message=msg_clean,
            retryable=False,
            status_code=status_code,
            provider=provider,
        )

    if status_code in (400, 404, 422):
        return ClassifiedProviderError(
            category="invalid_request",
            message=msg_clean,
            retryable=False,
            status_code=status_code,
            provider=provider,
        )

    retryable = bool(status_code is not None and status_code >= 500)
    return ClassifiedProviderError(
        category="unknown",
        message=msg_clean,
        retryable=retryable,
        retry_after=retry_after,
        status_code=status_code,
        provider=provider,
    )
