"""Concrete LLM provider adapters: OpenAI-compatible (/v1 & Responses), Anthropic, Gemini, Fake."""

from __future__ import annotations

import json
import re
from collections.abc import AsyncIterator
from typing import Any

import httpx

from backend.providers.base import (
    ClassifiedProviderError,
    ProviderChatRequest,
    ProviderEvent,
    classify_provider_error,
    sanitize_stream_text,
    strict_json_loads,
)
from backend.providers.fake import FakeProvider

FENCED_TOOL_CALL_RE = re.compile(
    r"```(?:tool_call|json_tool)\s*\n(.*?)\n```",
    re.DOTALL,
)


async def iter_bounded_sse_lines(
    response: httpx.Response,
    *,
    provider: str,
    max_frame_bytes: int = 262_144,
) -> AsyncIterator[str]:
    """Read SSE lines from an httpx stream while enforcing UTF-8 validity and max frame size."""
    buffer = bytearray()
    async for raw_chunk in response.aiter_bytes():
        if b"\x00" in raw_chunk:
            raise ClassifiedProviderError(
                category="invalid_request",
                message="Provider stream contained raw null byte (\\x00)",
                retryable=False,
                provider=provider,
            )
        buffer.extend(raw_chunk)
        if len(buffer) > max_frame_bytes and b"\n" not in buffer:
            raise ClassifiedProviderError(
                category="invalid_request",
                message=f"Provider stream frame exceeded max size ({max_frame_bytes} B)",
                retryable=False,
                provider=provider,
            )
        while b"\n" in buffer:
            idx = buffer.index(b"\n")
            line_bytes = bytes(buffer[:idx])
            del buffer[: idx + 1]
            if len(line_bytes) > max_frame_bytes:
                raise ClassifiedProviderError(
                    category="invalid_request",
                    message=f"Provider SSE line exceeded max size ({max_frame_bytes} B)",
                    retryable=False,
                    provider=provider,
                )
            try:
                line_str = line_bytes.decode("utf-8", errors="strict").rstrip("\r")
            except UnicodeDecodeError as exc:
                raise ClassifiedProviderError(
                    category="invalid_request",
                    message=f"Invalid UTF-8 in provider stream: {exc}",
                    retryable=False,
                    provider=provider,
                ) from exc
            yield line_str

    if buffer:
        if len(buffer) > max_frame_bytes:
            raise ClassifiedProviderError(
                category="invalid_request",
                message=f"Provider trailing frame exceeded max size ({max_frame_bytes} B)",
                retryable=False,
                provider=provider,
            )
        try:
            yield bytes(buffer).decode("utf-8", errors="strict").rstrip("\r")
        except UnicodeDecodeError as exc:
            raise ClassifiedProviderError(
                category="invalid_request",
                message=f"Invalid UTF-8 in provider trailing stream: {exc}",
                retryable=False,
                provider=provider,
            ) from exc


class OpenAICompatibleAdapter:
    """Adapter for OpenAI `/v1/chat/completions` and `/v1/responses` (Ollama, vLLM, Groq, etc.)."""

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str | None = None,
        provider_id: str = "openai",
        use_responses_api: bool = False,
        tools_mode: str = "native",
        connect_timeout: float = 5.0,
        read_timeout: float = 30.0,
        max_frame_bytes: int = 262_144,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.provider_id = provider_id
        self.use_responses_api = use_responses_api
        self.tools_mode = tools_mode
        self.connect_timeout = connect_timeout
        self.read_timeout = read_timeout
        self.max_frame_bytes = max_frame_bytes
        self.transport = transport

    def _build_payload(self, request: ProviderChatRequest) -> dict[str, Any]:
        model_short = (
            request.model.split("/", 1)[1]
            if "/" in request.model and request.model.startswith(f"{self.provider_id}/")
            else request.model
        )
        messages_payload: list[dict[str, Any]] = []
        for m in request.messages:
            if m.images:
                content_parts: list[dict[str, Any]] = [{"type": "text", "text": m.content}]
                for img in m.images:
                    content_parts.append(
                        {
                            "type": "image_url",
                            "image_url": {"url": img.get("url", "")},
                        }
                    )
                messages_payload.append({"role": m.role, "content": content_parts})
            else:
                msg_dict: dict[str, Any] = {"role": m.role, "content": m.content}
                if m.tool_call_id:
                    msg_dict["tool_call_id"] = m.tool_call_id
                messages_payload.append(msg_dict)

        if self.use_responses_api:
            return {
                "model": model_short,
                "input": messages_payload,
                "stream": True,
                "max_output_tokens": request.max_tokens,
            }

        payload: dict[str, Any] = {
            "model": model_short,
            "messages": messages_payload,
            "stream": True,
            "temperature": request.temperature,
            "max_tokens": request.max_tokens,
        }
        if request.json_mode:
            payload["response_format"] = {"type": "json_object"}
        if request.tools and self.tools_mode == "native":
            payload["tools"] = [
                {
                    "type": "function",
                    "function": {
                        "name": t.name,
                        "description": t.description,
                        "parameters": t.parameters,
                    },
                }
                for t in request.tools
            ]
        return payload

    async def stream_chat(self, request: ProviderChatRequest) -> AsyncIterator[ProviderEvent]:
        headers: dict[str, str] = {
            "Accept": "text/event-stream",
            "Content-Type": "application/json",
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        endpoint = (
            f"{self.base_url}/v1/responses"
            if self.use_responses_api
            else f"{self.base_url}/v1/chat/completions"
        )
        payload = self._build_payload(request)
        timeout = httpx.Timeout(
            connect=self.connect_timeout,
            read=self.read_timeout,
            write=10.0,
            pool=5.0,
        )

        active_tool_calls: dict[int, dict[str, str]] = {}
        accumulated_text: list[str] = []
        stop_emitted = False

        try:
            async with httpx.AsyncClient(timeout=timeout, transport=self.transport) as client:
                async with client.stream("POST", endpoint, headers=headers, json=payload) as resp:
                    if resp.status_code >= 400:
                        body_bytes = await resp.aread()
                        body_text = body_bytes.decode("utf-8", errors="replace")
                        raise classify_provider_error(
                            resp.status_code,
                            body_text,
                            resp.headers,
                            provider=self.provider_id,
                        )

                    async for line in iter_bounded_sse_lines(
                        resp,
                        provider=self.provider_id,
                        max_frame_bytes=self.max_frame_bytes,
                    ):
                        if not line or line.startswith(":"):
                            continue
                        if not line.startswith("data:"):
                            continue
                        data_str = line[5:].strip()
                        if data_str == "[DONE]":
                            break

                        frame = strict_json_loads(data_str, max_bytes=self.max_frame_bytes)

                        if frame.get("error"):
                            err_obj = frame["error"]
                            msg = (
                                err_obj.get("message", str(err_obj))
                                if isinstance(err_obj, dict)
                                else str(err_obj)
                            )
                            raise classify_provider_error(None, msg, provider=self.provider_id)

                        # Handle OpenAI Responses API events if applicable
                        frame_type = frame.get("type")
                        if frame_type == "response.output_text.delta":
                            delta_txt = sanitize_stream_text(str(frame.get("delta", "")))
                            if delta_txt:
                                accumulated_text.append(delta_txt)
                                yield ProviderEvent(type="text_delta", text=delta_txt)
                            continue
                        if frame_type == "response.completed":
                            resp_obj = frame.get("response") or {}
                            u_obj = resp_obj.get("usage") or {}
                            yield ProviderEvent(
                                type="usage",
                                input_tokens=int(u_obj.get("input_tokens", 0)),
                                output_tokens=int(u_obj.get("output_tokens", 0)),
                            )
                            yield ProviderEvent(type="stop", stop_reason="end_turn")
                            stop_emitted = True
                            continue

                        # Standard /v1/chat/completions delta handling
                        choices = frame.get("choices") or []
                        for choice in choices:
                            delta = choice.get("delta") or {}
                            thinking_txt = delta.get("reasoning_content") or delta.get("thinking")
                            if isinstance(thinking_txt, str) and thinking_txt:
                                yield ProviderEvent(
                                    type="thinking_delta",
                                    text=sanitize_stream_text(thinking_txt),
                                )

                            content_txt = delta.get("content")
                            if isinstance(content_txt, str) and content_txt:
                                clean_txt = sanitize_stream_text(content_txt)
                                accumulated_text.append(clean_txt)
                                yield ProviderEvent(type="text_delta", text=clean_txt)

                            tc_list = delta.get("tool_calls") or []
                            for idx_pos, tc in enumerate(tc_list):
                                tc_index = int(tc.get("index", idx_pos))
                                fn = tc.get("function") or {}
                                tc_id = tc.get("id")
                                fn_name = fn.get("name")
                                fn_args = fn.get("arguments")

                                if tc_index not in active_tool_calls:
                                    cid = str(tc_id or f"call_{tc_index}")
                                    tname = str(fn_name or "unknown_tool")
                                    active_tool_calls[tc_index] = {
                                        "call_id": cid,
                                        "name": tname,
                                        "args": "",
                                    }
                                    yield ProviderEvent(
                                        type="tool_call_start",
                                        call_id=cid,
                                        tool_name=tname,
                                    )
                                else:
                                    cur_name = active_tool_calls[tc_index]["name"]
                                    if fn_name and cur_name == "unknown_tool":
                                        active_tool_calls[tc_index]["name"] = str(fn_name)

                                if isinstance(fn_args, str) and fn_args:
                                    cid = active_tool_calls[tc_index]["call_id"]
                                    active_tool_calls[tc_index]["args"] += fn_args
                                    yield ProviderEvent(
                                        type="tool_call_args_delta",
                                        call_id=cid,
                                        args_delta=fn_args,
                                    )

                            finish_reason = choice.get("finish_reason")
                            if finish_reason:
                                for tc_state in active_tool_calls.values():
                                    yield ProviderEvent(
                                        type="tool_call_end",
                                        call_id=tc_state["call_id"],
                                        tool_name=tc_state["name"],
                                        args_delta=tc_state["args"],
                                    )
                                active_tool_calls.clear()
                                mapped_reason = (
                                    "tool_use"
                                    if finish_reason == "tool_calls"
                                    else ("max_tokens" if finish_reason == "length" else "end_turn")
                                )
                                yield ProviderEvent(type="stop", stop_reason=mapped_reason)
                                stop_emitted = True

                        usage_obj = frame.get("usage")
                        if isinstance(usage_obj, dict) and usage_obj:
                            prompt_details = usage_obj.get("prompt_tokens_details") or {}
                            comp_details = usage_obj.get("completion_tokens_details") or {}
                            yield ProviderEvent(
                                type="usage",
                                input_tokens=int(usage_obj.get("prompt_tokens", 0)),
                                output_tokens=int(usage_obj.get("completion_tokens", 0)),
                                cached_tokens=int(prompt_details.get("cached_tokens", 0)),
                                reasoning_tokens=int(comp_details.get("reasoning_tokens", 0)),
                            )

                    # Flush any open tool calls if stream ended without finish_reason
                    for tc_state in active_tool_calls.values():
                        yield ProviderEvent(
                            type="tool_call_end",
                            call_id=tc_state["call_id"],
                            tool_name=tc_state["name"],
                            args_delta=tc_state["args"],
                        )
                    active_tool_calls.clear()

                    # Extract fenced tool calls from accumulated text when in text_fenced mode
                    if self.tools_mode == "text_fenced" and accumulated_text:
                        full_txt = "".join(accumulated_text)
                        for idx_m, match in enumerate(FENCED_TOOL_CALL_RE.finditer(full_txt)):
                            try:
                                parsed_tc = json.loads(match.group(1).strip())
                                if isinstance(parsed_tc, dict) and "name" in parsed_tc:
                                    cid = f"fenced_call_{idx_m + 1}"
                                    tname = str(parsed_tc["name"])
                                    raw_args = json.dumps(parsed_tc.get("arguments", {}))
                                    yield ProviderEvent(
                                        type="tool_call_start",
                                        call_id=cid,
                                        tool_name=tname,
                                    )
                                    yield ProviderEvent(
                                        type="tool_call_args_delta",
                                        call_id=cid,
                                        args_delta=raw_args,
                                    )
                                    yield ProviderEvent(
                                        type="tool_call_end",
                                        call_id=cid,
                                        tool_name=tname,
                                        args_delta=raw_args,
                                    )
                            except ValueError:
                                continue

                    if not stop_emitted:
                        yield ProviderEvent(type="stop", stop_reason="end_turn")

        except ClassifiedProviderError:
            raise
        except httpx.TimeoutException as exc:
            raise classify_provider_error(
                None, str(exc), provider=self.provider_id, is_timeout=True
            ) from exc
        except httpx.HTTPError as exc:
            raise classify_provider_error(
                None, str(exc), provider=self.provider_id, is_network=True
            ) from exc


class AnthropicMessagesAdapter:
    """Adapter for Anthropic `/v1/messages` streaming SSE with thinking & prompt caching."""

    def __init__(
        self,
        *,
        base_url: str = "https://api.anthropic.com",
        api_key: str | None = None,
        provider_id: str = "anthropic",
        connect_timeout: float = 5.0,
        read_timeout: float = 30.0,
        max_frame_bytes: int = 262_144,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.provider_id = provider_id
        self.connect_timeout = connect_timeout
        self.read_timeout = read_timeout
        self.max_frame_bytes = max_frame_bytes
        self.transport = transport

    def build_request_headers_and_body(
        self, request: ProviderChatRequest
    ) -> tuple[dict[str, str], dict[str, Any]]:
        headers: dict[str, str] = {
            "Accept": "text/event-stream",
            "Content-Type": "application/json",
            "anthropic-version": "2023-06-01",
            "anthropic-beta": "prompt-caching-2024-07-31",
        }
        if self.api_key:
            headers["x-api-key"] = self.api_key

        model_short = (
            request.model.split("/", 1)[1]
            if request.model.startswith("anthropic/")
            else request.model
        )
        system_blocks: list[dict[str, Any]] = []
        messages_list: list[dict[str, Any]] = []

        for m in request.messages:
            if m.role == "system":
                block: dict[str, Any] = {"type": "text", "text": m.content}
                if m.cache_ephemeral:
                    block["cache_control"] = {"type": "ephemeral"}
                system_blocks.append(block)
            else:
                role = "assistant" if m.role == "assistant" else "user"
                msg_block: dict[str, Any] = {"type": "text", "text": m.content}
                if m.cache_ephemeral:
                    msg_block["cache_control"] = {"type": "ephemeral"}
                messages_list.append({"role": role, "content": [msg_block]})

        body: dict[str, Any] = {
            "model": model_short,
            "max_tokens": request.max_tokens,
            "messages": messages_list,
            "stream": True,
        }
        if system_blocks:
            body["system"] = system_blocks
        if request.thinking_enabled:
            body["thinking"] = {"type": "enabled", "budget_tokens": 1024}
        if request.tools:
            body["tools"] = [
                {
                    "name": t.name,
                    "description": t.description,
                    "input_schema": t.parameters,
                }
                for t in request.tools
            ]
        return headers, body

    async def stream_chat(self, request: ProviderChatRequest) -> AsyncIterator[ProviderEvent]:
        headers, body = self.build_request_headers_and_body(request)
        endpoint = f"{self.base_url}/v1/messages"
        timeout = httpx.Timeout(
            connect=self.connect_timeout,
            read=self.read_timeout,
            write=10.0,
            pool=5.0,
        )

        active_blocks: dict[int, dict[str, str]] = {}
        input_tokens = 0
        cached_tokens = 0
        output_tokens = 0
        stop_reason = "end_turn"

        try:
            async with httpx.AsyncClient(timeout=timeout, transport=self.transport) as client:
                async with client.stream("POST", endpoint, headers=headers, json=body) as resp:
                    if resp.status_code >= 400:
                        err_bytes = await resp.aread()
                        raise classify_provider_error(
                            resp.status_code,
                            err_bytes.decode("utf-8", errors="replace"),
                            resp.headers,
                            provider=self.provider_id,
                        )

                    async for line in iter_bounded_sse_lines(
                        resp,
                        provider=self.provider_id,
                        max_frame_bytes=self.max_frame_bytes,
                    ):
                        if not line or line.startswith(":") or line.startswith("event:"):
                            continue
                        if not line.startswith("data:"):
                            continue
                        data_str = line[5:].strip()
                        if not data_str or data_str == "[DONE]":
                            continue

                        frame = strict_json_loads(data_str, max_bytes=self.max_frame_bytes)
                        ftype = frame.get("type")

                        if ftype == "error":
                            err = frame.get("error") or {}
                            raise classify_provider_error(
                                None,
                                str(err.get("message", err)),
                                provider=self.provider_id,
                            )

                        if ftype == "message_start":
                            msg_obj = frame.get("message") or {}
                            u = msg_obj.get("usage") or {}
                            input_tokens = int(u.get("input_tokens", 0))
                            cached_tokens = int(u.get("cache_read_input_tokens", 0))
                            output_tokens = int(u.get("output_tokens", 0))

                        elif ftype == "content_block_start":
                            idx = int(frame.get("index", 0))
                            cb = frame.get("content_block") or {}
                            cb_type = str(cb.get("type", "text"))
                            if cb_type == "tool_use":
                                cid = str(cb.get("id", f"anth_call_{idx}"))
                                tname = str(cb.get("name", "unknown"))
                                active_blocks[idx] = {
                                    "type": "tool_use",
                                    "call_id": cid,
                                    "name": tname,
                                    "args": "",
                                }
                                yield ProviderEvent(
                                    type="tool_call_start",
                                    call_id=cid,
                                    tool_name=tname,
                                )
                            else:
                                active_blocks[idx] = {"type": cb_type, "signature": ""}

                        elif ftype == "content_block_delta":
                            idx = int(frame.get("index", 0))
                            delta = frame.get("delta") or {}
                            dtype = delta.get("type")
                            if dtype == "text_delta":
                                txt = sanitize_stream_text(str(delta.get("text", "")))
                                if txt:
                                    yield ProviderEvent(type="text_delta", text=txt)
                            elif dtype == "thinking_delta":
                                th_txt = sanitize_stream_text(str(delta.get("thinking", "")))
                                if th_txt:
                                    yield ProviderEvent(type="thinking_delta", text=th_txt)
                            elif dtype == "signature_delta":
                                sig = str(delta.get("signature", ""))
                                if idx in active_blocks:
                                    active_blocks[idx]["signature"] = (
                                        active_blocks[idx].get("signature", "") + sig
                                    )
                            elif dtype == "input_json_delta":
                                partial = str(delta.get("partial_json", ""))
                                bstate = active_blocks.get(idx)
                                if bstate and bstate.get("type") == "tool_use" and partial:
                                    bstate["args"] += partial
                                    yield ProviderEvent(
                                        type="tool_call_args_delta",
                                        call_id=bstate["call_id"],
                                        args_delta=partial,
                                    )

                        elif ftype == "content_block_stop":
                            idx = int(frame.get("index", 0))
                            bstate = active_blocks.pop(idx, None)
                            if bstate and bstate.get("type") == "tool_use":
                                yield ProviderEvent(
                                    type="tool_call_end",
                                    call_id=bstate["call_id"],
                                    tool_name=bstate["name"],
                                    args_delta=bstate["args"],
                                )

                        elif ftype == "message_delta":
                            md = frame.get("delta") or {}
                            sr = md.get("stop_reason")
                            if sr:
                                stop_reason = (
                                    "tool_use"
                                    if sr == "tool_use"
                                    else ("max_tokens" if sr == "max_tokens" else "end_turn")
                                )
                            u = frame.get("usage") or {}
                            if "output_tokens" in u:
                                output_tokens = int(u["output_tokens"])
                            yield ProviderEvent(
                                type="usage",
                                input_tokens=input_tokens,
                                output_tokens=output_tokens,
                                cached_tokens=cached_tokens,
                            )

                        elif ftype == "message_stop":
                            yield ProviderEvent(type="stop", stop_reason=stop_reason)
                            return

                    yield ProviderEvent(type="stop", stop_reason=stop_reason)

        except ClassifiedProviderError:
            raise
        except httpx.TimeoutException as exc:
            raise classify_provider_error(
                None, str(exc), provider=self.provider_id, is_timeout=True
            ) from exc
        except httpx.HTTPError as exc:
            raise classify_provider_error(
                None, str(exc), provider=self.provider_id, is_network=True
            ) from exc


class GeminiAdapter:
    """Adapter for Google Gemini `/v1beta/models/{model}:streamGenerateContent?alt=sse`."""

    def __init__(
        self,
        *,
        base_url: str = "https://generativelanguage.googleapis.com",
        api_key: str | None = None,
        provider_id: str = "gemini",
        connect_timeout: float = 5.0,
        read_timeout: float = 30.0,
        max_frame_bytes: int = 262_144,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.provider_id = provider_id
        self.connect_timeout = connect_timeout
        self.read_timeout = read_timeout
        self.max_frame_bytes = max_frame_bytes
        self.transport = transport

    def build_request_body(self, request: ProviderChatRequest) -> dict[str, Any]:
        contents: list[dict[str, Any]] = []
        system_instruction: dict[str, Any] | None = None

        for m in request.messages:
            if m.role == "system":
                system_instruction = {"parts": [{"text": m.content}]}
            else:
                role = "model" if m.role == "assistant" else "user"
                contents.append({"role": role, "parts": [{"text": m.content}]})

        body: dict[str, Any] = {
            "contents": contents,
            "generationConfig": {
                "temperature": request.temperature,
                "maxOutputTokens": request.max_tokens,
            },
        }
        if system_instruction:
            body["systemInstruction"] = system_instruction
        if request.tools:
            body["tools"] = [
                {
                    "functionDeclarations": [
                        {
                            "name": t.name,
                            "description": t.description,
                            "parameters": t.parameters,
                        }
                        for t in request.tools
                    ]
                }
            ]
        return body

    async def stream_chat(self, request: ProviderChatRequest) -> AsyncIterator[ProviderEvent]:
        model_short = (
            request.model.split("/", 1)[1] if request.model.startswith("gemini/") else request.model
        )
        headers: dict[str, str] = {
            "Accept": "text/event-stream",
            "Content-Type": "application/json",
        }
        if self.api_key:
            headers["x-goog-api-key"] = self.api_key

        endpoint = f"{self.base_url}/v1beta/models/{model_short}:streamGenerateContent?alt=sse"
        body = self.build_request_body(request)
        timeout = httpx.Timeout(
            connect=self.connect_timeout,
            read=self.read_timeout,
            write=10.0,
            pool=5.0,
        )

        call_seq = 0
        stop_reason = "end_turn"

        try:
            async with httpx.AsyncClient(timeout=timeout, transport=self.transport) as client:
                async with client.stream("POST", endpoint, headers=headers, json=body) as resp:
                    if resp.status_code >= 400:
                        err_bytes = await resp.aread()
                        raise classify_provider_error(
                            resp.status_code,
                            err_bytes.decode("utf-8", errors="replace"),
                            resp.headers,
                            provider=self.provider_id,
                        )

                    async for line in iter_bounded_sse_lines(
                        resp,
                        provider=self.provider_id,
                        max_frame_bytes=self.max_frame_bytes,
                    ):
                        if not line or line.startswith(":"):
                            continue
                        if not line.startswith("data:"):
                            continue
                        data_str = line[5:].strip()
                        if not data_str or data_str == "[DONE]":
                            continue

                        frame = strict_json_loads(data_str, max_bytes=self.max_frame_bytes)
                        if frame.get("error"):
                            err = frame["error"]
                            raise classify_provider_error(
                                int(err.get("code", 500)) if isinstance(err, dict) else 500,
                                str(err.get("message", err)) if isinstance(err, dict) else str(err),
                                provider=self.provider_id,
                            )

                        candidates = frame.get("candidates") or []
                        for cand in candidates:
                            content = cand.get("content") or {}
                            for part in content.get("parts") or []:
                                if part.get("thought") is True and "text" in part:
                                    yield ProviderEvent(
                                        type="thinking_delta",
                                        text=sanitize_stream_text(str(part["text"])),
                                    )
                                elif part.get("text"):
                                    yield ProviderEvent(
                                        type="text_delta",
                                        text=sanitize_stream_text(str(part["text"])),
                                    )
                                elif "functionCall" in part:
                                    fc = part["functionCall"]
                                    call_seq += 1
                                    cid = f"gem_call_{call_seq}"
                                    tname = str(fc.get("name", "unknown"))
                                    raw_args = json.dumps(fc.get("args", {}))
                                    yield ProviderEvent(
                                        type="tool_call_start",
                                        call_id=cid,
                                        tool_name=tname,
                                    )
                                    yield ProviderEvent(
                                        type="tool_call_args_delta",
                                        call_id=cid,
                                        args_delta=raw_args,
                                    )
                                    yield ProviderEvent(
                                        type="tool_call_end",
                                        call_id=cid,
                                        tool_name=tname,
                                        args_delta=raw_args,
                                    )
                                    stop_reason = "tool_use"

                            fr = cand.get("finishReason")
                            if fr == "MAX_TOKENS":
                                stop_reason = "max_tokens"
                            elif fr == "SAFETY":
                                raise classify_provider_error(
                                    400,
                                    "Blocked by safety filter",
                                    provider=self.provider_id,
                                )

                        usage_meta = frame.get("usageMetadata")
                        if isinstance(usage_meta, dict):
                            yield ProviderEvent(
                                type="usage",
                                input_tokens=int(usage_meta.get("promptTokenCount", 0)),
                                output_tokens=int(usage_meta.get("candidatesTokenCount", 0)),
                                cached_tokens=int(usage_meta.get("cachedContentTokenCount", 0)),
                                reasoning_tokens=int(usage_meta.get("thoughtsTokenCount", 0)),
                            )

                    yield ProviderEvent(type="stop", stop_reason=stop_reason)

        except ClassifiedProviderError:
            raise
        except httpx.TimeoutException as exc:
            raise classify_provider_error(
                None, str(exc), provider=self.provider_id, is_timeout=True
            ) from exc
        except httpx.HTTPError as exc:
            raise classify_provider_error(
                None, str(exc), provider=self.provider_id, is_network=True
            ) from exc


class FakeProviderAdapter:
    """In-process adapter bridging FakeProvider to the normalized ProviderEvent stream."""

    def __init__(self, fake_provider: FakeProvider, provider_id: str = "fake") -> None:
        self.fake = fake_provider
        self.provider_id = provider_id

    async def stream_chat(self, request: ProviderChatRequest) -> AsyncIterator[ProviderEvent]:
        from backend.providers.fake import FakeHttpError, FakeStreamDisconnectedError

        self.fake.recorded_requests.append(request)
        msg_dicts: list[dict[str, Any]] = [
            {"role": m.role, "content": m.content} for m in request.messages
        ]
        stop_reason = "end_turn"
        try:
            async for chunk in self.fake.stream_completion(msg_dicts):
                if chunk.kind == "thinking":
                    yield ProviderEvent(
                        type="thinking_delta",
                        text=sanitize_stream_text(chunk.text),
                        signature=chunk.signature,
                        duration_ms=chunk.duration_ms,
                    )
                elif chunk.kind == "text":
                    yield ProviderEvent(
                        type="text_delta",
                        text=sanitize_stream_text(chunk.text),
                    )
                elif chunk.kind == "tool_call":
                    cid = chunk.call_id or "call_1"
                    tname = chunk.tool_name or "tool"
                    raw_args = chunk.tool_args_raw or "{}"
                    yield ProviderEvent(type="tool_call_start", call_id=cid, tool_name=tname)
                    yield ProviderEvent(
                        type="tool_call_args_delta", call_id=cid, args_delta=raw_args
                    )
                    yield ProviderEvent(
                        type="tool_call_end",
                        call_id=cid,
                        tool_name=tname,
                        args_delta=raw_args,
                    )
                    stop_reason = "tool_use"
                elif chunk.kind == "usage" and chunk.usage:
                    yield ProviderEvent(
                        type="usage",
                        input_tokens=int(chunk.usage.get("input", 10)),
                        output_tokens=int(chunk.usage.get("output", 15)),
                        cached_tokens=int(chunk.usage.get("cached", 0)),
                        reasoning_tokens=int(chunk.usage.get("reasoning", 0)),
                    )
            yield ProviderEvent(type="stop", stop_reason=stop_reason)
        except FakeHttpError as exc:
            headers = {"Retry-After": str(exc.retry_after)} if exc.retry_after else None
            raise classify_provider_error(
                exc.status_code,
                exc.message,
                headers,
                provider=self.provider_id,
            ) from exc
        except FakeStreamDisconnectedError as exc:
            raise classify_provider_error(
                None,
                str(exc),
                provider=self.provider_id,
                is_network=True,
            ) from exc
