"""Phase 02 schema: projects, attachments, uploads, idempotency, usage_ledger, providers, FTS.

Revision ID: 0002_phase02_llm_run_engine
Revises: 0001_initial_foundation
Create Date: 2026-10-03 01:00:00
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "0002_phase02_llm_run_engine"
down_revision: str | None = "0001_initial_foundation"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    bind = op.get_bind()
    dialect = bind.dialect.name

    op.create_table(
        "projects",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column(
            "user_id",
            sa.String(length=64),
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("name", sa.String(length=255), nullable=False),
        sa.Column("description", sa.Text(), nullable=False, server_default=""),
        sa.Column("instructions", sa.Text(), nullable=False, server_default=""),
        sa.Column("default_model", sa.String(length=128), nullable=True),
        sa.Column("tools_allowlist", sa.JSON(), nullable=False),
        sa.Column("sources_json", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_projects_user_id", "projects", ["user_id"])

    op.add_column("chats", sa.Column("summary_text", sa.Text(), nullable=True))

    op.add_column(
        "messages",
        sa.Column("materialized_path", sa.Text(), nullable=False, server_default=""),
    )
    op.add_column(
        "messages",
        sa.Column("plain_text", sa.Text(), nullable=False, server_default=""),
    )
    op.add_column("messages", sa.Column("feedback", sa.String(length=32), nullable=True))
    op.add_column("messages", sa.Column("feedback_note", sa.Text(), nullable=True))
    op.create_index("ix_messages_chat_parent", "messages", ["chat_id", "parent_id"])
    op.create_index("ix_messages_chat_matpath", "messages", ["chat_id", "materialized_path"])

    op.add_column("runs", sa.Column("user_message_id", sa.String(length=64), nullable=True))
    op.add_column(
        "runs",
        sa.Column("step_index", sa.Integer(), nullable=False, server_default="0"),
    )
    op.add_column(
        "runs",
        sa.Column("checkpoint_json", sa.JSON(), nullable=False, server_default="{}"),
    )
    op.add_column(
        "runs",
        sa.Column("steer_queue_json", sa.JSON(), nullable=False, server_default="[]"),
    )

    op.create_table(
        "attachments",
        sa.Column("sha256", sa.String(length=64), primary_key=True),
        sa.Column(
            "user_id",
            sa.String(length=64),
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("filename", sa.String(length=255), nullable=False),
        sa.Column("mime_type", sa.String(length=128), nullable=False),
        sa.Column("size_bytes", sa.Integer(), nullable=False),
        sa.Column("storage_path", sa.Text(), nullable=False),
        sa.Column("thumbnail_path", sa.Text(), nullable=True),
        sa.Column("extracted_text", sa.Text(), nullable=True),
        sa.Column(
            "extraction_status",
            sa.String(length=32),
            nullable=False,
            server_default="queued",
        ),
        sa.Column(
            "scan_status",
            sa.String(length=32),
            nullable=False,
            server_default="clean",
        ),
        sa.Column("metadata_json", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_attachments_user_id", "attachments", ["user_id"])

    op.create_table(
        "upload_sessions",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column(
            "user_id",
            sa.String(length=64),
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("filename", sa.String(length=255), nullable=False),
        sa.Column("expected_size", sa.Integer(), nullable=False),
        sa.Column("received_bytes", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("temp_path", sa.Text(), nullable=False),
        sa.Column("completed_sha256", sa.String(length=64), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_upload_sessions_user_id", "upload_sessions", ["user_id"])

    op.create_table(
        "idempotency_keys",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column(
            "user_id",
            sa.String(length=64),
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("endpoint", sa.String(length=128), nullable=False),
        sa.Column("idempotency_key", sa.String(length=128), nullable=False),
        sa.Column(
            "status",
            sa.String(length=32),
            nullable=False,
            server_default="in_progress",
        ),
        sa.Column("response_json", sa.JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint(
            "user_id",
            "endpoint",
            "idempotency_key",
            name="uq_idempotency_user_endpoint_key",
        ),
    )
    op.create_index("ix_idempotency_keys_user_id", "idempotency_keys", ["user_id"])

    op.create_table(
        "usage_ledger",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column(
            "user_id",
            sa.String(length=64),
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("project_id", sa.String(length=64), nullable=True),
        sa.Column("chat_id", sa.String(length=64), nullable=True),
        sa.Column("run_id", sa.String(length=64), nullable=True),
        sa.Column("message_id", sa.String(length=64), nullable=True),
        sa.Column("provider", sa.String(length=64), nullable=False),
        sa.Column("model", sa.String(length=128), nullable=False),
        sa.Column("day", sa.String(length=10), nullable=False),
        sa.Column("input_tokens", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("output_tokens", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("cached_tokens", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("reasoning_tokens", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("cost_usd", sa.String(length=32), nullable=False, server_default="0.00000000"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_usage_ledger_user_id", "usage_ledger", ["user_id"])
    op.create_index("ix_usage_ledger_project_id", "usage_ledger", ["project_id"])
    op.create_index("ix_usage_ledger_chat_id", "usage_ledger", ["chat_id"])
    op.create_index("ix_usage_ledger_run_id", "usage_ledger", ["run_id"])
    op.create_index("ix_usage_ledger_provider", "usage_ledger", ["provider"])
    op.create_index("ix_usage_ledger_model", "usage_ledger", ["model"])
    op.create_index("ix_usage_ledger_day", "usage_ledger", ["day"])
    op.create_index("ix_usage_ledger_day_model", "usage_ledger", ["day", "model"])
    op.create_index("ix_usage_ledger_user_day", "usage_ledger", ["user_id", "day"])
    op.create_index("ix_usage_ledger_created_at", "usage_ledger", ["created_at"])

    op.create_table(
        "provider_configs",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("name", sa.String(length=128), nullable=False),
        sa.Column("kind", sa.String(length=32), nullable=False),
        sa.Column("base_url", sa.String(length=512), nullable=False),
        sa.Column("api_key_secret_key", sa.String(length=128), nullable=True),
        sa.Column("enabled", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("max_concurrency", sa.Integer(), nullable=False, server_default="2"),
        sa.Column("capabilities_override_json", sa.JSON(), nullable=False),
        sa.Column("probed_capabilities_json", sa.JSON(), nullable=False),
        sa.Column("fallback_model", sa.String(length=128), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "raw_exchanges",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("run_id", sa.String(length=64), nullable=False),
        sa.Column("provider", sa.String(length=64), nullable=False),
        sa.Column("model", sa.String(length=128), nullable=False),
        sa.Column("ciphertext", sa.Text(), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_raw_exchanges_run_id", "raw_exchanges", ["run_id"])
    op.create_index("ix_raw_exchanges_expires_at", "raw_exchanges", ["expires_at"])

    if dialect == "sqlite":
        op.execute(
            sa.text(
                "CREATE VIRTUAL TABLE IF NOT EXISTS messages_fts USING fts5("
                "message_id UNINDEXED, chat_id UNINDEXED, user_id UNINDEXED, content"
                ")"
            )
        )
    elif dialect == "postgresql":
        op.execute(
            sa.text(
                "CREATE INDEX IF NOT EXISTS ix_messages_plain_text_tsv "
                "ON messages USING gin (to_tsvector('simple', coalesce(plain_text, '')))"
            )
        )


def downgrade() -> None:
    bind = op.get_bind()
    dialect = bind.dialect.name

    if dialect == "sqlite":
        op.execute(sa.text("DROP TABLE IF EXISTS messages_fts"))
    elif dialect == "postgresql":
        op.execute(sa.text("DROP INDEX IF EXISTS ix_messages_plain_text_tsv"))

    op.drop_index("ix_raw_exchanges_expires_at", table_name="raw_exchanges")
    op.drop_index("ix_raw_exchanges_run_id", table_name="raw_exchanges")
    op.drop_table("raw_exchanges")

    op.drop_table("provider_configs")

    op.drop_index("ix_usage_ledger_created_at", table_name="usage_ledger")
    op.drop_index("ix_usage_ledger_user_day", table_name="usage_ledger")
    op.drop_index("ix_usage_ledger_day_model", table_name="usage_ledger")
    op.drop_index("ix_usage_ledger_day", table_name="usage_ledger")
    op.drop_index("ix_usage_ledger_model", table_name="usage_ledger")
    op.drop_index("ix_usage_ledger_provider", table_name="usage_ledger")
    op.drop_index("ix_usage_ledger_run_id", table_name="usage_ledger")
    op.drop_index("ix_usage_ledger_chat_id", table_name="usage_ledger")
    op.drop_index("ix_usage_ledger_project_id", table_name="usage_ledger")
    op.drop_index("ix_usage_ledger_user_id", table_name="usage_ledger")
    op.drop_table("usage_ledger")

    op.drop_index("ix_idempotency_keys_user_id", table_name="idempotency_keys")
    op.drop_table("idempotency_keys")

    op.drop_index("ix_upload_sessions_user_id", table_name="upload_sessions")
    op.drop_table("upload_sessions")

    op.drop_index("ix_attachments_user_id", table_name="attachments")
    op.drop_table("attachments")

    with op.batch_alter_table("runs") as batch_op:
        batch_op.drop_column("steer_queue_json")
        batch_op.drop_column("checkpoint_json")
        batch_op.drop_column("step_index")
        batch_op.drop_column("user_message_id")

    with op.batch_alter_table("messages") as batch_op:
        batch_op.drop_index("ix_messages_chat_matpath")
        batch_op.drop_index("ix_messages_chat_parent")
        batch_op.drop_column("feedback_note")
        batch_op.drop_column("feedback")
        batch_op.drop_column("plain_text")
        batch_op.drop_column("materialized_path")

    with op.batch_alter_table("chats") as batch_op:
        batch_op.drop_column("summary_text")

    op.drop_index("ix_projects_user_id", table_name="projects")
    op.drop_table("projects")
