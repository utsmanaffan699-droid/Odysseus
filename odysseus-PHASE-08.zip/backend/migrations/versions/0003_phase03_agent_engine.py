"""Phase 03 schema: tool_calls, approvals, approval_rules, artifacts, memories, skills, mcp_servers.

Revision ID: 0003_phase03_agent_engine
Revises: 0002_phase02_llm_run_engine
Create Date: 2026-10-03 01:35:00
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "0003_phase03_agent_engine"
down_revision: str | None = "0002_phase02_llm_run_engine"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "tool_calls",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column(
            "run_id",
            sa.String(length=64),
            sa.ForeignKey("runs.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("name", sa.String(length=128), nullable=False),
        sa.Column("args_json", sa.JSON(), nullable=False),
        sa.Column("risk", sa.String(length=32), nullable=False, server_default="read"),
        sa.Column("policy_decision", sa.String(length=32), nullable=False, server_default="auto"),
        sa.Column("policy_reason", sa.Text(), nullable=False, server_default=""),
        sa.Column("approval_id", sa.String(length=64), nullable=True),
        sa.Column("status", sa.String(length=32), nullable=False, server_default="proposed"),
        sa.Column("output_ref", sa.String(length=255), nullable=True),
        sa.Column("output_bytes", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("truncated", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("render_hint", sa.String(length=32), nullable=False, server_default="text"),
        sa.Column("summary", sa.Text(), nullable=False, server_default=""),
        sa.Column("model_view_text", sa.Text(), nullable=False, server_default=""),
        sa.Column("pgid", sa.Integer(), nullable=True),
        sa.Column("duration_ms", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_tool_calls_run_id", "tool_calls", ["run_id"])
    op.create_index("ix_tool_calls_name", "tool_calls", ["name"])
    op.create_index("ix_tool_calls_approval_id", "tool_calls", ["approval_id"])
    op.create_index("ix_tool_calls_status", "tool_calls", ["status"])

    op.create_table(
        "approvals",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column(
            "run_id",
            sa.String(length=64),
            sa.ForeignKey("runs.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("chat_id", sa.String(length=64), nullable=False),
        sa.Column(
            "user_id",
            sa.String(length=64),
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("tool_call_id", sa.String(length=64), nullable=False),
        sa.Column("tool_name", sa.String(length=128), nullable=False),
        sa.Column("args_json", sa.JSON(), nullable=False),
        sa.Column("risk", sa.String(length=32), nullable=False),
        sa.Column("reason", sa.Text(), nullable=False),
        sa.Column("explain_text", sa.Text(), nullable=False, server_default=""),
        sa.Column("suggested_pattern", sa.String(length=512), nullable=False, server_default=""),
        sa.Column("tainted_source", sa.String(length=255), nullable=True),
        sa.Column("spoof_warnings_json", sa.JSON(), nullable=False),
        sa.Column("status", sa.String(length=32), nullable=False, server_default="pending"),
        sa.Column("decision", sa.String(length=32), nullable=True),
        sa.Column("scope", sa.String(length=32), nullable=True),
        sa.Column("pattern", sa.String(length=512), nullable=True),
        sa.Column("decided_by", sa.String(length=64), nullable=True),
        sa.Column("requested_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("decided_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_approvals_run_id", "approvals", ["run_id"])
    op.create_index("ix_approvals_chat_id", "approvals", ["chat_id"])
    op.create_index("ix_approvals_user_id", "approvals", ["user_id"])
    op.create_index("ix_approvals_tool_call_id", "approvals", ["tool_call_id"])
    op.create_index("ix_approvals_status", "approvals", ["status"])

    op.create_table(
        "approval_rules",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column(
            "user_id",
            sa.String(length=64),
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("scope", sa.String(length=32), nullable=False),
        sa.Column("scope_target_id", sa.String(length=64), nullable=True),
        sa.Column("tool_name", sa.String(length=128), nullable=False),
        sa.Column("pattern", sa.String(length=512), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_approval_rules_user_id", "approval_rules", ["user_id"])
    op.create_index("ix_approval_rules_scope", "approval_rules", ["scope"])
    op.create_index("ix_approval_rules_scope_target_id", "approval_rules", ["scope_target_id"])
    op.create_index("ix_approval_rules_tool_name", "approval_rules", ["tool_name"])

    op.create_table(
        "artifacts",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column(
            "user_id",
            sa.String(length=64),
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("chat_id", sa.String(length=64), nullable=True),
        sa.Column("run_id", sa.String(length=64), nullable=True),
        sa.Column("type", sa.String(length=64), nullable=False),
        sa.Column("title", sa.String(length=255), nullable=False),
        sa.Column("latest_version", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_artifacts_user_id", "artifacts", ["user_id"])
    op.create_index("ix_artifacts_chat_id", "artifacts", ["chat_id"])
    op.create_index("ix_artifacts_run_id", "artifacts", ["run_id"])

    op.create_table(
        "artifact_versions",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column(
            "artifact_id",
            sa.String(length=64),
            sa.ForeignKey("artifacts.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("version", sa.Integer(), nullable=False),
        sa.Column("content", sa.Text(), nullable=False),
        sa.Column("summary", sa.Text(), nullable=False, server_default=""),
        sa.Column("created_by", sa.String(length=64), nullable=False, server_default="run"),
        sa.Column("parent_version", sa.Integer(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("artifact_id", "version", name="uq_artifact_version"),
    )
    op.create_index(
        "ix_artifact_versions_artifact_ver", "artifact_versions", ["artifact_id", "version"]
    )

    op.create_table(
        "memories",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column(
            "user_id",
            sa.String(length=64),
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("project_id", sa.String(length=64), nullable=True),
        sa.Column("scope", sa.String(length=32), nullable=False, server_default="user"),
        sa.Column("text", sa.Text(), nullable=False),
        sa.Column("source_chat_id", sa.String(length=64), nullable=True),
        sa.Column("source_run_id", sa.String(length=64), nullable=True),
        sa.Column("embedding_json", sa.JSON(), nullable=False),
        sa.Column("pinned", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("confirmed", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_memories_user_id", "memories", ["user_id"])
    op.create_index("ix_memories_project_id", "memories", ["project_id"])
    op.create_index("ix_memories_user_scope", "memories", ["user_id", "scope"])

    op.create_table(
        "skills",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column(
            "user_id",
            sa.String(length=64),
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=True,
        ),
        sa.Column("project_id", sa.String(length=64), nullable=True),
        sa.Column("scope", sa.String(length=32), nullable=False, server_default="user"),
        sa.Column("name", sa.String(length=128), nullable=False),
        sa.Column("description", sa.Text(), nullable=False, server_default=""),
        sa.Column("when_to_use", sa.Text(), nullable=False, server_default=""),
        sa.Column("requires_json", sa.JSON(), nullable=False),
        sa.Column("tools_json", sa.JSON(), nullable=False),
        sa.Column("body_markdown", sa.Text(), nullable=False, server_default=""),
        sa.Column("version", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("untrusted", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("reviewed", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("source_origin", sa.String(length=255), nullable=False, server_default="local"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_skills_user_id", "skills", ["user_id"])
    op.create_index("ix_skills_project_id", "skills", ["project_id"])
    op.create_index("ix_skills_name", "skills", ["name"])
    op.create_index("ix_skills_user_scope_name", "skills", ["user_id", "scope", "name"])

    op.create_table(
        "skill_versions",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column(
            "skill_id",
            sa.String(length=64),
            sa.ForeignKey("skills.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("version", sa.Integer(), nullable=False),
        sa.Column("body_markdown", sa.Text(), nullable=False),
        sa.Column("diff_summary", sa.Text(), nullable=False, server_default=""),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("skill_id", "version", name="uq_skill_version"),
    )
    op.create_index("ix_skill_versions_skill_id", "skill_versions", ["skill_id"])

    op.create_table(
        "mcp_servers",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("name", sa.String(length=128), unique=True, nullable=False),
        sa.Column("transport", sa.String(length=32), nullable=False, server_default="stdio"),
        sa.Column("command_or_url", sa.String(length=512), nullable=False),
        sa.Column("args_json", sa.JSON(), nullable=False),
        sa.Column("env_secret_keys_json", sa.JSON(), nullable=False),
        sa.Column("enabled", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("risk_overrides_json", sa.JSON(), nullable=False),
        sa.Column("oauth_config_json", sa.JSON(), nullable=False),
        sa.Column("discovered_tools_json", sa.JSON(), nullable=False),
        sa.Column("discovered_resources_json", sa.JSON(), nullable=False),
        sa.Column("discovered_prompts_json", sa.JSON(), nullable=False),
        sa.Column("status", sa.String(length=32), nullable=False, server_default="stopped"),
        sa.Column("last_error", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_mcp_servers_name", "mcp_servers", ["name"])


def downgrade() -> None:
    op.drop_index("ix_mcp_servers_name", table_name="mcp_servers")
    op.drop_table("mcp_servers")

    op.drop_index("ix_skill_versions_skill_id", table_name="skill_versions")
    op.drop_table("skill_versions")

    op.drop_index("ix_skills_user_scope_name", table_name="skills")
    op.drop_index("ix_skills_name", table_name="skills")
    op.drop_index("ix_skills_project_id", table_name="skills")
    op.drop_index("ix_skills_user_id", table_name="skills")
    op.drop_table("skills")

    op.drop_index("ix_memories_user_scope", table_name="memories")
    op.drop_index("ix_memories_project_id", table_name="memories")
    op.drop_index("ix_memories_user_id", table_name="memories")
    op.drop_table("memories")

    op.drop_index("ix_artifact_versions_artifact_ver", table_name="artifact_versions")
    op.drop_table("artifact_versions")

    op.drop_index("ix_artifacts_run_id", table_name="artifacts")
    op.drop_index("ix_artifacts_chat_id", table_name="artifacts")
    op.drop_index("ix_artifacts_user_id", table_name="artifacts")
    op.drop_table("artifacts")

    op.drop_index("ix_approval_rules_tool_name", table_name="approval_rules")
    op.drop_index("ix_approval_rules_scope_target_id", table_name="approval_rules")
    op.drop_index("ix_approval_rules_scope", table_name="approval_rules")
    op.drop_index("ix_approval_rules_user_id", table_name="approval_rules")
    op.drop_table("approval_rules")

    op.drop_index("ix_approvals_status", table_name="approvals")
    op.drop_index("ix_approvals_tool_call_id", table_name="approvals")
    op.drop_index("ix_approvals_user_id", table_name="approvals")
    op.drop_index("ix_approvals_chat_id", table_name="approvals")
    op.drop_index("ix_approvals_run_id", table_name="approvals")
    op.drop_table("approvals")

    op.drop_index("ix_tool_calls_status", table_name="tool_calls")
    op.drop_index("ix_tool_calls_approval_id", table_name="tool_calls")
    op.drop_index("ix_tool_calls_name", table_name="tool_calls")
    op.drop_index("ix_tool_calls_run_id", table_name="tool_calls")
    op.drop_table("tool_calls")
