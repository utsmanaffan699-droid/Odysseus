"""Structured JSON logging with contextvars and automatic secret redaction."""

from __future__ import annotations

import collections
import contextvars
import logging
import re
from typing import Any

import structlog

request_id_var: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "request_id", default=None
)
user_id_var: contextvars.ContextVar[str | None] = contextvars.ContextVar("user_id", default=None)
run_id_var: contextvars.ContextVar[str | None] = contextvars.ContextVar("run_id", default=None)

SENSITIVE_KEY_PATTERNS: tuple[str, ...] = (
    "password",
    "secret",
    "token",
    "authorization",
    "cookie",
    "api_key",
    "apikey",
    "master_key",
    "totp",
    "recovery_code",
    "ciphertext",
    "private_key",
)

BEARER_REGEX = re.compile(r"(Bearer\s+)[A-Za-z0-9._~+/-]+=*", re.IGNORECASE)
ODY_TOKEN_REGEX = re.compile(r"\body_[A-Za-z0-9_-]{8,}\b")

_REGISTERED_LITERAL_SECRETS: set[str] = set()
_RECENT_SANITIZED_LOGS: collections.deque[dict[str, Any]] = collections.deque(maxlen=500)


def register_secret_for_redaction(secret_value: str | None) -> None:
    """Register a literal secret string so it is scrubbed if it ever appears in any log/error."""
    if secret_value and len(secret_value) >= 4:
        _REGISTERED_LITERAL_SECRETS.add(secret_value)


def clear_registered_secrets() -> None:
    """Clear registered literal secrets (used in tests)."""
    _REGISTERED_LITERAL_SECRETS.clear()


def scrub_string(value: str) -> str:
    """Redact known secret patterns and registered literal secrets from a string."""
    result = BEARER_REGEX.sub(r"\1[REDACTED]", value)
    result = ODY_TOKEN_REGEX.sub("[REDACTED_TOKEN]", result)
    for literal in _REGISTERED_LITERAL_SECRETS:
        if literal in result:
            result = result.replace(literal, "[REDACTED]")
    return result


def scrub_value(key: str | None, value: Any) -> Any:
    """Recursively scrub sensitive keys and secret values from dicts, lists, and strings."""
    if key is not None:
        lower_key = key.lower()
        if any(pat in lower_key for pat in SENSITIVE_KEY_PATTERNS):
            return "[REDACTED]"

    if isinstance(value, str):
        return scrub_string(value)
    if isinstance(value, dict):
        return {str(k): scrub_value(str(k), v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [scrub_value(None, item) for item in value]
    return value


def inject_contextvars(
    _logger: Any, _method_name: str, event_dict: structlog.types.EventDict
) -> structlog.types.EventDict:
    """Inject request_id, user_id, and run_id contextvars into every structured log event."""
    req_id = request_id_var.get()
    usr_id = user_id_var.get()
    rn_id = run_id_var.get()
    if req_id is not None and "request_id" not in event_dict:
        event_dict["request_id"] = req_id
    if usr_id is not None and "user_id" not in event_dict:
        event_dict["user_id"] = usr_id
    if rn_id is not None and "run_id" not in event_dict:
        event_dict["run_id"] = rn_id
    return event_dict


def redact_secrets_processor(
    _logger: Any, _method_name: str, event_dict: structlog.types.EventDict
) -> structlog.types.EventDict:
    """Structlog processor that scrubs sensitive keys and literal secrets before serialization."""
    sanitized: structlog.types.EventDict = {}
    for k, v in event_dict.items():
        if k in ("event", "level", "timestamp", "logger"):
            sanitized[k] = scrub_string(v) if isinstance(v, str) else v
        else:
            sanitized[k] = scrub_value(k, v)
    _RECENT_SANITIZED_LOGS.append(dict(sanitized))
    return sanitized


def configure_logging(log_level: str = "INFO") -> None:
    """Configure structlog for JSON structured logging with redaction."""
    level_num = getattr(logging, log_level.upper(), logging.INFO)
    logging.basicConfig(format="%(message)s", level=level_num)
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            inject_contextvars,
            structlog.stdlib.add_log_level,
            structlog.processors.TimeStamper(fmt="iso", utc=True, key="timestamp"),
            redact_secrets_processor,
            structlog.processors.JSONRenderer(sort_keys=True),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(level_num),
        context_class=dict,
        logger_factory=structlog.PrintLoggerFactory(),
        cache_logger_on_first_use=False,
    )


def get_logger(name: str = "odysseus") -> Any:
    """Return a bound structured logger."""
    return structlog.get_logger(name)


def get_recent_sanitized_logs() -> list[dict[str, Any]]:
    """Return recent scrubbed log records for diagnostics/support bundles."""
    return list(_RECENT_SANITIZED_LOGS)
