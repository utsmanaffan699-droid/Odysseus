"""Security, rate-limiting, size enforcement, trusted proxy, and observability middleware."""

from __future__ import annotations

import asyncio
import re
import time
import uuid
from dataclasses import dataclass

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.responses import JSONResponse
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from backend.core.db import (
    StorageFullError,
    get_disk_degraded,
    is_disk_full_exception,
    set_disk_degraded,
)
from backend.core.logging import (
    get_logger,
    request_id_var,
    run_id_var,
    scrub_string,
    user_id_var,
)
from backend.core.metrics import HTTP_LATENCY, HTTP_REQUESTS
from backend.core.settings import Settings

logger = get_logger("odysseus.http")

SAFE_REQUEST_ID_RE = re.compile(r"^[A-Za-z0-9._-]{4,64}$")

STRICT_CSP = (
    "default-src 'self'; "
    "script-src 'self'; "
    "style-src 'self'; "
    "img-src 'self' data: blob:; "
    "font-src 'self' data:; "
    "connect-src 'self'; "
    "frame-ancestors 'none'; "
    "base-uri 'self'; "
    "form-action 'self'; "
    "object-src 'none'"
)


def resolve_client_ip(request: Request, settings: Settings) -> str:
    """Resolve client IP, trusting X-Forwarded-For ONLY when peer is in trusted_proxies."""
    peer_ip = request.client.host if request.client else "127.0.0.1"
    if peer_ip in settings.trusted_proxies:
        xff = request.headers.get("x-forwarded-for")
        if xff:
            first_hop = xff.split(",")[0].strip()
            if first_hop and "\r" not in first_hop and "\n" not in first_hop:
                return first_hop
    return peer_ip


def resolve_request_proto(request: Request, settings: Settings) -> str:
    """Resolve effective scheme ('http' or 'https'), trusting X-Forwarded-Proto from proxy."""
    peer_ip = request.client.host if request.client else "127.0.0.1"
    if peer_ip in settings.trusted_proxies:
        xfp = request.headers.get("x-forwarded-proto", "").split(",")[0].strip().lower()
        if xfp in ("http", "https"):
            return xfp
    return request.url.scheme.lower()


@dataclass
class TokenBucket:
    tokens: float
    last_refill: float


class InMemoryRateLimiter:
    """Per-IP token-bucket rate limiter (pluggable interface for Redis in cluster setups)."""

    def __init__(self, requests_per_minute: int, burst: int) -> None:
        self.rate_per_sec = max(0.01, requests_per_minute / 60.0)
        self.burst = float(max(1, burst))
        self._buckets: dict[str, TokenBucket] = {}

    def allow(self, key: str, *, now: float | None = None) -> tuple[bool, int]:
        ts = now if now is not None else time.monotonic()
        bucket = self._buckets.get(key)
        if bucket is None:
            self._buckets[key] = TokenBucket(tokens=self.burst - 1.0, last_refill=ts)
            return True, 0
        elapsed = max(0.0, ts - bucket.last_refill)
        bucket.tokens = min(self.burst, bucket.tokens + elapsed * self.rate_per_sec)
        bucket.last_refill = ts
        if bucket.tokens >= 1.0:
            bucket.tokens -= 1.0
            return True, 0
        needed = 1.0 - bucket.tokens
        retry_after = max(1, int(needed / self.rate_per_sec + 0.999))
        return False, retry_after


class BodySizeAndTimeoutEnforcerMiddleware:
    """ASGI middleware enforcing header limits, route-class body caps, and read timeouts."""

    def __init__(self, app: ASGIApp, settings: Settings) -> None:
        self.app = app
        self.settings = settings

    def _max_bytes_for_path(self, path: str) -> int:
        if path.startswith("/api/auth"):
            return self.settings.max_body_bytes_auth
        if path.startswith("/api/uploads"):
            return self.settings.max_body_bytes_upload
        return self.settings.max_body_bytes_default

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        raw_headers: list[tuple[bytes, bytes]] = scope.get("headers", [])
        if len(raw_headers) > self.settings.max_header_count:
            resp = JSONResponse(
                status_code=431,
                content={"detail": "Too many HTTP request headers"},
            )
            await resp(scope, receive, send)
            return

        total_header_bytes = sum(len(k) + len(v) for k, v in raw_headers)
        if total_header_bytes > self.settings.max_header_bytes:
            resp = JSONResponse(
                status_code=431,
                content={"detail": "Request header fields too large"},
            )
            await resp(scope, receive, send)
            return

        # Validate Host header against injection and allowed_hosts
        host_headers = [v for k, v in raw_headers if k.lower() == b"host"]
        if len(host_headers) != 1:
            resp = JSONResponse(
                status_code=400,
                content={"detail": "Invalid or duplicate Host header"},
            )
            await resp(scope, receive, send)
            return

        try:
            host_str = host_headers[0].decode("ascii").strip()
        except UnicodeDecodeError:
            resp = JSONResponse(status_code=400, content={"detail": "Malformed Host header"})
            await resp(scope, receive, send)
            return

        hostname_only = host_str.split(":")[0].lower()
        if (
            not hostname_only
            or any(c in host_str for c in ("\r", "\n", " ", "/", "\\", "@"))
            or (
                "*" not in self.settings.allowed_hosts
                and hostname_only not in [h.lower() for h in self.settings.allowed_hosts]
            )
        ):
            resp = JSONResponse(
                status_code=400,
                content={"detail": "Disallowed Host header"},
            )
            await resp(scope, receive, send)
            return

        path = str(scope.get("path", "/"))
        max_body = self._max_bytes_for_path(path)

        for k, v in raw_headers:
            if k.lower() == b"content-length":
                try:
                    declared_len = int(v.decode("ascii").strip())
                except ValueError:
                    resp = JSONResponse(
                        status_code=400, content={"detail": "Invalid Content-Length"}
                    )
                    await resp(scope, receive, send)
                    return
                if declared_len > max_body:
                    resp = JSONResponse(
                        status_code=413,
                        content={"detail": f"Request body exceeds limit of {max_body} bytes"},
                    )
                    await resp(scope, receive, send)
                    return

        bytes_received = 0
        read_timeout = float(self.settings.request_read_timeout_seconds)
        method = str(scope.get("method", "GET")).upper()

        if method in ("POST", "PUT", "PATCH"):
            body_chunks: list[bytes] = []
            more_body = True
            while more_body:
                try:
                    msg = await asyncio.wait_for(receive(), timeout=read_timeout)
                except TimeoutError:
                    resp = JSONResponse(
                        status_code=408,
                        content={"detail": "Request body read timed out"},
                    )
                    await resp(scope, receive, send)
                    return
                if msg["type"] == "http.disconnect":
                    return
                if msg["type"] == "http.request":
                    chunk = msg.get("body", b"")
                    bytes_received += len(chunk)
                    if bytes_received > max_body:
                        resp = JSONResponse(
                            status_code=413,
                            content={"detail": f"Request body exceeds limit of {max_body} bytes"},
                        )
                        await resp(scope, receive, send)
                        return
                    body_chunks.append(chunk)
                    more_body = bool(msg.get("more_body", False))
                else:
                    more_body = False

            full_body = b"".join(body_chunks)
            body_sent = False

            async def replay_receive() -> Message:
                nonlocal body_sent
                if not body_sent:
                    body_sent = True
                    return {
                        "type": "http.request",
                        "body": full_body,
                        "more_body": False,
                    }
                return await receive()

            await self.app(scope, replay_receive, send)
            return

        await self.app(scope, receive, send)


class SecurityAndObservabilityMiddleware(BaseHTTPMiddleware):
    """Enforces rate limits, CORS, security headers, request IDs, metrics, and storage recovery."""

    def __init__(
        self,
        app: ASGIApp,
        settings: Settings,
        rate_limiter: InMemoryRateLimiter,
    ) -> None:
        super().__init__(app)
        self.settings = settings
        self.rate_limiter = rate_limiter

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        incoming_req_id = request.headers.get("X-Request-ID", "")
        if incoming_req_id and SAFE_REQUEST_ID_RE.match(incoming_req_id):
            req_id = incoming_req_id
        else:
            req_id = f"req_{uuid.uuid4().hex[:16]}"

        token_req = request_id_var.set(req_id)
        token_usr = user_id_var.set(None)
        token_run = run_id_var.set(None)

        client_ip = resolve_client_ip(request, self.settings)
        proto = resolve_request_proto(request, self.settings)
        start_time = time.perf_counter()
        method = request.method.upper()
        path = request.url.path

        try:
            # Handle CORS preflight strictly against allowed_origins
            origin = request.headers.get("Origin")
            if method == "OPTIONS" and origin:
                if origin in self.settings.allowed_origins:
                    preflight = Response(status_code=204)
                    self._apply_cors_headers(preflight, origin)
                    self._apply_security_headers(preflight, req_id, proto)
                    return preflight
                return JSONResponse(
                    status_code=403,
                    content={"detail": "Origin not allowed by CORS policy"},
                )

            # Global rate limiter for API routes (skip health/metrics probes and static assets)
            if path.startswith("/api/") and not path.startswith("/api/health"):
                allowed, retry_after = self.rate_limiter.allow(client_ip)
                if not allowed:
                    resp = JSONResponse(
                        status_code=429,
                        content={"detail": "Rate limit exceeded"},
                        headers={"Retry-After": str(retry_after)},
                    )
                    self._apply_security_headers(resp, req_id, proto)
                    return resp

            try:
                response = await call_next(request)
            except BaseException as exc:
                if isinstance(exc, StorageFullError) or is_disk_full_exception(exc):
                    existing_reason = get_disk_degraded()
                    reason = existing_reason or (
                        f"Disk full during {method} {path}: {type(exc).__name__}: {exc}"
                    )
                    set_disk_degraded(reason)
                    logger.error("http_storage_full", path=path, method=method, reason=reason)
                    response = JSONResponse(
                        status_code=507,
                        content={
                            "detail": (
                                "Insufficient storage space on server; operation aborted safely."
                            )
                        },
                    )
                else:
                    logger.error(
                        "unhandled_exception",
                        path=path,
                        method=method,
                        error=scrub_string(str(exc)),
                    )
                    response = JSONResponse(
                        status_code=500,
                        content={"detail": "Internal server error"},
                    )

            if origin and origin in self.settings.allowed_origins:
                self._apply_cors_headers(response, origin)

            self._apply_security_headers(response, req_id, proto)

            duration = max(0.0, time.perf_counter() - start_time)
            route_label = self._normalize_route_label(path)
            HTTP_REQUESTS.labels(
                method=method,
                route=route_label,
                status=str(response.status_code),
            ).inc()
            HTTP_LATENCY.labels(method=method, route=route_label).observe(duration)

            logger.info(
                "http_access",
                method=method,
                path=path,
                status_code=response.status_code,
                duration_ms=round(duration * 1000.0, 2),
                client_ip=client_ip,
            )
            return response
        finally:
            request_id_var.reset(token_req)
            user_id_var.reset(token_usr)
            run_id_var.reset(token_run)

    @staticmethod
    def _normalize_route_label(path: str) -> str:
        parts = path.split("/")
        normalized: list[str] = []
        for p in parts:
            if p.startswith(("u_", "ses_", "tok_", "r_", "c_", "m_", "job_")) or (
                len(p) > 16 and any(ch.isdigit() for ch in p)
            ):
                normalized.append(":id")
            else:
                normalized.append(p)
        return "/".join(normalized) or "/"

    @staticmethod
    def _apply_cors_headers(response: Response, origin: str) -> None:
        response.headers["Access-Control-Allow-Origin"] = origin
        response.headers["Access-Control-Allow-Credentials"] = "true"
        response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, PATCH, DELETE, OPTIONS"
        response.headers["Access-Control-Allow-Headers"] = (
            "Authorization, Content-Type, X-CSRF-Token, X-Request-ID, "
            "Idempotency-Key, Last-Event-ID"
        )
        response.headers["Vary"] = "Origin"

    @staticmethod
    def _apply_security_headers(response: Response, req_id: str, proto: str) -> None:
        response.headers["X-Request-ID"] = req_id
        if "Content-Security-Policy" not in response.headers:
            response.headers["Content-Security-Policy"] = STRICT_CSP
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Permissions-Policy"] = (
            "camera=(), microphone=(), geolocation=(), payment=()"
        )
        response.headers["Cross-Origin-Opener-Policy"] = "same-origin"
        response.headers["Cross-Origin-Resource-Policy"] = "same-origin"
        if proto == "https":
            response.headers["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains"
        else:
            if "Strict-Transport-Security" in response.headers:
                del response.headers["Strict-Transport-Security"]
