"""Deterministic server-side parsers for tool-call JSON, Markdown code fences, and cron/RRULE."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from croniter import croniter
from dateutil.rrule import rrulestr


@dataclass(frozen=True)
class ToolCallParseResult:
    """Result of parsing a raw tool-call argument payload."""

    ok: bool
    args: dict[str, Any]
    raw: str
    error: str | None = None


def parse_tool_call_arguments(raw_args: str | dict[str, Any]) -> ToolCallParseResult:
    """Safely parse tool-call JSON arguments without throwing on malformed model output."""
    if isinstance(raw_args, dict):
        return ToolCallParseResult(
            ok=True,
            args=dict(raw_args),
            raw=json.dumps(raw_args, sort_keys=True),
            error=None,
        )

    raw_str = str(raw_args)
    stripped = raw_str.strip()
    if not stripped:
        return ToolCallParseResult(ok=True, args={}, raw=raw_str, error=None)

    try:
        parsed = json.loads(stripped)
        if isinstance(parsed, dict):
            return ToolCallParseResult(ok=True, args=parsed, raw=raw_str, error=None)
        return ToolCallParseResult(
            ok=False,
            args={"_non_object_value": parsed},
            raw=raw_str,
            error="Tool arguments must be a JSON object",
        )
    except json.JSONDecodeError as exc:
        return ToolCallParseResult(
            ok=False,
            args={},
            raw=raw_str,
            error=f"Malformed tool-call JSON at pos {exc.pos}: {exc.msg}",
        )


@dataclass(frozen=True)
class MarkdownSegment:
    """A contiguous segment of Markdown text (either prose or a fenced code block)."""

    kind: str  # "prose" | "code"
    raw: str
    language: str = ""
    closed: bool = True


_FENCE_OPEN_RE = re.compile(r"^ {0,3}(`{3,}|~{3,})([^\n`]*)$")


def split_markdown_fences(markdown_text: str) -> list[MarkdownSegment]:
    """Losslessly split Markdown text into prose and fenced code block segments.

    Handles arbitrary backtick/tilde fence lengths (CommonMark spec) and unclosed
    trailing fences during live streaming. Invariant:
        "".join(seg.raw for seg in split_markdown_fences(s)) == s
    """
    if not markdown_text:
        return []

    lines = markdown_text.splitlines(keepends=True)
    segments: list[MarkdownSegment] = []
    prose_buf: list[str] = []
    code_buf: list[str] = []
    in_fence = False
    fence_char = ""
    fence_len = 0
    fence_lang = ""

    for line in lines:
        stripped_line = line.rstrip("\r\n")
        if not in_fence:
            match = _FENCE_OPEN_RE.match(stripped_line)
            if match:
                if prose_buf:
                    segments.append(
                        MarkdownSegment(kind="prose", raw="".join(prose_buf), closed=True)
                    )
                    prose_buf = []
                in_fence = True
                marker = match.group(1)
                fence_char = marker[0]
                fence_len = len(marker)
                fence_lang = match.group(2).strip()
                code_buf = [line]
            else:
                prose_buf.append(line)
        else:
            code_buf.append(line)
            close_candidate = stripped_line.lstrip(" ")
            leading_spaces = len(stripped_line) - len(close_candidate)
            if (
                leading_spaces <= 3
                and close_candidate.rstrip(" ")
                and all(ch == fence_char for ch in close_candidate.rstrip(" "))
                and len(close_candidate.rstrip(" ")) >= fence_len
            ):
                segments.append(
                    MarkdownSegment(
                        kind="code",
                        raw="".join(code_buf),
                        language=fence_lang,
                        closed=True,
                    )
                )
                code_buf = []
                in_fence = False
                fence_char = ""
                fence_len = 0
                fence_lang = ""

    if in_fence and code_buf:
        segments.append(
            MarkdownSegment(
                kind="code",
                raw="".join(code_buf),
                language=fence_lang,
                closed=False,
            )
        )
    elif prose_buf:
        segments.append(MarkdownSegment(kind="prose", raw="".join(prose_buf), closed=True))

    return segments


def validate_and_preview_cron(
    expr: str,
    *,
    base_time: datetime | None = None,
    count: int = 5,
) -> list[datetime]:
    """Validate a 5-field cron expression and return the next `count` UTC run times."""
    cleaned = " ".join(expr.strip().split())
    parts = cleaned.split(" ")
    if len(parts) != 5:
        raise ValueError(f"Cron expression must have exactly 5 fields, got {len(parts)}: {expr!r}")
    if not croniter.is_valid(cleaned):
        raise ValueError(f"Invalid cron expression: {expr!r}")
    start = (base_time or datetime.now(UTC)).astimezone(UTC)
    it = croniter(cleaned, start)
    results: list[datetime] = []
    for _ in range(max(1, count)):
        nxt = it.get_next(datetime)
        if nxt.tzinfo is None:
            nxt = nxt.replace(tzinfo=UTC)
        results.append(nxt)
    return results


def validate_and_preview_rrule(
    rrule_str: str,
    *,
    dtstart: datetime | None = None,
    count: int = 5,
) -> list[datetime]:
    """Validate an iCalendar RRULE string and return the first `count` occurrences."""
    cleaned = rrule_str.strip()
    if not cleaned:
        raise ValueError("RRULE string cannot be empty")
    start = (dtstart or datetime(2026, 10, 3, 9, 0, tzinfo=UTC)).astimezone(UTC)
    rule = rrulestr(cleaned, dtstart=start)
    occurrences: list[datetime] = []
    for occ in rule:
        if occ.tzinfo is None:
            occ = occ.replace(tzinfo=UTC)
        occurrences.append(occ)
        if len(occurrences) >= max(1, count):
            break
    return occurrences
