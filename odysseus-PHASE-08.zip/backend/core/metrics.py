"""Prometheus metrics definitions and instrumentation helpers."""

from __future__ import annotations

from prometheus_client import CollectorRegistry, Counter, Gauge, Histogram, generate_latest

METRICS_REGISTRY = CollectorRegistry(auto_describe=True)

HTTP_REQUESTS = Counter(
    "http_requests",
    "Total HTTP requests processed by Odysseus",
    labelnames=("method", "route", "status"),
    registry=METRICS_REGISTRY,
)

HTTP_LATENCY = Histogram(
    "http_latency",
    "HTTP request latency in seconds",
    labelnames=("method", "route"),
    buckets=(0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0),
    registry=METRICS_REGISTRY,
)

DB_POOL = Gauge(
    "db_pool",
    "Database connection pool metrics",
    labelnames=("state",),
    registry=METRICS_REGISTRY,
)

SSE_CLIENTS = Gauge(
    "sse_clients",
    "Currently connected SSE streaming clients",
    registry=METRICS_REGISTRY,
)

RUNS_ACTIVE = Gauge(
    "runs_active",
    "Currently active agent runs by status",
    labelnames=("status",),
    registry=METRICS_REGISTRY,
)

EVENTS_APPENDED = Counter(
    "events_appended",
    "Total durable run events appended",
    labelnames=("event_type",),
    registry=METRICS_REGISTRY,
)

PROVIDER_LATENCY = Histogram(
    "provider_latency",
    "LLM provider call latency in seconds",
    labelnames=("provider", "model"),
    buckets=(0.01, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 15.0, 30.0),
    registry=METRICS_REGISTRY,
)

PROVIDER_ERRORS = Counter(
    "provider_errors",
    "Total LLM provider errors by provider and code",
    labelnames=("provider", "code"),
    registry=METRICS_REGISTRY,
)

# Initialize baseline label series so /metrics always exposes every mandated family
DB_POOL.labels(state="checked_in").set(0)
DB_POOL.labels(state="checked_out").set(0)
SSE_CLIENTS.set(0)
RUNS_ACTIVE.labels(status="running").set(0)
EVENTS_APPENDED.labels(event_type="run.started").inc(0)
PROVIDER_LATENCY.labels(provider="fake", model="default").observe(0.0)
PROVIDER_ERRORS.labels(provider="fake", code="none").inc(0)


def render_prometheus_metrics() -> tuple[bytes, str]:
    """Render Prometheus exposition format payload and content type."""
    payload = generate_latest(METRICS_REGISTRY)
    return payload, "text/plain; version=0.0.4; charset=utf-8"
