"""Tamper-evident append-only audit log with SHA-256 hash chaining."""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import sys
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.logging import scrub_value
from backend.core.models import AuditLog

GENESIS_HASH = "0" * 64


class AuditChainTamperedError(RuntimeError):
    """Raised when audit log verification detects an altered or missing record."""

    def __init__(self, record_id: int, reason: str) -> None:
        self.record_id = record_id
        self.reason = reason
        super().__init__(f"Audit log integrity violation at id={record_id}: {reason}")


def compute_audit_record_hash(
    *,
    timestamp: str,
    actor_user_id: str | None,
    actor_ip: str | None,
    action: str,
    resource_type: str,
    resource_id: str | None,
    details_json: dict[str, Any],
    prev_hash: str,
) -> str:
    """Compute canonical SHA-256 hash for an audit log entry."""
    canonical_payload = {
        "action": action,
        "actor_ip": actor_ip,
        "actor_user_id": actor_user_id,
        "details": details_json,
        "prev_hash": prev_hash,
        "resource_id": resource_id,
        "resource_type": resource_type,
        "timestamp": timestamp,
    }
    serialized = json.dumps(canonical_payload, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()


async def append_audit_event(
    session: AsyncSession,
    *,
    action: str,
    resource_type: str,
    actor_user_id: str | None = None,
    actor_ip: str | None = None,
    resource_id: str | None = None,
    details: dict[str, Any] | None = None,
    timestamp: str | None = None,
) -> AuditLog:
    """Append a new hash-chained record to the audit log within the given transaction."""
    stmt = select(AuditLog).order_by(AuditLog.id.desc()).limit(1)
    last_row = (await session.execute(stmt)).scalar_one_or_none()
    prev_hash = last_row.record_hash if last_row is not None else GENESIS_HASH

    ts_str = timestamp or datetime.now(UTC).isoformat()
    sanitized_details = scrub_value(None, details or {})
    if not isinstance(sanitized_details, dict):
        sanitized_details = {"value": sanitized_details}

    record_hash = compute_audit_record_hash(
        timestamp=ts_str,
        actor_user_id=actor_user_id,
        actor_ip=actor_ip,
        action=action,
        resource_type=resource_type,
        resource_id=resource_id,
        details_json=sanitized_details,
        prev_hash=prev_hash,
    )

    entry = AuditLog(
        timestamp=ts_str,
        actor_user_id=actor_user_id,
        actor_ip=actor_ip,
        action=action,
        resource_type=resource_type,
        resource_id=resource_id,
        details_json=sanitized_details,
        prev_hash=prev_hash,
        record_hash=record_hash,
    )
    session.add(entry)
    await session.flush()
    return entry


async def verify_audit_chain(session: AsyncSession) -> tuple[bool, int]:
    """Verify the entire audit log hash chain from genesis.

    Returns (True, verified_count) or raises AuditChainTamperedError on any tampering.
    """
    stmt = select(AuditLog).order_by(AuditLog.id.asc())
    rows = list((await session.execute(stmt)).scalars().all())
    expected_prev_hash = GENESIS_HASH
    expected_id = 1

    for row in rows:
        if row.id != expected_id:
            raise AuditChainTamperedError(
                row.id,
                f"Gap in audit log sequence: expected id={expected_id}, found id={row.id}",
            )
        if row.prev_hash != expected_prev_hash:
            raise AuditChainTamperedError(
                row.id,
                f"Broken prev_hash link: expected {expected_prev_hash}, found {row.prev_hash}",
            )
        recomputed = compute_audit_record_hash(
            timestamp=row.timestamp,
            actor_user_id=row.actor_user_id,
            actor_ip=row.actor_ip,
            action=row.action,
            resource_type=row.resource_type,
            resource_id=row.resource_id,
            details_json=row.details_json,
            prev_hash=row.prev_hash,
        )
        if recomputed != row.record_hash:
            raise AuditChainTamperedError(
                row.id,
                f"Record hash mismatch: expected {recomputed}, stored {row.record_hash}",
            )
        expected_prev_hash = row.record_hash
        expected_id = row.id + 1

    return True, len(rows)


async def _cli_verify(database_url: str | None) -> int:
    from backend.core.db import DatabaseManager
    from backend.core.settings import load_settings

    overrides: dict[str, Any] = {}
    if database_url:
        overrides["database_url"] = database_url
    settings = load_settings(overrides=overrides)
    db = DatabaseManager(settings)
    try:
        async with db.session() as sess:
            _, count = await verify_audit_chain(sess)
            print(f"OK: verified {count} audit log record(s).")
            return 0
    except AuditChainTamperedError as exc:
        print(f"TAMPER DETECTED: {exc}", file=sys.stderr)
        return 2
    finally:
        await db.dispose()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Odysseus Audit Log Integrity Verifier")
    sub = parser.add_subparsers(dest="command", required=True)
    verify_p = sub.add_parser("verify", help="Verify audit log hash chain")
    verify_p.add_argument("--database-url", default=None, help="Database URL override")
    args = parser.parse_args(argv)
    if args.command == "verify":
        return asyncio.run(_cli_verify(args.database_url))
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
