"""Authorization policy registry, Principal resolution, CSRF check, and require() dependency."""

from __future__ import annotations

from collections.abc import Callable, Coroutine, Iterator
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any, Literal

from fastapi import FastAPI, HTTPException, Request, status
from fastapi.routing import APIRoute
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.auth import (
    constant_time_equals,
    is_session_valid,
    sha256_hex,
)
from backend.core.db import DatabaseManager
from backend.core.logging import user_id_var
from backend.core.models import ApiToken, SessionRecord, User
from backend.core.settings import Settings
from backend.core.uow import UnitOfWork, _ensure_utc

UNSAFE_HTTP_METHODS: frozenset[str] = frozenset({"POST", "PUT", "PATCH", "DELETE"})

PolicyLevel = Literal[
    "public",
    "authenticated",
    "chat",
    "agent",
    "shell",
    "files",
    "email",
    "calendar",
    "research",
    "cookbook",
    "admin",
]


@dataclass(frozen=True)
class RoutePolicy:
    """Explicit security policy registered for an HTTP route."""

    method: str
    path: str
    level: PolicyLevel
    allow_mfa_pending: bool = False
    allow_must_change_password: bool = False


# Global registry of (METHOD, path) -> RoutePolicy inspected by route-policy test
ROUTE_POLICIES: dict[tuple[str, str], RoutePolicy] = {}


def register_route_policy(
    method: str,
    path: str,
    level: PolicyLevel,
    *,
    allow_mfa_pending: bool = False,
    allow_must_change_password: bool = False,
) -> RoutePolicy:
    """Register an explicit authorization policy for a route."""
    key = (method.upper(), path)
    policy = RoutePolicy(
        method=method.upper(),
        path=path,
        level=level,
        allow_mfa_pending=allow_mfa_pending,
        allow_must_change_password=allow_must_change_password,
    )
    ROUTE_POLICIES[key] = policy
    return policy


def iter_api_routes(app: FastAPI) -> Iterator[APIRoute]:
    """Yield every APIRoute registered on the FastAPI application or its included routers."""
    for r in app.routes:
        if isinstance(r, APIRoute):
            yield r
        else:
            orig_router = getattr(r, "original_router", None)
            if orig_router is not None:
                for sub in getattr(orig_router, "routes", ()):
                    if isinstance(sub, APIRoute):
                        yield sub


@dataclass
class Principal:
    """Resolved authenticated caller for a request."""

    user: User
    privileges: frozenset[str]
    auth_method: Literal["session", "bearer"]
    session_record: SessionRecord | None = None
    api_token: ApiToken | None = None


async def authenticate_request(
    request: Request,
    *,
    allow_mfa_pending: bool = False,
    allow_must_change_password: bool = False,
) -> Principal:
    """Resolve Principal from Authorization Bearer token or session cookie."""
    app_state = request.app.state
    settings: Settings = app_state.settings
    db: DatabaseManager = app_state.db

    auth_header = request.headers.get("Authorization", "").strip()
    cookie_token = request.cookies.get(settings.session_cookie_name)

    if auth_header.lower().startswith("bearer "):
        raw_bearer = auth_header[7:].strip()
        if not raw_bearer:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Empty bearer token",
            )
        return await _authenticate_bearer(
            db,
            raw_bearer,
            allow_must_change_password=allow_must_change_password,
        )

    if cookie_token:
        return await _authenticate_cookie(
            request,
            db,
            settings,
            cookie_token,
            allow_mfa_pending=allow_mfa_pending,
            allow_must_change_password=allow_must_change_password,
        )

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Authentication required",
    )


async def _authenticate_bearer(
    db: DatabaseManager,
    raw_token: str,
    *,
    allow_must_change_password: bool,
) -> Principal:
    token_hash = sha256_hex(raw_token)
    now = datetime.now(UTC)

    async def _op(sess: AsyncSession) -> Principal:
        uow = UnitOfWork(sess)
        tok = await uow.api_tokens.get_by_hash(token_hash)
        if tok is None or tok.revoked_at is not None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid or revoked API token",
            )
        if tok.expires_at is not None and now >= _ensure_utc(tok.expires_at):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="API token has expired",
            )
        user = await uow.users.get_by_id(tok.user_id)
        if user is None or not user.is_active:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="User account is inactive",
            )
        if user.must_change_password and not allow_must_change_password:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Password change required before using API resources",
            )
        tok.last_used_at = now
        user_privs = {p.privilege for p in user.privileges}
        effective_privs = frozenset(user_privs.intersection(tok.scopes))
        user_id_var.set(user.id)
        return Principal(
            user=user,
            privileges=effective_privs,
            auth_method="bearer",
            api_token=tok,
        )

    return await db.execute_write(_op)


async def _authenticate_cookie(
    request: Request,
    db: DatabaseManager,
    settings: Settings,
    cookie_token: str,
    *,
    allow_mfa_pending: bool,
    allow_must_change_password: bool,
) -> Principal:
    token_hash = sha256_hex(cookie_token)
    now = datetime.now(UTC)

    async def _op(sess: AsyncSession) -> Principal:
        uow = UnitOfWork(sess)
        record = await uow.sessions.get_by_token_hash(token_hash)
        if record is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid session",
            )
        valid, reason = is_session_valid(record, settings, now=now)
        if not valid:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail=f"Session invalid: {reason}",
            )

        # Enforce CSRF double-submit on unsafe methods for cookie-authenticated sessions
        if request.method.upper() in UNSAFE_HTTP_METHODS:
            header_csrf = request.headers.get("X-CSRF-Token", "")
            if not header_csrf or not constant_time_equals(header_csrf, record.csrf_token):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="CSRF token missing or invalid",
                )

        if record.mfa_pending and not allow_mfa_pending:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Two-factor authentication verification required",
            )

        user = await uow.users.get_by_id(record.user_id)
        if user is None or not user.is_active:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="User account is inactive",
            )

        if user.must_change_password and not allow_must_change_password:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Password change required before accessing this resource",
            )

        record.last_active_at = now
        user_privs = frozenset(p.privilege for p in user.privileges)
        user_id_var.set(user.id)
        return Principal(
            user=user,
            privileges=user_privs,
            auth_method="session",
            session_record=record,
        )

    return await db.execute_write(_op)


def require(
    privilege: PolicyLevel = "authenticated",
    *,
    allow_mfa_pending: bool = False,
    allow_must_change_password: bool = False,
) -> Callable[[Request], Coroutine[Any, Any, Principal]]:
    """FastAPI dependency enforcing authentication, CSRF, and capability privilege."""

    async def _dependency(request: Request) -> Principal:
        principal = await authenticate_request(
            request,
            allow_mfa_pending=allow_mfa_pending,
            allow_must_change_password=allow_must_change_password,
        )
        if privilege not in ("public", "authenticated"):
            if privilege not in principal.privileges and "admin" not in principal.privileges:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"Missing required privilege: {privilege}",
                )
            # For scoped API tokens, even an admin user's token must explicitly include the scope
            if principal.auth_method == "bearer" and privilege not in principal.privileges:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"API token lacks required scope: {privilege}",
                )
        return principal

    return _dependency
