"""Envelope encryption for secrets at rest (AES-256-GCM + Master Key / KMS hook)."""

from __future__ import annotations

import base64
import hashlib
import json
import os
import secrets
from collections.abc import Callable
from pathlib import Path
from typing import Any

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

ENVELOPE_VERSION = 1


class EnvelopeVault:
    """Envelope encryption service using AES-256-GCM.

    A 256-bit Master Key (KEK) stored in `data/master.key` with 0600 permissions
    (or provided via an external KMS hook) wraps a unique per-secret 256-bit
    Data Encryption Key (DEK). The DEK encrypts the plaintext payload.
    """

    def __init__(
        self,
        data_dir: Path,
        *,
        master_key_override: str | None = None,
        kms_wrap_hook: Callable[[bytes], bytes] | None = None,
        kms_unwrap_hook: Callable[[bytes], bytes] | None = None,
    ) -> None:
        self._data_dir = data_dir
        self._key_path = data_dir / "master.key"
        self._kms_wrap_hook = kms_wrap_hook
        self._kms_unwrap_hook = kms_unwrap_hook
        self._kek = self._load_or_create_kek(master_key_override)
        self._previous_keks: list[bytes] = []

    def _load_or_create_kek(self, override: str | None) -> bytes:
        if override:
            return hashlib.sha256(override.encode("utf-8")).digest()
        self._data_dir.mkdir(parents=True, exist_ok=True)
        if self._key_path.exists():
            raw = self._key_path.read_bytes().strip()
            os.chmod(self._key_path, 0o600)
            decoded = base64.urlsafe_b64decode(raw)
            if len(decoded) != 32:
                raise ValueError("Corrupted master.key: expected 32 bytes after base64 decode")
            return decoded

        new_kek = secrets.token_bytes(32)
        encoded = base64.urlsafe_b64encode(new_kek)
        fd = os.open(
            str(self._key_path),
            os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
            0o600,
        )
        try:
            os.write(fd, encoded)
        finally:
            os.close(fd)
        os.chmod(self._key_path, 0o600)
        return new_kek

    def encrypt(self, plaintext: str, *, associated_data: str = "odysseus-secret") -> str:
        """Encrypt a secret string into a versioned envelope token."""
        dek = secrets.token_bytes(32)
        dek_nonce = secrets.token_bytes(12)
        data_nonce = secrets.token_bytes(12)
        aad = associated_data.encode("utf-8")

        data_cipher = AESGCM(dek).encrypt(data_nonce, plaintext.encode("utf-8"), aad)
        if self._kms_wrap_hook is not None:
            wrapped_dek = self._kms_wrap_hook(dek)
        else:
            wrapped_dek = AESGCM(self._kek).encrypt(dek_nonce, dek, aad)

        envelope: dict[str, Any] = {
            "v": ENVELOPE_VERSION,
            "alg": "AES-256-GCM",
            "dn": base64.urlsafe_b64encode(dek_nonce).decode("ascii"),
            "wd": base64.urlsafe_b64encode(wrapped_dek).decode("ascii"),
            "cn": base64.urlsafe_b64encode(data_nonce).decode("ascii"),
            "ct": base64.urlsafe_b64encode(data_cipher).decode("ascii"),
        }
        serialized = json.dumps(envelope, separators=(",", ":"), sort_keys=True).encode("utf-8")
        return base64.urlsafe_b64encode(serialized).decode("ascii")

    def decrypt(self, token: str, *, associated_data: str = "odysseus-secret") -> str:
        """Decrypt a versioned envelope token back into plaintext."""
        raw_json = base64.urlsafe_b64decode(token.encode("ascii"))
        envelope = json.loads(raw_json.decode("utf-8"))
        if envelope.get("v") != ENVELOPE_VERSION:
            raise ValueError(f"Unsupported envelope version: {envelope.get('v')}")

        dek_nonce = base64.urlsafe_b64decode(envelope["dn"])
        wrapped_dek = base64.urlsafe_b64decode(envelope["wd"])
        data_nonce = base64.urlsafe_b64decode(envelope["cn"])
        ciphertext = base64.urlsafe_b64decode(envelope["ct"])
        aad = associated_data.encode("utf-8")

        if self._kms_unwrap_hook is not None:
            dek = self._kms_unwrap_hook(wrapped_dek)
        else:
            dek = self._unwrap_dek_with_keyring(dek_nonce, wrapped_dek, aad)

        plaintext_bytes = AESGCM(dek).decrypt(data_nonce, ciphertext, aad)
        return plaintext_bytes.decode("utf-8")

    def _unwrap_dek_with_keyring(self, dek_nonce: bytes, wrapped_dek: bytes, aad: bytes) -> bytes:
        last_err: Exception | None = None
        for candidate_kek in [self._kek, *self._previous_keks]:
            try:
                return AESGCM(candidate_kek).decrypt(dek_nonce, wrapped_dek, aad)
            except Exception as exc:
                last_err = exc
        raise ValueError("Failed to unwrap DEK with current or previous master keys") from last_err

    def rotate_master_key(self, new_kek_bytes: bytes | None = None) -> None:
        """Rotate the master KEK in memory and on disk while preserving old KEK for re-wrapping."""
        self._previous_keks.insert(0, self._kek)
        self._kek = new_kek_bytes if new_kek_bytes is not None else secrets.token_bytes(32)
        if self._key_path.exists():
            encoded = base64.urlsafe_b64encode(self._kek)
            self._key_path.write_bytes(encoded)
            os.chmod(self._key_path, 0o600)

    def rewrap_token(self, token: str, *, associated_data: str = "odysseus-secret") -> str:
        """Re-encrypt an existing envelope token under the current master KEK."""
        plaintext = self.decrypt(token, associated_data=associated_data)
        return self.encrypt(plaintext, associated_data=associated_data)
