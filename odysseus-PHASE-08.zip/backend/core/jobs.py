"""Durable background job supervisor with leases, heartbeats, retries, and crash recovery."""

from __future__ import annotations

import asyncio
import contextlib
import os
import uuid
from collections.abc import Awaitable, Callable
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from sqlalchemy import or_, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.db import DatabaseManager
from backend.core.logging import get_logger
from backend.core.metrics import EVENTS_APPENDED, RUNS_ACTIVE
from backend.core.models import JobRecord, RunRecord
from backend.core.settings import Settings
from backend.core.uow import UnitOfWork

logger = get_logger("odysseus.jobs")

JobHandler = Callable[[JobRecord, dict[str, Any]], Awaitable[dict[str, Any] | None]]


def _append_text_file(path: Path, line: str) -> None:
    with path.open("a", encoding="utf-8") as fh:
        fh.write(line)


class JobSupervisor:
    """In-process worker pool backed by durable `jobs` rows with atomic leases."""

    def __init__(self, db: DatabaseManager, settings: Settings) -> None:
        self.db = db
        self.settings = settings
        self.supervisor_id = f"sup_{os.getpid()}_{uuid.uuid4().hex[:8]}"
        self._handlers: dict[str, JobHandler] = {}
        self._workers: list[asyncio.Task[None]] = []
        self._stop_event = asyncio.Event()
        self._active_job_ids: set[str] = set()
        self.register_handler("noop", self._noop_handler)
        self.register_handler("sleep_job", self._sleep_job_handler)

    @staticmethod
    async def _noop_handler(_job: JobRecord, payload: dict[str, Any]) -> dict[str, Any]:
        return {"ok": True, "echo": payload}

    @staticmethod
    async def _sleep_job_handler(_job: JobRecord, payload: dict[str, Any]) -> dict[str, Any]:
        duration = float(payload.get("sleep_seconds", 0.05))
        marker_file = payload.get("marker_file")
        await asyncio.sleep(duration)
        if isinstance(marker_file, str) and marker_file:
            line = f"completed:{_job.id}:attempt={_job.attempts}\n"
            await asyncio.to_thread(_append_text_file, Path(marker_file), line)
        return {"completed": True, "attempts": _job.attempts}

    def register_handler(self, kind: str, handler: JobHandler) -> None:
        """Register an async job handler for a given job kind."""
        self._handlers[kind] = handler

    async def enqueue(
        self,
        kind: str,
        payload: dict[str, Any],
        *,
        max_attempts: int | None = None,
        delay_seconds: float = 0.0,
        job_id: str | None = None,
    ) -> JobRecord:
        """Persist a new queued job in the database."""
        now = datetime.now(UTC)
        jid = job_id or f"job_{uuid.uuid4().hex[:16]}"
        max_att = max_attempts if max_attempts is not None else self.settings.job_max_attempts

        async def _op(sess: AsyncSession) -> JobRecord:
            record = JobRecord(
                id=jid,
                kind=kind,
                payload_json=payload,
                status="queued",
                lease_owner=None,
                leased_until=None,
                heartbeat_at=None,
                attempts=0,
                max_attempts=max_att,
                next_run_at=now + timedelta(seconds=delay_seconds),
                last_error=None,
                result_json=None,
                created_at=now,
                updated_at=now,
            )
            sess.add(record)
            await sess.flush()
            return record

        return await self.db.execute_write(_op)

    async def recover_interrupted_work(
        self, *, reclaim_expired_only: bool = True
    ) -> dict[str, int]:
        """Mark in-flight runs as `interrupted` and reclaim orphaned job leases."""
        now = datetime.now(UTC)

        async def _op(sess: AsyncSession) -> dict[str, int]:
            uow = UnitOfWork(sess)
            # 1. Mark any runs left in `running` or `waiting_approval` state as `interrupted`
            stmt_runs = select(RunRecord).where(
                RunRecord.status.in_(["running", "waiting_approval"])
            )
            in_flight_runs = list((await sess.execute(stmt_runs)).scalars().all())
            for run in in_flight_runs:
                run.status = "interrupted"
                run.finished_at = now
                ev_rows = await uow.chats.list_run_events(run.id, after_seq=0)
                partial_chunks: list[str] = []
                for ev in ev_rows:
                    if ev.type == "message.text.delta" and isinstance(
                        ev.data_json.get("text"), str
                    ):
                        partial_chunks.append(ev.data_json["text"])
                partial_txt = "".join(partial_chunks)
                cp = dict(run.checkpoint_json or {})
                cp["emitted_text"] = partial_txt
                cp["emitted_chars"] = len(partial_txt)
                run.checkpoint_json = cp
                msg_rec = await uow.chats.get_message(run.message_id)
                if msg_rec is not None:
                    msg_rec.plain_text = partial_txt
                    msg_rec.status = "interrupted"
                    if partial_txt:
                        msg_rec.parts_json = [{"type": "text", "text": partial_txt}]
                await uow.chats.append_run_event(
                    run_id=run.id,
                    event_type="run.status",
                    data={"status": "interrupted"},
                    ts=now.isoformat(),
                )
                EVENTS_APPENDED.labels(event_type="run.status").inc()

            # 2. Reclaim leased jobs whose lease has expired (or all leases on full restart)
            if reclaim_expired_only:
                stmt_jobs = select(JobRecord).where(
                    JobRecord.status == "leased",
                    JobRecord.leased_until <= now,
                )
            else:
                stmt_jobs = select(JobRecord).where(JobRecord.status == "leased")
            orphaned_jobs = list((await sess.execute(stmt_jobs)).scalars().all())
            reclaimed_count = 0
            dead_letter_count = 0
            for job in orphaned_jobs:
                if job.attempts >= job.max_attempts:
                    job.status = "dead_letter"
                    job.last_error = "Exceeded max_attempts after worker crash/lease expiry"
                    job.lease_owner = None
                    job.leased_until = None
                    job.updated_at = now
                    dead_letter_count += 1
                else:
                    job.status = "queued"
                    job.lease_owner = None
                    job.leased_until = None
                    job.next_run_at = now
                    job.updated_at = now
                    reclaimed_count += 1

            return {
                "interrupted_runs": len(in_flight_runs),
                "reclaimed_jobs": reclaimed_count,
                "dead_letter_jobs": dead_letter_count,
            }

        summary = await self.db.execute_write(_op)
        if summary["interrupted_runs"] or summary["reclaimed_jobs"]:
            logger.info("recovered_interrupted_work", **summary)
        return summary

    async def acquire_next_lease(self, worker_id: str) -> JobRecord | None:
        """Atomically acquire a lease on the next eligible queued or lease-expired job."""
        now = datetime.now(UTC)
        lease_until = now + timedelta(seconds=self.settings.job_lease_seconds)

        async def _op(sess: AsyncSession) -> JobRecord | None:
            candidate_stmt = (
                select(JobRecord)
                .where(
                    or_(
                        (JobRecord.status == "queued") & (JobRecord.next_run_at <= now),
                        (JobRecord.status == "leased") & (JobRecord.leased_until <= now),
                    )
                )
                .order_by(JobRecord.next_run_at.asc(), JobRecord.created_at.asc())
                .limit(1)
            )
            candidate = (await sess.execute(candidate_stmt)).scalar_one_or_none()
            if candidate is None:
                return None

            if candidate.attempts >= candidate.max_attempts:
                candidate.status = "dead_letter"
                candidate.last_error = "Max attempts reached"
                candidate.lease_owner = None
                candidate.leased_until = None
                candidate.updated_at = now
                await sess.flush()
                return None

            # Atomic conditional UPDATE prevents two workers from leasing the same job
            claim_stmt = (
                update(JobRecord)
                .where(
                    JobRecord.id == candidate.id,
                    JobRecord.attempts == candidate.attempts,
                    or_(
                        JobRecord.status == "queued",
                        (JobRecord.status == "leased") & (JobRecord.leased_until <= now),
                    ),
                )
                .values(
                    status="leased",
                    lease_owner=worker_id,
                    leased_until=lease_until,
                    heartbeat_at=now,
                    attempts=candidate.attempts + 1,
                    updated_at=now,
                )
            )
            res = await sess.execute(claim_stmt)
            rowcount = int(getattr(res, "rowcount", 0) or 0)
            if rowcount != 1:
                return None

            refreshed = (
                await sess.execute(select(JobRecord).where(JobRecord.id == candidate.id))
            ).scalar_one()
            return refreshed

        return await self.db.execute_write(_op)

    async def heartbeat(self, job_id: str, worker_id: str) -> bool:
        """Extend the lease for an active job owned by worker_id."""
        now = datetime.now(UTC)
        lease_until = now + timedelta(seconds=self.settings.job_lease_seconds)

        async def _op(sess: AsyncSession) -> bool:
            stmt = (
                update(JobRecord)
                .where(
                    JobRecord.id == job_id,
                    JobRecord.status == "leased",
                    JobRecord.lease_owner == worker_id,
                )
                .values(
                    leased_until=lease_until,
                    heartbeat_at=now,
                    updated_at=now,
                )
            )
            res = await sess.execute(stmt)
            return int(getattr(res, "rowcount", 0) or 0) == 1

        return await self.db.execute_write(_op)

    async def complete_job(
        self,
        job_id: str,
        worker_id: str,
        result: dict[str, Any] | None = None,
    ) -> bool:
        """Mark a leased job as completed if still owned by worker_id."""
        now = datetime.now(UTC)

        async def _op(sess: AsyncSession) -> bool:
            stmt = (
                update(JobRecord)
                .where(
                    JobRecord.id == job_id,
                    JobRecord.status == "leased",
                    JobRecord.lease_owner == worker_id,
                )
                .values(
                    status="completed",
                    lease_owner=None,
                    leased_until=None,
                    result_json=result or {"ok": True},
                    updated_at=now,
                )
            )
            res = await sess.execute(stmt)
            return int(getattr(res, "rowcount", 0) or 0) == 1

        return await self.db.execute_write(_op)

    async def fail_job(self, job_id: str, worker_id: str, error_msg: str) -> str:
        """Record a job failure and schedule retry with backoff or move to dead_letter."""
        now = datetime.now(UTC)

        async def _op(sess: AsyncSession) -> str:
            job = (
                await sess.execute(select(JobRecord).where(JobRecord.id == job_id))
            ).scalar_one_or_none()
            if job is None or job.lease_owner != worker_id:
                return "lost_lease"
            if job.attempts >= job.max_attempts:
                job.status = "dead_letter"
                job.lease_owner = None
                job.leased_until = None
                job.last_error = error_msg[:2000]
                job.updated_at = now
                return "dead_letter"
            backoff_seconds = min(60.0, 0.5 * (2 ** max(0, job.attempts - 1)))
            job.status = "queued"
            job.lease_owner = None
            job.leased_until = None
            job.last_error = error_msg[:2000]
            job.next_run_at = now + timedelta(seconds=backoff_seconds)
            job.updated_at = now
            return "queued"

        return await self.db.execute_write(_op)

    async def execute_one(self, worker_id: str) -> JobRecord | None:
        """Acquire and execute a single eligible job if available."""
        job = await self.acquire_next_lease(worker_id)
        if job is None:
            return None

        self._active_job_ids.add(job.id)
        hb_stop = asyncio.Event()

        async def _hb_loop() -> None:
            interval = max(0.1, float(self.settings.job_heartbeat_seconds))
            while not hb_stop.is_set():
                with contextlib.suppress(TimeoutError):
                    await asyncio.wait_for(hb_stop.wait(), timeout=interval)
                if hb_stop.is_set():
                    break
                with contextlib.suppress(Exception):
                    await self.heartbeat(job.id, worker_id)

        hb_task = asyncio.create_task(_hb_loop())
        try:
            handler = self._handlers.get(job.kind)
            if handler is None:
                raise RuntimeError(f"No job handler registered for kind={job.kind!r}")
            result = await handler(job, dict(job.payload_json))
            await self.complete_job(job.id, worker_id, result)
        except Exception as exc:
            logger.warning("job_execution_failed", job_id=job.id, kind=job.kind, error=str(exc))
            await self.fail_job(job.id, worker_id, str(exc))
        finally:
            hb_stop.set()
            hb_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await hb_task
            self._active_job_ids.discard(job.id)

        async with self.db.session() as sess:
            return (
                await sess.execute(select(JobRecord).where(JobRecord.id == job.id))
            ).scalar_one_or_none()

    async def start(self) -> None:
        """Recover interrupted work and start background worker loops."""
        self._stop_event.clear()
        await self.recover_interrupted_work(reclaim_expired_only=False)
        for idx in range(self.settings.job_worker_concurrency):
            worker_id = f"{self.supervisor_id}_w{idx}"
            task = asyncio.create_task(self._worker_loop(worker_id))
            self._workers.append(task)

    async def _worker_loop(self, worker_id: str) -> None:
        while not self._stop_event.is_set():
            try:
                executed = await self.execute_one(worker_id)
                if executed is None:
                    with contextlib.suppress(TimeoutError):
                        await asyncio.wait_for(self._stop_event.wait(), timeout=0.15)
            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.warning("job_worker_loop_error", worker_id=worker_id, error=str(exc))
                await asyncio.sleep(0.25)

    async def stop(self) -> None:
        """Gracefully stop workers and mark any in-flight runs as `interrupted`."""
        self._stop_event.set()
        for task in self._workers:
            task.cancel()
        for task in self._workers:
            with contextlib.suppress(asyncio.CancelledError):
                await task
        self._workers.clear()
        RUNS_ACTIVE.labels(status="running").set(0)
        await self.recover_interrupted_work(reclaim_expired_only=False)
