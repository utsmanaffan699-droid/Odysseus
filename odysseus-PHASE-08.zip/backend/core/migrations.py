"""Programmatic Alembic migration helpers for SQLite and PostgreSQL async engines."""

from __future__ import annotations

from pathlib import Path

from alembic import command
from alembic.config import Config
from alembic.runtime.migration import MigrationContext
from alembic.script import ScriptDirectory
from sqlalchemy.engine import Connection
from sqlalchemy.ext.asyncio import AsyncEngine

ROOT_DIR = Path(__file__).resolve().parent.parent.parent
ALEMBIC_INI_PATH = ROOT_DIR / "alembic.ini"


def _make_alembic_config(database_url: str) -> Config:
    cfg = Config(str(ALEMBIC_INI_PATH))
    cfg.set_main_option("script_location", str(ROOT_DIR / "backend" / "migrations"))
    cfg.set_main_option("sqlalchemy.url", database_url)
    return cfg


def get_head_revision(database_url: str = "sqlite+aiosqlite:///./data/odysseus.db") -> str:
    """Return the head revision ID defined in `backend/migrations/versions`."""
    cfg = _make_alembic_config(database_url)
    script = ScriptDirectory.from_config(cfg)
    head = script.get_current_head()
    if head is None:
        raise RuntimeError("No Alembic head revision found")
    return head


async def upgrade_db_async(engine: AsyncEngine, revision: str = "head") -> None:
    """Run `alembic upgrade <revision>` over an existing AsyncEngine connection."""
    cfg = _make_alembic_config(str(engine.url))

    def _run_upgrade(connection: Connection) -> None:
        cfg.attributes["connection"] = connection
        command.upgrade(cfg, revision)

    async with engine.begin() as conn:
        await conn.run_sync(_run_upgrade)


async def downgrade_db_async(engine: AsyncEngine, revision: str = "-1") -> None:
    """Run `alembic downgrade <revision>` over an existing AsyncEngine connection."""
    cfg = _make_alembic_config(str(engine.url))

    def _run_downgrade(connection: Connection) -> None:
        cfg.attributes["connection"] = connection
        command.downgrade(cfg, revision)

    async with engine.begin() as conn:
        await conn.run_sync(_run_downgrade)


async def get_current_revision_async(engine: AsyncEngine) -> str | None:
    """Return the current Alembic revision recorded in `alembic_version`, or None."""

    def _get_rev(connection: Connection) -> str | None:
        ctx = MigrationContext.configure(connection)
        return ctx.get_current_revision()

    async with engine.connect() as conn:
        return await conn.run_sync(_get_rev)
