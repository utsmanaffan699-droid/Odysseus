"""Repository and Unit-of-Work pattern for database access."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from backend.core.audit import append_audit_event, verify_audit_chain
from backend.core.models import (
    ApiToken,
    ApprovalRecord,
    ApprovalRuleRecord,
    ArtifactRecord,
    ArtifactVersionRecord,
    AttachmentRecord,
    AuditLog,
    ChatRecord,
    EncryptedSecret,
    IdempotencyRecord,
    JobRecord,
    McpServerRecord,
    MemoryRecord,
    MessageRecord,
    ProjectRecord,
    ProviderConfigRecord,
    RunEventRecord,
    RunRecord,
    RuntimeSetting,
    SessionRecord,
    SkillRecord,
    SkillVersionRecord,
    ToolCallRecord,
    UploadSessionRecord,
    UsageLedgerRecord,
    User,
    UserPrivilege,
)


def _ensure_utc(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        return dt.replace(tzinfo=UTC)
    return dt.astimezone(UTC)


class UserRepository:
    """Repository for User and UserPrivilege entities."""

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def get_by_id(self, user_id: str) -> User | None:
        stmt = select(User).options(selectinload(User.privileges)).where(User.id == user_id)
        return (await self._session.execute(stmt)).scalar_one_or_none()

    async def get_by_username(self, username: str) -> User | None:
        stmt = select(User).options(selectinload(User.privileges)).where(User.username == username)
        return (await self._session.execute(stmt)).scalar_one_or_none()

    async def count_users(self) -> int:
        stmt = select(func.count()).select_from(User)
        return int((await self._session.execute(stmt)).scalar_one())

    async def list_users(self) -> list[User]:
        stmt = select(User).options(selectinload(User.privileges)).order_by(User.created_at.asc())
        return list((await self._session.execute(stmt)).scalars().all())

    async def add(self, user: User) -> User:
        self._session.add(user)
        await self._session.flush()
        return user

    async def set_privileges(
        self,
        user: User,
        privileges: list[str],
        *,
        granted_by: str | None = None,
    ) -> None:
        now = datetime.now(UTC)
        stmt = select(UserPrivilege).where(UserPrivilege.user_id == user.id)
        current_rows = list((await self._session.execute(stmt)).scalars().all())
        existing = {p.privilege: p for p in current_rows}
        desired = set(privileges)
        for priv_name, obj in list(existing.items()):
            if priv_name not in desired:
                await self._session.delete(obj)
        for priv_name in sorted(desired):
            if priv_name not in existing:
                self._session.add(
                    UserPrivilege(
                        user_id=user.id,
                        privilege=priv_name,
                        granted_at=now,
                        granted_by=granted_by,
                    )
                )
        await self._session.flush()
        await self._session.refresh(user, attribute_names=["privileges"])


class SessionRepository:
    """Repository for server-side opaque user sessions."""

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def add(self, record: SessionRecord) -> SessionRecord:
        self._session.add(record)
        await self._session.flush()
        return record

    async def get_by_token_hash(self, token_hash: str) -> SessionRecord | None:
        stmt = select(SessionRecord).where(SessionRecord.token_hash == token_hash)
        return (await self._session.execute(stmt)).scalar_one_or_none()

    async def get_by_id(self, session_id: str) -> SessionRecord | None:
        stmt = select(SessionRecord).where(SessionRecord.id == session_id)
        return (await self._session.execute(stmt)).scalar_one_or_none()

    async def list_for_user(self, user_id: str) -> list[SessionRecord]:
        stmt = (
            select(SessionRecord)
            .where(SessionRecord.user_id == user_id, SessionRecord.revoked_at.is_(None))
            .order_by(SessionRecord.created_at.desc())
        )
        return list((await self._session.execute(stmt)).scalars().all())

    async def revoke(self, record: SessionRecord) -> None:
        record.revoked_at = datetime.now(UTC)
        await self._session.flush()


class ApiTokenRepository:
    """Repository for scoped API tokens."""

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def add(self, token: ApiToken) -> ApiToken:
        self._session.add(token)
        await self._session.flush()
        return token

    async def get_by_hash(self, token_hash: str) -> ApiToken | None:
        stmt = select(ApiToken).where(ApiToken.token_hash == token_hash)
        return (await self._session.execute(stmt)).scalar_one_or_none()

    async def get_by_id(self, token_id: str) -> ApiToken | None:
        stmt = select(ApiToken).where(ApiToken.id == token_id)
        return (await self._session.execute(stmt)).scalar_one_or_none()

    async def list_for_user(self, user_id: str) -> list[ApiToken]:
        stmt = (
            select(ApiToken).where(ApiToken.user_id == user_id).order_by(ApiToken.created_at.desc())
        )
        return list((await self._session.execute(stmt)).scalars().all())


class AuditRepository:
    """Repository for the append-only hash-chained audit log."""

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def record(
        self,
        *,
        action: str,
        resource_type: str,
        actor_user_id: str | None = None,
        actor_ip: str | None = None,
        resource_id: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> AuditLog:
        return await append_audit_event(
            self._session,
            action=action,
            resource_type=resource_type,
            actor_user_id=actor_user_id,
            actor_ip=actor_ip,
            resource_id=resource_id,
            details=details,
        )

    async def list_recent(self, limit: int = 100) -> list[AuditLog]:
        stmt = select(AuditLog).order_by(AuditLog.id.desc()).limit(limit)
        return list((await self._session.execute(stmt)).scalars().all())

    async def verify_chain(self) -> tuple[bool, int]:
        return await verify_audit_chain(self._session)


class SettingsRepository:
    """Repository for runtime settings and encrypted secrets."""

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def get_all_runtime(self) -> dict[str, Any]:
        stmt = select(RuntimeSetting)
        rows = (await self._session.execute(stmt)).scalars().all()
        return {row.key: row.value_json for row in rows}

    async def set_runtime(
        self, key: str, value: Any, *, updated_by: str | None = None
    ) -> RuntimeSetting:
        now = datetime.now(UTC)
        stmt = select(RuntimeSetting).where(RuntimeSetting.key == key)
        existing = (await self._session.execute(stmt)).scalar_one_or_none()
        if existing is not None:
            existing.value_json = value
            existing.updated_at = now
            existing.updated_by = updated_by
            await self._session.flush()
            return existing
        created = RuntimeSetting(
            key=key,
            value_json=value,
            updated_at=now,
            updated_by=updated_by,
        )
        self._session.add(created)
        await self._session.flush()
        return created

    async def get_secret(self, key: str) -> EncryptedSecret | None:
        stmt = select(EncryptedSecret).where(EncryptedSecret.key == key)
        return (await self._session.execute(stmt)).scalar_one_or_none()

    async def set_secret(
        self, key: str, ciphertext: str, *, updated_by: str | None = None
    ) -> EncryptedSecret:
        now = datetime.now(UTC)
        existing = await self.get_secret(key)
        if existing is not None:
            existing.ciphertext = ciphertext
            existing.updated_at = now
            existing.updated_by = updated_by
            await self._session.flush()
            return existing
        created = EncryptedSecret(
            key=key,
            ciphertext=ciphertext,
            updated_at=now,
            updated_by=updated_by,
        )
        self._session.add(created)
        await self._session.flush()
        return created


class ChatAndRunRepository:
    """Repository for chats, messages, runs, and durable run_events."""

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def create_chat(self, chat: ChatRecord) -> ChatRecord:
        self._session.add(chat)
        await self._session.flush()
        return chat

    async def get_chat(self, chat_id: str) -> ChatRecord | None:
        stmt = select(ChatRecord).where(ChatRecord.id == chat_id)
        return (await self._session.execute(stmt)).scalar_one_or_none()

    async def list_chats(
        self,
        user_id: str,
        *,
        project_id: str | None = None,
        include_archived: bool = False,
    ) -> list[ChatRecord]:
        stmt = select(ChatRecord).where(ChatRecord.user_id == user_id)
        if project_id is not None:
            stmt = stmt.where(ChatRecord.project_id == project_id)
        if not include_archived:
            stmt = stmt.where(ChatRecord.archived.is_(False))
        stmt = stmt.order_by(ChatRecord.pinned.desc(), ChatRecord.updated_at.desc())
        return list((await self._session.execute(stmt)).scalars().all())

    async def delete_chat(self, chat: ChatRecord) -> None:
        await self._session.delete(chat)
        await self._session.flush()

    async def add_message(self, msg: MessageRecord) -> MessageRecord:
        self._session.add(msg)
        await self._session.flush()
        return msg

    async def get_message(self, message_id: str) -> MessageRecord | None:
        stmt = select(MessageRecord).where(MessageRecord.id == message_id)
        return (await self._session.execute(stmt)).scalar_one_or_none()

    async def list_messages(self, chat_id: str) -> list[MessageRecord]:
        stmt = (
            select(MessageRecord)
            .where(MessageRecord.chat_id == chat_id)
            .order_by(MessageRecord.created_at.asc(), MessageRecord.branch_index.asc())
        )
        return list((await self._session.execute(stmt)).scalars().all())

    async def create_run(self, run: RunRecord) -> RunRecord:
        self._session.add(run)
        await self._session.flush()
        return run

    async def get_run(self, run_id: str) -> RunRecord | None:
        stmt = select(RunRecord).where(RunRecord.id == run_id)
        return (await self._session.execute(stmt)).scalar_one_or_none()

    async def list_runs_by_statuses(self, statuses: list[str]) -> list[RunRecord]:
        stmt = (
            select(RunRecord)
            .where(RunRecord.status.in_(statuses))
            .order_by(RunRecord.created_at.asc())
        )
        return list((await self._session.execute(stmt)).scalars().all())

    async def list_runs_for_chat(self, chat_id: str) -> list[RunRecord]:
        stmt = (
            select(RunRecord)
            .where(RunRecord.chat_id == chat_id)
            .order_by(RunRecord.created_at.desc())
        )
        return list((await self._session.execute(stmt)).scalars().all())

    async def list_runs_for_user(
        self,
        user_id: str,
        *,
        status: str | None = None,
        model: str | None = None,
        limit: int = 100,
    ) -> list[RunRecord]:
        stmt = select(RunRecord).where(RunRecord.user_id == user_id)
        if status:
            stmt = stmt.where(RunRecord.status == status)
        if model:
            stmt = stmt.where(RunRecord.model == model)
        stmt = stmt.order_by(RunRecord.created_at.desc()).limit(max(1, min(limit, 500)))
        return list((await self._session.execute(stmt)).scalars().all())

    async def delete_run(self, run: RunRecord) -> None:
        await self._session.delete(run)
        await self._session.flush()

    async def append_run_event(
        self,
        *,
        run_id: str,
        event_type: str,
        data: dict[str, Any],
        ts: str | None = None,
    ) -> RunEventRecord:
        stmt = select(func.max(RunEventRecord.seq)).where(RunEventRecord.run_id == run_id)
        current_max = (await self._session.execute(stmt)).scalar_one_or_none()
        next_seq = 1 if current_max is None else int(current_max) + 1
        record = RunEventRecord(
            run_id=run_id,
            seq=next_seq,
            ts=ts or datetime.now(UTC).isoformat(),
            type=event_type,
            data_json=data,
        )
        self._session.add(record)
        await self._session.flush()
        return record

    async def list_run_events(self, run_id: str, *, after_seq: int = 0) -> list[RunEventRecord]:
        stmt = (
            select(RunEventRecord)
            .where(RunEventRecord.run_id == run_id, RunEventRecord.seq > after_seq)
            .order_by(RunEventRecord.seq.asc())
        )
        return list((await self._session.execute(stmt)).scalars().all())


class ProjectRepository:
    """Repository for projects and per-project instructions."""

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def add(self, project: ProjectRecord) -> ProjectRecord:
        self._session.add(project)
        await self._session.flush()
        return project

    async def get(self, project_id: str) -> ProjectRecord | None:
        stmt = select(ProjectRecord).where(ProjectRecord.id == project_id)
        return (await self._session.execute(stmt)).scalar_one_or_none()

    async def list_for_user(self, user_id: str) -> list[ProjectRecord]:
        stmt = (
            select(ProjectRecord)
            .where(ProjectRecord.user_id == user_id)
            .order_by(ProjectRecord.updated_at.desc())
        )
        return list((await self._session.execute(stmt)).scalars().all())

    async def delete(self, project: ProjectRecord) -> None:
        await self._session.delete(project)
        await self._session.flush()


class AttachmentRepository:
    """Repository for content-addressed attachments and upload sessions."""

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def add_session(self, upload_session: UploadSessionRecord) -> UploadSessionRecord:
        self._session.add(upload_session)
        await self._session.flush()
        return upload_session

    async def get_session(self, upload_id: str) -> UploadSessionRecord | None:
        stmt = select(UploadSessionRecord).where(UploadSessionRecord.id == upload_id)
        return (await self._session.execute(stmt)).scalar_one_or_none()

    async def add_attachment(self, attachment: AttachmentRecord) -> AttachmentRecord:
        self._session.add(attachment)
        await self._session.flush()
        return attachment

    async def get_by_sha256(self, sha256: str) -> AttachmentRecord | None:
        stmt = select(AttachmentRecord).where(AttachmentRecord.sha256 == sha256)
        return (await self._session.execute(stmt)).scalar_one_or_none()

    async def list_by_shas(self, shas: list[str]) -> list[AttachmentRecord]:
        if not shas:
            return []
        stmt = select(AttachmentRecord).where(AttachmentRecord.sha256.in_(shas))
        return list((await self._session.execute(stmt)).scalars().all())


class IdempotencyRepository:
    """Repository for Idempotency-Key deduplication records."""

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def get(
        self,
        *,
        user_id: str,
        endpoint: str,
        idempotency_key: str,
    ) -> IdempotencyRecord | None:
        stmt = select(IdempotencyRecord).where(
            IdempotencyRecord.user_id == user_id,
            IdempotencyRecord.endpoint == endpoint,
            IdempotencyRecord.idempotency_key == idempotency_key,
        )
        return (await self._session.execute(stmt)).scalar_one_or_none()

    async def add(self, record: IdempotencyRecord) -> IdempotencyRecord:
        self._session.add(record)
        await self._session.flush()
        return record


class UsageRepository:
    """Repository for token usage and Decimal cost ledger."""

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def add(self, entry: UsageLedgerRecord) -> UsageLedgerRecord:
        self._session.add(entry)
        await self._session.flush()
        return entry

    async def list_entries(
        self,
        *,
        user_id: str | None = None,
        project_id: str | None = None,
        model: str | None = None,
    ) -> list[UsageLedgerRecord]:
        stmt = select(UsageLedgerRecord)
        if user_id is not None:
            stmt = stmt.where(UsageLedgerRecord.user_id == user_id)
        if project_id is not None:
            stmt = stmt.where(UsageLedgerRecord.project_id == project_id)
        if model is not None:
            stmt = stmt.where(UsageLedgerRecord.model == model)
        stmt = stmt.order_by(UsageLedgerRecord.created_at.desc())
        return list((await self._session.execute(stmt)).scalars().all())


class ProviderConfigRepository:
    """Repository for custom provider endpoints and capability overrides."""

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def get(self, provider_id: str) -> ProviderConfigRecord | None:
        stmt = select(ProviderConfigRecord).where(ProviderConfigRecord.id == provider_id)
        return (await self._session.execute(stmt)).scalar_one_or_none()

    async def list_all(self) -> list[ProviderConfigRecord]:
        stmt = select(ProviderConfigRecord).order_by(ProviderConfigRecord.created_at.asc())
        return list((await self._session.execute(stmt)).scalars().all())

    async def upsert(self, config: ProviderConfigRecord) -> ProviderConfigRecord:
        self._session.add(config)
        await self._session.flush()
        return config


class JobRepository:
    """Repository for durable background jobs."""

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def add(self, job: JobRecord) -> JobRecord:
        self._session.add(job)
        await self._session.flush()
        return job

    async def get(self, job_id: str) -> JobRecord | None:
        stmt = select(JobRecord).where(JobRecord.id == job_id)
        return (await self._session.execute(stmt)).scalar_one_or_none()


class ToolCallRepository:
    """Repository for durable tool call records."""

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def upsert(self, record: ToolCallRecord) -> ToolCallRecord:
        self._session.add(record)
        await self._session.flush()
        return record

    async def get(self, call_id: str) -> ToolCallRecord | None:
        stmt = select(ToolCallRecord).where(ToolCallRecord.id == call_id)
        return (await self._session.execute(stmt)).scalar_one_or_none()

    async def list_by_run(self, run_id: str) -> list[ToolCallRecord]:
        stmt = (
            select(ToolCallRecord)
            .where(ToolCallRecord.run_id == run_id)
            .order_by(ToolCallRecord.created_at.asc())
        )
        return list((await self._session.execute(stmt)).scalars().all())

    async def list_by_statuses(self, statuses: list[str]) -> list[ToolCallRecord]:
        stmt = select(ToolCallRecord).where(ToolCallRecord.status.in_(statuses))
        return list((await self._session.execute(stmt)).scalars().all())


class ApprovalRepository:
    """Repository for tool approval requests and structured approval rules."""

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def add(self, record: ApprovalRecord) -> ApprovalRecord:
        self._session.add(record)
        await self._session.flush()
        return record

    async def get(self, approval_id: str) -> ApprovalRecord | None:
        stmt = select(ApprovalRecord).where(ApprovalRecord.id == approval_id)
        return (await self._session.execute(stmt)).scalar_one_or_none()

    async def list_by_run(self, run_id: str) -> list[ApprovalRecord]:
        stmt = (
            select(ApprovalRecord)
            .where(ApprovalRecord.run_id == run_id)
            .order_by(ApprovalRecord.requested_at.asc())
        )
        return list((await self._session.execute(stmt)).scalars().all())

    async def list_for_user(
        self, user_id: str, *, status: str | None = None
    ) -> list[ApprovalRecord]:
        stmt = select(ApprovalRecord).where(ApprovalRecord.user_id == user_id)
        if status is not None:
            stmt = stmt.where(ApprovalRecord.status == status)
        stmt = stmt.order_by(ApprovalRecord.requested_at.asc())
        return list((await self._session.execute(stmt)).scalars().all())

    async def list_pending_for_user(self, user_id: str) -> list[ApprovalRecord]:
        stmt = (
            select(ApprovalRecord)
            .where(ApprovalRecord.user_id == user_id, ApprovalRecord.status == "pending")
            .order_by(ApprovalRecord.requested_at.asc())
        )
        return list((await self._session.execute(stmt)).scalars().all())

    async def add_rule(self, rule: ApprovalRuleRecord) -> ApprovalRuleRecord:
        self._session.add(rule)
        await self._session.flush()
        return rule

    async def list_rules_for_user(self, user_id: str) -> list[ApprovalRuleRecord]:
        stmt = (
            select(ApprovalRuleRecord)
            .where(ApprovalRuleRecord.user_id == user_id)
            .order_by(ApprovalRuleRecord.created_at.asc())
        )
        return list((await self._session.execute(stmt)).scalars().all())

    async def get_rule(self, rule_id: str) -> ApprovalRuleRecord | None:
        stmt = select(ApprovalRuleRecord).where(ApprovalRuleRecord.id == rule_id)
        return (await self._session.execute(stmt)).scalar_one_or_none()

    async def delete_rule(self, rule: ApprovalRuleRecord) -> None:
        await self._session.delete(rule)
        await self._session.flush()


class ArtifactRepository:
    """Repository for versioned artifacts."""

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def add_artifact(self, artifact: ArtifactRecord) -> ArtifactRecord:
        self._session.add(artifact)
        await self._session.flush()
        return artifact

    async def add_version(self, version: ArtifactVersionRecord) -> ArtifactVersionRecord:
        self._session.add(version)
        await self._session.flush()
        return version

    async def get(self, artifact_id: str) -> ArtifactRecord | None:
        stmt = select(ArtifactRecord).where(ArtifactRecord.id == artifact_id)
        return (await self._session.execute(stmt)).scalar_one_or_none()

    async def get_version(self, artifact_id: str, version: int) -> ArtifactVersionRecord | None:
        stmt = select(ArtifactVersionRecord).where(
            ArtifactVersionRecord.artifact_id == artifact_id,
            ArtifactVersionRecord.version == version,
        )
        return (await self._session.execute(stmt)).scalar_one_or_none()

    async def list_versions(self, artifact_id: str) -> list[ArtifactVersionRecord]:
        stmt = (
            select(ArtifactVersionRecord)
            .where(ArtifactVersionRecord.artifact_id == artifact_id)
            .order_by(ArtifactVersionRecord.version.asc())
        )
        return list((await self._session.execute(stmt)).scalars().all())

    async def list_for_user(self, user_id: str) -> list[ArtifactRecord]:
        stmt = (
            select(ArtifactRecord)
            .where(ArtifactRecord.user_id == user_id)
            .order_by(ArtifactRecord.updated_at.desc())
        )
        return list((await self._session.execute(stmt)).scalars().all())


class MemoryRepository:
    """Repository for user and project memories."""

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def add(self, record: MemoryRecord) -> MemoryRecord:
        self._session.add(record)
        await self._session.flush()
        return record

    async def get(self, memory_id: str) -> MemoryRecord | None:
        stmt = select(MemoryRecord).where(MemoryRecord.id == memory_id)
        return (await self._session.execute(stmt)).scalar_one_or_none()

    async def list_for_user(
        self,
        user_id: str,
        *,
        scope: str | None = None,
        project_id: str | None = None,
        confirmed_only: bool = False,
    ) -> list[MemoryRecord]:
        stmt = select(MemoryRecord).where(MemoryRecord.user_id == user_id)
        if scope is not None:
            stmt = stmt.where(MemoryRecord.scope == scope)
        if project_id is not None:
            stmt = stmt.where(MemoryRecord.project_id == project_id)
        if confirmed_only:
            stmt = stmt.where(MemoryRecord.confirmed.is_(True))
        stmt = stmt.order_by(MemoryRecord.pinned.desc(), MemoryRecord.updated_at.desc())
        return list((await self._session.execute(stmt)).scalars().all())

    async def delete(self, record: MemoryRecord) -> None:
        await self._session.delete(record)
        await self._session.flush()


class SkillRepository:
    """Repository for skills and skill version snapshots."""

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def add(self, record: SkillRecord) -> SkillRecord:
        self._session.add(record)
        await self._session.flush()
        return record

    async def add_version(self, version: SkillVersionRecord) -> SkillVersionRecord:
        self._session.add(version)
        await self._session.flush()
        return version

    async def get(self, skill_id: str) -> SkillRecord | None:
        stmt = select(SkillRecord).where(SkillRecord.id == skill_id)
        return (await self._session.execute(stmt)).scalar_one_or_none()

    async def get_by_name(self, name: str, *, user_id: str | None = None) -> SkillRecord | None:
        stmt = select(SkillRecord).where(SkillRecord.name == name)
        if user_id is not None:
            stmt = stmt.where((SkillRecord.user_id == user_id) | (SkillRecord.scope == "global"))
        return (await self._session.execute(stmt)).scalars().first()

    async def list_visible(
        self, user_id: str, *, project_id: str | None = None
    ) -> list[SkillRecord]:
        stmt = select(SkillRecord).where(
            (SkillRecord.user_id == user_id)
            | (SkillRecord.scope == "global")
            | ((SkillRecord.project_id == project_id) if project_id else False)
        )
        stmt = stmt.order_by(SkillRecord.name.asc())
        return list((await self._session.execute(stmt)).scalars().all())

    async def list_versions(self, skill_id: str) -> list[SkillVersionRecord]:
        stmt = (
            select(SkillVersionRecord)
            .where(SkillVersionRecord.skill_id == skill_id)
            .order_by(SkillVersionRecord.version.asc())
        )
        return list((await self._session.execute(stmt)).scalars().all())

    async def delete(self, record: SkillRecord) -> None:
        await self._session.delete(record)
        await self._session.flush()


class McpServerRepository:
    """Repository for registered MCP servers."""

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def upsert(self, record: McpServerRecord) -> McpServerRecord:
        self._session.add(record)
        await self._session.flush()
        return record

    async def get(self, server_id: str) -> McpServerRecord | None:
        stmt = select(McpServerRecord).where(McpServerRecord.id == server_id)
        return (await self._session.execute(stmt)).scalar_one_or_none()

    async def get_by_name(self, name: str) -> McpServerRecord | None:
        stmt = select(McpServerRecord).where(McpServerRecord.name == name)
        return (await self._session.execute(stmt)).scalar_one_or_none()

    async def list_all(self) -> list[McpServerRecord]:
        stmt = select(McpServerRecord).order_by(McpServerRecord.name.asc())
        return list((await self._session.execute(stmt)).scalars().all())

    async def delete(self, record: McpServerRecord) -> None:
        await self._session.delete(record)
        await self._session.flush()


class UnitOfWork:
    """Unit of Work aggregating repositories around a single AsyncSession."""

    def __init__(self, session: AsyncSession) -> None:
        self.session = session
        self.users = UserRepository(session)
        self.sessions = SessionRepository(session)
        self.api_tokens = ApiTokenRepository(session)
        self.audit = AuditRepository(session)
        self.settings = SettingsRepository(session)
        self.chats = ChatAndRunRepository(session)
        self.projects = ProjectRepository(session)
        self.attachments = AttachmentRepository(session)
        self.idempotency = IdempotencyRepository(session)
        self.usage = UsageRepository(session)
        self.providers = ProviderConfigRepository(session)
        self.jobs = JobRepository(session)
        self.tool_calls = ToolCallRepository(session)
        self.approvals = ApprovalRepository(session)
        self.artifacts = ArtifactRepository(session)
        self.memories = MemoryRepository(session)
        self.skills = SkillRepository(session)
        self.mcp_servers = McpServerRepository(session)


__all__ = [
    "ApiTokenRepository",
    "ApprovalRepository",
    "ArtifactRepository",
    "AttachmentRepository",
    "AuditRepository",
    "ChatAndRunRepository",
    "IdempotencyRepository",
    "JobRepository",
    "McpServerRepository",
    "MemoryRepository",
    "ProjectRepository",
    "ProviderConfigRepository",
    "SessionRepository",
    "SettingsRepository",
    "SkillRepository",
    "ToolCallRepository",
    "UnitOfWork",
    "UsageRepository",
    "UserRepository",
    "_ensure_utc",
]
