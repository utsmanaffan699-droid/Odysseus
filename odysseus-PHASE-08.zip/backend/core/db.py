"""Async SQLAlchemy 2.0 database engine, SQLite WAL tuning, and write-retry resilience."""

from __future__ import annotations

import asyncio
import errno
import secrets
from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, TypeVar

from sqlalchemy import event, text
from sqlalchemy.exc import OperationalError
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.pool import NullPool

from backend.core.logging import get_logger
from backend.core.metrics import DB_POOL
from backend.core.models import Base
from backend.core.settings import Settings

T = TypeVar("T")
logger = get_logger("odysseus.db")


class StorageFullError(RuntimeError):
    """Raised when disk or database storage is exhausted (ENOSPC / SQLITE_FULL)."""


_DISK_DEGRADED_REASON: str | None = None


def set_disk_degraded(reason: str | None) -> None:
    """Record or clear a disk-full / storage degradation reason."""
    global _DISK_DEGRADED_REASON
    _DISK_DEGRADED_REASON = reason


def get_disk_degraded() -> str | None:
    """Return the current disk degradation reason if any."""
    return _DISK_DEGRADED_REASON


def is_disk_full_exception(exc: BaseException) -> bool:
    """Detect OS ENOSPC or SQLite disk-full / I/O errors."""
    if isinstance(exc, OSError) and exc.errno == errno.ENOSPC:
        return True
    msg = str(exc).lower()
    if any(
        phrase in msg
        for phrase in (
            "database or disk is full",
            "no space left on device",
            "disk i/o error",
            "enospc",
            "out of disk space",
        )
    ):
        return True
    if exc.__cause__ is not None and exc.__cause__ is not exc:
        return is_disk_full_exception(exc.__cause__)
    return False


def is_sqlite_locked_exception(exc: BaseException) -> bool:
    """Detect transient SQLite lock contention errors."""
    msg = str(exc).lower()
    return "database is locked" in msg or "database table is locked" in msg


class DatabaseManager:
    """Manages the async SQLAlchemy engine, session factory, and write serialization/retry."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.database_url = settings.database_url
        self.is_sqlite = self.database_url.startswith("sqlite")
        self._sqlite_write_lock = asyncio.Lock()

        if self.is_sqlite:
            self._ensure_sqlite_parent_dir()
            connect_args: dict[str, Any] = {
                "timeout": max(1.0, settings.db_busy_timeout_ms / 1000.0),
            }
            self.engine: AsyncEngine = create_async_engine(
                self.database_url,
                connect_args=connect_args,
                poolclass=NullPool,
            )
            self._register_sqlite_pragmas(self.engine, settings.db_busy_timeout_ms)
        else:
            self.engine = create_async_engine(
                self.database_url,
                pool_size=settings.db_pool_size,
                max_overflow=settings.db_max_overflow,
                pool_pre_ping=True,
            )

        self.session_factory = async_sessionmaker(
            self.engine,
            expire_on_commit=False,
            class_=AsyncSession,
        )

    def _ensure_sqlite_parent_dir(self) -> None:
        prefix = "sqlite+aiosqlite:///"
        if self.database_url.startswith(prefix):
            raw_path = self.database_url[len(prefix) :]
            if raw_path and raw_path != ":memory:" and not raw_path.startswith("file:"):
                db_path = Path(raw_path)
                db_path.parent.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _register_sqlite_pragmas(engine: AsyncEngine, busy_timeout_ms: int) -> None:
        @event.listens_for(engine.sync_engine, "connect")
        def _set_sqlite_pragma(dbapi_connection: Any, _connection_record: Any) -> None:
            cursor = dbapi_connection.cursor()
            cursor.execute("PRAGMA journal_mode=WAL;")
            cursor.execute("PRAGMA synchronous=NORMAL;")
            cursor.execute(f"PRAGMA busy_timeout={int(busy_timeout_ms)};")
            cursor.execute("PRAGMA foreign_keys=ON;")
            cursor.close()

    async def create_schema_if_needed(self) -> None:
        """Create tables if not already migrated (used by fast unit tests)."""
        async with self.engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)

    @asynccontextmanager
    async def session(self) -> AsyncIterator[AsyncSession]:
        """Provide a transactional async database session."""
        DB_POOL.labels(state="checked_out").inc()
        try:
            async with self.session_factory() as sess:
                yield sess
        finally:
            DB_POOL.labels(state="checked_out").dec()

    async def execute_read(
        self,
        fn: Callable[[AsyncSession], Awaitable[T]],
    ) -> T:
        """Execute a read-only database query inside a managed session."""
        async with self.session() as sess:
            return await fn(sess)

    async def execute_write(
        self,
        fn: Callable[[AsyncSession], Awaitable[T]],
        *,
        max_retries: int = 12,
    ) -> T:
        """Execute a database write operation with automatic retry on SQLite lock contention
        and clean detection of disk-full conditions.
        """
        attempt = 0
        while True:
            attempt += 1
            try:
                if self.is_sqlite:
                    async with self._sqlite_write_lock:
                        return await self._run_once(fn)
                return await self._run_once(fn)
            except BaseException as exc:
                if is_disk_full_exception(exc):
                    reason = (
                        f"Storage full on {self.settings.data_dir}: {type(exc).__name__}: {exc}"
                    )
                    set_disk_degraded(reason)
                    logger.error("storage_full_error", reason=reason)
                    raise StorageFullError(
                        "Insufficient storage space available to persist data."
                    ) from exc

                if isinstance(exc, OperationalError) and is_sqlite_locked_exception(exc):
                    if attempt <= max_retries:
                        jitter = (secrets.randbelow(10) + 1) / 1000.0
                        backoff = min(0.5, 0.005 * (1.6**attempt)) + jitter
                        await asyncio.sleep(backoff)
                        continue
                raise

    async def _run_once(self, fn: Callable[[AsyncSession], Awaitable[T]]) -> T:
        async with self.session() as sess:
            try:
                result = await fn(sess)
                await sess.commit()
                if _DISK_DEGRADED_REASON is not None:
                    set_disk_degraded(None)
                return result
            except BaseException:
                await sess.rollback()
                raise

    async def check_health(self) -> tuple[bool, str]:
        """Verify DB connectivity and check disk writability."""
        try:
            async with self.session() as sess:
                await sess.execute(text("SELECT 1"))
            return True, "ok"
        except Exception as exc:
            return False, str(exc)

    async def dispose(self) -> None:
        """Close all database connections cleanly."""
        await self.engine.dispose()
