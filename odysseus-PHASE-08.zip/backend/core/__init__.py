"""Odysseus core infrastructure package."""

from __future__ import annotations
