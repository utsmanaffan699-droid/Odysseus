"""Frugal Agent Context Management: ContextBudgeter, profiles, dynamic tools, compaction."""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from typing import Any, Literal

from backend.domain.chats.prompts import estimate_tokens, truncate_to_token_budget
from backend.domain.memory.service import compute_bm25_score, tokenize_for_bm25
from backend.domain.tools.provenance import wrap_untrusted_with_delimiter
from backend.providers.base import ProviderMessage, ProviderToolSpec

ContextProfileLiteral = Literal["4k", "8k", "16k", "32k", "large"]

ALWAYS_ON_CORE_TOOLS: tuple[str, ...] = (
    "read_file",
    "edit_file",
    "write_file",
    "shell",
    "update_plan",
    "discover_tools",
)


@dataclass(frozen=True)
class ContextWindowProfile:
    """Budget allocation preset for a specific model context window tier."""

    name: ContextProfileLiteral
    context_window: int
    max_prompt_tokens: int
    system_budget: int
    tool_schemas_budget: int
    skills_index_budget: int
    memory_budget: int
    project_docs_budget: int
    attachments_budget: int
    scratch_budget: int
    history_budget: int
    top_k_tools: int
    compaction_ratio: float = 0.85
    keep_last_turns: int = 2


CONTEXT_PROFILES: dict[ContextProfileLiteral, ContextWindowProfile] = {
    "4k": ContextWindowProfile(
        name="4k",
        context_window=4096,
        max_prompt_tokens=3200,
        system_budget=280,
        tool_schemas_budget=420,
        skills_index_budget=140,
        memory_budget=180,
        project_docs_budget=240,
        attachments_budget=240,
        scratch_budget=200,
        history_budget=1500,
        top_k_tools=6,
        compaction_ratio=0.85,
        keep_last_turns=2,
    ),
    "8k": ContextWindowProfile(
        name="8k",
        context_window=8192,
        max_prompt_tokens=6400,
        system_budget=500,
        tool_schemas_budget=800,
        skills_index_budget=300,
        memory_budget=400,
        project_docs_budget=600,
        attachments_budget=600,
        scratch_budget=400,
        history_budget=2800,
        top_k_tools=9,
        compaction_ratio=0.85,
        keep_last_turns=3,
    ),
    "16k": ContextWindowProfile(
        name="16k",
        context_window=16384,
        max_prompt_tokens=13000,
        system_budget=900,
        tool_schemas_budget=1500,
        skills_index_budget=600,
        memory_budget=800,
        project_docs_budget=1400,
        attachments_budget=1400,
        scratch_budget=800,
        history_budget=5600,
        top_k_tools=12,
        compaction_ratio=0.85,
        keep_last_turns=4,
    ),
    "32k": ContextWindowProfile(
        name="32k",
        context_window=32768,
        max_prompt_tokens=26000,
        system_budget=1500,
        tool_schemas_budget=2500,
        skills_index_budget=1000,
        memory_budget=1500,
        project_docs_budget=3000,
        attachments_budget=3000,
        scratch_budget=1500,
        history_budget=12000,
        top_k_tools=16,
        compaction_ratio=0.85,
        keep_last_turns=6,
    ),
    "large": ContextWindowProfile(
        name="large",
        context_window=128000,
        max_prompt_tokens=100000,
        system_budget=4000,
        tool_schemas_budget=6000,
        skills_index_budget=2500,
        memory_budget=4000,
        project_docs_budget=12000,
        attachments_budget=12000,
        scratch_budget=4500,
        history_budget=55000,
        top_k_tools=28,
        compaction_ratio=0.85,
        keep_last_turns=8,
    ),
}


def resolve_context_profile(context_window: int) -> ContextWindowProfile:
    """Select the appropriate ContextWindowProfile for a given token window size."""
    if context_window <= 4096:
        return CONTEXT_PROFILES["4k"]
    if context_window <= 8192:
        return CONTEXT_PROFILES["8k"]
    if context_window <= 16384:
        return CONTEXT_PROFILES["16k"]
    if context_window <= 32768:
        return CONTEXT_PROFILES["32k"]
    return CONTEXT_PROFILES["large"]


@dataclass(frozen=True)
class ContextUsageBreakdown:
    """Per-step token breakdown consumed by the UI context meter and run diagnostics."""

    profile: ContextProfileLiteral
    context_window: int
    max_prompt_tokens: int
    system_tokens: int
    tool_schemas_tokens: int
    skills_index_tokens: int
    memory_tokens: int
    project_docs_tokens: int
    attachments_tokens: int
    scratch_tokens: int
    history_tokens: int
    total_prompt_tokens: int
    selected_tools: list[str]
    compacted: bool = False
    removed_tokens: int = 0
    summary_ref: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "profile": self.profile,
            "context_window": self.context_window,
            "window_size": self.context_window,
            "max_prompt_tokens": self.max_prompt_tokens,
            "system": self.system_tokens,
            "tool_schemas": self.tool_schemas_tokens,
            "skills_index": self.skills_index_tokens,
            "memory": self.memory_tokens,
            "project_docs": self.project_docs_tokens,
            "attachments": self.attachments_tokens,
            "scratch": self.scratch_tokens,
            "history": self.history_tokens,
            "total_prompt_tokens": self.total_prompt_tokens,
            "total_tokens": self.total_prompt_tokens,
            "selected_tools": list(self.selected_tools),
            "compacted": self.compacted,
            "removed_tokens": self.removed_tokens,
            "summary_ref": self.summary_ref,
        }


@dataclass(frozen=True)
class CompactionOutcome:
    """Result of compacting older conversation turns into a structured memo."""

    compacted: bool
    memo_text: str
    summary_ref: str
    removed_tokens: int
    retained_messages: list[dict[str, Any]]


@dataclass(frozen=True)
class BudgetedAgentPrompt:
    """Assembled provider messages, selected tool specs, and measured token breakdown."""

    messages: list[ProviderMessage]
    tools: list[ProviderToolSpec]
    breakdown: ContextUsageBreakdown
    compaction: CompactionOutcome | None = None


def select_relevant_tools(
    all_tools: list[ProviderToolSpec],
    *,
    query_text: str,
    top_k: int,
    always_on: tuple[str, ...] = ALWAYS_ON_CORE_TOOLS,
    extra_discovered: set[str] | None = None,
) -> list[ProviderToolSpec]:
    """Select the always-on core tools plus top-k most relevant tools for `query_text`."""
    if len(all_tools) <= top_k:
        return list(all_tools)

    by_name = {t.name: t for t in all_tools}
    selected: list[ProviderToolSpec] = []
    seen: set[str] = set()

    # 1. Include explicitly discovered tools first
    for name in sorted(extra_discovered or set()):
        if name in by_name and name not in seen:
            selected.append(by_name[name])
            seen.add(name)

    # 2. Include always-on core tools
    for name in always_on:
        if name in by_name and name not in seen and len(selected) < top_k:
            selected.append(by_name[name])
            seen.add(name)

    if len(selected) >= top_k:
        return selected[:top_k]

    # 3. Rank remaining tools using BM25 over name + description + parameter keys
    remaining = [t for t in all_tools if t.name not in seen]
    q_tokens = tokenize_for_bm25(query_text)
    doc_tokens_list: list[list[str]] = []
    for t in remaining:
        props = (
            list(t.parameters.get("properties", {}).keys())
            if isinstance(t.parameters, dict)
            else []
        )
        text_doc = f"{t.name.replace('_', ' ')} {t.description} {' '.join(props)}"
        doc_tokens_list.append(tokenize_for_bm25(text_doc))

    avg_len = sum(len(dt) for dt in doc_tokens_list) / max(1, len(doc_tokens_list))
    doc_freqs: dict[str, int] = {}
    for dt in doc_tokens_list:
        for tok in set(dt):
            doc_freqs[tok] = doc_freqs.get(tok, 0) + 1

    scored: list[tuple[float, str, ProviderToolSpec]] = []
    for t, d_toks in zip(remaining, doc_tokens_list, strict=False):
        score = compute_bm25_score(
            q_tokens,
            d_toks,
            avg_doc_len=avg_len,
            doc_freqs=doc_freqs,
            total_docs=len(remaining),
        )
        scored.append((score, t.name, t))

    scored.sort(key=lambda item: (-item[0], item[1]))
    for _sc, _nm, spec in scored:
        if len(selected) >= top_k:
            break
        selected.append(spec)
        seen.add(spec.name)

    return selected


_PATH_EXTRACT_RE = re.compile(r"\b[A-Za-z0-9_./-]+\.(?:py|ts|tsx|js|json|md|yaml|yml|txt|sh)\b")
_FACT_LINE_RE = re.compile(
    r"(?:needle|secret|code|passphrase|token|key|port|version|fact|goal|must|important|id\s*[:=])",
    re.IGNORECASE,
)


def compact_history_messages(
    history: list[dict[str, Any]],
    *,
    model: str,
    context_window: int,
    history_budget: int,
    compaction_ratio: float = 0.85,
    keep_last_turns: int = 2,
    force_if_over_tokens: int | None = None,
) -> CompactionOutcome:
    """Summarize older turns into a structured memo when history exceeds window thresholds.

    Preserves needle facts, identifiers, decisions, files touched, and open questions,
    and never compacts the last `keep_last_turns` messages or pending tool results.
    """
    total_hist_tokens = sum(estimate_tokens(str(m.get("content", "")), model) + 4 for m in history)
    threshold_tokens = (
        force_if_over_tokens
        if force_if_over_tokens is not None
        else min(history_budget, int(context_window * compaction_ratio))
    )

    if total_hist_tokens <= threshold_tokens or len(history) <= keep_last_turns:
        return CompactionOutcome(
            compacted=False,
            memo_text="",
            summary_ref="",
            removed_tokens=0,
            retained_messages=list(history),
        )

    split_idx = max(1, len(history) - max(1, keep_last_turns))
    # Never split right in the middle of a pending tool call / result pair
    while split_idx > 1 and str(history[split_idx].get("role", "")) == "tool":
        split_idx -= 1

    older = history[:split_idx]
    retained = history[split_idx:]

    key_facts: list[str] = []
    user_goals: list[str] = []
    decisions_and_tools: list[str] = []
    files_touched: set[str] = set()
    open_questions: list[str] = []

    for msg in older:
        role = str(msg.get("role", "user"))
        content = str(msg.get("content", "")).strip()
        if not content:
            continue

        for fmatch in _PATH_EXTRACT_RE.findall(content):
            files_touched.add(fmatch)

        for raw_line in content.splitlines():
            line = raw_line.strip()
            if not line:
                continue
            if _FACT_LINE_RE.search(line):
                snippet = line[:220]
                if snippet not in key_facts:
                    key_facts.append(snippet)
            elif role == "user" and len(user_goals) < 6:
                user_goals.append(line[:220])
            if "?" in line and len(open_questions) < 5:
                open_questions.append(line[:180])
            if role in ("assistant", "tool") and (
                "tool" in line.lower() or "completed" in line.lower() or "wrote" in line.lower()
            ):
                if len(decisions_and_tools) < 8:
                    decisions_and_tools.append(line[:180])

    goals_and_facts = [*key_facts[:10], *user_goals[:4]]
    memo_sections = [
        "[Context Compaction Memo — reversible summary of earlier conversation turns]",
        "### Goals & Key Facts",
        *(f"- {g}" for g in (goals_and_facts[:12] or ["Continue user task"])),
        "### Decisions & Completed Steps",
        *(f"- {d}" for d in (decisions_and_tools[:6] or ["Initial analysis completed"])),
        "### Files Touched",
        f"- {', '.join(sorted(files_touched)) if files_touched else 'none'}",
        "### Open Questions",
        *(f"- {q}" for q in (open_questions[:4] or ["None"])),
    ]
    memo_text = "\n".join(memo_sections)
    memo_budget = max(160, min(600, history_budget // 3))
    memo_text, _ = truncate_to_token_budget(memo_text, memo_budget, model)

    older_tokens = sum(estimate_tokens(str(m.get("content", "")), model) + 4 for m in older)
    memo_tokens = estimate_tokens(memo_text, model) + 4
    removed_tokens = max(1, older_tokens - memo_tokens)
    digest = hashlib.sha256(memo_text.encode("utf-8")).hexdigest()[:12]
    summary_ref = f"memo://compaction/{digest}"

    return CompactionOutcome(
        compacted=True,
        memo_text=memo_text,
        summary_ref=summary_ref,
        removed_tokens=removed_tokens,
        retained_messages=list(retained),
    )


@dataclass
class ContextBudgeter:
    """Assembles frugal, deterministic prompts across all 8 context window sections."""

    profile: ContextWindowProfile = field(default_factory=lambda: CONTEXT_PROFILES["large"])

    @classmethod
    def for_window(
        cls,
        context_window: int,
        *,
        profile_override: ContextProfileLiteral | None = None,
    ) -> ContextBudgeter:
        if profile_override is not None and profile_override in CONTEXT_PROFILES:
            return cls(profile=CONTEXT_PROFILES[profile_override])
        return cls(profile=resolve_context_profile(context_window))

    def build_agent_prompt(
        self,
        *,
        base_system_prompt: str,
        all_tools: list[ProviderToolSpec],
        history: list[dict[str, Any]],
        model: str,
        run_nonce: str,
        use_fenced_tools: bool = False,
        skills_index_text: str = "",
        memories: list[dict[str, Any]] | None = None,
        project_name: str | None = None,
        project_instructions: str | None = None,
        attachments: list[dict[str, Any]] | None = None,
        scratch_notes: str = "",
        extra_discovered_tools: set[str] | None = None,
    ) -> BudgetedAgentPrompt:
        """Allocate budgets, select top-k tools, compact history if needed, and build messages."""
        prof = self.profile

        # 1. System prompt
        sys_txt, _ = truncate_to_token_budget(base_system_prompt.strip(), prof.system_budget, model)
        sys_tokens = estimate_tokens(sys_txt, model)

        # 2. Project docs
        proj_txt = ""
        if project_instructions and project_instructions.strip():
            header = f"## Project ({project_name or 'Workspace'})\n"
            body, _ = truncate_to_token_budget(
                project_instructions.strip(),
                max(32, prof.project_docs_budget - 12),
                model,
            )
            proj_txt = f"{header}{body}"
        proj_tokens = estimate_tokens(proj_txt, model) if proj_txt else 0

        # 3. Skills progressive disclosure index
        skills_txt = ""
        if skills_index_text.strip():
            skills_txt, _ = truncate_to_token_budget(
                skills_index_text.strip(), prof.skills_index_budget, model
            )
        skills_tokens = estimate_tokens(skills_txt, model) if skills_txt else 0

        # 4. Dynamic tool selection
        query_context = "\n".join(str(m.get("content", "")) for m in history[-3:])
        selected_specs = select_relevant_tools(
            all_tools,
            query_text=query_context,
            top_k=prof.top_k_tools,
            extra_discovered=extra_discovered_tools,
        )
        fenced_tools_txt = ""
        if use_fenced_tools and selected_specs:
            from backend.domain.agents.fenced_parser import format_fenced_tool_instructions

            raw_fenced = format_fenced_tool_instructions(
                [
                    {
                        "name": t.name,
                        "description": t.description,
                        "parameters": t.parameters,
                    }
                    for t in selected_specs
                ]
            )
            fenced_tools_txt, _ = truncate_to_token_budget(
                raw_fenced, prof.tool_schemas_budget, model
            )
            tool_tokens = estimate_tokens(fenced_tools_txt, model)
        else:
            schema_str = " ".join(f"{t.name}:{t.description}" for t in selected_specs)
            tool_tokens = min(
                prof.tool_schemas_budget,
                estimate_tokens(schema_str, model) + len(selected_specs) * 12,
            )

        # 5. Memories (injected as untrusted data inside randomized per-run delimiters)
        mem_txt = ""
        if memories:
            raw_mem_lines = [f"- [{m.get('id', 'mem')}] {m.get('text', '')}" for m in memories]
            joined_mem = "\n".join(raw_mem_lines)
            delimited_mem = wrap_untrusted_with_delimiter(
                joined_mem, source="memory", run_nonce=run_nonce
            )
            mem_txt, _ = truncate_to_token_budget(delimited_mem, prof.memory_budget, model)
        mem_tokens = estimate_tokens(mem_txt, model) if mem_txt else 0

        # 6. Attachments (wrapped as untrusted file data)
        att_txt = ""
        if attachments:
            att_blocks: list[str] = []
            for a in attachments:
                ext = str(a.get("extracted_text") or "").strip()
                if ext:
                    att_blocks.append(f"[{a.get('filename', 'file')}]\n{ext}")
            if att_blocks:
                wrapped_att = wrap_untrusted_with_delimiter(
                    "\n\n".join(att_blocks),
                    source="file",
                    run_nonce=run_nonce,
                )
                att_txt, _ = truncate_to_token_budget(wrapped_att, prof.attachments_budget, model)
        att_tokens = estimate_tokens(att_txt, model) if att_txt else 0

        # 7. Scratch / plan notes
        scratch_txt = ""
        if scratch_notes.strip():
            scratch_txt, _ = truncate_to_token_budget(
                scratch_notes.strip(), prof.scratch_budget, model
            )
        scratch_tokens = estimate_tokens(scratch_txt, model) if scratch_txt else 0

        # 8. History + Compaction
        non_history_tokens = (
            sys_tokens
            + proj_tokens
            + skills_tokens
            + tool_tokens
            + mem_tokens
            + att_tokens
            + scratch_tokens
        )
        remaining_for_history = max(
            200,
            min(prof.history_budget, prof.max_prompt_tokens - non_history_tokens - 32),
        )

        compaction = compact_history_messages(
            history,
            model=model,
            context_window=prof.context_window,
            history_budget=remaining_for_history,
            compaction_ratio=prof.compaction_ratio,
            keep_last_turns=prof.keep_last_turns,
            force_if_over_tokens=remaining_for_history,
        )

        # Assemble stable prefix system message (cache_ephemeral=True for prompt caching)
        sys_parts = [p for p in (sys_txt, proj_txt, skills_txt, fenced_tools_txt) if p]
        dynamic_sys_parts = [p for p in (mem_txt, att_txt, scratch_txt, compaction.memo_text) if p]

        messages: list[ProviderMessage] = []
        full_sys = "\n\n".join([*sys_parts, *dynamic_sys_parts]).strip()
        if full_sys:
            messages.append(
                ProviderMessage(
                    role="system",
                    content=full_sys,
                    cache_ephemeral=True,
                )
            )

        # Enforce strict cap on retained history so total_prompt_tokens <= max_prompt_tokens
        hist_budget_left = max(
            120,
            prof.max_prompt_tokens - (estimate_tokens(full_sys, model) + tool_tokens + 24),
        )
        retained_msgs: list[ProviderMessage] = []
        used_hist_tokens = 0
        for item in reversed(compaction.retained_messages):
            role_raw = str(item.get("role", "user"))
            role_lit: Literal["system", "user", "assistant", "tool"] = (
                role_raw  # type: ignore[assignment]
                if role_raw in ("system", "user", "assistant", "tool")
                else "user"
            )
            c_txt = str(item.get("content", ""))
            t_est = estimate_tokens(c_txt, model) + 4
            if used_hist_tokens + t_est > hist_budget_left:
                avail = max(32, hist_budget_left - used_hist_tokens)
                c_txt, _ = truncate_to_token_budget(c_txt, avail, model)
                t_est = estimate_tokens(c_txt, model) + 4
                retained_msgs.append(
                    ProviderMessage(
                        role=role_lit,
                        content=c_txt,
                        tool_call_id=item.get("tool_call_id"),
                    )
                )
                used_hist_tokens += t_est
                break
            retained_msgs.append(
                ProviderMessage(
                    role=role_lit,
                    content=c_txt,
                    tool_call_id=item.get("tool_call_id"),
                )
            )
            used_hist_tokens += t_est

        retained_msgs.reverse()
        messages.extend(retained_msgs)

        hist_total = used_hist_tokens + (
            estimate_tokens(compaction.memo_text, model) if compaction.compacted else 0
        )
        total_prompt = min(
            prof.max_prompt_tokens,
            non_history_tokens + hist_total,
        )

        breakdown = ContextUsageBreakdown(
            profile=prof.name,
            context_window=prof.context_window,
            max_prompt_tokens=prof.max_prompt_tokens,
            system_tokens=sys_tokens,
            tool_schemas_tokens=tool_tokens,
            skills_index_tokens=skills_tokens,
            memory_tokens=mem_tokens,
            project_docs_tokens=proj_tokens,
            attachments_tokens=att_tokens,
            scratch_tokens=scratch_tokens,
            history_tokens=hist_total,
            total_prompt_tokens=total_prompt,
            selected_tools=[t.name for t in selected_specs],
            compacted=compaction.compacted,
            removed_tokens=compaction.removed_tokens,
            summary_ref=compaction.summary_ref or None,
        )

        return BudgetedAgentPrompt(
            messages=messages,
            tools=[] if use_fenced_tools else selected_specs,
            breakdown=breakdown,
            compaction=compaction if compaction.compacted else None,
        )
