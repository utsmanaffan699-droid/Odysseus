"""Agent domain package: presets, context budgeter, compaction, and text-fenced tool parser."""

from backend.domain.agents.context import (
    ALWAYS_ON_CORE_TOOLS,
    CONTEXT_PROFILES,
    BudgetedAgentPrompt,
    CompactionOutcome,
    ContextBudgeter,
    ContextProfileLiteral,
    ContextUsageBreakdown,
    ContextWindowProfile,
    compact_history_messages,
    resolve_context_profile,
    select_relevant_tools,
)
from backend.domain.agents.fenced_parser import (
    FencedCallParseError,
    FencedParseBatchResult,
    IncrementalFencedToolParser,
    ParsedFencedToolCall,
    build_tool_call_repair_prompt,
    format_fenced_tool_instructions,
    parse_fenced_tool_calls,
)
from backend.domain.agents.models import AgentPreset, validate_agent_preset

__all__ = [
    "ALWAYS_ON_CORE_TOOLS",
    "CONTEXT_PROFILES",
    "AgentPreset",
    "BudgetedAgentPrompt",
    "CompactionOutcome",
    "ContextBudgeter",
    "ContextProfileLiteral",
    "ContextUsageBreakdown",
    "ContextWindowProfile",
    "FencedCallParseError",
    "FencedParseBatchResult",
    "IncrementalFencedToolParser",
    "ParsedFencedToolCall",
    "build_tool_call_repair_prompt",
    "compact_history_messages",
    "format_fenced_tool_instructions",
    "parse_fenced_tool_calls",
    "resolve_context_profile",
    "select_relevant_tools",
    "validate_agent_preset",
]
