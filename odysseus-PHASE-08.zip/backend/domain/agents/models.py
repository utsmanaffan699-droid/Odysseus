"""Agent preset models and validation."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from backend.domain.events import RunBudget


class AgentPreset(BaseModel):
    """Configuration for a reusable agent persona."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(min_length=1, max_length=64)
    name: str = Field(min_length=1, max_length=128)
    system_prompt: str = Field(default="You are Odysseus, a helpful and secure AI assistant.")
    model: str = Field(default="fake/default", min_length=1)
    tools: list[str] = Field(default_factory=list)
    skills: list[str] = Field(default_factory=list)
    budget: RunBudget = Field(default_factory=RunBudget)
    memory_scope: str = Field(default="user", pattern="^(user|project|none)$")


def validate_agent_preset(preset: AgentPreset, allowed_tools: set[str]) -> AgentPreset:
    """Verify that an agent preset only references registered tools."""
    unknown = [t for t in preset.tools if t not in allowed_tools]
    if unknown:
        raise ValueError(f"Agent preset references unknown tools: {', '.join(sorted(unknown))}")
    return preset
