"""Tolerant incremental parser for text-fenced tool calls with torture-test defenses."""

from __future__ import annotations

import codecs
import json
import re
from dataclasses import dataclass, field
from typing import Any

import yaml

_FENCE_HEADERS = ("tool_call", "tool-call", "tool", "function_call")
_XML_TAG_RE = re.compile(r"<tool_call>(.*?)(?:</tool_call>|$)", re.DOTALL | re.IGNORECASE)
_UNQUOTED_KEY_RE = re.compile(r"([{,]\s*)([A-Za-z_][A-Za-z0-9_-]*)(\s*:)")
_VALID_TOOL_NAME_RE = re.compile(r"^[A-Za-z0-9_.:-]+$")


def _reject_json_constant(val: str) -> Any:
    raise ValueError(f"Non-standard JSON constant {val!r} is forbidden")


@dataclass(frozen=True)
class ParsedFencedToolCall:
    """A validated tool call extracted from a text-fenced block."""

    call_id: str
    name: str
    args: dict[str, Any]
    raw_block: str
    repaired_syntax: bool = False


@dataclass(frozen=True)
class FencedCallParseError:
    """Structured parse error for a malformed or abusive tool-call block."""

    code: str
    message: str
    raw_snippet: str


@dataclass(frozen=True)
class FencedParseBatchResult:
    """Result of parsing an assistant message for text-fenced tool calls."""

    prose_text: str
    calls: list[ParsedFencedToolCall] = field(default_factory=list)
    errors: list[FencedCallParseError] = field(default_factory=list)
    has_incomplete_fence: bool = False

    @property
    def ok(self) -> bool:
        return len(self.errors) == 0 and not self.has_incomplete_fence


def format_fenced_tool_instructions(tool_specs: list[dict[str, Any]]) -> str:
    """Build compact fenced-block grammar instructions for models without native tool support."""
    lines = [
        "When you need to call a tool, emit a fenced block using this exact format:",
        "```tool_call",
        '{"name": "<tool_name>", "args": {"<param>": "<value>"}}',
        "```",
        "You may emit multiple ```tool_call blocks in a single turn if the calls are independent.",
        "Available tools:",
    ]
    for spec in tool_specs:
        name = str(spec.get("name", ""))
        desc = str(spec.get("description", "")).strip()
        params = spec.get("parameters", {})
        props = params.get("properties", {}) if isinstance(params, dict) else {}
        req = set(params.get("required", [])) if isinstance(params, dict) else set()
        arg_parts: list[str] = []
        if isinstance(props, dict):
            for k, v in props.items():
                ptype = v.get("type", "any") if isinstance(v, dict) else "any"
                opt = "" if k in req else "?"
                arg_parts.append(f"{k}{opt}:{ptype}")
        sig = f"- {name}({', '.join(arg_parts)}): {desc}"
        lines.append(sig)
    return "\n".join(lines)


def build_tool_call_repair_prompt(errors: list[FencedCallParseError]) -> str:
    """Construct a concise single-step repair prompt when fenced tool call parsing fails."""
    err_lines = [f"- [{e.code}] {e.message} (snippet: {e.raw_snippet!r})" for e in errors[:5]]
    return (
        "[Tool Call Parse Error]\n"
        "Your previous tool call block could not be parsed:\n"
        + "\n".join(err_lines)
        + "\nPlease re-emit the tool call as valid JSON inside a ```tool_call fence:\n"
        "```tool_call\n"
        '{"name": "<tool_name>", "args": {...}}\n'
        "```"
    )


def _check_torture_limits(
    raw: str,
    *,
    max_block_bytes: int,
    max_depth: int,
    max_number_digits: int,
) -> FencedCallParseError | None:
    """Enforce strict size, nesting depth, and numeric digit bounds in linear O(N) time."""
    raw_bytes_len = len(raw.encode("utf-8", errors="replace"))
    if raw_bytes_len > max_block_bytes:
        return FencedCallParseError(
            code="block_too_large",
            message=f"Tool call block size ({raw_bytes_len} B) exceeds cap ({max_block_bytes} B)",
            raw_snippet=raw[:120],
        )

    depth = 0
    in_str = False
    quote_ch = ""
    escaped = False
    num_run = 0

    for ch in raw:
        if in_str:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == quote_ch:
                in_str = False
            continue

        if ch in ('"', "'"):
            in_str = True
            quote_ch = ch
            num_run = 0
            continue

        if ch in ("{", "["):
            depth += 1
            if depth > max_depth:
                return FencedCallParseError(
                    code="max_depth_exceeded",
                    message=f"JSON nesting depth exceeds maximum allowed ({max_depth})",
                    raw_snippet=raw[:120],
                )
            num_run = 0
        elif ch in ("}", "]"):
            depth = max(0, depth - 1)
            num_run = 0
        elif ch.isdigit() or (num_run > 0 and ch in ("e", "E", "+", "-", ".")):
            num_run += 1
            if num_run > max_number_digits:
                return FencedCallParseError(
                    code="number_too_large",
                    message=f"Numeric literal exceeds {max_number_digits} characters",
                    raw_snippet=raw[:120],
                )
        else:
            num_run = 0

    return None


def _normalize_tolerant_json(candidate: str) -> str:
    """Repair common LLM JSON mistakes: BOM, inner fences, single quotes, trailing commas."""
    s = candidate.lstrip("\ufeff").replace("\x00", "").strip()

    # Strip inner markdown code fence if model wrapped ```json inside <tool_call> or ```tool_call
    if s.startswith("```"):
        first_nl = s.find("\n")
        if first_nl != -1:
            s = s[first_nl + 1 :]
        if s.endswith("```"):
            s = s[:-3]
        s = s.strip()

    # Fast path when no quotes or commas exist in candidate
    if '"' not in s and "'" not in s and "," not in s:
        return _quote_unquoted_keys_outside_strings(s)

    # Convert single-quoted strings to double-quoted strings and strip trailing commas
    out: list[str] = []
    i = 0
    n = len(s)
    in_double = False
    in_single = False

    while i < n:
        ch = s[i]
        if in_double:
            if ch == "\\" and i + 1 < n:
                out.append(ch)
                out.append(s[i + 1])
                i += 2
                continue
            if ch == '"':
                in_double = False
            elif ch == "\n":
                out.append("\\n")
                i += 1
                continue
            out.append(ch)
            i += 1
            continue

        if in_single:
            if ch == "\\" and i + 1 < n:
                nxt = s[i + 1]
                if nxt == "'":
                    out.append("'")
                elif nxt == '"':
                    out.append('\\"')
                else:
                    out.append("\\")
                    out.append(nxt)
                i += 2
                continue
            if ch == "'":
                in_single = False
                out.append('"')
                i += 1
                continue
            if ch == '"':
                out.append('\\"')
                i += 1
                continue
            if ch == "\n":
                out.append("\\n")
                i += 1
                continue
            out.append(ch)
            i += 1
            continue

        if ch == '"':
            in_double = True
            out.append(ch)
            i += 1
            continue

        if ch == "'":
            in_single = True
            out.append('"')
            i += 1
            continue

        # Check for trailing comma before } or ]
        if ch == ",":
            j = i + 1
            while j < n and s[j] in (" ", "\t", "\r", "\n"):
                j += 1
            if j < n and s[j] in ("}", "]"):
                i += 1
                continue

        out.append(ch)
        i += 1

    repaired = "".join(out)

    # Quote simple unquoted keys outside strings if needed
    repaired = _quote_unquoted_keys_outside_strings(repaired)
    return repaired


def _quote_unquoted_keys_outside_strings(s: str) -> str:
    """Quote unquoted identifier keys at object boundaries while preserving string literals."""
    if ":" not in s:
        return s
    if '"' not in s:
        return _UNQUOTED_KEY_RE.sub(r'\1"\2"\3', s)
    segments: list[str] = []
    last = 0
    in_str = False
    escaped = False
    for idx, ch in enumerate(s):
        if in_str:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == '"':
                in_str = False
                segments.append(s[last : idx + 1])
                last = idx + 1
        else:
            if ch == '"':
                non_str = s[last:idx]
                segments.append(_UNQUOTED_KEY_RE.sub(r'\1"\2"\3', non_str))
                last = idx
                in_str = True
    if last < len(s):
        tail = s[last:]
        if not in_str:
            tail = _UNQUOTED_KEY_RE.sub(r'\1"\2"\3', tail)
        segments.append(tail)
    return "".join(segments)


def _split_top_level_json_objects(s: str) -> list[str]:
    """Split a block containing one or more top-level JSON objects `{...}` or arrays `[...]`."""
    s_strip = s.strip()
    if not s_strip:
        return []
    if "{" not in s_strip and "[" not in s_strip:
        return [s_strip]
    objs: list[str] = []
    depth = 0
    start_idx: int | None = None
    in_str = False
    escaped = False

    for idx, ch in enumerate(s_strip):
        if in_str:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
            continue
        if ch == "{":
            if depth == 0:
                start_idx = idx
            depth += 1
        elif ch == "}":
            if depth > 0:
                depth -= 1
                if depth == 0 and start_idx is not None:
                    objs.append(s_strip[start_idx : idx + 1])
                    start_idx = None

    if not objs:
        return [s_strip]
    return objs


def _parse_single_json_object(
    raw_obj: str,
    *,
    reject_duplicate_keys: bool,
) -> tuple[dict[str, Any] | None, FencedCallParseError | None, bool]:
    """Parse a single JSON object with optional repair and duplicate key checking."""
    dup_key_found: str | None = None

    def _pairs_hook(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        nonlocal dup_key_found
        res: dict[str, Any] = {}
        for k, v in pairs:
            if reject_duplicate_keys and k in res and dup_key_found is None:
                dup_key_found = str(k)
            res[str(k)] = v
        return res

    cleaned = raw_obj.lstrip("\ufeff").replace("\x00", "").strip()
    repaired_used = False
    parsed: Any = None

    try:
        parsed = json.loads(
            cleaned,
            object_pairs_hook=_pairs_hook,
            parse_constant=_reject_json_constant,
        )
    except Exception:
        dup_key_found = None
        repaired_str = _normalize_tolerant_json(cleaned)
        repaired_used = repaired_str != cleaned
        try:
            parsed = json.loads(
                repaired_str,
                object_pairs_hook=_pairs_hook,
                parse_constant=_reject_json_constant,
            )
        except Exception as exc:
            # Tolerant YAML fallback for YAML-formatted fenced blocks (e.g. `name: read_file`)
            if ":" in cleaned and not cleaned.startswith("{") and not cleaned.startswith("["):
                try:
                    yaml_obj = yaml.safe_load(cleaned)
                    if isinstance(yaml_obj, dict):
                        parsed = yaml_obj
                        repaired_used = True
                except Exception as yaml_exc:
                    _ = yaml_exc
            if parsed is None:
                return (
                    None,
                    FencedCallParseError(
                        code="invalid_json",
                        message=f"Invalid tool-call JSON: {exc}",
                        raw_snippet=cleaned[:120],
                    ),
                    repaired_used,
                )

    if dup_key_found is not None:
        return (
            None,
            FencedCallParseError(
                code="duplicate_key",
                message=f"Duplicate JSON key '{dup_key_found}' in tool call",
                raw_snippet=cleaned[:120],
            ),
            repaired_used,
        )

    if not isinstance(parsed, dict):
        return (
            None,
            FencedCallParseError(
                code="non_object_payload",
                message="Tool call payload must be a JSON object",
                raw_snippet=cleaned[:120],
            ),
            repaired_used,
        )

    return parsed, None, repaired_used


def _extract_call_from_dict(
    payload: dict[str, Any],
    *,
    call_index: int,
    raw_block: str,
    repaired_syntax: bool,
) -> tuple[ParsedFencedToolCall | None, FencedCallParseError | None]:
    name = payload.get("name") or payload.get("tool") or payload.get("function")
    if not isinstance(name, str) or not name.strip():
        return (
            None,
            FencedCallParseError(
                code="missing_tool_name",
                message="Tool call JSON object must include a non-empty 'name' or 'tool' string",
                raw_snippet=raw_block[:120],
            ),
        )
    clean_name = name.strip()
    if not _VALID_TOOL_NAME_RE.match(clean_name):
        return (
            None,
            FencedCallParseError(
                code="invalid_tool_name",
                message=f"Invalid tool name {clean_name!r}",
                raw_snippet=raw_block[:120],
            ),
        )

    raw_args = payload.get("args")
    if raw_args is None:
        raw_args = payload.get("arguments")
    if raw_args is None:
        raw_args = payload.get("parameters", {})

    if isinstance(raw_args, str):
        try:
            loaded = json.loads(_normalize_tolerant_json(raw_args))
            if isinstance(loaded, dict):
                raw_args = loaded
            else:
                return (
                    None,
                    FencedCallParseError(
                        code="invalid_tool_args",
                        message="Tool 'args' must be a JSON object",
                        raw_snippet=raw_block[:120],
                    ),
                )
        except Exception as exc:
            return (
                None,
                FencedCallParseError(
                    code="invalid_tool_args",
                    message=f"Malformed stringified tool 'args': {exc}",
                    raw_snippet=raw_block[:120],
                ),
            )

    if not isinstance(raw_args, dict):
        return (
            None,
            FencedCallParseError(
                code="invalid_tool_args",
                message="Tool 'args' field must be a JSON object",
                raw_snippet=raw_block[:120],
            ),
        )

    call_id_raw = payload.get("id") or payload.get("call_id")
    call_id = (
        str(call_id_raw).strip()
        if isinstance(call_id_raw, str) and call_id_raw.strip()
        else f"fenced_call_{call_index}"
    )

    return (
        ParsedFencedToolCall(
            call_id=call_id,
            name=name.strip(),
            args=dict(raw_args),
            raw_block=raw_block,
            repaired_syntax=repaired_syntax,
        ),
        None,
    )


def parse_fenced_tool_calls(
    text: str,
    *,
    max_block_bytes: int = 262_144,
    max_depth: int = 64,
    max_number_digits: int = 64,
    reject_duplicate_keys: bool = True,
) -> FencedParseBatchResult:
    """Tolerantly parse all fenced or XML-tagged tool calls from model output.

    Guaranteed never to raise on any arbitrary input string.
    """
    try:
        if not text:
            return FencedParseBatchResult(prose_text="")

        cleaned_input = text.lstrip("\ufeff").replace("\x00", "")
        # Fast pre-check if the entire single-line input is a huge torture payload
        if len(cleaned_input.encode("utf-8", errors="replace")) > max_block_bytes * 2:
            if "tool_call" in cleaned_input[:256] or "<tool_call>" in cleaned_input[:256]:
                return FencedParseBatchResult(
                    prose_text="",
                    calls=[],
                    errors=[
                        FencedCallParseError(
                            code="block_too_large",
                            message=(
                                f"Input size exceeds maximum tool-call buffer ({max_block_bytes} B)"
                            ),
                            raw_snippet=cleaned_input[:120],
                        )
                    ],
                )

        calls: list[ParsedFencedToolCall] = []
        errors: list[FencedCallParseError] = []
        prose_parts: list[str] = []
        has_incomplete = False
        call_counter = 0

        # 1. Scan markdown fences line-by-line
        lines = cleaned_input.splitlines(keepends=True)
        in_fence = False
        fence_marker = ""
        fence_lang = ""
        fence_buf: list[str] = []

        for line in lines:
            stripped = line.strip()
            if not in_fence:
                if stripped.startswith("```") or stripped.startswith("~~~"):
                    marker_char = stripped[0]
                    marker_len = 0
                    for ch in stripped:
                        if ch == marker_char:
                            marker_len += 1
                        else:
                            break
                    lang = stripped[marker_len:].strip().lower()
                    if lang in _FENCE_HEADERS or lang == "json":
                        in_fence = True
                        fence_marker = marker_char * marker_len
                        fence_lang = lang
                        fence_buf = [line]
                        continue
                prose_parts.append(line)
            else:
                if stripped.startswith(fence_marker) and stripped.strip(fence_marker[0]) == "":
                    # Closed fence
                    body = "".join(fence_buf[1:])
                    full_block = "".join(fence_buf) + line
                    in_fence = False
                    fence_buf = []
                    _process_candidate_block(
                        body,
                        full_block=full_block,
                        is_explicit_tool_fence=(fence_lang in _FENCE_HEADERS),
                        prose_parts=prose_parts,
                        calls=calls,
                        errors=errors,
                        call_counter_start=len(calls),
                        max_block_bytes=max_block_bytes,
                        max_depth=max_depth,
                        max_number_digits=max_number_digits,
                        reject_duplicate_keys=reject_duplicate_keys,
                    )
                else:
                    fence_buf.append(line)

        if in_fence and fence_buf:
            has_incomplete = True
            body = "".join(fence_buf[1:])
            full_block = "".join(fence_buf)
            # Attempt tolerant parse if JSON object inside unclosed fence is already complete
            before_calls = len(calls)
            temp_errors: list[FencedCallParseError] = []
            _process_candidate_block(
                body,
                full_block=full_block,
                is_explicit_tool_fence=(fence_lang in _FENCE_HEADERS),
                prose_parts=[],
                calls=calls,
                errors=temp_errors,
                call_counter_start=before_calls,
                max_block_bytes=max_block_bytes,
                max_depth=max_depth,
                max_number_digits=max_number_digits,
                reject_duplicate_keys=reject_duplicate_keys,
            )
            if len(calls) == before_calls and fence_lang in _FENCE_HEADERS:
                errors.extend(temp_errors)

        # 2. Also scan prose_parts for <tool_call>...</tool_call> XML blocks
        joined_prose = "".join(prose_parts)
        if "<tool_call" in joined_prose.lower():
            new_prose_chunks: list[str] = []
            last_end = 0
            for match in _XML_TAG_RE.finditer(joined_prose):
                new_prose_chunks.append(joined_prose[last_end : match.start()])
                xml_body = match.group(1)
                xml_full = match.group(0)
                if not xml_full.lower().endswith("</tool_call>"):
                    has_incomplete = True
                _process_candidate_block(
                    xml_body,
                    full_block=xml_full,
                    is_explicit_tool_fence=True,
                    prose_parts=[],
                    calls=calls,
                    errors=errors,
                    call_counter_start=len(calls),
                    max_block_bytes=max_block_bytes,
                    max_depth=max_depth,
                    max_number_digits=max_number_digits,
                    reject_duplicate_keys=reject_duplicate_keys,
                )
                last_end = match.end()
            new_prose_chunks.append(joined_prose[last_end:])
            joined_prose = "".join(new_prose_chunks)

        _ = call_counter
        return FencedParseBatchResult(
            prose_text=joined_prose.strip(),
            calls=calls,
            errors=errors,
            has_incomplete_fence=has_incomplete,
        )
    except Exception as exc:
        return FencedParseBatchResult(
            prose_text="",
            calls=[],
            errors=[
                FencedCallParseError(
                    code="internal_parser_guard",
                    message=f"Parser guard caught unexpected error: {exc}",
                    raw_snippet=str(text)[:80],
                )
            ],
            has_incomplete_fence=False,
        )


def _process_candidate_block(
    body: str,
    *,
    full_block: str,
    is_explicit_tool_fence: bool,
    prose_parts: list[str],
    calls: list[ParsedFencedToolCall],
    errors: list[FencedCallParseError],
    call_counter_start: int,
    max_block_bytes: int,
    max_depth: int,
    max_number_digits: int,
    reject_duplicate_keys: bool,
) -> None:
    limit_err = _check_torture_limits(
        body,
        max_block_bytes=max_block_bytes,
        max_depth=max_depth,
        max_number_digits=max_number_digits,
    )
    if limit_err is not None:
        if is_explicit_tool_fence:
            errors.append(limit_err)
        else:
            prose_parts.append(full_block)
        return

    norm_body = _normalize_tolerant_json(body)
    obj_strings = _split_top_level_json_objects(norm_body)
    if not obj_strings:
        if is_explicit_tool_fence:
            errors.append(
                FencedCallParseError(
                    code="empty_tool_block",
                    message="Empty tool_call block",
                    raw_snippet=body[:80],
                )
            )
        else:
            prose_parts.append(full_block)
        return

    extracted_any = False
    for idx, obj_str in enumerate(obj_strings):
        parsed_dict, parse_err, repaired = _parse_single_json_object(
            obj_str,
            reject_duplicate_keys=reject_duplicate_keys,
        )
        if parse_err is not None:
            if is_explicit_tool_fence:
                errors.append(parse_err)
            continue

        assert parsed_dict is not None
        # If this is a ```json block, only treat it as a tool call if it looks like one
        if not is_explicit_tool_fence and not (
            ("name" in parsed_dict or "tool" in parsed_dict)
            and ("args" in parsed_dict or "arguments" in parsed_dict)
        ):
            continue

        call_obj, call_err = _extract_call_from_dict(
            parsed_dict,
            call_index=call_counter_start + idx + 1,
            raw_block=obj_str,
            repaired_syntax=repaired or (norm_body != body.strip()),
        )
        if call_err is not None:
            if is_explicit_tool_fence:
                errors.append(call_err)
            continue
        if call_obj is not None:
            calls.append(call_obj)
            extracted_any = True

    if not extracted_any and not is_explicit_tool_fence:
        prose_parts.append(full_block)


class IncrementalFencedToolParser:
    """Stateful incremental parser for streaming text-fenced tool calls."""

    def __init__(
        self,
        *,
        max_block_bytes: int = 262_144,
        max_depth: int = 64,
        max_number_digits: int = 64,
    ) -> None:
        self._chunks: list[str] = []
        self._utf8_decoder = codecs.getincrementaldecoder("utf-8")(errors="replace")
        self._max_block_bytes = max_block_bytes
        self._max_depth = max_depth
        self._max_number_digits = max_number_digits

    def feed(self, delta: str) -> FencedParseBatchResult:
        """Append a streamed text delta and return the current parse snapshot."""
        if delta:
            self._chunks.append(delta)
        return parse_fenced_tool_calls(
            "".join(self._chunks),
            max_block_bytes=self._max_block_bytes,
            max_depth=self._max_depth,
            max_number_digits=self._max_number_digits,
        )

    def feed_bytes(self, raw_chunk: bytes) -> FencedParseBatchResult:
        """Decode arbitrary UTF-8 byte chunks (including mid-codepoint splits) and feed."""
        decoded = self._utf8_decoder.decode(raw_chunk, final=False)
        return self.feed(decoded)

    def finish(self) -> FencedParseBatchResult:
        """Finalize parsing at the end of a model turn."""
        tail = self._utf8_decoder.decode(b"", final=True)
        if tail:
            self._chunks.append(tail)
        return parse_fenced_tool_calls(
            "".join(self._chunks),
            max_block_bytes=self._max_block_bytes,
            max_depth=self._max_depth,
            max_number_digits=self._max_number_digits,
        )

    def finalize(self) -> FencedParseBatchResult:
        """Alias for finish()."""
        return self.finish()
