"""Deterministic event reducer reconstructing RunViewState from ordered RunEventEnvelopes."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Any

from backend.domain.events import RunEventEnvelope


@dataclass
class PartState:
    part_id: str
    message_id: str
    type: str
    text: str = ""
    finished: bool = False


@dataclass
class ToolCallState:
    call_id: str
    name: str
    args: dict[str, Any]
    risk: str
    status: str = "proposed"
    approval_id: str | None = None
    approval_decision: str | None = None
    stdout: str = ""
    stderr: str = ""
    pct: float | None = None
    progress_label: str = ""
    ok: bool | None = None
    summary: str = ""
    render_hint: str = "text"


@dataclass
class ArtifactState:
    artifact_id: str
    type: str
    title: str
    version: int = 1
    content: str = ""
    summary: str = ""


@dataclass
class SubagentState:
    child_run_id: str
    task: str
    status: str = "running"
    summary: str = ""


@dataclass
class RunViewState:
    run_id: str = ""
    model: str = ""
    status: str = "queued"
    finish_reason: str | None = None
    last_seq: int = 0
    steps: dict[str, dict[str, Any]] = field(default_factory=dict)
    parts: dict[str, PartState] = field(default_factory=dict)
    plan: list[dict[str, str]] = field(default_factory=list)
    tool_calls: dict[str, ToolCallState] = field(default_factory=dict)
    subagents: dict[str, SubagentState] = field(default_factory=dict)
    artifacts: dict[str, ArtifactState] = field(default_factory=dict)
    citations: list[dict[str, Any]] = field(default_factory=list)
    sources_opened: list[dict[str, str]] = field(default_factory=list)
    memories_used: list[str] = field(default_factory=list)
    memories_updated: list[dict[str, str]] = field(default_factory=list)
    notices: list[dict[str, str]] = field(default_factory=list)
    steers: list[str] = field(default_factory=list)
    usage: dict[str, Any] = field(
        default_factory=lambda: {
            "input": 0,
            "output": 0,
            "cached": 0,
            "reasoning": 0,
            "cost": 0.0,
        }
    )
    error: dict[str, Any] | None = None
    resync_cursor: int | None = None


def reduce_run_state(
    events: Sequence[RunEventEnvelope],
    *,
    initial: RunViewState | None = None,
) -> RunViewState:
    """Fold an ordered sequence of RunEventEnvelopes into a deterministic RunViewState."""
    state = initial if initial is not None else RunViewState()

    for ev in events:
        if state.run_id and ev.run_id != state.run_id:
            raise ValueError(f"Mismatched run_id in stream: {ev.run_id} != {state.run_id}")
        if ev.seq <= state.last_seq:
            raise ValueError(
                f"Non-monotonic event sequence: got seq={ev.seq} after last_seq={state.last_seq}"
            )
        state.run_id = ev.run_id
        state.last_seq = ev.seq
        d = ev.data
        t = ev.type

        if t == "run.started":
            state.model = str(d["model"])
            state.status = "running"
        elif t == "run.status":
            state.status = str(d["status"])
        elif t == "run.finished":
            state.finish_reason = str(d["reason"])
            state.status = (
                "completed" if state.finish_reason == "completed" else state.finish_reason
            )
            state.usage.update(d.get("usage", {}))
        elif t == "run.error":
            state.status = "error"
            state.error = dict(d)
        elif t == "step.started":
            sid = str(d["step_id"])
            state.steps[sid] = {
                "step_id": sid,
                "index": int(d["index"]),
                "kind": str(d["kind"]),
                "status": "running",
                "duration_ms": 0,
            }
        elif t == "step.finished":
            sid = str(d["step_id"])
            if sid in state.steps:
                state.steps[sid]["status"] = str(d["status"])
                state.steps[sid]["duration_ms"] = int(d["duration_ms"])
        elif t == "message.part.started":
            pid = str(d["part_id"])
            state.parts[pid] = PartState(
                part_id=pid,
                message_id=str(d["message_id"]),
                type=str(d["type"]),
            )
        elif t in ("message.text.delta", "message.thinking.delta"):
            pid = str(d["part_id"])
            part = state.parts.get(pid)
            if part is not None:
                part.text += str(d["text"])
        elif t == "message.part.finished":
            pid = str(d["part_id"])
            part = state.parts.get(pid)
            if part is not None:
                part.finished = True
        elif t == "message.finished":
            state.usage.update(d.get("usage", {}))
        elif t == "plan.updated":
            state.plan = [dict(item) for item in d.get("items", [])]
        elif t == "tool.call.proposed":
            cid = str(d["call_id"])
            state.tool_calls[cid] = ToolCallState(
                call_id=cid,
                name=str(d["name"]),
                args=dict(d.get("args", {})),
                risk=str(d["risk"]),
                status="proposed",
            )
        elif t == "tool.approval.requested":
            cid = str(d["call_id"])
            tc = state.tool_calls.get(cid)
            if tc is not None:
                tc.status = "waiting_approval"
                tc.approval_id = str(d["approval_id"])
            state.status = "waiting_approval"
        elif t == "tool.approval.resolved":
            aid = str(d["approval_id"])
            decision = str(d["decision"])
            for tc in state.tool_calls.values():
                if tc.approval_id == aid:
                    tc.approval_decision = decision
                    tc.status = "approved" if decision == "approve" else "denied"
            if state.status == "waiting_approval":
                state.status = "running"
        elif t == "tool.started":
            cid = str(d["call_id"])
            tc = state.tool_calls.get(cid)
            if tc is not None:
                tc.status = "running"
        elif t == "tool.output.delta":
            cid = str(d["call_id"])
            tc = state.tool_calls.get(cid)
            if tc is not None:
                if d.get("stream") == "stderr":
                    tc.stderr += str(d["text"])
                else:
                    tc.stdout += str(d["text"])
        elif t == "tool.progress":
            cid = str(d["call_id"])
            tc = state.tool_calls.get(cid)
            if tc is not None:
                tc.pct = float(d["pct"]) if d.get("pct") is not None else None
                tc.progress_label = str(d["label"])
        elif t == "tool.result":
            cid = str(d["call_id"])
            tc = state.tool_calls.get(cid)
            if tc is not None:
                tc.ok = bool(d["ok"])
                tc.status = "succeeded" if tc.ok else "failed"
                tc.summary = str(d["summary"])
                tc.render_hint = str(d.get("render_hint", "text"))
        elif t == "tool.denied":
            cid = str(d["call_id"])
            tc = state.tool_calls.get(cid)
            if tc is not None:
                tc.status = "denied"
                tc.summary = str(d["reason"])
        elif t == "subagent.started":
            crid = str(d["child_run_id"])
            state.subagents[crid] = SubagentState(
                child_run_id=crid,
                task=str(d["task"]),
            )
        elif t == "subagent.finished":
            crid = str(d["child_run_id"])
            sub = state.subagents.get(crid)
            if sub is not None:
                sub.status = str(d["status"])
                sub.summary = str(d["summary"])
        elif t == "citation.added":
            state.citations.append(dict(d["citation"]))
        elif t == "source.opened":
            state.sources_opened.append({"url": str(d["url"]), "title": str(d["title"])})
        elif t == "memory.used":
            for mid in d.get("ids", []):
                if mid not in state.memories_used:
                    state.memories_used.append(str(mid))
        elif t == "memory.updated":
            state.memories_updated.append({"id": str(d["id"]), "op": str(d["op"])})
        elif t == "artifact.created":
            art_id = str(d["artifact_id"])
            state.artifacts[art_id] = ArtifactState(
                artifact_id=art_id,
                type=str(d["type"]),
                title=str(d["title"]),
                version=1,
            )
        elif t == "artifact.delta":
            art_id = str(d["artifact_id"])
            art = state.artifacts.get(art_id)
            if art is not None:
                art.version = int(d["version"])
                art.content += str(d["text"])
        elif t == "artifact.version":
            art_id = str(d["artifact_id"])
            art = state.artifacts.get(art_id)
            if art is not None:
                art.version = int(d["version"])
                art.summary = str(d["summary"])
        elif t == "usage.updated":
            state.usage.update(d)
        elif t == "context.compacted":
            state.notices.append(
                {
                    "level": "info",
                    "code": "context_compacted",
                    "text": f"Compacted {d['removed_tokens']} tokens",
                }
            )
        elif t == "notice":
            state.notices.append(
                {
                    "level": str(d["level"]),
                    "code": str(d["code"]),
                    "text": str(d["text"]),
                }
            )
        elif t == "steer.received":
            state.steers.append(str(d["text"]))
        elif t == "stream.resync":
            state.resync_cursor = int(d["cursor"])

    return state
