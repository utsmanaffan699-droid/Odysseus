"""Usage and Decimal cost accounting ledger and rollup queries."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from decimal import Decimal
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.db import DatabaseManager
from backend.core.models import UsageLedgerRecord
from backend.core.uow import UnitOfWork, _ensure_utc
from backend.providers.capabilities import (
    compute_cost_decimal,
    format_cost_usd,
    resolve_model_capabilities,
)


class UsageService:
    """Records per-call token usage with Decimal costs and computes multi-axis rollups."""

    def __init__(self, db: DatabaseManager) -> None:
        self.db = db

    async def record_usage(
        self,
        *,
        user_id: str,
        model: str,
        input_tokens: int,
        output_tokens: int,
        cached_tokens: int = 0,
        reasoning_tokens: int = 0,
        project_id: str | None = None,
        chat_id: str | None = None,
        run_id: str | None = None,
        message_id: str | None = None,
    ) -> dict[str, Any]:
        now = datetime.now(UTC)
        day_str = now.strftime("%Y-%m-%d")
        provider_id = model.split("/", 1)[0] if "/" in model else "local"
        caps = resolve_model_capabilities(model)
        cost_dec = compute_cost_decimal(
            caps,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cached_tokens=cached_tokens,
            reasoning_tokens=reasoning_tokens,
        )
        cost_str = format_cost_usd(cost_dec)
        entry_id = f"usg_{uuid.uuid4().hex[:20]}"

        async def _tx(sess: AsyncSession) -> dict[str, Any]:
            uow = UnitOfWork(sess)
            rec = UsageLedgerRecord(
                id=entry_id,
                user_id=user_id,
                project_id=project_id,
                chat_id=chat_id,
                run_id=run_id,
                message_id=message_id,
                provider=provider_id,
                model=model,
                day=day_str,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                cached_tokens=cached_tokens,
                reasoning_tokens=reasoning_tokens,
                cost_usd=cost_str,
                created_at=now,
            )
            await uow.usage.add(rec)
            return {
                "id": rec.id,
                "input": input_tokens,
                "output": output_tokens,
                "cached": cached_tokens,
                "reasoning": reasoning_tokens,
                "cost": float(cost_dec),
                "cost_usd": cost_str,
            }

        return await self.db.execute_write(_tx)

    async def get_rollups(
        self,
        *,
        user_id: str | None = None,
        project_id: str | None = None,
        model: str | None = None,
    ) -> dict[str, Any]:
        """Compute rollups by day, model, project, and user using exact Decimal arithmetic."""

        async def _load(sess: AsyncSession) -> list[UsageLedgerRecord]:
            uow = UnitOfWork(sess)
            return await uow.usage.list_entries(
                user_id=user_id,
                project_id=project_id,
                model=model,
            )

        rows = await self.db.execute_read(_load)

        total_in = 0
        total_out = 0
        total_cached = 0
        total_reasoning = 0
        total_cost = Decimal("0.00000000")

        by_day: dict[str, dict[str, Any]] = {}
        by_model: dict[str, dict[str, Any]] = {}
        by_project: dict[str, dict[str, Any]] = {}
        by_user: dict[str, dict[str, Any]] = {}

        def _acc(
            bucket: dict[str, dict[str, Any]], key: str, r: UsageLedgerRecord, c: Decimal
        ) -> None:
            if key not in bucket:
                bucket[key] = {
                    "key": key,
                    "calls": 0,
                    "input_tokens": 0,
                    "output_tokens": 0,
                    "cached_tokens": 0,
                    "reasoning_tokens": 0,
                    "_cost_dec": Decimal("0.00000000"),
                }
            item = bucket[key]
            item["calls"] += 1
            item["input_tokens"] += r.input_tokens
            item["output_tokens"] += r.output_tokens
            item["cached_tokens"] += r.cached_tokens
            item["reasoning_tokens"] += r.reasoning_tokens
            item["_cost_dec"] += c

        for r in rows:
            c_dec = Decimal(r.cost_usd or "0.00000000")
            total_in += r.input_tokens
            total_out += r.output_tokens
            total_cached += r.cached_tokens
            total_reasoning += r.reasoning_tokens
            total_cost += c_dec

            _acc(by_day, r.day, r, c_dec)
            _acc(by_model, r.model, r, c_dec)
            _acc(by_project, r.project_id or "unassigned", r, c_dec)
            _acc(by_user, r.user_id, r, c_dec)

        def _finalize(bucket: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
            out_list: list[dict[str, Any]] = []
            for k in sorted(bucket.keys()):
                item = dict(bucket[k])
                c_val: Decimal = item.pop("_cost_dec")
                item["cost_usd"] = format_cost_usd(c_val)
                item["cost"] = float(c_val)
                out_list.append(item)
            return out_list

        return {
            "totals": {
                "calls": len(rows),
                "input_tokens": total_in,
                "output_tokens": total_out,
                "cached_tokens": total_cached,
                "reasoning_tokens": total_reasoning,
                "cost_usd": format_cost_usd(total_cost),
                "cost": float(total_cost),
            },
            "by_day": _finalize(by_day),
            "by_model": _finalize(by_model),
            "by_project": _finalize(by_project),
            "by_user": _finalize(by_user),
            "entries": [
                {
                    "id": r.id,
                    "user_id": r.user_id,
                    "project_id": r.project_id,
                    "chat_id": r.chat_id,
                    "run_id": r.run_id,
                    "message_id": r.message_id,
                    "provider": r.provider,
                    "model": r.model,
                    "day": r.day,
                    "input_tokens": r.input_tokens,
                    "output_tokens": r.output_tokens,
                    "cached_tokens": r.cached_tokens,
                    "reasoning_tokens": r.reasoning_tokens,
                    "cost_usd": r.cost_usd,
                    "created_at": _ensure_utc(r.created_at).isoformat(),
                }
                for r in rows[:100]
            ],
        }
