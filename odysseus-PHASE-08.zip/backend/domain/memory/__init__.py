"""Memory domain package: semantic + BM25 fallback, privacy switch, TTL, dedup, export."""

from backend.domain.memory.service import (
    MemoryScopeLiteral,
    MemoryService,
    compute_bm25_score,
    compute_text_embedding,
    cosine_similarity,
)

__all__ = [
    "MemoryScopeLiteral",
    "MemoryService",
    "compute_bm25_score",
    "compute_text_embedding",
    "cosine_similarity",
]
