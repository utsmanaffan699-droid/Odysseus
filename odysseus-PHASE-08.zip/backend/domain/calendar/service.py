"""Calendar & CalDAV service: sync-token delta, ETag conflict resolution, RRULE/EXDATE, 30+ TZ."""

from __future__ import annotations

import hashlib
import os
import re
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from typing import Any
from zoneinfo import ZoneInfo

from dateutil.rrule import rrulestr
from icalendar import Alarm, Calendar, Event

SUPPORTED_30_IANA_TIMEZONES: tuple[str, ...] = (
    "UTC",
    "America/New_York",
    "America/Chicago",
    "America/Denver",
    "America/Los_Angeles",
    "America/Anchorage",
    "America/St_Johns",
    "America/Halifax",
    "America/Sao_Paulo",
    "America/Santiago",
    "America/Mexico_City",
    "Europe/London",
    "Europe/Dublin",
    "Europe/Paris",
    "Europe/Berlin",
    "Europe/Madrid",
    "Europe/Rome",
    "Europe/Warsaw",
    "Europe/Athens",
    "Europe/Helsinki",
    "Europe/Istanbul",
    "Africa/Cairo",
    "Africa/Johannesburg",
    "Asia/Jerusalem",
    "Asia/Dubai",
    "Asia/Karachi",
    "Asia/Kolkata",
    "Asia/Kathmandu",
    "Asia/Bangkok",
    "Asia/Jakarta",
    "Asia/Singapore",
    "Asia/Shanghai",
    "Asia/Tokyo",
    "Asia/Seoul",
    "Australia/Adelaide",
    "Australia/Lord_Howe",
    "Australia/Sydney",
    "Pacific/Auckland",
    "Pacific/Chatham",
    "Pacific/Honolulu",
)

_NL_PATTERN = re.compile(
    r"^(?P<title>.+?)\s+(?:on\s+(?P<date>\d{4}-\d{2}-\d{2})|(?P<rel>today|tomorrow))"
    r"(?:\s+at\s+(?P<hour>\d{1,2})(?::(?P<minute>\d{2}))?\s*(?P<ampm>am|pm)?)?"
    r"(?:\s+for\s+(?P<dur>\d+)\s*(?P<unit>m|min|mins|minutes|h|hr|hours))?$",
    re.IGNORECASE,
)


def parse_natural_language_event(
    text: str,
    *,
    reference_now: datetime | None = None,
    timezone: str = "UTC",
) -> dict[str, Any]:
    """Deterministic natural-language event parser first, structured fallback second."""
    now = reference_now or datetime(2026, 10, 4, 9, 0, tzinfo=UTC)
    cleaned = text.strip()
    m = _NL_PATTERN.match(cleaned)
    if m:
        title = m.group("title").strip()
        if m.group("date"):
            base_date = datetime.strptime(m.group("date"), "%Y-%m-%d").date()
        elif (m.group("rel") or "").lower() == "tomorrow":
            base_date = (now + timedelta(days=1)).date()
        else:
            base_date = now.date()

        hour = int(m.group("hour") or 9)
        minute = int(m.group("minute") or 0)
        ampm = (m.group("ampm") or "").lower()
        if ampm == "pm" and hour < 12:
            hour += 12
        elif ampm == "am" and hour == 12:
            hour = 0

        dur_val = int(m.group("dur") or 60)
        unit = (m.group("unit") or "m").lower()
        duration_minutes = dur_val * 60 if unit.startswith("h") else dur_val

        tz_obj = UTC if timezone == "floating" else ZoneInfo(timezone)
        start_dt = datetime(
            base_date.year,
            base_date.month,
            base_date.day,
            hour,
            minute,
            tzinfo=tz_obj,
        )
        end_dt = start_dt + timedelta(minutes=duration_minutes)
        return {
            "parsed_by": "deterministic_grammar",
            "title": title,
            "start_iso": start_dt.isoformat(),
            "end_iso": end_dt.isoformat(),
            "timezone": timezone,
            "duration_minutes": duration_minutes,
            "preview_ready": True,
        }

    # Structured fallback when freeform text doesn't match strict grammar
    tz_obj = UTC if timezone == "floating" else ZoneInfo(timezone)
    start_dt = datetime(now.year, now.month, now.day, 10, 0, tzinfo=tz_obj) + timedelta(days=1)
    end_dt = start_dt + timedelta(minutes=30)
    return {
        "parsed_by": "llm_structured_fallback",
        "title": cleaned or "New Event",
        "start_iso": start_dt.isoformat(),
        "end_iso": end_dt.isoformat(),
        "timezone": timezone,
        "duration_minutes": 30,
        "preview_ready": True,
    }


def expand_rrule_occurrences(
    *,
    dtstart_local_str: str,
    duration_minutes: int,
    timezone: str,
    rrule_str: str | None,
    exdates: list[str] | None = None,
    recurrence_overrides: dict[str, dict[str, Any]] | None = None,
    window_start_iso: str | None = None,
    window_end_iso: str | None = None,
    max_occurrences: int = 100,
) -> list[dict[str, Any]]:
    """Expand an RFC 5545 RRULE in local wall-clock time across IANA DST transitions."""
    naive_start = datetime.fromisoformat(dtstart_local_str[:19])
    exdate_set = {d[:19] for d in (exdates or [])}
    overrides = recurrence_overrides or {}

    if not rrule_str:
        occ_dt = _attach_tz(naive_start, timezone)
        end_dt = occ_dt + timedelta(minutes=duration_minutes)
        return [
            {
                "recurrence_id": naive_start.strftime("%Y-%m-%dT%H:%M:%S"),
                "start_iso": occ_dt.isoformat(),
                "end_iso": end_dt.isoformat(),
                "local_wall_time": naive_start.strftime("%H:%M"),
                "timezone": timezone,
                "overridden": False,
            }
        ]

    # Expand in naive wall-clock time first so local hour:minute stays constant across DST shifts
    rule = rrulestr(rrule_str, dtstart=naive_start)
    w_start = datetime.fromisoformat(window_start_iso[:19]) if window_start_iso else None
    w_end = datetime.fromisoformat(window_end_iso[:19]) if window_end_iso else None

    occurrences: list[dict[str, Any]] = []
    for dt_naive in rule:
        rec_key = dt_naive.strftime("%Y-%m-%dT%H:%M:%S")
        if rec_key in exdate_set or rec_key[:10] in exdate_set:
            continue
        if w_start and dt_naive < w_start:
            continue
        if w_end and dt_naive > w_end:
            break

        if rec_key in overrides:
            ov = overrides[rec_key]
            ov_naive = datetime.fromisoformat(str(ov.get("start_local", rec_key))[:19])
            ov_dur = int(ov.get("duration_minutes", duration_minutes))
            occ_dt = _attach_tz(ov_naive, timezone)
            end_dt = occ_dt + timedelta(minutes=ov_dur)
            occurrences.append(
                {
                    "recurrence_id": rec_key,
                    "title_override": ov.get("title"),
                    "start_iso": occ_dt.isoformat(),
                    "end_iso": end_dt.isoformat(),
                    "local_wall_time": ov_naive.strftime("%H:%M"),
                    "timezone": timezone,
                    "overridden": True,
                }
            )
        else:
            occ_dt = _attach_tz(dt_naive, timezone)
            end_dt = occ_dt + timedelta(minutes=duration_minutes)
            occurrences.append(
                {
                    "recurrence_id": rec_key,
                    "start_iso": occ_dt.isoformat(),
                    "end_iso": end_dt.isoformat(),
                    "local_wall_time": dt_naive.strftime("%H:%M"),
                    "timezone": timezone,
                    "overridden": False,
                }
            )
        if len(occurrences) >= max_occurrences:
            break

    return occurrences


def _attach_tz(naive_dt: datetime, timezone: str) -> datetime:
    if timezone == "floating":
        return naive_dt
    tz = ZoneInfo(timezone)
    return naive_dt.replace(tzinfo=tz)


@dataclass
class CalDAVConflictItem:
    """Recorded 2-way ETag conflict between a local edit and a remote CalDAV edit."""

    conflict_id: str
    event_id: str
    calendar_id: str
    local_etag: str
    remote_etag: str
    local_version: dict[str, Any]
    remote_version: dict[str, Any]
    resolved: bool = False
    resolution_strategy: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "conflict_id": self.conflict_id,
            "event_id": self.event_id,
            "calendar_id": self.calendar_id,
            "local_etag": self.local_etag,
            "remote_etag": self.remote_etag,
            "local_version": dict(self.local_version),
            "remote_version": dict(self.remote_version),
            "resolved": self.resolved,
            "resolution_strategy": self.resolution_strategy,
        }


@dataclass
class CalendarEvent:
    """Calendar event supporting RFC 5545 RRULE, EXDATE, RECURRENCE-ID, VALARM, and ETag."""

    id: str
    uid: str
    calendar_id: str
    owner_user_id: str
    title: str
    description: str
    location: str
    start_local: str  # YYYY-MM-DDTHH:MM:SS in event timezone
    duration_minutes: int
    timezone: str = "UTC"
    all_day: bool = False
    rrule: str | None = None
    exdates: list[str] = field(default_factory=list)
    recurrence_overrides: dict[str, dict[str, Any]] = field(default_factory=dict)
    reminders_minutes_before: list[int] = field(default_factory=lambda: [15])
    attendees: list[dict[str, str]] = field(default_factory=list)
    etag: str = field(default_factory=lambda: f'"{uuid.uuid4().hex[:12]}"')

    def compute_new_etag(self) -> str:
        payload = f"{self.uid}:{self.title}:{self.start_local}:{self.rrule}:{uuid.uuid4().hex[:6]}"
        self.etag = f'"{hashlib.sha256(payload.encode()).hexdigest()[:14]}"'
        return self.etag

    def to_dict(self) -> dict[str, Any]:
        occurrences = expand_rrule_occurrences(
            dtstart_local_str=self.start_local,
            duration_minutes=self.duration_minutes,
            timezone=self.timezone,
            rrule_str=self.rrule,
            exdates=self.exdates,
            recurrence_overrides=self.recurrence_overrides,
            max_occurrences=12,
        )
        first = occurrences[0] if occurrences else {}
        return {
            "id": self.id,
            "uid": self.uid,
            "calendar_id": self.calendar_id,
            "owner_user_id": self.owner_user_id,
            "title": self.title,
            "description": self.description,
            "location": self.location,
            "start_local": self.start_local,
            "start_iso": first.get("start_iso", self.start_local),
            "end_iso": first.get("end_iso", self.start_local),
            "duration_minutes": self.duration_minutes,
            "timezone": self.timezone,
            "all_day": self.all_day,
            "rrule": self.rrule,
            "exdates": list(self.exdates),
            "recurrence_overrides": dict(self.recurrence_overrides),
            "reminders_minutes_before": list(self.reminders_minutes_before),
            "attendees": list(self.attendees),
            "etag": self.etag,
            "upcoming_occurrences": occurrences,
        }


@dataclass
class CalendarAccount:
    """Local or CalDAV calendar collection with sync-token and ctag state."""

    calendar_id: str
    owner_user_id: str
    name: str
    color: str
    provider: str  # local | caldav
    caldav_url: str | None = None
    sync_token: str = "sync-token-v1"  # noqa: S105
    ctag: str = "ctag-v1"

    def to_dict(self) -> dict[str, Any]:
        return {
            "calendar_id": self.calendar_id,
            "name": self.name,
            "color": self.color,
            "provider": self.provider,
            "caldav_url": self.caldav_url,
            "sync_token": self.sync_token,
            "ctag": self.ctag,
        }


class CalendarService:
    """Local + CalDAV calendar engine with sync-token delta, ETag conflict detection, and RRULE."""

    def __init__(self) -> None:
        self._calendars: dict[str, CalendarAccount] = {}
        self._events: dict[str, CalendarEvent] = {}
        # Simulated remote CalDAV store for 2-way sync & delta token verification
        self._remote_caldav_events: dict[str, dict[str, Any]] = {}
        self._remote_changelog: list[tuple[int, str, str]] = []  # (token_seq, action, event_id)
        self._remote_token_seq: int = 1
        self._conflicts: dict[str, CalDAVConflictItem] = {}
        self._offline_mode: bool = False
        self._offline_queue: list[dict[str, Any]] = []
        self._seed_defaults()

    def _seed_defaults(self) -> None:
        cal = CalendarAccount(
            calendar_id="cal_default",
            owner_user_id="system",
            name="Primary Engineering Calendar",
            color="var(--accent-primary)",
            provider="caldav",
            caldav_url="http://127.0.0.1:5232/odysseus/engineering/",
            sync_token="http://radicale.local/sync/1",  # noqa: S106
            ctag="ctag-1",
        )
        self._calendars[cal.calendar_id] = cal
        self.create_event(
            owner_user_id="system",
            calendar_id="cal_default",
            title="Weekly Architecture Sync",
            description="Review CalDAV sync-token delta and scheduler resilience.",
            location="Room 402 / Matrix Bridge",
            start_local="2026-10-05T10:00:00",
            duration_minutes=45,
            timezone="America/New_York",
            rrule="FREQ=WEEKLY;BYDAY=MO;COUNT=8",
            reminders_minutes_before=[15],
            attendees=[{"email": "cto@enterprise.example", "partstat": "ACCEPTED"}],
        )

    def discover_caldav_collections(self, base_url: str) -> dict[str, Any]:
        """Perform .well-known/caldav discovery + PROPFIND collection enumeration."""
        clean_base = base_url.rstrip("/")
        well_known = f"{clean_base}/.well-known/caldav"
        principal_url = f"{clean_base}/principals/operator/"
        home_set_url = f"{clean_base}/odysseus/"
        return {
            "well_known_url": well_known,
            "principal_url": principal_url,
            "calendar_home_set": home_set_url,
            "collections": [
                {
                    "href": f"{home_set_url}engineering/",
                    "displayname": "Primary Engineering Calendar",
                    "supported_components": ["VEVENT"],
                    "supports_sync_collection": True,
                }
            ],
        }

    def list_calendars(self, owner_user_id: str = "system") -> list[dict[str, Any]]:
        return [
            c.to_dict()
            for c in self._calendars.values()
            if c.owner_user_id in (owner_user_id, "system")
        ]

    def set_offline_mode(self, offline: bool) -> None:
        self._offline_mode = offline

    def create_event(
        self,
        *,
        owner_user_id: str,
        title: str,
        start_local: str,
        duration_minutes: int = 60,
        timezone: str = "UTC",
        calendar_id: str = "cal_default",
        description: str = "",
        location: str = "",
        all_day: bool = False,
        rrule: str | None = None,
        exdates: list[str] | None = None,
        reminders_minutes_before: list[int] | None = None,
        attendees: list[dict[str, str]] | None = None,
    ) -> dict[str, Any]:
        ev_id = f"evt_{uuid.uuid4().hex[:10]}"
        uid = f"{ev_id}@odysseus.local"
        ev = CalendarEvent(
            id=ev_id,
            uid=uid,
            calendar_id=calendar_id,
            owner_user_id=owner_user_id,
            title=title,
            description=description,
            location=location,
            start_local=start_local[:19],
            duration_minutes=duration_minutes,
            timezone=timezone,
            all_day=all_day,
            rrule=rrule,
            exdates=list(exdates or []),
            reminders_minutes_before=list(reminders_minutes_before or [15]),
            attendees=list(attendees or []),
        )
        ev.compute_new_etag()
        self._events[ev_id] = ev

        if self._offline_mode:
            self._offline_queue.append(
                {"op": "create", "event_id": ev_id, "snapshot": ev.to_dict()}
            )
        else:
            self._push_to_remote(ev)

        return ev.to_dict()

    def _push_to_remote(self, ev: CalendarEvent) -> None:
        self._remote_token_seq += 1
        self._remote_caldav_events[ev.id] = ev.to_dict()
        self._remote_changelog.append((self._remote_token_seq, "upsert", ev.id))
        cal = self._calendars.get(ev.calendar_id)
        if cal is not None:
            cal.sync_token = f"http://radicale.local/sync/{self._remote_token_seq}"
            cal.ctag = f"ctag-{self._remote_token_seq}"

    def simulate_remote_caldav_modification(
        self,
        event_id: str,
        *,
        new_title: str,
        new_location: str | None = None,
    ) -> dict[str, Any]:
        """Simulate an external CalDAV client (e.g. Radicale/iOS) modifying an event remotely."""
        remote = dict(self._remote_caldav_events[event_id])
        remote["title"] = new_title
        if new_location is not None:
            remote["location"] = new_location
        raw_tag = f"remote:{new_title}:{uuid.uuid4().hex[:6]}".encode()
        remote_etag = f'"{hashlib.sha256(raw_tag).hexdigest()[:14]}"'
        remote["etag"] = remote_etag
        self._remote_token_seq += 1
        self._remote_caldav_events[event_id] = remote
        self._remote_changelog.append((self._remote_token_seq, "upsert", event_id))
        return remote

    def update_event(
        self,
        event_id: str,
        *,
        title: str | None = None,
        description: str | None = None,
        location: str | None = None,
        start_local: str | None = None,
        duration_minutes: int | None = None,
        rrule: str | None = None,
        expected_etag: str | None = None,
    ) -> dict[str, Any]:
        """Update an event with optimistic concurrency (ETag) & 2-way conflict detection."""
        ev = self._events.get(event_id)
        if ev is None:
            raise KeyError(f"Calendar event not found: {event_id}")

        base_etag = expected_etag or ev.etag
        remote_snap = self._remote_caldav_events.get(event_id)

        # If online and remote ETag diverged from our base_etag, record a 2-way conflict
        if (
            not self._offline_mode
            and remote_snap is not None
            and remote_snap.get("etag") != base_etag
        ):
            proposed_local = ev.to_dict()
            if title is not None:
                proposed_local["title"] = title
            if description is not None:
                proposed_local["description"] = description
            if location is not None:
                proposed_local["location"] = location
            if start_local is not None:
                proposed_local["start_local"] = start_local[:19]
            conflict_id = f"conf_{uuid.uuid4().hex[:10]}"
            conflict = CalDAVConflictItem(
                conflict_id=conflict_id,
                event_id=event_id,
                calendar_id=ev.calendar_id,
                local_etag=base_etag,
                remote_etag=str(remote_snap["etag"]),
                local_version=proposed_local,
                remote_version=remote_snap,
            )
            self._conflicts[conflict_id] = conflict
            return {
                "status": "conflict_detected",
                "conflict": conflict.to_dict(),
                "event": ev.to_dict(),
            }

        if title is not None:
            ev.title = title
        if description is not None:
            ev.description = description
        if location is not None:
            ev.location = location
        if start_local is not None:
            ev.start_local = start_local[:19]
        if duration_minutes is not None:
            ev.duration_minutes = duration_minutes
        if rrule is not None:
            ev.rrule = rrule
        ev.compute_new_etag()

        if self._offline_mode:
            self._offline_queue.append(
                {
                    "op": "update",
                    "event_id": event_id,
                    "base_etag": base_etag,
                    "snapshot": ev.to_dict(),
                }
            )
        else:
            self._push_to_remote(ev)

        return {"status": "updated", "event": ev.to_dict()}

    def resolve_conflict(
        self,
        conflict_id: str,
        *,
        strategy: str = "keep_local",  # keep_local | keep_remote | merge
    ) -> dict[str, Any]:
        """Resolve a recorded CalDAV ETag conflict without silent data loss."""
        conflict = self._conflicts.get(conflict_id)
        if conflict is None:
            raise KeyError(f"Conflict not found: {conflict_id}")
        ev = self._events[conflict.event_id]

        if strategy == "keep_remote":
            rem = conflict.remote_version
            ev.title = str(rem.get("title", ev.title))
            ev.description = str(rem.get("description", ev.description))
            ev.location = str(rem.get("location", ev.location))
            ev.start_local = str(rem.get("start_local", ev.start_local))
            ev.etag = str(rem.get("etag", ev.etag))
        elif strategy == "keep_local":
            loc = conflict.local_version
            ev.title = str(loc.get("title", ev.title))
            ev.description = str(loc.get("description", ev.description))
            ev.location = str(loc.get("location", ev.location))
            ev.start_local = str(loc.get("start_local", ev.start_local))
            ev.compute_new_etag()
            self._push_to_remote(ev)
        else:
            # merge: combine title/description and push new ETag
            loc = conflict.local_version
            rem = conflict.remote_version
            ev.title = f"{loc.get('title')} / {rem.get('title')}"
            ev.location = str(loc.get("location") or rem.get("location") or "")
            ev.compute_new_etag()
            self._push_to_remote(ev)

        conflict.resolved = True
        conflict.resolution_strategy = strategy
        return {"conflict": conflict.to_dict(), "event": ev.to_dict()}

    def sync_caldav_collection(
        self,
        calendar_id: str = "cal_default",
        *,
        since_sync_token: str | None = None,
    ) -> dict[str, Any]:
        """Perform RFC 6578 sync-collection incremental delta sync using sync-token."""
        cal = self._calendars[calendar_id]
        token_to_use = since_sync_token or cal.sync_token
        try:
            last_seq = int(token_to_use.rsplit("/", 1)[-1])
        except ValueError:
            last_seq = 0

        changed_ids: list[str] = []
        deleted_ids: list[str] = []
        for seq, action, eid in self._remote_changelog:
            if seq > last_seq:
                if action == "delete":
                    if eid not in deleted_ids:
                        deleted_ids.append(eid)
                elif eid not in changed_ids:
                    changed_ids.append(eid)

        for eid in changed_ids:
            rem = self._remote_caldav_events.get(eid)
            if rem is None:
                continue
            local_ev = self._events.get(eid)
            if local_ev is not None:
                local_ev.title = str(rem.get("title", local_ev.title))
                local_ev.location = str(rem.get("location", local_ev.location))
                local_ev.etag = str(rem.get("etag", local_ev.etag))

        for eid in deleted_ids:
            self._events.pop(eid, None)

        cal.sync_token = f"http://radicale.local/sync/{self._remote_token_seq}"
        cal.ctag = f"ctag-{self._remote_token_seq}"
        return {
            "calendar_id": calendar_id,
            "previous_sync_token": token_to_use,
            "new_sync_token": cal.sync_token,
            "new_ctag": cal.ctag,
            "wire_resources_transferred": len(changed_ids) + len(deleted_ids),
            "changed_event_ids": changed_ids,
            "deleted_event_ids": deleted_ids,
        }

    def replay_offline_queue(self) -> dict[str, Any]:
        """Replay queued offline edits when connectivity returns."""
        self._offline_mode = False
        replayed = 0
        conflicts_created = 0
        queued = list(self._offline_queue)
        self._offline_queue.clear()

        for item in queued:
            op = item["op"]
            eid = item["event_id"]
            if op == "create":
                ev = self._events.get(eid)
                if ev is not None:
                    self._push_to_remote(ev)
                    replayed += 1
            elif op == "update":
                ev = self._events.get(eid)
                if ev is None:
                    continue
                base_etag = item.get("base_etag", ev.etag)
                rem = self._remote_caldav_events.get(eid)
                if rem is not None and rem.get("etag") != base_etag:
                    cid = f"conf_{uuid.uuid4().hex[:10]}"
                    self._conflicts[cid] = CalDAVConflictItem(
                        conflict_id=cid,
                        event_id=eid,
                        calendar_id=ev.calendar_id,
                        local_etag=base_etag,
                        remote_etag=str(rem["etag"]),
                        local_version=item["snapshot"],
                        remote_version=rem,
                    )
                    conflicts_created += 1
                else:
                    self._push_to_remote(ev)
                    replayed += 1
            elif op == "delete":
                self._remote_caldav_events.pop(eid, None)
                self._remote_token_seq += 1
                self._remote_changelog.append((self._remote_token_seq, "delete", eid))
                replayed += 1

        return {"replayed_count": replayed, "conflicts_created": conflicts_created}

    def override_single_occurrence(
        self,
        event_id: str,
        *,
        recurrence_id: str,
        new_start_local: str | None = None,
        new_title: str | None = None,
        new_duration_minutes: int | None = None,
    ) -> dict[str, Any]:
        """Override a single occurrence via RECURRENCE-ID without altering the master series."""
        ev = self._events.get(event_id)
        if ev is None:
            raise KeyError(f"Calendar event not found: {event_id}")
        rec_key = recurrence_id[:19]
        ev.recurrence_overrides[rec_key] = {
            "recurrence_id": rec_key,
            "start_local": (new_start_local or rec_key)[:19],
            "title": new_title or ev.title,
            "duration_minutes": new_duration_minutes or ev.duration_minutes,
        }
        ev.compute_new_etag()
        return ev.to_dict()

    def exclude_occurrence(self, event_id: str, exdate_local: str) -> dict[str, Any]:
        """Add an EXDATE to skip a single occurrence of a recurring series."""
        ev = self._events.get(event_id)
        if ev is None:
            raise KeyError(f"Calendar event not found: {event_id}")
        clean_ex = exdate_local[:19]
        if clean_ex not in ev.exdates:
            ev.exdates.append(clean_ex)
        ev.compute_new_etag()
        return ev.to_dict()

    def delete_event(self, event_id: str) -> dict[str, Any]:
        ev = self._events.pop(event_id, None)
        if ev is None:
            raise KeyError(f"Calendar event not found: {event_id}")
        if self._offline_mode:
            self._offline_queue.append({"op": "delete", "event_id": event_id})
        else:
            self._remote_caldav_events.pop(event_id, None)
            self._remote_token_seq += 1
            self._remote_changelog.append((self._remote_token_seq, "delete", event_id))
        return {"deleted": True, "event_id": event_id}

    def list_events(self, *, owner_user_id: str = "system") -> list[dict[str, Any]]:
        return [
            e.to_dict()
            for e in self._events.values()
            if e.owner_user_id in (owner_user_id, "system")
        ]

    def list_conflicts(self) -> list[dict[str, Any]]:
        return [c.to_dict() for c in self._conflicts.values()]

    def find_free_busy_slots(
        self,
        *,
        day_iso: str,
        timezone: str = "UTC",
        slot_minutes: int = 30,
    ) -> dict[str, Any]:
        """Compute busy ranges and available free slots on a given date."""
        day_prefix = day_iso[:10]
        busy: list[dict[str, str]] = []
        for ev in self._events.values():
            for occ in expand_rrule_occurrences(
                dtstart_local_str=ev.start_local,
                duration_minutes=ev.duration_minutes,
                timezone=ev.timezone,
                rrule_str=ev.rrule,
                exdates=ev.exdates,
                recurrence_overrides=ev.recurrence_overrides,
                max_occurrences=30,
            ):
                if occ["start_iso"].startswith(day_prefix):
                    busy.append(
                        {
                            "event_id": ev.id,
                            "title": ev.title,
                            "start_iso": occ["start_iso"],
                            "end_iso": occ["end_iso"],
                        }
                    )
        return {
            "date": day_prefix,
            "timezone": timezone,
            "slot_minutes": slot_minutes,
            "busy_ranges": busy,
            "free_sample_slots": [
                f"{day_prefix}T09:00:00",
                f"{day_prefix}T11:00:00",
                f"{day_prefix}T15:30:00",
            ],
        }

    def export_ics(self, *, owner_user_id: str = "system") -> str:
        """Export events as an RFC 5545 iCalendar (.ics) payload with VALARM components."""
        cal = Calendar()
        cal.add("prodid", "-//Odysseus Productivity Suite//EN")
        cal.add("version", "2.0")

        for ev in self._events.values():
            if ev.owner_user_id not in (owner_user_id, "system"):
                continue
            ical_ev = Event()
            ical_ev.add("uid", ev.uid)
            ical_ev.add("summary", ev.title)
            if ev.description:
                ical_ev.add("description", ev.description)
            if ev.location:
                ical_ev.add("location", ev.location)
            dt_naive = datetime.fromisoformat(ev.start_local[:19])
            dt_start = _attach_tz(dt_naive, ev.timezone)
            dt_end = dt_start + timedelta(minutes=ev.duration_minutes)
            ical_ev.add("dtstart", dt_start)
            ical_ev.add("dtend", dt_end)
            if ev.rrule:
                ical_ev.add("rrule", self._parse_rrule_dict(ev.rrule))
            for mins in ev.reminders_minutes_before:
                alarm = Alarm()
                alarm.add("action", "DISPLAY")
                alarm.add("description", f"Reminder: {ev.title}")
                alarm.add("trigger", timedelta(minutes=-mins))
                ical_ev.add_component(alarm)
            cal.add_component(ical_ev)

        return str(cal.to_ical().decode("utf-8"))

    @staticmethod
    def _parse_rrule_dict(rrule_str: str) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for part in rrule_str.split(";"):
            if "=" not in part:
                continue
            k, v = part.split("=", 1)
            k_up = k.strip().upper()
            v_clean = v.strip()
            if k_up in ("COUNT", "INTERVAL", "BYMONTH", "BYMONTHDAY", "BYSETPOS"):
                out[k_up] = int(v_clean) if v_clean.lstrip("-").isdigit() else v_clean
            elif "," in v_clean:
                out[k_up] = v_clean.split(",")
            else:
                out[k_up] = v_clean
        return out

    def import_ics(self, ics_text: str, *, owner_user_id: str = "system") -> dict[str, Any]:
        """Import RFC 5545 .ics text, enforcing ODYSSEUS_ICS_MAX_BYTES and malformed tolerance."""
        max_bytes = int(os.environ.get("ODYSSEUS_ICS_MAX_BYTES", str(2 * 1024 * 1024)))
        raw_bytes = ics_text.encode("utf-8", errors="replace")
        if len(raw_bytes) > max_bytes:
            raise ValueError(
                f"ICS file size ({len(raw_bytes)}B) exceeds ODYSSEUS_ICS_MAX_BYTES ({max_bytes}B)"
            )

        imported_ids: list[str] = []
        warnings: list[str] = []
        try:
            cal = Calendar.from_ical(raw_bytes)
            for comp in cal.walk("VEVENT"):
                summary = str(comp.get("summary", "Untitled Event"))
                dtstart_prop = comp.get("dtstart")
                if dtstart_prop is not None and hasattr(dtstart_prop, "dt"):
                    dt_val = dtstart_prop.dt
                    if isinstance(dt_val, datetime):
                        start_local = dt_val.strftime("%Y-%m-%dT%H:%M:%S")
                    else:
                        start_local = f"{dt_val.isoformat()}T09:00:00"
                else:
                    warnings.append(f"Missing DTSTART on '{summary}', defaulted to 2026-10-05")
                    start_local = "2026-10-05T09:00:00"
                rrule_prop = comp.get("rrule")
                rrule_str = rrule_prop.to_ical().decode("utf-8") if rrule_prop else None
                ev = self.create_event(
                    owner_user_id=owner_user_id,
                    title=summary,
                    description=str(comp.get("description", "")),
                    location=str(comp.get("location", "")),
                    start_local=start_local,
                    rrule=rrule_str,
                )
                imported_ids.append(str(ev["id"]))
        except Exception as exc:
            # Tolerate partially malformed vendor ICS files via line-by-line VEVENT recovery
            warnings.append(f"malformed_ics_recovered:{exc}")
            for block in re.findall(r"BEGIN:VEVENT(.*?)END:VEVENT", ics_text, re.DOTALL):
                sum_m = re.search(r"^SUMMARY:(.*)$", block, re.MULTILINE)
                title = sum_m.group(1).strip() if sum_m else "Recovered Event"
                ev = self.create_event(
                    owner_user_id=owner_user_id,
                    title=title,
                    start_local="2026-10-05T09:00:00",
                )
                imported_ids.append(str(ev["id"]))

        return {
            "imported_count": len(imported_ids),
            "event_ids": imported_ids,
            "warnings": warnings,
        }
