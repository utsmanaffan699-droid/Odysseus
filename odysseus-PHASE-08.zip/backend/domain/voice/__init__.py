"""Voice (STT, Sentence-Streaming TTS, Barge-In, and Voice Conversation Mode) domain package."""

from backend.domain.voice.service import (
    MAX_AUDIO_BYTES,
    MAX_AUDIO_DURATION_SECONDS,
    WER_REFERENCE_FIXTURE,
    VoiceService,
    compute_word_error_rate,
    detect_kokoro_runtime,
    split_streaming_sentences,
)

__all__ = [
    "MAX_AUDIO_BYTES",
    "MAX_AUDIO_DURATION_SECONDS",
    "WER_REFERENCE_FIXTURE",
    "VoiceService",
    "compute_word_error_rate",
    "detect_kokoro_runtime",
    "split_streaming_sentences",
]
