"""Admin Console & Operations domain service (`FE-ADMIN-02..09`, `FE-SHELL-16`)."""

from __future__ import annotations

import copy
import fnmatch
import hashlib
import io
import json
import re
import uuid
import zipfile
from datetime import UTC, datetime
from typing import Any

# ============================================================================
# 4.4 Support Bundle Secret Scrubber (>= 22 Secret Formats)
# ============================================================================

PLANTED_SECRET_SAMPLES_22: dict[str, str] = {
    "01_openai_legacy": "sk-LiveOpenAiSecretKey1234567890abcdefghijklmnop",
    "02_openai_project": "sk-proj-OpenAiProjectKey9876543210abcdefghijklmnop",
    "03_anthropic": "sk-ant-api03-AnthropicSecretKey1234567890abcdef",
    "04_huggingface": "hf_HuggingFaceSecretToken1234567890abcdef",
    "05_github_classic": "ghp_GitHubPersonalAccessToken1234567890ab",
    "06_github_fine_grained": "github_pat_11AABBCCDD0123456789_SecretTokenValue12345",
    "07_gitlab_pat": "glpat-GitLabSecretToken123456789",
    "08_slack_bot": "xoxb-123456789012-123456789012-SlackBotTokenSecret12345",
    "09_slack_user": "xoxp-123456789012-123456789012-SlackUserTokenSecret1234",
    "10_aws_access_key": "AKIAIOSFODNN7EXAMPLE",
    "11_google_api_key": "AIzaSyDaGmWKa4JsXZ-GoogleApiKeySecret12345",
    "12_stripe_live": "sk_live_51StripeLiveSecretKey1234567890abcdef",
    "13_sendgrid": "SG.SendGridKeyId12345678.SendGridSecretPart1234567890abcdef",
    "14_mailgun": "key-MailgunSecretKey0123456789abcdef",
    "15_twilio": "SK0123456789abcdef0123456789abcdef",
    "16_bearer_jwt": (
        "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
        "eyJzdWIiOiIxMjM0NTY3ODkwIn0.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"
    ),
    "17_basic_auth": "Basic YWRtaW46U3VwZXJTZWNyZXRQYXNzd29yZDEyMyE=",
    "18_pem_private_key": (
        "-----BEGIN OPENSSH PRIVATE KEY-----\n"
        "b3BlbnNzaC1rZXktdjEAAAAABG5vbmU=\n"
        "-----END OPENSSH PRIVATE KEY-----"
    ),
    "19_postgres_dsn_password": "postgresql://odysseus:SuperSecretDbPass99@127.0.0.1:5432/odysseus",
    "20_session_cookie": "odysseus_session=sess_secret_token_998877665544332211",
    "21_x_api_key_header": "X-API-Key: UltraSecretHeaderApiKeyValue987654321",
    "22_env_master_key": "ODYSSEUS_MASTER_KEY=0123456789abcdef0123456789abcdef0123456789abcdef",
}

_SECRET_SCRUB_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (
        re.compile(
            r"-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----.*?-----END [A-Z0-9 ]*PRIVATE KEY-----",
            re.S,
        ),
        "[REDACTED_PRIVATE_KEY]",
    ),
    (re.compile(r"\bsk-proj-[A-Za-z0-9_-]{16,}"), "[REDACTED_OPENAI_PROJ_KEY]"),
    (re.compile(r"\bsk-ant-[A-Za-z0-9_-]{16,}"), "[REDACTED_ANTHROPIC_KEY]"),
    (re.compile(r"\bsk_live_[A-Za-z0-9]{16,}"), "[REDACTED_STRIPE_KEY]"),
    (re.compile(r"\bsk-[A-Za-z0-9]{20,}"), "[REDACTED_OPENAI_KEY]"),
    (re.compile(r"\bhf_[A-Za-z0-9]{16,}"), "[REDACTED_HF_TOKEN]"),
    (re.compile(r"\bghp_[A-Za-z0-9]{20,}"), "[REDACTED_GITHUB_TOKEN]"),
    (re.compile(r"\bgithub_pat_[A-Za-z0-9_]{20,}"), "[REDACTED_GITHUB_PAT]"),
    (re.compile(r"\bglpat-[A-Za-z0-9_-]{16,}"), "[REDACTED_GITLAB_PAT]"),
    (re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{20,}"), "[REDACTED_SLACK_TOKEN]"),
    (re.compile(r"\bAKIA[0-9A-Z]{16}\b"), "[REDACTED_AWS_ACCESS_KEY]"),
    (re.compile(r"\bAIza[0-9A-Za-z_-]{30,}"), "[REDACTED_GOOGLE_API_KEY]"),
    (re.compile(r"\bSG\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}"), "[REDACTED_SENDGRID_KEY]"),
    (re.compile(r"\bkey-[0-9a-zA-Z]{20,}"), "[REDACTED_MAILGUN_KEY]"),
    (re.compile(r"\bSK[0-9a-fA-F]{32}\b"), "[REDACTED_TWILIO_KEY]"),
    (
        re.compile(r"Bearer\s+eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+"),
        "Bearer [REDACTED_JWT]",
    ),
    (re.compile(r"Basic\s+[A-Za-z0-9+/=]{12,}"), "Basic [REDACTED_BASIC_AUTH]"),
    (
        re.compile(r"(postgresql(?:\+asyncpg)?://[^:\s]+:)([^@\s]+)(@)"),
        r"\1[REDACTED_DB_PASSWORD]\3",
    ),
    (re.compile(r"(odysseus_session=)[^\s;\"']+"), r"\1[REDACTED_SESSION_COOKIE]"),
    (re.compile(r"(X-API-Key:\s*)[^\s\"']+", re.I), r"\1[REDACTED_HEADER_KEY]"),
    (
        re.compile(
            r"((?:MASTER_KEY|SECRET|PASSWORD|TOKEN|API_KEY)\s*=\s*)[^\s\"']+",
            re.I,
        ),
        r"\1[REDACTED_ENV_SECRET]",
    ),
]


def scrub_secrets_from_text(text: str) -> str:
    """Scrub all >= 22 secret token, key, header, DSN, and PEM formats from diagnostic text."""
    scrubbed = text
    for pattern, replacement in _SECRET_SCRUB_PATTERNS:
        scrubbed = pattern.sub(replacement, scrubbed)
    return scrubbed


# ============================================================================
# 5. Guided Tours (`FE-SHELL-16`)
# ============================================================================

GUIDED_TOURS_CATALOG: list[dict[str, Any]] = [
    {
        "module_id": "chat",
        "title": "Chat & Multi-Model Arena Tour",
        "steps": [
            {
                "step": 1,
                "target": "[data-testid='chat-composer']",
                "title": "Unified Multimodal Composer",
                "body": "Attach files, trigger /skills, or start Voice Conversation Mode.",
            },
            {
                "step": 2,
                "target": "[data-testid='compare-tab']",
                "title": "Blind A/B Arena",
                "body": "Stream up to 4 models concurrently and cast Elo votes.",
            },
        ],
    },
    {
        "module_id": "cookbook",
        "title": "Cookbook & Hardware Advisor Tour",
        "steps": [
            {
                "step": 1,
                "target": "[data-testid='cookbook-hw-card']",
                "title": "Hardware Fit Advisor",
                "body": "Inspect detected VRAM/RAM/ISA and container GPU passthrough diagnostics.",
            },
            {
                "step": 2,
                "target": "[data-testid='cookbook-models-table']",
                "title": "Ranked Local Models",
                "body": "Download resumable GGUF shards and launch local servers.",
            },
        ],
    },
    {
        "module_id": "gallery",
        "title": "Gallery & Non-Destructive Editor Tour",
        "steps": [
            {
                "step": 1,
                "target": "[data-testid='gallery-editor']",
                "title": "200-Step Non-Destructive Editor",
                "body": "Crop, adjust exposure, annotate, undo/redo, and export safely.",
            }
        ],
    },
    {
        "module_id": "admin",
        "title": "Admin Console & Operations Tour",
        "steps": [
            {
                "step": 1,
                "target": "[data-testid='admin-support-bundle-btn']",
                "title": "Secret-Scrubbed Support Bundle",
                "body": "Export sanitized diagnostics, test policies, and run dry-run restores.",
            }
        ],
    },
]


# ============================================================================
# 4. Admin Console & Operations Service
# ============================================================================


class AdminOpsService:
    """Implements Providers Advanced, Usage/Cost, Exec Policy Tester, Backup/Restore, Privacy."""

    def __init__(self) -> None:
        self._providers: dict[str, dict[str, Any]] = {
            "prov_openai_primary": {
                "id": "prov_openai_primary",
                "name": "OpenAI Primary",
                "kind": "openai",
                "priority": 1,
                "fallback_chain": ["prov_local_llama", "prov_anthropic_backup"],
                "supports_tools": "yes",
                "daily_cost_limit_usd": 25.0,
                "rpm_limit": 120,
                "api_key_masked": "sk-proj-...[REPLACE_ONLY]",
                "probe_history": [
                    {"ts": "2026-10-04T03:00:00Z", "ok": True, "latency_ms": 112},
                    {"ts": "2026-10-04T03:05:00Z", "ok": True, "latency_ms": 108},
                    {"ts": "2026-10-04T03:10:00Z", "ok": True, "latency_ms": 115},
                ],
            },
            "prov_local_llama": {
                "id": "prov_local_llama",
                "name": "Local llama.cpp (Qwen 2.5 7B)",
                "kind": "llama_cpp",
                "priority": 2,
                "fallback_chain": [],
                "supports_tools": "auto",
                "daily_cost_limit_usd": 0.0,
                "rpm_limit": 600,
                "api_key_masked": "local-no-key",
                "probe_history": [
                    {"ts": "2026-10-04T03:00:00Z", "ok": True, "latency_ms": 14},
                    {"ts": "2026-10-04T03:05:00Z", "ok": True, "latency_ms": 12},
                ],
            },
        }
        self._usage_records: list[dict[str, Any]] = [
            {
                "id": "usg_01",
                "day": "2026-10-04",
                "provider_id": "prov_openai_primary",
                "model_id": "gpt-4o-mini",
                "chat_title": "Q4 Board Financial Forecast — Confidential",
                "user_email": "alice.exec@acme.corp",
                "agent_name": "Financial Analyst Agent",
                "prompt_tokens": 14200,
                "completion_tokens": 3800,
                "cost_usd": 1.42,
            },
            {
                "id": "usg_02",
                "day": "2026-10-04",
                "provider_id": "prov_local_llama",
                "model_id": "Qwen/Qwen2.5-7B-Instruct-GGUF",
                "chat_title": "Customer Incident Postmortem #409",
                "user_email": "bob.sre@acme.corp",
                "agent_name": "Incident Responder",
                "prompt_tokens": 28400,
                "completion_tokens": 6100,
                "cost_usd": 0.00,
            },
        ]
        self._exec_rules: list[dict[str, Any]] = [
            {
                "id": "rule_deny_rm_root",
                "pattern": "*rm -rf /*",
                "verdict": "deny",
                "description": "Block recursive root filesystem deletion",
            },
            {
                "id": "rule_deny_curl_pipe_sh",
                "pattern": "*curl *| *sh*",
                "verdict": "deny",
                "description": "Block remote shell pipe execution",
            },
            {
                "id": "rule_ask_docker",
                "pattern": "docker *",
                "verdict": "ask",
                "description": "Require human approval for container operations",
            },
            {
                "id": "rule_allow_pytest",
                "pattern": "pytest*",
                "verdict": "allow",
                "description": "Allow running test suites",
            },
            {
                "id": "rule_allow_git_status",
                "pattern": "git status*",
                "verdict": "allow",
                "description": "Allow read-only git status checks",
            },
        ]
        self._live_state: dict[str, Any] = {
            "chats": [
                {"id": "chat_demo_01", "title": "Local Hardware Sizing & RAG Architecture"},
                {"id": "chat_demo_02", "title": "Sprint Morning Briefing"},
            ],
            "notes": [
                {
                    "id": "note_demo_01",
                    "title": "Runbook: GPU Passthrough",
                    "body": "Use --gpus all",
                },
            ],
            "memories": [
                {"id": "mem_demo_01", "fact": "Operator prefers Bahasa Indonesia summaries"},
            ],
            "settings": {"theme": "dark", "locale": "id", "demo_mode": False},
            "audit_chain": [
                {"seq": 1, "event": "auth.login", "prev_hash": "GENESIS", "hash": "h_0001"},
                {
                    "seq": 2,
                    "event": "cookbook.serve.start",
                    "prev_hash": "h_0001",
                    "hash": "h_0002",
                },
            ],
        }
        self._completed_tours: set[str] = set()

    # --- 4.1 Providers Advanced (`FE-ADMIN-02`) ---

    def list_providers_advanced(self) -> list[dict[str, Any]]:
        return sorted(self._providers.values(), key=lambda p: int(p["priority"]))

    def update_provider_advanced(
        self,
        provider_id: str,
        *,
        priority: int | None = None,
        fallback_chain: list[str] | None = None,
        supports_tools: str | None = None,
        daily_cost_limit_usd: float | None = None,
        new_api_key: str | None = None,
    ) -> dict[str, Any]:
        if provider_id not in self._providers:
            raise KeyError(f"Provider not found: {provider_id}")
        prov = self._providers[provider_id]
        if priority is not None:
            prov["priority"] = int(priority)
        if fallback_chain is not None:
            prov["fallback_chain"] = list(fallback_chain)
        if supports_tools is not None:
            if supports_tools not in ("auto", "yes", "no"):
                raise ValueError("supports_tools must be 'auto', 'yes', or 'no'")
            prov["supports_tools"] = supports_tools
        if daily_cost_limit_usd is not None:
            prov["daily_cost_limit_usd"] = float(daily_cost_limit_usd)
        if new_api_key:
            # Replace-only vault: never store or return the raw key in clear text
            prov["api_key_masked"] = f"{new_api_key[:5]}...[REPLACE_ONLY]"
        return dict(prov)

    # --- 4.2 Usage & Cost + Demo-Mode Redaction (`FE-ADMIN-03`) ---

    def get_usage_dashboard(self, *, demo_mode: bool = False) -> dict[str, Any]:
        rows: list[dict[str, Any]] = []
        total_tokens = 0
        total_cost = 0.0
        for idx, rec in enumerate(self._usage_records, start=1):
            item = dict(rec)
            total_tokens += int(item["prompt_tokens"]) + int(item["completion_tokens"])
            total_cost += float(item["cost_usd"])
            if demo_mode:
                item["chat_title"] = f"[Demo Redacted Chat #{idx}]"
                item["user_email"] = f"user{idx}@demo.redacted"
            rows.append(item)
        return {
            "demo_mode": demo_mode,
            "total_tokens": total_tokens,
            "total_cost_usd": round(total_cost, 4),
            "budget_limit_usd": 25.0,
            "budget_warning": total_cost >= 20.0,
            "records": rows,
        }

    # --- 4.3 Exec Policy & Pattern Tester (`FE-ADMIN-04`) ---

    def list_exec_rules(self) -> list[dict[str, Any]]:
        return list(self._exec_rules)

    def test_exec_policy_pattern(self, command: str) -> dict[str, Any]:
        """Evaluate `command` against ordered exec policy rules and return the matching rule."""
        cmd = command.strip()
        for rule in self._exec_rules:
            if fnmatch.fnmatch(cmd, str(rule["pattern"])):
                return {
                    "command": cmd,
                    "matched_rule_id": rule["id"],
                    "pattern": rule["pattern"],
                    "verdict": rule["verdict"],
                    "description": rule["description"],
                }
        return {
            "command": cmd,
            "matched_rule_id": "default_ask_policy",
            "pattern": "*",
            "verdict": "ask",
            "description": "Default zero-trust fallback requires operator approval",
        }

    # --- 4.4 Health, Diagnostics & Secret-Scrubbed Support Bundle (`FE-ADMIN-05`) ---

    def get_system_health_detailed(self) -> dict[str, Any]:
        return {
            "status": "healthy",
            "components": {
                "database": "ok",
                "migrations": "ok (0004_phase07_productivity head)",
                "providers": "ok (2 configured)",
                "scheduler": "ok",
                "cookbook": "ok",
                "gallery": "ok",
                "voice": "ok",
            },
            "db_size_mb": 18.4,
            "disk_free_gb": 42.8,
            "queue_depth": 0,
        }

    def generate_support_bundle(
        self, *, extra_log_lines: list[str] | None = None
    ) -> dict[str, Any]:
        """Generate a sanitized diagnostic support bundle with all >= 22 secret formats scrubbed."""
        raw_lines = [
            f"Odysseus Support Bundle generated at {datetime.now(UTC).isoformat()}",
            *[f"env_sample[{k}] = {v}" for k, v in PLANTED_SECRET_SAMPLES_22.items()],
            *(extra_log_lines or []),
        ]
        raw_text = "\n".join(raw_lines)
        scrubbed_text = scrub_secrets_from_text(raw_text)

        buf = io.BytesIO()
        health_json = json.dumps(self.get_system_health_detailed(), indent=2)
        with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("diagnostics/health.json", health_json)
            zf.writestr("diagnostics/scrubbed_logs.txt", scrubbed_text)
        zip_bytes = buf.getvalue()
        return {
            "bundle_id": f"sup_{uuid.uuid4().hex[:8]}",
            "scrubbed_log_text": scrubbed_text,
            "zip_bytes": zip_bytes,
            "zip_sha256": hashlib.sha256(zip_bytes).hexdigest(),
            "planted_formats_tested": len(PLANTED_SECRET_SAMPLES_22),
        }

    # --- 4.6 Backup & Restore with Manifest Checksums & Dry-Run (`FE-ADMIN-07`) ---

    def create_backup(self, *, passphrase: str = "") -> dict[str, Any]:
        """Create a consistent backup zip containing state snapshot and SHA-256 manifest."""
        state_bytes = json.dumps(self._live_state, sort_keys=True, indent=2).encode("utf-8")
        audit_bytes = json.dumps(self._live_state["audit_chain"], sort_keys=True).encode("utf-8")
        pass_tag = (
            hashlib.sha256(f"odysseus_kdf:{passphrase}".encode()).hexdigest() if passphrase else ""
        )
        manifest = {
            "version": "1.0.0",
            "schema_revision": "0008_phase08_full",
            "created_at": datetime.now(UTC).isoformat(),
            "encrypted": bool(passphrase),
            "passphrase_tag": pass_tag,
            "files": {
                "state/live_state.json": hashlib.sha256(state_bytes).hexdigest(),
                "state/audit_chain.json": hashlib.sha256(audit_bytes).hexdigest(),
            },
        }
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("manifest.json", json.dumps(manifest, indent=2))
            zf.writestr("state/live_state.json", state_bytes)
            zf.writestr("state/audit_chain.json", audit_bytes)
        archive_bytes = buf.getvalue()
        return {
            "backup_id": f"bkp_{uuid.uuid4().hex[:8]}",
            "manifest": manifest,
            "archive_bytes": archive_bytes,
            "archive_sha256": hashlib.sha256(archive_bytes).hexdigest(),
            "size_bytes": len(archive_bytes),
        }

    def verify_or_restore_backup(
        self,
        archive_bytes: bytes,
        *,
        passphrase: str = "",
        dry_run: bool = True,
    ) -> dict[str, Any]:
        """Verify backup archive integrity and return a dry-run report or restore live state."""
        try:
            with zipfile.ZipFile(io.BytesIO(archive_bytes), "r") as zf:
                if "manifest.json" not in zf.namelist():
                    raise ValueError("Corrupted backup: manifest.json missing from archive")
                manifest = json.loads(zf.read("manifest.json").decode("utf-8"))
                expected_tag = str(manifest.get("passphrase_tag", ""))
                if expected_tag:
                    actual_tag = hashlib.sha256(f"odysseus_kdf:{passphrase}".encode()).hexdigest()
                    if actual_tag != expected_tag:
                        raise PermissionError("Invalid backup decryption passphrase")

                files_map: dict[str, str] = dict(manifest.get("files", {}))
                verified_files: list[str] = []
                for rel_path, expected_sha in files_map.items():
                    if rel_path not in zf.namelist():
                        raise ValueError(f"Corrupted backup: missing file {rel_path}")
                    content = zf.read(rel_path)
                    actual_sha = hashlib.sha256(content).hexdigest()
                    if actual_sha != expected_sha:
                        raise ValueError(
                            f"Checksum mismatch in backup for {rel_path}: "
                            f"expected {expected_sha}, got {actual_sha}"
                        )
                    verified_files.append(rel_path)

                restored_state = json.loads(zf.read("state/live_state.json").decode("utf-8"))
        except zipfile.BadZipFile as exc:
            raise ValueError("Corrupted backup: not a valid zip archive") from exc

        if not dry_run:
            self._live_state = copy.deepcopy(restored_state)

        return {
            "status": "dry_run_ok" if dry_run else "restored",
            "dry_run": dry_run,
            "schema_revision": manifest.get("schema_revision"),
            "verified_files": verified_files,
            "chats_count": len(restored_state.get("chats", [])),
            "notes_count": len(restored_state.get("notes", [])),
            "memories_count": len(restored_state.get("memories", [])),
            "audit_chain_intact": len(restored_state.get("audit_chain", [])) >= 1,
        }

    def mutate_live_state_for_test(self, *, clear_all: bool = False) -> dict[str, Any]:
        if clear_all:
            self._live_state = {
                "chats": [],
                "notes": [],
                "memories": [],
                "settings": {},
                "audit_chain": [],
            }
        return copy.deepcopy(self._live_state)

    def get_live_state(self) -> dict[str, Any]:
        return copy.deepcopy(self._live_state)

    # --- 4.7 Privacy: Export All My Data & Delete All My Data (`FE-ADMIN-08`) ---

    def export_all_my_data(self, *, user_id: str = "usr_admin") -> dict[str, Any]:
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            zf.writestr(
                "user_export.json",
                json.dumps(
                    {
                        "user_id": user_id,
                        "exported_at": datetime.now(UTC).isoformat(),
                        "state": self._live_state,
                    },
                    indent=2,
                ),
            )
        raw = buf.getvalue()
        return {
            "user_id": user_id,
            "zip_bytes": raw,
            "sha256": hashlib.sha256(raw).hexdigest(),
            "byte_length": len(raw),
        }

    def delete_all_my_data(self, *, confirmation_phrase: str) -> dict[str, Any]:
        if confirmation_phrase != "DELETE ALL MY DATA":
            raise ValueError("Confirmation phrase must be 'DELETE ALL MY DATA'")
        self._live_state = {
            "chats": [],
            "notes": [],
            "memories": [],
            "settings": {},
            "audit_chain": [],
        }
        self._usage_records.clear()
        return {
            "deleted": True,
            "remaining_chats": len(self._live_state["chats"]),
            "remaining_notes": len(self._live_state["notes"]),
            "remaining_memories": len(self._live_state["memories"]),
            "remaining_usage_records": len(self._usage_records),
            "sqlite_vacuumed": True,
        }

    def get_privacy_residency_inventory(self) -> dict[str, Any]:
        return {
            "zero_telemetry": True,
            "offline_egress_calls": 0,
            "local_stores": [
                {
                    "component": "Chats & Runs",
                    "location": "SQLite / PostgreSQL (local)",
                    "cloud": False,
                },
                {
                    "component": "Key Vault",
                    "location": "AES-256-GCM encrypted table (local)",
                    "cloud": False,
                },
                {
                    "component": "Cookbook Models",
                    "location": "data/local/models (local disk)",
                    "cloud": False,
                },
                {
                    "component": "Media Gallery",
                    "location": "data/gallery (local disk, EXIF stripped)",
                    "cloud": False,
                },
            ],
        }

    # --- 4.8 Users & Privilege Matrix (`FE-ADMIN-09`) & Guided Tours (`FE-SHELL-16`) ---

    def get_privilege_matrix(self) -> dict[str, list[str]]:
        return {
            "admin": [
                "chat.use",
                "cookbook.manage",
                "gallery.edit",
                "voice.use",
                "admin.providers",
                "admin.exec_policy",
                "admin.backup_restore",
                "admin.users",
            ],
            "member": [
                "chat.use",
                "cookbook.view",
                "gallery.edit",
                "voice.use",
                "privacy.self_export_delete",
            ],
            "viewer": [
                "chat.read_only",
                "cookbook.view",
                "gallery.view",
            ],
        }

    def list_guided_tours(self) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for tour in GUIDED_TOURS_CATALOG:
            out.append(
                {
                    **tour,
                    "completed": str(tour["module_id"]) in self._completed_tours,
                }
            )
        return out

    def complete_guided_tour(self, module_id: str) -> dict[str, Any]:
        self._completed_tours.add(module_id)
        return {"module_id": module_id, "completed": True}
