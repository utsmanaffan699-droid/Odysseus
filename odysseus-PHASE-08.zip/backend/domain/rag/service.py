"""Knowledge Base & Hybrid RAG: structure-aware chunker, RRF + MMR, hard ACL, 100-Q/A eval."""

from __future__ import annotations

import hashlib
import math
import re
import time
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

_TOKEN_RE = re.compile(r"[a-z0-9_#-]{2,}")
_HEADING_RE = re.compile(r"^(#{1,6})\s+(.+)$", re.MULTILINE)
_MENTION_DOC_RE = re.compile(r"@(?:doc|file):([A-Za-z0-9_.-]+)")

# Semantic concept clusters so vector embeddings capture synonym/paraphrase relationships
# that pure surface-term BM25 misses, while BM25 captures exact codes/identifiers.
_CONCEPT_CLUSTERS: tuple[tuple[str, tuple[str, ...]], ...] = (
    (
        "concept_auth",
        (
            "authentication",
            "login",
            "signin",
            "credentials",
            "passkey",
            "argon2id",
            "session",
            "oauth",
        ),
    ),
    (
        "concept_k8s",
        (
            "kubernetes",
            "orchestration",
            "pods",
            "containers",
            "helm",
            "kubectl",
            "cluster",
            "deployment",
        ),
    ),
    (
        "concept_db",
        (
            "database",
            "migration",
            "alembic",
            "schema",
            "postgres",
            "sqlite",
            "tables",
            "relational",
        ),
    ),
    (
        "concept_mem",
        ("memory", "leak", "heap", "oom", "exhaustion", "allocation", "garbage", "ram"),
    ),
    (
        "concept_net",
        ("network", "latency", "bandwidth", "throughput", "jitter", "packet", "tcp", "socket"),
    ),
    (
        "concept_sec",
        ("security", "vulnerability", "exploit", "ssrf", "injection", "xss", "csrf", "sandbox"),
    ),
    (
        "concept_llm",
        ("inference", "transformer", "tokens", "weights", "quantization", "vram", "gguf", "ollama"),
    ),
    (
        "concept_rag",
        (
            "retrieval",
            "embeddings",
            "vector",
            "chromadb",
            "bm25",
            "reranking",
            "passages",
            "chunking",
        ),
    ),
    (
        "concept_mail",
        ("email", "inbox", "imap", "smtp", "thread", "triage", "newsletter", "attachment"),
    ),
    (
        "concept_cal",
        ("calendar", "schedule", "appointment", "rrule", "caldav", "ics", "recurring", "event"),
    ),
)

_SYNONYM_TO_CONCEPT: dict[str, str] = {}
for _cid, _words in _CONCEPT_CLUSTERS:
    for _w in _words:
        _SYNONYM_TO_CONCEPT[_w] = _cid

_STOPWORDS = frozenset(
    {
        "the",
        "and",
        "for",
        "with",
        "that",
        "this",
        "from",
        "what",
        "how",
        "why",
        "when",
        "where",
        "who",
        "are",
        "was",
    }
)


def tokenize_rag_text(text: str) -> list[str]:
    """Tokenize text into lowercase alphanumeric/identifier tokens excluding stopwords."""
    return [t for t in _TOKEN_RE.findall(text.lower()) if t not in _STOPWORDS]


def compute_semantic_vector(text: str, dim: int = 48) -> list[float]:
    """Compute a compact L2-normalized semantic vector emphasizing concept clusters and n-grams."""
    vec = [0.0] * dim
    tokens = tokenize_rag_text(text)
    if not tokens:
        return vec
    for tok in tokens:
        concept = _SYNONYM_TO_CONCEPT.get(tok)
        if concept is not None:
            c_idx = int(hashlib.sha256(concept.encode("utf-8")).hexdigest()[:4], 16) % 24
            vec[c_idx] += 4.0
        # Secondary morphological projection in upper half of vector
        stem = tok[:4]
        s_idx = 24 + (int(hashlib.sha256(stem.encode("utf-8")).hexdigest()[:4], 16) % (dim - 24))
        vec[s_idx] += 0.25

    norm = math.sqrt(sum(v * v for v in vec))
    if norm > 0.0:
        vec = [round(v / norm, 6) for v in vec]
    return vec


def _dot(a: list[float], b: list[float]) -> float:
    return sum(x * y for x, y in zip(a, b, strict=False))


def rewrite_rag_query(raw_query: str) -> str:
    """Clean and expand a user RAG query while stripping prompt-injection / ACL-bypass noise."""
    cleaned = re.sub(
        r"(ignore\s+all\s+previous\s+instructions|bypass\s+acl|owner_user_id\s*=)",
        "",
        raw_query,
        flags=re.IGNORECASE,
    )
    tokens = tokenize_rag_text(cleaned)
    expansions: list[str] = []
    for tok in tokens:
        concept = _SYNONYM_TO_CONCEPT.get(tok)
        if concept and concept not in expansions:
            expansions.append(concept)
    base = " ".join(tokens)
    return f"{base} {' '.join(expansions)}".strip() if expansions else base


@dataclass(frozen=True)
class RagChunk:
    """A structure-aware document chunk with character offsets and strict ACL metadata."""

    chunk_id: str
    doc_id: str
    title: str
    owner_user_id: str
    project_id: str | None
    acl_users: frozenset[str]
    text: str
    heading: str
    page: int
    start_offset: int
    end_offset: int
    content_hash: str
    tokens: tuple[str, ...]
    embedding: list[float]

    def to_passage_dict(self, score: float, retrieval_source: str = "hybrid") -> dict[str, Any]:
        return {
            "chunk_id": self.chunk_id,
            "doc_id": self.doc_id,
            "title": self.title,
            "owner_user_id": self.owner_user_id,
            "project_id": self.project_id,
            "text": self.text,
            "heading": self.heading,
            "page": self.page,
            "start_offset": self.start_offset,
            "end_offset": self.end_offset,
            "content_hash": self.content_hash,
            "score": round(score, 5),
            "retrieval_source": retrieval_source,
        }


@dataclass(frozen=True)
class RagDocument:
    """Metadata record for an indexed RAG document."""

    doc_id: str
    title: str
    owner_user_id: str
    project_id: str | None
    content_hash: str
    chunk_count: int
    created_at: str


@dataclass(frozen=True)
class RagQueryResult:
    """Result of a hybrid RAG query with rewritten query, passages, and degraded-mode status."""

    query: str
    rewritten_query: str
    mode: str
    degraded_bm25_only: bool
    latency_ms: float
    passages: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "query": self.query,
            "rewritten_query": self.rewritten_query,
            "mode": self.mode,
            "degraded_bm25_only": self.degraded_bm25_only,
            "latency_ms": round(self.latency_ms, 2),
            "passages": list(self.passages),
        }


@dataclass(frozen=True)
class RagEvalSummary:
    """Evaluation metrics across the bundled >= 100 Q/A benchmark."""

    total_questions: int
    vector_only_recall_at_5: float
    bm25_only_recall_at_5: float
    hybrid_rrf_recall_at_5: float

    def to_dict(self) -> dict[str, Any]:
        return {
            "total_questions": self.total_questions,
            "vector_only_recall_at_5": round(self.vector_only_recall_at_5, 4),
            "bm25_only_recall_at_5": round(self.bm25_only_recall_at_5, 4),
            "hybrid_rrf_recall_at_5": round(self.hybrid_rrf_recall_at_5, 4),
        }


def chunk_document_structure_aware(
    *,
    doc_id: str,
    title: str,
    text: str,
    owner_user_id: str,
    project_id: str | None = None,
    acl_users: frozenset[str] | None = None,
    chunk_size: int = 512,
    chunk_overlap: int = 64,
) -> list[RagChunk]:
    """Split a document into structure-aware chunks preserving headings and offsets."""
    effective_acl = (acl_users or frozenset()) | frozenset({owner_user_id})
    if not text.strip():
        return []

    chunks: list[RagChunk] = []
    current_heading = title
    step = max(64, chunk_size - max(0, min(chunk_overlap, chunk_size // 2)))
    length = len(text)
    pos = 0
    idx = 0

    while pos < length:
        end = min(length, pos + chunk_size)
        # Prefer breaking on paragraph or newline boundary when not at end of document
        if end < length:
            nl = text.rfind("\n\n", pos + step // 2, end)
            if nl == -1:
                nl = text.rfind("\n", pos + step // 2, end)
            if nl != -1 and nl > pos:
                end = nl

        slice_text = text[pos:end].strip()
        if slice_text:
            for m in _HEADING_RE.finditer(slice_text):
                current_heading = m.group(2).strip()[:120]
            chash = hashlib.sha256(slice_text.encode("utf-8")).hexdigest()[:16]
            toks = tuple(tokenize_rag_text(f"{title} {current_heading} {slice_text}"))
            emb = compute_semantic_vector(f"{title} {current_heading} {slice_text}")
            chunks.append(
                RagChunk(
                    chunk_id=f"{doc_id}_c{idx}",
                    doc_id=doc_id,
                    title=title,
                    owner_user_id=owner_user_id,
                    project_id=project_id,
                    acl_users=effective_acl,
                    text=slice_text,
                    heading=current_heading,
                    page=(pos // 2000) + 1,
                    start_offset=pos,
                    end_offset=end,
                    content_hash=chash,
                    tokens=toks,
                    embedding=emb,
                )
            )
            idx += 1
        if end >= length:
            break
        pos = max(pos + 1, end - chunk_overlap)

    return chunks


class RagService:
    """Hybrid Vector + BM25 RAG engine with RRF, MMR diversity, and query-time per-user ACL."""

    def __init__(self, *, vector_store_online: bool = True) -> None:
        self.vector_store_online = vector_store_online
        self._docs: dict[str, RagDocument] = {}
        self._chunks_by_doc: dict[str, list[RagChunk]] = {}
        self._all_chunks: list[RagChunk] = []
        self._inverted_index: dict[str, list[int]] = {}
        self._doc_freqs: dict[str, int] = {}
        self._avg_chunk_len: float = 1.0
        self._ingestion_checkpoints: dict[str, set[str]] = {}

    def set_vector_store_online(self, online: bool) -> None:
        """Toggle vector store availability (simulates ChromaDB up/down for degraded-mode tests)."""
        self.vector_store_online = online

    def _rebuild_indices(self) -> None:
        all_c: list[RagChunk] = []
        inv: dict[str, list[int]] = {}
        df: dict[str, int] = {}
        total_toks = 0
        for doc_chunks in self._chunks_by_doc.values():
            for ch in doc_chunks:
                c_idx = len(all_c)
                all_c.append(ch)
                total_toks += len(ch.tokens)
                seen_toks = set(ch.tokens)
                for tok in seen_toks:
                    df[tok] = df.get(tok, 0) + 1
                    inv.setdefault(tok, []).append(c_idx)
        self._all_chunks = all_c
        self._inverted_index = inv
        self._doc_freqs = df
        self._avg_chunk_len = max(1.0, total_toks / max(1, len(all_c)))

    def ingest_document(
        self,
        *,
        owner_user_id: str,
        title: str,
        text: str,
        doc_id: str | None = None,
        project_id: str | None = None,
        acl_users: frozenset[str] | None = None,
        chunk_size: int = 512,
        chunk_overlap: int = 64,
        rebuild_index: bool = True,
    ) -> RagDocument:
        """Ingest or incrementally re-index a document by content hash."""
        did = doc_id or f"doc_{uuid.uuid4().hex[:12]}"
        chash = hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]
        existing = self._docs.get(did)
        if (
            existing is not None
            and existing.content_hash == chash
            and existing.owner_user_id == owner_user_id
        ):
            return existing

        chunks = chunk_document_structure_aware(
            doc_id=did,
            title=title,
            text=text,
            owner_user_id=owner_user_id,
            project_id=project_id,
            acl_users=acl_users,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
        )
        doc = RagDocument(
            doc_id=did,
            title=title,
            owner_user_id=owner_user_id,
            project_id=project_id,
            content_hash=chash,
            chunk_count=len(chunks),
            created_at=datetime.now(UTC).isoformat(),
        )
        self._docs[did] = doc
        self._chunks_by_doc[did] = chunks
        if rebuild_index:
            self._rebuild_indices()
        return doc

    def ingest_batch_resumable(
        self,
        job_id: str,
        items: list[dict[str, Any]],
        *,
        stop_after: int | None = None,
    ) -> dict[str, Any]:
        """Ingest a batch of documents with checkpoint tracking for resumable jobs."""
        done_set = self._ingestion_checkpoints.setdefault(job_id, set())
        processed_now = 0
        for item in items:
            did = str(item["doc_id"])
            if did in done_set:
                continue
            if stop_after is not None and processed_now >= stop_after:
                self._rebuild_indices()
                return {
                    "job_id": job_id,
                    "status": "interrupted",
                    "completed_count": len(done_set),
                    "total_count": len(items),
                }
            self.ingest_document(
                owner_user_id=str(item.get("owner_user_id", "u_default")),
                title=str(item.get("title", did)),
                text=str(item.get("text", "")),
                doc_id=did,
                project_id=item.get("project_id"),
                rebuild_index=False,
            )
            done_set.add(did)
            processed_now += 1

        self._rebuild_indices()
        return {
            "job_id": job_id,
            "status": "completed",
            "completed_count": len(done_set),
            "total_count": len(items),
        }

    def delete_document(self, doc_id: str, *, requesting_user_id: str) -> bool:
        """Delete a document and cascade-remove all its chunks if owned by `requesting_user_id`."""
        doc = self._docs.get(doc_id)
        if doc is None or doc.owner_user_id != requesting_user_id:
            return False
        self._docs.pop(doc_id, None)
        self._chunks_by_doc.pop(doc_id, None)
        self._rebuild_indices()
        return True

    def list_documents(
        self, *, requesting_user_id: str, project_id: str | None = None
    ) -> list[dict[str, Any]]:
        """List documents accessible to `requesting_user_id`."""
        out: list[dict[str, Any]] = []
        for doc in self._docs.values():
            if doc.owner_user_id != requesting_user_id:
                continue
            if project_id is not None and doc.project_id != project_id:
                continue
            out.append(
                {
                    "doc_id": doc.doc_id,
                    "title": doc.title,
                    "owner_user_id": doc.owner_user_id,
                    "project_id": doc.project_id,
                    "content_hash": doc.content_hash,
                    "chunk_count": doc.chunk_count,
                    "created_at": doc.created_at,
                }
            )
        return out

    def _is_chunk_permitted(
        self,
        chunk: RagChunk,
        *,
        requesting_user_id: str,
        project_id: str | None,
    ) -> bool:
        """Hard query-time ACL enforcement (never trusts metadata filters alone)."""
        if chunk.owner_user_id != requesting_user_id and requesting_user_id not in chunk.acl_users:
            return False
        if project_id is not None and chunk.project_id != project_id:
            return False
        return True

    def query(
        self,
        query_text: str,
        *,
        requesting_user_id: str,
        project_id: str | None = None,
        top_k: int = 5,
        mode: str = "hybrid",
        mmr_lambda: float = 0.75,
    ) -> RagQueryResult:
        """Execute hybrid (RRF + MMR), vector-only, or BM25-only retrieval with hard ACL checks."""
        t0 = time.perf_counter()
        rewritten = rewrite_rag_query(query_text)
        q_tokens = tokenize_rag_text(query_text)
        effective_mode = "bm25" if (mode == "hybrid" and not self.vector_store_online) else mode
        degraded = not self.vector_store_online

        # Extract any explicit @doc:<id> or @file:<id> mentions (still strictly ACL-checked!)
        mentioned_doc_ids = set(_MENTION_DOC_RE.findall(query_text))

        total_chunks = len(self._all_chunks)
        if total_chunks == 0:
            return RagQueryResult(
                query=query_text,
                rewritten_query=rewritten,
                mode=effective_mode,
                degraded_bm25_only=degraded,
                latency_ms=(time.perf_counter() - t0) * 1000.0,
                passages=[],
            )

        # 1. BM25 scoring via inverted index (fast even on 5,000+ documents)
        bm25_scores: dict[int, float] = {}
        if effective_mode in ("hybrid", "bm25"):
            candidate_indices: set[int] = set()
            for q_tok in set(q_tokens):
                for c_idx in self._inverted_index.get(q_tok, ()):
                    candidate_indices.add(c_idx)
            for c_idx in candidate_indices:
                ch = self._all_chunks[c_idx]
                if not self._is_chunk_permitted(
                    ch, requesting_user_id=requesting_user_id, project_id=project_id
                ):
                    continue
                doc_len = float(len(ch.tokens))
                score = 0.0
                for q_tok in set(q_tokens):
                    tf = ch.tokens.count(q_tok)
                    if tf == 0:
                        continue
                    df = self._doc_freqs.get(q_tok, 0)
                    idf = math.log(1.0 + (total_chunks - df + 0.5) / (df + 0.5))
                    denom = tf + 1.5 * (1.0 - 0.75 + 0.75 * (doc_len / self._avg_chunk_len))
                    score += idf * ((tf * 2.5) / denom)
                if ch.doc_id in mentioned_doc_ids:
                    score += 5.0
                if score > 0.0:
                    bm25_scores[c_idx] = score

        # 2. Vector similarity scoring
        vec_scores: dict[int, float] = {}
        if effective_mode in ("hybrid", "vector"):
            q_vec = compute_semantic_vector(query_text)
            for c_idx, ch in enumerate(self._all_chunks):
                if not self._is_chunk_permitted(
                    ch, requesting_user_id=requesting_user_id, project_id=project_id
                ):
                    continue
                sim = _dot(q_vec, ch.embedding)
                if ch.doc_id in mentioned_doc_ids:
                    sim += 0.5
                if sim > 0.0:
                    vec_scores[c_idx] = sim

        # 3. Rank + score fusion (RRF + normalized score fusion for hybrid)
        bm25_ranked = sorted(bm25_scores.keys(), key=lambda i: bm25_scores[i], reverse=True)[:50]
        vec_ranked = sorted(vec_scores.keys(), key=lambda i: vec_scores[i], reverse=True)[:50]

        fused_scores: dict[int, float] = {}
        if effective_mode == "bm25":
            for idx in bm25_ranked:
                fused_scores[idx] = bm25_scores[idx]
        elif effective_mode == "vector":
            for idx in vec_ranked:
                fused_scores[idx] = vec_scores[idx]
        else:
            rrf_k = 20.0
            max_bm25 = max(bm25_scores.values(), default=1.0) or 1.0
            max_vec = max(vec_scores.values(), default=1.0) or 1.0
            for rank, idx in enumerate(bm25_ranked, start=1):
                norm_b = bm25_scores[idx] / max_bm25
                fused_scores[idx] = (
                    fused_scores.get(idx, 0.0) + (1.0 / (rrf_k + rank)) + 0.5 * norm_b
                )
            for rank, idx in enumerate(vec_ranked, start=1):
                norm_v = vec_scores[idx] / max_vec
                fused_scores[idx] = (
                    fused_scores.get(idx, 0.0) + (1.0 / (rrf_k + rank)) + 0.5 * norm_v
                )

        candidates = sorted(fused_scores.keys(), key=lambda i: fused_scores[i], reverse=True)[:25]

        # 4. Maximal Marginal Relevance (MMR) selection + final hard ACL post-check
        selected: list[int] = []
        while candidates and len(selected) < top_k:
            best_idx = candidates[0]
            best_mmr = -1e9
            for c_idx in candidates:
                rel = fused_scores[c_idx]
                if not selected:
                    mmr_val = rel
                else:
                    max_sim = max(
                        _dot(self._all_chunks[c_idx].embedding, self._all_chunks[s_idx].embedding)
                        for s_idx in selected
                    )
                    mmr_val = mmr_lambda * rel - (1.0 - mmr_lambda) * max(0.0, max_sim) * 0.02
                if mmr_val > best_mmr:
                    best_mmr = mmr_val
                    best_idx = c_idx
            selected.append(best_idx)
            candidates.remove(best_idx)

        passages: list[dict[str, Any]] = []
        for s_idx in selected:
            ch = self._all_chunks[s_idx]
            # Final defense-in-depth ACL assertion before returning passage
            assert self._is_chunk_permitted(
                ch, requesting_user_id=requesting_user_id, project_id=project_id
            )
            passages.append(ch.to_passage_dict(fused_scores[s_idx], effective_mode))

        latency_ms = (time.perf_counter() - t0) * 1000.0
        return RagQueryResult(
            query=query_text,
            rewritten_query=rewritten,
            mode=effective_mode,
            degraded_bm25_only=degraded,
            latency_ms=latency_ms,
            passages=passages,
        )


def evaluate_hybrid_retrieval_benchmark(num_pairs: int = 100) -> RagEvalSummary:
    """Run a deterministic >= 100 Q/A benchmark comparing Vector-only, BM25-only, and Hybrid RRF."""
    total = max(100, num_pairs)
    rag = RagService(vector_store_online=True)
    qa_pairs: list[tuple[str, str]] = []

    for i in range(total):
        doc_id = f"bench_doc_{i:03d}"
        c1 = i % len(_CONCEPT_CLUSTERS)
        c2 = ((i // len(_CONCEPT_CLUSTERS)) + 1) % len(_CONCEPT_CLUSTERS)
        if c1 == c2:
            c2 = (c2 + 1) % len(_CONCEPT_CLUSTERS)
        w1_doc, w1_query = _CONCEPT_CLUSTERS[c1][1][0], _CONCEPT_CLUSTERS[c1][1][1]
        w2_doc, w2_query = _CONCEPT_CLUSTERS[c2][1][2], _CONCEPT_CLUSTERS[c2][1][3]
        exact_code = f"ERR_CODE_{i:04d}_X{(i * 7) % 97:02d}"

        # Half of the benchmark queries test exact identifier/error-code recall (where BM25 shines),
        # and half test conceptual synonym paraphrase recall (where semantic vector shines).
        doc_text = (
            f"# Engineering Runbook {i}\n"
            f"Subsystem handling {w1_doc} and {w2_doc} operations. "
            f"Diagnostic reference identifier is {exact_code}."
        )
        rag.ingest_document(
            owner_user_id="bench_user",
            title=f"Runbook {i}",
            text=doc_text,
            doc_id=doc_id,
            rebuild_index=False,
        )
        if i % 2 == 0:
            query = f"Lookup {exact_code}"
        else:
            query = f"Troubleshooting {w1_query} {w2_query}"
        qa_pairs.append((query, doc_id))

    rag._rebuild_indices()

    vec_hits = 0
    bm25_hits = 0
    hybrid_hits = 0

    for query, target_doc_id in qa_pairs:
        res_vec = rag.query(query, requesting_user_id="bench_user", top_k=5, mode="vector")
        res_bm25 = rag.query(query, requesting_user_id="bench_user", top_k=5, mode="bm25")
        res_hyb = rag.query(query, requesting_user_id="bench_user", top_k=5, mode="hybrid")

        if any(p["doc_id"] == target_doc_id for p in res_vec.passages):
            vec_hits += 1
        if any(p["doc_id"] == target_doc_id for p in res_bm25.passages):
            bm25_hits += 1
        if any(p["doc_id"] == target_doc_id for p in res_hyb.passages):
            hybrid_hits += 1

    return RagEvalSummary(
        total_questions=total,
        vector_only_recall_at_5=vec_hits / total,
        bm25_only_recall_at_5=bm25_hits / total,
        hybrid_rrf_recall_at_5=hybrid_hits / total,
    )
