"""Knowledge Base & Hybrid RAG domain package (Phase 06 §1.3)."""

from backend.domain.rag.service import (
    RagChunk,
    RagDocument,
    RagEvalSummary,
    RagQueryResult,
    RagService,
    chunk_document_structure_aware,
    evaluate_hybrid_retrieval_benchmark,
    rewrite_rag_query,
)

__all__ = [
    "RagChunk",
    "RagDocument",
    "RagEvalSummary",
    "RagQueryResult",
    "RagService",
    "chunk_document_structure_aware",
    "evaluate_hybrid_retrieval_benchmark",
    "rewrite_rag_query",
]
