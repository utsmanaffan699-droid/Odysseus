"""Deep Research & Citation Verification domain package (Phase 06 §1.2, §1.4)."""

from backend.domain.research.citations import (
    CitationVerificationReport,
    QuoteVerificationItem,
    verify_citations_and_quotes,
)
from backend.domain.research.service import (
    DEPTH_BUDGET_PRESETS,
    MODEL_PROFILE_PRESETS,
    REPORT_STRICT_CSP,
    RESEARCH_STAGES,
    DeepResearchService,
    ResearchRunRecord,
    render_sanitized_research_report,
)

__all__ = [
    "DEPTH_BUDGET_PRESETS",
    "MODEL_PROFILE_PRESETS",
    "REPORT_STRICT_CSP",
    "RESEARCH_STAGES",
    "CitationVerificationReport",
    "DeepResearchService",
    "QuoteVerificationItem",
    "ResearchRunRecord",
    "render_sanitized_research_report",
    "verify_citations_and_quotes",
]
