"""Citation verification, quote-checking, and citation-laundering defense (Phase 06 §1.2)."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

_CITATION_MARKER_RE = re.compile(r"\[(\d+)\]")
_QUOTED_CITATION_RE = re.compile(r'"([^"\n]{8,400})"\s*(?:\(\s*\[(\d+)\]\s*\)|\[(\d+)\])')
_WORD_RE = re.compile(r"[a-z0-9]{2,}")


def _normalize_for_quote_match(text: str) -> str:
    return " ".join(_WORD_RE.findall(text.lower()))


def _fuzzy_quote_match(quote: str, source_text: str, *, threshold: float = 0.78) -> float:
    norm_q = _normalize_for_quote_match(quote)
    norm_s = _normalize_for_quote_match(source_text)
    if not norm_q or not norm_s:
        return 0.0
    if norm_q in norm_s:
        return 1.0
    q_tokens = norm_q.split()
    s_token_set = set(norm_s.split())
    if not q_tokens:
        return 0.0
    matched = sum(1 for tok in q_tokens if tok in s_token_set)
    ratio = matched / len(q_tokens)
    # Require contiguous 3-gram overlap if length >= 4 to prevent bag-of-words false positives
    if len(q_tokens) >= 4 and ratio >= threshold:
        ngrams = [" ".join(q_tokens[i : i + 3]) for i in range(len(q_tokens) - 2)]
        ngram_hits = sum(1 for ng in ngrams if ng in norm_s)
        if ngram_hits == 0:
            return ratio * 0.5
    return round(ratio, 4)


@dataclass(frozen=True)
class QuoteVerificationItem:
    """Verification outcome for a single quoted claim tied to a citation `[n]`."""

    quote: str
    cited_id: int
    verified: bool
    match_score: float
    laundered_from_id: int | None = None
    reason: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "quote": self.quote,
            "cited_id": self.cited_id,
            "verified": self.verified,
            "match_score": self.match_score,
            "laundered_from_id": self.laundered_from_id,
            "reason": self.reason,
        }


@dataclass(frozen=True)
class CitationVerificationReport:
    """Post-processed text, verified citations, quote checks, and emitted notices."""

    cleaned_text: str
    valid_citation_ids: list[int]
    dangling_citation_ids: list[int]
    quote_checks: list[QuoteVerificationItem]
    notices: list[dict[str, str]] = field(default_factory=list)

    @property
    def unverified_quotes(self) -> list[QuoteVerificationItem]:
        return [q for q in self.quote_checks if not q.verified]

    def to_dict(self) -> dict[str, Any]:
        return {
            "cleaned_text": self.cleaned_text,
            "valid_citation_ids": self.valid_citation_ids,
            "dangling_citation_ids": self.dangling_citation_ids,
            "quote_checks": [q.to_dict() for q in self.quote_checks],
            "unverified_quote_count": len(self.unverified_quotes),
            "notices": list(self.notices),
        }


def verify_citations_and_quotes(
    answer_text: str,
    sources_by_id: dict[int, dict[str, Any]],
    *,
    fuzzy_threshold: float = 0.78,
) -> CitationVerificationReport:
    """Verify `[n]` citations against retrieved sources, strip dangling `[n]`, and check quotes."""
    valid_ids: list[int] = []
    dangling_ids: list[int] = []
    notices: list[dict[str, str]] = []
    quote_checks: list[QuoteVerificationItem] = []

    # 1. Inspect quoted claims tied to [n] BEFORE stripping dangling citations
    for match in _QUOTED_CITATION_RE.finditer(answer_text):
        quote_str = match.group(1).strip()
        cid_str = match.group(2) or match.group(3)
        cid = int(cid_str)
        src = sources_by_id.get(cid)
        if src is None:
            quote_checks.append(
                QuoteVerificationItem(
                    quote=quote_str,
                    cited_id=cid,
                    verified=False,
                    match_score=0.0,
                    reason=f"Cited source [{cid}] does not exist",
                )
            )
            continue

        src_text = str(src.get("text") or src.get("snippet") or "")
        score = _fuzzy_quote_match(quote_str, src_text, threshold=fuzzy_threshold)
        if score >= fuzzy_threshold:
            quote_checks.append(
                QuoteVerificationItem(
                    quote=quote_str,
                    cited_id=cid,
                    verified=True,
                    match_score=score,
                    reason="Verified in cited source",
                )
            )
        else:
            # Check if this quote was laundered from a different source in the pool
            laundered_from: int | None = None
            for other_id, other_src in sources_by_id.items():
                if other_id == cid:
                    continue
                other_text = str(other_src.get("text") or other_src.get("snippet") or "")
                if (
                    _fuzzy_quote_match(quote_str, other_text, threshold=fuzzy_threshold)
                    >= fuzzy_threshold
                ):
                    laundered_from = other_id
                    break

            reason = (
                f"Citation laundering: quote in [{laundered_from}], not cited source [{cid}]"
                if laundered_from is not None
                else f"Quote not found in cited source [{cid}] (score={score:.2f})"
            )
            quote_checks.append(
                QuoteVerificationItem(
                    quote=quote_str,
                    cited_id=cid,
                    verified=False,
                    match_score=score,
                    laundered_from_id=laundered_from,
                    reason=reason,
                )
            )
            notices.append(
                {
                    "level": "warn",
                    "code": (
                        "citation_laundering_detected"
                        if laundered_from is not None
                        else "unverified_quote_flagged"
                    ),
                    "text": reason,
                }
            )

    # 2. Strip dangling/invented [n] markers
    def _replace_marker(m: re.Match[str]) -> str:
        cid = int(m.group(1))
        if cid in sources_by_id:
            if cid not in valid_ids:
                valid_ids.append(cid)
            return m.group(0)
        if cid not in dangling_ids:
            dangling_ids.append(cid)
        return ""

    cleaned = _CITATION_MARKER_RE.sub(_replace_marker, answer_text)
    cleaned = re.sub(r"  +", " ", cleaned)

    for did in dangling_ids:
        notices.append(
            {
                "level": "warn",
                "code": "dangling_citation_stripped",
                "text": f"Stripped invented or unretrieved citation [{did}] from answer.",
            }
        )

    return CitationVerificationReport(
        cleaned_text=cleaned.strip(),
        valid_citation_ids=valid_ids,
        dangling_citation_ids=dangling_ids,
        quote_checks=quote_checks,
        notices=notices,
    )
