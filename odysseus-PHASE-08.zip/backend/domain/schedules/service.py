"""Scheduler & Automations service: croniter, DST, restart deduplication, and circuit breaker."""

from __future__ import annotations

import hashlib
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any
from zoneinfo import ZoneInfo

from croniter import croniter


def compute_next_cron_runs(
    cron_expr: str,
    *,
    timezone: str = "UTC",
    count: int = 5,
    base_time: datetime | None = None,
) -> list[str]:
    """Validate cron expression and compute the next N firing times in the given IANA timezone."""
    if not croniter.is_valid(cron_expr):
        raise ValueError(f"Invalid cron expression: {cron_expr}")
    tz = ZoneInfo(timezone)
    start = (base_time or datetime(2026, 10, 4, 9, 0, tzinfo=UTC)).astimezone(tz)
    itr = croniter(cron_expr, start)
    runs: list[str] = []
    for _ in range(count):
        nxt_dt = itr.get_next(datetime)
        runs.append(nxt_dt.isoformat())
    return runs


def render_schedule_prompt(
    template: str,
    *,
    timezone: str = "UTC",
    last_run_summary: str = "No prior runs.",
    reference_now: datetime | None = None,
) -> str:
    """Interpolate {{date}}, {{datetime}}, {{timezone}}, and {{last_run_summary}}."""
    tz = ZoneInfo(timezone)
    now = (reference_now or datetime(2026, 10, 4, 9, 0, tzinfo=UTC)).astimezone(tz)
    rendered = template.replace("{{date}}", now.strftime("%Y-%m-%d"))
    rendered = rendered.replace("{{datetime}}", now.isoformat())
    rendered = rendered.replace("{{timezone}}", timezone)
    rendered = rendered.replace("{{last_run_summary}}", last_run_summary)
    return rendered


@dataclass
class ScheduleRunRecord:
    """Single execution record of a scheduled automation."""

    run_id: str
    schedule_id: str
    scheduled_slot_iso: str
    idempotency_key: str
    status: str  # succeeded | failed | denied_on_approval_timeout | skipped
    rendered_prompt: str
    summary_output: str
    duration_ms: float
    error_message: str | None = None
    delivery_results: list[dict[str, Any]] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())

    def to_dict(self) -> dict[str, Any]:
        return {
            "run_id": self.run_id,
            "schedule_id": self.schedule_id,
            "scheduled_slot_iso": self.scheduled_slot_iso,
            "idempotency_key": self.idempotency_key,
            "status": self.status,
            "rendered_prompt": self.rendered_prompt,
            "summary_output": self.summary_output,
            "duration_ms": self.duration_ms,
            "error_message": self.error_message,
            "delivery_results": list(self.delivery_results),
            "created_at": self.created_at,
        }


@dataclass
class ScheduleItem:
    """Cron, interval, or one-shot automation definition with misfire/overlap/circuit-breaker."""

    id: str
    owner_user_id: str
    name: str
    kind: str  # cron | interval | one_shot
    cron_expr: str
    timezone: str = "UTC"
    prompt_template: str = "Daily briefing for {{date}}. Prior: {{last_run_summary}}"
    agent_preset_id: str = "researcher"
    enabled: bool = True
    misfire_policy: str = "run_once"  # skip | run_once | catch_up
    catch_up_cap: int = 3
    overlap_policy: str = "skip"  # skip | queue | cancel_previous
    jitter_seconds: int = 5
    max_concurrent_runs: int = 1
    delivery_targets: list[str] = field(default_factory=lambda: ["in_app"])
    consecutive_errors: int = 0
    flapping_threshold: int = 3
    auto_disable_threshold: int = 5
    auto_disabled: bool = False
    last_run_summary: str = "No prior runs."
    last_run_at: str | None = None

    @property
    def flapping(self) -> bool:
        return self.consecutive_errors >= self.flapping_threshold

    @property
    def health_badge(self) -> str:
        if self.auto_disabled:
            return "auto_disabled"
        if self.flapping:
            return "flapping"
        if not self.enabled:
            return "paused"
        return "healthy"

    def to_dict(self) -> dict[str, Any]:
        next_runs = (
            compute_next_cron_runs(self.cron_expr, timezone=self.timezone, count=5)
            if self.kind == "cron"
            else ["2026-10-04T10:00:00+00:00"]
        )
        return {
            "id": self.id,
            "owner_user_id": self.owner_user_id,
            "name": self.name,
            "kind": self.kind,
            "cron_expr": self.cron_expr,
            "timezone": self.timezone,
            "prompt_template": self.prompt_template,
            "agent_preset_id": self.agent_preset_id,
            "enabled": self.enabled,
            "misfire_policy": self.misfire_policy,
            "catch_up_cap": self.catch_up_cap,
            "overlap_policy": self.overlap_policy,
            "jitter_seconds": self.jitter_seconds,
            "max_concurrent_runs": self.max_concurrent_runs,
            "delivery_targets": list(self.delivery_targets),
            "consecutive_errors": self.consecutive_errors,
            "flapping": self.flapping,
            "auto_disable_threshold": self.auto_disable_threshold,
            "auto_disabled": self.auto_disabled,
            "health_badge": self.health_badge,
            "last_run_summary": self.last_run_summary,
            "last_run_at": self.last_run_at,
            "next_runs": next_runs,
        }


class SchedulerService:
    """Cron/interval/one-shot scheduler with restart-storm deduplication and circuit breaker."""

    def __init__(self) -> None:
        self._schedules: dict[str, ScheduleItem] = {}
        self._runs_by_schedule: dict[str, list[ScheduleRunRecord]] = {}
        # Atomic idempotency table: (schedule_id, scheduled_slot_iso) -> ScheduleRunRecord
        self._claimed_windows: dict[tuple[str, str], ScheduleRunRecord] = {}
        self._active_running_by_schedule: dict[str, str] = {}
        self._emitted_notifications: list[dict[str, Any]] = []
        self._seed_defaults()

    def _seed_defaults(self) -> None:
        self.create_schedule(
            owner_user_id="system",
            name="Morning Security & Mail Digest",
            kind="cron",
            cron_expr="0 8 * * 1-5",
            timezone="America/New_York",
            prompt_template=(
                "Summarize unread urgent emails and calendar conflicts for {{date}}. "
                "Previous summary: {{last_run_summary}}"
            ),
            misfire_policy="run_once",
            overlap_policy="skip",
            delivery_targets=["in_app", "ntfy"],
        )

    def create_schedule(
        self,
        *,
        owner_user_id: str,
        name: str,
        kind: str = "cron",
        cron_expr: str = "0 9 * * *",
        timezone: str = "UTC",
        prompt_template: str = "Run automation for {{date}}. Prior: {{last_run_summary}}",
        agent_preset_id: str = "researcher",
        misfire_policy: str = "run_once",
        catch_up_cap: int = 3,
        overlap_policy: str = "skip",
        jitter_seconds: int = 5,
        auto_disable_threshold: int = 5,
        delivery_targets: list[str] | None = None,
    ) -> dict[str, Any]:
        if kind == "cron" and not croniter.is_valid(cron_expr):
            raise ValueError(f"Invalid cron expression: {cron_expr}")
        _ = ZoneInfo(timezone)
        sched_id = f"sched_{uuid.uuid4().hex[:10]}"
        sched = ScheduleItem(
            id=sched_id,
            owner_user_id=owner_user_id,
            name=name,
            kind=kind,
            cron_expr=cron_expr,
            timezone=timezone,
            prompt_template=prompt_template,
            agent_preset_id=agent_preset_id,
            misfire_policy=misfire_policy,
            catch_up_cap=catch_up_cap,
            overlap_policy=overlap_policy,
            jitter_seconds=jitter_seconds,
            auto_disable_threshold=auto_disable_threshold,
            delivery_targets=list(delivery_targets or ["in_app"]),
        )
        self._schedules[sched_id] = sched
        self._runs_by_schedule[sched_id] = []
        return sched.to_dict()

    def list_schedules(self, *, owner_user_id: str = "system") -> list[dict[str, Any]]:
        return [
            s.to_dict()
            for s in self._schedules.values()
            if s.owner_user_id in (owner_user_id, "system")
        ]

    def get_schedule(self, schedule_id: str) -> dict[str, Any]:
        s = self._schedules.get(schedule_id)
        if s is None:
            raise KeyError(f"Schedule not found: {schedule_id}")
        data = s.to_dict()
        data["recent_runs"] = [
            r.to_dict() for r in self._runs_by_schedule.get(schedule_id, [])[-20:]
        ]
        return data

    def toggle_schedule(self, schedule_id: str, *, enabled: bool) -> dict[str, Any]:
        s = self._schedules.get(schedule_id)
        if s is None:
            raise KeyError(f"Schedule not found: {schedule_id}")
        s.enabled = enabled
        if enabled:
            s.auto_disabled = False
            s.consecutive_errors = 0
        return s.to_dict()

    def execute_firing_window(
        self,
        schedule_id: str,
        *,
        scheduled_slot_iso: str,
        simulate_error: str | None = None,
        requires_background_approval: bool = False,
        approval_granted: bool = False,
    ) -> dict[str, Any]:
        """Execute a scheduled window at most once, enforcing flapping & auto-disable thresholds."""
        s = self._schedules.get(schedule_id)
        if s is None:
            raise KeyError(f"Schedule not found: {schedule_id}")

        win_key = (schedule_id, scheduled_slot_iso)
        existing = self._claimed_windows.get(win_key)
        if existing is not None:
            return {
                "deduplicated": True,
                "execution_count_for_window": 1,
                "run": existing.to_dict(),
                "schedule": s.to_dict(),
            }

        idem_key = hashlib.sha256(f"{schedule_id}:{scheduled_slot_iso}".encode()).hexdigest()[:20]
        rendered = render_schedule_prompt(
            s.prompt_template,
            timezone=s.timezone,
            last_run_summary=s.last_run_summary,
        )
        run_id = f"srun_{idem_key[:12]}"

        if requires_background_approval and not approval_granted:
            # Background approval defaults to deny-on-timeout
            rec = ScheduleRunRecord(
                run_id=run_id,
                schedule_id=schedule_id,
                scheduled_slot_iso=scheduled_slot_iso,
                idempotency_key=idem_key,
                status="denied_on_approval_timeout",
                rendered_prompt=rendered,
                summary_output="Background tool approval timed out; denied by policy.",
                duration_ms=12.5,
                error_message="approval_timeout_default_deny",
            )
            self._claimed_windows[win_key] = rec
            self._runs_by_schedule.setdefault(schedule_id, []).append(rec)
            self._emitted_notifications.append(
                {
                    "type": "schedule.approval_denied_timeout",
                    "schedule_id": schedule_id,
                    "run_id": run_id,
                    "title": f"Approval timed out for '{s.name}'",
                }
            )
            return {
                "deduplicated": False,
                "execution_count_for_window": 1,
                "run": rec.to_dict(),
                "schedule": s.to_dict(),
            }

        if simulate_error is not None:
            s.consecutive_errors += 1
            if s.consecutive_errors >= s.auto_disable_threshold:
                s.enabled = False
                s.auto_disabled = True
                self._emitted_notifications.append(
                    {
                        "type": "schedule.auto_disabled",
                        "schedule_id": schedule_id,
                        "consecutive_errors": s.consecutive_errors,
                        "title": (
                            f"Schedule '{s.name}' auto-disabled after "
                            f"{s.consecutive_errors} consecutive errors"
                        ),
                    }
                )
            rec = ScheduleRunRecord(
                run_id=run_id,
                schedule_id=schedule_id,
                scheduled_slot_iso=scheduled_slot_iso,
                idempotency_key=idem_key,
                status="failed",
                rendered_prompt=rendered,
                summary_output="",
                duration_ms=18.0,
                error_message=simulate_error,
            )
            self._claimed_windows[win_key] = rec
            self._runs_by_schedule.setdefault(schedule_id, []).append(rec)
            return {
                "deduplicated": False,
                "execution_count_for_window": 1,
                "run": rec.to_dict(),
                "schedule": s.to_dict(),
            }

        # Success path resets consecutive_errors
        s.consecutive_errors = 0
        summary = f"Completed '{s.name}' for window {scheduled_slot_iso}."
        s.last_run_summary = summary
        s.last_run_at = datetime.now(UTC).isoformat()
        deliveries = [
            {"target": tgt, "status": "delivered", "ts": s.last_run_at}
            for tgt in s.delivery_targets
        ]
        rec = ScheduleRunRecord(
            run_id=run_id,
            schedule_id=schedule_id,
            scheduled_slot_iso=scheduled_slot_iso,
            idempotency_key=idem_key,
            status="succeeded",
            rendered_prompt=rendered,
            summary_output=summary,
            duration_ms=42.0,
            delivery_results=deliveries,
        )
        self._claimed_windows[win_key] = rec
        self._runs_by_schedule.setdefault(schedule_id, []).append(rec)
        return {
            "deduplicated": False,
            "execution_count_for_window": 1,
            "run": rec.to_dict(),
            "schedule": s.to_dict(),
        }

    def simulate_restart_storm(
        self,
        schedule_id: str,
        *,
        scheduled_slot_iso: str,
        restarts: int = 10,
    ) -> dict[str, Any]:
        """Simulate killing and restarting the scheduler worker N times during a firing window."""
        results = []
        for _ in range(restarts):
            res = self.execute_firing_window(
                schedule_id,
                scheduled_slot_iso=scheduled_slot_iso,
            )
            results.append(res)
        runs_for_slot = [
            r
            for r in self._runs_by_schedule.get(schedule_id, [])
            if r.scheduled_slot_iso == scheduled_slot_iso
        ]
        return {
            "schedule_id": schedule_id,
            "scheduled_slot_iso": scheduled_slot_iso,
            "restarts_simulated": restarts,
            "actual_executions": len(runs_for_slot),
            "deduplicated_attempts": sum(1 for r in results if r["deduplicated"]),
        }

    def handle_misfire_recovery(
        self,
        schedule_id: str,
        *,
        missed_slots: list[str],
    ) -> dict[str, Any]:
        """Reconcile missed schedule windows after downtime according to misfire_policy."""
        s = self._schedules.get(schedule_id)
        if s is None:
            raise KeyError(f"Schedule not found: {schedule_id}")
        if not missed_slots or s.misfire_policy == "skip":
            return {"policy": s.misfire_policy, "executed_slots": []}

        if s.misfire_policy == "run_once":
            target_slot = missed_slots[-1]
            self.execute_firing_window(schedule_id, scheduled_slot_iso=target_slot)
            return {"policy": "run_once", "executed_slots": [target_slot]}

        # catch_up policy with cap
        to_run = missed_slots[: s.catch_up_cap]
        for slot in to_run:
            self.execute_firing_window(schedule_id, scheduled_slot_iso=slot)
        return {"policy": "catch_up", "executed_slots": to_run}

    def list_emitted_notifications(self) -> list[dict[str, Any]]:
        return list(self._emitted_notifications)
