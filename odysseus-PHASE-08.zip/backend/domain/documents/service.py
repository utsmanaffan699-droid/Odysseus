"""Documents & Spreadsheet Workspace: versions, diffs, ETag 3-way merge, AI edits, Q&A."""

from __future__ import annotations

import difflib
import hashlib
import html
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any, Literal

DocFormatLiteral = Literal["markdown", "html", "csv", "code", "txt"]
AiAuthoringActionLiteral = Literal[
    "rewrite",
    "shorten",
    "expand",
    "translate",
    "tone_formal",
    "summarize",
    "extract_action_items",
    "continue_writing",
]


def _compute_etag(version: int, content: str) -> str:
    digest = hashlib.sha256(content.encode("utf-8")).hexdigest()[:16]
    return f'W/"v{version}-{digest}"'


def merge_three_way(base_text: str, server_text: str, client_text: str) -> dict[str, Any]:
    """Perform a line-based 3-way merge between `base_text`, `server_text`, and `client_text`."""
    base_lines = base_text.splitlines()
    server_lines = server_text.splitlines()
    client_lines = client_text.splitlines()

    if server_text == client_text:
        return {
            "merged_text": server_text,
            "has_conflicts": False,
            "conflict_count": 0,
        }
    if base_text == server_text:
        return {
            "merged_text": client_text,
            "has_conflicts": False,
            "conflict_count": 0,
        }
    if base_text == client_text:
        return {
            "merged_text": server_text,
            "has_conflicts": False,
            "conflict_count": 0,
        }

    # Collect additions/modifications from both sides relative to base
    s_matcher = difflib.SequenceMatcher(None, base_lines, server_lines)
    c_matcher = difflib.SequenceMatcher(None, base_lines, client_lines)
    s_edits: dict[tuple[int, int], list[str]] = {}
    c_edits: dict[tuple[int, int], list[str]] = {}

    for tag, i1, i2, j1, j2 in s_matcher.get_opcodes():
        if tag != "equal":
            s_edits[(i1, i2)] = server_lines[j1:j2]
    for tag, i1, i2, j1, j2 in c_matcher.get_opcodes():
        if tag != "equal":
            c_edits[(i1, i2)] = client_lines[j1:j2]

    # If edits touch disjoint line ranges in base_lines, apply both cleanly;
    # otherwise include both changes in a non-destructive merged output.
    merged_out: list[str] = []
    conflicts = 0
    idx = 0
    n_base = len(base_lines)

    while idx <= n_base:
        s_hit = next(((span, lines) for span, lines in s_edits.items() if span[0] == idx), None)
        c_hit = next(((span, lines) for span, lines in c_edits.items() if span[0] == idx), None)

        if s_hit and c_hit:
            s_span, s_rep = s_hit
            c_span, c_rep = c_hit
            if s_rep == c_rep:
                merged_out.extend(s_rep)
            else:
                conflicts += 1
                merged_out.extend(s_rep)
                for line in c_rep:
                    if line not in s_rep:
                        merged_out.append(line)
            next_idx = max(s_span[1], c_span[1])
            idx = next_idx if next_idx > idx else idx + 1
            if next_idx == idx and idx == n_base:
                break
            continue
        if s_hit:
            s_span, s_rep = s_hit
            merged_out.extend(s_rep)
            if s_span[1] > idx:
                idx = s_span[1]
                continue
        if c_hit:
            c_span, c_rep = c_hit
            merged_out.extend(c_rep)
            if c_span[1] > idx:
                idx = c_span[1]
                continue
        if idx < n_base:
            merged_out.append(base_lines[idx])
        idx += 1

    return {
        "merged_text": "\n".join(merged_out),
        "has_conflicts": conflicts > 0,
        "conflict_count": conflicts,
    }


@dataclass
class DocumentVersionRecord:
    """Snapshot of a document at a specific version."""

    version: int
    etag: str
    content: str
    summary: str
    created_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())

    def to_dict(self, *, include_content: bool = False) -> dict[str, Any]:
        data: dict[str, Any] = {
            "version": self.version,
            "etag": self.etag,
            "summary": self.summary,
            "byte_length": len(self.content.encode("utf-8")),
            "created_at": self.created_at,
        }
        if include_content:
            data["content"] = self.content
        return data


@dataclass
class DocumentSuggestion:
    """Tracked AI edit suggestion that requires user acceptance before mutating document content."""

    id: str
    doc_id: str
    action: str
    original_text: str
    proposed_text: str
    rationale: str
    status: str = "pending"  # "pending" | "accepted" | "rejected"
    created_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "doc_id": self.doc_id,
            "action": self.action,
            "original_text": self.original_text,
            "proposed_text": self.proposed_text,
            "rationale": self.rationale,
            "status": self.status,
            "created_at": self.created_at,
        }


@dataclass
class DocumentRecord:
    """Full workspace document record with versions, tags, folders, and suggestions."""

    id: str
    owner_user_id: str
    project_id: str | None
    title: str
    folder: str
    tags: list[str]
    format: DocFormatLiteral
    content: str
    version: int
    etag: str
    versions: list[DocumentVersionRecord] = field(default_factory=list)
    suggestions: list[DocumentSuggestion] = field(default_factory=list)
    deleted_at: str | None = None
    created_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())

    def to_dict(self, *, include_content: bool = True) -> dict[str, Any]:
        out: dict[str, Any] = {
            "id": self.id,
            "owner_user_id": self.owner_user_id,
            "project_id": self.project_id,
            "title": self.title,
            "folder": self.folder,
            "tags": list(self.tags),
            "format": self.format,
            "version": self.version,
            "etag": self.etag,
            "byte_length": len(self.content.encode("utf-8")),
            "line_count": len(self.content.splitlines()),
            "versions": [v.to_dict(include_content=False) for v in self.versions],
            "suggestions": [s.to_dict() for s in self.suggestions],
            "deleted_at": self.deleted_at,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }
        if include_content:
            out["content"] = self.content
        return out


class DocumentsService:
    """Document & Spreadsheet management service with 3-way merge, diffs, AI authoring, and Q&A."""

    def __init__(self) -> None:
        self._docs: dict[str, DocumentRecord] = {}

    def create_document(
        self,
        *,
        owner_user_id: str,
        title: str,
        content: str,
        doc_format: DocFormatLiteral = "markdown",
        folder: str = "/",
        tags: list[str] | None = None,
        project_id: str | None = None,
        doc_id: str | None = None,
    ) -> DocumentRecord:
        did = doc_id or f"doc_{uuid.uuid4().hex[:12]}"
        etag = _compute_etag(1, content)
        v1 = DocumentVersionRecord(version=1, etag=etag, content=content, summary="Initial version")
        rec = DocumentRecord(
            id=did,
            owner_user_id=owner_user_id,
            project_id=project_id,
            title=title,
            folder=folder,
            tags=list(tags or []),
            format=doc_format,
            content=content,
            version=1,
            etag=etag,
            versions=[v1],
        )
        self._docs[did] = rec
        return rec

    def get_document(self, doc_id: str, *, requesting_user_id: str) -> DocumentRecord | None:
        doc = self._docs.get(doc_id)
        if doc is None or doc.deleted_at is not None:
            return None
        if doc.owner_user_id != requesting_user_id:
            return None
        return doc

    def list_documents(
        self,
        *,
        requesting_user_id: str,
        folder: str | None = None,
        tag: str | None = None,
        search_query: str | None = None,
    ) -> list[dict[str, Any]]:
        results: list[dict[str, Any]] = []
        q_lower = (search_query or "").strip().lower()
        for doc in sorted(self._docs.values(), key=lambda d: d.updated_at, reverse=True):
            if doc.deleted_at is not None or doc.owner_user_id != requesting_user_id:
                continue
            if folder is not None and doc.folder != folder:
                continue
            if tag is not None and tag not in doc.tags:
                continue
            if q_lower and q_lower not in doc.title.lower() and q_lower not in doc.content.lower():
                continue
            results.append(doc.to_dict(include_content=False))
        return results

    def update_document(
        self,
        doc_id: str,
        *,
        requesting_user_id: str,
        content: str | None = None,
        title: str | None = None,
        folder: str | None = None,
        tags: list[str] | None = None,
        expected_version: int | None = None,
        expected_etag: str | None = None,
        force_merge: bool = False,
        summary: str = "Updated document",
    ) -> dict[str, Any]:
        """Update document with ETag/version concurrency guard and 3-way merge resolution."""
        doc = self.get_document(doc_id, requesting_user_id=requesting_user_id)
        if doc is None:
            raise KeyError(f"Document '{doc_id}' not found")

        version_mismatch = expected_version is not None and expected_version != doc.version
        etag_mismatch = expected_etag is not None and expected_etag != doc.etag

        if (version_mismatch or etag_mismatch) and content is not None:
            # Locate base version for 3-way merge
            base_ver = expected_version or max(1, doc.version - 1)
            base_rec = next((v for v in doc.versions if v.version == base_ver), doc.versions[0])
            merge_info = merge_three_way(base_rec.content, doc.content, content)

            if not force_merge:
                return {
                    "status": "conflict",
                    "doc_id": doc.id,
                    "server_version": doc.version,
                    "server_etag": doc.etag,
                    "base_version": base_rec.version,
                    "base_content": base_rec.content,
                    "server_content": doc.content,
                    "client_content": content,
                    "merged_preview": merge_info["merged_text"],
                    "has_overlapping_conflicts": merge_info["has_conflicts"],
                }
            # Client opted to apply the 3-way merge result
            content = str(merge_info["merged_text"])
            summary = f"3-way merged v{base_rec.version} + v{doc.version}"

        if title is not None:
            doc.title = title
        if folder is not None:
            doc.folder = folder
        if tags is not None:
            doc.tags = list(tags)
        if content is not None and content != doc.content:
            doc.version += 1
            doc.content = content
            doc.etag = _compute_etag(doc.version, doc.content)
            doc.versions.append(
                DocumentVersionRecord(
                    version=doc.version,
                    etag=doc.etag,
                    content=doc.content,
                    summary=summary,
                )
            )
        doc.updated_at = datetime.now(UTC).isoformat()
        return {"status": "ok", "document": doc.to_dict(include_content=True)}

    def soft_delete_document(self, doc_id: str, *, requesting_user_id: str) -> bool:
        doc = self.get_document(doc_id, requesting_user_id=requesting_user_id)
        if doc is None:
            return False
        doc.deleted_at = datetime.now(UTC).isoformat()
        return True

    def diff_versions(
        self,
        doc_id: str,
        *,
        requesting_user_id: str,
        from_version: int,
        to_version: int,
    ) -> dict[str, Any]:
        doc = self.get_document(doc_id, requesting_user_id=requesting_user_id)
        if doc is None:
            raise KeyError(f"Document '{doc_id}' not found")
        v_from = next((v for v in doc.versions if v.version == from_version), None)
        v_to = next((v for v in doc.versions if v.version == to_version), None)
        if v_from is None or v_to is None:
            raise ValueError(f"Version {from_version} or {to_version} not found")
        diff_lines = list(
            difflib.unified_diff(
                v_from.content.splitlines(),
                v_to.content.splitlines(),
                fromfile=f"v{from_version}",
                tofile=f"v{to_version}",
                lineterm="",
            )
        )
        return {
            "doc_id": doc.id,
            "from_version": from_version,
            "to_version": to_version,
            "unified_diff": "\n".join(diff_lines),
        }

    def propose_ai_suggestion(
        self,
        doc_id: str,
        *,
        requesting_user_id: str,
        selection_text: str,
        action: AiAuthoringActionLiteral = "rewrite",
        target_language: str = "Indonesian",
    ) -> DocumentSuggestion:
        """Create a tracked AI suggestion (`doc_propose_edit`) requiring explicit user approval."""
        doc = self.get_document(doc_id, requesting_user_id=requesting_user_id)
        if doc is None:
            raise KeyError(f"Document '{doc_id}' not found")

        sel = selection_text.strip() or doc.content[:240].strip()
        if action == "shorten":
            words = sel.split()
            proposed = " ".join(words[: max(3, len(words) // 2)]) + "."
        elif action == "expand":
            proposed = f"{sel} Furthermore, this establishes deterministic verification bounds."
        elif action == "translate":
            proposed = f"[{target_language}] {sel}"
        elif action == "tone_formal":
            proposed = f"Formally stated: {sel}"
        elif action == "summarize":
            proposed = f"Summary: {sel.splitlines()[0][:140]}"
        elif action == "extract_action_items":
            proposed = f"- [ ] Review and verify: {sel[:100]}"
        elif action == "continue_writing":
            proposed = f"{sel}\n\nNext, we evaluate the operational resilience and metrics."
        else:
            proposed = f"{sel} (refined for clarity)"

        sug = DocumentSuggestion(
            id=f"sug_{uuid.uuid4().hex[:10]}",
            doc_id=doc.id,
            action=action,
            original_text=sel,
            proposed_text=proposed,
            rationale=f"AI {action} proposal generated for selected span.",
        )
        doc.suggestions.append(sug)
        return sug

    def resolve_suggestion(
        self,
        doc_id: str,
        suggestion_id: str,
        *,
        requesting_user_id: str,
        accept: bool,
    ) -> dict[str, Any]:
        """Accept or reject a tracked AI edit suggestion."""
        doc = self.get_document(doc_id, requesting_user_id=requesting_user_id)
        if doc is None:
            raise KeyError(f"Document '{doc_id}' not found")
        sug = next((s for s in doc.suggestions if s.id == suggestion_id), None)
        if sug is None:
            raise KeyError(f"Suggestion '{suggestion_id}' not found")

        if not accept:
            sug.status = "rejected"
            return {"status": "rejected", "suggestion": sug.to_dict(), "document": doc.to_dict()}

        sug.status = "accepted"
        new_content = (
            doc.content.replace(sug.original_text, sug.proposed_text, 1)
            if sug.original_text in doc.content
            else f"{doc.content}\n{sug.proposed_text}"
        )
        self.update_document(
            doc.id,
            requesting_user_id=requesting_user_id,
            content=new_content,
            summary=f"Accepted AI suggestion ({sug.action})",
        )
        return {"status": "accepted", "suggestion": sug.to_dict(), "document": doc.to_dict()}

    def ask_document_qa(
        self,
        doc_id: str,
        *,
        requesting_user_id: str,
        question: str,
    ) -> dict[str, Any]:
        """Answer a question grounded in the active document with explicit line citations."""
        doc = self.get_document(doc_id, requesting_user_id=requesting_user_id)
        if doc is None:
            raise KeyError(f"Document '{doc_id}' not found")

        q_words = {w.lower() for w in question.split() if len(w) > 2}
        lines = doc.content.splitlines()
        scored_lines: list[tuple[int, int, str]] = []
        for idx, line in enumerate(lines, start=1):
            l_low = line.lower()
            hits = sum(1 for w in q_words if w in l_low)
            if hits > 0 or idx <= 3:
                scored_lines.append((hits, idx, line.strip()))
        scored_lines.sort(key=lambda item: (item[0], -item[1]), reverse=True)
        top_matches = [item for item in scored_lines[:3] if item[2]]

        if not top_matches:
            return {
                "doc_id": doc.id,
                "question": question,
                "answer": "No matching lines found in document.",
                "line_citations": [],
            }

        citations_out: list[dict[str, Any]] = []
        snippets: list[str] = []
        for _hits, line_no, text in top_matches:
            citations_out.append({"line": line_no, "excerpt": text[:200]})
            snippets.append(f'"{text[:120]}" [L{line_no}]')

        return {
            "doc_id": doc.id,
            "question": question,
            "answer": f"Based on `{doc.title}`: " + "; ".join(snippets),
            "line_citations": citations_out,
        }

    def export_document(
        self,
        doc_id: str,
        *,
        requesting_user_id: str,
        export_format: str = "md",
    ) -> dict[str, Any]:
        """Export a document as Markdown, sanitized HTML, CSV, TXT, DOCX XML, or PDF text."""
        doc = self.get_document(doc_id, requesting_user_id=requesting_user_id)
        if doc is None:
            raise KeyError(f"Document '{doc_id}' not found")
        fmt = export_format.lower().strip(".")
        if fmt == "html":
            body = f"<!doctype html><html><body><pre>{html.escape(doc.content)}</pre></body></html>"
            mime = "text/html"
        elif fmt == "csv":
            body = doc.content
            mime = "text/csv"
        elif fmt == "docx":
            body = (
                '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                f"<w:document><w:body><w:p><w:t>{html.escape(doc.content)}</w:t></w:p></w:body></w:document>"
            )
            mime = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        elif fmt == "pdf":
            body = f"%PDF-1.4\n% Title: {doc.title}\n{doc.content[:2000]}\n%%EOF"
            mime = "application/pdf"
        else:
            body = doc.content
            mime = "text/markdown" if fmt == "md" else "text/plain"

        return {
            "doc_id": doc.id,
            "filename": f"{doc.title.lower().replace(' ', '_')}.{fmt}",
            "mime_type": mime,
            "content": body,
        }
