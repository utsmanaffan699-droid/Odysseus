"""Documents & Spreadsheet Workspace domain package (Phase 06 §1.6)."""

from backend.domain.documents.service import (
    DocumentRecord,
    DocumentsService,
    DocumentSuggestion,
    DocumentVersionRecord,
    merge_three_way,
)

__all__ = [
    "DocumentRecord",
    "DocumentSuggestion",
    "DocumentVersionRecord",
    "DocumentsService",
    "merge_three_way",
]
