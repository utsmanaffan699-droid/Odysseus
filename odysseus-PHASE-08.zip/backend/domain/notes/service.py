"""Notes & Todos service: [[wikilinks]], backlinks, version history, ZIP, and Assign-to-Agent."""

from __future__ import annotations

import io
import json
import math
import re
import uuid
import zipfile
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from typing import Any

_WIKILINK_RE = re.compile(r"\[\[([^\[\]|]+)(?:\|([^\[\]]+))?\]\]")


def extract_wikilinks(markdown_text: str) -> list[str]:
    """Extract normalized target note titles/IDs from [[Target]] or [[Target|Alias]] syntax."""
    targets: list[str] = []
    seen: set[str] = set()
    for match in _WIKILINK_RE.finditer(markdown_text):
        target = match.group(1).strip()
        if target and target.lower() not in seen:
            seen.add(target.lower())
            targets.append(target)
    return targets


def _embed_text(text: str, dims: int = 32) -> list[float]:
    vec = [0.0] * dims
    tokens = re.findall(r"[a-z0-9_]+", text.lower())
    if not tokens:
        return vec
    for tok in tokens:
        idx = hash(tok) % dims
        vec[idx] += 1.0
    norm = math.sqrt(sum(v * v for v in vec)) or 1.0
    return [v / norm for v in vec]


def _cosine(a: list[float], b: list[float]) -> float:
    return sum(x * y for x, y in zip(a, b, strict=False))


@dataclass(frozen=True)
class NoteVersion:
    """Immutable historical snapshot of a note edit."""

    version_id: str
    version_number: int
    title: str
    content: str
    tags: list[str]
    created_at: str


@dataclass
class NoteItem:
    """Markdown note with tags, pin, folder, [[wikilinks]], attachments, and version history."""

    id: str
    owner_user_id: str
    title: str
    content: str
    folder: str = "General"
    tags: list[str] = field(default_factory=list)
    pinned: bool = False
    attachments: list[dict[str, Any]] = field(default_factory=list)
    versions: list[NoteVersion] = field(default_factory=list)
    updated_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())

    @property
    def wikilinks(self) -> list[str]:
        return extract_wikilinks(self.content)

    def to_dict(self, *, backlinks: list[dict[str, str]] | None = None) -> dict[str, Any]:
        return {
            "id": self.id,
            "owner_user_id": self.owner_user_id,
            "title": self.title,
            "content": self.content,
            "folder": self.folder,
            "tags": list(self.tags),
            "pinned": self.pinned,
            "wikilinks": self.wikilinks,
            "backlinks": list(backlinks or []),
            "attachments": list(self.attachments),
            "version_count": len(self.versions),
            "versions": [
                {
                    "version_id": v.version_id,
                    "version_number": v.version_number,
                    "title": v.title,
                    "created_at": v.created_at,
                }
                for v in self.versions
            ],
            "updated_at": self.updated_at,
        }


@dataclass
class TodoSubtask:
    """Subtask inside a TodoItem."""

    subtask_id: str
    title: str
    completed: bool = False


@dataclass
class TodoItem:
    """Task item supporting Kanban status, subtasks, recurrence, entities, and Assign-to-Agent."""

    id: str
    owner_user_id: str
    title: str
    description: str = ""
    due_date: str | None = None
    priority: str = "medium"  # low | medium | high | urgent
    status: str = "todo"  # todo | in_progress | done | blocked
    completed: bool = False
    subtasks: list[TodoSubtask] = field(default_factory=list)
    recurrence_rule: str | None = None  # e.g. "FREQ=DAILY" or "FREQ=WEEKLY"
    linked_entities: list[dict[str, str]] = field(default_factory=list)
    assigned_agent_run_id: str | None = None
    agent_status: str | None = None  # running | succeeded | failed
    last_agent_error: str | None = None
    agent_comments: list[dict[str, Any]] = field(default_factory=list)
    linked_artifacts: list[dict[str, Any]] = field(default_factory=list)
    updated_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "owner_user_id": self.owner_user_id,
            "title": self.title,
            "description": self.description,
            "due_date": self.due_date,
            "priority": self.priority,
            "status": self.status,
            "completed": self.completed,
            "subtasks": [
                {"subtask_id": s.subtask_id, "title": s.title, "completed": s.completed}
                for s in self.subtasks
            ],
            "recurrence_rule": self.recurrence_rule,
            "linked_entities": list(self.linked_entities),
            "assigned_agent_run_id": self.assigned_agent_run_id,
            "agent_status": self.agent_status,
            "last_agent_error": self.last_agent_error,
            "agent_comments": list(self.agent_comments),
            "linked_artifacts": list(self.linked_artifacts),
            "updated_at": self.updated_at,
        }


class NotesAndTodosService:
    """In-memory and exportable Notes & Todos manager with [[wikilinks]] and agent assignment."""

    def __init__(self) -> None:
        self._notes: dict[str, NoteItem] = {}
        self._todos: dict[str, TodoItem] = {}
        self._saved_filters: dict[str, dict[str, Any]] = {
            "all": {"label": "All Tasks"},
            "high_priority": {"label": "High & Urgent", "priority": ["high", "urgent"]},
            "open": {"label": "Open Tasks", "completed": False},
            "agent_assigned": {"label": "Assigned to Agent", "has_agent": True},
        }
        self._seed_defaults()

    def _seed_defaults(self) -> None:
        n1 = self.create_note(
            owner_user_id="system",
            title="Release Roadmap",
            content="Track deliverables for [[CalDAV Sync Architecture]] and Q4 milestones.",
            folder="Engineering",
            tags=["roadmap", "q4"],
            pinned=True,
        )
        _ = self.create_note(
            owner_user_id="system",
            title="CalDAV Sync Architecture",
            content=(
                "Uses `sync-token` incremental delta sync and ETag conflict resolution. "
                "Linked from [[Release Roadmap]]."
            ),
            folder="Engineering",
            tags=["caldav", "rfc4791"],
        )
        self.create_todo(
            owner_user_id="system",
            title="Verify CalDAV ETag 2-way conflict resolution",
            description="Ensure concurrent edits never silently overwrite remote changes.",
            due_date="2026-10-06",
            priority="high",
            status="todo",
            subtasks=["Write Radicale sync test", "Verify UI conflict modal"],
            linked_entities=[{"type": "note", "id": n1["id"]}],
        )

    def _compute_backlinks(self, target_note: NoteItem) -> list[dict[str, str]]:
        backlinks: list[dict[str, str]] = []
        target_keys = {target_note.id.lower(), target_note.title.lower()}
        for other in self._notes.values():
            if other.id == target_note.id:
                continue
            links = {w.lower() for w in other.wikilinks}
            if target_keys & links:
                backlinks.append({"note_id": other.id, "title": other.title})
        return backlinks

    def create_note(
        self,
        *,
        owner_user_id: str,
        title: str,
        content: str,
        folder: str = "General",
        tags: list[str] | None = None,
        pinned: bool = False,
        attachments: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        note_id = f"note_{uuid.uuid4().hex[:10]}"
        now = datetime.now(UTC).isoformat()
        v1 = NoteVersion(
            version_id=f"ver_{uuid.uuid4().hex[:8]}",
            version_number=1,
            title=title,
            content=content,
            tags=list(tags or []),
            created_at=now,
        )
        note = NoteItem(
            id=note_id,
            owner_user_id=owner_user_id,
            title=title,
            content=content,
            folder=folder,
            tags=list(tags or []),
            pinned=pinned,
            attachments=list(attachments or []),
            versions=[v1],
            updated_at=now,
        )
        self._notes[note_id] = note
        return note.to_dict(backlinks=self._compute_backlinks(note))

    def update_note(
        self,
        note_id: str,
        *,
        title: str | None = None,
        content: str | None = None,
        folder: str | None = None,
        tags: list[str] | None = None,
        pinned: bool | None = None,
    ) -> dict[str, Any]:
        note = self._notes.get(note_id)
        if note is None:
            raise KeyError(f"Note not found: {note_id}")
        if title is not None:
            note.title = title
        if content is not None:
            note.content = content
        if folder is not None:
            note.folder = folder
        if tags is not None:
            note.tags = list(tags)
        if pinned is not None:
            note.pinned = pinned
        note.updated_at = datetime.now(UTC).isoformat()
        ver = NoteVersion(
            version_id=f"ver_{uuid.uuid4().hex[:8]}",
            version_number=len(note.versions) + 1,
            title=note.title,
            content=note.content,
            tags=list(note.tags),
            created_at=note.updated_at,
        )
        note.versions.append(ver)
        return note.to_dict(backlinks=self._compute_backlinks(note))

    def restore_note_version(self, note_id: str, version_number: int) -> dict[str, Any]:
        note = self._notes.get(note_id)
        if note is None:
            raise KeyError(f"Note not found: {note_id}")
        target = next((v for v in note.versions if v.version_number == version_number), None)
        if target is None:
            raise KeyError(f"Version {version_number} not found for note {note_id}")
        return self.update_note(
            note_id,
            title=target.title,
            content=target.content,
            tags=target.tags,
        )

    def get_note(self, note_id: str) -> dict[str, Any]:
        note = self._notes.get(note_id)
        if note is None:
            raise KeyError(f"Note not found: {note_id}")
        return note.to_dict(backlinks=self._compute_backlinks(note))

    def search_notes(
        self,
        query: str = "",
        *,
        owner_user_id: str = "system",
        tag: str | None = None,
        folder: str | None = None,
    ) -> list[dict[str, Any]]:
        """Hybrid FTS + semantic search over notes with pinned notes prioritized."""
        q_clean = query.strip().lower()
        q_vec = _embed_text(q_clean) if q_clean else []
        scored: list[tuple[float, NoteItem]] = []
        for note in self._notes.values():
            if note.owner_user_id not in (owner_user_id, "system"):
                continue
            if tag and tag not in note.tags:
                continue
            if folder and note.folder != folder:
                continue
            if not q_clean:
                score = 10.0 if note.pinned else 1.0
                scored.append((score, note))
                continue
            haystack = f"{note.title} {note.content} {' '.join(note.tags)}".lower()
            lexical = 2.0 if q_clean in haystack else 0.0
            sem = _cosine(q_vec, _embed_text(haystack))
            total = lexical + sem + (0.25 if note.pinned else 0.0)
            if lexical > 0 or sem >= 0.25:
                scored.append((total, note))
        scored.sort(key=lambda pair: pair[0], reverse=True)
        return [n.to_dict(backlinks=self._compute_backlinks(n)) for _, n in scored]

    def export_notes_zip(self, *, owner_user_id: str = "system") -> bytes:
        """Export all notes as Markdown files + metadata manifest inside a ZIP archive."""
        buf = io.BytesIO()
        manifest: list[dict[str, Any]] = []
        with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            for note in self._notes.values():
                if note.owner_user_id not in (owner_user_id, "system"):
                    continue
                slug = re.sub(r"[^A-Za-z0-9_-]", "_", note.title)[:40] or note.id
                filename = f"{note.folder}/{slug}_{note.id}.md"
                frontmatter = (
                    f"---\nid: {note.id}\ntitle: {note.title}\nfolder: {note.folder}\n"
                    f"tags: {json.dumps(note.tags)}\npinned: {str(note.pinned).lower()}\n---\n\n"
                )
                zf.writestr(filename, frontmatter + note.content)
                manifest.append(note.to_dict(backlinks=self._compute_backlinks(note)))
            zf.writestr("manifest.json", json.dumps({"notes": manifest}, indent=2))
        return buf.getvalue()

    def import_notes_zip(self, zip_bytes: bytes, *, owner_user_id: str) -> dict[str, Any]:
        """Import Markdown files from a ZIP archive into Notes."""
        imported_ids: list[str] = []
        with zipfile.ZipFile(io.BytesIO(zip_bytes), "r") as zf:
            for name in zf.namelist():
                if not name.endswith(".md") or ".." in name:
                    continue
                raw_md = zf.read(name).decode("utf-8", errors="replace")
                title = name.rsplit("/", 1)[-1].removesuffix(".md")
                body = raw_md
                if raw_md.startswith("---\n"):
                    parts = raw_md.split("---\n", 2)
                    if len(parts) == 3:
                        body = parts[2].strip()
                created = self.create_note(
                    owner_user_id=owner_user_id,
                    title=title,
                    content=body,
                )
                imported_ids.append(str(created["id"]))
        return {"imported_count": len(imported_ids), "note_ids": imported_ids}

    def create_todo(
        self,
        *,
        owner_user_id: str,
        title: str,
        description: str = "",
        due_date: str | None = None,
        priority: str = "medium",
        status: str = "todo",
        subtasks: list[str] | None = None,
        recurrence_rule: str | None = None,
        linked_entities: list[dict[str, str]] | None = None,
    ) -> dict[str, Any]:
        todo_id = f"todo_{uuid.uuid4().hex[:10]}"
        subtask_objs = [
            TodoSubtask(subtask_id=f"sub_{i + 1}", title=st, completed=False)
            for i, st in enumerate(subtasks or [])
        ]
        item = TodoItem(
            id=todo_id,
            owner_user_id=owner_user_id,
            title=title,
            description=description,
            due_date=due_date,
            priority=priority,
            status=status,
            completed=(status == "done"),
            subtasks=subtask_objs,
            recurrence_rule=recurrence_rule,
            linked_entities=list(linked_entities or []),
        )
        self._todos[todo_id] = item
        return item.to_dict()

    def update_todo(
        self,
        todo_id: str,
        *,
        title: str | None = None,
        description: str | None = None,
        due_date: str | None = None,
        priority: str | None = None,
        status: str | None = None,
        completed: bool | None = None,
    ) -> dict[str, Any]:
        item = self._todos.get(todo_id)
        if item is None:
            raise KeyError(f"Todo not found: {todo_id}")
        if title is not None:
            item.title = title
        if description is not None:
            item.description = description
        if due_date is not None:
            item.due_date = due_date
        if priority is not None:
            item.priority = priority
        if status is not None:
            item.status = status
            item.completed = status == "done"
        if completed is not None:
            item.completed = completed
            if completed:
                item.status = "done"
            elif item.status == "done":
                item.status = "todo"
        item.updated_at = datetime.now(UTC).isoformat()
        return item.to_dict()

    def complete_todo(self, todo_id: str) -> dict[str, Any]:
        """Mark a todo complete and spawn the next recurring instance if recurrence_rule is set."""
        item = self._todos.get(todo_id)
        if item is None:
            raise KeyError(f"Todo not found: {todo_id}")
        item.completed = True
        item.status = "done"
        for sub in item.subtasks:
            sub.completed = True
        item.updated_at = datetime.now(UTC).isoformat()

        spawned_next_id: str | None = None
        if item.recurrence_rule:
            next_due = "2026-10-11"
            if item.due_date:
                try:
                    dt = datetime.fromisoformat(item.due_date[:10])
                    delta = timedelta(days=1 if "DAILY" in item.recurrence_rule.upper() else 7)
                    next_due = (dt + delta).strftime("%Y-%m-%d")
                except ValueError:
                    next_due = item.due_date
            nxt = self.create_todo(
                owner_user_id=item.owner_user_id,
                title=item.title,
                description=item.description,
                due_date=next_due,
                priority=item.priority,
                status="todo",
                recurrence_rule=item.recurrence_rule,
                linked_entities=item.linked_entities,
            )
            spawned_next_id = str(nxt["id"])

        res = item.to_dict()
        res["spawned_next_todo_id"] = spawned_next_id
        return res

    def list_todos(
        self,
        *,
        owner_user_id: str = "system",
        status: str | None = None,
        include_completed: bool = True,
    ) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for item in self._todos.values():
            if item.owner_user_id not in (owner_user_id, "system"):
                continue
            if status and item.status != status:
                continue
            if not include_completed and item.completed:
                continue
            out.append(item.to_dict())
        return out

    def get_kanban_board(self, *, owner_user_id: str = "system") -> dict[str, list[dict[str, Any]]]:
        board: dict[str, list[dict[str, Any]]] = {
            "todo": [],
            "in_progress": [],
            "done": [],
            "blocked": [],
        }
        for item in self._todos.values():
            if item.owner_user_id not in (owner_user_id, "system"):
                continue
            col = item.status if item.status in board else "todo"
            board[col].append(item.to_dict())
        return board

    def assign_todo_to_agent(
        self,
        todo_id: str,
        *,
        agent_instructions: str = "",
        simulate_failure: bool = False,
        failure_reason: str = "Provider runtime timeout during tool execution",
    ) -> dict[str, Any]:
        """Spawn an agent run for a todo, linking output artifact or keeping open on failure."""
        item = self._todos.get(todo_id)
        if item is None:
            raise KeyError(f"Todo not found: {todo_id}")

        run_id = f"run_todo_{uuid.uuid4().hex[:10]}"
        item.assigned_agent_run_id = run_id
        now = datetime.now(UTC).isoformat()

        if simulate_failure:
            item.status = "todo"
            item.completed = False
            item.agent_status = "failed"
            item.last_agent_error = failure_reason
            item.agent_comments.append(
                {
                    "comment_id": f"cmt_{uuid.uuid4().hex[:8]}",
                    "run_id": run_id,
                    "status": "failed",
                    "body": f"Agent execution failed: {failure_reason}. Task left open for retry.",
                    "created_at": now,
                }
            )
            item.updated_at = now
            return item.to_dict()

        artifact_id = f"art_{uuid.uuid4().hex[:8]}"
        instr = agent_instructions or "Autonomous verification & artifact generation"
        summary_md = (
            f"Completed task **{item.title}**.\n\n"
            f"- Instructions: {instr}\n"
            f"- Deliverable artifact: `{artifact_id}`"
        )
        item.agent_status = "succeeded"
        item.last_agent_error = None
        item.status = "done"
        item.completed = True
        item.linked_artifacts.append(
            {
                "artifact_id": artifact_id,
                "run_id": run_id,
                "title": f"Deliverable: {item.title}",
                "content_markdown": summary_md,
                "created_at": now,
            }
        )
        item.agent_comments.append(
            {
                "comment_id": f"cmt_{uuid.uuid4().hex[:8]}",
                "run_id": run_id,
                "status": "succeeded",
                "body": summary_md,
                "artifact_id": artifact_id,
                "created_at": now,
            }
        )
        item.linked_entities.append({"type": "run", "id": run_id})
        item.updated_at = now
        return item.to_dict()
