"""Odysseus Cookbook domain package: hardware advisor, model fit, downloads, engines, serve, SSH."""

from backend.domain.cookbook.service import (
    FAILURE_FIXTURES_32,
    HARDWARE_FIXTURES_24,
    REFERENCE_FIT_CASES_30,
    CookbookService,
    calculate_model_memory_fit,
    classify_cookbook_failure,
    diagnose_container_gpu_passthrough,
    parse_nvidia_smi_csv,
    parse_sysctl_or_lspci_text,
    rank_models_for_hardware,
    render_chat_template_sandboxed,
    validate_safe_cli_token,
    validate_safe_model_filename,
)

__all__ = [
    "FAILURE_FIXTURES_32",
    "HARDWARE_FIXTURES_24",
    "REFERENCE_FIT_CASES_30",
    "CookbookService",
    "calculate_model_memory_fit",
    "classify_cookbook_failure",
    "diagnose_container_gpu_passthrough",
    "parse_nvidia_smi_csv",
    "parse_sysctl_or_lspci_text",
    "rank_models_for_hardware",
    "render_chat_template_sandboxed",
    "validate_safe_cli_token",
    "validate_safe_model_filename",
]
