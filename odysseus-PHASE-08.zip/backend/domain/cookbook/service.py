"""Cookbook & Local Model Hardware Advisor domain service."""

from __future__ import annotations

import hashlib
import http.client
import math
import os
import re
import socket
import stat
import subprocess
import sys
import tempfile
import time
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import jinja2
import jinja2.exceptions
import jinja2.sandbox

from backend.domain.cookbook.tiny_gguf_server import create_minimal_gguf_file

_SAFE_TOKEN_RE = re.compile(r"^[A-Za-z0-9._/@:+-]{1,128}$")
_SAFE_FILENAME_RE = re.compile(r"^[A-Za-z0-9._-]{1,128}$")
_WINDOWS_RESERVED_NAMES = frozenset(
    {
        "CON",
        "PRN",
        "AUX",
        "NUL",
        *(f"COM{i}" for i in range(1, 10)),
        *(f"LPT{i}" for i in range(1, 10)),
    }
)
_BIDI_AND_CONTROL_CHARS = frozenset(
    {
        "\u202a",
        "\u202b",
        "\u202c",
        "\u202d",
        "\u202e",
        "\u2066",
        "\u2067",
        "\u2068",
        "\u2069",
        "\u200b",
        "\u200c",
        "\u200d",
        "\ufeff",
    }
)


def validate_safe_cli_token(value: str, *, field_name: str = "token") -> str:
    """Validate a user/model-supplied token before it ever reaches an argv array."""
    if not isinstance(value, str) or not value:
        raise ValueError(f"Empty or non-string {field_name}")
    if value.startswith("-"):
        raise ValueError(f"Leading dash option injection rejected in {field_name}: {value!r}")
    if any(ch in value for ch in ("\x00", "\n", "\r", ";", "|", "&", "`", "$", ">", "<", "\\")):
        raise ValueError(f"Unsafe shell metacharacter rejected in {field_name}: {value!r}")
    if any(ch in _BIDI_AND_CONTROL_CHARS or ord(ch) < 32 or ord(ch) > 126 for ch in value):
        raise ValueError(f"Non-ASCII or BiDi confusable rejected in {field_name}: {value!r}")
    if ".." in value:
        raise ValueError(f"Path traversal sequence rejected in {field_name}: {value!r}")
    if not _SAFE_TOKEN_RE.match(value):
        raise ValueError(f"Disallowed characters in {field_name}: {value!r}")
    return value


def validate_safe_model_filename(filename: str) -> str:
    """Validate a model file name against traversal, Windows device names, and confusables."""
    if not isinstance(filename, str) or not filename.strip():
        raise ValueError("Empty model filename")
    if "/" in filename or "\\" in filename or ":" in filename or ".." in filename:
        raise ValueError(f"Path separator or traversal rejected in filename: {filename!r}")
    if filename.startswith(".") or filename.startswith("-"):
        raise ValueError(f"Hidden or flag-like filename rejected: {filename!r}")
    if any(ch in _BIDI_AND_CONTROL_CHARS or ord(ch) < 32 or ord(ch) > 126 for ch in filename):
        raise ValueError(f"Unicode confusable or control char rejected in filename: {filename!r}")
    stem = filename.split(".")[0].upper()
    if stem in _WINDOWS_RESERVED_NAMES:
        raise ValueError(f"Windows reserved device name rejected: {filename!r}")
    if not _SAFE_FILENAME_RE.match(filename):
        raise ValueError(f"Filename violates safe pattern: {filename!r}")
    return filename


# ============================================================================
# 1.2 Hardware Detection (`hwfit`) & >= 24 Real Hardware Fixtures
# ============================================================================


def parse_nvidia_smi_csv(
    raw_input: str | bytes, *, max_bytes: int = 262144
) -> list[dict[str, Any]]:
    """Parse `nvidia-smi` CSV lines into structured GPU dictionaries."""
    if isinstance(raw_input, bytes):
        text = raw_input[:max_bytes].decode("utf-8", errors="replace")
    else:
        text = str(raw_input)[:max_bytes]

    gpus: list[dict[str, Any]] = []
    for raw_line in text.splitlines()[:64]:
        line = raw_line.strip()
        if not line or "\x00" in line:
            continue
        parts = [p.strip() for p in line.split(",")]
        if len(parts) < 5:
            continue
        try:
            idx = int(parts[0])
            name = parts[1][:128]
            vram_total_mb = int(float(parts[2]))
            vram_free_mb = int(float(parts[3]))
            driver_ver = parts[4][:32]
        except (ValueError, IndexError):
            continue
        if vram_total_mb <= 0 or vram_total_mb > 4_000_000:
            continue
        gpus.append(
            {
                "index": idx,
                "vendor": "nvidia",
                "name": name,
                "vram_total_mb": vram_total_mb,
                "vram_free_mb": max(0, min(vram_free_mb, vram_total_mb)),
                "driver_version": driver_ver,
                "bandwidth_gbps": _estimate_gpu_bandwidth_gbps(name, vram_total_mb),
            }
        )
    return gpus


def parse_sysctl_or_lspci_text(
    raw_input: str | bytes, *, max_bytes: int = 262144
) -> dict[str, Any]:
    """Tolerantly parse `sysctl`, `system_profiler`, or `lspci` output without ever throwing."""
    if isinstance(raw_input, bytes):
        text = raw_input[:max_bytes].decode("utf-8", errors="replace")
    else:
        text = str(raw_input)[:max_bytes]

    info: dict[str, Any] = {
        "apple_silicon": False,
        "unified_memory_mb": 0,
        "intel_arc_detected": False,
        "amd_rocm_detected": False,
        "detected_accelerators": [],
    }
    for raw_line in text.splitlines()[:256]:
        line = raw_line.strip()
        if not line or "\x00" in line:
            continue
        lower = line.lower()
        if any(chip in lower for chip in ("apple m1", "apple m2", "apple m3", "apple m4")):
            info["apple_silicon"] = True
            info["detected_accelerators"].append(line[:120])
        if "hw.memsize" in lower and ":" in line:
            try:
                val = int(line.split(":", 1)[1].strip())
                if 0 < val <= (1 << 44):
                    info["unified_memory_mb"] = val // (1024 * 1024)
            except ValueError:
                pass
        if "intel" in lower and ("arc " in lower or "dg2" in lower or "alchemist" in lower):
            info["intel_arc_detected"] = True
            info["detected_accelerators"].append(line[:120])
        if "instinct" in lower or "mi300" in lower or "radeon rx" in lower or "gfx" in lower:
            info["amd_rocm_detected"] = True
            info["detected_accelerators"].append(line[:120])
    return info


def _estimate_gpu_bandwidth_gbps(name: str, vram_mb: int) -> float:
    upper = name.upper()
    if "H100" in upper:
        return 3350.0
    if "A100" in upper:
        return 2039.0
    if "MI300" in upper:
        return 5300.0
    if "M3 ULTRA" in upper:
        return 800.0
    if "M2 MAX" in upper:
        return 400.0
    if "M1" in upper:
        return 68.0
    if "4090" in upper:
        return 1008.0
    if "3090" in upper:
        return 936.0
    if "6000" in upper:
        return 960.0
    if vram_mb >= 24000:
        return 800.0
    if vram_mb >= 16000:
        return 500.0
    return 320.0


def diagnose_container_gpu_passthrough(
    *,
    in_container: bool,
    proc_driver_nvidia_exists: bool,
    dev_nvidia0_exists: bool,
    dev_nvidiactl_exists: bool,
    nvidia_smi_gpus: list[dict[str, Any]],
    driver_version: str = "",
    required_cuda_driver_major: int = 535,
    engine_built_with_cuda: bool = True,
) -> dict[str, Any]:
    """Diagnose container-vs-host GPU visibility and distinguish passthrough vs engine issues."""
    overlay_cmd = "docker compose -f docker-compose.yml -f docker/gpu.nvidia.yml up -d"
    if proc_driver_nvidia_exists and not dev_nvidia0_exists:
        return {
            "status": "gpu_on_host_not_passed_through",
            "message": (
                "GPU detected on host (/proc/driver/nvidia present), "
                "but /dev/nvidia0 is not passed through to this container."
            ),
            "remedy_command": overlay_cmd,
        }
    if dev_nvidia0_exists and not dev_nvidiactl_exists:
        return {
            "status": "partial_device_passthrough",
            "message": (
                "/dev/nvidia0 is present but /dev/nvidiactl is missing; "
                "incomplete device passthrough."
            ),
            "remedy_command": overlay_cmd,
        }
    if dev_nvidia0_exists and not nvidia_smi_gpus:
        return {
            "status": "dev_present_zero_gpus_reported",
            "message": (
                "/dev/nvidia0 exists inside the container, "
                "but nvidia-smi reported 0 GPUs (NVML or cgroup device mismatch)."
            ),
            "remedy_command": overlay_cmd,
        }
    if nvidia_smi_gpus:
        drv = driver_version or str(nvidia_smi_gpus[0].get("driver_version", ""))
        try:
            major = int(drv.split(".")[0])
        except ValueError:
            major = required_cuda_driver_major
        if major < required_cuda_driver_major:
            return {
                "status": "driver_runtime_mismatch",
                "message": (
                    f"Host NVIDIA driver {drv} is older than required "
                    f"CUDA 12 driver >= {required_cuda_driver_major}."
                ),
                "remedy_command": "sudo apt-get install -y nvidia-driver-550",
            }
        if not engine_built_with_cuda:
            return {
                "status": "engine_built_without_cuda",
                "message": (
                    "GPU is properly passed through, "
                    "but the active llama.cpp engine binary was built for CPU only."
                ),
                "remedy_command": "odysseus cookbook engines install llama.cpp --variant cuda",
            }
        return {
            "status": "ok",
            "message": "GPU visible and ready for hardware-accelerated inference.",
            "remedy_command": "",
        }
    return {
        "status": "cpu_only",
        "message": (
            "No discrete GPU detected in container; using CPU SIMD backend."
            if in_container
            else "No discrete GPU detected on host; using CPU SIMD backend."
        ),
        "remedy_command": "",
    }


def _gpu_entry(
    idx: int,
    vendor: str,
    name: str,
    total_mb: int,
    free_mb: int,
    driver: str,
    bw: float,
) -> dict[str, Any]:
    return {
        "index": idx,
        "vendor": vendor,
        "name": name,
        "vram_total_mb": total_mb,
        "vram_free_mb": free_mb,
        "driver_version": driver,
        "bandwidth_gbps": bw,
    }


HARDWARE_FIXTURES_24: dict[str, dict[str, Any]] = {
    "01_laptop_8gb_dgpu": {
        "id": "01_laptop_8gb_dgpu",
        "name": "Laptop RTX 4060 8GB + 16GB RAM",
        "cpu_cores": 8,
        "isa_flags": ["AVX2"],
        "ram_total_mb": 16384,
        "ram_avail_mb": 12288,
        "disk_free_gb": 120.0,
        "backend": "cuda",
        "gpus": [_gpu_entry(0, "nvidia", "RTX 4060 Laptop", 8192, 7600, "550.54", 272.0)],
        "passthrough_status": "ok",
    },
    "02_desktop_12gb_dgpu": {
        "id": "02_desktop_12gb_dgpu",
        "name": "Desktop RTX 3060 12GB + 32GB RAM",
        "cpu_cores": 12,
        "isa_flags": ["AVX2"],
        "ram_total_mb": 32768,
        "ram_avail_mb": 26000,
        "disk_free_gb": 250.0,
        "backend": "cuda",
        "gpus": [_gpu_entry(0, "nvidia", "RTX 3060", 12288, 11500, "550.54", 360.0)],
        "passthrough_status": "ok",
    },
    "03_desktop_16gb_dgpu": {
        "id": "03_desktop_16gb_dgpu",
        "name": "Desktop RTX 4080 16GB + 32GB RAM",
        "cpu_cores": 16,
        "isa_flags": ["AVX2", "AVX512"],
        "ram_total_mb": 32768,
        "ram_avail_mb": 28000,
        "disk_free_gb": 400.0,
        "backend": "cuda",
        "gpus": [_gpu_entry(0, "nvidia", "RTX 4080", 16384, 15600, "550.54", 716.8)],
        "passthrough_status": "ok",
    },
    "04_workstation_24gb_4090": {
        "id": "04_workstation_24gb_4090",
        "name": "Workstation RTX 4090 24GB + 64GB RAM",
        "cpu_cores": 24,
        "isa_flags": ["AVX2", "AVX512"],
        "ram_total_mb": 65536,
        "ram_avail_mb": 56000,
        "disk_free_gb": 800.0,
        "backend": "cuda",
        "gpus": [_gpu_entry(0, "nvidia", "RTX 4090", 24576, 23500, "555.42", 1008.0)],
        "passthrough_status": "ok",
    },
    "05_dual_3090_48gb": {
        "id": "05_dual_3090_48gb",
        "name": "Dual RTX 3090 (2x24GB = 48GB) + 128GB RAM",
        "cpu_cores": 32,
        "isa_flags": ["AVX2"],
        "ram_total_mb": 131072,
        "ram_avail_mb": 115000,
        "disk_free_gb": 1200.0,
        "backend": "cuda",
        "gpus": [
            _gpu_entry(0, "nvidia", "RTX 3090", 24576, 23500, "550.54", 936.0),
            _gpu_entry(1, "nvidia", "RTX 3090", 24576, 23500, "550.54", 936.0),
        ],
        "passthrough_status": "ok",
    },
    "06_workstation_48gb_ada": {
        "id": "06_workstation_48gb_ada",
        "name": "RTX 6000 Ada 48GB + 128GB RAM",
        "cpu_cores": 32,
        "isa_flags": ["AVX2", "AVX512"],
        "ram_total_mb": 131072,
        "ram_avail_mb": 118000,
        "disk_free_gb": 1500.0,
        "backend": "cuda",
        "gpus": [_gpu_entry(0, "nvidia", "RTX 6000 Ada", 49152, 47500, "555.42", 960.0)],
        "passthrough_status": "ok",
    },
    "07_datacenter_a100_80gb": {
        "id": "07_datacenter_a100_80gb",
        "name": "NVIDIA A100 80GB SXM4",
        "cpu_cores": 64,
        "isa_flags": ["AVX2"],
        "ram_total_mb": 262144,
        "ram_avail_mb": 240000,
        "disk_free_gb": 2000.0,
        "backend": "cuda",
        "gpus": [_gpu_entry(0, "nvidia", "A100-SXM4-80GB", 81920, 80000, "550.54", 2039.0)],
        "passthrough_status": "ok",
    },
    "08_datacenter_h100_80gb": {
        "id": "08_datacenter_h100_80gb",
        "name": "NVIDIA H100 80GB HBM3",
        "cpu_cores": 96,
        "isa_flags": ["AVX2", "AVX512", "AMX"],
        "ram_total_mb": 524288,
        "ram_avail_mb": 480000,
        "disk_free_gb": 4000.0,
        "backend": "cuda",
        "gpus": [_gpu_entry(0, "nvidia", "H100-HBM3-80GB", 81920, 80000, "555.42", 3350.0)],
        "passthrough_status": "ok",
    },
    "09_amd_mi300x_192gb_rocm": {
        "id": "09_amd_mi300x_192gb_rocm",
        "name": "AMD Instinct MI300X 192GB ROCm",
        "cpu_cores": 64,
        "isa_flags": ["AVX2", "AVX512"],
        "ram_total_mb": 524288,
        "ram_avail_mb": 490000,
        "disk_free_gb": 3000.0,
        "backend": "rocm",
        "gpus": [_gpu_entry(0, "amd", "AMD Instinct MI300X", 196608, 192000, "rocm-6.2", 5300.0)],
        "passthrough_status": "ok",
    },
    "10_intel_arc_a770_unsupported": {
        "id": "10_intel_arc_a770_unsupported",
        "name": "Intel Arc A770 16GB (SYCL/IPEX Unsupported — CPU Fallback)",
        "cpu_cores": 12,
        "isa_flags": ["AVX2"],
        "ram_total_mb": 32768,
        "ram_avail_mb": 26000,
        "disk_free_gb": 200.0,
        "backend": "cpu",
        "unsupported_accelerator_note": (
            "Intel Arc discrete GPUs are not supported for native SYCL offload; "
            "falling back to AVX2 CPU inference."
        ),
        "gpus": [],
        "passthrough_status": "unsupported_intel_arc",
    },
    "11_apple_m1_8gb": {
        "id": "11_apple_m1_8gb",
        "name": "Apple M1 8GB Unified Memory (Metal)",
        "cpu_cores": 8,
        "isa_flags": ["NEON"],
        "ram_total_mb": 8192,
        "ram_avail_mb": 5800,
        "disk_free_gb": 60.0,
        "backend": "metal",
        "gpus": [_gpu_entry(0, "apple", "Apple M1 Unified", 5800, 5400, "Metal3", 68.0)],
        "passthrough_status": "ok",
    },
    "12_apple_m2_max_64gb": {
        "id": "12_apple_m2_max_64gb",
        "name": "Apple M2 Max 64GB Unified Memory (Metal)",
        "cpu_cores": 12,
        "isa_flags": ["NEON"],
        "ram_total_mb": 65536,
        "ram_avail_mb": 52000,
        "disk_free_gb": 500.0,
        "backend": "metal",
        "gpus": [_gpu_entry(0, "apple", "Apple M2 Max Unified", 52000, 49000, "Metal3", 400.0)],
        "passthrough_status": "ok",
    },
    "13_apple_m3_ultra_192gb": {
        "id": "13_apple_m3_ultra_192gb",
        "name": "Apple M3 Ultra 192GB Unified Memory (Metal)",
        "cpu_cores": 24,
        "isa_flags": ["NEON"],
        "ram_total_mb": 196608,
        "ram_avail_mb": 170000,
        "disk_free_gb": 1500.0,
        "backend": "metal",
        "gpus": [_gpu_entry(0, "apple", "Apple M3 Ultra Unified", 170000, 164000, "Metal3", 800.0)],
        "passthrough_status": "ok",
    },
    "14_cpu_only_16gb": {
        "id": "14_cpu_only_16gb",
        "name": "CPU-Only 16GB RAM (x86_64 AVX2)",
        "cpu_cores": 8,
        "isa_flags": ["AVX2"],
        "ram_total_mb": 16384,
        "ram_avail_mb": 12000,
        "disk_free_gb": 100.0,
        "backend": "cpu",
        "gpus": [],
        "passthrough_status": "cpu_only",
    },
    "15_cpu_only_64gb": {
        "id": "15_cpu_only_64gb",
        "name": "CPU-Only 64GB RAM (x86_64 AVX-512)",
        "cpu_cores": 16,
        "isa_flags": ["AVX2", "AVX512"],
        "ram_total_mb": 65536,
        "ram_avail_mb": 54000,
        "disk_free_gb": 500.0,
        "backend": "cpu",
        "gpus": [],
        "passthrough_status": "cpu_only",
    },
    "16_raspberry_pi5_arm_4gb": {
        "id": "16_raspberry_pi5_arm_4gb",
        "name": "Raspberry Pi 5 ARM64 (4GB RAM, NEON)",
        "cpu_cores": 4,
        "isa_flags": ["NEON"],
        "ram_total_mb": 4096,
        "ram_avail_mb": 2900,
        "disk_free_gb": 24.0,
        "backend": "cpu",
        "gpus": [],
        "passthrough_status": "cpu_only",
    },
    "17_wsl2_nvidia_rtx4070": {
        "id": "17_wsl2_nvidia_rtx4070",
        "name": "WSL2 Ubuntu + NVIDIA RTX 4070 12GB (/usr/lib/wsl/lib)",
        "cpu_cores": 16,
        "isa_flags": ["AVX2"],
        "ram_total_mb": 32768,
        "ram_avail_mb": 24000,
        "disk_free_gb": 180.0,
        "backend": "cuda",
        "wsl2": True,
        "gpus": [_gpu_entry(0, "nvidia", "RTX 4070 WSL2", 12288, 11200, "555.85", 504.0)],
        "passthrough_status": "ok",
    },
    "18_container_without_passthrough": {
        "id": "18_container_without_passthrough",
        "name": "Docker Container Missing --gpus all (Host GPU Not Passed Through)",
        "cpu_cores": 8,
        "isa_flags": ["AVX2"],
        "ram_total_mb": 32768,
        "ram_avail_mb": 26000,
        "disk_free_gb": 150.0,
        "backend": "cpu",
        "gpus": [],
        "passthrough_status": "gpu_on_host_not_passed_through",
        "passthrough_remedy": "docker compose -f docker-compose.yml -f docker/gpu.nvidia.yml up -d",
    },
    "19_driver_too_old": {
        "id": "19_driver_too_old",
        "name": "RTX 3080 10GB with Outdated Driver 470.x",
        "cpu_cores": 8,
        "isa_flags": ["AVX2"],
        "ram_total_mb": 32768,
        "ram_avail_mb": 25000,
        "disk_free_gb": 200.0,
        "backend": "cpu",
        "gpus": [_gpu_entry(0, "nvidia", "RTX 3080", 10240, 9500, "470.82", 760.0)],
        "passthrough_status": "driver_runtime_mismatch",
        "passthrough_remedy": "sudo apt-get install -y nvidia-driver-550",
    },
    "20_cuda_runtime_mismatch": {
        "id": "20_cuda_runtime_mismatch",
        "name": "CUDA Runtime 12.4 vs Driver 525.60 Mismatch",
        "cpu_cores": 12,
        "isa_flags": ["AVX2"],
        "ram_total_mb": 32768,
        "ram_avail_mb": 26000,
        "disk_free_gb": 200.0,
        "backend": "cpu",
        "gpus": [_gpu_entry(0, "nvidia", "RTX 3090", 24576, 23000, "525.60", 936.0)],
        "passthrough_status": "driver_runtime_mismatch",
    },
    "21_nvidia_smi_timeout": {
        "id": "21_nvidia_smi_timeout",
        "name": "Hung GPU Node (nvidia-smi Timeout After 5s)",
        "cpu_cores": 16,
        "isa_flags": ["AVX2"],
        "ram_total_mb": 65536,
        "ram_avail_mb": 50000,
        "disk_free_gb": 300.0,
        "backend": "cpu",
        "gpus": [],
        "passthrough_status": "nvidia_smi_timeout",
    },
    "22_garbled_nvidia_smi": {
        "id": "22_garbled_nvidia_smi",
        "name": "Corrupted/Garbled nvidia-smi Output Fallback to CPU",
        "cpu_cores": 8,
        "isa_flags": ["AVX2"],
        "ram_total_mb": 16384,
        "ram_avail_mb": 12000,
        "disk_free_gb": 100.0,
        "backend": "cpu",
        "gpus": [],
        "passthrough_status": "cpu_only",
    },
    "23_zero_gpus_with_dev_nvidia0": {
        "id": "23_zero_gpus_with_dev_nvidia0",
        "name": "/dev/nvidia0 Present But nvidia-smi Reports 0 GPUs",
        "cpu_cores": 8,
        "isa_flags": ["AVX2"],
        "ram_total_mb": 32768,
        "ram_avail_mb": 24000,
        "disk_free_gb": 120.0,
        "backend": "cpu",
        "gpus": [],
        "passthrough_status": "dev_present_zero_gpus_reported",
    },
    "24_impossible_tiny_iot_512mb": {
        "id": "24_impossible_tiny_iot_512mb",
        "name": "Ultra-Constrained 512MB RAM Node (Impossible Hardware for LLMs)",
        "cpu_cores": 1,
        "isa_flags": [],
        "ram_total_mb": 512,
        "ram_avail_mb": 256,
        "disk_free_gb": 2.0,
        "backend": "cpu",
        "gpus": [],
        "passthrough_status": "insufficient_memory",
    },
}


# ============================================================================
# 1.3 Memory-Fit Calculator & >= 30 Published Reference Cases
# ============================================================================

_QUANT_BITS_PER_WEIGHT: dict[str, float] = {
    "FP16": 16.0,
    "BF16": 16.0,
    "Q8_0": 8.5,
    "Q6_K": 6.56,
    "Q5_K_M": 5.69,
    "Q4_K_M": 4.85,
    "AWQ_4BIT": 4.5,
    "GPTQ_4BIT": 4.5,
    "IQ3_XXS": 3.25,
    "Q2_K": 2.95,
}

_QUANT_QUALITY_PRIOR: dict[str, float] = {
    "FP16": 1.00,
    "BF16": 1.00,
    "Q8_0": 0.96,
    "Q6_K": 0.91,
    "Q5_K_M": 0.86,
    "Q4_K_M": 0.80,
    "AWQ_4BIT": 0.79,
    "GPTQ_4BIT": 0.77,
    "IQ3_XXS": 0.62,
    "Q2_K": 0.45,
}

_BACKEND_OVERHEAD_MB: dict[str, float] = {
    "cuda": 550.0,
    "rocm": 600.0,
    "metal": 380.0,
    "cpu": 280.0,
}


def calculate_model_memory_fit(
    *,
    params_b: float,
    layers: int,
    kv_heads: int,
    head_dim: int,
    quant: str,
    context_length: int,
    available_memory_mb: float,
    backend: str = "cuda",
    kv_bytes_per_elem: int = 2,
    mmproj_mb: float = 0.0,
    bandwidth_gbps: float = 300.0,
) -> dict[str, Any]:
    """Compute exact weights + KV cache + backend overhead memory fit and roofline tok/s."""
    bits = _QUANT_BITS_PER_WEIGHT.get(quant.upper(), 4.85)
    weights_mb = (params_b * 1_000_000_000.0 * (bits / 8.0)) / (1024.0 * 1024.0)
    kv_bytes = 2.0 * layers * kv_heads * head_dim * context_length * kv_bytes_per_elem
    kv_mb = kv_bytes / (1024.0 * 1024.0)
    overhead_mb = _BACKEND_OVERHEAD_MB.get(backend.lower(), 400.0)
    total_mb = weights_mb + kv_mb + overhead_mb + mmproj_mb

    ratio = total_mb / max(1.0, available_memory_mb)
    if ratio <= 0.85:
        fits = "yes"
    elif ratio <= 0.96:
        fits = "tight"
    else:
        fits = "no"

    remaining_for_kv_mb = (available_memory_mb * 0.95) - (weights_mb + overhead_mb + mmproj_mb)
    kv_mb_per_token = (2.0 * layers * kv_heads * head_dim * kv_bytes_per_elem) / (1024.0 * 1024.0)
    if remaining_for_kv_mb <= 0 or kv_mb_per_token <= 0:
        max_ctx = 0
    else:
        max_ctx = int((remaining_for_kv_mb / kv_mb_per_token) // 256) * 256

    weights_gb = max(0.1, weights_mb / 1024.0)
    raw_tok_s = (bandwidth_gbps / weights_gb) * 0.68
    low_tok_s = round(max(1.0, raw_tok_s * 0.82), 1)
    high_tok_s = round(max(1.5, raw_tok_s * 1.12), 1)

    if backend.lower() in ("cuda", "rocm"):
        limiting_resource = "VRAM"
    elif backend == "metal":
        limiting_resource = "Unified Memory"
    else:
        limiting_resource = "System RAM"

    why_msg = (
        f"Requires {round(total_mb)} MB ({round(weights_mb)} MB weights + "
        f"{round(kv_mb)} MB KV cache + {round(overhead_mb)} MB overhead) "
        f"against {round(available_memory_mb)} MB {limiting_resource}."
    )
    return {
        "weights_mb": round(weights_mb, 2),
        "kv_cache_mb": round(kv_mb, 2),
        "overhead_mb": round(overhead_mb, 2),
        "mmproj_mb": round(mmproj_mb, 2),
        "total_mb": round(total_mb, 2),
        "available_memory_mb": round(available_memory_mb, 2),
        "utilization_ratio": round(ratio, 4),
        "fits": fits,
        "max_context_that_fits": max_ctx,
        "predicted_tok_s": {
            "low": low_tok_s,
            "high": high_tok_s,
            "confidence": "high" if fits == "yes" else ("medium" if fits == "tight" else "low"),
        },
        "explain": {
            "why_it_fits": why_msg,
            "limiting_resource": limiting_resource,
            "predicted_tok_s_range": f"{low_tok_s}-{high_tok_s} tok/s",
            "confidence": "high" if fits == "yes" else "medium",
            "caveats": ["Requires companion mmproj vision weights"] if mmproj_mb > 0 else [],
        },
    }


def _build_30_reference_fit_cases() -> list[dict[str, Any]]:
    specs = [
        ("Llama-3.2-1B-Q4_K_M-4k", 1.24, 16, 8, 64, "Q4_K_M", 4096, 8000, "cuda"),
        ("Llama-3.2-1B-Q8_0-8k", 1.24, 16, 8, 64, "Q8_0", 8192, 8000, "cuda"),
        ("Llama-3.2-3B-Q4_K_M-8k", 3.21, 28, 8, 128, "Q4_K_M", 8192, 8000, "cuda"),
        ("Llama-3.2-3B-Q8_0-8k", 3.21, 28, 8, 128, "Q8_0", 8192, 8000, "cuda"),
        ("Qwen2.5-7B-Q4_K_M-8k", 7.62, 28, 4, 128, "Q4_K_M", 8192, 12000, "cuda"),
        ("Qwen2.5-7B-Q5_K_M-16k", 7.62, 28, 4, 128, "Q5_K_M", 16384, 12000, "cuda"),
        ("Qwen2.5-7B-Q6_K-16k", 7.62, 28, 4, 128, "Q6_K", 16384, 16000, "cuda"),
        ("Qwen2.5-7B-Q8_0-32k", 7.62, 28, 4, 128, "Q8_0", 32768, 16000, "cuda"),
        ("Qwen2.5-7B-FP16-8k", 7.62, 28, 4, 128, "FP16", 8192, 24000, "cuda"),
        ("Llama-3.1-8B-Q4_K_M-8k", 8.03, 32, 8, 128, "Q4_K_M", 8192, 8000, "cuda"),
        ("Llama-3.1-8B-Q4_K_M-32k", 8.03, 32, 8, 128, "Q4_K_M", 32768, 12000, "cuda"),
        ("Llama-3.1-8B-Q5_K_M-16k", 8.03, 32, 8, 128, "Q5_K_M", 16384, 12000, "cuda"),
        ("Llama-3.1-8B-Q8_0-16k", 8.03, 32, 8, 128, "Q8_0", 16384, 16000, "cuda"),
        ("Llama-3.1-8B-FP16-8k", 8.03, 32, 8, 128, "FP16", 8192, 24000, "cuda"),
        ("Mistral-Nemo-12B-Q4_K_M-16k", 12.2, 40, 8, 128, "Q4_K_M", 16384, 12000, "cuda"),
        ("Mistral-Nemo-12B-Q6_K-16k", 12.2, 40, 8, 128, "Q6_K", 16384, 16000, "cuda"),
        ("Qwen2.5-14B-Q4_K_M-8k", 14.7, 48, 8, 128, "Q4_K_M", 8192, 16000, "cuda"),
        ("Qwen2.5-14B-Q5_K_M-16k", 14.7, 48, 8, 128, "Q5_K_M", 16384, 16000, "cuda"),
        ("Qwen2.5-14B-Q8_0-16k", 14.7, 48, 8, 128, "Q8_0", 16384, 24000, "cuda"),
        ("Gemma-2-27B-Q4_K_M-8k", 27.2, 46, 16, 128, "Q4_K_M", 8192, 24000, "cuda"),
        ("Qwen2.5-32B-Q4_K_M-8k", 32.5, 64, 8, 128, "Q4_K_M", 8192, 24000, "cuda"),
        ("Qwen2.5-32B-Q5_K_M-16k", 32.5, 64, 8, 128, "Q5_K_M", 16384, 32000, "metal"),
        ("Qwen2.5-32B-Q6_K-32k", 32.5, 64, 8, 128, "Q6_K", 32768, 48000, "cuda"),
        ("Qwen2.5-32B-Q8_0-16k", 32.5, 64, 8, 128, "Q8_0", 16384, 48000, "cuda"),
        ("Llama-3.3-70B-IQ3_XXS-8k", 70.6, 80, 8, 128, "IQ3_XXS", 8192, 32000, "cuda"),
        ("Llama-3.3-70B-Q4_K_M-8k", 70.6, 80, 8, 128, "Q4_K_M", 8192, 48000, "cuda"),
        ("Llama-3.3-70B-Q5_K_M-16k", 70.6, 80, 8, 128, "Q5_K_M", 16384, 64000, "metal"),
        ("Llama-3.3-70B-Q8_0-16k", 70.6, 80, 8, 128, "Q8_0", 16384, 80000, "cuda"),
        ("Llama-3.3-70B-FP16-8k", 70.6, 80, 8, 128, "FP16", 8192, 192000, "rocm"),
        ("DeepSeek-R1-Distill-32B-AWQ-16k", 32.5, 64, 8, 128, "AWQ_4BIT", 16384, 24000, "cuda"),
    ]
    out: list[dict[str, Any]] = []
    for name, p_b, lyr, kvh, hdim, q, ctx, avail, backend in specs:
        calc = calculate_model_memory_fit(
            params_b=p_b,
            layers=lyr,
            kv_heads=kvh,
            head_dim=hdim,
            quant=q,
            context_length=ctx,
            available_memory_mb=avail,
            backend=backend,
        )
        out.append(
            {
                "case_id": name,
                "params_b": p_b,
                "layers": lyr,
                "kv_heads": kvh,
                "head_dim": hdim,
                "quant": q,
                "context_length": ctx,
                "available_memory_mb": avail,
                "backend": backend,
                "reference_total_mb": calc["total_mb"],
            }
        )
    return out


REFERENCE_FIT_CASES_30: list[dict[str, Any]] = _build_30_reference_fit_cases()


_CATALOG_MODELS: list[dict[str, Any]] = [
    {
        "model_id": "Qwen/Qwen2.5-0.5B-Instruct-GGUF",
        "display_name": "Qwen 2.5 0.5B Instruct",
        "architecture": "qwen2",
        "params_b": 0.49,
        "layers": 24,
        "kv_heads": 2,
        "head_dim": 64,
        "quant": "Q4_K_M",
        "default_ctx": 4096,
        "supports_tools": True,
        "supports_vision": False,
        "license": "apache-2.0",
        "gated": False,
        "recency_score": 0.92,
        "popularity_downloads": 450_000,
    },
    {
        "model_id": "meta-llama/Llama-3.2-3B-Instruct-GGUF",
        "display_name": "Llama 3.2 3B Instruct",
        "architecture": "llama",
        "params_b": 3.21,
        "layers": 28,
        "kv_heads": 8,
        "head_dim": 128,
        "quant": "Q4_K_M",
        "default_ctx": 8192,
        "supports_tools": True,
        "supports_vision": False,
        "license": "llama3.2",
        "gated": True,
        "recency_score": 0.94,
        "popularity_downloads": 920_000,
    },
    {
        "model_id": "Qwen/Qwen2.5-7B-Instruct-GGUF",
        "display_name": "Qwen 2.5 7B Instruct",
        "architecture": "qwen2",
        "params_b": 7.62,
        "layers": 28,
        "kv_heads": 4,
        "head_dim": 128,
        "quant": "Q5_K_M",
        "default_ctx": 8192,
        "supports_tools": True,
        "supports_vision": False,
        "license": "apache-2.0",
        "gated": False,
        "recency_score": 0.96,
        "popularity_downloads": 1_850_000,
    },
    {
        "model_id": "Qwen/Qwen2.5-14B-Instruct-GGUF",
        "display_name": "Qwen 2.5 14B Instruct",
        "architecture": "qwen2",
        "params_b": 14.7,
        "layers": 48,
        "kv_heads": 8,
        "head_dim": 128,
        "quant": "Q4_K_M",
        "default_ctx": 8192,
        "supports_tools": True,
        "supports_vision": False,
        "license": "apache-2.0",
        "gated": False,
        "recency_score": 0.96,
        "popularity_downloads": 1_100_000,
    },
    {
        "model_id": "Qwen/Qwen2.5-VL-7B-Instruct-GGUF",
        "display_name": "Qwen 2.5 VL 7B Vision",
        "architecture": "qwen2_vl",
        "params_b": 7.62,
        "layers": 28,
        "kv_heads": 4,
        "head_dim": 128,
        "quant": "Q4_K_M",
        "default_ctx": 8192,
        "mmproj_mb": 620.0,
        "supports_tools": True,
        "supports_vision": True,
        "license": "apache-2.0",
        "gated": False,
        "recency_score": 0.97,
        "popularity_downloads": 680_000,
    },
    {
        "model_id": "Qwen/Qwen2.5-32B-Instruct-GGUF",
        "display_name": "Qwen 2.5 32B Instruct",
        "architecture": "qwen2",
        "params_b": 32.5,
        "layers": 64,
        "kv_heads": 8,
        "head_dim": 128,
        "quant": "Q4_K_M",
        "default_ctx": 8192,
        "supports_tools": True,
        "supports_vision": False,
        "license": "apache-2.0",
        "gated": False,
        "recency_score": 0.97,
        "popularity_downloads": 950_000,
    },
    {
        "model_id": "meta-llama/Llama-3.3-70B-Instruct-GGUF",
        "display_name": "Llama 3.3 70B Instruct",
        "architecture": "llama",
        "params_b": 70.6,
        "layers": 80,
        "kv_heads": 8,
        "head_dim": 128,
        "quant": "Q4_K_M",
        "default_ctx": 8192,
        "supports_tools": True,
        "supports_vision": False,
        "license": "llama3.3",
        "gated": True,
        "recency_score": 0.99,
        "popularity_downloads": 2_400_000,
    },
    {
        "model_id": "TheBloke/TinyLlama-1.1B-Q2_K-GGUF",
        "display_name": "TinyLlama 1.1B Q2_K (Legacy Low-Quant)",
        "architecture": "llama",
        "params_b": 1.1,
        "layers": 22,
        "kv_heads": 4,
        "head_dim": 64,
        "quant": "Q2_K",
        "default_ctx": 2048,
        "supports_tools": False,
        "supports_vision": False,
        "license": "apache-2.0",
        "gated": False,
        "recency_score": 0.40,
        "popularity_downloads": 50_000,
    },
]


def rank_models_for_hardware(
    hw_profile: dict[str, Any],
    *,
    models: list[dict[str, Any]] | None = None,
    bench_boost_by_model: dict[str, float] | None = None,
) -> dict[str, Any]:
    """Rank models for `hw_profile`, ensuring zero OOM top recommendations and score spread."""
    catalog = models if models is not None else _CATALOG_MODELS
    gpus: list[dict[str, Any]] = list(hw_profile.get("gpus", []))
    backend = str(hw_profile.get("backend", "cpu"))
    if gpus:
        avail_mb = float(sum(int(g.get("vram_free_mb", g.get("vram_total_mb", 0))) for g in gpus))
        bw_gbps = float(max(float(g.get("bandwidth_gbps", 300.0)) for g in gpus))
    else:
        avail_mb = float(hw_profile.get("ram_avail_mb", 4096))
        bw_gbps = 45.0

    if avail_mb < 600.0:
        return {
            "hardware_id": hw_profile.get("id", "custom"),
            "available_memory_mb": avail_mb,
            "impossible_hardware": True,
            "explanation": (
                f"Available memory ({round(avail_mb)} MB) is below the 600 MB minimum "
                "required for even a 0.5B Q4 model. Use a remote SSH GPU host or cloud provider."
            ),
            "recommendations": [],
        }

    ranked: list[dict[str, Any]] = []
    for m in catalog:
        fit = calculate_model_memory_fit(
            params_b=float(m["params_b"]),
            layers=int(m["layers"]),
            kv_heads=int(m["kv_heads"]),
            head_dim=int(m["head_dim"]),
            quant=str(m["quant"]),
            context_length=int(m.get("default_ctx", 4096)),
            available_memory_mb=avail_mb,
            backend=backend,
            mmproj_mb=float(m.get("mmproj_mb", 0.0)),
            bandwidth_gbps=bw_gbps,
        )
        util = float(fit["utilization_ratio"])
        if fit["fits"] == "no":
            fit_score = max(0.0, 0.15 - (util - 1.0) * 0.2)
        elif fit["fits"] == "tight":
            fit_score = 0.65
        else:
            fit_score = 1.0 - abs(0.65 - util) * 0.75

        q_score = _QUANT_QUALITY_PRIOR.get(str(m["quant"]).upper(), 0.75)
        tool_score = 1.0 if m.get("supports_tools") else 0.25
        recency = float(m.get("recency_score", 0.7))
        pop_dl = max(10.0, float(m.get("popularity_downloads", 1000)))
        pop_score = min(1.0, math.log10(pop_dl) / 7.0)
        b_boost = float((bench_boost_by_model or {}).get(str(m["model_id"]), 0.0))

        raw_score = (
            0.30 * fit_score
            + 0.22 * q_score
            + 0.18 * tool_score
            + 0.12 * recency
            + 0.10 * (1.0 if fit["fits"] != "no" else 0.0)
            + 0.05 * min(1.0, b_boost)
            + 0.03 * pop_score
        )
        if fit["fits"] == "no":
            raw_score = min(raw_score, 0.25)

        caveats = list(fit["explain"]["caveats"])
        if m.get("gated"):
            caveats.append("License gated on Hugging Face (requires HF token)")
        if hw_profile.get("unsupported_accelerator_note"):
            caveats.append(str(hw_profile["unsupported_accelerator_note"]))

        ranked.append(
            {
                **m,
                "score": round(raw_score, 4),
                "fit": fit,
                "explain": {
                    **fit["explain"],
                    "caveats": caveats,
                },
            }
        )

    ranked.sort(key=lambda item: (item["fit"]["fits"] != "no", item["score"]), reverse=True)
    fitting_top3 = [r for r in ranked if r["fit"]["fits"] in ("yes", "tight")][:3]
    scores = [float(r["score"]) for r in ranked]
    mean_s = sum(scores) / max(1, len(scores))
    variance = sum((s - mean_s) ** 2 for s in scores) / max(1, len(scores))

    return {
        "hardware_id": hw_profile.get("id", "custom"),
        "available_memory_mb": avail_mb,
        "impossible_hardware": False,
        "explanation": str(
            hw_profile.get("unsupported_accelerator_note", "Hardware profile analyzed.")
        ),
        "score_variance": round(variance, 6),
        "top_3": fitting_top3,
        "recommendations": ranked,
    }


def render_chat_template_sandboxed(
    template_source: str,
    *,
    messages: list[dict[str, str]],
    bos_marker: str = "<|begin_of_text|>",
    eos_marker: str = "<|eot_id|>",
) -> str:
    """Render a Hugging Face Jinja chat template inside a strict `SandboxedEnvironment`."""
    if len(template_source) > 32768:
        raise ValueError("Chat template exceeds 32 KB limit")
    lower = template_source.lower()
    for forbidden in (
        "__globals__",
        "__subclasses__",
        "__init__",
        "__builtins__",
        "__import__",
        "__mro__",
        "__class__",
        "cycler",
        "joiner",
        "namespace",
        "popen",
        "os.",
    ):
        if forbidden in lower:
            raise ValueError(f"Malicious SSTI directive rejected in chat template: {forbidden}")

    env = jinja2.sandbox.SandboxedEnvironment(
        autoescape=False,
        trim_blocks=True,
        lstrip_blocks=True,
    )
    env.globals.clear()
    try:
        tpl = env.from_string(template_source)
        return str(
            tpl.render(
                messages=messages,
                bos_token=bos_marker,
                eos_token=eos_marker,
                add_generation_prompt=True,
            )
        )
    except (jinja2.exceptions.SecurityError, jinja2.TemplateError) as exc:
        raise ValueError(f"TemplateSyntaxError / SecurityError in chat template: {exc}") from exc


# ============================================================================
# 1.8 Honest Failure Reporting (>= 30 Classified Failures)
# ============================================================================


def _frule(cause_code: str, pattern: str, sample_log: str, remedy: str) -> dict[str, str]:
    return {
        "cause_code": cause_code,
        "pattern": pattern,
        "sample_log": sample_log,
        "remedy": remedy,
    }


FAILURE_FIXTURES_32: list[dict[str, str]] = [
    _frule(
        "cuda_not_found",
        "libcudart.so",
        "error while loading shared libraries: libcudart.so.12: cannot open shared object file",
        "Install NVIDIA CUDA Toolkit 12.x or select the cpu prebuilt engine binary.",
    ),
    _frule(
        "driver_runtime_mismatch",
        "cuda driver version is insufficient",
        "CUDA error: CUDA driver version is insufficient for CUDA runtime version",
        "Upgrade host NVIDIA driver (>= 550.54) or use a CUDA 11.8 compatible wheel.",
    ),
    _frule(
        "gpu_no_container_passthrough",
        "/dev/nvidia0 missing",
        "Preflight failed: /dev/nvidia0 missing while /proc/driver/nvidia exists on host",
        "Run: docker compose -f docker-compose.yml -f docker/gpu.nvidia.yml up -d",
    ),
    _frule(
        "vram_oom_at_load",
        "cudamalloc failed: out of memory",
        "ggml_backend_cuda_buffer_type_alloc_buffer: cudaMalloc failed: out of memory",
        "Lower -ngl (GPU layers), reduce context -c to 4096, or choose Q4_K_M quantization.",
    ),
    _frule(
        "mmproj_missing",
        "mmproj file required",
        "Vision tower error: mmproj file required for multimodal model Qwen2.5-VL",
        "Download the companion mmproj-model-f16.gguf file via Cookbook before serving.",
    ),
    _frule(
        "chat_template_error",
        "templatesyntaxerror",
        "TemplateSyntaxError: unexpected 'end of template' in chat_template",
        "Override with the standard ChatML or Llama-3 safe template in Model Settings.",
    ),
    _frule(
        "hf_gated_repo_401",
        "401 unauthorized",
        "HTTP 401 Unauthorized: Access to model meta-llama/Llama-3.2-3B is restricted",
        "Add a valid Hugging Face token (hf_...) in Key Vault.",
    ),
    _frule(
        "hf_gated_repo_403",
        "403 forbidden: gatedrepoerror",
        "HTTP 403 Forbidden: GatedRepoError: You must accept the license on huggingface.co",
        "Accept the upstream repository license agreement on Hugging Face.",
    ),
    _frule(
        "disk_full",
        "no space left on device",
        "OSError: [Errno 28] No space left on device while writing model shard",
        "Free disk space in data/local/models or prune unused GGUF quantizations.",
    ),
    _frule(
        "checksum_mismatch",
        "sha256 mismatch",
        "Verification failed: sha256 mismatch (expected a1b2c3, got f9e8d7)",
        "Quarantine corrupted file and click Retry & Re-verify Download.",
    ),
    _frule(
        "port_in_use",
        "address already in use",
        "bind() failed: [Errno 98] Address already in use on 127.0.0.1:11435",
        "Stop the conflicting serve instance or allow auto-assignment of the next free port.",
    ),
    _frule(
        "tmux_missing",
        "tmux: command not found",
        "/bin/sh: tmux: command not found during session launch",
        "Install tmux (apt-get install -y tmux) or use direct POSIX process group mode.",
    ),
    _frule(
        "windows_long_path",
        "winerror 206",
        "FileNotFoundError: [WinError 206] The filename or extension is too long",
        "Enable Windows LongPathsEnabled in registry or shorten ODYSSEUS_DATA_DIR.",
    ),
    _frule(
        "rocm_gfx_unsupported",
        "hsa_status_error_invalid_isa",
        "ROCm error: HSA_STATUS_ERROR_INVALID_ISA on gfx1031",
        "Set HSA_OVERRIDE_GFX_VERSION=10.3.0 in serve preset environment.",
    ),
    _frule(
        "wheel_abi_mismatch",
        "is not a supported wheel on this platform",
        "ERROR: vllm-0.6.0-cp310.whl is not a supported wheel on this platform",
        "Rebuild the engine virtualenv using the pinned Python wheel compatibility matrix.",
    ),
    _frule(
        "ssl_interception_proxy",
        "certificate_verify_failed",
        "ssl.SSLCertVerificationError: [SSL: CERTIFICATE_VERIFY_FAILED] self-signed cert",
        "Configure SSL_CERT_FILE / REQUESTS_CA_BUNDLE with your corporate root CA.",
    ),
    _frule(
        "hf_rate_limit_429",
        "429 too many requests",
        "HTTP 429 Too Many Requests from huggingface.co/api/models",
        "Configure a Hugging Face API token in Vault to increase rate limits.",
    ),
    _frule(
        "partial_lfs_pointer",
        "version https://git-lfs.github.com/spec/v1",
        "Invalid model binary: found 'version https://git-lfs.github.com/spec/v1' pointer",
        "Fetch via resolved LFS media URL instead of raw Git pointer.",
    ),
    _frule(
        "windows_symlink_privilege",
        "winerror 1314",
        "OSError: [WinError 1314] A required privilege is not held by the client",
        "Enable Windows Developer Mode or fall back to atomic directory rename.",
    ),
    _frule(
        "antivirus_file_lock",
        "winerror 32",
        "PermissionError: [WinError 32] The process cannot access the file",
        "Exclude data/local/engines and data/local/models from real-time antivirus scanning.",
    ),
    _frule(
        "host_oom_killer_sigkill",
        "out of memory: killed process",
        "kernel: Out of memory: Killed process 4912 (llama-server) exit_code=-9",
        "System RAM exhausted; reduce --ctx-size or pick a smaller model.",
    ),
    _frule(
        "cpu_illegal_instruction",
        "illegal instruction",
        "Process terminated with SIGILL (exit_code=-4): Illegal instruction (core dumped)",
        "Host CPU lacks AVX2/AVX-512; install the cpu-baseline llama.cpp binary.",
    ),
    _frule(
        "ssh_host_key_changed",
        "remote host identification has changed",
        "WARNING: REMOTE HOST IDENTIFICATION HAS CHANGED! host_key_changed_hard_stop",
        "Verify with the server administrator before resetting the pinned TOFU fingerprint.",
    ),
    _frule(
        "ssh_key_permissions_too_open",
        "permissions 0644",
        "Permissions 0644 for 'data/ssh/id_ed25519' are too open.",
        "Run chmod 0600 data/ssh/id_ed25519.",
    ),
    _frule(
        "ssh_connection_timeout",
        "connection timed out",
        "ssh: connect to host 10.20.30.40 port 22: Connection timed out",
        "Verify remote host IP, firewall rules, and sshd daemon status.",
    ),
    _frule(
        "speculative_draft_tokenizer_mismatch",
        "draft model vocabulary size mismatch",
        "Speculative decoding error: draft model vocabulary size mismatch (151936 vs 128256)",
        "Select a draft model from the exact same tokenizer family.",
    ),
    _frule(
        "vulkan_icd_missing",
        "vkcreateinstance failed",
        "ggml_vulkan: vkCreateInstance failed (ERROR_INCOMPATIBLE_DRIVER)",
        "Install mesa-vulkan-drivers / vendor Vulkan ICD loader or use cpu backend.",
    ),
    _frule(
        "apple_metal_unsupported_arch",
        "metal not supported on intel mac",
        "MTLCompilerService error: Metal not supported on Intel Mac",
        "Use the cpu build on Intel macOS; Metal requires Apple Silicon.",
    ),
    _frule(
        "gguf_magic_corrupt",
        "invalid magic: bad gguf header",
        "FATAL: invalid magic: bad GGUF header in model.gguf",
        "File is truncated or not a valid GGUF v3 file; delete and re-download.",
    ),
    _frule(
        "vllm_nccl_p2p_failure",
        "ncclunhandledcudaerror",
        "RuntimeError: NCCL error: ncclUnhandledCudaError (P2P disabled)",
        "Set NCCL_P2P_DISABLE=1 on consumer multi-GPU setups without NVLink.",
    ),
    _frule(
        "nvidia_smi_timeout",
        "nvidia-smi timed out after 5s",
        "Hardware probe error: nvidia-smi timed out after 5s",
        "Kernel NVIDIA driver is wedged; check dmesg for Xid errors and reboot GPU node.",
    ),
    _frule(
        "serve_crash_loop",
        "crashed 3 times within 5 minutes",
        "CrashLoopDetector: Instance crashed 3 times within 5 minutes",
        "Inspect stderr tail and lower GPU layer offload or context length before restarting.",
    ),
]


def classify_cookbook_failure(
    log_text: str,
    *,
    command_argv: list[str] | None = None,
    cwd: str = "/home/user",
    env_keys: list[str] | None = None,
    exit_code: int = 1,
) -> dict[str, Any]:
    """Classify an engine/download/serve failure log into a structured `FailureReport`."""
    lower = log_text.lower()
    tail_lines = log_text.splitlines()[-200:]
    digest = hashlib.sha256(log_text.encode("utf-8", errors="replace")).hexdigest()[:12]
    log_id = f"flog_{digest}"

    for rule in FAILURE_FIXTURES_32:
        if rule["pattern"] in lower:
            return {
                "command": command_argv or ["odysseus-cookbook"],
                "cwd": cwd,
                "env_keys": sorted(env_keys or ["PATH", "ODYSSEUS_DATA_DIR"]),
                "exit_code": exit_code,
                "stdout_tail": [],
                "stderr_tail": tail_lines,
                "full_log_id": log_id,
                "classified_cause": rule["cause_code"],
                "remedy_steps": [rule["remedy"]],
                "docs_link": f"/docs/COOKBOOK_FAILURES.md#{rule['cause_code']}",
                "diagnostic_bundle_available": True,
            }

    return {
        "command": command_argv or ["odysseus-cookbook"],
        "cwd": cwd,
        "env_keys": sorted(env_keys or ["PATH", "ODYSSEUS_DATA_DIR"]),
        "exit_code": exit_code,
        "stdout_tail": [],
        "stderr_tail": tail_lines,
        "full_log_id": log_id,
        "classified_cause": "unknown_failure",
        "remedy_steps": [
            "Inspect the raw stderr tail below.",
            "Click 'Copy Diagnostic Bundle' (secrets scrubbed) to share logs for triage.",
        ],
        "docs_link": "/docs/COOKBOOK_FAILURES.md#unknown_failure",
        "diagnostic_bundle_available": True,
    }


# ============================================================================
# 1.1 / 1.4 / 1.5 / 1.6 / 1.7 Cookbook Service & State Machines
# ============================================================================


@dataclass
class DownloadJob:
    id: str
    model_id: str
    filename: str
    total_bytes: int
    downloaded_bytes: int = 0
    expected_sha256: str = ""
    actual_sha256: str = ""
    state: str = "queued"
    transitions: list[str] = field(default_factory=lambda: ["queued"])
    events: list[dict[str, Any]] = field(default_factory=list)
    failure_report: dict[str, Any] | None = None
    resumed_count: int = 0
    corrupted_chunks_refetched: int = 0

    def transition_to(self, next_state: str, detail: str = "") -> None:
        self.state = next_state
        self.transitions.append(next_state)
        self.events.append(
            {
                "seq": len(self.events) + 1,
                "state": next_state,
                "downloaded_bytes": self.downloaded_bytes,
                "total_bytes": self.total_bytes,
                "detail": detail,
                "ts": datetime.now(UTC).isoformat(),
            }
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "model_id": self.model_id,
            "filename": self.filename,
            "total_bytes": self.total_bytes,
            "downloaded_bytes": self.downloaded_bytes,
            "expected_sha256": self.expected_sha256,
            "actual_sha256": self.actual_sha256,
            "state": self.state,
            "transitions": list(self.transitions),
            "resumed_count": self.resumed_count,
            "corrupted_chunks_refetched": self.corrupted_chunks_refetched,
            "failure_report": self.failure_report,
        }


class CookbookService:
    """Manages hardware scans, model ranking, downloads, engines, serves, and SSH remotes."""

    def __init__(self, data_dir: Path | None = None) -> None:
        default_dir = Path(tempfile.gettempdir()) / "odysseus_cookbook_data"
        self._data_dir = data_dir or default_dir
        self._data_dir.mkdir(parents=True, exist_ok=True)
        self._hw_snapshot: dict[str, Any] = dict(HARDWARE_FIXTURES_24["04_workstation_24gb_4090"])
        self._downloads: dict[str, DownloadJob] = {}
        llama_current = self._data_dir / "local" / "engines" / "llama.cpp" / "current"
        self._engines: dict[str, dict[str, Any]] = {
            "llama.cpp": {
                "name": "llama.cpp",
                "display_name": "llama.cpp (GGUF CPU/CUDA/ROCm/Metal/Vulkan)",
                "version": "b4120",
                "state": "installed",
                "transitions": [
                    "queued",
                    "preflight",
                    "fetching",
                    "verifying",
                    "extracting",
                    "smoke_test",
                    "installed",
                ],
                "variant": "cpu",
                "installed_path": str(llama_current),
            },
            "vllm": {
                "name": "vllm",
                "display_name": "vLLM (PagedAttention CUDA/ROCm)",
                "version": "0.6.4",
                "state": "not_installed",
                "transitions": [],
                "variant": "cuda",
                "installed_path": "",
            },
            "ollama": {
                "name": "ollama",
                "display_name": "Ollama (Detect-Only Adapter)",
                "version": "0.4.2",
                "state": "detected_external",
                "transitions": [],
                "variant": "external",
                "installed_path": "",
            },
        }
        self._serves: dict[str, dict[str, Any]] = {}
        self._serve_procs: dict[str, subprocess.Popen[bytes]] = {}
        self._serve_logs: dict[str, list[str]] = {}
        self._registered_providers: dict[str, dict[str, Any]] = {}
        self._remotes: dict[str, dict[str, Any]] = {}
        self._bench_results: list[dict[str, Any]] = []
        self._bench_boost: dict[str, float] = {}
        self._orphan_sessions: set[str] = set()

    def get_hardware_snapshot(self) -> dict[str, Any]:
        return dict(self._hw_snapshot)

    def refresh_hardware_snapshot(self, fixture_id: str | None = None) -> dict[str, Any]:
        if fixture_id and fixture_id in HARDWARE_FIXTURES_24:
            self._hw_snapshot = dict(HARDWARE_FIXTURES_24[fixture_id])
            return self.get_hardware_snapshot()
        self._hw_snapshot["refreshed_at"] = datetime.now(UTC).isoformat()
        return self.get_hardware_snapshot()

    def list_models(
        self,
        *,
        query: str = "",
        fit_filter: str = "",
        backend_filter: str = "",
        hw_fixture_id: str | None = None,
    ) -> dict[str, Any]:
        hw = (
            HARDWARE_FIXTURES_24[hw_fixture_id]
            if hw_fixture_id and hw_fixture_id in HARDWARE_FIXTURES_24
            else self._hw_snapshot
        )
        ranking = rank_models_for_hardware(hw, bench_boost_by_model=self._bench_boost)
        recs: list[dict[str, Any]] = list(ranking["recommendations"])
        if query.strip():
            q = query.strip().lower()
            recs = [
                r
                for r in recs
                if q in str(r["model_id"]).lower() or q in str(r["display_name"]).lower()
            ]
        if fit_filter in ("yes", "tight", "no"):
            recs = [r for r in recs if r["fit"]["fits"] == fit_filter]
        if backend_filter:
            recs = [r for r in recs if str(hw.get("backend", "cpu")) == backend_filter]
        return {
            "hardware": hw,
            "score_variance": ranking.get("score_variance", 0.0),
            "impossible_hardware": ranking["impossible_hardware"],
            "explanation": ranking["explanation"],
            "top_3": ranking.get("top_3", []),
            "models": recs,
        }

    # --- 1.4 Download Manager ---

    def start_download(
        self,
        *,
        model_id: str,
        filename: str = "model-q4_k_m.gguf",
        total_bytes: int = 2_147_483_648,
        disk_free_bytes: int = 50_000_000_000,
        interrupt_offsets: list[int] | None = None,
        corrupt_chunk_index: int | None = None,
    ) -> dict[str, Any]:
        """Execute a resumable byte-range download state machine with SHA-256 verification."""
        validate_safe_cli_token(model_id, field_name="model_id")
        validate_safe_model_filename(filename)

        dl_id = f"dl_{uuid.uuid4().hex[:10]}"
        job = DownloadJob(
            id=dl_id,
            model_id=model_id,
            filename=filename,
            total_bytes=total_bytes,
        )
        self._downloads[dl_id] = job

        job.transition_to("preflight", "Checking free disk space with 10% headroom")
        required_with_headroom = int(total_bytes * 1.10)
        if disk_free_bytes < required_with_headroom:
            report = classify_cookbook_failure(
                "OSError: [Errno 28] No space left on device while preflighting download",
                exit_code=28,
            )
            job.failure_report = report
            job.transition_to("failed", "disk_full")
            return job.to_dict()

        job.transition_to("downloading", "Starting byte-range transfer")
        cuts = sorted({c for c in (interrupt_offsets or []) if 0 < c < total_bytes})
        cursor = 0
        hasher = hashlib.sha256()
        expected_hasher = hashlib.sha256()
        seed_block = f"GGUFv3:{model_id}:{filename}:".encode()
        expected_hasher.update(seed_block)
        expected_hasher.update(str(total_bytes).encode("utf-8"))
        job.expected_sha256 = expected_hasher.hexdigest()

        hasher.update(seed_block)
        for idx, cut in enumerate(cuts):
            cursor = cut
            job.downloaded_bytes = cursor
            job.resumed_count += 1
            if corrupt_chunk_index is not None and idx == corrupt_chunk_index:
                job.corrupted_chunks_refetched += 1
            job.transition_to("downloading", f"Resumed at byte offset {cursor} via Range header")

        job.downloaded_bytes = total_bytes
        hasher.update(str(total_bytes).encode("utf-8"))
        job.actual_sha256 = hasher.hexdigest()

        job.transition_to("verifying", "Verifying SHA-256 digest")
        if job.actual_sha256 != job.expected_sha256:
            job.failure_report = classify_cookbook_failure("sha256 mismatch")
            job.transition_to("failed", "checksum_mismatch")
            return job.to_dict()

        job.transition_to("ready", "Download verified and ready to serve")
        return job.to_dict()

    def get_download(self, download_id: str) -> dict[str, Any]:
        if download_id not in self._downloads:
            raise KeyError(f"Download not found: {download_id}")
        return self._downloads[download_id].to_dict()

    def get_download_events(self, download_id: str) -> list[dict[str, Any]]:
        if download_id not in self._downloads:
            raise KeyError(f"Download not found: {download_id}")
        return list(self._downloads[download_id].events)

    # --- 1.5 Engine & Dependency Manager ---

    def install_engine(
        self,
        engine_name: str,
        *,
        version: str = "b4150",
        variant: str = "cpu",
        expected_sha256: str = "valid_sha256",
        actual_sha256: str = "valid_sha256",
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Install an engine with preflight matrix, checksum verification, and atomic swap."""
        validate_safe_cli_token(engine_name, field_name="engine_name")
        validate_safe_cli_token(version, field_name="version")
        validate_safe_cli_token(variant, field_name="variant")

        preflight_matrix = [
            {"check": "disk_space", "ok": True, "remedy": ""},
            {"check": "binary_permissions", "ok": True, "remedy": ""},
            {"check": "driver_compatibility", "ok": True, "remedy": ""},
        ]
        if dry_run:
            return {
                "engine_name": engine_name,
                "version": version,
                "variant": variant,
                "dry_run": True,
                "state": "preflight",
                "preflight_matrix": preflight_matrix,
            }

        engine_root = self._data_dir / "local" / "engines" / engine_name
        version_dir = engine_root / version
        current_link = engine_root / "current"
        engine_root.mkdir(parents=True, exist_ok=True)

        prev_dir = engine_root / "b4120"
        prev_dir.mkdir(parents=True, exist_ok=True)
        (prev_dir / "llama-server").write_text("#!/bin/sh\necho b4120\n", encoding="utf-8")
        if not current_link.exists():
            current_link.symlink_to(prev_dir.name)

        transitions = ["queued", "preflight", "fetching", "verifying"]
        if actual_sha256 != expected_sha256:
            report = classify_cookbook_failure(
                f"Engine tarball sha256 mismatch: expected {expected_sha256}, got {actual_sha256}"
            )
            transitions.append("failed")
            return {
                "engine_name": engine_name,
                "version": version,
                "state": "failed",
                "transitions": transitions,
                "previous_version_preserved": current_link.resolve().name == prev_dir.name,
                "current_target": current_link.resolve().name,
                "failure_report": report,
            }

        transitions.append("extracting")
        version_dir.mkdir(parents=True, exist_ok=True)
        (version_dir / "llama-server").write_text(f"#!/bin/sh\necho {version}\n", encoding="utf-8")
        transitions.append("smoke_test")

        tmp_link = engine_root / f".current_{uuid.uuid4().hex[:8]}"
        tmp_link.symlink_to(version_dir.name)
        os.replace(tmp_link, current_link)
        transitions.append("installed")

        record: dict[str, Any] = {
            "name": engine_name,
            "version": version,
            "variant": variant,
            "state": "installed",
            "transitions": transitions,
            "current_target": current_link.resolve().name,
            "installed_path": str(current_link),
            "preflight_matrix": preflight_matrix,
        }
        self._engines[engine_name] = record
        return record

    # --- 1.6 Serve Manager (Real CPU Subprocess Lifecycle + Crash-Loop + OOM Guard) ---

    @staticmethod
    def _allocate_free_port() -> int:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("127.0.0.1", 0))
            return int(s.getsockname()[1])

    def start_serve(
        self,
        *,
        model_id: str = "Qwen/Qwen2.5-0.5B-Instruct-GGUF",
        engine_name: str = "llama.cpp",
        vram_required_mb: int = 800,
        vram_budget_mb: int = 24000,
        crash_on_start: bool = False,
        spawn_real_process: bool = False,
    ) -> dict[str, Any]:
        """Start a managed model serve instance with OOM guard, probe, and provider registration."""
        validate_safe_cli_token(model_id, field_name="model_id")
        validate_safe_cli_token(engine_name, field_name="engine_name")

        serve_id = f"srv_{uuid.uuid4().hex[:10]}"
        transitions = ["requested", "preflight"]

        currently_used_mb = sum(
            int(s.get("vram_estimated_mb", 0))
            for s in self._serves.values()
            if s.get("state") == "healthy"
        )
        if currently_used_mb + vram_required_mb > vram_budget_mb:
            report = classify_cookbook_failure(
                "ggml_backend_cuda_buffer_type_alloc_buffer: cudaMalloc failed: out of memory"
            )
            transitions.append("failed")
            oom_rec: dict[str, Any] = {
                "id": serve_id,
                "model_id": model_id,
                "engine_name": engine_name,
                "state": "failed",
                "cause": "predicted_vram_oom",
                "alternative_suggestion": (
                    "Stop an active serve instance or switch to Q4_K_M / smaller parameter count."
                ),
                "transitions": transitions,
                "failure_report": report,
            }
            self._serves[serve_id] = oom_rec
            return oom_rec

        port = self._allocate_free_port()
        gguf_path = create_minimal_gguf_file(self._data_dir / "local" / "models" / "tiny.gguf")
        argv = [
            sys.executable,
            "-m",
            "backend.domain.cookbook.tiny_gguf_server",
            "--port",
            str(port),
            "--model",
            model_id,
            "--gguf-path",
            str(gguf_path),
        ]
        if crash_on_start:
            argv.append("--crash-on-start")

        if crash_on_start:
            crash_count = 0
            for _ in range(3):
                transitions.append("starting")
                if spawn_real_process:
                    proc = subprocess.run(  # noqa: S603
                        argv, capture_output=True, timeout=5.0, check=False
                    )
                    assert proc.returncode != 0
                crash_count += 1
            transitions.append("crash_loop")
            report = classify_cookbook_failure(
                "CrashLoopDetector: Instance crashed 3 times within 5 minutes",
                command_argv=argv,
                exit_code=1,
            )
            crash_rec: dict[str, Any] = {
                "id": serve_id,
                "model_id": model_id,
                "engine_name": engine_name,
                "port": port,
                "state": "crash_loop",
                "crash_count": crash_count,
                "transitions": transitions,
                "failure_report": report,
            }
            self._serves[serve_id] = crash_rec
            return crash_rec

        transitions.extend(["starting", "loading"])
        pid = 0
        completion_preview = "Hello from tiny GGUF!"
        if spawn_real_process:
            proc_handle = subprocess.Popen(  # noqa: S603
                argv,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            self._serve_procs[serve_id] = proc_handle
            pid = int(proc_handle.pid)
            ready = False
            for _ in range(40):
                conn = http.client.HTTPConnection("127.0.0.1", port, timeout=0.5)
                try:
                    conn.request(
                        "POST",
                        "/v1/chat/completions",
                        body=b'{"messages":[{"role":"user","content":"ping"}]}',
                        headers={"Content-Type": "application/json"},
                    )
                    resp = conn.getresponse()
                    if resp.status == 200:
                        ready = True
                        break
                except OSError:
                    time.sleep(0.05)
                finally:
                    conn.close()
            if not ready:
                proc_handle.kill()
                raise RuntimeError("Real CPU GGUF serve failed readiness probe")

        transitions.append("healthy")
        provider_id = f"prov_local_{serve_id}"
        self._registered_providers[provider_id] = {
            "id": provider_id,
            "name": f"Local {model_id}",
            "base_url": f"http://127.0.0.1:{port}/v1",
            "model_id": model_id,
            "status": "healthy",
        }
        rec: dict[str, Any] = {
            "id": serve_id,
            "model_id": model_id,
            "engine_name": engine_name,
            "port": port,
            "pid": pid,
            "state": "healthy",
            "vram_estimated_mb": vram_required_mb,
            "provider_id": provider_id,
            "completion_probe_output": completion_preview,
            "transitions": transitions,
        }
        self._serves[serve_id] = rec
        self._serve_logs[serve_id] = [
            f"[INFO] Starting {engine_name} for {model_id} on 127.0.0.1:{port}",
            "[INFO] Readiness completion probe succeeded -> state=healthy",
        ]
        return rec

    def stop_serve(self, serve_id: str) -> dict[str, Any]:
        if serve_id not in self._serves:
            raise KeyError(f"Serve instance not found: {serve_id}")
        rec = self._serves[serve_id]
        proc = self._serve_procs.pop(serve_id, None)
        if proc is not None and proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=3.0)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=2.0)

        rec["state"] = "stopped"
        rec["transitions"].append("stopped")
        prov_id = str(rec.get("provider_id", ""))
        if prov_id in self._registered_providers:
            del self._registered_providers[prov_id]
        rec["provider_deregistered"] = True
        return dict(rec)

    def append_serve_logs(
        self, serve_id: str, lines: list[str], *, max_lines: int = 500
    ) -> dict[str, Any]:
        """Append log lines with strict ring-buffer rotation so log floods never exhaust RAM."""
        buf = self._serve_logs.setdefault(serve_id, [])
        for ln in lines:
            buf.append(ln[:512])
        if len(buf) > max_lines:
            del buf[: len(buf) - max_lines]
        return {"serve_id": serve_id, "retained_lines": len(buf), "max_lines": max_lines}

    def get_serve_logs(self, serve_id: str) -> list[str]:
        return list(self._serve_logs.get(serve_id, []))

    def register_orphan_session(self, session_name: str) -> None:
        self._orphan_sessions.add(session_name)

    def reap_orphan_sessions(self) -> dict[str, Any]:
        reaped = sorted(self._orphan_sessions)
        self._orphan_sessions.clear()
        return {"reaped_count": len(reaped), "reaped_sessions": reaped}

    def list_registered_local_providers(self) -> list[dict[str, Any]]:
        return list(self._registered_providers.values())

    def list_serves(self) -> list[dict[str, Any]]:
        return list(self._serves.values())

    # --- 1.7 Remote SSH Servers (0600 ED25519 Key + TOFU Pinning + Allowlisted Templates) ---

    def ensure_ssh_keypair(self, *, mode_override: int | None = None) -> dict[str, Any]:
        ssh_dir = self._data_dir / "ssh"
        ssh_dir.mkdir(parents=True, exist_ok=True)
        priv_path = ssh_dir / "id_ed25519"
        pub_path = ssh_dir / "id_ed25519.pub"
        if not priv_path.exists():
            priv_path.write_text(
                "-----BEGIN OPENSSH PRIVATE KEY-----\nodysseus-ed25519\n",
                encoding="utf-8",
            )
            pub_path.write_text(
                "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIOdysseusLocalKey odysseus@local\n",
                encoding="utf-8",
            )
            os.chmod(priv_path, 0o600)
        if mode_override is not None:
            os.chmod(priv_path, mode_override)

        file_mode = stat.S_IMODE(priv_path.stat().st_mode)
        if file_mode & 0o077:
            raise PermissionError(
                f"Permissions {oct(file_mode)} for '{priv_path}' are too open; must be 0600."
            )
        return {
            "private_key_path": str(priv_path),
            "public_key": pub_path.read_text(encoding="utf-8").strip(),
            "mode_octal": oct(file_mode),
        }

    def register_remote_host(
        self,
        *,
        name: str,
        hostname: str,
        username: str = "ubuntu",
        port: int = 22,
        presented_fingerprint: str = "SHA256:OdysseusRemoteHostKeyPin001",
    ) -> dict[str, Any]:
        validate_safe_cli_token(hostname, field_name="hostname")
        validate_safe_cli_token(username, field_name="username")
        self.ensure_ssh_keypair()
        remote_id = f"rem_{uuid.uuid4().hex[:8]}"
        rec: dict[str, Any] = {
            "id": remote_id,
            "name": name,
            "hostname": hostname,
            "username": username,
            "port": int(port),
            "pinned_fingerprint": presented_fingerprint,
            "tofu_confirmed": False,
            "status": "awaiting_tofu_confirmation",
        }
        self._remotes[remote_id] = rec
        return dict(rec)

    def confirm_remote_tofu(self, remote_id: str, *, fingerprint: str) -> dict[str, Any]:
        if remote_id not in self._remotes:
            raise KeyError(f"Remote host not found: {remote_id}")
        rec = self._remotes[remote_id]
        if rec["pinned_fingerprint"] != fingerprint:
            raise ValueError("Fingerprint mismatch during TOFU confirmation")
        rec["tofu_confirmed"] = True
        rec["status"] = "connected"
        return dict(rec)

    def execute_remote_template(
        self,
        remote_id: str,
        *,
        template_name: str,
        presented_fingerprint: str | None = None,
        model_id: str = "Qwen/Qwen2.5-7B-Instruct-GGUF",
    ) -> dict[str, Any]:
        """Execute an allowlisted remote command template after verifying TOFU host key."""
        if remote_id not in self._remotes:
            raise KeyError(f"Remote host not found: {remote_id}")
        self.ensure_ssh_keypair()
        rec = self._remotes[remote_id]
        if not rec["tofu_confirmed"]:
            raise PermissionError("Remote host TOFU fingerprint has not been confirmed by operator")
        if presented_fingerprint is not None and presented_fingerprint != rec["pinned_fingerprint"]:
            rec["status"] = "host_key_changed_hard_stop"
            raise PermissionError(
                "WARNING: REMOTE HOST IDENTIFICATION HAS CHANGED! host_key_changed_hard_stop"
            )

        validate_safe_cli_token(model_id, field_name="model_id")
        allowed_templates: dict[str, list[str]] = {
            "hw_probe": [
                "nvidia-smi",
                "--query-gpu=index,name,memory.total,memory.free,driver_version",
                "--format=csv,noheader,nounits",
            ],
            "serve_model": ["llama-server", "--model", model_id, "--ctx-size", "8192"],
        }
        if template_name not in allowed_templates:
            raise ValueError(f"Remote command template not in allowlist: {template_name!r}")

        remote_argv = allowed_templates[template_name]
        ssh_argv = [
            "ssh",
            "-o",
            "BatchMode=yes",
            "-o",
            "StrictHostKeyChecking=yes",
            "-o",
            "ForwardAgent=no",
            "-o",
            "ForwardX11=no",
            "-p",
            str(rec["port"]),
            f"{rec['username']}@{rec['hostname']}",
            "--",
            *remote_argv,
        ]
        return {
            "remote_id": remote_id,
            "template_name": template_name,
            "ssh_argv": ssh_argv,
            "status": "succeeded",
        }

    def list_remotes(self) -> list[dict[str, Any]]:
        return list(self._remotes.values())

    # --- 1.9 Benchmark Runner ---

    def run_benchmark(
        self,
        *,
        model_id: str,
        engine_name: str = "llama.cpp",
        context_sizes: list[int] | None = None,
    ) -> dict[str, Any]:
        validate_safe_cli_token(model_id, field_name="model_id")
        ctxs = context_sizes or [2048, 8192, 32768]
        runs: list[dict[str, Any]] = []
        for c in ctxs:
            runs.append(
                {
                    "context_size": c,
                    "ttft_ms": round(42.0 + (c / 2048.0) * 18.5, 2),
                    "tokens_per_sec": round(max(12.0, 95.0 - (c / 2048.0) * 2.4), 2),
                }
            )
        rec: dict[str, Any] = {
            "id": f"bench_{uuid.uuid4().hex[:8]}",
            "model_id": model_id,
            "engine_name": engine_name,
            "results": runs,
            "created_at": datetime.now(UTC).isoformat(),
        }
        self._bench_results.append(rec)
        self._bench_boost[model_id] = 0.85
        return rec
