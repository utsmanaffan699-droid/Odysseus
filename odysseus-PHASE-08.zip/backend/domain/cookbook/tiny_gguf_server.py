"""Real lightweight CPU OpenAI-compatible GGUF server for Cookbook serve lifecycle tests."""

from __future__ import annotations

import argparse
import json
import sys
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any


def create_minimal_gguf_file(target_path: Path) -> Path:
    """Write a valid minimal GGUF v3 header file for CPU serve verification."""
    target_path.parent.mkdir(parents=True, exist_ok=True)
    # GGUF magic ('GGUF') + version 3 (uint32 LE) + tensor_count 0 + kv_count 0
    header = b"GGUF" + (3).to_bytes(4, "little") + (0).to_bytes(8, "little") * 2
    target_path.write_bytes(header)
    return target_path


def verify_gguf_header(path: Path) -> bool:
    """Verify that `path` starts with a valid GGUF v3 magic header."""
    if not path.exists() or not path.is_file():
        return False
    raw = path.read_bytes()[:8]
    if len(raw) < 8 or raw[:4] != b"GGUF":
        return False
    version = int.from_bytes(raw[4:8], "little")
    return version in (2, 3)


class _TinyGgufHandler(BaseHTTPRequestHandler):
    model_id: str = "tiny-gguf-cpu"

    def log_message(self, format: str, *args: Any) -> None:
        # Suppress default stderr HTTP access noise
        return

    def do_GET(self) -> None:
        if self.path in ("/health", "/v1/models"):
            payload = {
                "status": "ok",
                "model": self.model_id,
                "data": [{"id": self.model_id, "object": "model"}],
            }
            body = json.dumps(payload).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        self.send_response(404)
        self.end_headers()

    def do_POST(self) -> None:
        if self.path.startswith("/v1/chat/completions"):
            length = int(self.headers.get("Content-Length", "0"))
            raw = self.rfile.read(length) if length > 0 else b"{}"
            try:
                req = json.loads(raw.decode("utf-8", errors="replace"))
            except ValueError:
                req = {}
            stream = bool(req.get("stream", False))
            if stream:
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream")
                self.send_header("Cache-Control", "no-cache")
                self.end_headers()
                for tok in ("Hello", " from", " tiny", " GGUF!"):
                    chunk = {
                        "id": "chatcmpl_tiny",
                        "object": "chat.completion.chunk",
                        "model": self.model_id,
                        "choices": [{"index": 0, "delta": {"content": tok}, "finish_reason": None}],
                    }
                    self.wfile.write(f"data: {json.dumps(chunk)}\n\n".encode())
                    self.wfile.flush()
                done_chunk = {
                    "id": "chatcmpl_tiny",
                    "object": "chat.completion.chunk",
                    "model": self.model_id,
                    "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}],
                }
                self.wfile.write(f"data: {json.dumps(done_chunk)}\n\ndata: [DONE]\n\n".encode())
                self.wfile.flush()
                return

            resp = {
                "id": "chatcmpl_tiny",
                "object": "chat.completion",
                "created": int(time.time()),
                "model": self.model_id,
                "choices": [
                    {
                        "index": 0,
                        "message": {"role": "assistant", "content": "Hello from tiny GGUF!"},
                        "finish_reason": "stop",
                    }
                ],
                "usage": {"prompt_tokens": 8, "completion_tokens": 5, "total_tokens": 13},
            }
            body = json.dumps(resp).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        self.send_response(404)
        self.end_headers()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Tiny CPU GGUF Server")
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--model", type=str, default="tiny-gguf-cpu")
    parser.add_argument("--gguf-path", type=str, default="")
    parser.add_argument("--crash-on-start", action="store_true")
    args = parser.parse_args(argv)

    if args.crash_on_start:
        sys.stderr.write("FATAL: simulated engine startup crash (exit code 1)\n")
        sys.stderr.flush()
        return 1

    if args.gguf_path:
        p = Path(args.gguf_path)
        if not verify_gguf_header(p):
            sys.stderr.write(f"FATAL: invalid magic: bad GGUF header in {p}\n")
            sys.stderr.flush()
            return 2

    _TinyGgufHandler.model_id = str(args.model)
    server = HTTPServer(("127.0.0.1", int(args.port)), _TinyGgufHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
