"""Chat domain package: message tree, PromptBuilder, attachments, FTS search, and ChatService."""

from backend.domain.chats.attachments import (
    AttachmentService,
    AttachmentValidationError,
    extract_attachment_content,
    scan_bytes_clamav,
    sniff_mime_type,
)
from backend.domain.chats.prompts import (
    BuiltPrompt,
    PromptBuilder,
    PromptSectionBudget,
    estimate_tokens,
    truncate_to_token_budget,
)
from backend.domain.chats.search import (
    build_highlighted_snippet,
    search_chats_and_messages,
)
from backend.domain.chats.service import (
    ChatService,
    generate_deterministic_title,
)
from backend.domain.chats.tree import (
    MessageNode,
    MessageTreeError,
    collect_subtree_ids,
    compute_active_path,
    find_default_leaf,
    next_branch_index,
    validate_tree_invariants,
)

__all__ = [
    "AttachmentService",
    "AttachmentValidationError",
    "BuiltPrompt",
    "ChatService",
    "MessageNode",
    "MessageTreeError",
    "PromptBuilder",
    "PromptSectionBudget",
    "build_highlighted_snippet",
    "collect_subtree_ids",
    "compute_active_path",
    "estimate_tokens",
    "extract_attachment_content",
    "find_default_leaf",
    "generate_deterministic_title",
    "next_branch_index",
    "scan_bytes_clamav",
    "search_chats_and_messages",
    "sniff_mime_type",
    "truncate_to_token_budget",
    "validate_tree_invariants",
]
