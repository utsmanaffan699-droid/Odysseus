"""Message tree data structures, invariants, and O(depth) active-path operations."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any


class MessageTreeError(ValueError):
    """Raised when a message tree operation violates tree invariants."""


@dataclass(slots=True)
class MessageNode:
    """Lightweight node representation of a message in a chat tree."""

    id: str
    chat_id: str
    parent_id: str | None
    branch_index: int
    role: str
    content: str
    status: str = "complete"
    model: str | None = None
    run_id: str | None = None
    parts_json: list[dict[str, Any]] = field(default_factory=list)
    attachment_ids_json: list[str] = field(default_factory=list)
    usage_json: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))


def compute_active_path(
    nodes: dict[str, MessageNode],
    active_leaf_id: str | None,
) -> list[MessageNode]:
    """Compute the root-to-leaf active path in O(depth) time via parent pointers."""
    if active_leaf_id is None or not nodes:
        return []
    if active_leaf_id not in nodes:
        raise MessageTreeError(f"Active leaf '{active_leaf_id}' does not exist in tree")

    path: list[MessageNode] = []
    visited: set[str] = set()
    curr_id: str | None = active_leaf_id

    while curr_id is not None:
        if curr_id in visited:
            raise MessageTreeError(f"Cycle detected in message tree at node '{curr_id}'")
        visited.add(curr_id)
        node = nodes.get(curr_id)
        if node is None:
            raise MessageTreeError(f"Orphan parent reference '{curr_id}' in message tree")
        path.append(node)
        curr_id = node.parent_id

    path.reverse()
    return path


def validate_tree_invariants(
    nodes: dict[str, MessageNode],
    active_leaf_id: str | None,
) -> None:
    """Verify tree invariants: no orphans, no cycles, unique sibling branch_index, active path."""
    if not nodes:
        if active_leaf_id is not None:
            raise MessageTreeError("Empty tree cannot have a non-null active_leaf_id")
        return

    sibling_keys: set[tuple[str | None, int]] = set()
    for node_id, node in nodes.items():
        if node.id != node_id:
            raise MessageTreeError(f"Node key '{node_id}' does not match node.id '{node.id}'")
        if node.parent_id is not None and node.parent_id not in nodes:
            raise MessageTreeError(
                f"Orphan node '{node_id}': parent '{node.parent_id}' not in tree"
            )
        sib_key = (node.parent_id, node.branch_index)
        if sib_key in sibling_keys:
            raise MessageTreeError(
                f"Duplicate branch_index {node.branch_index} under parent '{node.parent_id}'"
            )
        sibling_keys.add(sib_key)

    # Check cycle freedom for every node using memoized clean set
    verified_acyclic: set[str] = set()
    for start_id in nodes:
        if start_id in verified_acyclic:
            continue
        seen_in_walk: set[str] = set()
        curr: str | None = start_id
        while curr is not None:
            if curr in seen_in_walk:
                raise MessageTreeError(f"Cycle detected involving node '{curr}'")
            if curr in verified_acyclic:
                break
            seen_in_walk.add(curr)
            curr = nodes[curr].parent_id
        verified_acyclic.update(seen_in_walk)

    if active_leaf_id is not None:
        path = compute_active_path(nodes, active_leaf_id)
        if not path or path[0].parent_id is not None or path[-1].id != active_leaf_id:
            raise MessageTreeError("Invalid active path from root to active_leaf_id")


def next_branch_index(nodes: dict[str, MessageNode], parent_id: str | None) -> int:
    """Return the next monotonic branch_index for a new child of parent_id."""
    max_idx = -1
    for node in nodes.values():
        if node.parent_id == parent_id and node.branch_index > max_idx:
            max_idx = node.branch_index
    return max_idx + 1


def collect_subtree_ids(nodes: dict[str, MessageNode], root_id: str) -> set[str]:
    """Collect root_id and all of its descendants."""
    if root_id not in nodes:
        raise MessageTreeError(f"Subtree root '{root_id}' not found")
    children_map: dict[str, list[str]] = {}
    for node in nodes.values():
        if node.parent_id is not None:
            children_map.setdefault(node.parent_id, []).append(node.id)

    collected: set[str] = set()
    stack = [root_id]
    while stack:
        curr = stack.pop()
        if curr in collected:
            continue
        collected.add(curr)
        stack.extend(children_map.get(curr, []))
    return collected


def find_default_leaf(nodes: dict[str, MessageNode], start_id: str) -> str:
    """Walk down from start_id following the latest (highest branch_index) child to a leaf."""
    if start_id not in nodes:
        raise MessageTreeError(f"Node '{start_id}' not found")
    children_map: dict[str, list[MessageNode]] = {}
    for node in nodes.values():
        if node.parent_id is not None:
            children_map.setdefault(node.parent_id, []).append(node)

    curr = start_id
    visited: set[str] = set()
    while True:
        if curr in visited:
            raise MessageTreeError(f"Cycle detected while finding leaf from '{start_id}'")
        visited.add(curr)
        kids = children_map.get(curr)
        if not kids:
            return curr
        kids.sort(key=lambda n: (n.branch_index, n.created_at))
        curr = kids[-1].id
