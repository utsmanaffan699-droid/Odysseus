"""Deterministic PromptBuilder with per-section token budgets and token estimation utility."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from backend.providers.base import ProviderMessage

WORD_OR_PUNCT_RE = re.compile(r"\w+|[^\w\s]", re.UNICODE)


def estimate_tokens(text: str, model: str = "default") -> int:
    """Deterministic token count estimator across ASCII, CJK, emoji, and code."""
    _ = model
    if not text:
        return 0
    # Combine subword token count and UTF-8 byte-density heuristic
    words_and_punct = len(WORD_OR_PUNCT_RE.findall(text))
    utf8_len = len(text.encode("utf-8", errors="replace"))
    char_approx = max(1, (utf8_len + 3) // 4)
    return max(words_and_punct, char_approx)


def truncate_to_token_budget(
    text: str, budget_tokens: int, model: str = "default"
) -> tuple[str, bool]:
    """Deterministically truncate text to fit within budget_tokens."""
    if budget_tokens <= 0:
        return "", bool(text)
    current = estimate_tokens(text, model)
    if current <= budget_tokens:
        return text, False
    # Approximate character cap (~3.5 chars per token) and refine downward
    approx_chars = max(1, int(budget_tokens * 3.5))
    candidate = text[:approx_chars]
    while candidate and estimate_tokens(candidate, model) > budget_tokens:
        step = max(1, len(candidate) // 10)
        candidate = candidate[:-step]
    return candidate.rstrip() + "…", True


@dataclass(frozen=True, slots=True)
class PromptSectionBudget:
    """Per-section token budgets for PromptBuilder."""

    system_tokens: int = 1024
    project_tokens: int = 2048
    summary_tokens: int = 1024
    attachments_tokens: int = 4096
    history_tokens: int = 16384


@dataclass(slots=True)
class BuiltPrompt:
    """Output of PromptBuilder with deterministic messages and token breakdown."""

    messages: list[ProviderMessage]
    section_tokens: dict[str, int] = field(default_factory=dict)
    truncated_sections: list[str] = field(default_factory=list)
    total_tokens: int = 0


class PromptBuilder:
    """Deterministic prompt compiler enforcing section ordering and token budgets.

    Section order inside the compiled system block:
    1. Base System Instructions (`[SYSTEM INSTRUCTIONS]`)
    2. Project Instructions (`[PROJECT INSTRUCTIONS: <name>]`)
    3. Conversation Summary (`[CONVERSATION SUMMARY]`)
    4. Attachment Context (`[ATTACHMENTS]`)
    Followed by the chronologically ordered active message history within `history_tokens`.
    """

    def __init__(self, budgets: PromptSectionBudget | None = None) -> None:
        self.budgets = budgets or PromptSectionBudget()

    def build(
        self,
        *,
        base_system_prompt: str = "You are Odysseus, a helpful and precise AI assistant.",
        project_name: str | None = None,
        project_instructions: str | None = None,
        chat_summary: str | None = None,
        attachments: list[dict[str, Any]] | None = None,
        history: list[dict[str, Any]] | None = None,
        model: str = "default",
    ) -> BuiltPrompt:
        section_tokens: dict[str, int] = {
            "system": 0,
            "project": 0,
            "summary": 0,
            "attachments": 0,
            "history": 0,
        }
        truncated: list[str] = []
        system_blocks: list[str] = []

        # 1. Base system prompt
        if base_system_prompt.strip():
            sys_txt, was_trunc = truncate_to_token_budget(
                base_system_prompt.strip(), self.budgets.system_tokens
            )
            if was_trunc:
                truncated.append("system")
            section_tokens["system"] = estimate_tokens(sys_txt, model)
            system_blocks.append(f"[SYSTEM INSTRUCTIONS]\n{sys_txt}")

        # 2. Project instructions
        if project_instructions and project_instructions.strip():
            proj_header = f"[PROJECT INSTRUCTIONS: {project_name or 'Project'}]"
            proj_txt, was_trunc = truncate_to_token_budget(
                project_instructions.strip(), self.budgets.project_tokens
            )
            if was_trunc:
                truncated.append("project")
            section_tokens["project"] = estimate_tokens(proj_txt, model)
            system_blocks.append(f"{proj_header}\n{proj_txt}")

        # 3. Conversation summary
        if chat_summary and chat_summary.strip():
            sum_txt, was_trunc = truncate_to_token_budget(
                chat_summary.strip(), self.budgets.summary_tokens
            )
            if was_trunc:
                truncated.append("summary")
            section_tokens["summary"] = estimate_tokens(sum_txt, model)
            system_blocks.append(f"[CONVERSATION SUMMARY]\n{sum_txt}")

        # 4. Attachments (sorted deterministically by sha256 then filename)
        if attachments:
            sorted_atts = sorted(
                attachments,
                key=lambda a: (str(a.get("sha256", "")), str(a.get("filename", ""))),
            )
            att_lines: list[str] = []
            for att in sorted_atts:
                fname = str(att.get("filename", "attachment"))
                mime = str(att.get("mime_type", "application/octet-stream"))
                ext_text = str(att.get("extracted_text") or "").strip()
                if ext_text:
                    att_lines.append(f"--- Attachment: {fname} ({mime}) ---\n{ext_text}")
                else:
                    att_lines.append(f"--- Attachment: {fname} ({mime}) [binary] ---")
            joined_att = "\n\n".join(att_lines)
            att_txt, was_trunc = truncate_to_token_budget(
                joined_att, self.budgets.attachments_tokens
            )
            if was_trunc:
                truncated.append("attachments")
            section_tokens["attachments"] = estimate_tokens(att_txt, model)
            system_blocks.append(f"[ATTACHMENTS]\n{att_txt}")

        compiled_messages: list[ProviderMessage] = []
        if system_blocks:
            compiled_messages.append(
                ProviderMessage(role="system", content="\n\n".join(system_blocks))
            )

        # 5. Active history (preserve newest messages fitting in history_tokens)
        hist_list = history or []
        selected_history: list[ProviderMessage] = []
        used_hist_tokens = 0
        hist_truncated = False

        for idx in range(len(hist_list) - 1, -1, -1):
            item = hist_list[idx]
            role_raw = str(item.get("role", "user"))
            role = role_raw if role_raw in ("system", "user", "assistant", "tool") else "user"
            content = str(item.get("content", ""))
            msg_tokens = estimate_tokens(content, model) + 4

            if idx == len(hist_list) - 1 and msg_tokens > self.budgets.history_tokens:
                content, _ = truncate_to_token_budget(content, self.budgets.history_tokens)
                msg_tokens = estimate_tokens(content, model) + 4
                hist_truncated = True

            if used_hist_tokens + msg_tokens > self.budgets.history_tokens and selected_history:
                hist_truncated = True
                break

            used_hist_tokens += msg_tokens
            selected_history.append(
                ProviderMessage(
                    role=role,  # type: ignore[arg-type]
                    content=content,
                    tool_call_id=item.get("tool_call_id"),
                    tool_calls=item.get("tool_calls") or [],
                )
            )

        selected_history.reverse()
        if hist_truncated:
            truncated.append("history")
        section_tokens["history"] = used_hist_tokens
        compiled_messages.extend(selected_history)

        total_tok = sum(section_tokens.values())
        return BuiltPrompt(
            messages=compiled_messages,
            section_tokens=section_tokens,
            truncated_sections=truncated,
            total_tokens=total_tok,
        )
