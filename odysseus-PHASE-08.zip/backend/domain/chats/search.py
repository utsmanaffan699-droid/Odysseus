"""Full-text search across chats and messages (SQLite FTS5 / Postgres tsvector + snippets)."""

from __future__ import annotations

import re
from typing import Any

from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.models import ChatRecord, MessageRecord


def build_highlighted_snippet(
    content: str,
    query: str,
    *,
    context_chars: int = 80,
) -> str:
    """Extract a contextual snippet around matching terms and wrap hits in <mark>...</mark>."""
    if not content:
        return ""
    terms = [t for t in re.findall(r"\w+", query, flags=re.UNICODE) if t]
    if not terms:
        return content[: context_chars * 2]

    pattern = re.compile(
        "(" + "|".join(re.escape(t) for t in sorted(set(terms), key=len, reverse=True)) + ")",
        flags=re.IGNORECASE | re.UNICODE,
    )
    match = pattern.search(content)
    if match is None:
        return content[: context_chars * 2]

    start = max(0, match.start() - context_chars)
    end = min(len(content), match.end() + context_chars)
    window = content[start:end]
    prefix = "…" if start > 0 else ""
    suffix = "…" if end < len(content) else ""
    highlighted = pattern.sub(r"<mark>\1</mark>", window)
    return f"{prefix}{highlighted}{suffix}"


async def ensure_fts_index(session: AsyncSession) -> None:
    """Ensure SQLite FTS5 virtual table exists and is populated if running on SQLite."""
    bind = session.get_bind()
    dialect = bind.dialect.name
    if dialect != "sqlite":
        return
    await session.execute(
        text(
            "CREATE VIRTUAL TABLE IF NOT EXISTS messages_fts USING fts5("
            "message_id UNINDEXED, chat_id UNINDEXED, content"
            ")"
        )
    )


async def index_message_fts(
    session: AsyncSession,
    *,
    message_id: str,
    chat_id: str,
    content: str,
) -> None:
    """Index a single message into SQLite FTS5 when running on SQLite."""
    bind = session.get_bind()
    if bind.dialect.name != "sqlite":
        return
    await ensure_fts_index(session)
    await session.execute(
        text("DELETE FROM messages_fts WHERE message_id = :mid"),
        {"mid": message_id},
    )
    await session.execute(
        text(
            "INSERT INTO messages_fts (message_id, chat_id, content) VALUES (:mid, :cid, :content)"
        ),
        {"mid": message_id, "cid": chat_id, "content": content},
    )


async def search_chats_and_messages(
    session: AsyncSession,
    *,
    user_id: str,
    query: str,
    limit: int = 20,
) -> list[dict[str, Any]]:
    """Search user's chats and messages using FTS5 (SQLite) or tsvector (Postgres) with fallback."""
    clean_q = query.strip()
    if not clean_q:
        return []

    bind = session.get_bind()
    dialect = bind.dialect.name
    results: list[dict[str, Any]] = []
    seen_keys: set[tuple[str, str | None]] = set()

    terms = [t for t in re.findall(r"\w+", clean_q, flags=re.UNICODE) if t]

    if dialect == "sqlite" and terms:
        await ensure_fts_index(session)
        fts_query = " OR ".join(f'"{t}"' for t in terms)
        stmt_fts = text(
            "SELECT m.id, m.chat_id, m.role, m.plain_text, c.title "
            "FROM messages_fts f "
            "JOIN messages m ON m.id = f.message_id "
            "JOIN chats c ON c.id = m.chat_id "
            "WHERE c.user_id = :uid AND messages_fts MATCH :q "
            "LIMIT :lim"
        )
        rows = (
            await session.execute(stmt_fts, {"uid": user_id, "q": fts_query, "lim": limit})
        ).fetchall()
        for row in rows:
            mid, cid, role, content, title = row
            key = (str(cid), str(mid))
            if key not in seen_keys:
                seen_keys.add(key)
                results.append(
                    {
                        "chat_id": str(cid),
                        "chat_title": str(title),
                        "message_id": str(mid),
                        "role": str(role),
                        "snippet": build_highlighted_snippet(str(content), clean_q),
                    }
                )

    elif dialect == "postgresql" and terms:
        ts_query = " | ".join(terms)
        stmt_pg = text(
            "SELECT m.id, m.chat_id, m.role, m.plain_text, c.title "
            "FROM messages m "
            "JOIN chats c ON c.id = m.chat_id "
            "WHERE c.user_id = :uid "
            "AND to_tsvector('simple', coalesce(m.plain_text, '') || ' ' || coalesce(c.title, '')) "
            "@@ to_tsquery('simple', :q) "
            "ORDER BY m.created_at DESC LIMIT :lim"
        )
        rows = (
            await session.execute(stmt_pg, {"uid": user_id, "q": ts_query, "lim": limit})
        ).fetchall()
        for row in rows:
            mid, cid, role, content, title = row
            key = (str(cid), str(mid))
            if key not in seen_keys:
                seen_keys.add(key)
                results.append(
                    {
                        "chat_id": str(cid),
                        "chat_title": str(title),
                        "message_id": str(mid),
                        "role": str(role),
                        "snippet": build_highlighted_snippet(str(content), clean_q),
                    }
                )

    # Also match chat titles or any unindexed messages via case-insensitive substring match
    if len(results) < limit:
        pattern = f"%{clean_q}%"
        msg_stmt = (
            select(MessageRecord, ChatRecord.title)
            .join(ChatRecord, ChatRecord.id == MessageRecord.chat_id)
            .where(
                ChatRecord.user_id == user_id,
                (MessageRecord.plain_text.ilike(pattern)) | (ChatRecord.title.ilike(pattern)),
            )
            .order_by(MessageRecord.created_at.desc())
            .limit(limit)
        )
        for msg_rec, chat_title in (await session.execute(msg_stmt)).all():
            key = (msg_rec.chat_id, msg_rec.id)
            if key not in seen_keys:
                seen_keys.add(key)
                source_txt = (
                    msg_rec.plain_text
                    if clean_q.lower() in msg_rec.plain_text.lower()
                    else f"{chat_title}: {msg_rec.plain_text}"
                )
                results.append(
                    {
                        "chat_id": msg_rec.chat_id,
                        "chat_title": str(chat_title),
                        "message_id": msg_rec.id,
                        "role": msg_rec.role,
                        "snippet": build_highlighted_snippet(source_txt, clean_q),
                    }
                )
            if len(results) >= limit:
                break

    return results
