"""Chat & Project service: message tree CRUD, branching, fork, title gen, and auto-summary."""

from __future__ import annotations

import asyncio
import contextlib
import re
import uuid
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import delete, insert
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.db import DatabaseManager
from backend.core.logging import get_logger
from backend.core.models import ChatRecord, MessageRecord, ProjectRecord
from backend.core.uow import UnitOfWork, _ensure_utc
from backend.domain.chats.search import index_message_fts
from backend.domain.chats.tree import (
    MessageNode,
    MessageTreeError,
    collect_subtree_ids,
    compute_active_path,
    find_default_leaf,
    next_branch_index,
    validate_tree_invariants,
)

logger = get_logger("odysseus.chats")


def _extract_attachment_ids(parts: list[dict[str, Any]]) -> list[str]:
    out: list[str] = []
    for p in parts:
        if p.get("type") == "attachment" and isinstance(p.get("sha256"), str):
            out.append(p["sha256"])
    return out


def _record_to_node(rec: MessageRecord) -> MessageNode:
    parts = list(rec.parts_json or [])
    usage = rec.usage_json or {}
    run_id = usage.get("run_id") if isinstance(usage, dict) else None
    return MessageNode(
        id=rec.id,
        chat_id=rec.chat_id,
        parent_id=rec.parent_id,
        branch_index=rec.branch_index,
        role=rec.role,
        content=rec.plain_text,
        status=rec.status,
        model=rec.model,
        run_id=str(run_id) if isinstance(run_id, str) else None,
        parts_json=parts,
        attachment_ids_json=_extract_attachment_ids(parts),
        usage_json=dict(usage) if isinstance(usage, dict) else {},
        created_at=_ensure_utc(rec.created_at),
    )


def _node_to_dict(node: MessageNode) -> dict[str, Any]:
    return {
        "id": node.id,
        "chat_id": node.chat_id,
        "parent_id": node.parent_id,
        "branch_index": node.branch_index,
        "role": node.role,
        "content": node.content,
        "status": node.status,
        "model": node.model,
        "run_id": node.run_id,
        "parts": node.parts_json,
        "attachment_ids": node.attachment_ids_json,
        "usage": node.usage_json,
        "created_at": node.created_at.isoformat(),
    }


def _chat_to_dict(chat: ChatRecord) -> dict[str, Any]:
    return {
        "id": chat.id,
        "user_id": chat.user_id,
        "project_id": chat.project_id,
        "title": chat.title,
        "model": chat.model,
        "system_prompt": chat.folder,
        "active_leaf_id": chat.active_leaf_id,
        "summary_text": chat.summary_text,
        "pinned": chat.pinned,
        "archived": chat.archived,
        "temporary": chat.temporary,
        "created_at": _ensure_utc(chat.created_at).isoformat(),
        "updated_at": _ensure_utc(chat.updated_at).isoformat(),
    }


def generate_deterministic_title(prompt_text: str) -> str:
    """Produce a clean, concise chat title (≤ 60 chars) from the first user prompt."""
    cleaned = re.sub(r"\s+", " ", prompt_text).strip()
    if not cleaned:
        return "New Chat"
    words = cleaned.split(" ")[:8]
    candidate = " ".join(words).rstrip(".,;:!?")
    if len(candidate) > 60:
        candidate = candidate[:57].rstrip() + "…"
    return candidate


class ChatService:
    """Domain service for chats, projects, message trees, title generation, and auto-summaries."""

    def __init__(
        self,
        db: DatabaseManager,
        *,
        auto_summary_threshold: int = 8,
    ) -> None:
        self.db = db
        self.auto_summary_threshold = auto_summary_threshold
        self._title_tasks: dict[str, asyncio.Task[None]] = {}

    async def shutdown(self) -> None:
        for task in list(self._title_tasks.values()):
            task.cancel()
        for task in list(self._title_tasks.values()):
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await task
        self._title_tasks.clear()

    def cancel_title_generation(self, chat_id: str) -> bool:
        task = self._title_tasks.pop(chat_id, None)
        if task is not None and not task.done():
            task.cancel()
            return True
        return False

    def schedule_title_generation(self, chat_id: str, first_user_text: str) -> asyncio.Task[None]:
        """Schedule a non-blocking, cancellable background title generator for chat_id."""
        self.cancel_title_generation(chat_id)

        async def _worker() -> None:
            try:
                await asyncio.sleep(0.01)
                new_title = generate_deterministic_title(first_user_text)

                async def _upd(sess: AsyncSession) -> None:
                    uow = UnitOfWork(sess)
                    chat = await uow.chats.get_chat(chat_id)
                    if chat is not None and chat.title in ("New Chat", "Untitled Chat", ""):
                        chat.title = new_title
                        chat.updated_at = datetime.now(UTC)

                await self.db.execute_write(_upd)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                logger.warning("title_generation_failed", chat_id=chat_id, error=str(exc))
            finally:
                self._title_tasks.pop(chat_id, None)

        task = asyncio.create_task(_worker(), name=f"title_gen:{chat_id}")
        self._title_tasks[chat_id] = task
        return task

    async def maybe_update_chat_summary(self, chat_id: str) -> str | None:
        """Compute and persist a rolling conversation summary if active path exceeds threshold."""

        async def _tx(sess: AsyncSession) -> str | None:
            uow = UnitOfWork(sess)
            chat = await uow.chats.get_chat(chat_id)
            if chat is None or chat.active_leaf_id is None:
                return None
            rows = await uow.chats.list_messages(chat_id)
            nodes = {r.id: _record_to_node(r) for r in rows}
            active_path = compute_active_path(nodes, chat.active_leaf_id)
            if len(active_path) < self.auto_summary_threshold:
                return chat.summary_text
            if chat.summary_text is not None and len(active_path) % 8 != 0:
                return chat.summary_text

            # Summarize all messages except the last 4 active messages
            older = active_path[:-4]
            if not older:
                return chat.summary_text

            bullet_lines: list[str] = []
            for m in older[-10:]:
                snippet = re.sub(r"\s+", " ", m.content).strip()[:120]
                bullet_lines.append(f"- {m.role}: {snippet}")
            summary = "Earlier conversation summary:\n" + "\n".join(bullet_lines)
            chat.summary_text = summary
            chat.updated_at = datetime.now(UTC)
            return summary

        return await self.db.execute_write(_tx)

    async def create_chat(
        self,
        *,
        user_id: str,
        title: str = "New Chat",
        model: str = "fake/default",
        project_id: str | None = None,
        system_prompt: str | None = None,
    ) -> dict[str, Any]:
        now = datetime.now(UTC)
        chat_id = f"chat_{uuid.uuid4().hex[:20]}"

        async def _tx(sess: AsyncSession) -> dict[str, Any]:
            uow = UnitOfWork(sess)
            if project_id is not None:
                proj = await uow.projects.get(project_id)
                if proj is None or proj.user_id != user_id:
                    raise MessageTreeError(f"Project '{project_id}' not found")
            chat = ChatRecord(
                id=chat_id,
                user_id=user_id,
                project_id=project_id,
                title=title or "New Chat",
                model=model,
                folder=system_prompt,
                active_leaf_id=None,
                created_at=now,
                updated_at=now,
            )
            await uow.chats.create_chat(chat)
            return _chat_to_dict(chat)

        return await self.db.execute_write(_tx)

    async def get_chat_detail(self, *, chat_id: str, user_id: str) -> dict[str, Any] | None:
        async def _tx(sess: AsyncSession) -> dict[str, Any] | None:
            uow = UnitOfWork(sess)
            chat = await uow.chats.get_chat(chat_id)
            if chat is None or chat.user_id != user_id:
                return None
            rows = await uow.chats.list_messages(chat_id)
            nodes = {r.id: _record_to_node(r) for r in rows}
            active_path = (
                compute_active_path(nodes, chat.active_leaf_id)
                if chat.active_leaf_id and chat.active_leaf_id in nodes
                else []
            )
            out = _chat_to_dict(chat)
            out["messages"] = [_node_to_dict(n) for n in active_path]
            out["all_messages"] = [_node_to_dict(_record_to_node(r)) for r in rows]
            return out

        return await self.db.execute_read(_tx)

    async def list_chats(
        self,
        *,
        user_id: str,
        project_id: str | None = None,
        include_archived: bool = False,
    ) -> list[dict[str, Any]]:
        async def _tx(sess: AsyncSession) -> list[dict[str, Any]]:
            uow = UnitOfWork(sess)
            rows = await uow.chats.list_chats(
                user_id, project_id=project_id, include_archived=include_archived
            )
            return [_chat_to_dict(r) for r in rows]

        return await self.db.execute_read(_tx)

    async def update_chat(
        self,
        *,
        chat_id: str,
        user_id: str,
        title: str | None = None,
        model: str | None = None,
        system_prompt: str | None = None,
        project_id: str | None = None,
        pinned: bool | None = None,
        archived: bool | None = None,
    ) -> dict[str, Any] | None:
        async def _tx(sess: AsyncSession) -> dict[str, Any] | None:
            uow = UnitOfWork(sess)
            chat = await uow.chats.get_chat(chat_id)
            if chat is None or chat.user_id != user_id:
                return None
            if title is not None:
                self.cancel_title_generation(chat_id)
                chat.title = title
            if model is not None:
                chat.model = model
            if system_prompt is not None:
                chat.folder = system_prompt
            if project_id is not None:
                chat.project_id = project_id or None
            if pinned is not None:
                chat.pinned = pinned
            if archived is not None:
                chat.archived = archived
            chat.updated_at = datetime.now(UTC)
            return _chat_to_dict(chat)

        return await self.db.execute_write(_tx)

    async def delete_chat(self, *, chat_id: str, user_id: str) -> bool:
        self.cancel_title_generation(chat_id)

        async def _tx(sess: AsyncSession) -> bool:
            uow = UnitOfWork(sess)
            chat = await uow.chats.get_chat(chat_id)
            if chat is None or chat.user_id != user_id:
                return False
            await uow.chats.delete_chat(chat)
            return True

        return await self.db.execute_write(_tx)

    async def append_message(
        self,
        *,
        chat_id: str,
        user_id: str,
        role: str,
        content: str,
        parent_id: str | None = "__active_leaf__",
        status: str = "complete",
        model: str | None = None,
        run_id: str | None = None,
        parts: list[dict[str, Any]] | None = None,
        attachment_ids: list[str] | None = None,
        message_id: str | None = None,
    ) -> dict[str, Any]:
        """Append a message to the tree and update active_leaf_id."""
        now = datetime.now(UTC)
        msg_id = message_id or f"msg_{uuid.uuid4().hex[:20]}"

        async def _tx(sess: AsyncSession) -> tuple[dict[str, Any], bool]:
            uow = UnitOfWork(sess)
            chat = await uow.chats.get_chat(chat_id)
            if chat is None or chat.user_id != user_id:
                raise MessageTreeError(f"Chat '{chat_id}' not found")

            rows = await uow.chats.list_messages(chat_id)
            nodes = {r.id: _record_to_node(r) for r in rows}

            effective_parent = chat.active_leaf_id if parent_id == "__active_leaf__" else parent_id
            if effective_parent is not None and effective_parent not in nodes:
                raise MessageTreeError(f"Parent message '{effective_parent}' not found in chat")

            b_idx = next_branch_index(nodes, effective_parent)
            compiled_parts: list[dict[str, Any]] = list(
                parts or ([{"type": "text", "text": content}] if content else [])
            )
            for sha in attachment_ids or []:
                compiled_parts.append({"type": "attachment", "sha256": sha})
            usage_payload = {"run_id": run_id} if run_id else None
            rec = MessageRecord(
                id=msg_id,
                chat_id=chat_id,
                parent_id=effective_parent,
                branch_index=b_idx,
                role=role,
                plain_text=content,
                parts_json=compiled_parts,
                usage_json=usage_payload,
                status=status,
                model=model,
                created_at=now,
            )
            await uow.chats.add_message(rec)
            await index_message_fts(sess, message_id=rec.id, chat_id=chat_id, content=content)

            nodes[rec.id] = _record_to_node(rec)
            chat.active_leaf_id = rec.id
            chat.updated_at = now
            validate_tree_invariants(nodes, chat.active_leaf_id)

            is_first_user = len(nodes) == 1 and role == "user"
            return _node_to_dict(nodes[rec.id]), is_first_user

        msg_dict, is_first_user = await self.db.execute_write(_tx)
        if is_first_user and content.strip():
            self.schedule_title_generation(chat_id, content)
        return msg_dict

    async def edit_user_message(
        self,
        *,
        chat_id: str,
        user_id: str,
        message_id: str,
        new_content: str,
        attachment_ids: list[str] | None = None,
    ) -> dict[str, Any]:
        """Create a sibling user message with incremented branch_index and set as active_leaf_id."""

        async def _load_parent(sess: AsyncSession) -> tuple[str | None, list[str]]:
            uow = UnitOfWork(sess)
            chat = await uow.chats.get_chat(chat_id)
            if chat is None or chat.user_id != user_id:
                raise MessageTreeError(f"Chat '{chat_id}' not found")
            orig = await uow.chats.get_message(message_id)
            if orig is None or orig.chat_id != chat_id:
                raise MessageTreeError(f"Message '{message_id}' not found in chat")
            if orig.role != "user":
                raise MessageTreeError("Only user messages can be edited and resubmitted")
            atts = (
                attachment_ids
                if attachment_ids is not None
                else _extract_attachment_ids(list(orig.parts_json or []))
            )
            return orig.parent_id, atts

        parent_id, atts = await self.db.execute_read(_load_parent)
        return await self.append_message(
            chat_id=chat_id,
            user_id=user_id,
            role="user",
            content=new_content,
            parent_id=parent_id,
            attachment_ids=atts,
        )

    async def resolve_regenerate_parent(
        self,
        *,
        chat_id: str,
        user_id: str,
        assistant_message_id: str,
    ) -> str:
        """Validate an assistant message for regeneration and move active_leaf_id to its parent."""

        async def _tx(sess: AsyncSession) -> str:
            uow = UnitOfWork(sess)
            chat = await uow.chats.get_chat(chat_id)
            if chat is None or chat.user_id != user_id:
                raise MessageTreeError(f"Chat '{chat_id}' not found")
            target = await uow.chats.get_message(assistant_message_id)
            if target is None or target.chat_id != chat_id:
                raise MessageTreeError(f"Message '{assistant_message_id}' not found")
            if target.role != "assistant" or target.parent_id is None:
                raise MessageTreeError(
                    "Regenerate requires an assistant message with a user parent"
                )
            chat.active_leaf_id = target.parent_id
            chat.updated_at = datetime.now(UTC)
            return target.parent_id

        return await self.db.execute_write(_tx)

    async def activate_branch(
        self,
        *,
        chat_id: str,
        user_id: str,
        message_id: str,
    ) -> dict[str, Any]:
        """Move active_leaf_id to the default leaf descending from message_id."""

        async def _tx(sess: AsyncSession) -> dict[str, Any]:
            uow = UnitOfWork(sess)
            chat = await uow.chats.get_chat(chat_id)
            if chat is None or chat.user_id != user_id:
                raise MessageTreeError(f"Chat '{chat_id}' not found")
            rows = await uow.chats.list_messages(chat_id)
            nodes = {r.id: _record_to_node(r) for r in rows}
            new_leaf = find_default_leaf(nodes, message_id)
            chat.active_leaf_id = new_leaf
            chat.updated_at = datetime.now(UTC)
            validate_tree_invariants(nodes, chat.active_leaf_id)
            active_path = compute_active_path(nodes, chat.active_leaf_id)
            return {
                "id": chat_id,
                "chat_id": chat_id,
                "title": chat.title,
                "model": chat.model,
                "active_leaf_id": new_leaf,
                "messages": [_node_to_dict(n) for n in active_path],
                "all_messages": [_node_to_dict(nodes[r.id]) for r in rows],
            }

        return await self.db.execute_write(_tx)

    async def delete_subtree(
        self,
        *,
        chat_id: str,
        user_id: str,
        message_id: str,
    ) -> dict[str, Any]:
        """Delete message_id and all its descendants, adjusting active_leaf_id safely."""

        async def _tx(sess: AsyncSession) -> dict[str, Any]:
            uow = UnitOfWork(sess)
            chat = await uow.chats.get_chat(chat_id)
            if chat is None or chat.user_id != user_id:
                raise MessageTreeError(f"Chat '{chat_id}' not found")
            rows = await uow.chats.list_messages(chat_id)
            nodes = {r.id: _record_to_node(r) for r in rows}
            if message_id not in nodes:
                raise MessageTreeError(f"Message '{message_id}' not found")

            target_parent = nodes[message_id].parent_id
            to_delete = collect_subtree_ids(nodes, message_id)

            await sess.execute(
                delete(MessageRecord).where(
                    MessageRecord.chat_id == chat_id,
                    MessageRecord.id.in_(list(to_delete)),
                )
            )
            for did in to_delete:
                nodes.pop(did, None)

            if chat.active_leaf_id in to_delete:
                if target_parent is not None and target_parent in nodes:
                    chat.active_leaf_id = find_default_leaf(nodes, target_parent)
                elif nodes:
                    roots = [n for n in nodes.values() if n.parent_id is None]
                    roots.sort(key=lambda n: (n.branch_index, n.created_at))
                    chat.active_leaf_id = find_default_leaf(nodes, roots[-1].id)
                else:
                    chat.active_leaf_id = None

            chat.updated_at = datetime.now(UTC)
            validate_tree_invariants(nodes, chat.active_leaf_id)
            return {
                "deleted_ids": sorted(to_delete),
                "active_leaf_id": chat.active_leaf_id,
            }

        return await self.db.execute_write(_tx)

    async def fork_chat(
        self,
        *,
        chat_id: str,
        user_id: str,
        up_to_message_id: str,
        title: str | None = None,
    ) -> dict[str, Any]:
        """Fork a chat from root up to up_to_message_id into a new chat."""
        now = datetime.now(UTC)
        new_chat_id = f"chat_{uuid.uuid4().hex[:20]}"

        async def _tx(sess: AsyncSession) -> dict[str, Any]:
            uow = UnitOfWork(sess)
            orig_chat = await uow.chats.get_chat(chat_id)
            if orig_chat is None or orig_chat.user_id != user_id:
                raise MessageTreeError(f"Chat '{chat_id}' not found")
            rows = await uow.chats.list_messages(chat_id)
            nodes = {r.id: _record_to_node(r) for r in rows}
            path = compute_active_path(nodes, up_to_message_id)

            fork_title = title or f"{orig_chat.title} (Fork)"
            new_chat = ChatRecord(
                id=new_chat_id,
                user_id=user_id,
                project_id=orig_chat.project_id,
                title=fork_title,
                model=orig_chat.model,
                folder=orig_chat.folder,
                active_leaf_id=None,
                created_at=now,
                updated_at=now,
            )
            await uow.chats.create_chat(new_chat)

            prev_new_id: str | None = None
            for node in path:
                cloned_id = f"msg_{uuid.uuid4().hex[:20]}"
                rec = MessageRecord(
                    id=cloned_id,
                    chat_id=new_chat_id,
                    parent_id=prev_new_id,
                    branch_index=0,
                    role=node.role,
                    plain_text=node.content,
                    parts_json=list(node.parts_json),
                    status=node.status,
                    model=node.model,
                    created_at=now,
                )
                await uow.chats.add_message(rec)
                await index_message_fts(
                    sess, message_id=cloned_id, chat_id=new_chat_id, content=node.content
                )
                prev_new_id = cloned_id

            new_chat.active_leaf_id = prev_new_id
            out = _chat_to_dict(new_chat)
            out["forked_from_chat_id"] = chat_id
            out["forked_from_message_id"] = up_to_message_id
            out["message_count"] = len(path)
            return out

        return await self.db.execute_write(_tx)

    # --- Projects CRUD ---

    async def create_project(
        self,
        *,
        user_id: str,
        name: str,
        description: str = "",
        instructions: str = "",
        token_budget: int = 2048,
    ) -> dict[str, Any]:
        now = datetime.now(UTC)
        proj_id = f"proj_{uuid.uuid4().hex[:16]}"

        async def _tx(sess: AsyncSession) -> dict[str, Any]:
            uow = UnitOfWork(sess)
            proj = ProjectRecord(
                id=proj_id,
                user_id=user_id,
                name=name,
                description=description,
                instructions=instructions,
                sources_json=[{"type": "budget", "token_budget": token_budget}],
                created_at=now,
                updated_at=now,
            )
            await uow.projects.add(proj)
            return {
                "id": proj.id,
                "user_id": proj.user_id,
                "name": proj.name,
                "description": proj.description,
                "instructions": proj.instructions,
                "token_budget": token_budget,
                "created_at": _ensure_utc(proj.created_at).isoformat(),
                "updated_at": _ensure_utc(proj.updated_at).isoformat(),
            }

        return await self.db.execute_write(_tx)

    async def list_projects(self, *, user_id: str) -> list[dict[str, Any]]:
        async def _tx(sess: AsyncSession) -> list[dict[str, Any]]:
            uow = UnitOfWork(sess)
            rows = await uow.projects.list_for_user(user_id)
            out: list[dict[str, Any]] = []
            for p in rows:
                budget = 2048
                for s in p.sources_json or []:
                    if isinstance(s, dict) and s.get("type") == "budget":
                        budget = int(s.get("token_budget", 2048))
                out.append(
                    {
                        "id": p.id,
                        "user_id": p.user_id,
                        "name": p.name,
                        "description": p.description,
                        "instructions": p.instructions,
                        "token_budget": budget,
                        "created_at": _ensure_utc(p.created_at).isoformat(),
                        "updated_at": _ensure_utc(p.updated_at).isoformat(),
                    }
                )
            return out

        return await self.db.execute_read(_tx)

    async def update_project(
        self,
        *,
        project_id: str,
        user_id: str,
        name: str | None = None,
        description: str | None = None,
        instructions: str | None = None,
        token_budget: int | None = None,
    ) -> dict[str, Any] | None:
        async def _tx(sess: AsyncSession) -> dict[str, Any] | None:
            uow = UnitOfWork(sess)
            proj = await uow.projects.get(project_id)
            if proj is None or proj.user_id != user_id:
                return None
            if name is not None:
                proj.name = name
            if description is not None:
                proj.description = description
            if instructions is not None:
                proj.instructions = instructions
            budget = 2048
            for s in proj.sources_json or []:
                if isinstance(s, dict) and s.get("type") == "budget":
                    budget = int(s.get("token_budget", 2048))
            if token_budget is not None:
                budget = token_budget
                proj.sources_json = [{"type": "budget", "token_budget": budget}]
            proj.updated_at = datetime.now(UTC)
            return {
                "id": proj.id,
                "user_id": proj.user_id,
                "name": proj.name,
                "description": proj.description,
                "instructions": proj.instructions,
                "token_budget": budget,
                "created_at": _ensure_utc(proj.created_at).isoformat(),
                "updated_at": _ensure_utc(proj.updated_at).isoformat(),
            }

        return await self.db.execute_write(_tx)

    async def delete_project(self, *, project_id: str, user_id: str) -> bool:
        async def _tx(sess: AsyncSession) -> bool:
            uow = UnitOfWork(sess)
            proj = await uow.projects.get(project_id)
            if proj is None or proj.user_id != user_id:
                return False
            await uow.projects.delete(proj)
            return True

        return await self.db.execute_write(_tx)

    async def seed_messages(
        self,
        *,
        chat_id: str,
        user_id: str,
        count: int,
    ) -> dict[str, Any]:
        """Fast bulk-seed of alternating messages for virtualization testing."""
        capped = max(1, min(10000, count))
        now = datetime.now(UTC)

        async def _tx(sess: AsyncSession) -> dict[str, Any]:
            uow = UnitOfWork(sess)
            chat = await uow.chats.get_chat(chat_id)
            if chat is None or chat.user_id != user_id:
                raise MessageTreeError(f"Chat '{chat_id}' not found")

            prev_id = chat.active_leaf_id
            batch: list[dict[str, Any]] = []
            for idx in range(capped):
                msg_id = f"m_seed_{idx + 1:05d}"
                role = "user" if idx % 2 == 0 else "assistant"
                needle = "NEEDLE_QUANTUM_4242" if idx == capped // 2 else ""
                text = (
                    f"Message #{idx + 1} ({role}): Virtualized message body "
                    f"for scale testing. {needle}"
                ).strip()
                batch.append(
                    {
                        "id": msg_id,
                        "chat_id": chat_id,
                        "parent_id": prev_id,
                        "branch_index": 0,
                        "role": role,
                        "parts_json": [{"type": "text", "text": text}],
                        "plain_text": text,
                        "model": chat.model if role == "assistant" else None,
                        "usage_json": {"input": 12, "output": 18, "cost": 0.0},
                        "status": "completed",
                        "created_at": now,
                    }
                )
                prev_id = msg_id

            # Insert in chunks of 500 to stay well under SQLite variable limits
            for offset in range(0, len(batch), 500):
                await sess.execute(insert(MessageRecord), batch[offset : offset + 500])

            chat.active_leaf_id = prev_id
            chat.updated_at = now
            return {
                "chat_id": chat_id,
                "seeded_count": len(batch),
                "active_leaf_id": prev_id,
            }

        return await self.db.execute_write(_tx)
