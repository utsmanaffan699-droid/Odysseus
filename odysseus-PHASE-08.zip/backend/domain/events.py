"""Run Event Protocol v1: Envelope and all 35 strongly-typed event payload schemas."""

from __future__ import annotations

import json
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

PROTOCOL_VERSION = 1

RunStatusLiteral = Literal[
    "queued",
    "running",
    "paused",
    "waiting_approval",
    "interrupted",
]

RunFinishReasonLiteral = Literal[
    "completed",
    "cancelled",
    "error",
    "budget_exceeded",
    "max_iterations",
]

StepKindLiteral = Literal["model", "tool", "subagent", "compaction"]
StepStatusLiteral = Literal["running", "completed", "failed", "cancelled", "interrupted"]

MessagePartTypeLiteral = Literal[
    "text",
    "thinking",
    "tool_call",
    "tool_result",
    "image",
    "file",
    "citation",
    "artifact_ref",
    "plan",
    "notice",
]

PlanItemStatusLiteral = Literal["pending", "in_progress", "done", "skipped", "failed"]

ToolRiskLiteral = Literal["read", "write", "exec", "network", "admin"]
ApprovalDecisionLiteral = Literal["approve", "deny"]
ApprovalScopeLiteral = Literal["once", "run", "chat", "always"]
ToolStreamLiteral = Literal["stdout", "stderr", "log"]
RenderHintLiteral = Literal[
    "text",
    "json",
    "table",
    "diff",
    "image",
    "search_results",
    "file_tree",
    "terminal",
    "browser_snapshot",
]

MemoryOpLiteral = Literal["created", "updated", "deleted", "pinned"]
NoticeLevelLiteral = Literal["info", "warning", "error"]


class RunBudget(BaseModel):
    model_config = ConfigDict(extra="forbid")

    max_iters: int = Field(default=25, gt=0)
    max_tokens: int = Field(default=128000, gt=0)
    max_cost: float = Field(default=5.0, ge=0.0)
    max_seconds: int = Field(default=600, gt=0)


class UsageStats(BaseModel):
    model_config = ConfigDict(extra="forbid")

    input: int = Field(default=0, ge=0)
    output: int = Field(default=0, ge=0)
    cached: int = Field(default=0, ge=0)
    reasoning: int = Field(default=0, ge=0)
    cost: float = Field(default=0.0, ge=0.0)


# --- 1. Run lifecycle ---
class RunStartedPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    model: str
    budget: RunBudget


class RunStatusPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    status: RunStatusLiteral


class RunFinishedPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    reason: RunFinishReasonLiteral
    usage: UsageStats


class RunErrorPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    code: str
    message: str
    retryable: bool = False


# --- 2. Iteration / steps ---
class StepStartedPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    step_id: str
    index: int = Field(ge=0)
    kind: StepKindLiteral


class StepFinishedPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    step_id: str
    status: StepStatusLiteral
    duration_ms: int = Field(ge=0)


# --- 3. Model output ---
class MessagePartStartedPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    message_id: str
    part_id: str
    type: MessagePartTypeLiteral


class MessageTextDeltaPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    part_id: str
    text: str


class MessageThinkingDeltaPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    part_id: str
    text: str


class MessagePartFinishedPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    part_id: str


class MessageFinishedPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    message_id: str
    stop_reason: str
    usage: UsageStats


# --- 4. Plan / todo ---
class PlanItem(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: str
    title: str
    status: PlanItemStatusLiteral


class PlanUpdatedPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    items: list[PlanItem]


# --- 5. Tools ---
class ToolCallProposedPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    call_id: str
    name: str
    args: dict[str, Any]
    risk: ToolRiskLiteral


class ToolApprovalRequestedPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    approval_id: str
    call_id: str
    reason: str
    suggested_pattern: str
    expires_at: str | None = None


class ToolApprovalResolvedPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    approval_id: str
    decision: ApprovalDecisionLiteral
    scope: ApprovalScopeLiteral
    by: str


class ToolStartedPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    call_id: str


class ToolOutputDeltaPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    call_id: str
    stream: ToolStreamLiteral
    text: str


class ToolProgressPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    call_id: str
    pct: float | None = Field(default=None, ge=0.0, le=100.0)
    label: str


class ToolResultPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    call_id: str
    ok: bool
    summary: str
    output_ref: str | None = None
    truncated: bool = False
    duration_ms: int = Field(ge=0)
    render_hint: RenderHintLiteral = "text"


class ToolDeniedPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    call_id: str
    reason: str


# --- 6. Sub-agents ---
class SubagentStartedPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    child_run_id: str
    task: str


class SubagentFinishedPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    child_run_id: str
    status: StepStatusLiteral
    summary: str


# --- 7. Knowledge ---
class CitationItem(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: str
    source: str
    url: str
    title: str
    snippet: str
    span: tuple[int, int] | None = None


class CitationAddedPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    citation: CitationItem


class SourceOpenedPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    url: str
    title: str


class MemoryUsedPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    ids: list[str]


class MemoryUpdatedPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: str
    op: MemoryOpLiteral


# --- 8. Artifacts ---
class ArtifactCreatedPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    artifact_id: str
    type: str
    title: str


class ArtifactDeltaPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    artifact_id: str
    version: int = Field(ge=1)
    text: str


class ArtifactVersionPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    artifact_id: str
    version: int = Field(ge=1)
    summary: str


# --- 9. Context & cost ---
class UsageUpdatedPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    input: int = Field(ge=0)
    output: int = Field(ge=0)
    cached: int = Field(ge=0)
    reasoning: int = Field(ge=0)
    cost: float = Field(ge=0.0)
    context_used: int = Field(ge=0)
    context_window: int = Field(gt=0)


class ContextCompactedPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    removed_tokens: int = Field(ge=0)
    summary_ref: str


class NoticePayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    level: NoticeLevelLiteral
    code: str
    text: str


# --- 10. Control ---
class SteerReceivedPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    text: str


class StreamResyncPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    cursor: int = Field(ge=0)


class StreamKeepalivePayload(BaseModel):
    model_config = ConfigDict(extra="forbid")


EventTypeLiteral = Literal[
    "run.started",
    "run.status",
    "run.finished",
    "run.error",
    "step.started",
    "step.finished",
    "message.part.started",
    "message.text.delta",
    "message.thinking.delta",
    "message.part.finished",
    "message.finished",
    "plan.updated",
    "tool.call.proposed",
    "tool.approval.requested",
    "tool.approval.resolved",
    "tool.started",
    "tool.output.delta",
    "tool.progress",
    "tool.result",
    "tool.denied",
    "subagent.started",
    "subagent.finished",
    "citation.added",
    "source.opened",
    "memory.used",
    "memory.updated",
    "artifact.created",
    "artifact.delta",
    "artifact.version",
    "usage.updated",
    "context.compacted",
    "notice",
    "steer.received",
    "stream.resync",
    "stream.keepalive",
]

EVENT_PAYLOAD_MODELS: dict[str, type[BaseModel]] = {
    "run.started": RunStartedPayload,
    "run.status": RunStatusPayload,
    "run.finished": RunFinishedPayload,
    "run.error": RunErrorPayload,
    "step.started": StepStartedPayload,
    "step.finished": StepFinishedPayload,
    "message.part.started": MessagePartStartedPayload,
    "message.text.delta": MessageTextDeltaPayload,
    "message.thinking.delta": MessageThinkingDeltaPayload,
    "message.part.finished": MessagePartFinishedPayload,
    "message.finished": MessageFinishedPayload,
    "plan.updated": PlanUpdatedPayload,
    "tool.call.proposed": ToolCallProposedPayload,
    "tool.approval.requested": ToolApprovalRequestedPayload,
    "tool.approval.resolved": ToolApprovalResolvedPayload,
    "tool.started": ToolStartedPayload,
    "tool.output.delta": ToolOutputDeltaPayload,
    "tool.progress": ToolProgressPayload,
    "tool.result": ToolResultPayload,
    "tool.denied": ToolDeniedPayload,
    "subagent.started": SubagentStartedPayload,
    "subagent.finished": SubagentFinishedPayload,
    "citation.added": CitationAddedPayload,
    "source.opened": SourceOpenedPayload,
    "memory.used": MemoryUsedPayload,
    "memory.updated": MemoryUpdatedPayload,
    "artifact.created": ArtifactCreatedPayload,
    "artifact.delta": ArtifactDeltaPayload,
    "artifact.version": ArtifactVersionPayload,
    "usage.updated": UsageUpdatedPayload,
    "context.compacted": ContextCompactedPayload,
    "notice": NoticePayload,
    "steer.received": SteerReceivedPayload,
    "stream.resync": StreamResyncPayload,
    "stream.keepalive": StreamKeepalivePayload,
}


class RunEventEnvelope(BaseModel):
    """Canonical event envelope sent over SSE and persisted in `run_events`."""

    model_config = ConfigDict(extra="forbid")

    seq: int = Field(ge=1)
    run_id: str = Field(min_length=1)
    ts: str = Field(min_length=1)
    type: EventTypeLiteral
    data: dict[str, Any]

    @model_validator(mode="after")
    def _validate_payload_against_type(self) -> RunEventEnvelope:
        model_cls = EVENT_PAYLOAD_MODELS.get(self.type)
        if model_cls is None:
            raise ValueError(f"Unknown event type: {self.type}")
        validated = model_cls.model_validate(self.data)
        self.data = validated.model_dump(mode="json", exclude_none=True)
        return self


def format_sse_event(envelope: RunEventEnvelope) -> str:
    """Format a RunEventEnvelope into standard Server-Sent Events wire framing."""
    payload_str = json.dumps(
        envelope.model_dump(mode="json"), separators=(",", ":"), sort_keys=True
    )
    return f"id: {envelope.seq}\nevent: {envelope.type}\ndata: {payload_str}\n\n"


def format_sse_keepalive() -> str:
    """Format an SSE keepalive comment."""
    return ": keepalive\n\n"


def build_event_protocol_json_schema() -> dict[str, Any]:
    """Export canonical JSON Schema for RunEventEnvelope and all 35 v1 event payloads."""
    definitions: dict[str, Any] = {}
    for event_type, model_cls in sorted(EVENT_PAYLOAD_MODELS.items()):
        definitions[event_type] = model_cls.model_json_schema()

    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "title": "OdysseusRunEventProtocolV1",
        "protocol_version": PROTOCOL_VERSION,
        "envelope": RunEventEnvelope.model_json_schema(),
        "events": definitions,
    }
