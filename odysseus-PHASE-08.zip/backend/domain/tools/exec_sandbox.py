"""Sandboxed shell and Python execution with process-group isolation and rlimit caps."""

from __future__ import annotations

import asyncio
import contextlib
import os
import resource
import shutil
import signal
import sys
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

OutputDeltaCallback = Callable[[Literal["stdout", "stderr", "log"], str], Awaitable[None]]
PgidCallback = Callable[[int], Awaitable[None]]


@dataclass(frozen=True)
class SandboxResult:
    """Outcome of a sandboxed subprocess execution."""

    exit_code: int
    stdout: str
    stderr: str
    combined_output: str
    truncated: bool
    timed_out: bool
    duration_ms: int
    pgid: int | None = None


def kill_process_group_safely(pgid: int | None) -> bool:
    """Send SIGTERM then SIGKILL to a process group if it still exists."""
    if pgid is None or pgid <= 1:
        return False
    killed = False
    try:
        os.killpg(pgid, signal.SIGKILL)
        killed = True
    except ProcessLookupError:
        return False
    except PermissionError:
        killed = True
    return killed


def is_process_group_alive(pgid: int | None) -> bool:
    """Return True if any process in process group `pgid` is still alive."""
    if pgid is None or pgid <= 1:
        return False
    try:
        os.killpg(pgid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


def _build_minimal_env(workspace_root: Path, tmp_dir: Path) -> dict[str, str]:
    """Construct a clean, secret-free environment dictionary for sandboxed execution."""
    return {
        "PATH": "/usr/local/bin:/usr/bin:/bin",
        "HOME": str(workspace_root),
        "TMPDIR": str(tmp_dir),
        "TEMP": str(tmp_dir),
        "TMP": str(tmp_dir),
        "LANG": "C.UTF-8",
        "LC_ALL": "C.UTF-8",
        "PYTHONIOENCODING": "utf-8",
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONNOUSERSITE": "1",
        "NO_PROXY": "*",
        "http_proxy": "http://127.0.0.1:1",
        "https_proxy": "http://127.0.0.1:1",
    }


def _make_preexec_fn(
    *,
    cpu_seconds: int,
    max_fsize_bytes: int,
    max_nproc: int | None,
    max_nofile: int = 64,
) -> Callable[[], None]:
    """Create preexec_fn that starts a dedicated process group and applies POSIX rlimits."""

    def _preexec() -> None:
        os.setsid()
        with contextlib.suppress(ValueError, OSError):
            resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        with contextlib.suppress(ValueError, OSError):
            resource.setrlimit(resource.RLIMIT_CPU, (cpu_seconds, cpu_seconds + 1))
        with contextlib.suppress(ValueError, OSError):
            resource.setrlimit(resource.RLIMIT_FSIZE, (max_fsize_bytes, max_fsize_bytes))
        with contextlib.suppress(ValueError, OSError):
            resource.setrlimit(resource.RLIMIT_NOFILE, (max_nofile, max_nofile))
        if max_nproc is not None and hasattr(resource, "RLIMIT_NPROC"):
            with contextlib.suppress(ValueError, OSError):
                resource.setrlimit(resource.RLIMIT_NPROC, (max_nproc, max_nproc))

    return _preexec


_PYTHON_SANDBOX_PRELUDE = """\
import sys as _sys
def _odysseus_audit_hook(event, args):
    if event in (
        "socket.bind",
        "socket.connect",
        "socket.sendmsg",
        "socket.sendto",
        "urllib.Request",
        "http.client.connect",
    ):
        raise PermissionError(f"Network socket operation '{event}' is blocked in sandbox")
_sys.addaudithook(_odysseus_audit_hook)
"""


async def run_sandboxed_command(
    argv: list[str],
    *,
    workspace_root: Path,
    timeout_seconds: float = 10.0,
    max_output_bytes: int = 65536,
    cpu_seconds: int = 5,
    max_fsize_bytes: int = 10_485_760,
    max_nproc: int | None = None,
    backend: Literal["subprocess_rlimit", "bwrap", "docker"] = "subprocess_rlimit",
    cancel_event: asyncio.Event | None = None,
    on_output_delta: OutputDeltaCallback | None = None,
    on_pgid_started: PgidCallback | None = None,
) -> SandboxResult:
    """Execute `argv` inside an isolated process group with resource, time, and output caps."""
    os.makedirs(str(workspace_root), exist_ok=True)
    tmp_dir = workspace_root / ".sandbox_tmp"
    os.makedirs(str(tmp_dir), exist_ok=True)

    env = _build_minimal_env(workspace_root, tmp_dir)
    effective_argv = list(argv)

    if backend == "bwrap" and shutil.which("bwrap"):
        effective_argv = [
            "bwrap",
            "--ro-bind",
            "/usr",
            "/usr",
            "--ro-bind",
            "/lib",
            "/lib",
            "--ro-bind-try",
            "/lib64",
            "/lib64",
            "--ro-bind",
            "/bin",
            "/bin",
            "--bind",
            str(workspace_root),
            str(workspace_root),
            "--tmpfs",
            "/tmp",  # noqa: S108
            "--unshare-all",
            "--die-with-parent",
            "--chdir",
            str(workspace_root),
            *argv,
        ]

    start_mono = time.perf_counter()
    proc = await asyncio.create_subprocess_exec(
        *effective_argv,
        cwd=str(workspace_root),
        env=env,
        stdin=asyncio.subprocess.DEVNULL,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        preexec_fn=_make_preexec_fn(
            cpu_seconds=max(1, cpu_seconds),
            max_fsize_bytes=max(4096, max_fsize_bytes),
            max_nproc=max_nproc,
        ),
    )

    pgid = proc.pid
    if on_pgid_started is not None and pgid is not None:
        await on_pgid_started(pgid)

    stdout_chunks: list[bytes] = []
    stderr_chunks: list[bytes] = []
    total_captured = 0
    truncated = False
    timed_out = False
    cap_lock = asyncio.Lock()

    # Coalesce output deltas at <= 20 events/s (50ms window) per stream
    coalesce_interval = 0.05

    async def _pump_stream(
        stream: asyncio.StreamReader | None,
        stream_name: Literal["stdout", "stderr"],
        collector: list[bytes],
    ) -> None:
        nonlocal total_captured, truncated
        if stream is None:
            return
        pending_str: list[str] = []
        last_emit = time.perf_counter()

        async def _flush_delta(*, force: bool = False) -> None:
            nonlocal last_emit
            if not pending_str or on_output_delta is None:
                return
            now = time.perf_counter()
            if not force and (now - last_emit) < coalesce_interval:
                return
            text_payload = "".join(pending_str)
            pending_str.clear()
            last_emit = now
            await on_output_delta(stream_name, text_payload)

        while True:
            chunk = await stream.read(4096)
            if not chunk:
                break
            async with cap_lock:
                remaining = max_output_bytes - total_captured
                if remaining <= 0:
                    truncated = True
                    kill_process_group_safely(pgid)
                    break
                if len(chunk) > remaining:
                    chunk = chunk[:remaining]
                    truncated = True
                collector.append(chunk)
                total_captured += len(chunk)
                if truncated:
                    kill_process_group_safely(pgid)

            decoded = chunk.decode("utf-8", errors="replace")
            pending_str.append(decoded)
            await _flush_delta(force=False)
            if truncated:
                break

        await _flush_delta(force=True)

    pump_task = asyncio.gather(
        _pump_stream(proc.stdout, "stdout", stdout_chunks),
        _pump_stream(proc.stderr, "stderr", stderr_chunks),
    )
    wait_task = asyncio.create_task(proc.wait())

    try:
        deadline = start_mono + timeout_seconds
        while not wait_task.done():
            if cancel_event is not None and cancel_event.is_set():
                kill_process_group_safely(pgid)
                raise asyncio.CancelledError()
            remaining_sec = deadline - time.perf_counter()
            if remaining_sec <= 0:
                timed_out = True
                kill_process_group_safely(pgid)
                break
            try:
                await asyncio.wait_for(
                    asyncio.shield(wait_task),
                    timeout=min(0.05, max(0.005, remaining_sec)),
                )
            except TimeoutError:
                continue

        with contextlib.suppress(TimeoutError, Exception):
            await asyncio.wait_for(pump_task, timeout=1.0)
        with contextlib.suppress(TimeoutError, Exception):
            await asyncio.wait_for(wait_task, timeout=1.0)
    finally:
        # Always reap the entire process group so no background child / port listener survives
        kill_process_group_safely(pgid)
        if not wait_task.done():
            with contextlib.suppress(TimeoutError, asyncio.CancelledError, Exception):
                await asyncio.wait_for(wait_task, timeout=0.5)
        kill_process_group_safely(pgid)
        if not wait_task.done():
            wait_task.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await wait_task
        if not pump_task.done():
            pump_task.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await pump_task

    duration_ms = max(0, int((time.perf_counter() - start_mono) * 1000))
    stdout_str = b"".join(stdout_chunks).decode("utf-8", errors="replace")
    stderr_str = b"".join(stderr_chunks).decode("utf-8", errors="replace")
    if truncated:
        marker = f"\n... [OUTPUT TRUNCATED AT {max_output_bytes} BYTES] ..."
        stdout_str += marker
    if timed_out:
        stderr_str += f"\n[Process killed after exceeding {timeout_seconds:.1f}s timeout]"

    combined = stdout_str
    if stderr_str:
        combined = f"{stdout_str}\n[stderr]\n{stderr_str}".strip() if stdout_str else stderr_str

    exit_code = proc.returncode if proc.returncode is not None else (-9 if timed_out else -1)
    return SandboxResult(
        exit_code=exit_code,
        stdout=stdout_str,
        stderr=stderr_str,
        combined_output=combined,
        truncated=truncated,
        timed_out=timed_out,
        duration_ms=duration_ms,
        pgid=pgid,
    )


async def run_sandboxed_shell(
    command: str,
    *,
    workspace_root: Path,
    timeout_seconds: float = 10.0,
    max_output_bytes: int = 65536,
    cpu_seconds: int = 5,
    max_fsize_bytes: int = 10_485_760,
    max_nproc: int | None = None,
    backend: Literal["subprocess_rlimit", "bwrap", "docker"] = "subprocess_rlimit",
    cancel_event: asyncio.Event | None = None,
    on_output_delta: OutputDeltaCallback | None = None,
    on_pgid_started: PgidCallback | None = None,
) -> SandboxResult:
    """Execute a shell command in a sandboxed process group with ulimit guards."""
    fsize_blocks = max(1, max_fsize_bytes // 512)
    nproc_guard = f"ulimit -u {max_nproc} 2>/dev/null || true; " if max_nproc else ""
    wrapped_cmd = f"ulimit -f {fsize_blocks} 2>/dev/null || true; {nproc_guard}{command}"
    return await run_sandboxed_command(
        ["/bin/sh", "-c", wrapped_cmd],
        workspace_root=workspace_root,
        timeout_seconds=timeout_seconds,
        max_output_bytes=max_output_bytes,
        cpu_seconds=cpu_seconds,
        max_fsize_bytes=max_fsize_bytes,
        max_nproc=max_nproc,
        backend=backend,
        cancel_event=cancel_event,
        on_output_delta=on_output_delta,
        on_pgid_started=on_pgid_started,
    )


async def run_sandboxed_python(
    code: str,
    *,
    workspace_root: Path,
    allow_network: bool = False,
    timeout_seconds: float = 10.0,
    max_output_bytes: int = 65536,
    cpu_seconds: int = 5,
    max_fsize_bytes: int = 10_485_760,
    max_nproc: int | None = None,
    backend: Literal["subprocess_rlimit", "bwrap", "docker"] = "subprocess_rlimit",
    cancel_event: asyncio.Event | None = None,
    on_output_delta: OutputDeltaCallback | None = None,
    on_pgid_started: PgidCallback | None = None,
) -> SandboxResult:
    """Execute Python code in a sandboxed subprocess with audit hook blocking network sockets."""
    full_script = code if allow_network else f"{_PYTHON_SANDBOX_PRELUDE}\n{code}"
    return await run_sandboxed_command(
        [sys.executable, "-I", "-B", "-c", full_script],
        workspace_root=workspace_root,
        timeout_seconds=timeout_seconds,
        max_output_bytes=max_output_bytes,
        cpu_seconds=cpu_seconds,
        max_fsize_bytes=max_fsize_bytes,
        max_nproc=max_nproc,
        backend=backend,
        cancel_event=cancel_event,
        on_output_delta=on_output_delta,
        on_pgid_started=on_pgid_started,
    )
