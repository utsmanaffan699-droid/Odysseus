"""Code-enforced tool execution policy engine, structured approval patterns, and taint rules."""

from __future__ import annotations

import fnmatch
import hashlib
import json
import posixpath
import shlex
from dataclasses import dataclass, field
from typing import Any, Literal
from urllib.parse import urlparse

from backend.domain.events import RenderHintLiteral, ToolRiskLiteral

ApprovalMode = Literal["auto", "ask", "deny"]
RunModeLiteral = Literal["interactive", "background"]

_SHELL_METACHARS = frozenset({";", "|", "&", "$", ">", "<", "`", "\n", "\r"})


@dataclass(frozen=True)
class ToolDefinition:
    """Declarative metadata for a built-in or MCP tool."""

    name: str
    risk: ToolRiskLiteral
    required_privilege: str
    default_approval: ApprovalMode = "ask"
    description: str = ""
    render_hint: RenderHintLiteral = "text"
    timeout_seconds: float = 15.0
    max_output_bytes: int = 65536
    idempotent: bool = False
    enabled: bool = True
    disabled_until_phase: str | None = None


@dataclass(frozen=True)
class PolicyDecision:
    """Result of evaluating a proposed tool call against the code-enforced policy engine."""

    decision: ApprovalMode
    reason: str
    tainted_by_untrusted_source: str | None = None
    suggested_pattern: str = ""


DEFAULT_RISK_POLICY: dict[ToolRiskLiteral, ApprovalMode] = {
    "read": "auto",
    "write": "ask",
    "exec": "ask",
    "network": "ask",
    "admin": "deny",
}


def wrap_untrusted_content(source: str, content: str) -> str:
    """Wrap untrusted external data in explicit non-executable data delimiters."""
    safe_source = source.replace("\n", " ").replace(">", "")
    return (
        f'<untrusted_external_data source="{safe_source}">\n{content}\n</untrusted_external_data>'
    )


def has_shell_metacharacters(command: str) -> bool:
    """Return True if a command string contains shell chaining, redirection, or subshell chars."""
    return any(ch in _SHELL_METACHARS for ch in command) or "$(" in command


def suggest_structured_pattern(tool_name: str, args: dict[str, Any]) -> str:
    """Build a structured, non-regex approval pattern for a proposed tool call."""
    if tool_name == "shell":
        cmd = str(args.get("command", "")).strip()
        if not cmd or has_shell_metacharacters(cmd):
            digest = hashlib.sha256(cmd.encode("utf-8", errors="replace")).hexdigest()[:16]
            return f"shell_exact:{digest}"
        try:
            tokens = shlex.split(cmd)
        except ValueError:
            digest = hashlib.sha256(cmd.encode("utf-8", errors="replace")).hexdigest()[:16]
            return f"shell_exact:{digest}"
        prefix = tokens[:2] if len(tokens) >= 2 else tokens[:1]
        return f"argv_prefix:{json.dumps(prefix, separators=(',', ':'))}"

    if tool_name == "python":
        code = str(args.get("code", "")).strip()
        digest = hashlib.sha256(code.encode("utf-8", errors="replace")).hexdigest()[:16]
        return f"python_exact:{digest}"

    if tool_name in ("read_file", "write_file", "edit_file", "list_dir", "glob", "grep"):
        raw_path = str(args.get("path", ".")).replace("\\", "/").strip()
        norm = posixpath.normpath(raw_path).lstrip("/")
        parent = posixpath.dirname(norm)
        if parent and parent != ".":
            return f"path_glob:{tool_name}:{parent}/*"
        return f"path_glob:{tool_name}:*"

    if tool_name in ("fetch_url", "youtube_transcript"):
        raw_url = str(args.get("url") or args.get("video_url") or "")
        host = (urlparse(raw_url).hostname or "").lower()
        if host:
            return f"host_allowlist:{tool_name}:{host}"
        return f"host_allowlist:{tool_name}:*"

    if tool_name == "web_search":
        return "host_allowlist:web_search:*"

    return f"tool:{tool_name}"


def match_structured_pattern(pattern: str, tool_name: str, args: dict[str, Any]) -> bool:
    """Deterministically evaluate a structured pattern against a tool call (never regex)."""
    pat = pattern.strip()
    if not pat:
        return False

    # 1. Structured argv_prefix for shell (supports `argv_prefix:[...]` or raw `[...]`)
    if pat.startswith("argv_prefix:") or (pat.startswith("[") and tool_name == "shell"):
        if tool_name != "shell":
            return False
        cmd = str(args.get("command", "")).strip()
        if not cmd or has_shell_metacharacters(cmd):
            return False
        raw_json_list = pat[len("argv_prefix:") :] if pat.startswith("argv_prefix:") else pat
        try:
            allowed_prefix = json.loads(raw_json_list)
            if not isinstance(allowed_prefix, list) or not allowed_prefix:
                return False
            tokens = shlex.split(cmd)
        except Exception:
            return False
        if len(tokens) < len(allowed_prefix):
            return False
        return all(tokens[i] == str(allowed_prefix[i]) for i in range(len(allowed_prefix)))

    # 2. Exact hash match for shell or python
    if pat.startswith("shell_exact:"):
        if tool_name != "shell":
            return False
        cmd = str(args.get("command", "")).strip()
        digest = hashlib.sha256(cmd.encode("utf-8", errors="replace")).hexdigest()[:16]
        return pat == f"shell_exact:{digest}"

    if pat.startswith("python_exact:"):
        if tool_name != "python":
            return False
        code = str(args.get("code", "")).strip()
        digest = hashlib.sha256(code.encode("utf-8", errors="replace")).hexdigest()[:16]
        return pat == f"python_exact:{digest}"

    # 3. Structured path_glob:<tool>:<glob>
    if pat.startswith("path_glob:"):
        rest = pat[len("path_glob:") :]
        t_part, _, glob_pat = rest.partition(":")
        if t_part not in (tool_name, "*"):
            return False
        raw_path = str(args.get("path", ".")).replace("\\", "/").strip()
        if ".." in raw_path.split("/"):
            return False
        norm = posixpath.normpath(raw_path).lstrip("/")
        return fnmatch.fnmatchcase(norm, glob_pat)

    # 4. Structured host_allowlist:<tool>:<host>
    if pat.startswith("host_allowlist:"):
        rest = pat[len("host_allowlist:") :]
        t_part, _, allowed_host = rest.partition(":")
        if t_part not in (tool_name, "*"):
            return False
        if allowed_host == "*":
            return True
        raw_url = str(args.get("url") or args.get("video_url") or "")
        host = (urlparse(raw_url).hostname or "").lower()
        if not host:
            return False
        allowed_lower = allowed_host.lower()
        return host == allowed_lower or host.endswith(f".{allowed_lower}")

    if pat == f"tool:{tool_name}":
        return True

    # 5. Legacy <tool_name>:<fnmatch> pattern (still blocks shell metacharacters on allow!)
    target_arg = str(args.get("command") or args.get("path") or args.get("url") or "")
    signature = f"{tool_name}:{target_arg}"
    if tool_name == "shell" and has_shell_metacharacters(target_arg):
        # Allow deny_patterns to match metacharacters, handled by caller
        return fnmatch.fnmatchcase(signature, pat)
    return fnmatch.fnmatchcase(signature, pat)


@dataclass
class ToolPolicyEngine:
    """Enforces privilege, preset, allow/deny rules, and untrusted-content taint in code."""

    risk_modes: dict[ToolRiskLiteral, ApprovalMode] = field(
        default_factory=lambda: dict(DEFAULT_RISK_POLICY)
    )
    allow_patterns: list[str] = field(default_factory=list)
    deny_patterns: list[str] = field(default_factory=list)

    def evaluate(
        self,
        tool: ToolDefinition,
        args: dict[str, Any],
        *,
        user_privileges: frozenset[str],
        tainted_source: str | None = None,
        preset_allowed_tools: set[str] | None = None,
        run_mode: RunModeLiteral = "interactive",
        background_deny_on_ask: bool = False,
    ) -> PolicyDecision:
        """Pure function deciding whether a tool call is auto-approved, asked, or denied."""
        suggested = suggest_structured_pattern(tool.name, args)

        # 0. Disabled / future-phase stub check
        if not tool.enabled:
            phase_msg = (
                f" (scheduled for {tool.disabled_until_phase})" if tool.disabled_until_phase else ""
            )
            return PolicyDecision(
                decision="deny",
                reason=f"Tool '{tool.name}' is disabled{phase_msg}",
                tainted_by_untrusted_source=tainted_source,
                suggested_pattern=suggested,
            )

        # 1. Agent preset tool allowlist check
        if preset_allowed_tools is not None and tool.name not in preset_allowed_tools:
            return PolicyDecision(
                decision="deny",
                reason=f"Tool '{tool.name}' is not permitted by the active agent preset",
                tainted_by_untrusted_source=tainted_source,
                suggested_pattern=suggested,
            )

        # 2. Privilege check is absolute: non-admins never get admin tools; exec needs privilege
        is_admin = "admin" in user_privileges
        if tool.risk == "admin" and not is_admin:
            return PolicyDecision(
                decision="deny",
                reason="Admin-risk tools require 'admin' privilege",
                tainted_by_untrusted_source=tainted_source,
                suggested_pattern=suggested,
            )
        if tool.required_privilege not in user_privileges and not is_admin:
            return PolicyDecision(
                decision="deny",
                reason=f"Caller lacks required privilege '{tool.required_privilege}'",
                tainted_by_untrusted_source=tainted_source,
                suggested_pattern=suggested,
            )

        # 3. Explicit deny patterns always win (deny > ask > auto)
        for pat in self.deny_patterns:
            if match_structured_pattern(pat, tool.name, args):
                return PolicyDecision(
                    decision="deny",
                    reason=f"Matched deny pattern '{pat}'",
                    tainted_by_untrusted_source=tainted_source,
                    suggested_pattern=suggested,
                )

        # 4. Base risk / tool default check if explicitly set to deny
        risk_mode = self.risk_modes.get(tool.risk, tool.default_approval)
        if tool.default_approval == "deny" or risk_mode == "deny":
            return PolicyDecision(
                decision="deny",
                reason=f"Tool '{tool.name}' (risk={tool.risk}) is denied by policy",
                tainted_by_untrusted_source=tainted_source,
                suggested_pattern=suggested,
            )
        base_mode = risk_mode if self.risk_modes != DEFAULT_RISK_POLICY else tool.default_approval

        # 5. Lethal Trifecta / Taint escalation:
        # If untrusted content is in context, ANY write/exec/network/admin call requires approval
        # even if previously allow-listed!
        if tainted_source is not None and tool.risk in ("write", "exec", "network", "admin"):
            if run_mode == "background" and background_deny_on_ask:
                return PolicyDecision(
                    decision="deny",
                    reason=(
                        f"Background run cannot wait for approval on tainted '{tool.name}' "
                        f"(tainted by {tainted_source})"
                    ),
                    tainted_by_untrusted_source=tainted_source,
                    suggested_pattern=suggested,
                )
            return PolicyDecision(
                decision="ask",
                reason=(
                    f"Requested after reading untrusted source {tainted_source}; "
                    "explicit approval required"
                ),
                tainted_by_untrusted_source=tainted_source,
                suggested_pattern=suggested,
            )

        # 6. Check structured allow patterns (only when not tainted and not admin-risk)
        if tool.risk != "admin":
            target_cmd = str(args.get("command", ""))
            for pat in self.allow_patterns:
                # Never allow a legacy fnmatch pattern to auto-approve shell metacharacter smuggling
                if (
                    tool.name == "shell"
                    and not pat.startswith("shell_exact:")
                    and has_shell_metacharacters(target_cmd)
                ):
                    continue
                if match_structured_pattern(pat, tool.name, args):
                    return PolicyDecision(
                        decision="auto",
                        reason=f"Matched allow pattern '{pat}'",
                        suggested_pattern=suggested,
                    )

        # 7. Fall back to risk-class or tool default
        if base_mode == "ask" and run_mode == "background" and background_deny_on_ask:
            return PolicyDecision(
                decision="deny",
                reason=f"Background run auto-denied '{tool.name}' requiring interactive approval",
                tainted_by_untrusted_source=tainted_source,
                suggested_pattern=suggested,
            )

        return PolicyDecision(
            decision=base_mode,
            reason=f"Default policy for risk='{tool.risk}' is '{base_mode}'",
            tainted_by_untrusted_source=tainted_source,
            suggested_pattern=suggested,
        )
