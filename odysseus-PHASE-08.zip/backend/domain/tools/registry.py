"""Tool Registry, typed Pydantic schemas, explain() intent cards, blob truncation, tools."""

from __future__ import annotations

import asyncio
import json
import uuid
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

import httpx
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.db import DatabaseManager
from backend.core.models import ArtifactRecord, ArtifactVersionRecord
from backend.core.settings import Settings
from backend.core.uow import UnitOfWork
from backend.domain.events import (
    EventTypeLiteral,
    PlanItemStatusLiteral,
    RenderHintLiteral,
)
from backend.domain.memory.service import MemoryService
from backend.domain.skills.service import SkillService
from backend.domain.tools.exec_sandbox import (
    OutputDeltaCallback,
    PgidCallback,
    run_sandboxed_python,
    run_sandboxed_shell,
)
from backend.domain.tools.filesystem import (
    get_user_workspace_root,
    workspace_edit_file,
    workspace_glob,
    workspace_grep,
    workspace_list_dir,
    workspace_read_file,
    workspace_write_file,
)
from backend.domain.tools.policy import ToolDefinition
from backend.domain.tools.provenance import (
    NormalizedApprovalCard,
    ProvenanceTag,
    normalize_and_flag_approval_args,
)
from backend.domain.tools.web_tools import (
    execute_web_search,
    extract_youtube_video_id,
    safe_fetch_url,
)
from backend.providers.base import ProviderToolSpec

if TYPE_CHECKING:
    from backend.mcp.manager import McpClientManager


@dataclass
class ToolExecutionContext:
    """Runtime context passed to every tool handler during a run."""

    run_id: str
    chat_id: str
    user_id: str
    call_id: str
    user_privileges: frozenset[str]
    settings: Settings
    db: DatabaseManager
    memory_service: MemoryService | None = None
    skill_service: SkillService | None = None
    mcp_manager: McpClientManager | None = None
    cancel_event: asyncio.Event | None = None
    emit_event: Callable[[EventTypeLiteral, dict[str, Any]], Awaitable[None]] | None = None
    on_output_delta: OutputDeltaCallback | None = None
    on_pgid_started: PgidCallback | None = None
    on_discover_tools: Callable[[list[str]], None] | None = None
    spawn_subagent_fn: Callable[[dict[str, Any]], Awaitable[dict[str, Any]]] | None = None
    http_transport: httpx.AsyncBaseTransport | None = None
    resolve_dns: bool = True


@dataclass(frozen=True)
class ToolExecutionOutput:
    """Raw output produced by a tool handler before blob persistence and truncation."""

    ok: bool
    summary: str
    full_output: str
    render_hint: RenderHintLiteral = "text"
    provenance: ProvenanceTag = field(
        default_factory=lambda: ProvenanceTag(source="tool", trust="trusted")
    )
    truncated_by_tool: bool = False
    extra_events: list[tuple[EventTypeLiteral, dict[str, Any]]] = field(default_factory=list)


@dataclass(frozen=True)
class PersistedToolOutput:
    """Persisted tool output with blob reference and model-facing truncated view."""

    output_ref: str
    output_bytes: int
    truncated: bool
    model_view: str
    full_output: str


def persist_and_truncate_tool_output(
    data_dir: Path,
    call_id: str,
    full_output: str,
    *,
    max_model_bytes: int = 4096,
    already_truncated: bool = False,
) -> PersistedToolOutput:
    """Store full tool output on disk and construct a model-facing head/tail truncated view."""
    safe_cid = "".join(ch if ch.isalnum() or ch in ("_", "-") else "_" for ch in call_id)
    out_dir = data_dir / "tool_outputs"
    out_dir.mkdir(parents=True, exist_ok=True)
    blob_path = out_dir / f"{safe_cid}.txt"
    encoded = full_output.encode("utf-8", errors="replace")
    blob_path.write_bytes(encoded)
    output_ref = f"blob://tool_outputs/{safe_cid}"
    total_bytes = len(encoded)

    if total_bytes <= max_model_bytes:
        return PersistedToolOutput(
            output_ref=output_ref,
            output_bytes=total_bytes,
            truncated=already_truncated,
            model_view=full_output,
            full_output=full_output,
        )

    head_len = max(128, (max_model_bytes * 2) // 5)
    tail_len = max(128, (max_model_bytes * 2) // 5)
    head_str = encoded[:head_len].decode("utf-8", errors="replace")
    tail_str = encoded[-tail_len:].decode("utf-8", errors="replace")
    omitted = max(1, total_bytes - head_len - tail_len)
    model_view = (
        f"{head_str}\n"
        f'... [{omitted} bytes omitted; use read_tool_output(call_id="{call_id}", '
        f"offset={head_len}, length=4096) to read more] ...\n"
        f"{tail_str}"
    )
    return PersistedToolOutput(
        output_ref=output_ref,
        output_bytes=total_bytes,
        truncated=True,
        model_view=model_view,
        full_output=full_output,
    )


def read_tool_output_slice(
    data_dir: Path,
    call_id: str,
    *,
    offset: int = 0,
    length: int = 4096,
) -> dict[str, Any]:
    """Read a byte slice `[offset : offset + length]` from a persisted tool output blob."""
    safe_cid = "".join(ch if ch.isalnum() or ch in ("_", "-") else "_" for ch in call_id)
    blob_path = data_dir / "tool_outputs" / f"{safe_cid}.txt"
    if not blob_path.exists():
        raise FileNotFoundError(f"Tool output blob not found for call_id={call_id!r}")
    raw = blob_path.read_bytes()
    total = len(raw)
    start = max(0, min(offset, total))
    end = max(start, min(start + max(1, length), total))
    chunk = raw[start:end].decode("utf-8", errors="replace")
    return {
        "call_id": call_id,
        "offset": start,
        "length": end - start,
        "total_bytes": total,
        "has_more": end < total,
        "text": chunk,
    }


ToolHandlerFn = Callable[[ToolExecutionContext, dict[str, Any]], Awaitable[ToolExecutionOutput]]
ExplainFn = Callable[[dict[str, Any]], str]


@dataclass
class RegisteredTool:
    """Complete definition, schema, explain() callback, and async handler for a tool."""

    definition: ToolDefinition
    args_schema: type[BaseModel]
    handler: ToolHandlerFn
    explain_fn: ExplainFn

    def to_provider_spec(self) -> ProviderToolSpec:
        schema = self.args_schema.model_json_schema()
        clean_schema = {
            "type": "object",
            "properties": schema.get("properties", {}),
            "required": schema.get("required", []),
        }
        return ProviderToolSpec(
            name=self.definition.name,
            description=self.definition.description,
            parameters=clean_schema,
        )

    def explain(self, args: dict[str, Any]) -> NormalizedApprovalCard:
        """Produce a normalized, spoof-checked human-readable approval card description."""
        raw_intent = self.explain_fn(args)
        return normalize_and_flag_approval_args(self.definition.name, args, raw_intent)


# --- Pydantic Schemas for Built-in Tools ---


class ReadFileArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    path: str = Field(description="Workspace-relative file path to read.")
    offset: int = Field(default=1, ge=1, description="1-based starting line number.")
    limit: int = Field(default=200, ge=1, le=2000, description="Max lines to return.")


class WriteFileArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    path: str = Field(description="Workspace-relative file path to write.")
    content: str = Field(description="Full UTF-8 content to write.")


class EditFileArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    path: str = Field(description="Workspace-relative file path to edit.")
    old_text: str = Field(description="Exact text to replace (must match once).")
    new_text: str = Field(description="Replacement text.")


class ListDirArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    path: str = Field(default=".", description="Workspace-relative directory path.")


class GlobArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    pattern: str = Field(description="Glob pattern such as '*.py' or 'src/**/*.ts'.")
    path: str = Field(default=".", description="Base workspace directory.")


class GrepArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    pattern: str = Field(description="Regex or literal pattern to search for.")
    path: str = Field(default=".", description="File or directory path inside workspace.")
    max_results: int = Field(default=50, ge=1, le=200)


class ReadToolOutputArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    call_id: str = Field(description="ID of the tool call whose full output to inspect.")
    offset: int = Field(default=0, ge=0, description="Byte offset to start reading from.")
    length: int = Field(default=4096, ge=64, le=65536, description="Byte count to read.")


class ShellArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    command: str = Field(description="Shell command to execute inside the workspace sandbox.")
    timeout_seconds: float = Field(default=10.0, gt=0.1, le=120.0)


class PythonArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    code: str = Field(description="Python snippet to execute inside the isolated sandbox.")
    timeout_seconds: float = Field(default=10.0, gt=0.1, le=120.0)


class WebSearchArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    query: str = Field(description="Search query string.")
    max_results: int = Field(default=5, ge=1, le=10)


class FetchUrlArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    url: str = Field(description="External HTTP/HTTPS URL to fetch.")


class YoutubeTranscriptArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    video_url: str = Field(description="YouTube video URL or 11-char video ID.")


class PlanItemArg(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default="step_1")
    title: str
    status: PlanItemStatusLiteral = "pending"


class UpdatePlanArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[PlanItemArg] = Field(description="Ordered list of plan/todo items.")


class CreateArtifactArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    title: str = Field(description="Artifact title.")
    type: str = Field(default="code", description="Artifact type (code, markdown, html, svg).")
    content: str = Field(description="Artifact body content.")
    summary: str = Field(default="Initial version")


class UpdateArtifactArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    artifact_id: str = Field(description="Existing artifact ID to update.")
    content: str = Field(description="Updated artifact body content.")
    summary: str = Field(default="Updated artifact")


class MemorySearchArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    query: str = Field(description="Search query for user/project memories.")
    scope: Literal["user", "project"] = "user"
    limit: int = Field(default=5, ge=1, le=20)


class MemorySaveArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    text: str = Field(description="Fact or preference to save in memory.")
    scope: Literal["user", "project"] = "user"
    pinned: bool = False


class LoadSkillArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    name: str = Field(description="Name of the skill to load.")


class DiscoverToolsArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    query: str = Field(description="Keyword query describing the needed capability.")
    limit: int = Field(default=5, ge=1, le=15)


class SpawnAgentArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    task: str = Field(description="Focused sub-task for the child agent to complete.")
    preset: str = Field(default="researcher", description="Sub-agent preset name.")
    budget: dict[str, Any] | None = Field(
        default=None,
        description="Optional budget dict (max_tokens, max_tool_calls, max_seconds).",
    )
    max_iters: int = Field(default=4, ge=1, le=10)
    max_tokens: int = Field(default=4096, ge=128, le=32768)
    max_seconds: int = Field(default=30, ge=1, le=120)


class AdminDiagnosticsArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    section: str = Field(default="overview")


class StubDomainArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    query: str = Field(default="")


class EmailSearchArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    query: str = Field(default="", description="Mail search query (e.g. from:alice is:unread).")
    folder: str | None = Field(default=None, description="Optional folder filter.")


class EmailReadArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    message_id: str = Field(default="mail_seed_1", description="Message ID to read.")


class EmailDraftReplyArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    message_id: str = Field(default="mail_seed_1", description="Message ID to draft a reply to.")
    body_text: str = Field(default="", description="Draft reply body text.")


class EmailSendArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    to: list[str] = Field(default_factory=list, description="Recipient email addresses.")
    subject: str = Field(default="", description="Email subject.")
    body_text: str = Field(default="", description="Email body text.")
    idempotency_key: str | None = Field(default=None, description="Idempotency key.")


class EmailTagArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    message_id: str = Field(default="mail_seed_1", description="Message ID to triage/tag.")


class NotesSearchArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    query: str = Field(default="", description="Full-text or semantic note search query.")
    tag: str | None = Field(default=None)


class NotesReadArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    note_id: str = Field(default="", description="Note ID to read.")


class NotesCreateArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    title: str = Field(default="Untitled Note", description="Note title.")
    content: str = Field(default="", description="Markdown content.")
    folder: str = Field(default="General")
    tags: list[str] = Field(default_factory=list)


class NotesUpdateArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    note_id: str = Field(description="Note ID to update.")
    title: str | None = None
    content: str | None = None


class TodosListArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    status: str | None = Field(default=None, description="Optional status filter.")


class TodosCreateArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    title: str = Field(default="New Task", description="Todo title.")
    description: str = Field(default="")
    due_date: str | None = None
    priority: str = Field(default="medium")


class TodosUpdateArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    todo_id: str = Field(description="Todo ID to update.")
    title: str | None = None
    status: str | None = None
    priority: str | None = None


class TodosCompleteArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    todo_id: str = Field(description="Todo ID to complete.")


class CalendarListArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    query: str = Field(default="")


class CalendarCreateArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    title: str = Field(default="New Meeting", description="Event title.")
    start_local: str = Field(default="2026-10-06T14:00:00", description="Local start ISO.")
    duration_minutes: int = Field(default=60, ge=5, le=1440)
    timezone: str = Field(default="UTC")
    rrule: str | None = None


class CalendarUpdateArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    event_id: str = Field(description="Event ID to update.")
    title: str | None = None
    start_local: str | None = None


class CalendarDeleteArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    event_id: str = Field(description="Event ID to delete.")


class CalendarFreeBusyArgs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    day_iso: str = Field(default="2026-10-05", description="Date (YYYY-MM-DD) to check free/busy.")
    timezone: str = Field(default="UTC")


class ToolRegistry:
    """Central registry of built-in and dynamically discovered MCP tools."""

    def __init__(self) -> None:
        from backend.domain.calendar.service import CalendarService
        from backend.domain.mail.service import MailService
        from backend.domain.notes.service import NotesAndTodosService

        self._tools: dict[str, RegisteredTool] = {}
        self.mail_service = MailService()
        self.notes_service = NotesAndTodosService()
        self.calendar_service = CalendarService()
        self._register_builtins()

    def register(self, tool: RegisteredTool) -> None:
        self._tools[tool.definition.name] = tool

    def get(self, name: str) -> RegisteredTool | None:
        return self._tools.get(name)

    def list_tools(self, *, enabled_only: bool = True) -> list[RegisteredTool]:
        items = list(self._tools.values())
        if enabled_only:
            items = [t for t in items if t.definition.enabled]
        return sorted(items, key=lambda t: t.definition.name)

    def list_provider_specs(self, *, enabled_only: bool = True) -> list[ProviderToolSpec]:
        return [t.to_provider_spec() for t in self.list_tools(enabled_only=enabled_only)]

    def search_tools(self, query: str, *, limit: int = 5) -> list[RegisteredTool]:
        enabled = self.list_tools(enabled_only=True)
        specs = [t.to_provider_spec() for t in enabled]
        from backend.domain.agents.context import select_relevant_tools

        matched_specs = select_relevant_tools(
            specs,
            query_text=query,
            top_k=limit,
            always_on=(),
        )
        by_name = {t.definition.name: t for t in enabled}
        return [by_name[s.name] for s in matched_specs if s.name in by_name]

    def _register_builtins(self) -> None:
        # 1. read_file
        async def _h_read_file(
            ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = ReadFileArgs.model_validate(args)
            root = get_user_workspace_root(ctx.settings.data_dir, ctx.user_id)
            res = workspace_read_file(root, parsed.path, offset=parsed.offset, limit=parsed.limit)
            return ToolExecutionOutput(
                ok=True,
                summary=f"Read {res['path']} ({res['total_lines']} lines)",
                full_output=str(res["content"]),
                render_hint="text",
                provenance=ProvenanceTag(source="file", trust="untrusted"),
                truncated_by_tool=bool(res["truncated"]),
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="read_file",
                    risk="read",
                    required_privilege="files",
                    default_approval="auto",
                    description="Read lines from a UTF-8 file inside the user's workspace.",
                    render_hint="text",
                    idempotent=True,
                ),
                args_schema=ReadFileArgs,
                handler=_h_read_file,
                explain_fn=lambda a: f"Read workspace file '{a.get('path', '')}'",
            )
        )

        # 2. write_file
        async def _h_write_file(
            ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = WriteFileArgs.model_validate(args)
            root = get_user_workspace_root(ctx.settings.data_dir, ctx.user_id)
            res = workspace_write_file(root, parsed.path, parsed.content)
            return ToolExecutionOutput(
                ok=True,
                summary=f"Wrote {res['bytes_written']} bytes to {res['path']}",
                full_output=json.dumps(res),
                render_hint="text",
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="write_file",
                    risk="write",
                    required_privilege="files",
                    default_approval="ask",
                    description="Create or overwrite a file inside the user's workspace.",
                    render_hint="text",
                ),
                args_schema=WriteFileArgs,
                handler=_h_write_file,
                explain_fn=lambda a: (
                    f"Write {len(str(a.get('content', '')))} chars "
                    f"to workspace file '{a.get('path', '')}'"
                ),
            )
        )

        # 3. edit_file
        async def _h_edit_file(
            ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = EditFileArgs.model_validate(args)
            root = get_user_workspace_root(ctx.settings.data_dir, ctx.user_id)
            res = workspace_edit_file(root, parsed.path, parsed.old_text, parsed.new_text)
            return ToolExecutionOutput(
                ok=True,
                summary=f"Edited {res['path']}",
                full_output=str(res["diff"]),
                render_hint="diff",
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="edit_file",
                    risk="write",
                    required_privilege="files",
                    default_approval="ask",
                    description="Replace a unique text span in a workspace file and return a diff.",
                    render_hint="diff",
                ),
                args_schema=EditFileArgs,
                handler=_h_edit_file,
                explain_fn=lambda a: f"Edit workspace file '{a.get('path', '')}'",
            )
        )

        # 4. list_dir
        async def _h_list_dir(
            ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = ListDirArgs.model_validate(args)
            root = get_user_workspace_root(ctx.settings.data_dir, ctx.user_id)
            res = workspace_list_dir(root, parsed.path)
            entries = res["entries"]
            assert isinstance(entries, list)
            return ToolExecutionOutput(
                ok=True,
                summary=f"Listed {len(entries)} entries in {res['path']}",
                full_output=json.dumps(res, indent=2),
                render_hint="file_tree",
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="list_dir",
                    risk="read",
                    required_privilege="files",
                    default_approval="auto",
                    description="List files and subdirectories inside the user's workspace.",
                    render_hint="file_tree",
                    idempotent=True,
                ),
                args_schema=ListDirArgs,
                handler=_h_list_dir,
                explain_fn=lambda a: f"List workspace directory '{a.get('path', '.')}'",
            )
        )

        # 5. glob
        async def _h_glob(ctx: ToolExecutionContext, args: dict[str, Any]) -> ToolExecutionOutput:
            parsed = GlobArgs.model_validate(args)
            root = get_user_workspace_root(ctx.settings.data_dir, ctx.user_id)
            res = workspace_glob(root, parsed.pattern, parsed.path)
            matches = res["matches"]
            assert isinstance(matches, list)
            return ToolExecutionOutput(
                ok=True,
                summary=f"Found {len(matches)} files matching '{parsed.pattern}'",
                full_output=json.dumps(res, indent=2),
                render_hint="json",
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="glob",
                    risk="read",
                    required_privilege="files",
                    default_approval="auto",
                    description="Find workspace files matching a glob pattern.",
                    render_hint="json",
                    idempotent=True,
                ),
                args_schema=GlobArgs,
                handler=_h_glob,
                explain_fn=lambda a: (
                    f"Match glob '{a.get('pattern', '')}' in '{a.get('path', '.')}'"
                ),
            )
        )

        # 6. grep
        async def _h_grep(ctx: ToolExecutionContext, args: dict[str, Any]) -> ToolExecutionOutput:
            parsed = GrepArgs.model_validate(args)
            root = get_user_workspace_root(ctx.settings.data_dir, ctx.user_id)
            res = workspace_grep(root, parsed.pattern, parsed.path, max_results=parsed.max_results)
            hits = res["hits"]
            assert isinstance(hits, list)
            return ToolExecutionOutput(
                ok=True,
                summary=f"Found {len(hits)} matches for '{parsed.pattern}'",
                full_output=json.dumps(res, indent=2),
                render_hint="search_results",
                provenance=ProvenanceTag(source="file", trust="untrusted"),
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="grep",
                    risk="read",
                    required_privilege="files",
                    default_approval="auto",
                    description="Search for regex or text matches across workspace files.",
                    render_hint="search_results",
                    idempotent=True,
                ),
                args_schema=GrepArgs,
                handler=_h_grep,
                explain_fn=lambda a: (
                    f"Search pattern '{a.get('pattern', '')}' in '{a.get('path', '.')}'"
                ),
            )
        )

        # 7. read_tool_output
        async def _h_read_tool_output(
            ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = ReadToolOutputArgs.model_validate(args)
            sliced = read_tool_output_slice(
                ctx.settings.data_dir,
                parsed.call_id,
                offset=parsed.offset,
                length=parsed.length,
            )
            return ToolExecutionOutput(
                ok=True,
                summary=(
                    f"Read {sliced['length']} bytes from {parsed.call_id} "
                    f"at offset {sliced['offset']}"
                ),
                full_output=str(sliced["text"]),
                render_hint="text",
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="read_tool_output",
                    risk="read",
                    required_privilege="chat",
                    default_approval="auto",
                    description="Read a byte range from a truncated tool call output blob.",
                    render_hint="text",
                    idempotent=True,
                ),
                args_schema=ReadToolOutputArgs,
                handler=_h_read_tool_output,
                explain_fn=lambda a: (
                    f"Read output of tool call '{a.get('call_id', '')}' "
                    f"(offset={a.get('offset', 0)}, length={a.get('length', 4096)})"
                ),
            )
        )

        # 8. shell
        async def _h_shell(ctx: ToolExecutionContext, args: dict[str, Any]) -> ToolExecutionOutput:
            parsed = ShellArgs.model_validate(args)
            root = get_user_workspace_root(ctx.settings.data_dir, ctx.user_id)
            t_sec = min(parsed.timeout_seconds, ctx.settings.tool_default_timeout_seconds)
            res = await run_sandboxed_shell(
                parsed.command,
                workspace_root=root,
                timeout_seconds=t_sec,
                max_output_bytes=ctx.settings.tool_max_output_bytes,
                cpu_seconds=ctx.settings.sandbox_cpu_seconds,
                max_fsize_bytes=ctx.settings.sandbox_max_fsize_bytes,
                max_nproc=ctx.settings.sandbox_max_nproc,
                backend=ctx.settings.sandbox_backend,
                cancel_event=ctx.cancel_event,
                on_output_delta=ctx.on_output_delta,
                on_pgid_started=ctx.on_pgid_started,
            )
            ok = res.exit_code == 0 and not res.timed_out
            summary = (
                f"Command exited with {res.exit_code} ({res.duration_ms} ms)"
                if not res.timed_out
                else f"Command timed out after {t_sec:.1f}s"
            )
            return ToolExecutionOutput(
                ok=ok,
                summary=summary,
                full_output=res.combined_output or f"(exit {res.exit_code})",
                render_hint="terminal",
                truncated_by_tool=res.truncated,
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="shell",
                    risk="exec",
                    required_privilege="shell",
                    default_approval="ask",
                    description="Execute a shell command in the isolated workspace sandbox.",
                    render_hint="terminal",
                ),
                args_schema=ShellArgs,
                handler=_h_shell,
                explain_fn=lambda a: f"Execute shell command: {a.get('command', '')}",
            )
        )

        # 9. python
        async def _h_python(ctx: ToolExecutionContext, args: dict[str, Any]) -> ToolExecutionOutput:
            parsed = PythonArgs.model_validate(args)
            root = get_user_workspace_root(ctx.settings.data_dir, ctx.user_id)
            t_sec = min(parsed.timeout_seconds, ctx.settings.tool_default_timeout_seconds)
            res = await run_sandboxed_python(
                parsed.code,
                workspace_root=root,
                allow_network=False,
                timeout_seconds=t_sec,
                max_output_bytes=ctx.settings.tool_max_output_bytes,
                cpu_seconds=ctx.settings.sandbox_cpu_seconds,
                max_fsize_bytes=ctx.settings.sandbox_max_fsize_bytes,
                max_nproc=ctx.settings.sandbox_max_nproc,
                backend=ctx.settings.sandbox_backend,
                cancel_event=ctx.cancel_event,
                on_output_delta=ctx.on_output_delta,
                on_pgid_started=ctx.on_pgid_started,
            )
            ok = res.exit_code == 0 and not res.timed_out
            return ToolExecutionOutput(
                ok=ok,
                summary=f"Python exited with {res.exit_code} ({res.duration_ms} ms)",
                full_output=res.combined_output or f"(exit {res.exit_code})",
                render_hint="terminal",
                truncated_by_tool=res.truncated,
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="python",
                    risk="exec",
                    required_privilege="shell",
                    default_approval="ask",
                    description="Run Python code inside the isolated workspace sandbox.",
                    render_hint="terminal",
                ),
                args_schema=PythonArgs,
                handler=_h_python,
                explain_fn=lambda a: f"Execute Python snippet: {str(a.get('code', ''))[:120]}",
            )
        )

        # 10. web_search
        async def _h_web_search(
            ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = WebSearchArgs.model_validate(args)
            results = await execute_web_search(
                parsed.query,
                max_results=parsed.max_results,
                searxng_url=ctx.settings.searxng_url,
                transport=ctx.http_transport,
            )
            extra: list[tuple[EventTypeLiteral, dict[str, Any]]] = []
            for idx, item in enumerate(results[:3], start=1):
                extra.append(
                    (
                        "citation.added",
                        {
                            "citation": {
                                "id": f"cit_{ctx.call_id}_{idx}",
                                "source": "web",
                                "url": item["url"],
                                "title": item["title"],
                                "snippet": item["snippet"][:200],
                            }
                        },
                    )
                )
            return ToolExecutionOutput(
                ok=True,
                summary=f"Found {len(results)} web results for '{parsed.query}'",
                full_output=json.dumps({"query": parsed.query, "results": results}, indent=2),
                render_hint="search_results",
                provenance=ProvenanceTag(source="web", trust="untrusted"),
                extra_events=extra,
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="web_search",
                    risk="network",
                    required_privilege="chat",
                    default_approval="ask",
                    description="Search the web for current information.",
                    render_hint="search_results",
                    idempotent=True,
                ),
                args_schema=WebSearchArgs,
                handler=_h_web_search,
                explain_fn=lambda a: f"Search the web for '{a.get('query', '')}'",
            )
        )

        # 11. fetch_url
        async def _h_fetch_url(
            ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = FetchUrlArgs.model_validate(args)
            page = await safe_fetch_url(
                parsed.url,
                max_bytes=ctx.settings.tool_max_output_bytes,
                timeout_seconds=ctx.settings.tool_default_timeout_seconds,
                transport=ctx.http_transport,
                resolve_dns=ctx.resolve_dns,
            )
            extra: list[tuple[EventTypeLiteral, dict[str, Any]]] = [
                ("source.opened", {"url": page.url, "title": page.title}),
                (
                    "citation.added",
                    {
                        "citation": {
                            "id": f"cit_{ctx.call_id}",
                            "source": "web",
                            "url": page.url,
                            "title": page.title,
                            "snippet": page.content[:200],
                        }
                    },
                ),
            ]
            return ToolExecutionOutput(
                ok=page.status_code < 400,
                summary=f"Fetched {page.url} ({page.bytes_read} bytes, HTTP {page.status_code})",
                full_output=page.content,
                render_hint="text",
                provenance=ProvenanceTag(source="web", trust="untrusted"),
                truncated_by_tool=page.truncated,
                extra_events=extra,
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="fetch_url",
                    risk="network",
                    required_privilege="chat",
                    default_approval="ask",
                    description="Fetch and extract readable text from an external HTTP/HTTPS URL.",
                    render_hint="text",
                    idempotent=True,
                ),
                args_schema=FetchUrlArgs,
                handler=_h_fetch_url,
                explain_fn=lambda a: f"Fetch external URL '{a.get('url', '')}'",
            )
        )

        # 12. youtube_transcript
        async def _h_youtube_transcript(
            ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = YoutubeTranscriptArgs.model_validate(args)
            vid = extract_youtube_video_id(parsed.video_url)
            transcript = f"[Transcript for YouTube video {vid}]"
            return ToolExecutionOutput(
                ok=True,
                summary=f"Retrieved transcript for video {vid}",
                full_output=transcript,
                render_hint="text",
                provenance=ProvenanceTag(source="web", trust="untrusted"),
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="youtube_transcript",
                    risk="network",
                    required_privilege="chat",
                    default_approval="ask",
                    description="Fetch the transcript for a YouTube video URL or 11-char ID.",
                    render_hint="text",
                    idempotent=True,
                ),
                args_schema=YoutubeTranscriptArgs,
                handler=_h_youtube_transcript,
                explain_fn=lambda a: f"Fetch YouTube transcript for '{a.get('video_url', '')}'",
            )
        )

        # 13. update_plan (backbone of agent timeline; never executes side effects!)
        async def _h_update_plan(
            _ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = UpdatePlanArgs.model_validate(args)
            items_dump = [
                {"id": it.id, "title": it.title, "status": it.status} for it in parsed.items
            ]
            return ToolExecutionOutput(
                ok=True,
                summary=f"Updated plan ({len(items_dump)} items)",
                full_output=json.dumps({"items": items_dump}),
                render_hint="json",
                extra_events=[("plan.updated", {"items": items_dump})],
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="update_plan",
                    risk="read",
                    required_privilege="chat",
                    default_approval="auto",
                    description="Update the run's structured to-do plan items (no side effects).",
                    render_hint="json",
                    idempotent=True,
                ),
                args_schema=UpdatePlanArgs,
                handler=_h_update_plan,
                explain_fn=lambda a: f"Update plan with {len(a.get('items', []))} items",
            )
        )

        # 14. create_artifact
        async def _h_create_artifact(
            ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = CreateArtifactArgs.model_validate(args)
            art_id = f"art_{uuid.uuid4().hex[:16]}"
            now = datetime.now(UTC)

            async def _tx(sess: AsyncSession) -> None:
                uow = UnitOfWork(sess)
                await uow.artifacts.add_artifact(
                    ArtifactRecord(
                        id=art_id,
                        user_id=ctx.user_id,
                        chat_id=ctx.chat_id,
                        run_id=ctx.run_id,
                        type=parsed.type,
                        title=parsed.title,
                        latest_version=1,
                        created_at=now,
                        updated_at=now,
                    )
                )
                await uow.artifacts.add_version(
                    ArtifactVersionRecord(
                        id=f"artv_{uuid.uuid4().hex[:16]}",
                        artifact_id=art_id,
                        version=1,
                        content=parsed.content,
                        summary=parsed.summary,
                        created_by="run",
                        parent_version=None,
                        created_at=now,
                    )
                )

            await ctx.db.execute_write(_tx)
            extra: list[tuple[EventTypeLiteral, dict[str, Any]]] = [
                (
                    "artifact.created",
                    {"artifact_id": art_id, "type": parsed.type, "title": parsed.title},
                ),
                (
                    "artifact.delta",
                    {"artifact_id": art_id, "version": 1, "text": parsed.content},
                ),
                (
                    "artifact.version",
                    {"artifact_id": art_id, "version": 1, "summary": parsed.summary},
                ),
            ]
            return ToolExecutionOutput(
                ok=True,
                summary=f"Created artifact '{parsed.title}' ({art_id}@v1)",
                full_output=json.dumps(
                    {"artifact_id": art_id, "version": 1, "title": parsed.title}
                ),
                render_hint="json",
                extra_events=extra,
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="create_artifact",
                    risk="write",
                    required_privilege="chat",
                    default_approval="auto",
                    description="Create a versioned artifact (code, markdown, html, svg).",
                    render_hint="json",
                ),
                args_schema=CreateArtifactArgs,
                handler=_h_create_artifact,
                explain_fn=lambda a: f"Create artifact '{a.get('title', '')}'",
            )
        )

        # 15. update_artifact
        async def _h_update_artifact(
            ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = UpdateArtifactArgs.model_validate(args)
            now = datetime.now(UTC)

            async def _tx(sess: AsyncSession) -> int:
                uow = UnitOfWork(sess)
                art = await uow.artifacts.get(parsed.artifact_id)
                if art is None or art.user_id != ctx.user_id:
                    raise LookupError(f"Artifact '{parsed.artifact_id}' not found")
                new_ver = art.latest_version + 1
                art.latest_version = new_ver
                art.updated_at = now
                await uow.artifacts.add_version(
                    ArtifactVersionRecord(
                        id=f"artv_{uuid.uuid4().hex[:16]}",
                        artifact_id=art.id,
                        version=new_ver,
                        content=parsed.content,
                        summary=parsed.summary,
                        created_by="run",
                        parent_version=new_ver - 1,
                        created_at=now,
                    )
                )
                return new_ver

            ver = await ctx.db.execute_write(_tx)
            extra: list[tuple[EventTypeLiteral, dict[str, Any]]] = [
                (
                    "artifact.delta",
                    {
                        "artifact_id": parsed.artifact_id,
                        "version": ver,
                        "text": parsed.content,
                    },
                ),
                (
                    "artifact.version",
                    {
                        "artifact_id": parsed.artifact_id,
                        "version": ver,
                        "summary": parsed.summary,
                    },
                ),
            ]
            return ToolExecutionOutput(
                ok=True,
                summary=f"Updated artifact {parsed.artifact_id} to v{ver}",
                full_output=json.dumps({"artifact_id": parsed.artifact_id, "version": ver}),
                render_hint="json",
                extra_events=extra,
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="update_artifact",
                    risk="write",
                    required_privilege="chat",
                    default_approval="auto",
                    description="Create a new version of an existing artifact.",
                    render_hint="json",
                ),
                args_schema=UpdateArtifactArgs,
                handler=_h_update_artifact,
                explain_fn=lambda a: f"Update artifact '{a.get('artifact_id', '')}'",
            )
        )

        # 16. memory_search
        async def _h_memory_search(
            ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = MemorySearchArgs.model_validate(args)
            mem_svc = ctx.memory_service or MemoryService(ctx.db, ctx.settings)
            results = await mem_svc.search_memories(
                user_id=ctx.user_id,
                query=parsed.query,
                scope=parsed.scope,
                limit=parsed.limit,
            )
            ids = [str(r["id"]) for r in results]
            extra: list[tuple[EventTypeLiteral, dict[str, Any]]] = []
            if ids:
                extra.append(("memory.used", {"ids": ids}))
            return ToolExecutionOutput(
                ok=True,
                summary=f"Found {len(results)} memories matching '{parsed.query}'",
                full_output=json.dumps({"query": parsed.query, "memories": results}, indent=2),
                render_hint="search_results",
                provenance=ProvenanceTag(source="memory", trust="untrusted"),
                extra_events=extra,
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="memory_search",
                    risk="read",
                    required_privilege="chat",
                    default_approval="auto",
                    description="Search semantic and BM25 keyword memories.",
                    render_hint="search_results",
                    idempotent=True,
                ),
                args_schema=MemorySearchArgs,
                handler=_h_memory_search,
                explain_fn=lambda a: f"Search memories for '{a.get('query', '')}'",
            )
        )

        # 17. memory_save
        async def _h_memory_save(
            ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = MemorySaveArgs.model_validate(args)
            mem_svc = ctx.memory_service or MemoryService(ctx.db, ctx.settings)
            saved, op = await mem_svc.save_memory(
                user_id=ctx.user_id,
                text=parsed.text,
                scope=parsed.scope,
                source_chat_id=ctx.chat_id,
                source_run_id=ctx.run_id,
                pinned=parsed.pinned,
                confirmed=True,
            )
            if saved is None:
                return ToolExecutionOutput(
                    ok=True,
                    summary="Memory privacy switch is disabled; nothing saved",
                    full_output=json.dumps({"saved": False, "reason": "privacy_disabled"}),
                    render_hint="json",
                )
            return ToolExecutionOutput(
                ok=True,
                summary=f"Memory {op}: {saved['id']}",
                full_output=json.dumps(saved),
                render_hint="json",
                extra_events=[("memory.updated", {"id": saved["id"], "op": op})],
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="memory_save",
                    risk="write",
                    required_privilege="chat",
                    default_approval="auto",
                    description="Save or update a user/project memory entry.",
                    render_hint="json",
                ),
                args_schema=MemorySaveArgs,
                handler=_h_memory_save,
                explain_fn=lambda a: f"Save memory: {str(a.get('text', ''))[:80]}",
            )
        )

        # 18. load_skill
        async def _h_load_skill(
            ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = LoadSkillArgs.model_validate(args)
            sk_svc = ctx.skill_service or SkillService(ctx.db)
            skill = await sk_svc.load_skill_body(
                name=parsed.name,
                user_id=ctx.user_id,
                user_privileges=ctx.user_privileges,
            )
            is_untrusted = bool(skill.get("untrusted")) and not bool(skill.get("reviewed"))
            prov = (
                ProvenanceTag(source="skill_import", trust="untrusted")
                if is_untrusted
                else ProvenanceTag(source="system", trust="trusted")
            )
            return ToolExecutionOutput(
                ok=True,
                summary=f"Loaded skill '{parsed.name}' (v{skill['version']})",
                full_output=str(skill.get("body_markdown", "")),
                render_hint="text",
                provenance=prov,
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="load_skill",
                    risk="read",
                    required_privilege="chat",
                    default_approval="auto",
                    description="Load the full Markdown instructions for a named skill on demand.",
                    render_hint="text",
                    idempotent=True,
                ),
                args_schema=LoadSkillArgs,
                handler=_h_load_skill,
                explain_fn=lambda a: f"Load skill '{a.get('name', '')}'",
            )
        )

        # 19. discover_tools
        async def _h_discover_tools(
            ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = DiscoverToolsArgs.model_validate(args)
            found = self.search_tools(parsed.query, limit=parsed.limit)
            names = [t.definition.name for t in found]
            if ctx.on_discover_tools is not None:
                ctx.on_discover_tools(names)
            payload = [
                {
                    "name": t.definition.name,
                    "risk": t.definition.risk,
                    "description": t.definition.description,
                }
                for t in found
            ]
            return ToolExecutionOutput(
                ok=True,
                summary=f"Discovered {len(payload)} tools for '{parsed.query}'",
                full_output=json.dumps({"tools": payload}, indent=2),
                render_hint="json",
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="discover_tools",
                    risk="read",
                    required_privilege="chat",
                    default_approval="auto",
                    description="Search the tool catalog to activate tools for the next step.",
                    render_hint="json",
                    idempotent=True,
                ),
                args_schema=DiscoverToolsArgs,
                handler=_h_discover_tools,
                explain_fn=lambda a: f"Discover tools matching '{a.get('query', '')}'",
            )
        )

        # 20. spawn_agent (sub-agents)
        async def _h_spawn_agent(
            ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = SpawnAgentArgs.model_validate(args)
            if ctx.spawn_subagent_fn is None:
                raise RuntimeError("Sub-agent spawning is not enabled in this context")
            res = await ctx.spawn_subagent_fn(parsed.model_dump())
            summary_txt = str(res.get("summary", ""))
            child_id = str(res.get("child_run_id", ""))
            return ToolExecutionOutput(
                ok=res.get("status") in ("succeeded", "completed"),
                summary=f"Sub-agent {child_id} finished: {summary_txt[:120]}",
                full_output=summary_txt,
                render_hint="text",
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="spawn_agent",
                    risk="read",
                    required_privilege="agent",
                    default_approval="auto",
                    description=(
                        "Spawn a child sub-agent with a reduced toolset and budget; "
                        "returns summary only."
                    ),
                    render_hint="text",
                ),
                args_schema=SpawnAgentArgs,
                handler=_h_spawn_agent,
                explain_fn=lambda a: f"Spawn sub-agent for task: {str(a.get('task', ''))[:100]}",
            )
        )

        # 21. admin_system_diagnostics (admin-risk tool for confused-deputy defense testing)
        async def _h_admin_diag(
            ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = AdminDiagnosticsArgs.model_validate(args)
            return ToolExecutionOutput(
                ok=True,
                summary=f"Admin diagnostics ({parsed.section})",
                full_output=json.dumps(
                    {"section": parsed.section, "environment": ctx.settings.environment}
                ),
                render_hint="json",
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="admin_system_diagnostics",
                    risk="admin",
                    required_privilege="admin",
                    default_approval="ask",
                    description="Inspect privileged system diagnostics (admin only).",
                    render_hint="json",
                    idempotent=True,
                ),
                args_schema=AdminDiagnosticsArgs,
                handler=_h_admin_diag,
                explain_fn=lambda a: f"Run admin diagnostics ({a.get('section', 'overview')})",
            )
        )

        # 22. Phase-07 Productivity Suite Tools (Email, Notes, Todos, Calendar)
        async def _h_email_search(
            ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = EmailSearchArgs.model_validate(args)
            hits = self.mail_service.search_messages(
                parsed.query,
                owner_user_id=ctx.user_id,
                folder=parsed.folder,
            )
            return ToolExecutionOutput(
                ok=True,
                summary=f"Found {len(hits)} email messages for '{parsed.query}'",
                full_output=json.dumps({"messages": hits}, indent=2),
                render_hint="json",
                provenance=ProvenanceTag(source="email", trust="untrusted"),
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="email_search",
                    risk="read",
                    required_privilege="chat",
                    default_approval="auto",
                    description="Search mailbox messages using from:, is:unread, or text.",
                    render_hint="json",
                    idempotent=True,
                ),
                args_schema=EmailSearchArgs,
                handler=_h_email_search,
                explain_fn=lambda a: f"Search emails for '{a.get('query', '')}'",
            )
        )

        async def _h_email_read(
            ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = EmailReadArgs.model_validate(args)
            msg = self.mail_service.get_message(parsed.message_id, owner_user_id=ctx.user_id)
            sender = str(msg.get("sender", "unknown"))
            return ToolExecutionOutput(
                ok=True,
                summary=f"Read email '{msg.get('subject', '')}' from {sender}",
                full_output=json.dumps(msg, indent=2),
                render_hint="json",
                provenance=ProvenanceTag(source=f"email:{sender}", trust="untrusted"),
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="email_read",
                    risk="read",
                    required_privilege="chat",
                    default_approval="auto",
                    description="Read a sanitized email message by ID.",
                    render_hint="json",
                    idempotent=True,
                ),
                args_schema=EmailReadArgs,
                handler=_h_email_read,
                explain_fn=lambda a: f"Read email message '{a.get('message_id', '')}'",
            )
        )

        async def _h_email_draft_reply(
            ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = EmailDraftReplyArgs.model_validate(args)
            triage = self.mail_service.triage_message(parsed.message_id, owner_user_id=ctx.user_id)
            return ToolExecutionOutput(
                ok=True,
                summary=f"Created draft reply {triage.draft_reply_id} (never auto-sent)",
                full_output=json.dumps(triage.to_dict(), indent=2),
                render_hint="json",
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="email_draft_reply",
                    risk="write",
                    required_privilege="chat",
                    default_approval="ask",
                    description="Create a draft reply in Drafts without sending.",
                    render_hint="json",
                ),
                args_schema=EmailDraftReplyArgs,
                handler=_h_email_draft_reply,
                explain_fn=lambda a: f"Draft reply to email '{a.get('message_id', '')}'",
            )
        )

        async def _h_email_send(
            ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = EmailSendArgs.model_validate(args)
            res = self.mail_service.send_message(
                owner_user_id=ctx.user_id,
                to=parsed.to or ["recipient@example.com"],
                subject=parsed.subject,
                body_text=parsed.body_text,
                idempotency_key=parsed.idempotency_key,
            )
            return ToolExecutionOutput(
                ok=True,
                summary=f"Sent email '{parsed.subject}' to {', '.join(parsed.to)}",
                full_output=json.dumps(res, indent=2),
                render_hint="json",
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="email_send",
                    risk="exec",
                    required_privilege="chat",
                    default_approval="ask",
                    description="Send an outgoing email (exec-risk: always requires approval).",
                    render_hint="json",
                ),
                args_schema=EmailSendArgs,
                handler=_h_email_send,
                explain_fn=lambda a: (
                    f"Send email to {a.get('to', [])} with subject '{a.get('subject', '')}'"
                ),
            )
        )

        async def _h_email_tag(
            ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = EmailTagArgs.model_validate(args)
            triage = self.mail_service.triage_message(parsed.message_id, owner_user_id=ctx.user_id)
            return ToolExecutionOutput(
                ok=True,
                summary=f"Tagged email {parsed.message_id}: {', '.join(triage.tags)}",
                full_output=json.dumps(triage.to_dict(), indent=2),
                render_hint="json",
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="email_tag",
                    risk="write",
                    required_privilege="chat",
                    default_approval="ask",
                    description="Run supervised triage tagging on an email message.",
                    render_hint="json",
                ),
                args_schema=EmailTagArgs,
                handler=_h_email_tag,
                explain_fn=lambda a: f"Tag/triage email '{a.get('message_id', '')}'",
            )
        )

        async def _h_notes_search(
            ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = NotesSearchArgs.model_validate(args)
            notes = self.notes_service.search_notes(
                parsed.query, owner_user_id=ctx.user_id, tag=parsed.tag
            )
            return ToolExecutionOutput(
                ok=True,
                summary=f"Found {len(notes)} notes matching '{parsed.query}'",
                full_output=json.dumps({"notes": notes}, indent=2),
                render_hint="json",
            )

        for note_search_name in ("notes_search", "notes_list"):
            self.register(
                RegisteredTool(
                    definition=ToolDefinition(
                        name=note_search_name,
                        risk="read",
                        required_privilege="chat",
                        default_approval="auto",
                        description="Search or list Markdown notes and backlinks.",
                        render_hint="json",
                        idempotent=True,
                    ),
                    args_schema=NotesSearchArgs,
                    handler=_h_notes_search,
                    explain_fn=lambda a: f"Search notes for '{a.get('query', '')}'",
                )
            )

        async def _h_notes_read(
            _ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = NotesReadArgs.model_validate(args)
            note = self.notes_service.get_note(parsed.note_id)
            return ToolExecutionOutput(
                ok=True,
                summary=f"Read note '{note['title']}'",
                full_output=json.dumps(note, indent=2),
                render_hint="json",
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="notes_read",
                    risk="read",
                    required_privilege="chat",
                    default_approval="auto",
                    description="Read a Markdown note and its [[wikilinks]] backlinks.",
                    render_hint="json",
                    idempotent=True,
                ),
                args_schema=NotesReadArgs,
                handler=_h_notes_read,
                explain_fn=lambda a: f"Read note '{a.get('note_id', '')}'",
            )
        )

        async def _h_notes_create(
            ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = NotesCreateArgs.model_validate(args)
            created = self.notes_service.create_note(
                owner_user_id=ctx.user_id,
                title=parsed.title,
                content=parsed.content,
                folder=parsed.folder,
                tags=parsed.tags,
            )
            return ToolExecutionOutput(
                ok=True,
                summary=f"Created note '{created['title']}' ({created['id']})",
                full_output=json.dumps(created, indent=2),
                render_hint="json",
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="notes_create",
                    risk="write",
                    required_privilege="chat",
                    default_approval="ask",
                    description="Create a new Markdown note with [[wikilinks]].",
                    render_hint="json",
                ),
                args_schema=NotesCreateArgs,
                handler=_h_notes_create,
                explain_fn=lambda a: f"Create note '{a.get('title', '')}'",
            )
        )

        async def _h_notes_update(
            _ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = NotesUpdateArgs.model_validate(args)
            updated = self.notes_service.update_note(
                parsed.note_id,
                title=parsed.title,
                content=parsed.content,
            )
            return ToolExecutionOutput(
                ok=True,
                summary=f"Updated note '{updated['title']}' (v{updated['version_count']})",
                full_output=json.dumps(updated, indent=2),
                render_hint="json",
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="notes_update",
                    risk="write",
                    required_privilege="chat",
                    default_approval="ask",
                    description="Update an existing Markdown note and record a version snapshot.",
                    render_hint="json",
                ),
                args_schema=NotesUpdateArgs,
                handler=_h_notes_update,
                explain_fn=lambda a: f"Update note '{a.get('note_id', '')}'",
            )
        )

        async def _h_todos_list(
            ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = TodosListArgs.model_validate(args)
            items = self.notes_service.list_todos(owner_user_id=ctx.user_id, status=parsed.status)
            return ToolExecutionOutput(
                ok=True,
                summary=f"Listed {len(items)} todos",
                full_output=json.dumps({"todos": items}, indent=2),
                render_hint="json",
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="todos_list",
                    risk="read",
                    required_privilege="chat",
                    default_approval="auto",
                    description="List todos and Kanban task status.",
                    render_hint="json",
                    idempotent=True,
                ),
                args_schema=TodosListArgs,
                handler=_h_todos_list,
                explain_fn=lambda a: f"List todos (status={a.get('status', 'all')})",
            )
        )

        async def _h_todos_create(
            ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = TodosCreateArgs.model_validate(args)
            created = self.notes_service.create_todo(
                owner_user_id=ctx.user_id,
                title=parsed.title,
                description=parsed.description,
                due_date=parsed.due_date,
                priority=parsed.priority,
            )
            return ToolExecutionOutput(
                ok=True,
                summary=f"Created todo '{created['title']}' ({created['id']})",
                full_output=json.dumps(created, indent=2),
                render_hint="json",
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="todos_create",
                    risk="write",
                    required_privilege="chat",
                    default_approval="ask",
                    description="Create a new todo item.",
                    render_hint="json",
                ),
                args_schema=TodosCreateArgs,
                handler=_h_todos_create,
                explain_fn=lambda a: f"Create todo '{a.get('title', '')}'",
            )
        )

        async def _h_todos_update(
            _ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = TodosUpdateArgs.model_validate(args)
            updated = self.notes_service.update_todo(
                parsed.todo_id,
                title=parsed.title,
                status=parsed.status,
                priority=parsed.priority,
            )
            return ToolExecutionOutput(
                ok=True,
                summary=f"Updated todo '{updated['title']}'",
                full_output=json.dumps(updated, indent=2),
                render_hint="json",
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="todos_update",
                    risk="write",
                    required_privilege="chat",
                    default_approval="ask",
                    description="Update a todo's status, priority, or title.",
                    render_hint="json",
                ),
                args_schema=TodosUpdateArgs,
                handler=_h_todos_update,
                explain_fn=lambda a: f"Update todo '{a.get('todo_id', '')}'",
            )
        )

        async def _h_todos_complete(
            _ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = TodosCompleteArgs.model_validate(args)
            completed = self.notes_service.complete_todo(parsed.todo_id)
            return ToolExecutionOutput(
                ok=True,
                summary=f"Completed todo '{completed['title']}'",
                full_output=json.dumps(completed, indent=2),
                render_hint="json",
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="todos_complete",
                    risk="write",
                    required_privilege="chat",
                    default_approval="ask",
                    description="Mark a todo complete (spawning next recurring instance if set).",
                    render_hint="json",
                ),
                args_schema=TodosCompleteArgs,
                handler=_h_todos_complete,
                explain_fn=lambda a: f"Complete todo '{a.get('todo_id', '')}'",
            )
        )

        async def _h_calendar_list(
            ctx: ToolExecutionContext, _args: dict[str, Any]
        ) -> ToolExecutionOutput:
            events = self.calendar_service.list_events(owner_user_id=ctx.user_id)
            return ToolExecutionOutput(
                ok=True,
                summary=f"Listed {len(events)} calendar events",
                full_output=json.dumps({"events": events}, indent=2),
                render_hint="json",
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="calendar_list",
                    risk="read",
                    required_privilege="chat",
                    default_approval="auto",
                    description="List calendar events and upcoming RRULE occurrences.",
                    render_hint="json",
                    idempotent=True,
                ),
                args_schema=CalendarListArgs,
                handler=_h_calendar_list,
                explain_fn=lambda _a: "List calendar events",
            )
        )

        async def _h_calendar_create(
            ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = CalendarCreateArgs.model_validate(args)
            ev = self.calendar_service.create_event(
                owner_user_id=ctx.user_id,
                title=parsed.title,
                start_local=parsed.start_local,
                duration_minutes=parsed.duration_minutes,
                timezone=parsed.timezone,
                rrule=parsed.rrule,
            )
            return ToolExecutionOutput(
                ok=True,
                summary=f"Created calendar event '{ev['title']}' at {ev['start_local']}",
                full_output=json.dumps(ev, indent=2),
                render_hint="json",
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="calendar_create",
                    risk="write",
                    required_privilege="chat",
                    default_approval="ask",
                    description="Create a calendar event with optional RRULE recurrence.",
                    render_hint="json",
                ),
                args_schema=CalendarCreateArgs,
                handler=_h_calendar_create,
                explain_fn=lambda a: (
                    f"Create calendar event '{a.get('title', '')}' at '{a.get('start_local', '')}'"
                ),
            )
        )

        async def _h_calendar_update(
            _ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = CalendarUpdateArgs.model_validate(args)
            res = self.calendar_service.update_event(
                parsed.event_id,
                title=parsed.title,
                start_local=parsed.start_local,
            )
            return ToolExecutionOutput(
                ok=True,
                summary=f"Calendar update result: {res['status']}",
                full_output=json.dumps(res, indent=2),
                render_hint="json",
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="calendar_update",
                    risk="write",
                    required_privilege="chat",
                    default_approval="ask",
                    description="Update a calendar event with ETag conflict detection.",
                    render_hint="json",
                ),
                args_schema=CalendarUpdateArgs,
                handler=_h_calendar_update,
                explain_fn=lambda a: f"Update calendar event '{a.get('event_id', '')}'",
            )
        )

        async def _h_calendar_delete(
            _ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = CalendarDeleteArgs.model_validate(args)
            res = self.calendar_service.delete_event(parsed.event_id)
            return ToolExecutionOutput(
                ok=True,
                summary=f"Deleted calendar event {parsed.event_id}",
                full_output=json.dumps(res, indent=2),
                render_hint="json",
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="calendar_delete",
                    risk="write",
                    required_privilege="chat",
                    default_approval="ask",
                    description="Delete a calendar event by ID.",
                    render_hint="json",
                ),
                args_schema=CalendarDeleteArgs,
                handler=_h_calendar_delete,
                explain_fn=lambda a: f"Delete calendar event '{a.get('event_id', '')}'",
            )
        )

        async def _h_calendar_free_busy(
            _ctx: ToolExecutionContext, args: dict[str, Any]
        ) -> ToolExecutionOutput:
            parsed = CalendarFreeBusyArgs.model_validate(args)
            fb = self.calendar_service.find_free_busy_slots(
                day_iso=parsed.day_iso, timezone=parsed.timezone
            )
            return ToolExecutionOutput(
                ok=True,
                summary=f"Computed free/busy slots for {parsed.day_iso}",
                full_output=json.dumps(fb, indent=2),
                render_hint="json",
            )

        self.register(
            RegisteredTool(
                definition=ToolDefinition(
                    name="calendar_free_busy",
                    risk="read",
                    required_privilege="chat",
                    default_approval="auto",
                    description="Find free/busy time slots on a given date.",
                    render_hint="json",
                    idempotent=True,
                ),
                args_schema=CalendarFreeBusyArgs,
                handler=_h_calendar_free_busy,
                explain_fn=lambda a: f"Check free/busy slots for {a.get('day_iso', '')}",
            )
        )
