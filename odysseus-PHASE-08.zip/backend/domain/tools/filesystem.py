"""Workspace-jailed file tools with strict path-traversal and symlink escape defenses."""

from __future__ import annotations

import difflib
import fnmatch
import os
import re
import unicodedata
from pathlib import Path
from urllib.parse import unquote

_WINDOWS_DRIVE_RE = re.compile(r"^[A-Za-z]:")
_WINDOWS_RESERVED_NAMES = frozenset(
    {
        "CON",
        "PRN",
        "AUX",
        "NUL",
        "COM1",
        "COM2",
        "COM3",
        "COM4",
        "COM5",
        "COM6",
        "COM7",
        "COM8",
        "COM9",
        "LPT1",
        "LPT2",
        "LPT3",
        "LPT4",
        "LPT5",
        "LPT6",
        "LPT7",
        "LPT8",
        "LPT9",
    }
)


class WorkspaceEscapeError(PermissionError):
    """Raised when a file tool argument attempts to escape the per-user workspace root."""


def get_user_workspace_root(data_dir: Path, user_id: str) -> Path:
    """Return (and create if needed) the canonical per-user workspace directory."""
    safe_uid = re.sub(r"[^A-Za-z0-9_.-]", "_", user_id.strip())
    if not safe_uid or safe_uid in (".", ".."):
        raise WorkspaceEscapeError("Invalid user_id for workspace root")
    base = (data_dir / "workspaces").resolve()
    base.mkdir(parents=True, exist_ok=True)
    user_root = (base / safe_uid).resolve()
    if base not in user_root.parents:
        raise WorkspaceEscapeError("User workspace root escaped base workspaces directory")
    user_root.mkdir(parents=True, exist_ok=True)
    return user_root


def resolve_workspace_path(workspace_root: Path, raw_path: str) -> Path:
    """Resolve `raw_path` strictly inside `workspace_root`, blocking all >=60 escape vectors.

    Blocks:
    - Null bytes, control characters, bidi/zero-width characters
    - Unicode NFKC normalization tricks (fullwidth dots/slashes, homoglyph dots)
    - URL-encoded / double-URL-encoded traversal (%2e%2e, %2f, %5c, %00)
    - Absolute paths (/etc/passwd), UNC paths (\\\\server\\share, //server/share), file:// URIs
    - Windows drive letters (C:\\...) and reserved device names (CON, NUL, COM1, ...)
    - Tilde expansion (~, ~root)
    - Backslash separators and '..' segments
    - Symlink escapes (intermediate or leaf symlinks pointing outside workspace_root)
    """
    if not isinstance(raw_path, str):
        raise WorkspaceEscapeError("Path must be a string")

    if "\x00" in raw_path:
        raise WorkspaceEscapeError("Null byte in path is forbidden")

    for ch in raw_path:
        cp = ord(ch)
        if cp < 32 or cp == 127 or (0xE0000 <= cp <= 0xE007F):
            raise WorkspaceEscapeError("Control or tag character in path is forbidden")
        if unicodedata.category(ch) == "Cf":
            raise WorkspaceEscapeError("Format/bidi control character in path is forbidden")

    # Reject Unicode characters that NFKC-normalize into dots, slashes, backslashes, or tildes
    nfkc = unicodedata.normalize("NFKC", raw_path)
    if nfkc != raw_path:
        for orig_ch in raw_path:
            norm_ch = unicodedata.normalize("NFKC", orig_ch)
            if orig_ch != norm_ch and any(c in (".", "/", "\\", "~", ":") for c in norm_ch):
                raise WorkspaceEscapeError(
                    f"Unicode normalization traversal character rejected: {orig_ch!r}"
                )

    candidate = nfkc.strip()
    if not candidate:
        candidate = "."

    # Check URL-decoded variants for encoded traversal (%2e, %2f, %5c, %00)
    unquoted_once = unquote(candidate)
    unquoted_twice = unquote(unquoted_once)
    for variant in (candidate, unquoted_once, unquoted_twice):
        low = variant.lower()
        if "\x00" in variant or ".." in variant.replace("\\", "/").split("/"):
            raise WorkspaceEscapeError("Directory traversal ('..') is forbidden")
        if low.startswith(("file:", "http:", "https:", "ftp:")):
            raise WorkspaceEscapeError("URI schemes are forbidden in workspace paths")

    # Reject backslashes altogether to prevent Windows/POSIX parser mismatches
    if "\\" in candidate or "\\" in unquoted_once:
        raise WorkspaceEscapeError("Backslash path separators are forbidden")

    # Reject leading slashes, UNC paths, tilde expansion, and Windows drive letters
    if candidate.startswith("/") or unquoted_once.startswith("/"):
        raise WorkspaceEscapeError("Absolute paths starting with '/' are forbidden")
    if candidate.startswith("~") or unquoted_once.startswith("~"):
        raise WorkspaceEscapeError("Tilde ('~') home expansion is forbidden")
    if _WINDOWS_DRIVE_RE.match(candidate) or _WINDOWS_DRIVE_RE.match(unquoted_once):
        raise WorkspaceEscapeError("Windows drive letters are forbidden")

    root_real = workspace_root.resolve(strict=True)
    parts = [p for p in candidate.split("/") if p and p != "."]

    for part in parts:
        if part == ".." or part.startswith("..") or part.endswith(".."):
            raise WorkspaceEscapeError(f"Traversal segment {part!r} is forbidden")
        stem = part.split(".")[0].upper()
        if stem in _WINDOWS_RESERVED_NAMES:
            raise WorkspaceEscapeError(f"Reserved device name {part!r} is forbidden")

    # Walk each component and reject symlinks escaping workspace_root
    current = root_real
    for part in parts:
        next_path = current / part
        if os.path.islink(next_path):
            link_target = next_path.resolve(strict=False)
            try:
                link_target.relative_to(root_real)
            except ValueError as exc:
                raise WorkspaceEscapeError(
                    f"Symlink {part!r} points outside workspace root"
                ) from exc
        current = next_path

    resolved = current.resolve(strict=False)
    try:
        resolved.relative_to(root_real)
    except ValueError as exc:
        raise WorkspaceEscapeError("Resolved path escapes workspace root") from exc

    return resolved


def workspace_read_file(
    workspace_root: Path,
    path: str,
    *,
    offset: int = 1,
    limit: int = 200,
    max_bytes: int = 131072,
) -> dict[str, object]:
    """Read lines from a file inside the user's workspace jail."""
    target = resolve_workspace_path(workspace_root, path)
    if not target.exists():
        raise FileNotFoundError(f"File not found in workspace: {path}")
    if target.is_dir():
        raise IsADirectoryError(f"Path is a directory, not a file: {path}")
    if not target.is_file():
        raise WorkspaceEscapeError(f"Not a regular file (special/FIFO/device rejected): {path}")

    raw_bytes = target.read_bytes()
    truncated = False
    if len(raw_bytes) > max_bytes:
        raw_bytes = raw_bytes[:max_bytes]
        truncated = True

    text = raw_bytes.decode("utf-8", errors="replace")
    all_lines = text.splitlines()
    start_idx = max(0, offset - 1)
    end_idx = min(len(all_lines), start_idx + max(1, limit))
    selected = all_lines[start_idx:end_idx]
    numbered = "\n".join(f"{start_idx + i + 1:4d} | {line}" for i, line in enumerate(selected))
    rel = str(target.relative_to(workspace_root.resolve()))
    return {
        "path": rel,
        "content": numbered,
        "raw_content": "\n".join(selected),
        "total_lines": len(all_lines),
        "offset": offset,
        "limit": limit,
        "truncated": truncated or (end_idx < len(all_lines)),
    }


def workspace_write_file(
    workspace_root: Path,
    path: str,
    content: str,
    *,
    max_bytes: int = 1048576,
) -> dict[str, object]:
    """Create or overwrite a file inside the user's workspace jail."""
    target = resolve_workspace_path(workspace_root, path)
    if target.exists() and not target.is_file():
        raise WorkspaceEscapeError(f"Target exists and is not a regular file: {path}")
    encoded = content.encode("utf-8")
    if len(encoded) > max_bytes:
        raise ValueError(f"File content ({len(encoded)} B) exceeds limit ({max_bytes} B)")
    target.parent.mkdir(parents=True, exist_ok=True)
    # Re-verify parent after mkdir in case of race
    _ = target.parent.resolve(strict=True).relative_to(workspace_root.resolve(strict=True))
    target.write_bytes(encoded)
    rel = str(target.relative_to(workspace_root.resolve()))
    return {
        "path": rel,
        "bytes_written": len(encoded),
        "lines": len(content.splitlines()),
    }


def workspace_edit_file(
    workspace_root: Path,
    path: str,
    old_text: str,
    new_text: str,
) -> dict[str, object]:
    """Apply a deterministic single-match replacement and return a unified diff."""
    target = resolve_workspace_path(workspace_root, path)
    if not target.exists() or not target.is_file():
        raise FileNotFoundError(f"File not found in workspace: {path}")
    original = target.read_text(encoding="utf-8")
    if not old_text:
        raise ValueError("old_text must not be empty")
    occurrences = original.count(old_text)
    if occurrences == 0:
        raise ValueError(f"old_text not found in {path}")
    if occurrences > 1:
        raise ValueError(f"old_text matched {occurrences} times in {path}; must match once")

    updated = original.replace(old_text, new_text, 1)
    target.write_text(updated, encoding="utf-8")
    rel = str(target.relative_to(workspace_root.resolve()))
    diff_lines = list(
        difflib.unified_diff(
            original.splitlines(keepends=True),
            updated.splitlines(keepends=True),
            fromfile=f"a/{rel}",
            tofile=f"b/{rel}",
            n=3,
        )
    )
    diff_str = "".join(diff_lines)
    return {
        "path": rel,
        "diff": diff_str,
        "bytes_written": len(updated.encode("utf-8")),
    }


def workspace_list_dir(workspace_root: Path, path: str = ".") -> dict[str, object]:
    """List directory entries inside the user's workspace jail."""
    target = resolve_workspace_path(workspace_root, path)
    if not target.exists():
        raise FileNotFoundError(f"Directory not found: {path}")
    if not target.is_dir():
        raise NotADirectoryError(f"Path is not a directory: {path}")

    root_real = workspace_root.resolve(strict=True)
    entries: list[dict[str, object]] = []
    for child in sorted(target.iterdir(), key=lambda p: (not p.is_dir(), p.name)):
        if os.path.islink(child):
            continue
        rel = str(child.relative_to(root_real))
        entries.append(
            {
                "name": child.name,
                "path": rel,
                "kind": "dir" if child.is_dir() else "file",
                "size_bytes": child.stat().st_size if child.is_file() else 0,
            }
        )
    return {
        "path": str(target.relative_to(root_real)) if target != root_real else ".",
        "entries": entries,
    }


def workspace_glob(
    workspace_root: Path,
    pattern: str,
    path: str = ".",
    *,
    max_results: int = 200,
) -> dict[str, object]:
    """Match workspace files using a glob pattern without leaving the workspace jail."""
    base = resolve_workspace_path(workspace_root, path)
    root_real = workspace_root.resolve(strict=True)
    matches: list[str] = []
    for dirpath, dirnames, filenames in os.walk(base, followlinks=False):
        dirnames[:] = sorted(d for d in dirnames if not os.path.islink(os.path.join(dirpath, d)))
        for fname in sorted(filenames):
            full = Path(dirpath) / fname
            if os.path.islink(full):
                continue
            rel = str(full.relative_to(root_real))
            rel_from_base = str(full.relative_to(base))
            if fnmatch.fnmatch(rel_from_base, pattern) or fnmatch.fnmatch(fname, pattern):
                matches.append(rel)
                if len(matches) >= max_results:
                    return {"pattern": pattern, "matches": matches, "truncated": True}
    return {"pattern": pattern, "matches": matches, "truncated": False}


def workspace_grep(
    workspace_root: Path,
    pattern: str,
    path: str = ".",
    *,
    max_results: int = 50,
) -> dict[str, object]:
    """Search for a substring or regex pattern across files inside the workspace jail."""
    base = resolve_workspace_path(workspace_root, path)
    root_real = workspace_root.resolve(strict=True)
    try:
        regex = re.compile(pattern)
    except re.error:
        regex = re.compile(re.escape(pattern))

    hits: list[dict[str, object]] = []
    files_to_scan: list[Path] = []
    if base.is_file():
        files_to_scan.append(base)
    else:
        for dirpath, dirnames, filenames in os.walk(base, followlinks=False):
            dirnames[:] = sorted(
                d for d in dirnames if not os.path.islink(os.path.join(dirpath, d))
            )
            for fname in sorted(filenames):
                full = Path(dirpath) / fname
                if not os.path.islink(full) and full.is_file():
                    files_to_scan.append(full)

    for fpath in files_to_scan:
        try:
            if fpath.stat().st_size > 1_048_576:
                continue
            text = fpath.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        rel = str(fpath.relative_to(root_real))
        for line_no, line in enumerate(text.splitlines(), start=1):
            if regex.search(line):
                hits.append(
                    {
                        "path": rel,
                        "line": line_no,
                        "text": line[:240],
                    }
                )
                if len(hits) >= max_results:
                    return {"pattern": pattern, "hits": hits, "truncated": True}
    return {"pattern": pattern, "hits": hits, "truncated": False}
