"""Email domain package: IMAP/SMTP accounts, OAuth/XOAUTH2, sync engine, sanitizer, and triage."""

from backend.domain.mail.service import (
    DANGEROUS_ATTACHMENT_EXTENSIONS,
    MailAccount,
    MailAttachment,
    MailMessage,
    MailService,
    OutboxEntry,
    SanitizedEmailResult,
    TriageResult,
    build_gmail_oauth_url,
    build_m365_oauth_url,
    build_xoauth2_sasl_string,
    classify_attachment_safety,
    detect_spoofed_domain_or_url,
    parse_mail_search_query,
    sanitize_email_html,
)

__all__ = [
    "DANGEROUS_ATTACHMENT_EXTENSIONS",
    "MailAccount",
    "MailAttachment",
    "MailMessage",
    "MailService",
    "OutboxEntry",
    "SanitizedEmailResult",
    "TriageResult",
    "build_gmail_oauth_url",
    "build_m365_oauth_url",
    "build_xoauth2_sasl_string",
    "classify_attachment_safety",
    "detect_spoofed_domain_or_url",
    "parse_mail_search_query",
    "sanitize_email_html",
]
