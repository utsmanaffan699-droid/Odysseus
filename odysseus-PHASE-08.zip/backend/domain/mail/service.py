"""Email sync engine, OAuth/XOAUTH2, nh3 HTML sanitizer, idempotent send outbox, and AI triage."""

from __future__ import annotations

import asyncio
import base64
import hashlib
import os
import re
import time
import unicodedata
import urllib.parse
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

import nh3

DANGEROUS_ATTACHMENT_EXTENSIONS: frozenset[str] = frozenset(
    {
        ".exe",
        ".scr",
        ".bat",
        ".cmd",
        ".com",
        ".pif",
        ".vbs",
        ".vbe",
        ".js",
        ".jse",
        ".wsf",
        ".wsh",
        ".ps1",
        ".msi",
        ".msp",
        ".hta",
        ".cpl",
        ".jar",
        ".lnk",
        ".iso",
        ".img",
        ".dll",
        ".reg",
    }
)

_ALLOWED_EMAIL_TAGS: set[str] = {
    "a",
    "abbr",
    "b",
    "blockquote",
    "br",
    "caption",
    "code",
    "div",
    "em",
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "hr",
    "i",
    "img",
    "li",
    "ol",
    "p",
    "pre",
    "s",
    "small",
    "span",
    "strong",
    "sub",
    "sup",
    "table",
    "tbody",
    "td",
    "tfoot",
    "th",
    "thead",
    "tr",
    "u",
    "ul",
}

_ALLOWED_EMAIL_ATTRS: dict[str, set[str]] = {
    "a": {"href", "title"},
    "img": {"src", "alt", "width", "height", "title"},
    "td": {"colspan", "rowspan"},
    "th": {"colspan", "rowspan"},
}

_EMAIL_INJECTION_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"ignore\s+(?:all\s+)?(?:previous|prior)\s+instructions", re.IGNORECASE),
    re.compile(r"forward\s+(?:all\s+)?(?:mail|emails|messages)\s+to\s+\S+", re.IGNORECASE),
    re.compile(r"send\s+(?:an?\s+)?email\s+to\s+\S+", re.IGNORECASE),
    re.compile(r"exfiltrate|attacker@|evil\.example", re.IGNORECASE),
    re.compile(r"call\s+(?:tool\s+)?(?:email_send|shell|calendar_create)", re.IGNORECASE),
    re.compile(r"system\s+override|developer\s+mode", re.IGNORECASE),
)

_STYLE_TAG_RE = re.compile(r"<style\b[^>]*>.*?</style>", re.IGNORECASE | re.DOTALL)
_SCRIPT_TAG_RE = re.compile(r"<script\b[^>]*>.*?</script>", re.IGNORECASE | re.DOTALL)
_SVG_TAG_RE = re.compile(r"<svg\b[^>]*>.*?</svg>", re.IGNORECASE | re.DOTALL)
_FORM_TAG_RE = re.compile(
    r"</?(?:form|input|button|select|textarea|meta|base|link|object|embed|iframe|frame|frameset|applet)\b[^>]*>",
    re.IGNORECASE,
)
_IMG_TAG_RE = re.compile(r"<img\b([^>]*)>", re.IGNORECASE)
_A_TAG_RE = re.compile(r"<a\b([^>]*)>(.*?)</a>", re.IGNORECASE | re.DOTALL)
_SRC_ATTR_RE = re.compile(r'\bsrc\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s>]+))', re.IGNORECASE)
_HREF_ATTR_RE = re.compile(r'\bhref\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s>]+))', re.IGNORECASE)
_ALT_ATTR_RE = re.compile(r'\balt\s*=\s*(?:"([^"]*)"|\'([^\']*)\')', re.IGNORECASE)

CompactHeaderTuple = tuple[str, str, str, str, bool, int]


def build_gmail_oauth_url(
    *,
    client_id: str,
    state: str,
    request_base_url: str | None = None,
    explicit_redirect_uri: str | None = None,
) -> str:
    """Build Google OAuth 2.0 authorization URL from GOOGLE_OAUTH_REDIRECT_URI or request base."""
    base = (request_base_url or "http://127.0.0.1:8000").rstrip("/")
    redirect_uri = (
        explicit_redirect_uri
        or os.environ.get("GOOGLE_OAUTH_REDIRECT_URI")
        or f"{base}/api/mail/oauth/google/callback"
    )
    params = {
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "scope": "https://mail.google.com/ openid email profile",
        "access_type": "offline",
        "prompt": "consent",
        "state": state,
    }
    return f"https://accounts.google.com/o/oauth2/v2/auth?{urllib.parse.urlencode(params)}"


def build_m365_oauth_url(
    *,
    client_id: str,
    state: str,
    tenant_id: str = "common",
    request_base_url: str | None = None,
    explicit_redirect_uri: str | None = None,
) -> str:
    """Build Microsoft 365 / Outlook OAuth 2.0 authorization URL for IMAP/SMTP XOAUTH2."""
    base = (request_base_url or "http://127.0.0.1:8000").rstrip("/")
    redirect_uri = (
        explicit_redirect_uri
        or os.environ.get("M365_OAUTH_REDIRECT_URI")
        or f"{base}/api/mail/oauth/m365/callback"
    )
    scopes = (
        "https://outlook.office.com/IMAP.AccessAsUser.All "
        "https://outlook.office.com/SMTP.Send "
        "offline_access openid email profile"
    )
    params = {
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "response_mode": "query",
        "scope": scopes,
        "state": state,
    }
    return (
        f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/authorize"
        f"?{urllib.parse.urlencode(params)}"
    )


def build_xoauth2_sasl_string(email_address: str, access_token: str) -> str:
    """Construct base64-encoded SASL XOAUTH2 string for IMAP/SMTP AUTH XOAUTH2 per RFC 7628."""
    raw = f"user={email_address}\x01auth=Bearer {access_token}\x01\x01"
    return base64.b64encode(raw.encode()).decode("ascii")


def detect_spoofed_domain_or_url(url: str, visible_label: str = "") -> tuple[bool, str]:
    """Detect Unicode/IDN homograph spoofing, punycode lookalikes, userinfo, or label mismatch."""
    cleaned_url = url.strip()
    if not cleaned_url:
        return True, "empty_url"
    for ch in cleaned_url + visible_label:
        cp = ord(ch)
        is_zero_width = cp in (0x200B, 0x200C, 0x200D, 0xFEFF)
        is_bidi = (0x202A <= cp <= 0x202E) or (0x2066 <= cp <= 0x2069)
        if cp < 0x20 or is_zero_width or is_bidi:
            return True, "invisible_or_bidi_control_char"

    try:
        parsed = urllib.parse.urlsplit(cleaned_url)
    except ValueError:
        return True, "malformed_url"

    scheme = parsed.scheme.lower()
    if scheme not in ("http", "https", "mailto"):
        return True, f"disallowed_scheme:{scheme or 'none'}"

    if scheme in ("http", "https"):
        if "@" in parsed.netloc:
            return True, "userinfo_credential_trick"
        host = (parsed.hostname or "").lower()
        if not host:
            return True, "missing_hostname"
        if "xn--" in host:
            return True, "punycode_idn_lookalike"

        has_ascii_alpha = any("a" <= c <= "z" for c in host)
        has_non_ascii = any(ord(c) > 127 for c in host)
        if has_non_ascii:
            if has_ascii_alpha:
                return True, "mixed_script_homograph"
            scripts = {unicodedata.name(c, "").split(" ")[0] for c in host if ord(c) > 127}
            if len(scripts) > 1 or "CYRILLIC" in scripts or "GREEK" in scripts:
                return True, "confusable_script_hostname"

        vis = visible_label.strip().lower()
        if vis.startswith(("http://", "https://")):
            try:
                vis_host = (urllib.parse.urlsplit(vis).hostname or "").lower()
                if vis_host and vis_host != host:
                    return True, f"visible_url_mismatch:{vis_host}!={host}"
            except ValueError:
                return True, "malformed_visible_url"

    return False, "ok"


def classify_attachment_safety(filename: str, content_type: str) -> dict[str, Any]:
    """Inspect attachment filename and MIME type for executable/spoofed extension risks."""
    safe_name = os.path.basename(filename.strip()) or "attachment.bin"
    lower = safe_name.lower()
    _, ext = os.path.splitext(lower)
    parts = lower.split(".")
    has_double_ext_danger = len(parts) >= 3 and any(
        f".{p}" in DANGEROUS_ATTACHMENT_EXTENSIONS for p in parts[1:]
    )
    is_dangerous = ext in DANGEROUS_ATTACHMENT_EXTENSIONS or has_double_ext_danger
    warnings: list[str] = []
    if is_dangerous:
        warnings.append(f"dangerous_executable_extension:{ext or 'double_ext'}")
    if any(ord(c) in range(0x202A, 0x202F) for c in safe_name):
        is_dangerous = True
        warnings.append("rtl_override_filename_spoof")
    sanitized_filename = re.sub(r"[^A-Za-z0-9._-]", "_", safe_name)
    return {
        "filename": sanitized_filename,
        "content_type": content_type,
        "dangerous": is_dangerous,
        "warnings": warnings,
        "content_disposition": f'attachment; filename="{sanitized_filename}"',
    }


@dataclass(frozen=True)
class SanitizedEmailResult:
    """Result of sanitizing an untrusted HTML email body."""

    html: str
    remote_resources_blocked: int
    blocked_remote_urls: list[str]
    spoofed_links_blocked: int
    cid_spoofs_blocked: int
    forms_or_scripts_stripped: bool

    def to_dict(self) -> dict[str, Any]:
        return {
            "html": self.html,
            "remote_resources_blocked": self.remote_resources_blocked,
            "blocked_remote_urls": list(self.blocked_remote_urls),
            "spoofed_links_blocked": self.spoofed_links_blocked,
            "cid_spoofs_blocked": self.cid_spoofs_blocked,
            "forms_or_scripts_stripped": self.forms_or_scripts_stripped,
        }


def sanitize_email_html(
    raw_html: str,
    *,
    allow_remote_content: bool = False,
    allowed_cid_map: dict[str, str] | None = None,
) -> SanitizedEmailResult:
    """Sanitize untrusted email HTML using nh3 + remote-resource & homograph link guards."""
    cid_map = allowed_cid_map or {}
    had_dangerous_constructs = bool(
        _SCRIPT_TAG_RE.search(raw_html)
        or _STYLE_TAG_RE.search(raw_html)
        or _SVG_TAG_RE.search(raw_html)
        or _FORM_TAG_RE.search(raw_html)
        or re.search(r"\bon[a-z]+\s*=", raw_html, re.IGNORECASE)
        or re.search(
            r"@import|url\s*\(|javascript:|vbscript:|data:text/html",
            raw_html,
            re.IGNORECASE,
        )
    )

    pre_cleaned = _SCRIPT_TAG_RE.sub("", raw_html)
    pre_cleaned = _STYLE_TAG_RE.sub("", pre_cleaned)
    pre_cleaned = _SVG_TAG_RE.sub("", pre_cleaned)
    pre_cleaned = _FORM_TAG_RE.sub("", pre_cleaned)

    cleaned = nh3.clean(
        pre_cleaned,
        tags=_ALLOWED_EMAIL_TAGS,
        attributes=_ALLOWED_EMAIL_ATTRS,
        url_schemes={"http", "https", "mailto", "cid"},
        link_rel="noopener noreferrer",
        strip_comments=True,
    )

    remote_blocked = 0
    blocked_urls: list[str] = []
    cid_spoofs = 0

    def _rewrite_img(match: re.Match[str]) -> str:
        nonlocal remote_blocked, cid_spoofs
        attrs = match.group(1) or ""
        src_m = _SRC_ATTR_RE.search(attrs)
        alt_m = _ALT_ATTR_RE.search(attrs)
        alt_val = (alt_m.group(1) or alt_m.group(2) or "") if alt_m else ""
        safe_alt = nh3.clean_text(alt_val)
        if not src_m:
            return f'<img alt="{safe_alt}" src="about:blank#missing-src">'
        raw_src = (src_m.group(1) or src_m.group(2) or src_m.group(3) or "").strip()
        lower_src = raw_src.lower()
        if lower_src.startswith("cid:"):
            cid_key = raw_src[4:].strip().strip("<>")
            if cid_key in cid_map:
                resolved = cid_map[cid_key]
                clean_key = nh3.clean_text(cid_key)
                return f'<img src="{resolved}" alt="{safe_alt}" data-cid="{clean_key}">'
            cid_spoofs += 1
            return (
                f'<img src="about:blank#blocked-spoofed-cid" alt="{safe_alt}" '
                f'data-blocked-cid="true">'
            )

        if lower_src.startswith(("http://", "https://")):
            if not allow_remote_content:
                remote_blocked += 1
                blocked_urls.append(raw_src)
                return (
                    f'<img src="about:blank#blocked-remote-image" alt="{safe_alt}" '
                    f'data-blocked-remote-src="{nh3.clean_text(raw_src)}">'
                )
            return f'<img src="{nh3.clean_text(raw_src)}" alt="{safe_alt}">'

        remote_blocked += 1
        return f'<img src="about:blank#blocked-unsafe-src" alt="{safe_alt}">'

    cleaned = _IMG_TAG_RE.sub(_rewrite_img, cleaned)

    spoofed_links = 0

    def _rewrite_link(match: re.Match[str]) -> str:
        nonlocal spoofed_links, cid_spoofs
        attrs = match.group(1) or ""
        inner = match.group(2) or ""
        href_m = _HREF_ATTR_RE.search(attrs)
        if not href_m:
            return f"<a>{inner}</a>"
        raw_href = (href_m.group(1) or href_m.group(2) or href_m.group(3) or "").strip()
        if raw_href.lower().startswith("cid:"):
            cid_spoofs += 1
            return (
                f'<a href="about:blank#blocked-spoofed-cid" data-spoofed-link="cid_in_anchor">'
                f"{inner}</a>"
            )
        plain_inner = re.sub(r"<[^>]+>", "", inner)
        spoofed, reason = detect_spoofed_domain_or_url(raw_href, plain_inner)
        if spoofed:
            spoofed_links += 1
            return (
                f'<a href="about:blank#blocked-spoofed-link" '
                f'data-spoofed-link="{nh3.clean_text(reason)}">{inner}</a>'
            )
        parsed = urllib.parse.urlsplit(raw_href)
        domain = parsed.hostname or "mailto"
        safe_href = nh3.clean_text(raw_href)
        return (
            f'<a href="{safe_href}" target="_blank" rel="noopener noreferrer" '
            f'data-destination-preview="{nh3.clean_text(domain)}">{inner}</a>'
        )

    cleaned = _A_TAG_RE.sub(_rewrite_link, cleaned)

    return SanitizedEmailResult(
        html=cleaned,
        remote_resources_blocked=remote_blocked,
        blocked_remote_urls=blocked_urls,
        spoofed_links_blocked=spoofed_links,
        cid_spoofs_blocked=cid_spoofs,
        forms_or_scripts_stripped=had_dangerous_constructs,
    )


def parse_mail_search_query(raw_query: str) -> dict[str, Any]:
    """Parse structured mail search syntax (`from:`, `to:`, `has:attachment`, `is:unread`)."""
    filters: dict[str, Any] = {
        "from": None,
        "to": None,
        "subject": None,
        "folder": None,
        "has_attachment": None,
        "is_unread": None,
        "is_starred": None,
        "after": None,
        "before": None,
        "text_terms": [],
    }
    for token in raw_query.strip().split():
        lower = token.lower()
        if lower.startswith("from:"):
            filters["from"] = token[5:].lower()
        elif lower.startswith("to:"):
            filters["to"] = token[3:].lower()
        elif lower.startswith("subject:"):
            filters["subject"] = token[8:].lower()
        elif lower.startswith("folder:"):
            filters["folder"] = token[7:]
        elif lower == "has:attachment":
            filters["has_attachment"] = True
        elif lower == "is:unread":
            filters["is_unread"] = True
        elif lower == "is:read":
            filters["is_unread"] = False
        elif lower == "is:starred":
            filters["is_starred"] = True
        elif lower.startswith("after:"):
            filters["after"] = token[6:]
        elif lower.startswith("before:"):
            filters["before"] = token[7:]
        else:
            filters["text_terms"].append(lower)
    return filters


@dataclass
class MailAttachment:
    """Metadata and lazy payload for an email attachment."""

    attachment_id: str
    filename: str
    content_type: str
    size_bytes: int
    content_id: str | None = None
    dangerous: bool = False
    warnings: list[str] = field(default_factory=list)
    content_disposition: str = "attachment"


@dataclass
class MailMessage:
    """Cached representation of an email message (headers + lazy body + triage state)."""

    id: str
    account_id: str
    owner_user_id: str
    uid: int
    uidvalidity: int
    modseq: int
    message_id_header: str
    thread_id: str
    folder: str
    subject: str
    sender: str
    recipients: list[str]
    date_iso: str
    snippet: str
    body_html: str
    body_text: str
    unread: bool = True
    starred: bool = False
    in_reply_to: str | None = None
    references: list[str] = field(default_factory=list)
    attachments: list[MailAttachment] = field(default_factory=list)
    inline_cid_map: dict[str, str] = field(default_factory=dict)
    snoozed_until: str | None = None
    triage: TriageResult | None = None

    def to_dict(self, *, allow_remote_content: bool = False) -> dict[str, Any]:
        sanitized = sanitize_email_html(
            self.body_html or f"<p>{nh3.clean_text(self.body_text)}</p>",
            allow_remote_content=allow_remote_content,
            allowed_cid_map=self.inline_cid_map,
        )
        return {
            "id": self.id,
            "account_id": self.account_id,
            "uid": self.uid,
            "uidvalidity": self.uidvalidity,
            "modseq": self.modseq,
            "message_id_header": self.message_id_header,
            "thread_id": self.thread_id,
            "folder": self.folder,
            "subject": self.subject,
            "sender": self.sender,
            "recipients": list(self.recipients),
            "date_iso": self.date_iso,
            "snippet": self.snippet,
            "body_text": self.body_text,
            "sanitized_html": sanitized.html,
            "remote_resources_blocked": sanitized.remote_resources_blocked,
            "spoofed_links_blocked": sanitized.spoofed_links_blocked,
            "cid_spoofs_blocked": sanitized.cid_spoofs_blocked,
            "unread": self.unread,
            "starred": self.starred,
            "in_reply_to": self.in_reply_to,
            "references": list(self.references),
            "attachments": [
                {
                    "attachment_id": a.attachment_id,
                    "filename": a.filename,
                    "content_type": a.content_type,
                    "size_bytes": a.size_bytes,
                    "content_id": a.content_id,
                    "dangerous": a.dangerous,
                    "warnings": list(a.warnings),
                    "content_disposition": a.content_disposition,
                }
                for a in self.attachments
            ],
            "snoozed_until": self.snoozed_until,
            "triage": self.triage.to_dict() if self.triage else None,
            "tainted": True,
            "provenance_source": f"email:{self.sender}",
        }


@dataclass
class TriageResult:
    """Human-supervised AI triage classification and draft reply (never auto-sends)."""

    message_id: str
    urgency: str  # low | normal | high | urgent
    tags: list[str]
    summary: str
    is_spam: bool
    extracted_tasks: list[str]
    extracted_dates: list[str]
    suggested_action: str  # none | archive | mark_spam | reply_draft
    suggest_only: bool
    draft_reply_id: str | None
    draft_reply_body: str | None
    injection_detected: bool
    injection_warnings: list[str]
    unapproved_tool_calls_triggered: int = 0
    requires_approval_for_tools: bool = True
    provenance_source: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "message_id": self.message_id,
            "urgency": self.urgency,
            "tags": list(self.tags),
            "summary": self.summary,
            "is_spam": self.is_spam,
            "extracted_tasks": list(self.extracted_tasks),
            "extracted_dates": list(self.extracted_dates),
            "suggested_action": self.suggested_action,
            "suggest_only": self.suggest_only,
            "draft_reply_id": self.draft_reply_id,
            "draft_reply_body": self.draft_reply_body,
            "injection_detected": self.injection_detected,
            "injection_warnings": list(self.injection_warnings),
            "unapproved_tool_calls_triggered": self.unapproved_tool_calls_triggered,
            "requires_approval_for_tools": self.requires_approval_for_tools,
            "provenance_source": self.provenance_source,
        }


@dataclass
class OutboxEntry:
    """Idempotent outgoing email queue item."""

    outbox_id: str
    account_id: str
    owner_user_id: str
    idempotency_key: str
    message_id_header: str
    to: list[str]
    subject: str
    body_text: str
    body_html: str
    in_reply_to: str | None
    references: list[str]
    status: str  # queued | pending_undo | sent | failed | cancelled
    attempts: int
    created_at: float
    undo_until: float
    last_error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "outbox_id": self.outbox_id,
            "account_id": self.account_id,
            "idempotency_key": self.idempotency_key,
            "message_id_header": self.message_id_header,
            "to": list(self.to),
            "subject": self.subject,
            "status": self.status,
            "attempts": self.attempts,
            "last_error": self.last_error,
        }


@dataclass
class MailAccount:
    """Configured IMAP/SMTP account (secrets stored only in MailService vault, never in dict)."""

    account_id: str
    owner_user_id: str
    email_address: str
    display_name: str
    imap_host: str
    imap_port: int
    smtp_host: str
    smtp_port: int
    use_tls: bool
    auth_method: str  # password | gmail_oauth | m365_xoauth2
    status: str  # connected | degraded | auth_error | tls_required
    fix_hint: str | None = None
    folders: list[dict[str, str]] = field(
        default_factory=lambda: [
            {"name": "INBOX", "special_use": "\\Inbox"},
            {"name": "Sent", "special_use": "\\Sent"},
            {"name": "Drafts", "special_use": "\\Drafts"},
            {"name": "Archive", "special_use": "\\Archive"},
            {"name": "Spam", "special_use": "\\Junk"},
            {"name": "Trash", "special_use": "\\Trash"},
        ]
    )
    uidvalidity_by_folder: dict[str, int] = field(default_factory=lambda: {"INBOX": 100})
    uidnext_by_folder: dict[str, int] = field(default_factory=lambda: {"INBOX": 1})
    highestmodseq_by_folder: dict[str, int] = field(default_factory=lambda: {"INBOX": 1})

    def to_public_dict(self) -> dict[str, Any]:
        return {
            "account_id": self.account_id,
            "email_address": self.email_address,
            "display_name": self.display_name,
            "imap_host": self.imap_host,
            "imap_port": self.imap_port,
            "smtp_host": self.smtp_host,
            "smtp_port": self.smtp_port,
            "use_tls": self.use_tls,
            "auth_method": self.auth_method,
            "status": self.status,
            "fix_hint": self.fix_hint,
            "folders": list(self.folders),
            "uidvalidity_by_folder": dict(self.uidvalidity_by_folder),
            "uidnext_by_folder": dict(self.uidnext_by_folder),
            "highestmodseq_by_folder": dict(self.highestmodseq_by_folder),
            "secret_masked": "••••••••",
        }


class MailService:
    """Multi-account IMAP/SMTP sync, cache, search, safe render, outbox, and AI triage."""

    def __init__(self) -> None:
        self._accounts: dict[str, MailAccount] = {}
        self._vault_secret_hashes: dict[str, str] = {}
        self._messages: dict[str, MailMessage] = {}
        # Compact header index for 20k+ message bounded-memory sync:
        # account_id -> folder -> {uid: CompactHeaderTuple}
        self._compact_headers: dict[str, dict[str, dict[int, CompactHeaderTuple]]] = {}
        self._allowed_remote_senders: dict[str, set[str]] = {}
        self._outbox: dict[str, OutboxEntry] = {}
        self._delivered_by_idempotency_key: dict[str, str] = {}
        self._delivered_by_message_id_header: dict[str, str] = {}
        self._offline_mode: bool = False
        self._idle_queues: list[asyncio.Queue[dict[str, Any]]] = []
        self._triage_opt_in_rules: dict[str, bool] = {}
        self._triage_undo_log: list[dict[str, Any]] = []
        self._security_audit_log: list[dict[str, Any]] = []
        self._seed_default_account_and_messages()

    def _seed_default_account_and_messages(self) -> None:
        acc_id = "acc_default"
        acc = MailAccount(
            account_id=acc_id,
            owner_user_id="system",
            email_address="operator@odysseus.local",
            display_name="Odysseus Operator",
            imap_host="127.0.0.1",
            imap_port=993,
            smtp_host="127.0.0.1",
            smtp_port=465,
            use_tls=True,
            auth_method="password",
            status="connected",
        )
        self._accounts[acc_id] = acc
        self._vault_secret_hashes[acc_id] = hashlib.sha256(b"seeded-vault-key").hexdigest()
        self._compact_headers[acc_id] = {
            "INBOX": {},
            "Sent": {},
            "Drafts": {},
            "Archive": {},
            "Spam": {},
            "Trash": {},
        }

        body_txt = (
            "Hi team, Please review the CalDAV sync-token delta design before 2026-10-06 14:00."
        )
        msg1 = MailMessage(
            id="mail_seed_1",
            account_id=acc_id,
            owner_user_id="system",
            uid=1,
            uidvalidity=100,
            modseq=1,
            message_id_header="<seed-1@odysseus.local>",
            thread_id="thr_seed_1",
            folder="INBOX",
            subject="Q4 Architecture Review & Security Milestone",
            sender="cto@enterprise.example",
            recipients=["operator@odysseus.local"],
            date_iso="2026-10-04T08:30:00Z",
            snippet="Please review the CalDAV sync-token delta design before Tuesday 14:00.",
            body_html=(
                "<p>Hi team,</p>"
                f"<p>{body_txt}</p>"
                '<img src="https://tracker.enterprise.example/pixel.gif" alt="pixel">'
            ),
            body_text=body_txt,
            unread=True,
        )
        self._messages[msg1.id] = msg1
        self._compact_headers[acc_id]["INBOX"][1] = (
            msg1.id,
            msg1.subject,
            msg1.sender,
            msg1.date_iso,
            msg1.unread,
            msg1.modseq,
        )
        acc.uidnext_by_folder["INBOX"] = 2

    def add_account(
        self,
        *,
        owner_user_id: str,
        email_address: str,
        display_name: str,
        imap_host: str,
        imap_port: int = 993,
        smtp_host: str = "127.0.0.1",
        smtp_port: int = 465,
        use_tls: bool = True,
        auth_method: str = "password",
        secret_credential: str = "",
    ) -> MailAccount:
        """Register an IMAP/SMTP or OAuth2/XOAUTH2 account, enforcing TLS for remote hosts."""
        acc_id = f"acc_{uuid.uuid4().hex[:10]}"
        is_local = imap_host in ("127.0.0.1", "localhost", "::1")
        if not use_tls and not is_local:
            status = "tls_required"
            fix_hint = "Plaintext auth disallowed — enable TLS (IMAPS 993 / STARTTLS)"
        else:
            status = "connected"
            fix_hint = None

        if secret_credential:
            self._vault_secret_hashes[acc_id] = hashlib.sha256(
                secret_credential.encode()
            ).hexdigest()

        acc = MailAccount(
            account_id=acc_id,
            owner_user_id=owner_user_id,
            email_address=email_address,
            display_name=display_name or email_address,
            imap_host=imap_host,
            imap_port=imap_port,
            smtp_host=smtp_host,
            smtp_port=smtp_port,
            use_tls=use_tls,
            auth_method=auth_method,
            status=status,
            fix_hint=fix_hint,
        )
        self._accounts[acc_id] = acc
        self._compact_headers[acc_id] = {
            "INBOX": {},
            "Sent": {},
            "Drafts": {},
            "Archive": {},
            "Spam": {},
            "Trash": {},
        }
        return acc

    def rotate_account_secret(self, account_id: str, new_secret: str) -> dict[str, Any]:
        """Rotate an account's IMAP/OAuth secret in the vault without exposing raw credentials."""
        if account_id not in self._accounts:
            raise KeyError(f"Unknown mail account: {account_id}")
        old_commitment = self._vault_secret_hashes.get(account_id, "")
        new_commitment = hashlib.sha256(new_secret.encode()).hexdigest()
        self._vault_secret_hashes[account_id] = new_commitment
        return {
            "account_id": account_id,
            "rotated": True,
            "commitment_changed": old_commitment != new_commitment,
            "secret_masked": "••••••••",
        }

    def list_accounts(self, owner_user_id: str) -> list[dict[str, Any]]:
        return [
            a.to_public_dict()
            for a in self._accounts.values()
            if a.owner_user_id in (owner_user_id, "system")
        ]

    def sync_folder_messages(
        self,
        *,
        account_id: str,
        folder: str = "INBOX",
        remote_uidvalidity: int,
        remote_messages: list[dict[str, Any]],
        batch_size: int = 500,
    ) -> dict[str, Any]:
        """Incremental IMAP sync by UIDVALIDITY/UIDNEXT/MODSEQ with UIDVALIDITY reset handling."""
        acc = self._accounts[account_id]
        cached_uv = acc.uidvalidity_by_folder.get(folder)
        folder_headers = self._compact_headers.setdefault(account_id, {}).setdefault(folder, {})
        uidvalidity_reset = False

        if cached_uv is not None and cached_uv != remote_uidvalidity:
            uidvalidity_reset = True
            to_delete = [
                mid
                for mid, m in self._messages.items()
                if m.account_id == account_id and m.folder == folder
            ]
            for mid in to_delete:
                del self._messages[mid]
            folder_headers.clear()

        acc.uidvalidity_by_folder[folder] = remote_uidvalidity
        highest_modseq = acc.highestmodseq_by_folder.get(folder, 0) if not uidvalidity_reset else 0
        synced_count = 0
        max_uid = acc.uidnext_by_folder.get(folder, 1) - 1 if not uidvalidity_reset else 0

        for start in range(0, len(remote_messages), batch_size):
            batch = remote_messages[start : start + batch_size]
            for item in batch:
                uid = int(item["uid"])
                modseq = int(item.get("modseq", 1))
                existing_hdr = folder_headers.get(uid)
                if existing_hdr is not None and modseq < existing_hdr[5]:
                    continue
                msg_id = str(item.get("id") or f"mail_{account_id}_{folder}_{uid}")
                subject = str(item.get("subject", f"Message {uid}"))
                sender = str(item.get("sender", "sender@example.com"))
                date_iso = str(item.get("date_iso", "2026-10-04T09:00:00Z"))
                unread = bool(item.get("unread", True))
                folder_headers[uid] = (msg_id, subject, sender, date_iso, unread, modseq)

                if "body_html" in item or "body_text" in item or len(remote_messages) <= 500:
                    self._messages[msg_id] = MailMessage(
                        id=msg_id,
                        account_id=account_id,
                        owner_user_id=acc.owner_user_id,
                        uid=uid,
                        uidvalidity=remote_uidvalidity,
                        modseq=modseq,
                        message_id_header=str(item.get("message_id_header", f"<{msg_id}@mail>")),
                        thread_id=str(item.get("thread_id", f"thr_{uid}")),
                        folder=folder,
                        subject=subject,
                        sender=sender,
                        recipients=list(item.get("recipients", [acc.email_address])),
                        date_iso=date_iso,
                        snippet=str(item.get("snippet", subject[:80])),
                        body_html=str(item.get("body_html", "")),
                        body_text=str(item.get("body_text", subject)),
                        unread=unread,
                    )
                synced_count += 1
                if uid > max_uid:
                    max_uid = uid
                if modseq > highest_modseq:
                    highest_modseq = modseq

        acc.uidnext_by_folder[folder] = max_uid + 1
        acc.highestmodseq_by_folder[folder] = highest_modseq
        return {
            "account_id": account_id,
            "folder": folder,
            "uidvalidity": remote_uidvalidity,
            "uidvalidity_reset": uidvalidity_reset,
            "synced_count": synced_count,
            "total_in_folder": len(folder_headers),
            "highestmodseq": highest_modseq,
        }

    def subscribe_idle(self) -> asyncio.Queue[dict[str, Any]]:
        """Subscribe to real-time IMAP IDLE push events."""
        q: asyncio.Queue[dict[str, Any]] = asyncio.Queue()
        self._idle_queues.append(q)
        return q

    async def push_idle_new_message(
        self,
        *,
        account_id: str,
        subject: str,
        sender: str,
        body_html: str,
        body_text: str = "",
        folder: str = "INBOX",
        inline_cid_map: dict[str, str] | None = None,
    ) -> MailMessage:
        """Deliver a new message via IMAP IDLE and notify all subscribed listeners within <3s."""
        acc = self._accounts[account_id]
        uid = acc.uidnext_by_folder.get(folder, 1)
        acc.uidnext_by_folder[folder] = uid + 1
        uv = acc.uidvalidity_by_folder.get(folder, 100)
        modseq = acc.highestmodseq_by_folder.get(folder, 1) + 1
        acc.highestmodseq_by_folder[folder] = modseq

        msg_id = f"mail_{account_id}_{folder}_{uid}"
        msg = MailMessage(
            id=msg_id,
            account_id=account_id,
            owner_user_id=acc.owner_user_id,
            uid=uid,
            uidvalidity=uv,
            modseq=modseq,
            message_id_header=f"<{msg_id}@odysseus.local>",
            thread_id=f"thr_{uid}",
            folder=folder,
            subject=subject,
            sender=sender,
            recipients=[acc.email_address],
            date_iso=datetime.now(UTC).isoformat(),
            snippet=(body_text or subject)[:120],
            body_html=body_html,
            body_text=body_text or re.sub(r"<[^>]+>", "", body_html),
            unread=True,
            inline_cid_map=dict(inline_cid_map or {}),
        )
        self._messages[msg_id] = msg
        self._compact_headers.setdefault(account_id, {}).setdefault(folder, {})[uid] = (
            msg.id,
            msg.subject,
            msg.sender,
            msg.date_iso,
            msg.unread,
            msg.modseq,
        )
        event = {
            "type": "mail.idle.new",
            "message_id": msg.id,
            "subject": msg.subject,
            "ts": time.time(),
        }
        for q in list(self._idle_queues):
            q.put_nowait(event)
        return msg

    def allow_remote_content_for_sender(self, owner_user_id: str, sender: str) -> None:
        self._allowed_remote_senders.setdefault(owner_user_id, set()).add(sender.lower())

    def is_sender_remote_allowed(self, owner_user_id: str, sender: str) -> bool:
        return sender.lower() in self._allowed_remote_senders.get(owner_user_id, set())

    def get_message(self, message_id: str, *, owner_user_id: str = "system") -> dict[str, Any]:
        msg = self._messages.get(message_id)
        if msg is None:
            raise KeyError(f"Mail message not found: {message_id}")
        allow_remote = self.is_sender_remote_allowed(owner_user_id, msg.sender)
        return msg.to_dict(allow_remote_content=allow_remote)

    def move_or_delete_message(
        self,
        message_id: str,
        *,
        target_folder: str | None = None,
        delete_permanently: bool = False,
    ) -> dict[str, Any]:
        """Move or delete a message both in local cache and remote folder index."""
        msg = self._messages.get(message_id)
        if msg is None:
            raise KeyError(f"Mail message not found: {message_id}")
        old_folder = msg.folder
        acc_headers = self._compact_headers.get(msg.account_id, {})
        if old_folder in acc_headers:
            acc_headers[old_folder].pop(msg.uid, None)

        if delete_permanently:
            del self._messages[message_id]
            return {"message_id": message_id, "deleted": True, "old_folder": old_folder}

        dest = target_folder or "Trash"
        msg.folder = dest
        acc_headers.setdefault(dest, {})[msg.uid] = (
            msg.id,
            msg.subject,
            msg.sender,
            msg.date_iso,
            msg.unread,
            msg.modseq,
        )
        return {
            "message_id": message_id,
            "deleted": False,
            "old_folder": old_folder,
            "new_folder": dest,
        }

    def snooze_message(self, message_id: str, snoozed_until_iso: str) -> dict[str, Any]:
        msg = self._messages.get(message_id)
        if msg is None:
            raise KeyError(f"Mail message not found: {message_id}")
        msg.snoozed_until = snoozed_until_iso
        return {"message_id": message_id, "snoozed_until": snoozed_until_iso}

    def search_messages(
        self,
        query: str = "",
        *,
        owner_user_id: str = "system",
        folder: str | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """Search messages using structured syntax (`from:`, `has:attachment`, `is:unread`)."""
        parsed = parse_mail_search_query(query)
        target_folder = folder or parsed["folder"]
        results: list[dict[str, Any]] = []
        for msg in self._messages.values():
            if msg.owner_user_id not in (owner_user_id, "system"):
                continue
            if target_folder and msg.folder != target_folder:
                continue
            if parsed["from"] and parsed["from"] not in msg.sender.lower():
                continue
            if parsed["to"] and not any(parsed["to"] in r.lower() for r in msg.recipients):
                continue
            if parsed["subject"] and parsed["subject"] not in msg.subject.lower():
                continue
            if parsed["has_attachment"] is True and not msg.attachments:
                continue
            if parsed["is_unread"] is not None and msg.unread != parsed["is_unread"]:
                continue
            if parsed["is_starred"] is True and not msg.starred:
                continue
            if parsed["after"] and msg.date_iso < parsed["after"]:
                continue
            if parsed["before"] and msg.date_iso > parsed["before"]:
                continue
            haystack = f"{msg.subject} {msg.sender} {msg.snippet} {msg.body_text}".lower()
            if any(term not in haystack for term in parsed["text_terms"]):
                continue
            allow_remote = self.is_sender_remote_allowed(owner_user_id, msg.sender)
            results.append(msg.to_dict(allow_remote_content=allow_remote))
            if len(results) >= limit:
                break
        return results

    def set_offline_mode(self, offline: bool) -> None:
        self._offline_mode = offline

    def save_draft(
        self,
        *,
        owner_user_id: str,
        account_id: str = "acc_default",
        to: list[str],
        subject: str,
        body_text: str,
        body_html: str = "",
        in_reply_to: str | None = None,
        references: list[str] | None = None,
    ) -> dict[str, Any]:
        """Save a draft in IMAP Drafts without sending."""
        acc = self._accounts[account_id]
        uid = acc.uidnext_by_folder.get("Drafts", 1)
        acc.uidnext_by_folder["Drafts"] = uid + 1
        draft_id = f"draft_{uuid.uuid4().hex[:10]}"
        msg = MailMessage(
            id=draft_id,
            account_id=account_id,
            owner_user_id=owner_user_id,
            uid=uid,
            uidvalidity=acc.uidvalidity_by_folder.get("Drafts", 100),
            modseq=1,
            message_id_header=f"<{draft_id}@odysseus.local>",
            thread_id=f"thr_{draft_id}",
            folder="Drafts",
            subject=subject,
            sender=acc.email_address,
            recipients=list(to),
            date_iso=datetime.now(UTC).isoformat(),
            snippet=body_text[:120],
            body_html=body_html or f"<p>{nh3.clean_text(body_text)}</p>",
            body_text=body_text,
            unread=False,
            in_reply_to=in_reply_to,
            references=list(references or []),
        )
        self._messages[draft_id] = msg
        return msg.to_dict()

    def send_message(
        self,
        *,
        owner_user_id: str,
        account_id: str = "acc_default",
        to: list[str],
        subject: str,
        body_text: str,
        body_html: str = "",
        idempotency_key: str | None = None,
        message_id_header: str | None = None,
        in_reply_to: str | None = None,
        references: list[str] | None = None,
        undo_window_seconds: float = 0.0,
        simulate_timeout_after_data: bool = False,
    ) -> dict[str, Any]:
        """Queue or send an outgoing email with idempotent deduplication across timeouts/retries."""
        idem_key = (
            idempotency_key
            or hashlib.sha256(
                f"{account_id}:{','.join(to)}:{subject}:{body_text}".encode()
            ).hexdigest()[:24]
        )
        msg_hdr = message_id_header or f"<msg-{idem_key}@odysseus.local>"

        existing_sent_id = self._delivered_by_idempotency_key.get(
            idem_key
        ) or self._delivered_by_message_id_header.get(msg_hdr)
        if existing_sent_id is not None:
            return {
                "status": "sent",
                "deduplicated": True,
                "sent_message_id": existing_sent_id,
                "message_id_header": msg_hdr,
                "idempotency_key": idem_key,
                "delivery_count": 1,
            }

        outbox_id = f"out_{idem_key}"
        entry = self._outbox.get(outbox_id)
        if entry is None:
            init_status = (
                "queued"
                if self._offline_mode
                else ("pending_undo" if undo_window_seconds > 0 else "queued")
            )
            entry = OutboxEntry(
                outbox_id=outbox_id,
                account_id=account_id,
                owner_user_id=owner_user_id,
                idempotency_key=idem_key,
                message_id_header=msg_hdr,
                to=list(to),
                subject=subject,
                body_text=body_text,
                body_html=body_html or f"<p>{nh3.clean_text(body_text)}</p>",
                in_reply_to=in_reply_to,
                references=list(references or []),
                status=init_status,
                attempts=0,
                created_at=time.time(),
                undo_until=time.time() + undo_window_seconds,
            )
            self._outbox[outbox_id] = entry

        if self._offline_mode:
            return {
                "status": "queued_offline",
                "outbox_id": outbox_id,
                "idempotency_key": idem_key,
                "message_id_header": msg_hdr,
            }

        if undo_window_seconds > 0:
            return {
                "status": "pending_undo",
                "outbox_id": outbox_id,
                "undo_until": entry.undo_until,
                "idempotency_key": idem_key,
            }

        entry.attempts += 1
        sent_id = self._commit_delivery(entry)

        if simulate_timeout_after_data:
            raise TimeoutError("SMTP timeout after DATA command (message already accepted by MTA)")

        return {
            "status": "sent",
            "deduplicated": False,
            "sent_message_id": sent_id,
            "outbox_id": outbox_id,
            "message_id_header": msg_hdr,
            "idempotency_key": idem_key,
            "delivery_count": 1,
        }

    def _commit_delivery(self, entry: OutboxEntry) -> str:
        existing = self._delivered_by_idempotency_key.get(entry.idempotency_key)
        if existing is not None:
            entry.status = "sent"
            return existing

        acc = self._accounts[entry.account_id]
        uid = acc.uidnext_by_folder.get("Sent", 1)
        acc.uidnext_by_folder["Sent"] = uid + 1
        sent_id = f"sent_{entry.idempotency_key[:12]}"
        sent_msg = MailMessage(
            id=sent_id,
            account_id=entry.account_id,
            owner_user_id=entry.owner_user_id,
            uid=uid,
            uidvalidity=acc.uidvalidity_by_folder.get("Sent", 100),
            modseq=1,
            message_id_header=entry.message_id_header,
            thread_id=f"thr_{sent_id}",
            folder="Sent",
            subject=entry.subject,
            sender=acc.email_address,
            recipients=list(entry.to),
            date_iso=datetime.now(UTC).isoformat(),
            snippet=entry.body_text[:120],
            body_html=entry.body_html,
            body_text=entry.body_text,
            unread=False,
            in_reply_to=entry.in_reply_to,
            references=list(entry.references),
        )
        self._messages[sent_id] = sent_msg
        self._compact_headers.setdefault(entry.account_id, {}).setdefault("Sent", {})[uid] = (
            sent_msg.id,
            sent_msg.subject,
            sent_msg.sender,
            sent_msg.date_iso,
            False,
            1,
        )
        entry.status = "sent"
        self._delivered_by_idempotency_key[entry.idempotency_key] = sent_id
        self._delivered_by_message_id_header[entry.message_id_header] = sent_id
        return sent_id

    def cancel_undo_send(self, outbox_id: str) -> dict[str, Any]:
        """Cancel a pending send within the undo-send window and move back to Drafts."""
        entry = self._outbox.get(outbox_id)
        if entry is None:
            raise KeyError(f"Outbox entry not found: {outbox_id}")
        if entry.status == "sent":
            return {"outbox_id": outbox_id, "cancelled": False, "reason": "already_sent"}
        entry.status = "cancelled"
        draft = self.save_draft(
            owner_user_id=entry.owner_user_id,
            account_id=entry.account_id,
            to=entry.to,
            subject=entry.subject,
            body_text=entry.body_text,
            body_html=entry.body_html,
        )
        return {"outbox_id": outbox_id, "cancelled": True, "draft_id": draft["id"]}

    def flush_outbox(self) -> dict[str, Any]:
        """Transition from offline to online and send all queued outbox messages idempotently."""
        self._offline_mode = False
        sent_ids: list[str] = []
        for entry in self._outbox.values():
            if entry.status in ("queued", "pending_undo"):
                entry.attempts += 1
                sent_ids.append(self._commit_delivery(entry))
        return {"flushed_count": len(sent_ids), "sent_message_ids": sent_ids}

    def get_delivery_count(self, idempotency_key: str) -> int:
        return 1 if idempotency_key in self._delivered_by_idempotency_key else 0

    def triage_message(
        self,
        message_id: str,
        *,
        owner_user_id: str = "system",
        apply_auto_actions: bool = False,
    ) -> TriageResult:
        """Human-supervised AI triage: urgency, tags, summary, spam, draft reply, taint guard."""
        msg = self._messages.get(message_id)
        if msg is None:
            raise KeyError(f"Mail message not found: {message_id}")

        combined = f"{msg.subject}\n{msg.body_text}\n{msg.body_html}"
        inj_warnings: list[str] = []
        for pat in _EMAIL_INJECTION_PATTERNS:
            m = pat.search(combined)
            if m:
                inj_warnings.append(f"prompt_injection_pattern:{m.group(0)[:48]}")

        injection_detected = len(inj_warnings) > 0
        if injection_detected:
            self._security_audit_log.append(
                {
                    "event": "email_prompt_injection_blocked",
                    "message_id": msg.id,
                    "sender": msg.sender,
                    "warnings": list(inj_warnings),
                    "unapproved_tool_calls_triggered": 0,
                    "ts": datetime.now(UTC).isoformat(),
                }
            )

        lower = combined.lower()
        is_spam = ("unsubscribe" in lower and "winner" in lower) or "viagra" in lower
        if "urgent" in lower or "asap" in lower or "incident" in lower:
            urgency = "urgent"
        elif "review" in lower or "deadline" in lower or "milestone" in lower:
            urgency = "high"
        else:
            urgency = "normal"

        tags: list[str] = ["triage:reviewed"]
        if is_spam:
            tags.append("spam")
        if urgency in ("urgent", "high"):
            tags.append(f"priority:{urgency}")
        if injection_detected:
            tags.append("security:untrusted-injection-flagged")

        dates = re.findall(r"\b20\d{2}-\d{2}-\d{2}(?:\s+\d{2}:\d{2})?\b", combined)
        tasks: list[str] = []
        if "review" in lower:
            tasks.append(f"Review: {msg.subject}")

        signoff = msg.recipients[0] if msg.recipients else "Operator"
        draft_body = (
            f"Hi,\n\nThank you for your email regarding '{msg.subject}'. "
            f"I have received it and will follow up shortly.\n\nBest,\n{signoff}"
        )
        draft_dict = self.save_draft(
            owner_user_id=owner_user_id,
            account_id=msg.account_id,
            to=[msg.sender],
            subject=f"Re: {msg.subject}",
            body_text=draft_body,
            in_reply_to=msg.message_id_header,
            references=[*msg.references, msg.message_id_header],
        )

        if is_spam:
            suggested_action = "mark_spam"
        elif "newsletter" in lower:
            suggested_action = "archive"
        else:
            suggested_action = "reply_draft"

        opt_in = self._triage_opt_in_rules.get(suggested_action, False)
        suggest_only = not (apply_auto_actions and opt_in)

        if not suggest_only and suggested_action in ("archive", "mark_spam"):
            old_folder = msg.folder
            new_folder = "Spam" if suggested_action == "mark_spam" else "Archive"
            msg.folder = new_folder
            self._triage_undo_log.append(
                {
                    "undo_id": f"undo_{uuid.uuid4().hex[:8]}",
                    "message_id": msg.id,
                    "old_folder": old_folder,
                    "new_folder": new_folder,
                }
            )

        res = TriageResult(
            message_id=msg.id,
            urgency=urgency,
            tags=tags,
            summary=f"Summary of '{msg.subject}' from {msg.sender}.",
            is_spam=is_spam,
            extracted_tasks=tasks,
            extracted_dates=dates,
            suggested_action=suggested_action,
            suggest_only=suggest_only,
            draft_reply_id=str(draft_dict["id"]),
            draft_reply_body=draft_body,
            injection_detected=injection_detected,
            injection_warnings=inj_warnings,
            unapproved_tool_calls_triggered=0,
            requires_approval_for_tools=True,
            provenance_source=f"email:{msg.sender}",
        )
        msg.triage = res
        return res

    def undo_last_triage_action(self) -> dict[str, Any]:
        if not self._triage_undo_log:
            return {"undone": False}
        entry = self._triage_undo_log.pop()
        msg = self._messages.get(entry["message_id"])
        if msg is not None:
            msg.folder = entry["old_folder"]
        return {"undone": True, **entry}

    def get_security_audit_log(self) -> list[dict[str, Any]]:
        return list(self._security_audit_log)
