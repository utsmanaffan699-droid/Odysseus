"""Skills service: frontmatter parsing, progressive disclosure, eligibility, zip import, diffs."""

from __future__ import annotations

import difflib
import io
import os
import re
import shutil
import uuid
import zipfile
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any, Literal

import yaml
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.db import DatabaseManager
from backend.core.models import SkillRecord, SkillVersionRecord
from backend.core.uow import UnitOfWork, _ensure_utc

SkillScopeLiteral = Literal["user", "project", "global"]

_SKILL_SECURITY_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (
    (
        "remote_pipe_to_shell",
        re.compile(
            r"(?:curl|wget|fetch)\b[^\n|]*\|\s*(?:ba|z)?sh\b",
            re.IGNORECASE,
        ),
    ),
    (
        "destructive_filesystem_command",
        re.compile(r"\b(?:rm\s+-rf\s+/|mkfs\.|dd\s+if=/dev/)", re.IGNORECASE),
    ),
    (
        "credential_exfiltration_pattern",
        re.compile(r"(?:\.ssh/id_rsa|/etc/shadow|AWS_SECRET_ACCESS_KEY)", re.IGNORECASE),
    ),
    (
        "prompt_injection_override",
        re.compile(
            r"(?:ignore\s+all\s+previous\s+instructions|<\|im_start\|>|\[SYSTEM\s*OVERRIDE\])",
            re.IGNORECASE,
        ),
    ),
)


def scan_skill_security(markdown_text: str) -> list[str]:
    """Statically scan skill markdown for malicious shell pipes, exfil, or injection patterns."""
    findings: list[str] = []
    for code, pattern in _SKILL_SECURITY_PATTERNS:
        if pattern.search(markdown_text):
            findings.append(code)
    return findings


@dataclass(frozen=True)
class ParsedSkillDocument:
    """Parsed skill Markdown document with YAML frontmatter."""

    name: str
    description: str
    when_to_use: str
    requires: dict[str, list[str]]
    tools: list[str]
    body_markdown: str


@dataclass(frozen=True)
class SkillEligibility:
    """Eligibility evaluation for a skill in the current environment and user context."""

    eligible: bool
    reasons: list[str] = field(default_factory=list)


def parse_skill_markdown(raw_markdown: str) -> ParsedSkillDocument:
    """Parse a Markdown skill document starting with YAML frontmatter `--- ... ---`."""
    cleaned = raw_markdown.lstrip("\ufeff").strip()
    meta: dict[str, Any] = {}
    body = cleaned

    if cleaned.startswith("---"):
        parts = cleaned.split("---", 2)
        if len(parts) >= 3:
            fm_raw = parts[1].strip()
            body = parts[2].strip()
            loaded = yaml.safe_load(fm_raw)
            if isinstance(loaded, dict):
                meta = loaded

    name = str(meta.get("name", "")).strip()
    if not name:
        raise ValueError("Skill frontmatter must define a non-empty 'name'")

    description = str(meta.get("description", "")).strip()
    when_to_use = str(meta.get("when_to_use", "")).strip()

    raw_req = meta.get("requires", {})
    req_dict: dict[str, list[str]] = {"binaries": [], "env": [], "privileges": []}
    if isinstance(raw_req, dict):
        for k in ("binaries", "env", "privileges"):
            val = raw_req.get(k, [])
            if isinstance(val, list):
                req_dict[k] = [str(item).strip() for item in val if str(item).strip()]

    raw_tools = meta.get("tools", [])
    tools_list = (
        [str(t).strip() for t in raw_tools if str(t).strip()] if isinstance(raw_tools, list) else []
    )

    return ParsedSkillDocument(
        name=name,
        description=description,
        when_to_use=when_to_use,
        requires=req_dict,
        tools=tools_list,
        body_markdown=body,
    )


def check_skill_eligibility(
    requires: dict[str, Any],
    *,
    user_privileges: frozenset[str],
    environ: dict[str, str] | None = None,
) -> SkillEligibility:
    """Verify whether a skill's required binaries, env vars, and privileges are satisfied."""
    env_map = environ if environ is not None else dict(os.environ)
    reasons: list[str] = []

    for binary in requires.get("binaries", []) or []:
        if shutil.which(str(binary)) is None:
            reasons.append(f"Missing required binary: {binary}")

    for env_key in requires.get("env", []) or []:
        if not env_map.get(str(env_key)):
            reasons.append(f"Missing required environment variable: {env_key}")

    is_admin = "admin" in user_privileges
    for priv in requires.get("privileges", []) or []:
        if str(priv) not in user_privileges and not is_admin:
            reasons.append(f"Missing required privilege: {priv}")

    return SkillEligibility(eligible=(len(reasons) == 0), reasons=reasons)


def _skill_to_dict(
    rec: SkillRecord,
    *,
    user_privileges: frozenset[str] = frozenset({"chat", "agent"}),
    include_body: bool = False,
) -> dict[str, Any]:
    elig = check_skill_eligibility(rec.requires_json or {}, user_privileges=user_privileges)
    sec_warnings = scan_skill_security(rec.body_markdown or "")
    requires_review = bool((rec.untrusted or sec_warnings) and not rec.reviewed)
    reasons = list(elig.reasons)
    if requires_review:
        reasons.append("Requires explicit security review before activation")
    out: dict[str, Any] = {
        "id": rec.id,
        "user_id": rec.user_id,
        "project_id": rec.project_id,
        "scope": rec.scope,
        "name": rec.name,
        "description": rec.description,
        "when_to_use": rec.when_to_use,
        "requires": rec.requires_json or {},
        "tools": rec.tools_json or [],
        "version": rec.version,
        "untrusted": bool(rec.untrusted or sec_warnings),
        "reviewed": rec.reviewed,
        "security_warnings": sec_warnings,
        "requires_security_review": requires_review,
        "source_origin": rec.source_origin,
        "eligible": elig.eligible and not requires_review,
        "ineligible_reasons": reasons,
        "created_at": _ensure_utc(rec.created_at).isoformat(),
        "updated_at": _ensure_utc(rec.updated_at).isoformat(),
    }
    if include_body:
        out["body_markdown"] = rec.body_markdown
    return out


class SkillService:
    """Manages skill CRUD, progressive disclosure index, untrusted imports, and version diffs."""

    def __init__(self, db: DatabaseManager) -> None:
        self.db = db

    async def create_or_update_skill(
        self,
        *,
        user_id: str,
        raw_markdown: str,
        scope: SkillScopeLiteral = "user",
        project_id: str | None = None,
        untrusted: bool = False,
        source_origin: str = "local",
    ) -> dict[str, Any]:
        parsed = parse_skill_markdown(raw_markdown)
        sec_findings = scan_skill_security(parsed.body_markdown)
        effective_untrusted = bool(untrusted or sec_findings)
        now = datetime.now(UTC)

        async def _tx(sess: AsyncSession) -> dict[str, Any]:
            uow = UnitOfWork(sess)
            existing = await uow.skills.get_by_name(parsed.name, user_id=user_id)
            if existing is not None and existing.user_id == user_id and existing.scope == scope:
                old_body = existing.body_markdown
                new_ver = existing.version + 1
                diff_str = "".join(
                    difflib.unified_diff(
                        old_body.splitlines(keepends=True),
                        parsed.body_markdown.splitlines(keepends=True),
                        fromfile=f"{parsed.name}@v{existing.version}",
                        tofile=f"{parsed.name}@v{new_ver}",
                    )
                )
                existing.description = parsed.description
                existing.when_to_use = parsed.when_to_use
                existing.requires_json = parsed.requires
                existing.tools_json = parsed.tools
                existing.body_markdown = parsed.body_markdown
                existing.version = new_ver
                existing.updated_at = now
                if effective_untrusted:
                    existing.untrusted = True
                    existing.reviewed = False
                    existing.source_origin = source_origin

                await uow.skills.add_version(
                    SkillVersionRecord(
                        id=f"skv_{uuid.uuid4().hex[:20]}",
                        skill_id=existing.id,
                        version=new_ver,
                        body_markdown=parsed.body_markdown,
                        diff_summary=diff_str,
                        created_at=now,
                    )
                )
                return _skill_to_dict(existing, include_body=True)

            skill_id = f"sk_{uuid.uuid4().hex[:20]}"
            rec = SkillRecord(
                id=skill_id,
                user_id=user_id,
                project_id=project_id,
                scope=scope,
                name=parsed.name,
                description=parsed.description,
                when_to_use=parsed.when_to_use,
                requires_json=parsed.requires,
                tools_json=parsed.tools,
                body_markdown=parsed.body_markdown,
                version=1,
                untrusted=effective_untrusted,
                reviewed=not effective_untrusted,
                source_origin=source_origin,
                created_at=now,
                updated_at=now,
            )
            await uow.skills.add(rec)
            await uow.skills.add_version(
                SkillVersionRecord(
                    id=f"skv_{uuid.uuid4().hex[:20]}",
                    skill_id=skill_id,
                    version=1,
                    body_markdown=parsed.body_markdown,
                    diff_summary="Initial version",
                    created_at=now,
                )
            )
            return _skill_to_dict(rec, include_body=True)

        return await self.db.execute_write(_tx)

    async def import_skills_from_zip(
        self,
        *,
        user_id: str,
        zip_bytes: bytes,
        scope: SkillScopeLiteral = "user",
        source_origin: str = "zip_import",
        max_uncompressed_bytes: int = 2_097_152,
    ) -> list[dict[str, Any]]:
        """Import one or more `.md` skills from a zip archive, flagging them untrusted."""
        if len(zip_bytes) > max_uncompressed_bytes:
            raise ValueError("Zip archive exceeds maximum allowed size")

        imported: list[dict[str, Any]] = []
        total_uncompressed = 0
        with zipfile.ZipFile(io.BytesIO(zip_bytes), "r") as zf:
            for info in zf.infolist():
                if info.is_dir() or not info.filename.endswith(".md"):
                    continue
                if ".." in info.filename or info.filename.startswith("/"):
                    raise ValueError(f"Unsafe zip member path: {info.filename}")
                total_uncompressed += info.file_size
                if total_uncompressed > max_uncompressed_bytes:
                    raise ValueError("Zip archive uncompressed content exceeds size limit")
                md_text = zf.read(info.filename).decode("utf-8", errors="replace")
                item = await self.create_or_update_skill(
                    user_id=user_id,
                    raw_markdown=md_text,
                    scope=scope,
                    untrusted=True,
                    source_origin=f"{source_origin}:{info.filename}",
                )
                imported.append(item)
        return imported

    async def review_skill(self, *, skill_id: str, user_id: str) -> dict[str, Any]:
        """Mark an imported untrusted skill as reviewed."""
        now = datetime.now(UTC)

        async def _tx(sess: AsyncSession) -> dict[str, Any]:
            uow = UnitOfWork(sess)
            rec = await uow.skills.get(skill_id)
            if rec is None:
                raise LookupError(f"Skill '{skill_id}' not found")
            if rec.user_id not in (user_id, None):
                raise LookupError(f"Skill '{skill_id}' not found")
            rec.reviewed = True
            rec.updated_at = now
            return _skill_to_dict(rec, include_body=True)

        return await self.db.execute_write(_tx)

    async def list_skills(
        self,
        *,
        user_id: str,
        project_id: str | None = None,
        user_privileges: frozenset[str] = frozenset({"chat", "agent"}),
    ) -> list[dict[str, Any]]:
        async def _load(sess: AsyncSession) -> list[dict[str, Any]]:
            uow = UnitOfWork(sess)
            rows = await uow.skills.list_visible(user_id, project_id=project_id)
            return [_skill_to_dict(r, user_privileges=user_privileges) for r in rows]

        return await self.db.execute_read(_load)

    async def build_progressive_disclosure_index(
        self,
        *,
        user_id: str,
        project_id: str | None = None,
        user_privileges: frozenset[str] = frozenset({"chat", "agent"}),
    ) -> str:
        """Return name + description + when_to_use for eligible skills."""
        skills = await self.list_skills(
            user_id=user_id,
            project_id=project_id,
            user_privileges=user_privileges,
        )
        eligible = [s for s in skills if s["eligible"]]
        if not eligible:
            return ""
        lines = ["Available Skills (use `load_skill(name)` to load full instructions):"]
        for s in eligible:
            when = f" (when: {s['when_to_use']})" if s.get("when_to_use") else ""
            trust_tag = " [UNTRUSTED-IMPORT]" if s.get("untrusted") else ""
            lines.append(f"- {s['name']}{trust_tag}: {s['description']}{when}")
        return "\n".join(lines)

    async def load_skill_body(
        self,
        *,
        name: str,
        user_id: str,
        user_privileges: frozenset[str] = frozenset({"chat", "agent"}),
    ) -> dict[str, Any]:
        """Load the full body of a skill on demand (`load_skill` tool)."""

        async def _load(sess: AsyncSession) -> SkillRecord | None:
            uow = UnitOfWork(sess)
            return await uow.skills.get_by_name(name, user_id=user_id)

        rec = await self.db.execute_read(_load)
        if rec is None:
            raise LookupError(f"Skill '{name}' not found")
        info = _skill_to_dict(rec, user_privileges=user_privileges, include_body=True)
        if not info["eligible"]:
            reasons_str = "; ".join(info["ineligible_reasons"])
            raise PermissionError(f"Skill '{name}' is not eligible in this context: {reasons_str}")
        return info

    async def list_skill_versions(self, *, skill_id: str) -> list[dict[str, Any]]:
        async def _load(sess: AsyncSession) -> list[dict[str, Any]]:
            uow = UnitOfWork(sess)
            rows = await uow.skills.list_versions(skill_id)
            return [
                {
                    "id": v.id,
                    "skill_id": v.skill_id,
                    "version": v.version,
                    "body_markdown": v.body_markdown,
                    "diff_summary": v.diff_summary,
                    "created_at": _ensure_utc(v.created_at).isoformat(),
                }
                for v in rows
            ]

        return await self.db.execute_read(_load)

    async def diff_versions(
        self,
        *,
        skill_id: str,
        from_version: int,
        to_version: int,
    ) -> dict[str, Any]:
        """Compute unified diff between two versions of a skill."""
        versions = await self.list_skill_versions(skill_id=skill_id)
        by_ver = {int(v["version"]): str(v["body_markdown"]) for v in versions}
        if from_version not in by_ver or to_version not in by_ver:
            raise LookupError(f"Skill '{skill_id}' versions {from_version}->{to_version} not found")
        diff_text = "\n".join(
            difflib.unified_diff(
                by_ver[from_version].splitlines(),
                by_ver[to_version].splitlines(),
                fromfile=f"v{from_version}",
                tofile=f"v{to_version}",
                lineterm="",
            )
        )
        return {
            "skill_id": skill_id,
            "from_version": from_version,
            "to_version": to_version,
            "diff": diff_text,
        }
