"""Domain models, contracts, and business logic for Odysseus."""

from __future__ import annotations
