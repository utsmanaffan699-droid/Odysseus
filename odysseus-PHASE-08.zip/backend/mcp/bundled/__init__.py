"""Bundled MCP server presets (disabled by default, one-click enable)."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any


def get_bundled_mcp_presets(workspace_dir: Path) -> list[dict[str, Any]]:
    """Return the built-in bundled MCP server configurations (disabled by default)."""
    ws_str = str(workspace_dir)
    return [
        {
            "name": "filesystem",
            "transport": "stdio",
            "command_or_url": sys.executable,
            "args": ["-m", "backend.mcp.bundled.filesystem_server", ws_str],
            "enabled": False,
            "risk_overrides": {
                "read_file": "read",
                "list_dir": "read",
                "write_file": "write",
            },
            "description": "Jailed workspace filesystem MCP server.",
        },
        {
            "name": "fetch",
            "transport": "stdio",
            "command_or_url": sys.executable,
            "args": ["-m", "backend.mcp.bundled.fetch_server"],
            "enabled": False,
            "risk_overrides": {"fetch_url": "network"},
            "description": "SSRF-safe HTTP/HTML fetch MCP server.",
        },
        {
            "name": "playwright",
            "transport": "stdio",
            "command_or_url": sys.executable,
            "args": ["-m", "backend.mcp.bundled.playwright_server", ws_str],
            "enabled": False,
            "risk_overrides": {"snapshot_cached_html": "read"},
            "description": "Cached-only offline DOM snapshot MCP server (opt-in).",
        },
    ]


__all__ = ["get_bundled_mcp_presets"]
