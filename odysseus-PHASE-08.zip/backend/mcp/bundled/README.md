# Bundled MCP Servers (`backend/mcp/bundled/`)

Odysseus ships with three bundled stdio MCP servers that are disabled by default and can be enabled per-user:

1. **`filesystem_server.py` (`python -m backend.mcp.bundled.filesystem_server <jail_dir>`)**
   - Provides `read_file`, `write_file`, and `list_dir` strictly jailed inside `<jail_dir>` via `resolve_jailed_path` (`O_NOFOLLOW`, traversal/symlink rejection).
2. **`fetch_server.py` (`python -m backend.mcp.bundled.fetch_server`)**
   - Provides `fetch_url` backed by Odysseus's SSRF-safe HTTP fetcher (`safe_fetch_url`), blocking private, loopback, link-local, CGNAT, and cloud-metadata IP ranges.
3. **`playwright_server.py` (`python -m backend.mcp.bundled.playwright_server <jail_dir>`)**
   - Optional cached-only DOM inspection server (`snapshot_cached_html`) that extracts structured DOM text and links from cached HTML files inside `<jail_dir>` without making live network requests.
