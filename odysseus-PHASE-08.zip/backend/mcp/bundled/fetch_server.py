"""Bundled SSRF-safe Fetch MCP server speaking JSON-RPC 2.0 over stdio."""

from __future__ import annotations

import asyncio
import json
import sys
from typing import Any

from backend.domain.tools.web_tools import safe_fetch_url


async def _handle_request(req: dict[str, Any]) -> dict[str, Any] | None:
    req_id = req.get("id")
    method = str(req.get("method", ""))
    params = req.get("params") or {}
    if req_id is None:
        return None

    if method == "initialize":
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "protocolVersion": "2024-11-05",
                "serverInfo": {"name": "odysseus-bundled-fetch", "version": "0.1.0"},
                "capabilities": {"tools": {}},
            },
        }

    if method == "tools/list":
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "tools": [
                    {
                        "name": "mcp_fetch_url",
                        "description": "Fetch an external HTTP/HTTPS URL with SSRF-safe checks.",
                        "inputSchema": {
                            "type": "object",
                            "properties": {"url": {"type": "string"}},
                            "required": ["url"],
                        },
                    }
                ]
            },
        }

    if method == "tools/call":
        tname = str(params.get("name", ""))
        targs = params.get("arguments") or {}
        if tname != "mcp_fetch_url":
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "error": {"code": -32601, "message": f"Unknown tool: {tname}"},
            }
        try:
            page = await safe_fetch_url(str(targs.get("url", "")))
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "content": [{"type": "text", "text": page.content}],
                    "isError": False,
                },
            }
        except Exception as exc:
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "content": [{"type": "text", "text": f"Fetch blocked: {exc}"}],
                    "isError": True,
                },
            }

    return {
        "jsonrpc": "2.0",
        "id": req_id,
        "result": {},
    }


def main() -> None:
    sys.stderr.write("[odysseus-bundled-fetch] started\n")
    sys.stderr.flush()
    while True:
        line = sys.stdin.readline()
        if not line:
            break
        stripped = line.strip()
        if not stripped:
            continue
        try:
            req = json.loads(stripped)
            if isinstance(req, dict):
                resp = asyncio.run(_handle_request(req))
                if resp is not None:
                    sys.stdout.write(json.dumps(resp) + "\n")
                    sys.stdout.flush()
        except Exception as exc:
            sys.stderr.write(f"[odysseus-bundled-fetch] error: {exc}\n")
            sys.stderr.flush()


if __name__ == "__main__":
    main()
