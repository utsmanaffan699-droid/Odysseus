"""Bundled cached-only Playwright/DOM inspection MCP server over stdio.

Disabled by default unless the user explicitly opts in. Operates strictly in cached/offline
mode: never makes live outbound network requests, only parses and extracts structured DOM
snapshots from cached HTML payloads or workspace HTML files inside the user's jail.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

from bs4 import BeautifulSoup

from backend.domain.tools.filesystem import workspace_read_file
from backend.domain.tools.web_tools import extract_readable_html


def handle_request(req: dict[str, Any], jail_root: Path) -> dict[str, Any] | None:
    method = req.get("method", "")
    req_id = req.get("id")
    params = req.get("params") or {}

    if method == "notifications/initialized":
        return None

    if method == "initialize":
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "protocolVersion": "2024-11-05",
                "capabilities": {"tools": {}},
                "serverInfo": {"name": "odysseus-bundled-playwright", "version": "1.0.0"},
            },
        }

    if method == "tools/list":
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "tools": [
                    {
                        "name": "snapshot_cached_html",
                        "description": (
                            "Extract a structured DOM accessibility snapshot and links from a "
                            "cached HTML file in the jailed workspace (offline/cached-only)."
                        ),
                        "inputSchema": {
                            "type": "object",
                            "properties": {
                                "path": {
                                    "type": "string",
                                    "description": "Relative path to cached .html file.",
                                }
                            },
                            "required": ["path"],
                        },
                    }
                ]
            },
        }

    if method == "tools/call":
        name = params.get("name")
        args = params.get("arguments") or {}
        try:
            if name == "snapshot_cached_html":
                rel_path = str(args.get("path", ""))
                html_raw = str(workspace_read_file(jail_root, rel_path)["raw_content"])
                title, readable = extract_readable_html(html_raw)
                soup = BeautifulSoup(html_raw, "html.parser")
                links = [
                    {"text": a.get_text(strip=True)[:80], "href": str(a.get("href", ""))[:200]}
                    for a in soup.find_all("a", href=True)[:50]
                ]
                payload = json.dumps(
                    {
                        "mode": "cached_only",
                        "title": title,
                        "readable_text": readable,
                        "links": links,
                    },
                    ensure_ascii=False,
                )
                return {
                    "jsonrpc": "2.0",
                    "id": req_id,
                    "result": {
                        "content": [{"type": "text", "text": payload}],
                        "isError": False,
                    },
                }
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "error": {"code": -32601, "message": f"Unknown tool: {name}"},
            }
        except Exception as exc:
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "content": [{"type": "text", "text": f"Error: {exc}"}],
                    "isError": True,
                },
            }

    if method in ("resources/list", "prompts/list"):
        key = "resources" if method.startswith("resources") else "prompts"
        return {"jsonrpc": "2.0", "id": req_id, "result": {key: []}}

    return {
        "jsonrpc": "2.0",
        "id": req_id,
        "error": {"code": -32601, "message": f"Method not found: {method}"},
    }


def main() -> int:
    jail_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
    jail_dir.mkdir(parents=True, exist_ok=True)
    while True:
        line = sys.stdin.readline()
        if not line:
            break
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except json.JSONDecodeError:
            continue
        resp = handle_request(req, jail_dir)
        if resp is not None:
            sys.stdout.write(json.dumps(resp) + "\n")
            sys.stdout.flush()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
