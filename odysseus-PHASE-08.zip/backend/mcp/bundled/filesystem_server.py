"""Bundled workspace-jailed Filesystem MCP server speaking JSON-RPC 2.0 over stdio."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

from backend.domain.tools.filesystem import (
    workspace_list_dir,
    workspace_read_file,
    workspace_write_file,
)


def _handle_request(req: dict[str, Any], root: Path) -> dict[str, Any] | None:
    req_id = req.get("id")
    method = str(req.get("method", ""))
    params = req.get("params") or {}

    if req_id is None:
        return None

    if method == "initialize":
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "protocolVersion": "2024-11-05",
                "serverInfo": {"name": "odysseus-bundled-filesystem", "version": "0.1.0"},
                "capabilities": {"tools": {}, "resources": {}, "prompts": {}},
            },
        }

    if method == "tools/list":
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "tools": [
                    {
                        "name": "mcp_fs_read",
                        "description": "Read a file inside the jailed workspace directory.",
                        "inputSchema": {
                            "type": "object",
                            "properties": {"path": {"type": "string"}},
                            "required": ["path"],
                        },
                    },
                    {
                        "name": "read_text_file",
                        "description": (
                            "Read a UTF-8 text file inside the jailed workspace directory."
                        ),
                        "inputSchema": {
                            "type": "object",
                            "properties": {"path": {"type": "string"}},
                            "required": ["path"],
                        },
                    },
                    {
                        "name": "mcp_fs_write",
                        "description": "Write a UTF-8 file inside the jailed workspace directory.",
                        "inputSchema": {
                            "type": "object",
                            "properties": {
                                "path": {"type": "string"},
                                "content": {"type": "string"},
                            },
                            "required": ["path", "content"],
                        },
                    },
                    {
                        "name": "mcp_fs_list",
                        "description": "List entries inside a jailed workspace directory.",
                        "inputSchema": {
                            "type": "object",
                            "properties": {"path": {"type": "string"}},
                        },
                    },
                    {
                        "name": "list_directory",
                        "description": "List files and directories inside a jailed workspace path.",
                        "inputSchema": {
                            "type": "object",
                            "properties": {"path": {"type": "string"}},
                        },
                    },
                ]
            },
        }

    if method == "resources/list":
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "resources": [
                    {
                        "uri": f"file://{root}",
                        "name": "Workspace Root",
                        "mimeType": "inode/directory",
                    }
                ]
            },
        }

    if method == "prompts/list":
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "prompts": [
                    {
                        "name": "inspect_workspace",
                        "description": "Summarize files in the current workspace.",
                    }
                ]
            },
        }

    if method == "tools/call":
        tname = str(params.get("name", ""))
        targs = params.get("arguments") or {}
        try:
            if tname in ("mcp_fs_read", "read_text_file"):
                res = workspace_read_file(root, str(targs.get("path", "")))
                text_out = str(res["raw_content"])
            elif tname == "mcp_fs_write":
                res = workspace_write_file(
                    root,
                    str(targs.get("path", "")),
                    str(targs.get("content", "")),
                )
                text_out = json.dumps(res)
            elif tname in ("mcp_fs_list", "list_directory"):
                res = workspace_list_dir(root, str(targs.get("path", ".")))
                text_out = json.dumps(res)
            else:
                return {
                    "jsonrpc": "2.0",
                    "id": req_id,
                    "error": {"code": -32601, "message": f"Unknown tool: {tname}"},
                }
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "content": [{"type": "text", "text": text_out}],
                    "isError": False,
                },
            }
        except Exception as exc:
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "content": [{"type": "text", "text": f"Error: {exc}"}],
                    "isError": True,
                },
            }

    return {
        "jsonrpc": "2.0",
        "id": req_id,
        "error": {"code": -32601, "message": f"Method not found: {method}"},
    }


def main() -> None:
    workspace_arg = sys.argv[1] if len(sys.argv) > 1 else "./data/workspaces/mcp_default"
    root = Path(workspace_arg).resolve()
    root.mkdir(parents=True, exist_ok=True)
    sys.stderr.write(f"[odysseus-bundled-filesystem] started jailed at {root}\n")
    sys.stderr.flush()

    while True:
        line = sys.stdin.readline()
        if not line:
            break
        stripped = line.strip()
        if not stripped:
            continue
        try:
            req = json.loads(stripped)
            if not isinstance(req, dict):
                continue
            resp = _handle_request(req, root)
            if resp is not None:
                sys.stdout.write(json.dumps(resp) + "\n")
                sys.stdout.flush()
        except Exception as exc:
            sys.stderr.write(f"[odysseus-bundled-filesystem] error: {exc}\n")
            sys.stderr.flush()


if __name__ == "__main__":
    main()
