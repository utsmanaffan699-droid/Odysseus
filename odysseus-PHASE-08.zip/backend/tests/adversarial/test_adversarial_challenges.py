"""Adversarial Challenge Suite (Phase 01 §4: Fuzzer, Headers, SQLite Storm, Disk, Secrets)."""

from __future__ import annotations

import asyncio
import errno
import json
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

import httpx
from backend.app.main import create_app
from backend.core.auth import create_user_session, hash_password, mint_api_token
from backend.core.db import DatabaseManager, get_disk_degraded
from backend.core.logging import get_recent_sanitized_logs
from backend.core.models import ChatRecord, User
from backend.core.security import ROUTE_POLICIES, iter_api_routes
from backend.core.settings import Settings
from backend.core.uow import UnitOfWork


def _sample_path(route_path: str) -> str:
    return (
        route_path.replace("{session_id}", "ses_nonexistent")
        .replace("{token_id}", "tok_nonexistent")
        .replace("{run_id}", "r_nonexistent")
        .replace("{user_id}", "u_nonexistent")
        .replace("{full_path:path}", "assets/app.js")
    )


def _sample_body_for_route(path: str, method: str) -> dict[str, Any] | None:
    if method not in ("POST", "PUT", "PATCH"):
        return None
    if path == "/api/auth/login":
        return {"username": "nonexistent", "password": "wrongpassword"}
    if path == "/api/auth/password/change":
        return {"current_password": "wrongpassword", "new_password": "NewPassword!12345"}
    if path == "/api/auth/2fa/verify":
        return {"code": "000000"}
    if path == "/api/auth/tokens":
        return {"name": "fuzzer-tok", "scopes": ["chat"]}
    if path == "/api/chats":
        return {"title": "Fuzzer Chat"}
    if path == "/api/admin/users":
        return {
            "username": f"fuzz_{datetime.now(UTC).timestamp()}",
            "email": "fuzz@odysseus.local",
            "password": "FuzzUserPassword!2026",
            "privileges": ["chat"],
            "must_change_password": False,
        }
    if path.endswith("/privileges"):
        return {"privileges": ["chat"]}
    if path == "/api/admin/settings":
        return {"overrides": {"rate_limit_burst": 80}}
    if path == "/api/admin/secrets":
        return {"key": "fuzz_secret", "value": "secret_value_123"}
    if path == "/api/admin/jobs":
        return {"kind": "noop", "payload": {}}
    return {}


async def test_adversarial_1_auth_bypass_fuzzer_all_routes_x_credentials(
    tmp_path: Path,
) -> None:
    """Challenge 1: Enumerate every registered route x 6 credential states and assert policy."""
    data_dir = tmp_path / "data"
    settings = Settings(
        environment="test",
        data_dir=data_dir,
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{data_dir / 'fuzzer.db'}",
        rate_limit_requests_per_minute=100000,
        rate_limit_burst=10000,
    )
    app = create_app(settings, start_job_workers=False)

    async with app.router.lifespan_context(app):
        db: DatabaseManager = app.state.db

        # Seed credentials for: admin, regular user, expired, revoked, and wrong-scope token
        creds: dict[str, dict[str, str]] = {}

        async def _seed_actors(sess: object) -> None:
            from sqlalchemy.ext.asyncio import AsyncSession

            assert isinstance(sess, AsyncSession)
            uow = UnitOfWork(sess)
            now = datetime.now(UTC)

            # 1. Admin user (already bootstrapped, clear must_change_password)
            admin_user = await uow.users.get_by_username("admin")
            assert admin_user is not None
            admin_user.must_change_password = False
            admin_tok, admin_ses = await create_user_session(
                uow, settings, user=admin_user, ip_address="127.0.0.1", user_agent="fuzzer"
            )
            creds["admin"] = {"cookie": admin_tok, "csrf": admin_ses.csrf_token}

            # 2. Regular user with ONLY `chat` and `files` privileges
            reg_user = User(
                id="u_regular",
                username="regular_user",
                email="regular@odysseus.local",
                password_hash=hash_password("RegularPassword!2026"),
                must_change_password=False,
                totp_enabled=False,
                recovery_codes_hashes=[],
                is_active=True,
                created_at=now,
                updated_at=now,
            )
            await uow.users.add(reg_user)
            await uow.users.set_privileges(reg_user, ["chat", "files"], granted_by="admin")
            reg_tok, reg_ses = await create_user_session(
                uow, settings, user=reg_user, ip_address="127.0.0.1", user_agent="fuzzer"
            )
            creds["user"] = {"cookie": reg_tok, "csrf": reg_ses.csrf_token}

            # 3. Expired session
            exp_tok, exp_ses = await create_user_session(
                uow, settings, user=admin_user, ip_address="127.0.0.1", user_agent="fuzzer"
            )
            exp_ses.expires_at = now - timedelta(seconds=10)
            creds["expired"] = {"cookie": exp_tok, "csrf": exp_ses.csrf_token}

            # 4. Revoked session
            rev_tok, rev_ses = await create_user_session(
                uow, settings, user=admin_user, ip_address="127.0.0.1", user_agent="fuzzer"
            )
            rev_ses.revoked_at = now
            creds["revoked"] = {"cookie": rev_tok, "csrf": rev_ses.csrf_token}

            # 5. API token with ONLY `cookbook` scope (wrong scope for chat/files/admin routes)
            raw_wrong_scope, _ = await mint_api_token(
                uow, user=admin_user, name="cookbook-only", scopes=["cookbook"]
            )
            creds["wrong_scope_token"] = {"bearer": raw_wrong_scope}

        await db.execute_write(_seed_actors)

        transport = httpx.ASGITransport(app=app)
        surprises: list[str] = []

        for route in iter_api_routes(app):
            methods = {
                m.upper() for m in (route.methods or set()) if m.upper() not in ("HEAD", "OPTIONS")
            }
            for method in sorted(methods):
                policy = ROUTE_POLICIES[(method, route.path)]
                url_path = _sample_path(route.path)
                # Avoid revoking the live fuzzer sessions when testing /api/auth/logout
                if route.path == "/api/auth/logout":
                    continue

                body = _sample_body_for_route(route.path, method)

                for actor in (
                    "no_auth",
                    "expired",
                    "revoked",
                    "wrong_scope_token",
                    "user",
                    "admin",
                ):
                    async with httpx.AsyncClient(
                        transport=transport, base_url="http://localhost"
                    ) as client:
                        headers: dict[str, str] = {}
                        if actor in ("expired", "revoked", "user", "admin"):
                            client.cookies.set(settings.session_cookie_name, creds[actor]["cookie"])
                            headers["X-CSRF-Token"] = creds[actor]["csrf"]
                        elif actor == "wrong_scope_token":
                            headers["Authorization"] = (
                                f"Bearer {creds['wrong_scope_token']['bearer']}"
                            )

                        resp = await client.request(
                            method,
                            url_path,
                            json=body if body is not None else None,
                            headers=headers,
                        )

                        if policy.level == "public":
                            # Public routes never fail session auth (except login & HMAC webhook)
                            if route.path not in (
                                "/api/auth/login",
                                "/api/webhooks/inbound/{endpoint_id}",
                            ) and resp.status_code in (401, 403):
                                surprises.append(
                                    f"Public {method} {route.path} rejected {actor}: "
                                    f"{resp.status_code}"
                                )
                        else:
                            # Non-public route: no_auth, expired, revoked MUST be 401
                            if actor in ("no_auth", "expired", "revoked"):
                                if resp.status_code != 401:
                                    surprises.append(
                                        f"Auth bypass on {method} {route.path} for {actor}: "
                                        f"expected 401, got {resp.status_code}"
                                    )
                            elif actor == "wrong_scope_token":
                                # Token has `cookbook` scope; MUST be 403 on other privilege routes
                                if (
                                    policy.level not in ("authenticated", "cookbook")
                                    and resp.status_code != 403
                                ):
                                    surprises.append(
                                        f"Scope bypass on {method} {route.path} "
                                        f"(level={policy.level}): got {resp.status_code}"
                                    )
                            elif actor == "user":
                                # User has `chat` and `files`; MUST be 403 on `admin`/`cookbook`
                                if (
                                    policy.level in ("admin", "cookbook")
                                    and resp.status_code != 403
                                ):
                                    surprises.append(
                                        f"Privilege escalation on {method} {route.path}: "
                                        f"expected 403, got {resp.status_code}"
                                    )
                            elif actor == "admin":
                                # Admin has all privileges; must NEVER get 403 or session 401
                                if resp.status_code == 403 or (
                                    resp.status_code == 401
                                    and route.path
                                    not in ("/api/auth/password/change", "/api/auth/2fa/verify")
                                ):
                                    surprises.append(
                                        f"Admin rejected on {method} {route.path}: "
                                        f"got {resp.status_code} ({resp.text})"
                                    )

        assert not surprises, "Auth bypass fuzzer found policy violations:\n" + "\n".join(surprises)


async def test_adversarial_2_header_injection_host_spoofed_xff_oversized_and_slowloris(
    tmp_path: Path,
) -> None:
    """Challenge 2: Bad Host, spoofed XFF, oversized headers (431), body (413), slowloris (408)."""
    data_dir = tmp_path / "data"
    settings = Settings(
        environment="test",
        data_dir=data_dir,
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{data_dir / 'headers.db'}",
        allowed_hosts=["localhost", "127.0.0.1"],
        trusted_proxies=["127.0.0.1"],
        max_header_bytes=2048,
        max_header_count=25,
        max_body_bytes_default=1024,
        max_body_bytes_auth=512,
        max_body_bytes_upload=2048,
        request_read_timeout_seconds=1,
        login_max_attempts_per_ip=3,
    )
    app = create_app(settings, start_job_workers=False)

    async with app.router.lifespan_context(app):
        transport = httpx.ASGITransport(app=app, client=("127.0.0.1", 50000))
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client:
            # 1. Host header attack (untrusted host) -> 400 Bad Request
            r_bad_host = await client.get(
                "/api/health/live", headers={"Host": "evil.attacker.example"}
            )
            assert r_bad_host.status_code == 400

            # 2. Oversized header value (> 2048 bytes) -> 431 Request Header Fields Too Large
            r_big_hdr = await client.get("/api/health/live", headers={"X-Giant-Header": "A" * 3000})
            assert r_big_hdr.status_code == 431

            # 3. Too many headers (> 25 headers) -> 431
            many_headers = {f"X-Custom-{i}": "val" for i in range(30)}
            r_many_hdr = await client.get("/api/health/live", headers=many_headers)
            assert r_many_hdr.status_code == 431

            # 4. Oversized body on auth route (> 512 bytes) -> 413 Content Too Large
            r_big_body = await client.post(
                "/api/auth/login",
                content=json.dumps({"username": "admin", "password": "P" * 800}),
                headers={"Content-Type": "application/json"},
            )
            assert r_big_body.status_code == 413

        # 5. Spoofed X-Forwarded-For from an UNTRUSTED peer IP (192.0.2.99 not in trusted_proxies)
        # Attacker rotates X-Forwarded-For on every request to try bypassing login throttling,
        # but middleware ignores XFF from untrusted peer and throttles 192.0.2.99!
        untrusted_transport = httpx.ASGITransport(app=app, client=("192.0.2.99", 51000))
        async with httpx.AsyncClient(
            transport=untrusted_transport, base_url="http://localhost"
        ) as untrusted_client:
            codes: list[int] = []
            for i in range(5):
                r_spoof = await untrusted_client.post(
                    "/api/auth/login",
                    json={"username": "admin", "password": "bad"},
                    headers={"X-Forwarded-For": f"10.0.0.{i}"},
                )
                codes.append(r_spoof.status_code)
            assert 429 in codes, f"Spoofed X-Forwarded-For bypassed IP throttle: {codes}"

            # Also verify spoofed X-Forwarded-Proto: https from untrusted peer does NOT inject HSTS
            r_proto = await untrusted_client.get(
                "/api/health/live",
                headers={"X-Forwarded-Proto": "https"},
            )
            assert "Strict-Transport-Security" not in r_proto.headers

        # 6. Slow-loris attack on upload route: stall body past request_read_timeout_seconds -> 408
        scope = {
            "type": "http",
            "asgi": {"version": "3.0"},
            "http_version": "1.1",
            "method": "POST",
            "scheme": "http",
            "path": "/api/uploads",
            "raw_path": b"/api/uploads",
            "query_string": b"",
            "headers": [
                (b"host", b"localhost"),
                (b"content-type", b"application/octet-stream"),
            ],
            "client": ("127.0.0.1", 52000),
            "server": ("127.0.0.1", 8000),
        }
        sent_responses: list[dict[str, Any]] = []

        async def slow_receive() -> dict[str, Any]:
            await asyncio.sleep(2.5)
            return {"type": "http.request", "body": b"late", "more_body": False}

        async def capture_send(msg: dict[str, Any]) -> None:
            sent_responses.append(msg)

        await app(scope, slow_receive, capture_send)
        start_msgs = [m for m in sent_responses if m.get("type") == "http.response.start"]
        assert len(start_msgs) == 1
        assert start_msgs[0]["status"] == 408


async def test_adversarial_3_sqlite_lock_storm_100_concurrent_writers(
    tmp_path: Path,
) -> None:
    """Challenge 3: 100 concurrent writers on SQLite WAL; zero `database is locked` leaks."""
    db_path = tmp_path / "storm.db"
    settings = Settings(
        database_url=f"sqlite+aiosqlite:///{db_path}",
        data_dir=tmp_path,
        db_busy_timeout_ms=30000,
    )
    db = DatabaseManager(settings)
    await db.create_schema_if_needed()

    try:

        async def _seed_user(sess: object) -> None:
            from sqlalchemy.ext.asyncio import AsyncSession

            assert isinstance(sess, AsyncSession)
            uow = UnitOfWork(sess)
            now = datetime.now(UTC)
            u = User(
                id="u_storm",
                username="storm_user",
                email="storm@odysseus.local",
                password_hash="h",
                must_change_password=False,
                totp_enabled=False,
                recovery_codes_hashes=[],
                is_active=True,
                created_at=now,
                updated_at=now,
            )
            await uow.users.add(u)

        await db.execute_write(_seed_user)

        async def _writer(idx: int) -> str:
            async def _op(sess: object) -> str:
                from sqlalchemy.ext.asyncio import AsyncSession

                assert isinstance(sess, AsyncSession)
                uow = UnitOfWork(sess)
                now = datetime.now(UTC)
                chat = ChatRecord(
                    id=f"c_storm_{idx:03d}",
                    user_id="u_storm",
                    title=f"Concurrent Chat {idx}",
                    model="fake/default",
                    created_at=now,
                    updated_at=now,
                )
                await uow.chats.create_chat(chat)
                return chat.id

            return await db.execute_write(_op)

        # Launch 100 concurrent writers simultaneously
        created_ids = await asyncio.gather(*[_writer(i) for i in range(100)])
        assert len(created_ids) == 100
        assert len(set(created_ids)) == 100

        async with db.session() as sess:
            uow = UnitOfWork(sess)
            chats = await uow.chats.list_chats("u_storm")
            assert len(chats) == 100
    finally:
        await db.dispose()


async def test_adversarial_4_disk_full_simulation_returns_507_and_degraded_explains(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    """Challenge 4: Disk-full simulation -> clean 507, app stays alive, /api/health/degraded."""
    data_dir = tmp_path / "data"
    settings = Settings(
        environment="test",
        data_dir=data_dir,
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{data_dir / 'diskfull.db'}",
    )
    app = create_app(settings, start_job_workers=False)

    async with app.router.lifespan_context(app):
        admin_pw = app.state.bootstrap_admin_result.temporary_password
        transport = httpx.ASGITransport(app=app)
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client:
            r_login = await client.post(
                "/api/auth/login",
                json={"username": "admin", "password": admin_pw},
            )
            csrf = r_login.json()["csrf_token"]
            await client.post(
                "/api/auth/password/change",
                json={"current_password": admin_pw, "new_password": "StrongAdminPassword!2026"},
                headers={"X-CSRF-Token": csrf},
            )
            r_tok = await client.post(
                "/api/auth/tokens",
                json={"name": "disk-test", "scopes": ["chat"]},
                headers={"X-CSRF-Token": csrf},
            )
            bearer = r_tok.json()["token"]

        # Simulate ENOSPC (No space left on device) when writing a new chat to the database
        db: DatabaseManager = app.state.db
        orig_run_once = db._run_once

        async def _enospc_on_create_chat(fn: Any) -> Any:
            if getattr(fn, "__qualname__", "").endswith("create_chat.<locals>._op"):
                raise OSError(errno.ENOSPC, "No space left on device (simulated tmpfs full)")
            return await orig_run_once(fn)

        monkeypatch.setattr(db, "_run_once", _enospc_on_create_chat)

        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client:
            r_full = await client.post(
                "/api/chats",
                json={"title": "Will fail with ENOSPC"},
                headers={"Authorization": f"Bearer {bearer}"},
            )
            assert r_full.status_code == 507
            assert "Insufficient storage" in r_full.json()["detail"]
            assert get_disk_degraded() is not None

            # App stays alive and /api/health/degraded explains the storage degradation + fix hint
            r_live = await client.get("/api/health/live")
            assert r_live.status_code == 200

            r_deg = await client.get("/api/health/degraded")
            assert r_deg.status_code == 200
            deg_body = r_deg.json()
            assert deg_body["degraded"] is True
            storage_items = [s for s in deg_body["services"] if s["service"] == "storage"]
            assert len(storage_items) == 1
            assert "No space left on device" in storage_items[0]["reason"]
            assert "ODYSSEUS_DATA_DIR" in storage_items[0]["fix_hint"]


async def test_adversarial_5_secret_leakage_scan(tmp_path: Path) -> None:
    """Challenge 5: Verify canary secrets appear nowhere in logs, metrics, errors, or bundle."""
    canary_env = "CANARY_ENV_SECRET_99887766_NEVER_LEAK"
    canary_vault = "CANARY_VAULT_SECRET_11223344_NEVER_LEAK"
    data_dir = tmp_path / "data"

    settings = Settings(
        environment="test",
        data_dir=data_dir,
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{data_dir / 'canary.db'}",
        canary_secret=canary_env,
        openai_api_key=canary_env,
    )
    app = create_app(settings, start_job_workers=False)

    async with app.router.lifespan_context(app):
        admin_pw = app.state.bootstrap_admin_result.temporary_password
        transport = httpx.ASGITransport(app=app)
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client:
            r_login = await client.post(
                "/api/auth/login",
                json={"username": "admin", "password": admin_pw},
            )
            csrf = r_login.json()["csrf_token"]
            await client.post(
                "/api/auth/password/change",
                json={"current_password": admin_pw, "new_password": "StrongAdminPassword!2026"},
                headers={"X-CSRF-Token": csrf},
            )

            # Store second canary in encrypted secret vault
            r_sec = await client.post(
                "/api/admin/secrets",
                json={"key": "provider_canary", "value": canary_vault},
                headers={"X-CSRF-Token": csrf},
            )
            assert r_sec.status_code == 200

            # Collect outputs from settings, audit log, metrics, and support bundle
            r_settings = await client.get("/api/admin/settings")
            r_audit = await client.get("/api/admin/audit")
            r_metrics = await client.get("/metrics")
            r_bundle = await client.get("/api/admin/diagnostics/support-bundle")

            corpus = "\n".join(
                [
                    r_settings.text,
                    r_audit.text,
                    r_metrics.text,
                    r_bundle.text,
                    json.dumps(get_recent_sanitized_logs()),
                ]
            )

            assert canary_env not in corpus, "Env canary secret leaked!"
            assert canary_vault not in corpus, "Vault canary secret leaked!"
            assert admin_pw not in corpus, "Bootstrap temporary password leaked!"
