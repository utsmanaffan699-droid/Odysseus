"""Phase 02 Adversarial & Chaos Suite: 50-run chaos, 5k flood, malicious frames, clock, 200-run."""

from __future__ import annotations

import asyncio
import contextlib
import resource
import secrets
import statistics
import time
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

import httpx
import pytest
from backend.app.main import create_app
from backend.core.settings import Settings
from backend.domain.runs.reducer import reduce_run_state
from backend.providers.adapters import OpenAICompatibleAdapter
from backend.providers.base import (
    ClassifiedProviderError,
    ProviderChatRequest,
    ProviderMessage,
)
from backend.providers.fake import FakeProvider, FakeScript, FakeScriptStep


async def _wait_terminal(app: Any, run_id: str, max_wait: float = 15.0) -> dict[str, Any]:
    snap = await app.state.run_manager.wait_for_run(run_id, max_wait_seconds=max_wait)
    if snap["status"] in ("succeeded", "failed", "cancelled", "interrupted"):
        return dict(snap)
    raise AssertionError(f"Run {run_id} did not terminate within {max_wait}s")


async def test_chaos_50_runs_fault_injection(tmp_path: Path) -> None:
    """Chaos harness: 50 runs under random SSE disconnects, 5xx errors, cancels, pauses, steers."""
    settings = Settings(
        environment="test",
        data_dir=tmp_path / "data",
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{tmp_path / 'chaos50.db'}",
        delta_coalesce_interval_ms=5,
        max_concurrent_runs_global=16,
        max_concurrent_runs_per_user=16,
        provider_max_retries=2,
    )
    fake = FakeProvider()
    app = create_app(settings, start_job_workers=False, fake_provider=fake)

    async def _fast_sleep(_sec: float) -> None:
        await asyncio.sleep(0.002)

    app.state.provider_router.sleep_fn = _fast_sleep
    rng = secrets.SystemRandom()

    async with app.router.lifespan_context(app):
        from backend.core.uow import UnitOfWork

        async with app.state.db.session() as sess:
            uow = UnitOfWork(sess)
            admin = await uow.users.get_by_username("admin")
            assert admin is not None
            uid = admin.id

        chat = await app.state.chat_service.create_chat(user_id=uid, title="Chaos 50")

        # Enqueue 60 scripts (some with transient 503s, some multi-chunk streams)
        for i in range(65):
            if i % 9 == 0:
                fake.enqueue_script(
                    FakeScript(
                        name=f"transient_503_{i}",
                        model="fake/default",
                        steps=[
                            FakeScriptStep(
                                kind="http_error",
                                status_code=503,
                                error_message="Chaos 503",
                            )
                        ],
                    )
                )
            fake.enqueue_script(
                FakeScript(
                    name=f"stream_{i}",
                    model="fake/default",
                    steps=[
                        *[
                            FakeScriptStep(kind="text", text=f"c{i}_{j} ", delay_ms=2)
                            for j in range(8)
                        ],
                        FakeScriptStep(kind="usage", input_tokens=10, output_tokens=8),
                    ],
                )
            )

        async def _run_one(idx: int) -> str:
            res = await app.state.run_manager.post_user_message_and_start_run(
                chat_id=chat["id"],
                user_id=uid,
                content=f"Chaos prompt #{idx}",
            )
            rid = str(res["run"]["id"])
            action = idx % 5
            await asyncio.sleep(rng.uniform(0.002, 0.02))

            if action == 0:
                # Cancel mid-run
                await app.state.run_manager.cancel_run(rid, user_id=uid)
            elif action == 1:
                # Pause then resume
                with contextlib.suppress(Exception):
                    await app.state.run_manager.pause_run(rid, user_id=uid)
                    await asyncio.sleep(0.005)
                    await app.state.run_manager.resume_run(rid, user_id=uid)
            elif action == 2:
                # Steer mid-run
                with contextlib.suppress(Exception):
                    await app.state.run_manager.steer_run(rid, "Stay concise", user_id=uid)
            elif action == 3:
                # Partial SSE read then reconnect
                count = 0
                last_seq = 0
                async with contextlib.aclosing(
                    app.state.run_manager.stream_sse(run_id=rid, user_id=uid, after_seq=0)
                ) as gen1:
                    async for _frame in gen1:
                        count += 1
                        if count >= 2:
                            break
                evs_so_far = await app.state.run_manager.list_events(rid)
                if evs_so_far:
                    last_seq = evs_so_far[-1].seq
                async with contextlib.aclosing(
                    app.state.run_manager.stream_sse(run_id=rid, user_id=uid, after_seq=last_seq)
                ) as gen2:
                    async for _frame in gen2:
                        pass

            await _wait_terminal(app, rid, max_wait=20.0)
            return rid

        run_ids = await asyncio.gather(*[_run_one(i) for i in range(50)])

        # Verify invariants across all 50 runs
        for rid in run_ids:
            snap = await app.state.run_manager.get_run_dict(rid)
            assert snap["status"] in ("succeeded", "cancelled", "failed")
            evs = await app.state.run_manager.list_events(rid)
            assert len(evs) >= 2
            assert [e.seq for e in evs] == list(range(1, len(evs) + 1))
            state = reduce_run_state(evs)
            assert state.finish_reason in ("completed", "cancelled", "error")

        assert fake.active_streams_count == 0


async def test_event_flood_5000_deltas_coalescing_and_health_p95(
    tmp_path: Path,
) -> None:
    """Adversarial: 5,000 deltas coalesced into <=8KB chunks; /api/health/live p95 <= 250ms."""
    settings = Settings(
        environment="test",
        data_dir=tmp_path / "data",
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{tmp_path / 'flood.db'}",
        delta_coalesce_interval_ms=60,
        sse_max_chunk_bytes=8192,
    )
    fake = FakeProvider(
        FakeScript(
            name="flood_5000",
            model="fake/default",
            steps=[
                *[FakeScriptStep(kind="text", text=f"d{i}|") for i in range(5000)],
                FakeScriptStep(kind="usage", input_tokens=50, output_tokens=5000),
            ],
        )
    )
    app = create_app(settings, start_job_workers=False, fake_provider=fake)

    async with app.router.lifespan_context(app):
        transport = httpx.ASGITransport(app=app, client=("127.0.0.1", 50100))
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client:
            from backend.core.uow import UnitOfWork

            async with app.state.db.session() as sess:
                uow = UnitOfWork(sess)
                admin = await uow.users.get_by_username("admin")
                assert admin is not None
                uid = admin.id

            chat = await app.state.chat_service.create_chat(user_id=uid, title="Flood Chat")
            res = await app.state.run_manager.post_user_message_and_start_run(
                chat_id=chat["id"], user_id=uid, content="Start 5000 delta flood"
            )
            run_id = res["run"]["id"]

            health_latencies_ms: list[float] = []
            probes = 0
            while True:
                t0 = time.perf_counter()
                r_h = await client.get("/api/health/live")
                health_latencies_ms.append((time.perf_counter() - t0) * 1000.0)
                assert r_h.status_code == 200
                probes += 1
                if probes % 5 == 0:
                    snap = await app.state.run_manager.get_run_dict(run_id)
                    if snap["status"] in ("succeeded", "failed", "cancelled"):
                        break
                await asyncio.sleep(0.005)

            evs = await app.state.run_manager.list_events(run_id)
            delta_evs = [e for e in evs if e.type == "message.text.delta"]
            # Coalescing must collapse 5,000 micro-deltas into far fewer DB events
            assert 1 <= len(delta_evs) <= 1000
            for de in delta_evs:
                assert len(de.data["text"].encode("utf-8")) <= 8192

            reconstructed = "".join(de.data["text"] for de in delta_evs)
            expected = "".join(f"d{i}|" for i in range(5000))
            assert reconstructed == expected

            sorted_lat = sorted(health_latencies_ms)
            p95_idx = min(len(sorted_lat) - 1, int(len(sorted_lat) * 0.95))
            p95_ms = sorted_lat[p95_idx]
            assert p95_ms <= 250.0


async def test_malicious_provider_payloads_and_infinite_stream(
    tmp_path: Path,
) -> None:
    """Adversarial: oversized SSE line, invalid UTF-8, dup JSON keys, NUL bytes, infinite stream."""

    # 1. Oversized SSE line (> max_sse_line_bytes) rejected cleanly without OOM
    async def _oversized_handler(_request: httpx.Request) -> httpx.Response:
        giant_line = "data: " + ("A" * (2 * 1024 * 1024)) + "\n\n"
        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            content=giant_line.encode("utf-8"),
        )

    adapter_oversized = OpenAICompatibleAdapter(
        base_url="http://malicious.local",
        max_frame_bytes=64 * 1024,
        transport=httpx.MockTransport(_oversized_handler),
    )
    req = ProviderChatRequest(
        model="local/test",
        messages=[ProviderMessage(role="user", content="hi")],
    )
    with pytest.raises(ClassifiedProviderError) as exc_info:
        async for _ in adapter_oversized.stream_chat(req):
            pass
    assert exc_info.value.category == "invalid_request"

    # 2a. Invalid UTF-8 bytes -> rejected with ClassifiedProviderError(invalid_request)
    async def _invalid_utf8_handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            content=b"data: \xff\xfe\xfd\n\n",
        )

    adapter_utf8 = OpenAICompatibleAdapter(
        base_url="http://malicious.local",
        transport=httpx.MockTransport(_invalid_utf8_handler),
    )
    with pytest.raises(ClassifiedProviderError) as utf8_exc:
        async for _ in adapter_utf8.stream_chat(req):
            pass
    assert utf8_exc.value.category == "invalid_request"

    # 2b. Duplicate JSON keys -> rejected with ClassifiedProviderError(invalid_request)
    async def _dup_keys_handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            content=b'data: {"choices":[{"delta":{"content":"a","content":"b"}}]}\n\n',
        )

    adapter_dup = OpenAICompatibleAdapter(
        base_url="http://malicious.local",
        transport=httpx.MockTransport(_dup_keys_handler),
    )
    with pytest.raises(ClassifiedProviderError) as dup_exc:
        async for _ in adapter_dup.stream_chat(req):
            pass
    assert dup_exc.value.category == "invalid_request"

    # 2c. Embedded \u0000 bytes in JSON frame -> rejected by strict_json_loads with invalid_request
    async def _nul_escaped_handler(_request: httpx.Request) -> httpx.Response:
        body = b'data: {"choices":[{"delta":{"content":"clean\\u0000text!"}}]}\n\ndata: [DONE]\n\n'
        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            content=body,
        )

    adapter_nul = OpenAICompatibleAdapter(
        base_url="http://malicious.local",
        transport=httpx.MockTransport(_nul_escaped_handler),
    )
    with pytest.raises(ClassifiedProviderError) as nul_exc:
        async for _ in adapter_nul.stream_chat(req):
            pass
    assert nul_exc.value.category == "invalid_request"

    # 3. Infinite stream terminated by max_tokens / max_seconds budget -> budget_exceeded
    settings = Settings(
        environment="test",
        data_dir=tmp_path / "data",
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{tmp_path / 'inf.db'}",
        delta_coalesce_interval_ms=0,
    )
    infinite_fake = FakeProvider(
        FakeScript(
            name="infinite_stream",
            model="fake/default",
            steps=[
                FakeScriptStep(kind="text", text="endless token stream ", delay_ms=2)
                for _ in range(500)
            ],
        )
    )
    app = create_app(settings, start_job_workers=False, fake_provider=infinite_fake)
    async with app.router.lifespan_context(app):
        from backend.core.uow import UnitOfWork

        async with app.state.db.session() as sess:
            uow = UnitOfWork(sess)
            admin = await uow.users.get_by_username("admin")
            assert admin is not None
            uid = admin.id

        chat = await app.state.chat_service.create_chat(user_id=uid, title="Infinite Stream")
        res = await app.state.run_manager.post_user_message_and_start_run(
            chat_id=chat["id"],
            user_id=uid,
            content="Trigger budget cap",
            budget={"max_tokens": 12, "max_seconds": 5.0, "max_cost": 1.0, "max_iterations": 2},
        )
        rid = res["run"]["id"]
        snap = await _wait_terminal(app, rid)
        assert snap["status"] == "succeeded"
        evs = await app.state.run_manager.list_events(rid)
        assert evs[-1].type == "run.finished"
        assert evs[-1].data["reason"] == "budget_exceeded"
        assert infinite_fake.active_streams_count == 0


async def test_clock_jump_plus_minus_1_hour_resilience(tmp_path: Path, monkeypatch: Any) -> None:
    """Adversarial: Jump wall-clock by +1h and -1h mid-run; monotonic timer & budgets unaffected."""
    settings = Settings(
        environment="test",
        data_dir=tmp_path / "data",
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{tmp_path / 'clock.db'}",
        delta_coalesce_interval_ms=0,
    )
    fake = FakeProvider(
        FakeScript(
            name="clock_jump",
            model="fake/default",
            steps=[
                FakeScriptStep(kind="text", text="Part 1 ", delay_ms=5),
                FakeScriptStep(kind="text", text="Part 2 ", delay_ms=5),
                FakeScriptStep(kind="usage", input_tokens=10, output_tokens=10),
            ],
        )
    )
    app = create_app(settings, start_job_workers=False, fake_provider=fake)

    async with app.router.lifespan_context(app):
        import backend.domain.runs.manager as mgr_mod
        from backend.core.uow import UnitOfWork

        async with app.state.db.session() as sess:
            uow = UnitOfWork(sess)
            admin = await uow.users.get_by_username("admin")
            assert admin is not None
            uid = admin.id

        chat = await app.state.chat_service.create_chat(user_id=uid, title="Clock Jump Chat")

        # Jump wall-clock +1 hour then -1 hour while monotonic clock advances normally
        real_datetime = datetime

        class _JumpedDatetime(datetime):
            offset_hours = 1

            @classmethod
            def now(cls, tz: Any = None) -> datetime:
                return real_datetime.now(tz or UTC) + timedelta(hours=cls.offset_hours)

        monkeypatch.setattr(mgr_mod, "datetime", _JumpedDatetime)

        res1 = await app.state.run_manager.post_user_message_and_start_run(
            chat_id=chat["id"],
            user_id=uid,
            content="Run under +1h wall-clock jump",
            budget={"max_seconds": 10.0, "max_tokens": 1000, "max_cost": 1.0, "max_iterations": 2},
        )
        snap1 = await _wait_terminal(app, res1["run"]["id"])
        assert snap1["status"] == "succeeded"

        _JumpedDatetime.offset_hours = -1
        res2 = await app.state.run_manager.post_user_message_and_start_run(
            chat_id=chat["id"],
            user_id=uid,
            content="Run under -1h wall-clock jump",
            budget={"max_seconds": 10.0, "max_tokens": 1000, "max_cost": 1.0, "max_iterations": 2},
        )
        snap2 = await _wait_terminal(app, res2["run"]["id"])
        assert snap2["status"] == "succeeded"

        for rid in (res1["run"]["id"], res2["run"]["id"]):
            evs = await app.state.run_manager.list_events(rid)
            step_fin = [e for e in evs if e.type == "step.finished"]
            assert len(step_fin) == 1
            assert step_fin[0].data["duration_ms"] >= 0
            assert evs[-1].data["reason"] == "completed"


async def test_load_200_concurrent_runs_metrics(tmp_path: Path) -> None:
    """Load test: 200 concurrent runs against FakeProvider; record p50/p95/p99 latency & RSS."""
    settings = Settings(
        environment="test",
        data_dir=tmp_path / "data",
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{tmp_path / 'load200.db'}",
        delta_coalesce_interval_ms=10,
        max_concurrent_runs_global=50,
        max_concurrent_runs_per_user=200,
    )
    fake = FakeProvider(
        FakeScript(
            name="load_fast",
            model="fake/default",
            steps=[
                FakeScriptStep(kind="text", text="Fast response delta."),
                FakeScriptStep(kind="usage", input_tokens=8, output_tokens=4),
            ],
        )
    )
    app = create_app(settings, start_job_workers=False, fake_provider=fake)
    rss_start_kb = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss

    async with app.router.lifespan_context(app):
        from backend.core.uow import UnitOfWork

        async with app.state.db.session() as sess:
            uow = UnitOfWork(sess)
            admin = await uow.users.get_by_username("admin")
            assert admin is not None
            uid = admin.id

        chat = await app.state.chat_service.create_chat(user_id=uid, title="Load 200")

        first_delta_latencies_ms: list[float] = []

        async def _launch_and_measure(idx: int) -> str:
            t0 = time.perf_counter()
            res = await app.state.run_manager.post_user_message_and_start_run(
                chat_id=chat["id"],
                user_id=uid,
                content=f"Load message {idx}",
            )
            rid = str(res["run"]["id"])
            await _wait_terminal(app, rid, max_wait=60.0)
            first_delta_latencies_ms.append((time.perf_counter() - t0) * 1000.0)
            return rid

        rids = await asyncio.gather(*[_launch_and_measure(i) for i in range(200)])
        assert len(rids) == 200

        sorted_lat = sorted(first_delta_latencies_ms)
        p50 = statistics.median(sorted_lat)
        p95 = sorted_lat[int(len(sorted_lat) * 0.95)]
        p99 = sorted_lat[int(len(sorted_lat) * 0.99)]
        rss_delta_mb = (resource.getrusage(resource.RUSAGE_SELF).ru_maxrss - rss_start_kb) / 1024.0

        assert p50 > 0
        assert p95 >= p50
        assert p99 >= p95
        assert rss_delta_mb < 128.0
