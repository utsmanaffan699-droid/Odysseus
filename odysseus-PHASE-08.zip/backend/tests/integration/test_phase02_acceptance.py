"""Phase 02 Acceptance Suite (Tests 1-10): replay, 1000-reconnects, cancel, SIGKILL, resilience."""

from __future__ import annotations

import asyncio
import json
import os
import resource
import secrets
import signal
import sys
import time
from pathlib import Path
from typing import Any

import httpx
from backend.app.main import create_app
from backend.core.settings import Settings
from backend.domain.events import RunEventEnvelope
from backend.domain.runs.reducer import reduce_run_state
from backend.providers.adapters import OpenAICompatibleAdapter
from backend.providers.capabilities import probe_openai_compatible_endpoint
from backend.providers.fake import (
    FakeProvider,
    FakeScript,
    FakeScriptStep,
    create_fake_openai_app,
)


def _parse_sse_envelopes(raw_sse: str) -> list[RunEventEnvelope]:
    envelopes: list[RunEventEnvelope] = []
    for block in raw_sse.split("\n\n"):
        lines = [ln.strip() for ln in block.splitlines() if ln.strip()]
        for ln in lines:
            if ln.startswith("data:"):
                payload = json.loads(ln[5:].strip())
                envelopes.append(RunEventEnvelope.model_validate(payload))
    return envelopes


async def _login_admin(client: httpx.AsyncClient, app: Any) -> str:
    admin_pw = app.state.bootstrap_admin_result.temporary_password
    r_login = await client.post(
        "/api/auth/login",
        json={"username": "admin", "password": admin_pw},
    )
    assert r_login.status_code == 200
    csrf = str(r_login.json()["csrf_token"])
    await client.post(
        "/api/auth/password/change",
        json={"current_password": admin_pw, "new_password": "StrongAdminPassword!2026"},
        headers={"X-CSRF-Token": csrf},
    )
    return csrf


async def _wait_run_done(app: Any, run_id: str, max_wait: float = 5.0) -> dict[str, Any]:
    r = await app.state.run_manager.wait_for_run(run_id, max_wait_seconds=max_wait)
    if r["status"] in ("succeeded", "failed", "cancelled", "interrupted"):
        return dict(r)
    raise AssertionError(f"Run {run_id} did not reach terminal state within {max_wait}s")


async def test_01_replay_equality_50_deltas(tmp_path: Path) -> None:
    """Acceptance #1: Stream a 50-delta run live via SSE; replay ?after=0; both reduce equal."""
    settings = Settings(
        environment="test",
        data_dir=tmp_path / "data",
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{tmp_path / 't1.db'}",
        delta_coalesce_interval_ms=0,
    )
    fake = FakeProvider(
        FakeScript(
            name="fifty_deltas",
            model="fake/default",
            steps=[
                *[FakeScriptStep(kind="text", text=f"token_{i} ", delay_ms=1) for i in range(50)],
                FakeScriptStep(kind="usage", input_tokens=20, output_tokens=50),
            ],
        )
    )
    app = create_app(settings, start_job_workers=False, fake_provider=fake)

    async with app.router.lifespan_context(app):
        transport = httpx.ASGITransport(app=app, client=("127.0.0.1", 50001))
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client:
            csrf = await _login_admin(client, app)
            r_chat = await client.post(
                "/api/chats", json={"title": "T1"}, headers={"X-CSRF-Token": csrf}
            )
            chat_id = r_chat.json()["id"]

            r_post = await client.post(
                f"/api/chats/{chat_id}/messages",
                json={"content": "Stream 50 deltas"},
                headers={"X-CSRF-Token": csrf},
            )
            assert r_post.status_code == 200
            run_id = r_post.json()["run"]["id"]

            # Live SSE stream
            live_resp = await client.get(f"/api/runs/{run_id}/events")
            assert live_resp.status_code == 200
            live_events = _parse_sse_envelopes(live_resp.text)
            await _wait_run_done(app, run_id)

            # Replay SSE stream from ?after=0
            replay_resp = await client.get(f"/api/runs/{run_id}/events?after=0")
            assert replay_resp.status_code == 200
            replay_events = _parse_sse_envelopes(replay_resp.text)

            text_deltas = [e for e in replay_events if e.type == "message.text.delta"]
            assert len(text_deltas) == 50

            live_state = reduce_run_state(live_events)
            replay_state = reduce_run_state(replay_events)
            assert live_state == replay_state
            assert replay_state.finish_reason == "completed"


async def test_02_mid_stream_reconnect_1000_random_points(tmp_path: Path) -> None:
    """Acceptance #2: Disconnect SSE at 1,000 random points and reconnect with Last-Event-ID."""
    settings = Settings(
        environment="test",
        data_dir=tmp_path / "data",
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{tmp_path / 't2.db'}",
        delta_coalesce_interval_ms=0,
        rate_limit_requests_per_minute=100000,
        rate_limit_burst=10000,
    )
    fake = FakeProvider(
        FakeScript(
            name="sixty_deltas",
            model="fake/default",
            steps=[
                *[FakeScriptStep(kind="text", text=f"chunk_{i} ") for i in range(60)],
                FakeScriptStep(kind="usage", input_tokens=30, output_tokens=60),
            ],
        )
    )
    app = create_app(settings, start_job_workers=False, fake_provider=fake)

    async with app.router.lifespan_context(app):
        transport = httpx.ASGITransport(app=app, client=("127.0.0.1", 50002))
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client:
            csrf = await _login_admin(client, app)
            r_chat = await client.post(
                "/api/chats", json={"title": "T2"}, headers={"X-CSRF-Token": csrf}
            )
            chat_id = r_chat.json()["id"]
            r_post = await client.post(
                f"/api/chats/{chat_id}/messages",
                json={"content": "60 chunks"},
                headers={"X-CSRF-Token": csrf},
            )
            run_id = r_post.json()["run"]["id"]
            await _wait_run_done(app, run_id)

            full_resp = await client.get(f"/api/runs/{run_id}/events?after=0")
            full_events = _parse_sse_envelopes(full_resp.text)
            total_seq = full_events[-1].seq
            assert total_seq >= 65
            expected_state = reduce_run_state(full_events)

            rng = secrets.SystemRandom()
            # Perform 1,000 random disconnect/reconnect stitches across the stream
            for i in range(1_000):
                cut_seq = rng.randint(1, total_seq - 1)
                prefix = [e for e in full_events if e.seq <= cut_seq]
                # Exercise HTTP Last-Event-ID on every 20th iteration and list_events on the rest
                if i % 20 == 0:
                    r_tail = await client.get(
                        f"/api/runs/{run_id}/events",
                        headers={"Last-Event-ID": str(cut_seq)},
                    )
                    assert r_tail.status_code == 200
                    suffix = _parse_sse_envelopes(r_tail.text)
                else:
                    suffix = await app.state.run_manager.list_events(run_id, after_seq=cut_seq)

                combined = prefix + suffix
                assert [e.seq for e in combined] == list(range(1, total_seq + 1))
                assert reduce_run_state(combined) == expected_state


async def test_03_multi_subscriber_5_clients(tmp_path: Path) -> None:
    """Acceptance #3: 5 SSE clients subscribed to one run all receive identical event sequences."""
    settings = Settings(
        environment="test",
        data_dir=tmp_path / "data",
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{tmp_path / 't3.db'}",
        delta_coalesce_interval_ms=0,
    )
    fake = FakeProvider(
        FakeScript(
            name="fanout",
            model="fake/default",
            steps=[
                *[
                    FakeScriptStep(kind="text", text=f"broadcast_{i} ", delay_ms=5)
                    for i in range(15)
                ],
                FakeScriptStep(kind="usage", input_tokens=10, output_tokens=15),
            ],
        )
    )
    app = create_app(settings, start_job_workers=False, fake_provider=fake)

    async with app.router.lifespan_context(app):
        transport = httpx.ASGITransport(app=app, client=("127.0.0.1", 50003))
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client:
            csrf = await _login_admin(client, app)
            r_chat = await client.post(
                "/api/chats", json={"title": "T3"}, headers={"X-CSRF-Token": csrf}
            )
            chat_id = r_chat.json()["id"]
            r_post = await client.post(
                f"/api/chats/{chat_id}/messages",
                json={"content": "Fan out to 5 subscribers"},
                headers={"X-CSRF-Token": csrf},
            )
            run_id = r_post.json()["run"]["id"]

            async def _sub() -> list[dict[str, Any]]:
                r = await client.get(f"/api/runs/{run_id}/events")
                assert r.status_code == 200
                return [e.model_dump(mode="json") for e in _parse_sse_envelopes(r.text)]

            streams = await asyncio.gather(*[_sub() for _ in range(5)])
            assert len(streams[0]) >= 18
            for s in streams[1:]:
                assert s == streams[0]


async def test_04_cancel_semantics_20_random_points(tmp_path: Path) -> None:
    """Acceptance #4: Cancel at 20 random points; <=500ms, aborted msg saved, stream closed."""
    settings = Settings(
        environment="test",
        data_dir=tmp_path / "data",
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{tmp_path / 't4.db'}",
        delta_coalesce_interval_ms=0,
        rate_limit_requests_per_minute=100000,
        rate_limit_burst=10000,
    )
    fake = FakeProvider(
        FakeScript(
            name="slow_stream",
            model="fake/default",
            steps=[
                *[FakeScriptStep(kind="text", text=f"piece_{i} ", delay_ms=15) for i in range(30)],
                FakeScriptStep(kind="usage", input_tokens=10, output_tokens=30),
            ],
        )
    )
    app = create_app(settings, start_job_workers=False, fake_provider=fake)
    rng = secrets.SystemRandom()

    async with app.router.lifespan_context(app):
        transport = httpx.ASGITransport(app=app, client=("127.0.0.1", 50004))
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client:
            csrf = await _login_admin(client, app)
            r_chat = await client.post(
                "/api/chats", json={"title": "T4"}, headers={"X-CSRF-Token": csrf}
            )
            chat_id = r_chat.json()["id"]

            for _ in range(20):
                r_post = await client.post(
                    f"/api/chats/{chat_id}/messages",
                    json={"content": "Cancel test"},
                    headers={"X-CSRF-Token": csrf},
                )
                run_id = r_post.json()["run"]["id"]
                asst_id = r_post.json()["assistant_message_id"]

                # Wait until provider stream is active, then sleep random offset inside stream
                for _ in range(200):
                    if fake.active_streams_count > 0:
                        break
                    await asyncio.sleep(0.002)
                await asyncio.sleep(rng.uniform(0.002, 0.045))
                t0 = time.monotonic()
                r_cancel = await client.post(
                    f"/api/runs/{run_id}/cancel",
                    headers={"X-CSRF-Token": csrf},
                )
                elapsed_ms = (time.monotonic() - t0) * 1000.0
                assert r_cancel.status_code == 200
                assert elapsed_ms <= 500.0

                run_snap = await _wait_run_done(app, run_id)
                assert run_snap["status"] == "cancelled"

                evs = await app.state.run_manager.list_events(run_id)
                assert evs[-1].type == "run.finished"
                assert evs[-1].data["reason"] == "cancelled"

                chat_detail = await app.state.chat_service.get_chat_detail(
                    chat_id=chat_id, user_id=run_snap["user_id"]
                )
                assert chat_detail is not None
                asst_nodes = [m for m in chat_detail["all_messages"] if m["id"] == asst_id]
                assert len(asst_nodes) == 1
                assert asst_nodes[0]["status"] == "aborted"

            assert fake.active_streams_count == 0
            assert fake.closed_streams_count >= 20


async def test_05_crash_recovery_sigkill_and_resume_zero_duplicates(tmp_path: Path) -> None:
    """Acceptance #5: SIGKILL mid-run -> boot marks interrupted -> resume with 0 duplicates."""
    db_file = tmp_path / "crash_recovery.db"
    data_dir = tmp_path / "data"
    logs_dir = tmp_path / "logs"
    marker_file = tmp_path / "run_id.txt"

    worker_code = f"""
import asyncio
from pathlib import Path
from backend.app.main import create_app
from backend.core.settings import Settings
from backend.providers.fake import FakeProvider, FakeScript, FakeScriptStep

async def main() -> None:
    settings = Settings(
        environment="test",
        data_dir=Path({str(data_dir)!r}),
        logs_dir=Path({str(logs_dir)!r}),
        database_url="sqlite+aiosqlite:///" + {str(db_file)!r},
        delta_coalesce_interval_ms=0,
    )
    fake = FakeProvider(
        FakeScript(
            name="crash_script",
            model="fake/default",
            steps=[
                FakeScriptStep(kind="text", text="Alpha segment before crash. "),
                FakeScriptStep(kind="text", text="Beta segment after resume!", delay_ms=10000),
                FakeScriptStep(kind="usage", input_tokens=15, output_tokens=10),
            ],
        )
    )
    app = create_app(settings, start_job_workers=False, fake_provider=fake)
    async with app.router.lifespan_context(app):
        from backend.core.uow import UnitOfWork
        async with app.state.db.session() as sess:
            uow = UnitOfWork(sess)
            admin = await uow.users.get_by_username("admin")
            uid = admin.id
        chat = await app.state.chat_service.create_chat(user_id=uid, title="Crash Chat")
        res = await app.state.run_manager.post_user_message_and_start_run(
            chat_id=chat["id"], user_id=uid, content="Start run"
        )
        rid = res["run"]["id"]
        # Wait until the first text delta is committed in run_events
        while True:
            evs = await app.state.run_manager.list_events(rid)
            if any(e.type == "message.text.delta" for e in evs):
                break
            await asyncio.sleep(0.01)
        Path({str(marker_file)!r}).write_text(rid + "\\n" + chat["id"], encoding="utf-8")
        await asyncio.sleep(30.0)

asyncio.run(main())
"""
    proc = await asyncio.create_subprocess_exec(
        sys.executable,
        "-c",
        worker_code,
        cwd="/home/user",
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    try:
        for _ in range(750):
            if marker_file.exists():
                break
            await asyncio.sleep(0.02)
        if not marker_file.exists():
            out, err = await proc.communicate()
            raise AssertionError(f"Worker failed to write marker: {out!r} {err!r}")

        assert proc.pid is not None
        os.kill(proc.pid, signal.SIGKILL)
        await proc.wait()
    finally:
        if proc.returncode is None:
            proc.kill()
            await proc.wait()

    lines = marker_file.read_text(encoding="utf-8").strip().splitlines()
    run_id, chat_id = lines[0], lines[1]

    # Restart app on the same DB with the full script (no 10s delay)
    settings = Settings(
        environment="test",
        data_dir=data_dir,
        logs_dir=logs_dir,
        database_url=f"sqlite+aiosqlite:///{db_file}",
        delta_coalesce_interval_ms=0,
    )
    fake = FakeProvider(
        FakeScript(
            name="crash_script",
            model="fake/default",
            steps=[
                FakeScriptStep(kind="text", text="Alpha segment before crash. "),
                FakeScriptStep(kind="text", text="Beta segment after resume!"),
                FakeScriptStep(kind="usage", input_tokens=15, output_tokens=10),
            ],
        )
    )
    app = create_app(settings, start_job_workers=False, fake_provider=fake)
    async with app.router.lifespan_context(app):
        # Verify boot marked the run interrupted
        snap = await app.state.run_manager.get_run_dict(run_id)
        assert snap["status"] == "interrupted"
        pre_events = await app.state.run_manager.list_events(run_id)
        assert any(
            e.type == "run.status" and e.data.get("status") == "interrupted" for e in pre_events
        )

        # Resume via RunManager (same handler as POST /api/runs/{id}/resume)
        await app.state.run_manager.resume_run(run_id, user_id=snap["user_id"])
        final_snap = await _wait_run_done(app, run_id)
        assert final_snap["status"] == "succeeded"

        all_events = await app.state.run_manager.list_events(run_id)
        reduced = reduce_run_state(all_events)
        assert reduced.finish_reason == "completed"
        combined_text = "".join(p.text for p in reduced.parts.values() if p.type == "text")
        assert combined_text == "Alpha segment before crash. Beta segment after resume!"
        assert chat_id == final_snap["chat_id"]


async def test_06_idempotency_10_parallel_posts(tmp_path: Path) -> None:
    """Acceptance #6: 10 parallel POSTs with same Idempotency-Key create 1 msg & 1 run."""
    settings = Settings(
        environment="test",
        data_dir=tmp_path / "data",
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{tmp_path / 't6.db'}",
    )
    app = create_app(settings, start_job_workers=False)

    async with app.router.lifespan_context(app):
        transport = httpx.ASGITransport(app=app, client=("127.0.0.1", 50006))
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client:
            csrf = await _login_admin(client, app)
            r_chat = await client.post(
                "/api/chats", json={"title": "T6"}, headers={"X-CSRF-Token": csrf}
            )
            chat_id = r_chat.json()["id"]

            async def _post_once() -> dict[str, Any]:
                r = await client.post(
                    f"/api/chats/{chat_id}/messages",
                    json={"content": "Idempotent hello"},
                    headers={
                        "X-CSRF-Token": csrf,
                        "Idempotency-Key": "idem-key-001",
                    },
                )
                assert r.status_code == 200
                return dict(r.json())

            responses = await asyncio.gather(*[_post_once() for _ in range(10)])
            first_run_id = responses[0]["run"]["id"]
            first_user_msg_id = responses[0]["user_message"]["id"]
            for resp in responses[1:]:
                assert resp["run"]["id"] == first_run_id
                assert resp["user_message"]["id"] == first_user_msg_id

            await _wait_run_done(app, first_run_id)
            detail = (await client.get(f"/api/chats/{chat_id}")).json()
            user_msgs = [m for m in detail["all_messages"] if m["role"] == "user"]
            assert len(user_msgs) == 1


async def test_07_message_branching_edit_regenerate_switch_and_endpoints(
    tmp_path: Path,
) -> None:
    """Acceptance #7: 3-turn chat -> edit turn 2 -> regenerate on branch -> switch leaf."""
    settings = Settings(
        environment="test",
        data_dir=tmp_path / "data",
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{tmp_path / 't7.db'}",
        delta_coalesce_interval_ms=0,
    )
    app = create_app(settings, start_job_workers=False)

    async with app.router.lifespan_context(app):
        transport = httpx.ASGITransport(app=app, client=("127.0.0.1", 50007))
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client:
            csrf = await _login_admin(client, app)

            # Create project and chat
            r_proj = await client.post(
                "/api/projects",
                json={
                    "name": "Odysseus Core",
                    "description": "Core project",
                    "instructions": "Respond with precision.",
                    "token_budget": 1024,
                },
                headers={"X-CSRF-Token": csrf},
            )
            assert r_proj.status_code == 200
            proj_id = r_proj.json()["id"]

            r_chat = await client.post(
                "/api/chats",
                json={"title": "Branch Chat", "project_id": proj_id},
                headers={"X-CSRF-Token": csrf},
            )
            chat_id = r_chat.json()["id"]

            # Turn 1, Turn 2, Turn 3
            turn_user_ids: list[str] = []
            turn_asst_ids: list[str] = []
            for idx in range(1, 4):
                r_m = await client.post(
                    f"/api/chats/{chat_id}/messages",
                    json={"content": f"User turn {idx}"},
                    headers={"X-CSRF-Token": csrf},
                )
                assert r_m.status_code == 200
                turn_user_ids.append(r_m.json()["user_message"]["id"])
                turn_asst_ids.append(r_m.json()["assistant_message_id"])
                await _wait_run_done(app, r_m.json()["run"]["id"])

            # Edit user turn 2 -> creates sibling branch (branch_index=1)
            m2_orig_id = turn_user_ids[1]
            r_edit = await client.post(
                f"/api/chats/{chat_id}/messages/{m2_orig_id}/edit",
                json={"content": "User turn 2 (edited branch)"},
                headers={"X-CSRF-Token": csrf},
            )
            assert r_edit.status_code == 200
            m2_branch_id = r_edit.json()["user_message"]["id"]
            asst_b1_first = r_edit.json()["assistant_message_id"]
            assert r_edit.json()["user_message"]["branch_index"] == 1
            await _wait_run_done(app, r_edit.json()["run"]["id"])

            # Regenerate assistant response on branch 1 -> creates second assistant sibling
            r_regen = await client.post(
                f"/api/chats/{chat_id}/messages/{asst_b1_first}/regenerate",
                json={},
                headers={"X-CSRF-Token": csrf},
            )
            assert r_regen.status_code == 200
            asst_b1_second = r_regen.json()["assistant_message_id"]
            await _wait_run_done(app, r_regen.json()["run"]["id"])
            assert asst_b1_second != asst_b1_first

            # Switch active_leaf_id back to original branch
            r_act0 = await client.post(
                f"/api/chats/{chat_id}/messages/{m2_orig_id}/activate",
                headers={"X-CSRF-Token": csrf},
            )
            assert r_act0.status_code == 200
            assert r_act0.json()["active_leaf_id"] == turn_asst_ids[2]
            assert len(r_act0.json()["messages"]) == 6

            # Switch active_leaf_id to edited branch
            r_act1 = await client.post(
                f"/api/chats/{chat_id}/messages/{m2_branch_id}/activate",
                headers={"X-CSRF-Token": csrf},
            )
            assert r_act1.status_code == 200
            assert r_act1.json()["active_leaf_id"] == asst_b1_second
            assert len(r_act1.json()["messages"]) == 4

            # Fork chat up to m2_branch_id
            r_fork = await client.post(
                f"/api/chats/{chat_id}/fork",
                json={"up_to_message_id": m2_branch_id, "title": "Forked Chat"},
                headers={"X-CSRF-Token": csrf},
            )
            assert r_fork.status_code == 200
            assert r_fork.json()["message_count"] == 3

            # FTS search
            r_search = await client.get("/api/chats/search?q=edited")
            assert r_search.status_code == 200
            assert any("<mark>edited</mark>" in h["snippet"] for h in r_search.json()["results"])

            # Usage rollups & token estimation & debug stream
            r_usage = await client.get("/api/usage")
            assert r_usage.status_code == 200
            assert r_usage.json()["totals"]["calls"] >= 5

            r_est = await client.post(
                "/api/tokens/estimate",
                json={"text": "Estimate this prompt", "model": "openai/gpt-4o"},
                headers={"X-CSRF-Token": csrf},
            )
            assert r_est.status_code == 200
            assert r_est.json()["text_tokens"] >= 3

            r_dbg = await client.get("/debug/stream")
            assert r_dbg.status_code == 200
            assert "Odysseus Run Event Protocol v1" in r_dbg.text


async def test_08_provider_resilience_429_retry_after_and_circuit_breaker_fallback(
    tmp_path: Path,
) -> None:
    """Acceptance #8: 429 Retry-After twice then succeed; 5 failures -> circuit open -> fallback."""
    settings = Settings(
        environment="test",
        data_dir=tmp_path / "data",
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{tmp_path / 't8.db'}",
        delta_coalesce_interval_ms=0,
        provider_max_retries=3,
        provider_circuit_breaker_threshold=3,
        provider_circuit_breaker_cooldown_seconds=60.0,
    )
    fake = FakeProvider()
    app = create_app(settings, start_job_workers=False, fake_provider=fake)
    # Speed up sleep_fn in test while verifying Retry-After is honored
    recorded_sleeps: list[float] = []

    async def _fast_sleep(sec: float) -> None:
        recorded_sleeps.append(sec)
        await asyncio.sleep(0.005)

    app.state.provider_router.sleep_fn = _fast_sleep

    async with app.router.lifespan_context(app):
        transport = httpx.ASGITransport(app=app, client=("127.0.0.1", 50008))
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client:
            csrf = await _login_admin(client, app)
            r_chat = await client.post(
                "/api/chats", json={"title": "T8"}, headers={"X-CSRF-Token": csrf}
            )
            chat_id = r_chat.json()["id"]

            # Part A: Enqueue two 429 (Retry-After: 2) scripts followed by success
            err_429 = FakeScript(
                name="rl_429",
                model="fake/default",
                steps=[
                    FakeScriptStep(
                        kind="http_error",
                        status_code=429,
                        error_message="Rate limit hit",
                        retry_after=2,
                    )
                ],
            )
            fake.enqueue_script(err_429)
            fake.enqueue_script(err_429)
            fake.enqueue_script(
                FakeScript(
                    name="ok_after_retry",
                    model="fake/default",
                    steps=[
                        FakeScriptStep(kind="text", text="Succeeded on attempt 3!"),
                        FakeScriptStep(kind="usage", input_tokens=10, output_tokens=6),
                    ],
                )
            )

            r_post = await client.post(
                f"/api/chats/{chat_id}/messages",
                json={"content": "Test 429 retry"},
                headers={"X-CSRF-Token": csrf},
            )
            run_id = r_post.json()["run"]["id"]
            snap = await _wait_run_done(app, run_id)
            assert snap["status"] == "succeeded"
            assert recorded_sleeps[:2] == [2.0, 2.0]

            evs = await app.state.run_manager.list_events(run_id)
            retry_notices = [
                e for e in evs if e.type == "notice" and e.data.get("code") == "provider_retry"
            ]
            assert len(retry_notices) == 2

            # Part B: Primary provider ("flaky/primary") fails -> circuit opens -> fallback
            flaky_fake = FakeProvider(
                FakeScript(
                    name="always_503",
                    model="flaky/primary",
                    steps=[
                        FakeScriptStep(
                            kind="http_error", status_code=503, error_message="Primary overloaded"
                        )
                    ],
                )
            )
            from backend.providers.adapters import FakeProviderAdapter

            app.state.provider_router.register_adapter(
                "flaky", FakeProviderAdapter(flaky_fake, provider_id="flaky")
            )
            app.state.provider_router.set_fallback_chain("flaky/primary", ["fake/default"])
            fake.script = FakeScript(
                name="fallback_ok",
                model="fake/default",
                steps=[
                    FakeScriptStep(kind="text", text="Served by fallback model!"),
                    FakeScriptStep(kind="usage", input_tokens=8, output_tokens=5),
                ],
            )

            r_fb = await client.post(
                f"/api/chats/{chat_id}/messages",
                json={"content": "Trigger circuit breaker and fallback", "model": "flaky/primary"},
                headers={"X-CSRF-Token": csrf},
            )
            fb_run_id = r_fb.json()["run"]["id"]
            fb_snap = await _wait_run_done(app, fb_run_id)
            assert fb_snap["status"] == "succeeded"
            assert app.state.provider_router.get_breaker("flaky").state == "open"

            fb_evs = await app.state.run_manager.list_events(fb_run_id)
            fb_notices = [
                e
                for e in fb_evs
                if e.type == "notice" and e.data.get("code") == "provider_fallback"
            ]
            assert len(fb_notices) >= 1


async def test_09_capability_probing_fake_variants(monkeypatch: Any) -> None:
    """Acceptance #9: Capability probe against FakeProvider (no_tools, tools_broken, vision)."""
    fake_app = create_fake_openai_app()
    provider: FakeProvider = fake_app.state.provider
    transport = httpx.ASGITransport(app=fake_app)

    orig_async_client = httpx.AsyncClient

    def _patched_client(*args: Any, **kwargs: Any) -> httpx.AsyncClient:
        kwargs["transport"] = transport
        return orig_async_client(*args, **kwargs)

    monkeypatch.setattr(httpx, "AsyncClient", _patched_client)

    provider.probe_variant = "no_tools"
    res_no_tools = await probe_openai_compatible_endpoint("http://fake.local")
    assert res_no_tools["reachable"] is True
    assert res_no_tools["tools"] == "none"
    assert res_no_tools["vision"] is False

    provider.probe_variant = "tools_broken"
    res_broken = await probe_openai_compatible_endpoint("http://fake.local")
    assert res_broken["reachable"] is True
    assert res_broken["tools"] == "text_fenced"
    assert res_broken["vision"] is False

    provider.probe_variant = "vision_capable"
    res_vision = await probe_openai_compatible_endpoint("http://fake.local")
    assert res_vision["reachable"] is True
    assert res_vision["tools"] == "native"
    assert res_vision["vision"] is True


async def test_10_slow_reader_backpressure_resync_and_bounded_rss(tmp_path: Path) -> None:
    """Acceptance #10: Slow SSE reader receives stream.resync; fast reader unaffected."""
    settings = Settings(
        environment="test",
        data_dir=tmp_path / "data",
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{tmp_path / 't10.db'}",
        delta_coalesce_interval_ms=0,
        sse_max_lag_events=10,
    )
    fake = FakeProvider(
        FakeScript(
            name="fast_80",
            model="fake/default",
            steps=[
                *[FakeScriptStep(kind="text", text=f"fast_{i} ") for i in range(80)],
                FakeScriptStep(kind="usage", input_tokens=20, output_tokens=80),
            ],
        )
    )
    app = create_app(settings, start_job_workers=False, fake_provider=fake)
    rss_before_kb = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss

    async with app.router.lifespan_context(app):
        from backend.core.uow import UnitOfWork

        async with app.state.db.session() as sess:
            uow = UnitOfWork(sess)
            admin = await uow.users.get_by_username("admin")
            assert admin is not None
            uid = admin.id

        chat = await app.state.chat_service.create_chat(user_id=uid, title="T10")

        # Start run and attach a slow subscriber + fast subscriber directly to stream_sse
        res = await app.state.run_manager.post_user_message_and_start_run(
            chat_id=chat["id"], user_id=uid, content="Fast 80"
        )
        run_id = res["run"]["id"]

        slow_frames: list[RunEventEnvelope] = []
        fast_frames: list[RunEventEnvelope] = []

        async def _slow_reader() -> None:
            app.state.run_manager.acquire_sse_slot(uid)
            async for frame in app.state.run_manager.stream_sse(
                run_id=run_id, user_id=uid, after_seq=0
            ):
                slow_frames.extend(_parse_sse_envelopes(frame))
                await asyncio.sleep(0.02)

        async def _fast_reader() -> None:
            app.state.run_manager.acquire_sse_slot(uid)
            async for frame in app.state.run_manager.stream_sse(
                run_id=run_id, user_id=uid, after_seq=0
            ):
                fast_frames.extend(_parse_sse_envelopes(frame))

        await asyncio.gather(_slow_reader(), _fast_reader())

        # Verify reconnecting with after_seq=0 when > sse_max_lag_events behind emits stream.resync
        app.state.run_manager.acquire_sse_slot(uid)
        reconnect_frames: list[RunEventEnvelope] = []
        async for frame in app.state.run_manager.stream_sse(
            run_id=run_id, user_id=uid, after_seq=0
        ):
            reconnect_frames.extend(_parse_sse_envelopes(frame))

        assert any(e.type == "stream.resync" for e in (slow_frames + reconnect_frames))
        assert any(e.type == "run.finished" for e in fast_frames)

    rss_after_kb = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    assert (rss_after_kb - rss_before_kb) < 64 * 1024
    _ = OpenAICompatibleAdapter
