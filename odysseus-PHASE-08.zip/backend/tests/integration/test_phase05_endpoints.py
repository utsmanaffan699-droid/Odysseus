"""Phase 05 Backend Integration Tests: agent scenarios, artifacts, presets, policies, and traces."""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any

import httpx
from backend.app.main import create_app
from backend.core.settings import Settings


async def _login_admin(client: httpx.AsyncClient, app: Any) -> str:
    admin_pw = app.state.bootstrap_admin_result.temporary_password
    r_login = await client.post(
        "/api/auth/login",
        json={"username": "admin", "password": admin_pw},
    )
    assert r_login.status_code == 200
    csrf = str(r_login.json()["csrf_token"])
    await client.post(
        "/api/auth/password/change",
        json={"current_password": admin_pw, "new_password": "StrongAdminPassword!2026"},
        headers={"X-CSRF-Token": csrf},
    )
    return csrf


async def test_phase05_agent_scenarios_and_approval_race(tmp_path: Path) -> None:
    """Verify Phase 05 agent scenarios, approval race, and trace export."""
    settings = Settings(
        environment="test",
        data_dir=tmp_path / "data",
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{tmp_path / 'p05.db'}",
        delta_coalesce_interval_ms=0,
    )
    app = create_app(settings, start_job_workers=False)
    async with app.router.lifespan_context(app):
        transport = httpx.ASGITransport(app=app, client=("127.0.0.1", 50201))
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client:
            csrf = await _login_admin(client, app)
            headers = {"X-CSRF-Token": csrf}

            r_chat = await client.post("/api/chats", json={"title": "P05 Chat"}, headers=headers)
            assert r_chat.status_code == 200
            chat_id = r_chat.json()["id"]

            # 1. [FAKE_AGENT_6TOOLS]
            r_msg1 = await client.post(
                f"/api/chats/{chat_id}/messages",
                json={"content": "Run [FAKE_AGENT_6TOOLS]"},
                headers=headers,
            )
            assert r_msg1.status_code == 200
            run1_id = r_msg1.json()["run"]["id"]

            # Wait briefly for approval.requested to be emitted
            apr_id = f"app_1_{run1_id[-6:]}"
            for _ in range(50):
                if apr_id in app.state.run_manager._approval_events:
                    break
                await asyncio.sleep(0.02)

            r_res1 = await client.post(
                f"/api/runs/{run1_id}/approvals/{apr_id}",
                json={"decision": "approve", "scope": "once"},
                headers=headers,
            )
            assert r_res1.status_code == 200
            assert r_res1.json()["already_decided"] is False

            # Second resolution on same approval returns already_decided=True
            r_res1_dup = await client.post(
                f"/api/approvals/{apr_id}/resolve",
                json={"decision": "deny", "scope": "once", "reason": "late"},
                headers=headers,
            )
            assert r_res1_dup.status_code == 200
            assert r_res1_dup.json()["already_decided"] is True

            # 2. [FAKE_DECEPTIVE_APPROVAL]
            await asyncio.sleep(0.25)
            r_msg2 = await client.post(
                f"/api/chats/{chat_id}/messages",
                json={"content": "Check [FAKE_DECEPTIVE_APPROVAL]", "parent_id": "__active_leaf__"},
                headers=headers,
            )
            assert r_msg2.status_code == 200
            run2_id = r_msg2.json()["run"]["id"]
            dec_apr_id = f"apr_dec_{run2_id[-10:]}"
            for _ in range(50):
                if dec_apr_id in app.state.run_manager._approval_events:
                    break
                await asyncio.sleep(0.02)

            r_dec = await client.post(
                f"/api/approvals/{dec_apr_id}/resolve",
                json={"decision": "deny", "scope": "once", "reason": "Spoofed"},
                headers=headers,
            )
            assert r_dec.status_code == 200

            # 3. [FAKE_INJECTION_TOOL] & [FAKE_ARTIFACT_STREAM]
            await asyncio.sleep(0.15)
            r_msg3 = await client.post(
                f"/api/chats/{chat_id}/messages",
                json={"content": "Test [FAKE_INJECTION_TOOL]", "parent_id": "__active_leaf__"},
                headers=headers,
            )
            assert r_msg3.status_code == 200
            await asyncio.sleep(0.15)

            r_msg4 = await client.post(
                f"/api/chats/{chat_id}/messages",
                json={"content": "Stream [FAKE_ARTIFACT_STREAM]", "parent_id": "__active_leaf__"},
                headers=headers,
            )
            assert r_msg4.status_code == 200

            # Wait for background tasks to finish
            await asyncio.sleep(0.25)

            # 4. Run trace export, extend-budget, rerun-from-step, list, bulk-delete
            r_trace = await client.get(f"/api/runs/{run1_id}/trace")
            assert r_trace.status_code == 200
            trace_json = r_trace.json()
            assert trace_json["run"]["id"] == run1_id
            assert len(trace_json["events"]) >= 1

            r_ext = await client.post(
                f"/api/runs/{run1_id}/extend-budget",
                json={"add_iters": 5, "add_tokens": 10000, "add_cost": 0.5, "add_seconds": 60},
                headers=headers,
            )
            assert r_ext.status_code == 200

            r_rerun = await client.post(
                f"/api/runs/{run1_id}/rerun-from-step",
                json={"step_id": "s_1"},
                headers=headers,
            )
            assert r_rerun.status_code == 200
            await asyncio.sleep(0.1)

            r_runs = await client.get("/api/runs")
            assert r_runs.status_code == 200
            assert len(r_runs.json()["runs"]) >= 1

            r_bdel = await client.post(
                "/api/runs/bulk-delete",
                json={"run_ids": [run2_id]},
                headers=headers,
            )
            assert r_bdel.status_code == 200
            assert r_bdel.json()["count"] >= 1


async def test_phase05_tool_output_slice_artifacts_presets_and_policies(tmp_path: Path) -> None:
    """Verify tool output slicing, Artifacts CRUD/suggest/exec, Presets, and Exec Policies."""
    settings = Settings(
        environment="test",
        data_dir=tmp_path / "data",
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{tmp_path / 'p05_2.db'}",
        delta_coalesce_interval_ms=0,
    )
    app = create_app(settings, start_job_workers=False)
    async with app.router.lifespan_context(app):
        transport = httpx.ASGITransport(app=app, client=("127.0.0.1", 50202))
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client:
            csrf = await _login_admin(client, app)
            headers = {"X-CSRF-Token": csrf}

            # 1. Tool-call output store & range slice
            r_seed = await client.post(
                "/api/tool-calls/tc_slice_1/output",
                json={"text": "0123456789" * 100},
                headers=headers,
            )
            assert r_seed.status_code == 200
            r_slice = await client.get("/api/tool-calls/tc_slice_1/output?range=10-50")
            assert r_slice.status_code == 200
            assert r_slice.json()["length"] == 40
            assert r_slice.json()["has_more"] is True

            # 2. Agent Presets CRUD (/api/agent-presets)
            r_plist = await client.get("/api/agent-presets")
            assert r_plist.status_code == 200
            assert len(r_plist.json()["presets"]) >= 2

            r_psave = await client.post(
                "/api/agent-presets",
                json={
                    "name": "Custom Auditor",
                    "description": "Audits code",
                    "mode": "agent",
                    "system_prompt": "Check everything.",
                    "model": "fake/default",
                },
                headers=headers,
            )
            assert r_psave.status_code == 200
            saved_id = r_psave.json()["preset"]["id"]

            r_pdel = await client.delete(f"/api/agent-presets/{saved_id}", headers=headers)
            assert r_pdel.status_code == 200

            # 3. Exec Policy Rules CRUD + Pattern Tester (/api/exec-policies)
            r_pol_list = await client.get("/api/exec-policies")
            assert r_pol_list.status_code == 200

            r_pol_bad = await client.post(
                "/api/exec-policies",
                json={"tool_name": "run_shell", "pattern": "*"},
                headers=headers,
            )
            assert r_pol_bad.status_code == 400

            r_pol_ok = await client.post(
                "/api/exec-policies",
                json={"tool_name": "shell", "pattern": 'argv_prefix:["pytest", "-q"]'},
                headers=headers,
            )
            assert r_pol_ok.status_code == 200
            rule_id = r_pol_ok.json()["id"]

            r_pol_test = await client.post(
                "/api/exec-policies/test",
                json={
                    "tool_name": "shell",
                    "pattern": 'argv_prefix:["pytest", "-q"]',
                    "sample_args": {"command": "pytest -q tests/unit"},
                },
                headers=headers,
            )
            assert r_pol_test.status_code == 200
            assert r_pol_test.json()["valid"] is True
            assert r_pol_test.json()["matches"] is True

            r_pol_del = await client.delete(f"/api/exec-policies/{rule_id}", headers=headers)
            assert r_pol_del.status_code == 200

            # 4. Artifacts CRUD, version append, restore, suggest, and execute
            r_art_create = await client.post(
                "/api/artifacts",
                json={
                    "title": "calc.py",
                    "type": "code",
                    "content": "def add(a, b):\n    return a + b\n",
                    "summary": "Initial version",
                },
                headers=headers,
            )
            assert r_art_create.status_code == 200
            art_id = r_art_create.json()["id"]

            r_art_list = await client.get("/api/artifacts")
            assert r_art_list.status_code == 200
            assert any(a["id"] == art_id for a in r_art_list.json()["artifacts"])

            r_art_get = await client.get(f"/api/artifacts/{art_id}")
            assert r_art_get.status_code == 200

            r_art_ver = await client.post(
                f"/api/artifacts/{art_id}/versions",
                json={
                    "content": "def add(a: int, b: int) -> int:\n    return a + b\n",
                    "summary": "Added type annotations",
                    "author": "user",
                },
                headers=headers,
            )
            assert r_art_ver.status_code == 200
            assert r_art_ver.json()["latest_version"] == 2

            r_art_rest = await client.post(
                f"/api/artifacts/{art_id}/restore",
                json={"version": 1},
                headers=headers,
            )
            assert r_art_rest.status_code == 200
            assert r_art_rest.json()["latest_version"] == 3

            for act in ("improve", "shorten", "expand", "explain", "fix"):
                r_art_sug = await client.post(
                    f"/api/artifacts/{art_id}/suggest",
                    json={"action": act, "content": "var x == True\nreturn x\n"},
                    headers=headers,
                )
                assert r_art_sug.status_code == 200
                assert len(r_art_sug.json()["hunks"]) >= 1

            r_art_exec = await client.post(
                f"/api/artifacts/{art_id}/execute",
                json={"language": "python", "code": "print(2 + 2)"},
                headers=headers,
            )
            assert r_art_exec.status_code == 200
            assert "print(2 + 2)" in r_art_exec.json()["stdout"]
            assert r_art_exec.json()["exit_code"] == 0
