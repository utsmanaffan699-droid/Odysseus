"""Deliverable #3: Route-policy test proving every registered route has an explicit auth policy."""

from __future__ import annotations

from backend.app.main import create_app
from backend.core.security import ROUTE_POLICIES, iter_api_routes
from backend.core.settings import Settings


def test_every_route_has_explicit_policy() -> None:
    """Walk the FastAPI router and fail if any route lacks an explicit entry in ROUTE_POLICIES."""
    app = create_app(Settings(), start_job_workers=False)

    unprotected: list[str] = []
    verified_count = 0

    for route in iter_api_routes(app):
        methods = {
            m.upper() for m in (route.methods or set()) if m.upper() not in ("HEAD", "OPTIONS")
        }
        for method in sorted(methods):
            key = (method, route.path)
            policy = ROUTE_POLICIES.get(key)
            if policy is None:
                unprotected.append(f"{method} {route.path}")
            else:
                verified_count += 1

    assert not unprotected, (
        f"Routes registered without an explicit entry in ROUTE_POLICIES: {unprotected}"
    )
    assert verified_count >= 20
