"""Deliverable #2: Alembic migration upgrade/downgrade test on both SQLite and PostgreSQL 17."""

from __future__ import annotations

import os
from pathlib import Path

import pytest
from backend.core.migrations import (
    downgrade_db_async,
    get_current_revision_async,
    get_head_revision,
    upgrade_db_async,
)
from sqlalchemy import inspect, text
from sqlalchemy.ext.asyncio import create_async_engine

EXPECTED_TABLES = {
    "users",
    "privileges",
    "sessions",
    "api_tokens",
    "audit_log",
    "runtime_settings",
    "encrypted_secrets",
    "jobs",
    "chats",
    "messages",
    "runs",
    "run_events",
}

EXPECTED_PHASE02_TABLES = {
    "projects",
    "attachments",
    "upload_sessions",
    "idempotency_keys",
    "usage_ledger",
    "provider_configs",
    "raw_exchanges",
}

EXPECTED_PHASE03_TABLES = {
    "tool_calls",
    "approvals",
    "approval_rules",
    "artifacts",
    "artifact_versions",
    "memories",
    "skills",
    "skill_versions",
    "mcp_servers",
}


async def _verify_up_down_cycle(database_url: str) -> None:
    engine = create_async_engine(database_url)
    try:
        head_rev = get_head_revision(database_url)
        assert head_rev == "0003_phase03_agent_engine"

        # 1. Upgrade from empty to head (0003)
        await upgrade_db_async(engine, "head")
        current = await get_current_revision_async(engine)
        assert current == head_rev

        async with engine.connect() as conn:
            tables = await conn.run_sync(
                lambda sync_conn: set(inspect(sync_conn).get_table_names())
            )
        assert EXPECTED_TABLES.issubset(tables)
        assert EXPECTED_PHASE02_TABLES.issubset(tables)
        assert EXPECTED_PHASE03_TABLES.issubset(tables)

        # 2. Downgrade one step (-1 -> 0002_phase02_llm_run_engine)
        await downgrade_db_async(engine, "-1")
        current_after_step_down = await get_current_revision_async(engine)
        assert current_after_step_down == "0002_phase02_llm_run_engine"

        async with engine.connect() as conn:
            p2_tables = await conn.run_sync(
                lambda sync_conn: set(inspect(sync_conn).get_table_names())
            )
        assert EXPECTED_TABLES.issubset(p2_tables)
        assert EXPECTED_PHASE02_TABLES.issubset(p2_tables)
        assert EXPECTED_PHASE03_TABLES.isdisjoint(p2_tables)

        # 3. Downgrade another step (-1 -> 0001_initial_foundation)
        await downgrade_db_async(engine, "-1")
        current_after_second_down = await get_current_revision_async(engine)
        assert current_after_second_down == "0001_initial_foundation"

        async with engine.connect() as conn:
            mid_tables = await conn.run_sync(
                lambda sync_conn: set(inspect(sync_conn).get_table_names())
            )
        assert EXPECTED_TABLES.issubset(mid_tables)
        assert EXPECTED_PHASE02_TABLES.isdisjoint(mid_tables)
        assert EXPECTED_PHASE03_TABLES.isdisjoint(mid_tables)

        # 4. Downgrade to base
        await downgrade_db_async(engine, "base")
        current_after_down = await get_current_revision_async(engine)
        assert current_after_down is None

        async with engine.connect() as conn:
            remaining = await conn.run_sync(
                lambda sync_conn: set(inspect(sync_conn).get_table_names())
            )
        assert EXPECTED_TABLES.isdisjoint(remaining)

        # 5. Upgrade back to head
        await upgrade_db_async(engine, "head")
        assert await get_current_revision_async(engine) == head_rev
    finally:
        await engine.dispose()


async def test_alembic_migrations_up_down_sqlite(tmp_path: Path) -> None:
    """Test full upgrade -> downgrade -1 -> upgrade cycle on SQLite."""
    db_url = f"sqlite+aiosqlite:///{tmp_path / 'mig_sqlite.db'}"
    await _verify_up_down_cycle(db_url)


async def test_alembic_migrations_up_down_postgres() -> None:
    """Test full upgrade -> downgrade -1 -> upgrade cycle on PostgreSQL 17."""
    pg_url = os.environ.get(
        "ODYSSEUS_TEST_POSTGRES_URL",
        "postgresql+asyncpg://odysseus:odysseus@127.0.0.1:5432/odysseus_test",
    )
    engine = create_async_engine(pg_url)
    try:
        async with engine.begin() as conn:
            await conn.execute(text("DROP SCHEMA public CASCADE"))
            await conn.execute(text("CREATE SCHEMA public"))
    except Exception as exc:
        await engine.dispose()
        pytest.fail(f"PostgreSQL test database unavailable at {pg_url}: {exc}")
    await engine.dispose()

    await _verify_up_down_cycle(pg_url)
