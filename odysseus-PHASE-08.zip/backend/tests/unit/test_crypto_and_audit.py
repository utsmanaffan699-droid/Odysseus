"""Unit tests for EnvelopeVault (encryption at rest) and tamper-evident AuditLog hash chain."""

from __future__ import annotations

import stat
from pathlib import Path

import pytest
from backend.core.audit import (
    AuditChainTamperedError,
    append_audit_event,
    verify_audit_chain,
)
from backend.core.audit import (
    main as audit_cli_main,
)
from backend.core.crypto import EnvelopeVault
from backend.core.db import DatabaseManager
from backend.core.settings import Settings
from sqlalchemy import text


def test_envelope_vault_encryption_permissions_and_rotation(tmp_path: Path) -> None:
    """Verify AES-256-GCM envelope encryption, 0600 key permissions, KMS hooks, and key rotation."""
    vault = EnvelopeVault(tmp_path)
    key_file = tmp_path / "master.key"
    assert key_file.exists()
    mode = stat.S_IMODE(key_file.stat().st_mode)
    assert mode == 0o600

    token = vault.encrypt("super-secret-provider-key-2026", associated_data="provider:openai")
    assert "super-secret" not in token
    decrypted = vault.decrypt(token, associated_data="provider:openai")
    assert decrypted == "super-secret-provider-key-2026"

    # Wrong associated data must fail authentication tag verification
    with pytest.raises((ValueError, Exception), match=r".*"):
        vault.decrypt(token, associated_data="provider:wrong")

    # Rotate master key: old token still decrypts via keyring and can be re-wrapped
    vault.rotate_master_key()
    assert (
        vault.decrypt(token, associated_data="provider:openai") == "super-secret-provider-key-2026"
    )
    rewrapped = vault.rewrap_token(token, associated_data="provider:openai")
    assert rewrapped != token
    assert (
        vault.decrypt(rewrapped, associated_data="provider:openai")
        == "super-secret-provider-key-2026"
    )

    # Test external KMS wrap/unwrap hooks
    kms_vault = EnvelopeVault(
        tmp_path / "kms",
        kms_wrap_hook=lambda dek: bytes(b ^ 0x5A for b in dek),
        kms_unwrap_hook=lambda wdek: bytes(b ^ 0x5A for b in wdek),
    )
    kms_tok = kms_vault.encrypt("kms-protected-secret")
    assert kms_vault.decrypt(kms_tok) == "kms-protected-secret"


async def test_audit_log_hash_chain_detects_tampering_and_cli(tmp_path: Path) -> None:
    """Acceptance Test #8: Audit log chain verification command detects a manually altered row."""
    db_path = tmp_path / "audit_test.db"
    db_url = f"sqlite+aiosqlite:///{db_path}"
    settings = Settings(database_url=db_url, data_dir=tmp_path)
    db = DatabaseManager(settings)
    await db.create_schema_if_needed()

    try:

        async def _seed(sess: object) -> None:
            from sqlalchemy.ext.asyncio import AsyncSession

            assert isinstance(sess, AsyncSession)
            await append_audit_event(
                sess,
                action="auth.login",
                resource_type="user",
                actor_user_id="u_1",
                details={"ip": "127.0.0.1"},
            )
            await append_audit_event(
                sess,
                action="admin.privileges_updated",
                resource_type="user",
                actor_user_id="u_1",
                resource_id="u_2",
                details={"privileges": ["chat", "admin"]},
            )
            await append_audit_event(
                sess,
                action="auth.logout",
                resource_type="session",
                actor_user_id="u_1",
            )

        await db.execute_write(_seed)

        async with db.session() as sess:
            ok, count = await verify_audit_chain(sess)
            assert ok is True
            assert count == 3

        # CLI verification passes on untampered DB
        exit_code_ok = await _run_cli_in_thread(db_url)
        assert exit_code_ok == 0

        # Manually alter row #2 out-of-band via SQL
        async def _tamper(sess: object) -> None:
            from sqlalchemy.ext.asyncio import AsyncSession

            assert isinstance(sess, AsyncSession)
            await sess.execute(text("UPDATE audit_log SET action = 'benign.action' WHERE id = 2"))

        await db.execute_write(_tamper)

        async with db.session() as sess:
            with pytest.raises(AuditChainTamperedError) as exc_info:
                await verify_audit_chain(sess)
            assert exc_info.value.record_id == 2
            assert "hash mismatch" in exc_info.value.reason.lower()

        # CLI verification returns non-zero (2) when tampered
        exit_code_tampered = await _run_cli_in_thread(db_url)
        assert exit_code_tampered == 2
    finally:
        await db.dispose()


async def _run_cli_in_thread(db_url: str) -> int:
    import asyncio

    return await asyncio.to_thread(audit_cli_main, ["verify", "--database-url", db_url])
