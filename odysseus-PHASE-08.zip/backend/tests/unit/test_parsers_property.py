"""Property-based tests (Hypothesis) for server-side parsers."""

from __future__ import annotations

import json
from datetime import UTC, datetime

import pytest
from backend.core.parsers import (
    parse_tool_call_arguments,
    split_markdown_fences,
    validate_and_preview_cron,
    validate_and_preview_rrule,
)
from hypothesis import given
from hypothesis import settings as hyp_settings
from hypothesis import strategies as st


@given(st.text(max_size=500))
@hyp_settings(max_examples=75, deadline=None)
def test_property_tool_call_parser_never_raises_on_arbitrary_strings(raw: str) -> None:
    """Property: parse_tool_call_arguments never raises an unhandled exception on any string."""
    res = parse_tool_call_arguments(raw)
    assert isinstance(res.args, dict)
    assert res.raw == raw


@given(
    st.dictionaries(
        keys=st.text(min_size=1, max_size=20),
        values=st.one_of(st.integers(), st.text(max_size=50), st.booleans(), st.none()),
        max_size=10,
    )
)
@hyp_settings(max_examples=50, deadline=None)
def test_property_tool_call_parser_roundtrips_json_objects(obj: dict[str, object]) -> None:
    """Property: any valid JSON object string parses with ok=True and identical dictionary."""
    encoded = json.dumps(obj)
    res = parse_tool_call_arguments(encoded)
    assert res.ok is True
    assert res.args == obj
    assert res.error is None


@given(st.text(max_size=1000))
@hyp_settings(max_examples=75, deadline=None)
def test_property_markdown_fence_splitter_is_lossless(md: str) -> None:
    """Property: concatenating raw segments from split_markdown_fences equals original input."""
    segments = split_markdown_fences(md)
    reconstructed = "".join(seg.raw for seg in segments)
    assert reconstructed == md


def test_markdown_fence_unclosed_and_nested_fences() -> None:
    """Verify unclosed trailing fences and 4-backtick outer fences containing 3-backtick fences."""
    unclosed = "Intro paragraph\n```python\ndef f():\n    return 42\n"
    segs = split_markdown_fences(unclosed)
    assert len(segs) == 2
    assert segs[0].kind == "prose"
    assert segs[0].closed is True
    assert segs[1].kind == "code"
    assert segs[1].language == "python"
    assert segs[1].closed is False
    assert "".join(s.raw for s in segs) == unclosed

    nested = "````markdown\nHere is code:\n```ts\nconst x = 1;\n```\n````\nDone.\n"
    nested_segs = split_markdown_fences(nested)
    assert len(nested_segs) == 2
    assert nested_segs[0].kind == "code"
    assert nested_segs[0].closed is True
    assert nested_segs[1].kind == "prose"


@given(
    minute=st.integers(min_value=0, max_value=59),
    hour=st.integers(min_value=0, max_value=23),
)
@hyp_settings(max_examples=30, deadline=None)
def test_property_cron_preview_strictly_increasing(minute: int, hour: int) -> None:
    """Property: cron preview timestamps are strictly increasing and in UTC."""
    expr = f"{minute} {hour} * * *"
    base = datetime(2026, 10, 3, 0, 0, tzinfo=UTC)
    runs = validate_and_preview_cron(expr, base_time=base, count=5)
    assert len(runs) == 5
    for i in range(1, len(runs)):
        assert runs[i] > runs[i - 1]
        assert runs[i].minute == minute
        assert runs[i].hour == hour


def test_cron_and_rrule_validation_errors() -> None:
    with pytest.raises(ValueError, match="exactly 5 fields"):
        validate_and_preview_cron("* * *")
    with pytest.raises(ValueError, match="Invalid cron"):
        validate_and_preview_cron("99 99 * * *")

    rrule_dates = validate_and_preview_rrule(
        "FREQ=DAILY;COUNT=4",
        dtstart=datetime(2026, 10, 3, 9, 0, tzinfo=UTC),
        count=4,
    )
    assert len(rrule_dates) == 4
    with pytest.raises(ValueError, match="cannot be empty"):
        validate_and_preview_rrule("   ")
