"""Unit & Fuzz tests for the Text-Fenced Tool-Call Parser (10k Hypothesis + 30 torture)
and the 60-vector Workspace Filesystem Jail.
"""

from __future__ import annotations

import os
import time
from pathlib import Path

import pytest
from backend.domain.agents.fenced_parser import (
    IncrementalFencedToolParser,
    build_tool_call_repair_prompt,
    format_fenced_tool_instructions,
    parse_fenced_tool_calls,
)
from backend.domain.tools.filesystem import (
    WorkspaceEscapeError,
    resolve_workspace_path,
    workspace_edit_file,
    workspace_glob,
    workspace_grep,
    workspace_list_dir,
    workspace_read_file,
    workspace_write_file,
)
from hypothesis import HealthCheck, given, settings
from hypothesis import strategies as st

# ---------------------------------------------------------------------------
# 1. Hypothesis 10,000-example property-based fuzz test (Phase 03 §1.2 & §7)
# ---------------------------------------------------------------------------

_FENCE_FRAGMENT_STRATEGY = st.one_of(
    st.text(max_size=120),
    st.just("```tool_call\n"),
    st.just("~~~tool_call\n"),
    st.just("\n```\n"),
    st.just("<tool_call>"),
    st.just("</tool_call>"),
    st.just('{"name": "read_file", "args": {"path": "README.md"}}'),
    st.just("{'name': 'list_dir', 'args': {'path': '.'},}"),
    st.just('{"name": "write_file", "name": "shell", "args": {}}'),
)


@settings(
    max_examples=10000,
    deadline=None,
    suppress_health_check=[HealthCheck.too_slow],
)
@given(
    fragments=st.lists(_FENCE_FRAGMENT_STRATEGY, min_size=1, max_size=6),
)
def test_fenced_tool_parser_hypothesis_10000_examples_never_raises(
    fragments: list[str],
) -> None:
    """Property test: across 10,000 fuzzed inputs, parse_fenced_tool_calls never raises."""
    payload = "".join(fragments)
    res = parse_fenced_tool_calls(payload)
    assert isinstance(res.prose_text, str)
    assert isinstance(res.calls, list)
    assert isinstance(res.errors, list)


# ---------------------------------------------------------------------------
# 2. 30-case Fenced Tool-Call Parser Torture Suite (Phase 03 §8 Challenge #2)
# ---------------------------------------------------------------------------

TORTURE_CASES: list[tuple[str, str, int, int]] = [
    # (id, payload, expected_valid_calls, expected_min_errors)
    (
        "01_valid_canonical_backtick",
        'Hello!\n```tool_call\n{"name": "read_file", "args": {"path": "a.txt"}}\n```\nDone.',
        1,
        0,
    ),
    (
        "02_valid_tilde_fence",
        '~~~tool_call\n{"name": "list_dir", "args": {"path": "."}}\n~~~',
        1,
        0,
    ),
    (
        "03_valid_xml_tool_call",
        'Prose <tool_call>{"name": "glob", "args": {"pattern": "*.py"}}</tool_call> tail',
        1,
        0,
    ),
    (
        "04_unclosed_fence_with_valid_json",
        'Thinking...\n```tool_call\n{"name": "read_file", "args": {"path": "unclosed.md"}}',
        1,
        0,
    ),
    (
        "05_unclosed_fence_with_broken_json",
        '```tool_call\n{"name": "read_file", "args": {"path": ',
        0,
        1,
    ),
    (
        "06_nested_markdown_fence_inside_string_arg",
        (
            '```tool_call\n{"name": "write_file", "args": {"path": "doc.md", '
            '"content": "Here is code:\\n```python\\nprint(1)\\n```\\nEnd"}}\n```'
        ),
        1,
        0,
    ),
    (
        "07_trailing_commas_in_json",
        '```tool_call\n{"name": "read_file", "args": {"path": "x.py", "offset": 1,},}\n```',
        1,
        0,
    ),
    (
        "08_single_quoted_python_dict",
        "```tool_call\n{'name': 'read_file', 'args': {'path': 'single.txt'}}\n```",
        1,
        0,
    ),
    (
        "09_yaml_formatted_tool_call",
        "```tool_call\nname: read_file\nargs:\n  path: yaml_file.txt\n```",
        1,
        0,
    ),
    (
        "10_multiple_tool_calls_in_one_fence_concatenated",
        (
            '```tool_call\n{"name": "read_file", "args": {"path": "1.txt"}}\n'
            '{"name": "read_file", "args": {"path": "2.txt"}}\n```'
        ),
        2,
        0,
    ),
    (
        "11_multiple_tool_calls_json_array_in_one_fence",
        (
            '```tool_call\n[{"name": "read_file", "args": {"path": "a.txt"}}, '
            '{"name": "list_dir", "args": {"path": "."}}]\n```'
        ),
        2,
        0,
    ),
    (
        "12_tool_calls_mixed_with_thinking_tags",
        (
            "<thinking>Let me check the file first.</thinking>\n"
            '```tool_call\n{"name": "read_file", "args": {"path": "main.py"}}\n```'
        ),
        1,
        0,
    ),
    (
        "13_inner_json_fence_inside_tool_call_fence",
        '```tool_call\n```json\n{"name": "read_file", "args": {"path": "inner.json"}}\n```\n```',
        1,
        0,
    ),
    (
        "14_duplicate_key_smuggling_top_level",
        '```tool_call\n{"name": "read_file", "name": "shell", "args": {"command": "id"}}\n```',
        0,
        1,
    ),
    (
        "15_duplicate_key_smuggling_nested_args",
        (
            '```tool_call\n{"name": "write_file", "args": '
            '{"path": "safe.txt", "path": "../evil.txt", "content": "x"}}\n```'
        ),
        0,
        1,
    ),
    (
        "16_deeply_nested_json_depth_200",
        "```tool_call\n" + ("{" * 200) + '"a": 1' + ("}" * 200) + "\n```",
        0,
        1,
    ),
    (
        "17_100kb_garbage_inside_fence",
        "```tool_call\n" + ("X" * 102400) + "\n```",
        0,
        1,
    ),
    (
        "18_giant_exponent_scientific_notation",
        '```tool_call\n{"name": "read_file", "args": {"offset": 1e' + ("9" * 4500) + "}}\n```",
        0,
        1,
    ),
    (
        "19_giant_integer_10000_digits",
        '```tool_call\n{"name": "read_file", "args": {"offset": ' + ("7" * 10000) + "}}\n```",
        0,
        1,
    ),
    (
        "20_nan_constant_rejected",
        '```tool_call\n{"name": "read_file", "args": {"offset": NaN}}\n```',
        0,
        1,
    ),
    (
        "21_infinity_constant_rejected",
        '```tool_call\n{"name": "read_file", "args": {"offset": Infinity}}\n```',
        0,
        1,
    ),
    (
        "22_neg_infinity_constant_rejected",
        '```tool_call\n{"name": "read_file", "args": {"offset": -Infinity}}\n```',
        0,
        1,
    ),
    (
        "23_missing_tool_name",
        '```tool_call\n{"args": {"path": "no_name.txt"}}\n```',
        0,
        1,
    ),
    (
        "24_invalid_tool_name_with_spaces_and_metachars",
        '```tool_call\n{"name": "shell; rm -rf /", "args": {}}\n```',
        0,
        1,
    ),
    (
        "25_non_object_arguments_field",
        '```tool_call\n{"name": "read_file", "args": ["not", "a", "dict"]}\n```',
        0,
        1,
    ),
    (
        "26_empty_tool_call_fence",
        "```tool_call\n   \n```",
        0,
        1,
    ),
    (
        "27_bom_and_null_bytes_in_fence",
        '```tool_call\n\ufeff\x00{"name": "read_file", "args": {"path": "bom.txt"}}\n```',
        1,
        0,
    ),
    (
        "28_json_fence_that_is_not_a_tool_call_stays_prose",
        'Here is config:\n```json\n{"version": 1, "debug": true}\n```',
        0,
        0,
    ),
    (
        "29_json_fence_with_tool_and_arguments_alias",
        '```json\n{"tool": "read_file", "arguments": {"path": "alias.txt"}}\n```',
        1,
        0,
    ),
    (
        "30_unclosed_xml_tool_call_with_complete_json",
        'Let me call <tool_call>{"name": "list_dir", "args": {"path": "src"}}',
        1,
        0,
    ),
]


@pytest.mark.parametrize(
    ("case_id", "payload", "expected_calls", "expected_min_errors"),
    TORTURE_CASES,
    ids=[c[0] for c in TORTURE_CASES],
)
def test_fenced_parser_30_torture_fixtures(
    case_id: str,
    payload: str,
    expected_calls: int,
    expected_min_errors: int,
) -> None:
    """Verify every torture case parses or rejects deterministically in < 100ms."""
    t0 = time.perf_counter()
    res = parse_fenced_tool_calls(payload)
    elapsed_ms = (time.perf_counter() - t0) * 1000.0
    assert elapsed_ms < 250.0, f"Torture case {case_id} took {elapsed_ms:.1f}ms"
    assert len(res.calls) == expected_calls, (
        f"Case {case_id}: calls={res.calls}, errors={res.errors}"
    )
    assert len(res.errors) >= expected_min_errors, f"Case {case_id}: errors={res.errors}"


def test_incremental_fenced_parser_mid_utf8_codepoint_splitting() -> None:
    """Verify IncrementalFencedToolParser handles arbitrary byte splits including mid-UTF-8."""
    full_text = (
        "Checking file 🚀:\n"
        "```tool_call\n"
        '{"name": "write_file", "args": {"path": "notes/日本語_🚀.md", '
        '"content": "こんにちは世界"}}\n'
        "```\n"
        "All done!"
    )
    raw_bytes = full_text.encode("utf-8")
    parser = IncrementalFencedToolParser()
    # Feed 3 bytes at a time (deliberately splitting 3-byte CJK and 4-byte emoji UTF-8 sequences)
    for idx in range(0, len(raw_bytes), 3):
        parser.feed_bytes(raw_bytes[idx : idx + 3])
    res = parser.finalize()
    assert len(res.calls) == 1
    assert res.calls[0].name == "write_file"
    assert res.calls[0].args["path"] == "notes/日本語_🚀.md"
    assert res.calls[0].args["content"] == "こんにちは世界"

    repair_prompt = build_tool_call_repair_prompt(res.errors)
    assert "```tool_call" in repair_prompt
    instr = format_fenced_tool_instructions(
        [
            {
                "name": "read_file",
                "description": "Read file",
                "parameters": {"properties": {"path": {}}},
            }
        ]
    )
    assert "read_file" in instr


# ---------------------------------------------------------------------------
# 3. 60-Vector Workspace Filesystem Jail Escape Test (Phase 03 §8 Challenge #3)
# ---------------------------------------------------------------------------


def _build_60_escape_vectors(ws_root: Path, outside_dir: Path) -> list[tuple[str, str]]:
    outside_file = outside_dir / "secret.txt"
    outside_file.write_text("TOP_SECRET_OUTSIDE", encoding="utf-8")

    # Create symlinks inside workspace pointing outside
    sym_direct = ws_root / "sym_outside"
    if not sym_direct.exists() and not sym_direct.is_symlink():
        sym_direct.symlink_to(outside_file)

    sym_dir = ws_root / "sym_outside_dir"
    if not sym_dir.exists() and not sym_dir.is_symlink():
        sym_dir.symlink_to(outside_dir)

    sym_chain_1 = ws_root / "sym_chain_1"
    sym_chain_2 = ws_root / "sym_chain_2"
    if not sym_chain_2.exists() and not sym_chain_2.is_symlink():
        sym_chain_2.symlink_to(outside_file)
    if not sym_chain_1.exists() and not sym_chain_1.is_symlink():
        sym_chain_1.symlink_to(sym_chain_2)

    sub_dir = ws_root / "nested" / "deep"
    sub_dir.mkdir(parents=True, exist_ok=True)
    sym_rel = sub_dir / "rel_escape"
    if not sym_rel.exists() and not sym_rel.is_symlink():
        sym_rel.symlink_to(Path("../../../") / outside_dir.name / "secret.txt")

    sym_broken = ws_root / "sym_broken_outside"
    if not sym_broken.exists() and not sym_broken.is_symlink():
        sym_broken.symlink_to(outside_dir / "nonexistent_target.txt")

    vectors: list[tuple[str, str]] = [
        ("01_dotdot_simple", ".."),
        ("02_dotdot_slash", "../"),
        ("03_dotdot_file", "../secret.txt"),
        ("04_dotdot_2x", "../../etc/passwd"),
        ("05_dotdot_3x", "../../../etc/passwd"),
        ("06_dotdot_4x", "../../../../etc/shadow"),
        ("07_dotdot_10x", ("../" * 10) + "etc/hosts"),
        ("08_nested_then_dotdot", "nested/../../secret.txt"),
        ("09_nested_deep_dotdot", "nested/deep/../../../secret.txt"),
        ("10_dot_dotdot_mix", "./nested/./../../secret.txt"),
        ("11_abs_etc_passwd", "/etc/passwd"),
        ("12_abs_etc_shadow", "/etc/shadow"),
        ("13_abs_root_ssh", "/root/.ssh/id_rsa"),
        ("14_abs_proc_self_environ", "/proc/self/environ"),
        ("15_abs_proc_self_cmdline", "/proc/self/cmdline"),
        ("16_abs_proc_self_maps", "/proc/self/maps"),
        ("17_abs_proc_self_fd_0", "/proc/self/fd/0"),
        ("18_abs_dev_urandom", "/dev/urandom"),
        ("19_abs_var_run_docker", "/var/run/docker.sock"),
        ("20_abs_outside_secret", str(outside_file)),
        ("21_double_leading_slash", "//etc/passwd"),
        ("22_triple_leading_slash", "///etc/passwd"),
        ("23_backslash_dotdot", "..\\secret.txt"),
        ("24_backslash_2x", "..\\..\\etc\\passwd"),
        ("25_backslash_nested", "nested\\..\\..\\secret.txt"),
        ("26_mixed_slash_backslash", "nested/../..\\secret.txt"),
        ("27_unc_path_backslash", "\\\\localhost\\c$\\windows\\win.ini"),
        ("28_unc_path_forward", "//localhost/c$/windows/win.ini"),
        ("29_windows_drive_c", "C:\\Windows\\System32\\cmd.exe"),
        ("30_windows_drive_d_rel", "D:../secret.txt"),
        ("31_url_encoded_dotdot_lower", "%2e%2e/secret.txt"),
        ("32_url_encoded_dotdot_upper", "%2E%2E/secret.txt"),
        ("33_url_encoded_slash", "..%2fsecret.txt"),
        ("34_url_encoded_full", "%2e%2e%2f%2e%2e%2fetc%2fpasswd"),
        ("35_url_encoded_backslash", "%2e%2e%5csecret.txt"),
        ("36_double_url_encoded_dotdot", "%252e%252e/secret.txt"),
        ("37_double_url_encoded_full", "%252e%252e%252fetc%252fpasswd"),
        ("38_mixed_raw_and_url_encoded", ".%2e/secret.txt"),
        ("39_null_byte_prefix", "\x00../secret.txt"),
        ("40_null_byte_mid", "safe.txt\x00/../../etc/passwd"),
        ("41_null_byte_suffix", "../secret.txt\x00"),
        ("42_url_encoded_null_byte", "safe.txt%00/../../etc/passwd"),
        ("43_tilde_home", "~"),
        ("44_tilde_slash", "~/.ssh/id_rsa"),
        ("45_tilde_user", "~root/.bashrc"),
        ("46_tilde_dotdot", "~/../secret.txt"),
        ("47_unicode_fullwidth_dots", "\uff0e\uff0e/secret.txt"),
        ("48_unicode_one_dot_leader", "\u2024\u2024/secret.txt"),
        ("49_unicode_two_dot_leader", "\u2025/secret.txt"),
        ("50_unicode_fullwidth_solidus", "..\uff0fsecret.txt"),
        ("51_unicode_division_slash", "..\u2215secret.txt"),
        ("52_unicode_fraction_slash", "..\u2044secret.txt"),
        ("53_control_char_newline", "safe\n/../secret.txt"),
        ("54_control_char_cr", "safe\r/../secret.txt"),
        ("55_symlink_direct_to_outside_file", "sym_outside"),
        ("56_symlink_to_outside_dir_traversal", "sym_outside_dir/secret.txt"),
        ("57_symlink_chain_to_outside", "sym_chain_1"),
        ("58_symlink_relative_deep_escape", "nested/deep/rel_escape"),
        ("59_symlink_broken_outside_target", "sym_broken_outside"),
        ("60_symlink_outside_dir_new_file", "sym_outside_dir/new_pwn.txt"),
    ]
    return vectors


def test_filesystem_jail_blocks_all_60_escape_vectors(tmp_path: Path) -> None:
    """Verify all 60 path-escape vectors raise WorkspacePathEscapeError."""
    ws_root = tmp_path / "workspace"
    ws_root.mkdir(parents=True, exist_ok=True)
    outside_dir = tmp_path / "outside"
    outside_dir.mkdir(parents=True, exist_ok=True)

    vectors = _build_60_escape_vectors(ws_root, outside_dir)
    assert len(vectors) >= 60

    for vec_id, raw_path in vectors:
        with pytest.raises(WorkspaceEscapeError, match=r".") as exc_info:
            resolve_workspace_path(ws_root, raw_path)
        assert exc_info.value is not None, f"Vector {vec_id} did not raise"

        with pytest.raises(WorkspaceEscapeError):
            workspace_read_file(ws_root, raw_path)

        with pytest.raises(WorkspaceEscapeError):
            workspace_write_file(ws_root, raw_path, "evil")


def test_filesystem_jail_normal_operations_and_fifo_rejection(tmp_path: Path) -> None:
    """Verify valid workspace file operations work and special FIFO files are rejected."""
    ws_root = tmp_path / "ws_ok"
    ws_root.mkdir(parents=True, exist_ok=True)

    w_res = workspace_write_file(ws_root, "src/hello.py", "print('hello')\nprint('world')\n")
    assert w_res["path"] == "src/hello.py"

    r_res = workspace_read_file(ws_root, "src/hello.py", offset=1, limit=10)
    assert "print('hello')" in r_res["content"]

    e_res = workspace_edit_file(
        ws_root,
        "src/hello.py",
        old_text="print('world')",
        new_text="print('odysseus')",
    )
    assert "+print('odysseus')" in e_res["diff"]

    l_res = workspace_list_dir(ws_root, ".")
    assert any(e["name"] == "src" for e in l_res["entries"])

    g_res = workspace_glob(ws_root, "**/*.py")
    assert "src/hello.py" in g_res["matches"]

    gr_res = workspace_grep(ws_root, "odysseus")
    assert len(gr_res["hits"]) == 1  # type: ignore[arg-type]

    # Create a named pipe (FIFO) inside workspace and verify read_file rejects it
    fifo_path = ws_root / "named_pipe.fifo"
    os.mkfifo(fifo_path)
    with pytest.raises(WorkspaceEscapeError):
        workspace_read_file(ws_root, "named_pipe.fifo")


async def test_bundled_mcp_servers_and_tools_reexport(tmp_path: Path) -> None:
    """Verify backend.tools re-export and bundled MCP JSON-RPC request handlers directly."""
    import backend.tools as tools_pkg
    from backend.mcp.bundled.fetch_server import _handle_request as fetch_rpc
    from backend.mcp.bundled.filesystem_server import _handle_request as fs_rpc

    assert hasattr(tools_pkg, "ToolRegistry")
    ws = tmp_path / "mcp_unit"
    ws.mkdir(parents=True, exist_ok=True)

    assert fs_rpc({"method": "notifications/initialized"}, ws) is None
    init_res = fs_rpc({"id": 1, "method": "initialize"}, ws)
    assert init_res is not None and "result" in init_res
    list_res = fs_rpc({"id": 2, "method": "tools/list"}, ws)
    assert list_res is not None and len(list_res["result"]["tools"]) >= 4
    res_list = fs_rpc({"id": 3, "method": "resources/list"}, ws)
    assert res_list is not None
    prm_list = fs_rpc({"id": 4, "method": "prompts/list"}, ws)
    assert prm_list is not None

    w_call = fs_rpc(
        {
            "id": 5,
            "method": "tools/call",
            "params": {
                "name": "mcp_fs_write",
                "arguments": {"path": "a.txt", "content": "hello_mcp"},
            },
        },
        ws,
    )
    assert w_call is not None and w_call["result"]["isError"] is False

    r_call = fs_rpc(
        {
            "id": 6,
            "method": "tools/call",
            "params": {"name": "read_text_file", "arguments": {"path": "a.txt"}},
        },
        ws,
    )
    assert r_call is not None and "hello_mcp" in r_call["result"]["content"][0]["text"]

    l_call = fs_rpc(
        {
            "id": 7,
            "method": "tools/call",
            "params": {"name": "list_directory", "arguments": {"path": "."}},
        },
        ws,
    )
    assert l_call is not None and l_call["result"]["isError"] is False

    bad_tool = fs_rpc(
        {"id": 8, "method": "tools/call", "params": {"name": "unknown", "arguments": {}}},
        ws,
    )
    assert bad_tool is not None and "error" in bad_tool

    esc_call = fs_rpc(
        {
            "id": 9,
            "method": "tools/call",
            "params": {"name": "read_text_file", "arguments": {"path": "../outside.txt"}},
        },
        ws,
    )
    assert esc_call is not None and esc_call["result"]["isError"] is True

    # Bundled fetch server
    assert await fetch_rpc({"method": "notifications/initialized"}) is None
    f_init = await fetch_rpc({"id": 1, "method": "initialize"})
    assert f_init is not None and "result" in f_init
    f_list = await fetch_rpc({"id": 2, "method": "tools/list"})
    assert f_list is not None and len(f_list["result"]["tools"]) == 1
    f_ssrf = await fetch_rpc(
        {
            "id": 3,
            "method": "tools/call",
            "params": {"name": "mcp_fetch_url", "arguments": {"url": "http://127.0.0.1:8000/"}},
        }
    )
    assert f_ssrf is not None and f_ssrf["result"]["isError"] is True
    f_unk = await fetch_rpc(
        {"id": 4, "method": "tools/call", "params": {"name": "bad", "arguments": {}}}
    )
    assert f_unk is not None and "error" in f_unk

    # Bundled playwright cached-only server and bundled presets registry
    from backend.mcp.bundled import get_bundled_mcp_presets
    from backend.mcp.bundled.playwright_server import handle_request as pw_rpc

    presets = get_bundled_mcp_presets(ws)
    assert [p["name"] for p in presets] == ["filesystem", "fetch", "playwright"]
    assert all(p["enabled"] is False for p in presets)

    assert pw_rpc({"method": "notifications/initialized"}, ws) is None
    pw_init = pw_rpc({"id": 1, "method": "initialize"}, ws)
    assert pw_init is not None and "result" in pw_init
    pw_tools = pw_rpc({"id": 2, "method": "tools/list"}, ws)
    assert pw_tools is not None and len(pw_tools["result"]["tools"]) == 1
    (ws / "cached.html").write_text(
        "<html><head><title>Cached</title></head>"
        '<body><a href="/doc">Doc</a>Hello DOM</body></html>',
        encoding="utf-8",
    )
    pw_snap = pw_rpc(
        {
            "id": 3,
            "method": "tools/call",
            "params": {"name": "snapshot_cached_html", "arguments": {"path": "cached.html"}},
        },
        ws,
    )
    assert pw_snap is not None and pw_snap["result"]["isError"] is False
    assert "Hello DOM" in pw_snap["result"]["content"][0]["text"]
    pw_esc = pw_rpc(
        {
            "id": 4,
            "method": "tools/call",
            "params": {"name": "snapshot_cached_html", "arguments": {"path": "../outside.html"}},
        },
        ws,
    )
    assert pw_esc is not None and pw_esc["result"]["isError"] is True
    pw_unk = pw_rpc(
        {"id": 5, "method": "tools/call", "params": {"name": "bad", "arguments": {}}},
        ws,
    )
    assert pw_unk is not None and "error" in pw_unk
