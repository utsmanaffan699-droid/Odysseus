"""Unit tests for RunEventEnvelope, all 8 golden fixtures, and FakeProvider DSL + OpenAI server."""

from __future__ import annotations

import json
from pathlib import Path

import httpx
import pytest
from backend.domain.events import EVENT_PAYLOAD_MODELS, RunEventEnvelope, format_sse_event
from backend.domain.runs import reduce_run_state
from backend.providers.fake import (
    FakeHttpError,
    FakeProvider,
    FakeScript,
    FakeScriptStep,
    FakeStreamDisconnectedError,
    create_fake_openai_app,
    load_fake_script,
)

ROOT = Path(__file__).resolve().parent.parent.parent.parent
FIXTURES_DIR = ROOT / "contracts" / "fixtures"


def test_all_eight_golden_fixtures_validate_and_reduce() -> None:
    """Verify that all 13 golden fixtures in contracts/fixtures/ validate and reduce cleanly."""
    fixture_files = sorted(FIXTURES_DIR.glob("*.json"))
    assert len(fixture_files) == 13

    seen_types: set[str] = set()
    for fpath in fixture_files:
        raw_list = json.loads(fpath.read_text(encoding="utf-8"))
        envelopes = [RunEventEnvelope.model_validate(item) for item in raw_list]
        for env in envelopes:
            seen_types.add(env.type)
            sse_str = format_sse_event(env)
            assert sse_str.startswith(f"id: {env.seq}\nevent: {env.type}\ndata: ")

        state = reduce_run_state(envelopes)
        assert state.run_id == envelopes[0].run_id
        assert state.last_seq == len(envelopes)

    assert seen_types == set(EVENT_PAYLOAD_MODELS.keys())


async def test_fake_provider_script_dsl_all_step_types() -> None:
    """Verify FakeProvider DSL: thinking, tool_call, long_output, fences, unicode, usage, errors."""
    script = FakeScript(
        name="comprehensive-test",
        model="fake/test",
        steps=[
            FakeScriptStep(kind="thinking", text="Step 1 thinking", duration_ms=50),
            FakeScriptStep(
                kind="tool_call",
                call_id="c1",
                tool_name="search",
                args={"q": "odysseus"},
            ),
            FakeScriptStep(
                kind="tool_call",
                call_id="c2",
                tool_name="broken",
                malformed_json="{unclosed_json: true",
            ),
            FakeScriptStep(kind="long_output", lines=10, chunk_size=128),
            FakeScriptStep(kind="unclosed_fence", language="rust", text="fn main() {}"),
            FakeScriptStep(kind="unicode_edge"),
            FakeScriptStep(kind="usage", input_tokens=20, output_tokens=100, cost=0.005),
        ],
    )
    provider = FakeProvider(script)
    probe_info = await provider.probe()
    assert probe_info["healthy"] is True

    chunks = [c async for c in provider.stream_completion([{"role": "user", "content": "hi"}])]
    kinds = [c.kind for c in chunks]
    assert "thinking" in kinds
    assert "tool_call" in kinds
    assert "text" in kinds
    assert "usage" in kinds

    malformed_calls = [c for c in chunks if c.call_id == "c2"]
    assert len(malformed_calls) == 1
    assert malformed_calls[0].tool_args_valid is False

    # Test mid-stream disconnect
    disc_script = load_fake_script(
        {
            "name": "disconnect-script",
            "steps": [
                {"kind": "text", "text": "Partial chunk before drop"},
                {"kind": "disconnect"},
            ],
        }
    )
    received: list[str] = []
    with pytest.raises(FakeStreamDisconnectedError):
        async for ch in provider.stream_completion([], script_override=disc_script):
            received.append(ch.text)
    assert received == ["Partial chunk before drop"]

    # Test HTTP 429 with Retry-After
    err_script = load_fake_script(
        {
            "name": "rate-limit-script",
            "steps": [
                {
                    "kind": "http_error",
                    "status_code": 429,
                    "retry_after": 7,
                    "error_message": "Rate limited",
                }
            ],
        }
    )
    with pytest.raises(FakeHttpError) as exc_info:
        async for _ in provider.stream_completion([], script_override=err_script):
            pass
    assert exc_info.value.status_code == 429
    assert exc_info.value.retry_after == 7


async def test_fake_openai_http_server() -> None:
    """Verify FakeProvider OpenAI-compatible HTTP server (/v1/models, /v1/chat/completions, 429)."""
    sample_yaml = FIXTURES_DIR / "fake_script_sample.yaml"
    script = load_fake_script(sample_yaml)
    app = create_fake_openai_app(script)

    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://fake.local") as client:
        r_health = await client.get("/health")
        assert r_health.status_code == 200

        r_models = await client.get("/v1/models")
        assert r_models.status_code == 200
        assert r_models.json()["data"][0]["id"] == "fake/odysseus-v1"

        # Non-streaming completion
        r_comp = await client.post(
            "/v1/chat/completions",
            json={"model": "fake/odysseus-v1", "messages": [{"role": "user", "content": "hi"}]},
        )
        assert r_comp.status_code == 200
        body = r_comp.json()
        assert "Durable runs" in body["choices"][0]["message"]["content"]

        # Streaming completion
        r_stream = await client.post(
            "/v1/chat/completions",
            json={"model": "fake/odysseus-v1", "stream": True, "messages": []},
        )
        assert r_stream.status_code == 200
        assert "data: [DONE]" in r_stream.text

        # Update script to return 429 with Retry-After
        await client.post(
            "/v1/admin/script",
            json={
                "name": "429-test",
                "steps": [{"kind": "http_error", "status_code": 429, "retry_after": 12}],
            },
        )
        r_429 = await client.post("/v1/chat/completions", json={"messages": []})
        assert r_429.status_code == 429
        assert r_429.headers["Retry-After"] == "12"


async def test_fake_provider_phase04_triggers_and_chat_seed_export(tmp_path: Path) -> None:
    """Verify FakeProvider Phase 04 prompt triggers and ChatService seed/export."""
    from backend.core.db import DatabaseManager
    from backend.core.migrations import upgrade_db_async
    from backend.core.models import User
    from backend.core.settings import Settings
    from backend.core.uow import UnitOfWork
    from backend.domain.chats.service import ChatService
    from sqlalchemy.ext.asyncio import AsyncSession

    provider = FakeProvider()
    for trigger, expected in [
        ("[FAKE_SLOW] test", "Chunk_20_steady"),
        ("[FAKE_RICH] test", "mermaid"),
        ("[FAKE_ECHO] custom echo payload", "custom echo payload"),
    ]:
        chunks = [
            ev.text
            for ev in [
                e async for e in provider.stream_completion([{"role": "user", "content": trigger}])
            ]
            if ev.text
        ]
        assert expected in "".join(chunks)

    db_path = tmp_path / "seed_export.db"
    settings = Settings(
        environment="test",
        data_dir=tmp_path / "data",
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{db_path}",
    )
    db = DatabaseManager(settings)
    await upgrade_db_async(db.engine)
    try:

        async def _mk_user(sess: AsyncSession) -> str:
            from datetime import UTC, datetime

            now = datetime.now(UTC)
            uow = UnitOfWork(sess)
            u = User(
                id="u_seed",
                username="seeder",
                email="seeder@odysseus.local",
                password_hash="h",
                created_at=now,
                updated_at=now,
            )
            await uow.users.add(u)
            return u.id

        uid = await db.execute_write(_mk_user)
        svc = ChatService(db=db)
        proj = await svc.create_project(
            user_id=uid,
            name="P1",
            description="Desc",
            instructions="Inst",
            token_budget=4000,
        )
        assert proj["name"] == "P1"
        projs = await svc.list_projects(user_id=uid)
        assert len(projs) == 1
        upd_proj = await svc.update_project(
            project_id=proj["id"],
            user_id=uid,
            name="P1-Updated",
            token_budget=8000,
        )
        assert upd_proj is not None and upd_proj["name"] == "P1-Updated"

        chat = await svc.create_chat(user_id=uid, title="Seed Chat", project_id=proj["id"])
        seeded = await svc.seed_messages(chat_id=chat["id"], user_id=uid, count=20)
        assert seeded["seeded_count"] == 20
        detail = await svc.get_chat_detail(chat_id=chat["id"], user_id=uid)
        assert detail is not None and len(detail["messages"]) == 20
        assert await svc.delete_project(project_id=proj["id"], user_id=uid) is True
    finally:
        await db.dispose()
