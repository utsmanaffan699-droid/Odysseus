"""Unit tests for layered settings, 25+ bad-config matrix, and UTF-8 BOM + CRLF .env parsing."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest
from backend.core.settings import Settings, SettingsConfigurationError, load_settings


def test_dotenv_utf8_bom_and_crlf_parses_cleanly(tmp_path: Path) -> None:
    """Acceptance Test #7: .env saved with a UTF-8 BOM and CRLF still parses correctly."""
    env_file = tmp_path / ".env"
    content = (
        "# Comment line with CRLF\r\n"
        "ODYSSEUS_ENVIRONMENT=staging\r\n"
        "ODYSSEUS_PORT=8123\r\n"
        'ODYSSEUS_ADMIN_USER="bom_admin"\r\n'
        "ODYSSEUS_SESSION_IDLE_TIMEOUT_SECONDS=1800\r\n"
        'ODYSSEUS_ALLOWED_HOSTS=["127.0.0.1","bom.local"]\r\n'
    )
    # Write with explicit UTF-8 BOM (\xef\xbb\xbf) and CRLF line endings
    raw_bytes = b"\xef\xbb\xbf" + content.encode("utf-8")
    env_file.write_bytes(raw_bytes)

    settings = load_settings(env_file=env_file, ignore_process_env=True)
    assert settings.environment == "staging"
    assert settings.port == 8123
    assert settings.admin_user == "bom_admin"
    assert settings.session_idle_timeout_seconds == 1800
    assert settings.allowed_hosts == ["127.0.0.1", "bom.local"]


def test_settings_validation_matrix_28_bad_cases_aggregated() -> None:
    """Deliverable #4: >= 25 bad-config cases produce a single aggregated, readable error."""
    bad_overrides: dict[str, Any] = {
        "environment": "invalid_env",
        "bind_host": "",
        "port": -80,
        "log_level": "VERBOSE_INVALID",
        "admin_user": "a",
        "admin_email": "not-an-email",
        "database_url": "mysql://unsupported/db",
        "db_pool_size": 0,
        "db_max_overflow": -5,
        "db_busy_timeout_ms": 0,
        "session_idle_timeout_seconds": -10,
        "session_absolute_timeout_seconds": 0,
        "login_max_attempts_per_ip": 0,
        "login_max_attempts_per_user": -1,
        "login_window_seconds": 0,
        "login_base_lockout_seconds": -5,
        "totp_max_attempts": 0,
        "session_cookie_name": "ab",
        "allowed_hosts": [],
        "allowed_origins": ["*"],
        "max_header_bytes": 0,
        "max_header_count": -1,
        "max_body_bytes_default": 0,
        "max_body_bytes_auth": -100,
        "max_body_bytes_upload": 0,
        "request_read_timeout_seconds": 0,
        "rate_limit_requests_per_minute": 0,
        "rate_limit_burst": -1,
        "job_worker_concurrency": 0,
        "job_lease_seconds": 0,
        "job_heartbeat_seconds": 0,
        "job_max_attempts": 0,
        "sse_keepalive_seconds": 0,
        "sse_max_lag_events": 0,
        "sse_max_chunk_bytes": 0,
        "chromadb_url": "ftp://invalid-scheme",
        "searxng_url": "invalid-url",
        "ntfy_url": "ws://invalid",
    }
    assert len(bad_overrides) >= 25

    with pytest.raises(SettingsConfigurationError) as exc_info:
        load_settings(env_file=None, overrides=bad_overrides, ignore_process_env=True)

    err = exc_info.value
    assert len(err.problems) >= 25
    msg = str(err)
    assert "Invalid Odysseus configuration" in msg
    assert "ODYSSEUS_PORT" in msg
    assert "ODYSSEUS_DATABASE_URL" in msg
    assert "ODYSSEUS_MAX_BODY_BYTES_DEFAULT" in msg


def test_cross_field_validation_and_runtime_overrides() -> None:
    """Verify cross-field constraints and runtime override protection."""
    with pytest.raises(SettingsConfigurationError) as exc_info:
        load_settings(
            env_file=None,
            overrides={
                "session_idle_timeout_seconds": 7200,
                "session_absolute_timeout_seconds": 3600,
                "job_lease_seconds": 10,
                "job_heartbeat_seconds": 10,
            },
            ignore_process_env=True,
        )
    assert "session_absolute_timeout_seconds" in str(exc_info.value)

    base = Settings()
    updated = base.apply_runtime_overrides(
        {"rate_limit_requests_per_minute": 600, "default_model": "fake/fast"}
    )
    assert updated.rate_limit_requests_per_minute == 600
    assert updated.default_model == "fake/fast"

    with pytest.raises(ValueError, match="Secret key"):
        base.apply_runtime_overrides({"openai_api_key": "sk-secret"})

    with pytest.raises(ValueError, match="not runtime-editable"):
        base.apply_runtime_overrides({"database_url": "sqlite+aiosqlite:///other.db"})
