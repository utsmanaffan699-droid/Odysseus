"""Unit and integration tests for JobSupervisor, domain agents/tools, SSE, and security."""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime, timedelta
from pathlib import Path

import httpx
import pytest
from backend.app.main import create_app
from backend.core.auth import mint_api_token
from backend.core.db import DatabaseManager
from backend.core.jobs import JobSupervisor
from backend.core.migrations import upgrade_db_async
from backend.core.models import JobRecord
from backend.core.settings import Settings
from backend.core.uow import UnitOfWork
from backend.domain.agents import AgentPreset, validate_agent_preset
from backend.domain.tools.policy import (
    ToolDefinition,
    ToolPolicyEngine,
    wrap_untrusted_content,
)


def test_agent_config_and_tool_policy_branches() -> None:
    """Verify AgentPreset, validate_agent_preset, and all ToolPolicyEngine branches."""
    preset = AgentPreset(
        id="agent_default",
        name="Odysseus Default Agent",
        system_prompt="You are Odysseus.",
        tools=["file_write"],
    )
    validated = validate_agent_preset(preset, {"file_write", "safe_read"})
    assert validated.id == "agent_default"

    with pytest.raises(ValueError, match="unknown tools"):
        validate_agent_preset(preset, {"safe_read"})

    wrapped = wrap_untrusted_content("web:https://example.com>", "payload")
    assert "untrusted_external_data" in wrapped

    read_tool = ToolDefinition(
        name="safe_read", risk="read", required_privilege="files", default_approval="auto"
    )
    write_tool = ToolDefinition(
        name="file_write", risk="write", required_privilege="files", default_approval="ask"
    )
    admin_tool = ToolDefinition(
        name="admin_nuke", risk="admin", required_privilege="admin", default_approval="deny"
    )

    engine = ToolPolicyEngine(
        allow_patterns=["file_write:/workspace/notes/*"],
        deny_patterns=["file_write:/etc/*"],
    )

    # 1. Explicit allow pattern in untainted context -> auto
    r_allow = engine.evaluate(
        write_tool,
        {"path": "/workspace/notes/todo.md"},
        user_privileges=frozenset({"files"}),
        tainted_source=None,
    )
    assert r_allow.decision == "auto"

    # 2. Explicit deny pattern -> deny
    r_deny = engine.evaluate(
        write_tool,
        {"path": "/etc/passwd"},
        user_privileges=frozenset({"files"}),
        tainted_source=None,
    )
    assert r_deny.decision == "deny"

    # 3. Default ask when no pattern matches
    r_ask = engine.evaluate(
        write_tool,
        {"path": "/workspace/other.md"},
        user_privileges=frozenset({"files"}),
        tainted_source=None,
    )
    assert r_ask.decision == "ask"

    # 4. Read tool in tainted context -> still auto
    r_read = engine.evaluate(
        read_tool,
        {"path": "README.md"},
        user_privileges=frozenset({"files"}),
        tainted_source="email:123",
    )
    assert r_read.decision == "auto"

    # 5. Admin tool with default_approval="deny" -> deny both tainted and untainted
    r_admin_tainted = engine.evaluate(
        admin_tool,
        {"command": "drop"},
        user_privileges=frozenset({"admin"}),
        tainted_source="web:evil",
    )
    assert r_admin_tainted.decision == "deny"

    r_admin_untainted = engine.evaluate(
        admin_tool,
        {"command": "drop"},
        user_privileges=frozenset({"admin"}),
        tainted_source=None,
    )
    assert r_admin_untainted.decision == "deny"


async def test_job_supervisor_worker_pool_retries_dead_letter_and_heartbeat(
    tmp_path: Path,
) -> None:
    """Exercise JobSupervisor worker loop, heartbeat, retry backoff, and dead-letter state."""
    data_dir = tmp_path / "data"
    settings = Settings(
        environment="test",
        data_dir=data_dir,
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{data_dir / 'jobs.db'}",
        job_worker_concurrency=2,
        job_lease_seconds=10,
        job_heartbeat_seconds=1,
    )
    db = DatabaseManager(settings)
    await upgrade_db_async(db.engine)

    supervisor = JobSupervisor(db, settings)
    completed_jobs: list[str] = []

    async def succeeding_handler(job: JobRecord, payload: dict[str, object]) -> dict[str, object]:
        await asyncio.sleep(0.05)
        completed_jobs.append(job.id)
        return {"ok": True, "payload": payload}

    async def failing_handler(job: JobRecord, _payload: dict[str, object]) -> dict[str, object]:
        raise RuntimeError(f"boom on attempt {job.attempts}")

    supervisor.register_handler("test_ok", succeeding_handler)
    supervisor.register_handler("test_fail", failing_handler)

    job_ok = await supervisor.enqueue(
        kind="test_ok",
        payload={"msg": "ok"},
        max_attempts=2,
    )
    job_noop = await supervisor.enqueue(
        kind="noop",
        payload={"ping": "pong"},
        max_attempts=1,
    )
    job_fail = await supervisor.enqueue(
        kind="test_fail",
        payload={"msg": "fail"},
        max_attempts=1,
    )
    job_unregistered = await supervisor.enqueue(
        kind="no_such_handler",
        payload={},
        max_attempts=1,
    )

    await supervisor.start()
    await asyncio.sleep(0.6)
    await supervisor.stop()

    assert job_ok.id in completed_jobs

    async with db.session() as sess:
        uow = UnitOfWork(sess)
        rec_ok = await uow.jobs.get(job_ok.id)
        rec_noop = await uow.jobs.get(job_noop.id)
        rec_fail = await uow.jobs.get(job_fail.id)
        rec_unreg = await uow.jobs.get(job_unregistered.id)
        assert rec_ok is not None and rec_ok.status == "completed"
        assert rec_noop is not None and rec_noop.status == "completed"
        assert rec_fail is not None and rec_fail.status == "dead_letter"
        assert rec_unreg is not None and rec_unreg.status == "dead_letter"

    await db.dispose()


async def test_runs_sse_replay_cancel_2fa_disable_and_cors_hsts(
    tmp_path: Path,
) -> None:
    """Exercise run creation, SSE event streaming, run cancel, 2FA recovery, and CORS/HSTS."""
    data_dir = tmp_path / "data"
    settings = Settings(
        environment="test",
        data_dir=data_dir,
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{data_dir / 'full_flow.db'}",
        trusted_proxies=["127.0.0.1"],
        allowed_origins=["https://app.odysseus.local"],
    )
    app = create_app(settings, start_job_workers=False)

    async with app.router.lifespan_context(app):
        admin_pw = app.state.bootstrap_admin_result.temporary_password
        transport = httpx.ASGITransport(app=app, client=("127.0.0.1", 50000))
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client:
            # 1. Trusted proxy X-Forwarded-Proto: https injects HSTS and CORS headers
            r_cors = await client.options(
                "/api/health/live",
                headers={
                    "Origin": "https://app.odysseus.local",
                    "X-Forwarded-Proto": "https",
                    "X-Forwarded-For": "203.0.113.7, 127.0.0.1",
                },
            )
            assert r_cors.status_code == 204
            assert r_cors.headers.get("Access-Control-Allow-Origin") == "https://app.odysseus.local"
            assert "Strict-Transport-Security" in r_cors.headers

            # 2. Login and change password
            r_login = await client.post(
                "/api/auth/login",
                json={"username": "admin", "password": admin_pw},
            )
            csrf = r_login.json()["csrf_token"]
            await client.post(
                "/api/auth/password/change",
                json={"current_password": admin_pw, "new_password": "StrongAdminPassword!2026"},
                headers={"X-CSRF-Token": csrf},
            )

            # 3. Enroll 2FA and verify with a recovery code
            r_enroll = await client.post(
                "/api/auth/2fa/enroll",
                headers={"X-CSRF-Token": csrf},
            )
            assert r_enroll.status_code == 200
            recovery_code = r_enroll.json()["recovery_codes"][0]

            r_verify_rec = await client.post(
                "/api/auth/2fa/verify",
                json={"code": recovery_code},
                headers={"X-CSRF-Token": csrf},
            )
            assert r_verify_rec.status_code == 200
            assert r_verify_rec.json()["totp_enabled"] is True

            # 4. Create, list, and revoke an API token + expired token check
            r_tok = await client.post(
                "/api/auth/tokens",
                json={"name": "temp-token", "scopes": ["chat"], "expires_in_days": 7},
                headers={"X-CSRF-Token": csrf},
            )
            assert r_tok.status_code == 200
            tok_id = r_tok.json()["id"]

            r_list_tok = await client.get("/api/auth/tokens")
            assert r_list_tok.status_code == 200
            assert any(t["id"] == tok_id for t in r_list_tok.json())

            r_del_tok = await client.delete(
                f"/api/auth/tokens/{tok_id}",
                headers={"X-CSRF-Token": csrf},
            )
            assert r_del_tok.status_code == 200

            # 5. Create a chat + durable run + events, stream SSE with Last-Event-ID, and cancel
            r_chat = await client.post(
                "/api/chats",
                json={"title": "SSE Test Chat"},
                headers={"X-CSRF-Token": csrf},
            )
            chat_id = r_chat.json()["id"]
            run_id = "r_sse_test_1"

            async def _seed_run(sess: object) -> None:
                from backend.core.models import RunRecord
                from sqlalchemy.ext.asyncio import AsyncSession

                assert isinstance(sess, AsyncSession)
                uow = UnitOfWork(sess)
                admin = await uow.users.get_by_username("admin")
                assert admin is not None
                now = datetime.now(UTC)
                run = RunRecord(
                    id=run_id,
                    chat_id=chat_id,
                    user_id=admin.id,
                    message_id="m_1",
                    status="streaming",
                    model="fake/default",
                    budget_json={"max_steps": 10},
                    usage_json={"input": 5, "output": 10},
                    started_at=now,
                    finished_at=None,
                    created_at=now,
                )
                await uow.chats.create_run(run)
                await uow.chats.append_run_event(
                    run_id=run_id,
                    event_type="run.started",
                    data={
                        "chat_id": chat_id,
                        "message_id": "m_1",
                        "model": "fake/default",
                        "budget": {},
                    },
                    ts=now.isoformat(),
                )
                await uow.chats.append_run_event(
                    run_id=run_id,
                    event_type="message.text.delta",
                    data={"part_id": "p_1", "text": "Hello from FakeProvider!"},
                    ts=now.isoformat(),
                )

            await app.state.db.execute_write(_seed_run)

            r_snap = await client.get(f"/api/runs/{run_id}")
            assert r_snap.status_code == 200
            assert r_snap.json()["status"] == "streaming"
            assert r_snap.json()["last_seq"] == 2

            r_sse = await client.get(
                f"/api/runs/{run_id}/events",
                headers={"Last-Event-ID": "1"},
            )
            assert r_sse.status_code == 200
            assert "event: message.text.delta" in r_sse.text
            assert "event: run.started" not in r_sse.text

            r_cancel = await client.post(
                f"/api/runs/{run_id}/cancel",
                headers={"X-CSRF-Token": csrf},
            )
            assert r_cancel.status_code == 200
            assert r_cancel.json()["status"] == "cancelled"

            # 6. List sessions and revoke a secondary session
            r_sessions = await client.get("/api/auth/sessions")
            assert r_sessions.status_code == 200
            current_session_id = r_sessions.json()[0]["id"]
            r_revoke_self = await client.delete(
                f"/api/auth/sessions/{current_session_id}",
                headers={"X-CSRF-Token": csrf},
            )
            assert r_revoke_self.status_code == 200

        # 7. Verify expired API token returns 401
        raw_exp_tok: str = ""

        async def _mint_expired(sess: object) -> None:
            nonlocal raw_exp_tok
            from sqlalchemy.ext.asyncio import AsyncSession

            assert isinstance(sess, AsyncSession)
            uow = UnitOfWork(sess)
            admin = await uow.users.get_by_username("admin")
            assert admin is not None
            raw_exp_tok, rec = await mint_api_token(
                uow,
                user=admin,
                name="already-expired",
                scopes=["chat"],
            )
            rec.expires_at = datetime.now(UTC) - timedelta(minutes=5)

        await app.state.db.execute_write(_mint_expired)
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client2:
            r_exp = await client2.get(
                "/api/chats",
                headers={"Authorization": f"Bearer {raw_exp_tok}"},
            )
            assert r_exp.status_code == 401
            assert "expired" in r_exp.json()["detail"].lower()
