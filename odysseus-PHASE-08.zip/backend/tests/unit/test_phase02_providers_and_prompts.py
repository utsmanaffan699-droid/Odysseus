"""Unit & property tests for Phase 02: providers, capabilities, message tree, prompts, uploads."""

from __future__ import annotations

import io
import time
import zipfile
from decimal import Decimal
from pathlib import Path

import httpx
import pytest
from backend.core.crypto import EnvelopeVault
from backend.core.db import DatabaseManager
from backend.core.settings import Settings
from backend.domain.chats import (
    AttachmentService,
    AttachmentValidationError,
    MessageNode,
    PromptBuilder,
    PromptSectionBudget,
    build_highlighted_snippet,
    collect_subtree_ids,
    compute_active_path,
    find_default_leaf,
    next_branch_index,
    scan_bytes_clamav,
    sniff_mime_type,
    validate_tree_invariants,
)
from backend.providers.adapters import (
    AnthropicMessagesAdapter,
    GeminiAdapter,
    OpenAICompatibleAdapter,
)
from backend.providers.base import (
    ClassifiedProviderError,
    ProviderChatRequest,
    ProviderMessage,
    ProviderToolSpec,
    classify_provider_error,
    sanitize_stream_text,
    strict_json_loads,
)
from backend.providers.capabilities import (
    compute_cost_decimal,
    format_cost_usd,
    resolve_model_capabilities,
)
from backend.providers.fake import (
    FakeScript,
    FakeScriptStep,
    create_fake_openai_app,
)
from backend.providers.resilience import ResilientProviderRouter
from hypothesis import given, settings
from hypothesis import strategies as st
from PIL import Image
from pypdf import PdfWriter


def test_error_classification_all_nine_categories() -> None:
    """Verify classify_provider_error maps status codes and messages to all 9 categories."""
    e_auth = classify_provider_error(401, "Invalid API key", provider="openai")
    assert e_auth.category == "auth"
    assert e_auth.retryable is False

    e_rl = classify_provider_error(
        429, "Rate limit exceeded", {"Retry-After": "3.5"}, provider="openai"
    )
    assert e_rl.category == "rate_limit"
    assert e_rl.retryable is True
    assert e_rl.retry_after == 3.5

    e_ov = classify_provider_error(503, "Server overloaded", provider="anthropic")
    assert e_ov.category == "overloaded"
    assert e_ov.retryable is True

    e_ctx = classify_provider_error(400, "Maximum context length is 128000 tokens")
    assert e_ctx.category == "context_length"
    assert e_ctx.retryable is False

    e_cf = classify_provider_error(400, "Blocked by content_filter policy")
    assert e_cf.category == "content_filter"
    assert e_cf.retryable is False

    e_inv = classify_provider_error(422, "Invalid parameter temperature")
    assert e_inv.category == "invalid_request"
    assert e_inv.retryable is False

    e_net = classify_provider_error(None, "Connection reset by peer", is_network=True)
    assert e_net.category == "network"
    assert e_net.retryable is True

    e_to = classify_provider_error(None, "Read timed out", is_timeout=True)
    assert e_to.category == "timeout"
    assert e_to.retryable is True

    e_unk = classify_provider_error(418, "I am a teapot")
    assert e_unk.category == "unknown"


def test_strict_json_loads_and_sanitize() -> None:
    """Verify strict_json_loads rejects null bytes, duplicate keys, and oversized frames."""
    assert strict_json_loads('{"ok": 1}') == {"ok": 1}
    assert sanitize_stream_text("hello\x00world") == "helloworld"

    with pytest.raises(ClassifiedProviderError):
        strict_json_loads('{"a": 1, "a": 2}')

    with pytest.raises(ClassifiedProviderError):
        strict_json_loads('{"a": "\\u0000"}')

    with pytest.raises(ClassifiedProviderError):
        strict_json_loads('{"a": "' + ("x" * 200) + '"}', max_bytes=64)


def test_capabilities_resolution_and_decimal_cost() -> None:
    """Verify conservative local default (text_fenced), tri-state override, and Decimal cost."""
    local_caps = resolve_model_capabilities("ollama/llama3", is_local_v1=True)
    assert local_caps.tools == "text_fenced"
    assert local_caps.supports_json_mode is False

    forced_off = resolve_model_capabilities("openai/gpt-4o", supports_tools_override=False)
    assert forced_off.tools == "none"

    forced_on = resolve_model_capabilities(
        "ollama/llama3", is_local_v1=True, supports_tools_override=True
    )
    assert forced_on.tools == "native"

    gpt4o = resolve_model_capabilities("openai/gpt-4o")
    cost = compute_cost_decimal(
        gpt4o,
        input_tokens=100_000,
        output_tokens=50_000,
        cached_tokens=20_000,
        reasoning_tokens=10_000,
    )
    # Uncached in = 80k * $2.50/M = 0.20; Cached = 0.025; Out = 60k * $10/M = 0.60 => 0.825
    assert cost == Decimal("0.82500000")
    assert format_cost_usd(cost) == "0.82500000"


async def test_openai_anthropic_gemini_adapters_against_fake_http() -> None:
    """Contract-test OpenAI, Anthropic, and Gemini adapters against FakeProvider HTTP mode."""
    script = FakeScript(
        name="multi_adapter",
        model="fake/default",
        steps=[
            FakeScriptStep(kind="thinking", text="Let me think..."),
            FakeScriptStep(kind="text", text="Final answer."),
            FakeScriptStep(
                kind="tool_call",
                call_id="tc_99",
                tool_name="search_docs",
                args={"query": "odysseus"},
            ),
            FakeScriptStep(kind="usage", input_tokens=25, output_tokens=15, cached_tokens=5),
        ],
    )
    fake_app = create_fake_openai_app(script)
    transport = httpx.ASGITransport(app=fake_app)

    req = ProviderChatRequest(
        model="fake/default",
        messages=[
            ProviderMessage(role="system", content="Be concise."),
            ProviderMessage(role="user", content="Search odysseus"),
        ],
        tools=[
            ProviderToolSpec(
                name="search_docs",
                description="Search documentation",
                parameters={"type": "object", "properties": {"query": {"type": "string"}}},
            )
        ],
        thinking_enabled=True,
    )

    # 1. OpenAI-compatible adapter
    oai = OpenAICompatibleAdapter(
        base_url="http://fake.local", api_key="sk-test", transport=transport
    )
    oai_events = [ev async for ev in oai.stream_chat(req)]
    assert any(e.type == "thinking_delta" and "think" in e.text for e in oai_events)
    assert any(e.type == "text_delta" and "Final answer." in e.text for e in oai_events)
    assert any(e.type == "tool_call_end" and e.tool_name == "search_docs" for e in oai_events)
    assert any(e.type == "usage" and e.input_tokens == 25 for e in oai_events)

    # 2. Anthropic Messages adapter
    anth = AnthropicMessagesAdapter(
        base_url="http://fake.local", api_key="sk-ant-test", transport=transport
    )
    anth_events = [ev async for ev in anth.stream_chat(req)]
    assert any(e.type == "thinking_delta" for e in anth_events)
    assert any(e.type == "text_delta" and "Final answer." in e.text for e in anth_events)
    assert any(e.type == "tool_call_end" and e.tool_name == "search_docs" for e in anth_events)

    # 3. Google Gemini adapter
    gem = GeminiAdapter(base_url="http://fake.local", api_key="gem-key", transport=transport)
    gem_events = [ev async for ev in gem.stream_chat(req)]
    assert any(e.type == "thinking_delta" for e in gem_events)
    assert any(e.type == "text_delta" and "Final answer." in e.text for e in gem_events)
    assert any(e.type == "tool_call_end" and e.tool_name == "search_docs" for e in gem_events)


async def test_openai_text_fenced_tool_parsing() -> None:
    """Verify local text_fenced tool call extraction when native tool calling is unavailable."""
    fenced_script = FakeScript(
        name="fenced",
        model="local/llama",
        steps=[
            FakeScriptStep(
                kind="text",
                text='Sure!\n```tool_call\n{"name": "calc", "arguments": {"expr": "2+2"}}\n```',
            ),
        ],
    )
    fake_app = create_fake_openai_app(fenced_script)
    transport = httpx.ASGITransport(app=fake_app)
    adapter = OpenAICompatibleAdapter(
        base_url="http://fake.local",
        tools_mode="text_fenced",
        transport=transport,
    )
    req = ProviderChatRequest(
        model="local/llama",
        messages=[ProviderMessage(role="user", content="Calculate 2+2")],
        tools=[ProviderToolSpec(name="calc", description="Calculator", parameters={})],
    )
    events = [ev async for ev in adapter.stream_chat(req)]
    assert any(e.type == "tool_call_end" and e.tool_name == "calc" for e in events)


def test_prompt_builder_golden_ordering_and_budgets() -> None:
    """Golden test verifying PromptBuilder deterministic section ordering and budgets."""
    budgets = PromptSectionBudget(
        system_tokens=50,
        project_tokens=20,
        summary_tokens=30,
        attachments_tokens=40,
        history_tokens=25,
    )
    builder = PromptBuilder(budgets)
    built = builder.build(
        base_system_prompt="You are Odysseus.",
        project_name="Apollo",
        project_instructions=(
            "Always answer in rigorous markdown with citations when possible. " * 5
        ),
        chat_summary="User asked about orbital mechanics.",
        attachments=[
            {
                "sha256": "bbb",
                "filename": "second.txt",
                "mime_type": "text/plain",
                "extracted_text": "Second attachment content",
            },
            {
                "sha256": "aaa",
                "filename": "first.txt",
                "mime_type": "text/plain",
                "extracted_text": "First attachment content",
            },
        ],
        history=[
            {"role": "user", "content": "Old message 1 " * 20},
            {"role": "assistant", "content": "Old reply 1 " * 20},
            {"role": "user", "content": "Latest question?"},
        ],
    )
    assert len(built.messages) == 2
    sys_msg = built.messages[0].content
    # Deterministic section order check
    idx_sys = sys_msg.index("[SYSTEM INSTRUCTIONS]")
    idx_proj = sys_msg.index("[PROJECT INSTRUCTIONS: Apollo]")
    idx_sum = sys_msg.index("[CONVERSATION SUMMARY]")
    idx_att = sys_msg.index("[ATTACHMENTS]")
    assert idx_sys < idx_proj < idx_sum < idx_att
    # Attachments sorted by sha256 ("aaa" before "bbb")
    assert sys_msg.index("first.txt") < sys_msg.index("second.txt")
    # Project and history were truncated to fit their budgets, latest user message preserved
    assert "project" in built.truncated_sections
    assert "history" in built.truncated_sections
    assert built.messages[-1].content == "Latest question?"


def test_message_tree_10k_nodes_benchmark() -> None:
    """Benchmark compute_active_path and validate_tree_invariants on a 10,000-node tree."""
    nodes: dict[str, MessageNode] = {}
    prev_id: str | None = None
    leaf_id = ""
    for i in range(10_000):
        nid = f"m_{i}"
        # Create occasional branches while growing a deep spine
        parent = prev_id if (i % 5 != 0 or prev_id is None) else f"m_{max(0, i - 3)}"
        b_idx = 0 if parent == prev_id else (i % 4) + 1
        nodes[nid] = MessageNode(
            id=nid,
            chat_id="c_bench",
            parent_id=parent,
            branch_index=b_idx,
            role="user" if i % 2 == 0 else "assistant",
            content=f"msg {i}",
        )
        if parent == prev_id:
            prev_id = nid
            leaf_id = nid

    t0 = time.perf_counter()
    path = compute_active_path(nodes, leaf_id)
    elapsed_ms = (time.perf_counter() - t0) * 1000.0
    assert len(path) >= 8_000
    assert path[0].parent_id is None
    assert path[-1].id == leaf_id
    assert elapsed_ms < 50.0


@settings(max_examples=50, deadline=None)
@given(
    ops=st.lists(
        st.tuples(
            st.sampled_from(["append_leaf", "branch_random", "switch_leaf", "delete_sub"]),
            st.integers(min_value=0, max_value=100),
        ),
        min_size=1,
        max_size=40,
    )
)
def test_message_tree_hypothesis_invariants(ops: list[tuple[str, int]]) -> None:
    """Property test: arbitrary append, branch, switch, and delete preserve tree invariants."""
    nodes: dict[str, MessageNode] = {}
    active_leaf: str | None = None
    seq = 0

    for op, seed in ops:
        seq += 1
        nid = f"n_{seq}"
        if op == "append_leaf" or not nodes:
            b_idx = next_branch_index(nodes, active_leaf)
            nodes[nid] = MessageNode(
                id=nid,
                chat_id="c1",
                parent_id=active_leaf,
                branch_index=b_idx,
                role="user",
                content=f"text {seq}",
            )
            active_leaf = nid
        elif op == "branch_random":
            keys = sorted(nodes.keys())
            parent_node = nodes[keys[seed % len(keys)]]
            b_idx = next_branch_index(nodes, parent_node.id)
            nodes[nid] = MessageNode(
                id=nid,
                chat_id="c1",
                parent_id=parent_node.id,
                branch_index=b_idx,
                role="user",
                content=f"branch {seq}",
            )
            active_leaf = nid
        elif op == "switch_leaf":
            keys = sorted(nodes.keys())
            target = keys[seed % len(keys)]
            active_leaf = find_default_leaf(nodes, target)
        elif op == "delete_sub" and len(nodes) > 1:
            keys = sorted(nodes.keys())
            target = keys[seed % len(keys)]
            target_parent = nodes[target].parent_id
            to_del = collect_subtree_ids(nodes, target)
            for did in to_del:
                nodes.pop(did, None)
            if active_leaf in to_del:
                if target_parent and target_parent in nodes:
                    active_leaf = find_default_leaf(nodes, target_parent)
                elif nodes:
                    roots = [n for n in nodes.values() if n.parent_id is None]
                    roots.sort(key=lambda n: n.branch_index)
                    active_leaf = find_default_leaf(nodes, roots[-1].id)
                else:
                    active_leaf = None

        validate_tree_invariants(nodes, active_leaf)


async def test_attachments_pipeline_pdf_image_docx_and_clamav(tmp_path: Path) -> None:
    """Verify chunked upload, PDF extraction, image thumbnail, DOCX parsing, and ClamAV."""
    cfg = Settings(
        environment="development",
        data_dir=tmp_path / "data",
        logs_dir=tmp_path / "logs",
        database_url=f"sqlite+aiosqlite:///{tmp_path / 'att.db'}",
        capture_raw_exchanges=True,
    )
    db = DatabaseManager(cfg)
    await db.create_schema_if_needed()

    # Create dummy user for FK
    from backend.core.auth import bootstrap_first_admin
    from backend.core.uow import UnitOfWork

    user_id = ""

    async def _boot(sess: object) -> None:
        nonlocal user_id
        from sqlalchemy.ext.asyncio import AsyncSession

        assert isinstance(sess, AsyncSession)
        uow = UnitOfWork(sess)
        res = await bootstrap_first_admin(uow, cfg)
        u = await uow.users.get_by_username(res.username)
        assert u is not None
        user_id = u.id

    await db.execute_write(_boot)
    svc = AttachmentService(db, cfg, storage_root=tmp_path / "att_store")

    # 1. Image upload -> PNG thumbnail + dimensions
    img_buf = io.BytesIO()
    Image.new("RGB", (64, 48), color=(20, 40, 80)).save(img_buf, format="PNG")
    img_bytes = img_buf.getvalue()
    assert sniff_mime_type(img_bytes, "pic.png") == "image/png"
    res_img = await svc.store_bytes(user_id=user_id, filename="pic.png", data=img_bytes)
    assert res_img["mime_type"] == "image/png"
    assert res_img["metadata"]["width"] == 64

    # 2. PDF upload -> pypdf extraction
    pdf_buf = io.BytesIO()
    writer = PdfWriter()
    writer.add_blank_page(width=200, height=200)
    writer.write(pdf_buf)
    pdf_bytes = pdf_buf.getvalue()
    assert sniff_mime_type(pdf_bytes, "doc.pdf") == "application/pdf"
    res_pdf = await svc.store_bytes(user_id=user_id, filename="doc.pdf", data=pdf_bytes)
    assert res_pdf["mime_type"] == "application/pdf"
    assert res_pdf["metadata"]["page_count"] == 1

    # 3. DOCX upload -> XML text extraction
    docx_buf = io.BytesIO()
    with zipfile.ZipFile(docx_buf, "w") as zf:
        zf.writestr(
            "word/document.xml",
            "<w:document xmlns:w='http://schemas.openxmlformats.org/wordprocessingml/2006/main'>"
            "<w:body><w:p><w:t>Hello from DOCX</w:t></w:p></w:body></w:document>",
        )
    docx_bytes = docx_buf.getvalue()
    res_docx = await svc.store_bytes(user_id=user_id, filename="notes.docx", data=docx_bytes)
    assert "Hello from DOCX" in (res_docx["extracted_text"] or "")

    # 4. Chunked/resumable upload session
    payload = b"Chunk 1 data -- " + b"Chunk 2 data!"
    sess_info = await svc.start_upload_session(
        user_id=user_id, filename="chunked.txt", total_bytes=len(payload)
    )
    uid = sess_info["upload_id"]
    p1 = await svc.append_upload_chunk(upload_id=uid, user_id=user_id, chunk=payload[:16], offset=0)
    assert p1["status"] == "open"
    p2 = await svc.append_upload_chunk(
        upload_id=uid, user_id=user_id, chunk=payload[16:], offset=16, finalize=True
    )
    assert p2["status"] == "completed"
    assert p2["extracted_text"] == payload.decode("utf-8")

    # 5. EICAR virus signature rejected by ClamAV hook
    eicar = b"X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*"
    ok, sig = scan_bytes_clamav(eicar, enabled=True)
    assert not ok and sig == "Eicar-Test-Signature"
    with pytest.raises(AttachmentValidationError):
        await svc.store_bytes(user_id=user_id, filename="bad.bin", data=eicar)

    # 6. Dev-mode encrypted raw exchange capture
    vault = EnvelopeVault(cfg.data_dir, master_key_override="a" * 64)
    router = ResilientProviderRouter(cfg, db=db, vault=vault)
    events = [
        ev
        async for ev in router.stream_with_resilience(
            ProviderChatRequest(
                model="fake/default",
                messages=[ProviderMessage(role="user", content="test capture")],
                run_id="r_cap_1",
            )
        )
    ]
    assert events

    # 7. Highlighted search snippet
    snippet = build_highlighted_snippet(
        "Odysseus provides durable streaming runs with SQLite WAL.", "durable streaming"
    )
    assert "<mark>durable</mark>" in snippet
    assert "<mark>streaming</mark>" in snippet
    await db.dispose()

    await db.dispose()
