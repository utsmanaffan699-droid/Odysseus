"""CLI entry point for `python -m providers.fake serve --script x.yaml`."""

from __future__ import annotations

from backend.providers.fake import (
    FakeHttpError,
    FakeProvider,
    FakeScript,
    FakeScriptStep,
    FakeStreamChunk,
    FakeStreamDisconnectedError,
    create_fake_openai_app,
    load_fake_script,
    main,
)

__all__ = [
    "FakeHttpError",
    "FakeProvider",
    "FakeScript",
    "FakeScriptStep",
    "FakeStreamChunk",
    "FakeStreamDisconnectedError",
    "create_fake_openai_app",
    "load_fake_script",
    "main",
]

if __name__ == "__main__":
    raise SystemExit(main())
