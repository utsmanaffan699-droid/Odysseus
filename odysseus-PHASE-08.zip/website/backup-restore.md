# Odysseus Backup & Restore Runbook (`website/backup-restore.md`)

## 1. Consistent Snapshot Contents
Every Odysseus backup archive (`odysseus-backup-<id>.zip` or `.enc`) captures a consistent snapshot of:
- **Database**: Users, privileges, chats, message trees, runs, documents, notes, todos, calendars, schedules, memories, settings, mail cache metadata, and gallery records.
- **Manifest & Checksums (`manifest.json`)**: Per-section SHA-256 digests, entity counts (`users`, `chats`, `documents`, `memories`, `settings`, `mail_messages`, `gallery_items`), schema version, and overall HMAC/SHA-256 archive signature.
- **Secrets Key Handling**: Vault ciphertexts remain envelope-encrypted under `data/master.key`. Operators may optionally supply a backup `passphrase` which encrypts the archive payload via PBKDF2-HMAC-SHA256 + AES-256-GCM.

## 2. Creating a Backup
- **UI**: Navigate to **Admin Console → Backups & Restore** (`FE-ADMIN-08`) and click **Create Snapshot**.
- **API**: `POST /api/admin/backups` with `{"label": "pre-upgrade", "passphrase": "..."}`.

## 3. Restore Dry-Run & Clean-Instance Restore
1. **Verify Checksum**: `POST /api/admin/backups/{backup_id}/verify` checks every entry digest in `manifest.json` and rejects tampered archives (`checksum_mismatch`).
2. **Dry-Run Preview**: `POST /api/admin/backups/{backup_id}/restore` with `{"dry_run": true, "passphrase": "..."}` returns the exact diff (`entity_counts_to_restore`) without mutating state.
3. **Execute Restore**: `POST /api/admin/backups/{backup_id}/restore` with `{"dry_run": false, "passphrase": "..."}` atomically restores all collections and verifies post-restore counts match the dry-run preview.
