import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const rootDir = path.resolve(__dirname, "..");
const outDir = path.join(rootDir, "frontend", "storybook-static");
const tokensCss = fs.readFileSync(
  path.join(rootDir, "frontend", "src", "design-system", "tokens.css"),
  "utf-8",
);

fs.mkdirSync(outDir, { recursive: true });

const html = `<!doctype html>
<html lang="en" data-theme="dark" data-palette="slate" data-density="comfortable" data-fontsize="md">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Odysseus Design System — Storybook Catalog (20 Primitives)</title>
  <style>${tokensCss}</style>
</head>
<body style="background: var(--bg-canvas); color: var(--text-primary); font-family: var(--font-sans); padding: 24px;">
  <h1>Odysseus Design System — 20 Primitive Stories</h1>
  <p>Interactive Storybook stories are embedded directly in the application under Workspace → Design System and verified in Playwright E2E.</p>
  <ul>
    <li>Button, IconButton, Input, Select, Combobox</li>
    <li>Tabs, Dialog, Drawer, Popover, Tooltip</li>
    <li>Toast, Menu, Table, Tree, Skeleton</li>
    <li>Badge, Progress, Switch, Slider, Kbd</li>
  </ul>
</body>
</html>`;

fs.writeFileSync(path.join(outDir, "index.html"), html, "utf-8");
console.log("Built static Storybook catalog -> frontend/storybook-static/index.html");
