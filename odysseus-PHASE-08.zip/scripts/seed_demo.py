#!/usr/bin/env python3
"""Optional demo data seeder for Odysseus (`scripts/seed_demo.py`).

Populates sample data across Chat, Cookbook, Gallery, Voice, and Admin Console
for interactive walkthroughs or demo recordings. Never imported automatically
by production application startup.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from backend.domain.admin_ops.service import AdminOpsService  # noqa: E402
from backend.domain.cookbook.service import CookbookService  # noqa: E402
from backend.domain.gallery.service import GalleryService  # noqa: E402
from backend.domain.voice.service import VoiceService  # noqa: E402


def seed_demo_environment() -> dict[str, object]:
    """Seed deterministic demo records across Cookbook, Gallery, Voice, and Admin."""
    cookbook = CookbookService()
    gallery = GalleryService()
    voice = VoiceService()
    admin = AdminOpsService()

    dl = cookbook.start_download(
        model_id="Qwen/Qwen2.5-7B-Instruct-GGUF",
        filename="qwen2.5-7b-instruct-q5_k_m.gguf",
        total_bytes=5_368_709_120,
    )
    img_job = gallery.generate_image(
        prompt="Isometric local AI workstation with glowing GPU telemetry",
        width=1024,
        height=1024,
    )
    vsess = voice.create_session()
    backup = admin.create_backup()

    return {
        "seeded": True,
        "cookbook_download_id": dl["id"],
        "gallery_media_id": img_job["media_id"],
        "voice_session_id": vsess["id"],
        "backup_id": backup["backup_id"],
    }


if __name__ == "__main__":
    summary = seed_demo_environment()
    sys.stdout.write(json.dumps(summary, indent=2) + "\n")
