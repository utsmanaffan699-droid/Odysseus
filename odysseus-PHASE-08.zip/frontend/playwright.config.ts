import fs from "node:fs";
import { defineConfig } from "@playwright/test";

const customPath =
  process.env.PLAYWRIGHT_CHROMIUM_PATH ??
  (fs.existsSync("/usr/bin/chromium") ? "/usr/bin/chromium" : undefined);

export default defineConfig({
  testDir: "./e2e",
  timeout: 30000,
  fullyParallel: false,
  workers: 1,
  use: {
    baseURL: process.env.PLAYWRIGHT_BASE_URL ?? "http://127.0.0.1:8015",
    headless: true,
    launchOptions: {
      ...(customPath ? { executablePath: customPath } : {}),
      args: ["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage"],
    },
  },
});
