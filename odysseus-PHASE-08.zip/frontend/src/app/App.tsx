import React, { Suspense, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { ToastRegion } from "../design-system/primitives";
import { RunHistoryAndPresetsModal } from "../features/agent/RunHistoryAndPresetsView";
import { AgentTimeline } from "../features/agent/timeline/AgentTimeline";
import {
  type ArtifactItem,
  ArtifactsCanvasPanel,
} from "../features/artifacts/ArtifactsCanvasPanel";
import { ChatComposer } from "../features/composer/ChatComposer";
import { VirtualizedMessageList } from "../features/messages/VirtualizedMessageList";
import { AppSidebar } from "../features/shell/AppSidebar";
import { AppTopBar } from "../features/shell/AppTopBar";
import {
  CommandPaletteModal,
  ProjectsManagerView,
  RouteErrorBoundary,
  ShortcutsOverlayModal,
} from "../features/shell/ShellOverlays";
import { setAppLocale, type SupportedLocale } from "../i18n";
import { sharedCrossTabBus } from "../lib/broadcast";
import {
  type ChatDetailResponse,
  type ChatMessageNode,
  type ChatSummaryItem,
  OdysseusApiClient,
  type ProjectItem,
  type ProviderModelCapability,
} from "../lib/contracts/api.gen";
import type { RunEventEnvelope } from "../lib/contracts/events.gen";
import { installGlobalDiagnosticsListeners } from "../lib/diagnostics";
import { odysseusQueryClient } from "../lib/queryClient";
import { reduceRunState, type RunViewState } from "../lib/runReducer";
import { SseStreamClient } from "../lib/sse";
import { useAppShellStore } from "../lib/store";

const LazyStorybookCatalog = React.lazy(async () => {
  const mod = await import("../design-system/StorybookCatalog");
  return { default: mod.StorybookCatalog };
});

const LazyKnowledgeWorkspacesView = React.lazy(async () => {
  const mod = await import("../features/knowledge/KnowledgeWorkspacesView");
  return { default: mod.KnowledgeWorkspacesView };
});

const LazyProductivityWorkspacesView = React.lazy(async () => {
  const mod = await import("../features/productivity/ProductivityWorkspacesView");
  return { default: mod.ProductivityWorkspacesView };
});

const LazyLocalMediaAdminWorkspacesView = React.lazy(async () => {
  const mod = await import("../features/local-media-admin/LocalMediaAdminWorkspacesView");
  return { default: mod.LocalMediaAdminWorkspacesView };
});

const LazySettingsAndProvidersView = React.lazy(async () => {
  const mod = await import("../features/settings/SettingsAndProvidersView");
  return { default: mod.SettingsAndProvidersView };
});

function parseDeepLinkFromLocation(): {
  chatId: string | null;
  messageId: string | null;
  runId: string | null;
} {
  if (typeof window === "undefined") {
    return { chatId: null, messageId: null, runId: null };
  }
  const pathMatch = /^\/c\/([A-Za-z0-9_-]+)/.exec(window.location.pathname);
  const runPathMatch = /^\/runs\/([A-Za-z0-9_-]+)/.exec(window.location.pathname);
  const params = new URLSearchParams(window.location.search);
  const hash = window.location.hash.replace(/^#/, "");
  const hashParams = new URLSearchParams(hash);

  const chatId = pathMatch?.[1] ?? params.get("chat") ?? hashParams.get("c") ?? null;
  const messageId = params.get("m") ?? hashParams.get("m") ?? null;
  const runId = runPathMatch?.[1] ?? params.get("run") ?? hashParams.get("run") ?? null;
  return { chatId, messageId, runId };
}

export function App(): React.ReactElement {
  const { t } = useTranslation();
  const {
    user,
    inspectorOpen,
    theme,
    palette,
    density,
    fontSize,
    locale,
    activeWorkspace,
    activeChatId,
    selectedModel,
    runsById,
    activeRunIdByChatId,
    commandPaletteOpen,
    shortcutsOpen,
    degradedServices,
    toasts,
    setUser,
    setLocale,
    setWorkspace,
    setActiveChatId,
    setSelectedModel,
    setConnectionStatus,
    setDegradedServices,
    applyRunEvent,
    setActiveRunForChat,
    setCommandPaletteOpen,
    setShortcutsOpen,
    addToast,
    dismissToast,
  } = useAppShellStore();

  const apiClient = useMemo(() => new OdysseusApiClient(""), []);
  const sseClientsRef = useRef<Map<string, SseStreamClient>>(new Map());
  const creatingChatPromiseRef = useRef<Promise<string> | null>(null);

  const [readyStatus, setReadyStatus] = useState<string>("ready");
  const [usernameInput, setUsernameInput] = useState("admin");
  const [passwordInput, setPasswordInput] = useState("");
  const [currentPasswordInput, setCurrentPasswordInput] = useState("");
  const [newPasswordInput, setNewPasswordInput] = useState("");
  const [authError, setAuthError] = useState<string | null>(null);

  const [chats, setChats] = useState<ReadonlyArray<ChatSummaryItem>>([]);
  const [projects, setProjects] = useState<ReadonlyArray<ProjectItem>>([]);
  const [capabilities, setCapabilities] = useState<ReadonlyArray<ProviderModelCapability>>([]);
  const [chatDetail, setChatDetail] = useState<ChatDetailResponse | null>(null);
  const [deepLinkMessageId, setDeepLinkMessageId] = useState<string | null>(null);

  // Phase 05: Event log per run, Artifacts Canvas state, and Agent Hub modal state
  const [eventsByRunId, setEventsByRunId] = useState<
    Record<string, ReadonlyArray<RunEventEnvelope>>
  >({});
  const [lastRunIdByChatId, setLastRunIdByChatId] = useState<
    Record<string, string>
  >({});
  const [artifactsList, setArtifactsList] = useState<ReadonlyArray<ArtifactItem>>([]);
  const [activeArtifactId, setActiveArtifactId] = useState<string | null>(null);
  const [artifactsPanelOpen, setArtifactsPanelOpen] = useState<boolean>(false);
  const [agentHubOpen, setAgentHubOpen] = useState<boolean>(false);
  const [agentHubTab, setAgentHubTab] = useState<"runs" | "presets" | "policies">("runs");
  const [syntheticRunState, setSyntheticRunState] = useState<RunViewState | null>(null);
  const [syntheticRunEvents, setSyntheticRunEvents] = useState<
    ReadonlyArray<RunEventEnvelope>
  >([]);

  // Sync theme, palette, density, font size to <html> root
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    document.documentElement.dataset.palette = palette;
    document.documentElement.dataset.density = density;
    document.documentElement.dataset.fontsize = fontSize;
  }, [theme, palette, density, fontSize]);

  // Install global diagnostics and PWA service worker
  useEffect(() => {
    const cleanupDiag = installGlobalDiagnosticsListeners();
    if ("serviceWorker" in navigator) {
      void navigator.serviceWorker.register("/sw.js").catch(() => {});
    }
    return cleanupDiag;
  }, []);

  const handleOpenRunView = useCallback(
    async (runId: string): Promise<void> => {
      if (!runId) return;
      setWorkspace("agents");
      window.history.replaceState(
        null,
        "",
        `/runs/${encodeURIComponent(runId)}${window.location.hash}`,
      );
      const existingEvents = eventsByRunId[runId];
      if (existingEvents && existingEvents.length > 0) {
        setSyntheticRunEvents(existingEvents);
        setSyntheticRunState(
          reduceRunState(existingEvents, undefined, { ignoreDuplicates: true }),
        );
        return;
      }
      try {
        const trace = await apiClient.exportRunTrace(runId);
        const traceEvents = trace.events as ReadonlyArray<RunEventEnvelope>;
        if (traceEvents.length > 0) {
          setSyntheticRunEvents(traceEvents);
          setSyntheticRunState(
            reduceRunState(traceEvents, undefined, { ignoreDuplicates: true }),
          );
        }
      } catch {
        // Fallback if run trace is only in local reducer state
      }
    },
    [apiClient, eventsByRunId, setWorkspace],
  );

  // Parse deep link (`#m=<id>`, `?chat=<id>`, `/c/<id>`, `/runs/<id>`)
  useEffect(() => {
    const applyDeepLink = (): void => {
      const { chatId, messageId, runId } = parseDeepLinkFromLocation();
      if (chatId) {
        setActiveChatId(chatId);
      }
      if (messageId) {
        setDeepLinkMessageId(messageId);
      }
      if (runId) {
        void handleOpenRunView(runId);
      }
    };
    applyDeepLink();
    window.addEventListener("hashchange", applyDeepLink);
    window.addEventListener("popstate", applyDeepLink);
    return () => {
      window.removeEventListener("hashchange", applyDeepLink);
      window.removeEventListener("popstate", applyDeepLink);
    };
  }, [handleOpenRunView, setActiveChatId]);

  const refreshChats = useCallback(async (): Promise<ReadonlyArray<ChatSummaryItem>> => {
    try {
      const list = await apiClient.listChats();
      odysseusQueryClient.setQueryData(["chats"], list);
      setChats(list);
      return list;
    } catch {
      return [];
    }
  }, [apiClient]);

  const refreshProjects = useCallback(async (): Promise<void> => {
    try {
      const list = await apiClient.listProjects();
      odysseusQueryClient.setQueryData(["projects"], list);
      setProjects(list);
    } catch {
      // Ignore
    }
  }, [apiClient]);

  const refreshCapabilities = useCallback(async (): Promise<void> => {
    try {
      const res = await apiClient.getProviderCapabilities();
      odysseusQueryClient.setQueryData(["capabilities"], res.models);
      setCapabilities(res.models);
    } catch {
      // Ignore
    }
  }, [apiClient]);

  const loadChatDetail = useCallback(
    async (chatId: string): Promise<ChatDetailResponse | null> => {
      try {
        const detail = await apiClient.getChat(chatId);
        odysseusQueryClient.setQueryData(["chat", chatId], detail);
        setChatDetail(detail);
        return detail;
      } catch {
        return null;
      }
    },
    [apiClient],
  );

  // Connect SSE stream for a run (idempotent, supports mid-stream resume with after=<cursor>)
  const connectRunStream = useCallback(
    (chatId: string, runId: string, initialCursor = 0): void => {
      if (sseClientsRef.current.has(runId)) {
        return;
      }
      setActiveRunForChat(chatId, runId);
      setLastRunIdByChatId((prev) => ({ ...prev, [chatId]: runId }));
      try {
        sessionStorage.setItem(`odysseus_active_run_${chatId}`, runId);
      } catch {
        // Ignore storage quota
      }

      const existingRun = useAppShellStore.getState().runsById[runId];
      const startCursor = Math.max(initialCursor, existingRun?.last_seq ?? 0);

      const client = new SseStreamClient({
        url: `/api/runs/${encodeURIComponent(runId)}/events`,
        initialCursor: startCursor,
        onStatusChange: (st) => {
          if (st === "connected") {
            setConnectionStatus("connected");
          } else if (st === "reconnecting") {
            setConnectionStatus("reconnecting");
          } else if (st === "offline") {
            setConnectionStatus("offline");
          }
        },
        onEvent: (ev: RunEventEnvelope) => {
          applyRunEvent(chatId, ev, true);
          setEventsByRunId((prev) => {
            const list = prev[runId] ?? [];
            if (list.some((item) => item.seq === ev.seq)) return prev;
            return { ...prev, [runId]: [...list, ev] };
          });

          if (ev.type === "run.finished" || ev.type === "run.error") {
            sseClientsRef.current.delete(runId);
            try {
              sessionStorage.removeItem(`odysseus_active_run_${chatId}`);
            } catch {
              // Ignore
            }
            void loadChatDetail(chatId);
            void refreshChats();
          }
        },
      });

      sseClientsRef.current.set(runId, client);
      void client.start();
    },
    [applyRunEvent, loadChatDetail, refreshChats, setActiveRunForChat, setConnectionStatus],
  );

  // Cross-tab BroadcastChannel listener for terminal events (Acceptance #4)
  useEffect(() => {
    const unsub = sharedCrossTabBus.subscribe((msg) => {
      if (msg.type === "run_event") {
        if (
          (msg.event.type === "run.finished" || msg.event.type === "run.error") &&
          msg.chatId === activeChatId
        ) {
          void loadChatDetail(msg.chatId);
          void refreshChats();
        }
      }
    });
    return unsub;
  }, [activeChatId, loadChatDetail, refreshChats]);

  // Network online/offline listeners (Acceptance #8)
  useEffect(() => {
    const onOffline = (): void => setConnectionStatus("offline");
    const onOnline = (): void => {
      setConnectionStatus("connected");
      for (const client of sseClientsRef.current.values()) {
        client.retryNow();
      }
    };
    window.addEventListener("offline", onOffline);
    window.addEventListener("online", onOnline);
    return () => {
      window.removeEventListener("offline", onOffline);
      window.removeEventListener("online", onOnline);
    };
  }, [setConnectionStatus]);

  // Global keyboard shortcuts (`Ctrl/Cmd+K`, `?`, `/`, `Esc`)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent): void => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setCommandPaletteOpen(!commandPaletteOpen);
        return;
      }

      const activeEl = document.activeElement;
      const inInput =
        activeEl instanceof HTMLInputElement ||
        activeEl instanceof HTMLTextAreaElement ||
        activeEl instanceof HTMLSelectElement;

      if (!inInput && e.key === "?") {
        e.preventDefault();
        setShortcutsOpen(!shortcutsOpen);
        return;
      }

      if (!inInput && e.key === "/") {
        e.preventDefault();
        document.getElementById("chat-composer-textarea")?.focus();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [commandPaletteOpen, setCommandPaletteOpen, setShortcutsOpen, shortcutsOpen]);

  // Initial health + auth bootstrap
  useEffect(() => {
    let active = true;
    void apiClient
      .getHealthReady()
      .then((res) => {
        if (active) setReadyStatus(res.status);
      })
      .catch(() => {
        if (active) setReadyStatus("degraded");
      });

    void apiClient
      .getHealthDegraded()
      .then((res) => {
        if (active) setDegradedServices(res.services);
      })
      .catch(() => {});

    void apiClient
      .getMe()
      .then((profile) => {
        if (active) {
          setUser(profile, profile.csrf_token ?? null);
        }
      })
      .catch(() => {
        if (active) {
          setUser(null, null);
        }
      });

    return () => {
      active = false;
    };
  }, [apiClient, setDegradedServices, setUser]);

  // Load workspace data once authenticated
  useEffect(() => {
    if (!user || user.must_change_password) return;
    void refreshChats().then((list) => {
      const currentChatId = useAppShellStore.getState().activeChatId;
      if (!currentChatId && !creatingChatPromiseRef.current && list.length > 0) {
        setActiveChatId(list[0]!.id);
      }
    });
    void refreshProjects();
    void refreshCapabilities();
  }, [user, refreshCapabilities, refreshChats, refreshProjects, setActiveChatId]);

  // Load active chat detail and resume any in-progress streaming run (Acceptance #4 & #5)
  useEffect(() => {
    if (!user || user.must_change_password || !activeChatId) return;
    let active = true;
    void loadChatDetail(activeChatId).then(async (detail) => {
      if (!active || !detail) return;

      // Deep-link branch auto-activation (#m=<msgId>)
      if (deepLinkMessageId) {
        const onActive = detail.messages.some((m) => m.id === deepLinkMessageId);
        const inAll = (detail.all_messages ?? []).some((m) => m.id === deepLinkMessageId);
        if (!onActive && inAll) {
          const updated = await apiClient.activateBranch(activeChatId, deepLinkMessageId);
          if (active) setChatDetail(updated);
        }
      }

      // Check if there is an active streaming run to resume after reload
      let resumeRunId: string | null = null;
      try {
        resumeRunId = sessionStorage.getItem(`odysseus_active_run_${activeChatId}`);
      } catch {
        resumeRunId = null;
      }
      if (!resumeRunId) {
        const streamingMsg = detail.messages.find(
          (m) => m.status === "streaming" && typeof m.run_id === "string" && m.run_id.length > 0,
        );
        if (streamingMsg?.run_id) {
          resumeRunId = streamingMsg.run_id;
        }
      }
      if (resumeRunId) {
        connectRunStream(activeChatId, resumeRunId, 0);
      }
    });
    return () => {
      active = false;
    };
  }, [user, activeChatId, apiClient, connectRunStream, deepLinkMessageId, loadChatDetail]);

  const toggleLanguage = (): void => {
    const nextLocale: SupportedLocale = locale === "en" ? "id" : "en";
    setLocale(nextLocale);
    void setAppLocale(nextLocale);
  };

  const handleLoginSubmit = async (e: React.FormEvent): Promise<void> => {
    e.preventDefault();
    setAuthError(null);
    try {
      const res = await apiClient.login(usernameInput, passwordInput);
      setUser(res.user, res.csrf_token);
      setPasswordInput("");
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : "Login failed");
    }
  };

  const handlePasswordChangeSubmit = async (e: React.FormEvent): Promise<void> => {
    e.preventDefault();
    setAuthError(null);
    try {
      await apiClient.changePassword(currentPasswordInput, newPasswordInput);
      const updatedProfile = await apiClient.getMe();
      setUser(updatedProfile, apiClient.getCsrfToken());
      setCurrentPasswordInput("");
      setNewPasswordInput("");
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : "Password change failed");
    }
  };

  const handleLogout = async (): Promise<void> => {
    await apiClient.logout();
    setUser(null, null);
  };

  const handleNewChat = async (temporary = false, projectId: string | null = null): Promise<void> => {
    setActiveChatId(null);
    setChatDetail(null);
    setWorkspace("chat");
    const createPromise = (async () => {
      const created = await apiClient.createChat({
        title: temporary ? "Temporary Chat" : "New Chat",
        model: useAppShellStore.getState().selectedModel,
        temporary,
        project_id: projectId,
      });
      setActiveChatId(created.id);
      await refreshChats();
      await loadChatDetail(created.id);
      return created.id;
    })();
    creatingChatPromiseRef.current = createPromise;
    try {
      await createPromise;
    } finally {
      if (creatingChatPromiseRef.current === createPromise) {
        creatingChatPromiseRef.current = null;
      }
    }
  };

  const handleSendMessage = async (
    content: string,
    attachmentShas: ReadonlyArray<string>,
    thinkingEnabled: boolean,
  ): Promise<void> => {
    if (creatingChatPromiseRef.current) {
      await creatingChatPromiseRef.current;
    }
    let targetChatId = useAppShellStore.getState().activeChatId;
    if (!targetChatId) {
      const created = await apiClient.createChat({
        title: content.slice(0, 48) || "New Chat",
        model: useAppShellStore.getState().selectedModel,
      });
      targetChatId = created.id;
      setActiveChatId(targetChatId);
      await refreshChats();
    }

    const activeLeafId =
      chatDetail && chatDetail.id === targetChatId ? chatDetail.active_leaf_id ?? null : null;

    const res = await apiClient.sendMessage(targetChatId, {
      content,
      parent_id: activeLeafId ?? "__active_leaf__",
      model: useAppShellStore.getState().selectedModel,
      thinking_enabled: thinkingEnabled,
      attachment_ids: attachmentShas,
    });

    connectRunStream(targetChatId, res.run.id, 0);
    await loadChatDetail(targetChatId);
    await refreshChats();
  };

  const handleEditMessage = async (messageId: string, newContent: string): Promise<void> => {
    const cid = useAppShellStore.getState().activeChatId;
    if (!cid) return;
    const res = await apiClient.editMessage(cid, messageId, {
      content: newContent,
      model: useAppShellStore.getState().selectedModel,
    });
    connectRunStream(cid, res.run.id, 0);
    await loadChatDetail(cid);
  };

  const handleRegenerateMessage = async (messageId: string): Promise<void> => {
    const cid = useAppShellStore.getState().activeChatId;
    if (!cid) return;
    const res = await apiClient.regenerateMessage(
      cid,
      messageId,
      useAppShellStore.getState().selectedModel,
    );
    connectRunStream(cid, res.run.id, 0);
    await loadChatDetail(cid);
  };

  const handleActivateBranch = async (messageId: string): Promise<void> => {
    const cid = useAppShellStore.getState().activeChatId;
    if (!cid) return;
    await apiClient.activateBranch(cid, messageId);
    await loadChatDetail(cid);
  };

  const handleForkChat = async (messageId: string): Promise<void> => {
    const cid = useAppShellStore.getState().activeChatId;
    if (!cid) return;
    const forked = await apiClient.forkChat(cid, messageId);
    await refreshChats();
    setActiveChatId(forked.id);
    await loadChatDetail(forked.id);
    addToast({ message: `Forked conversation "${forked.title}"`, variant: "success" });
  };

  const handleDeleteSubtree = async (messageId: string): Promise<void> => {
    const cid = useAppShellStore.getState().activeChatId;
    if (!cid) return;
    await apiClient.deleteMessageSubtree(cid, messageId);
    await loadChatDetail(cid);
  };

  const activeRunId = activeChatId
    ? activeRunIdByChatId[activeChatId] ?? lastRunIdByChatId[activeChatId] ?? null
    : null;
  const activeRun = activeRunId ? runsById[activeRunId] ?? null : null;
  const activeRunEvents: ReadonlyArray<RunEventEnvelope> = useMemo(
    () => (activeRunId ? eventsByRunId[activeRunId] ?? [] : []),
    [activeRunId, eventsByRunId],
  );
  const isRunning =
    activeRun !== null &&
    (activeRun.status === "running" ||
      activeRun.status === "queued" ||
      activeRun.status === "waiting_approval");

  const runningRunsCount = useMemo(
    () =>
      Object.values(runsById).filter(
        (r) => r.status === "running" || r.status === "waiting_approval",
      ).length,
    [runsById],
  );

  const pendingApprovalsCount = useMemo(() => {
    let count = 0;
    for (const r of Object.values(runsById)) {
      count += Object.values(r.approvals).filter(
        (a) => a.status === "pending",
      ).length;
    }
    return count;
  }, [runsById]);

  // Sync artifacts streamed from activeRun into artifactsList
  useEffect(() => {
    if (!activeRun) return;
    const runArts = Object.values(activeRun.artifacts);
    if (runArts.length === 0) return;
    setArtifactsList((prev) => {
      const next = [...prev];
      for (const ra of runArts) {
        const existingIdx = next.findIndex((a) => a.id === ra.artifact_id);
        const verObj = {
          version: ra.version || 1,
          content: ra.content,
          summary: ra.summary || "Generated by agent",
          created_at: new Date().toISOString(),
          author: "agent" as const,
        };
        if (existingIdx < 0) {
          next.push({
            id: ra.artifact_id,
            title: ra.title || "artifact",
            type: (ra.type as ArtifactItem["type"]) || "code",
            latest_version: ra.version || 1,
            versions: [verObj],
          });
        } else {
          const cur = next[existingIdx]!;
          const updatedVers = [...cur.versions];
          const vIdx = updatedVers.findIndex((v) => v.version === verObj.version);
          if (vIdx >= 0) {
            updatedVers[vIdx] = verObj;
          } else {
            updatedVers.push(verObj);
          }
          next[existingIdx] = {
            ...cur,
            latest_version: Math.max(cur.latest_version, verObj.version),
            versions: updatedVers,
          };
        }
      }
      return next;
    });
    const firstArt = runArts[0];
    if (firstArt) {
      setActiveArtifactId((prev) => prev ?? firstArt.artifact_id);
      setArtifactsPanelOpen(true);
    }
  }, [activeRun]);

  const handleLoad2000StepsStress = useCallback(() => {
    const evs: RunEventEnvelope[] = [
      {
        seq: 1,
        run_id: "r_stress_2000",
        ts: "2026-10-03T00:00:00Z",
        type: "run.started",
        data: { model: "fake-gpt", budget: { max_iters: 2000 } },
      },
    ];
    let seq = 2;
    for (let i = 0; i < 2000; i += 1) {
      evs.push({
        seq: seq++,
        run_id: "r_stress_2000",
        ts: "2026-10-03T00:00:01Z",
        type: "tool.call.proposed",
        data: {
          call_id: `tc_2k_${i}`,
          name: "read_file",
          args: { path: `src/module_${i}.ts` },
          risk: "read",
        },
      });
      evs.push({
        seq: seq++,
        run_id: "r_stress_2000",
        ts: "2026-10-03T00:00:01Z",
        type: "tool.result",
        data: {
          call_id: `tc_2k_${i}`,
          ok: true,
          summary: `Read module_${i}.ts`,
          output_ref: `blob://tc_2k_${i}`,
          truncated: false,
          duration_ms: 2,
          render_hint: "text",
        },
      });
    }
    evs.push({
      seq: seq++,
      run_id: "r_stress_2000",
      ts: "2026-10-03T00:00:02Z",
      type: "run.finished",
      data: {
        reason: "completed",
        usage: { input: 20000, output: 5000, cached: 0, reasoning: 0, cost: 0.12 },
      },
    });
    setSyntheticRunEvents(evs);
    setSyntheticRunState(reduceRunState(evs));
  }, []);

  const handleLoadSubagentTree = useCallback(() => {
    const evs: RunEventEnvelope[] = [
      {
        seq: 1,
        run_id: "r_fixture_05_subagent",
        ts: "2026-10-03T00:00:00Z",
        type: "run.started",
        data: { model: "fake-gpt", budget: { max_iters: 10 } },
      },
      {
        seq: 2,
        run_id: "r_fixture_05_subagent",
        ts: "2026-10-03T00:00:01Z",
        type: "subagent.started",
        data: {
          child_run_id: "r_child_01",
          task: "Audit repository dependencies and licenses",
        },
      },
      {
        seq: 3,
        run_id: "r_fixture_05_subagent",
        ts: "2026-10-03T00:00:02Z",
        type: "subagent.finished",
        data: {
          child_run_id: "r_child_01",
          status: "completed",
          summary: "Verified 42 packages: 0 license violations.",
        },
      },
      {
        seq: 4,
        run_id: "r_fixture_05_subagent",
        ts: "2026-10-03T00:00:03Z",
        type: "context.compacted",
        data: { removed_tokens: 4096, summary_ref: "sum_01" },
      },
      {
        seq: 5,
        run_id: "r_fixture_05_subagent",
        ts: "2026-10-03T00:00:04Z",
        type: "run.finished",
        data: {
          reason: "completed",
          usage: { input: 1200, output: 400, cached: 200, reasoning: 100, cost: 0.02 },
        },
      },
    ];
    setSyntheticRunEvents(evs);
    setSyntheticRunState(reduceRunState(evs));
  }, []);

  const handleLoad50MbJsonTool = useCallback(() => {
    const sampleChunk = '{"id":101,"status":"ok","metrics":[1,2,3,4,5]},';
    const bigSlice = "[" + sampleChunk.repeat(8000) + "{}]";
    const evs: RunEventEnvelope[] = [
      {
        seq: 1,
        run_id: "r_50mb_json",
        ts: "2026-10-03T00:00:00Z",
        type: "run.started",
        data: { model: "fake-gpt", budget: { max_iters: 5 } },
      },
      {
        seq: 2,
        run_id: "r_50mb_json",
        ts: "2026-10-03T00:00:01Z",
        type: "tool.call.proposed",
        data: {
          call_id: "tc_50mb",
          name: "query_db",
          args: { sql: "SELECT * FROM telemetry_events LIMIT 1000000" },
          risk: "read",
        },
      },
      {
        seq: 3,
        run_id: "r_50mb_json",
        ts: "2026-10-03T00:00:02Z",
        type: "tool.output.delta",
        data: { call_id: "tc_50mb", stream: "stdout", text: bigSlice },
      },
      {
        seq: 4,
        run_id: "r_50mb_json",
        ts: "2026-10-03T00:00:03Z",
        type: "tool.result",
        data: {
          call_id: "tc_50mb",
          ok: true,
          summary: "Returned 50 MB JSON telemetry dataset",
          output_ref: "blob://tc_50mb",
          truncated: true,
          duration_ms: 48,
          render_hint: "json",
        },
      },
      {
        seq: 5,
        run_id: "r_50mb_json",
        ts: "2026-10-03T00:00:04Z",
        type: "run.finished",
        data: {
          reason: "completed",
          usage: { input: 500, output: 200, cached: 0, reasoning: 0, cost: 0.01 },
        },
      },
    ];
    setSyntheticRunEvents(evs);
    setSyntheticRunState(reduceRunState(evs));
  }, []);

  const handleOpenSandboxTestArtifact = useCallback(() => {
    const sandboxArt: ArtifactItem = {
      id: "art_sandbox_probe",
      title: "sandbox_probe.html",
      type: "html",
      latest_version: 1,
      versions: [
        {
          version: 1,
          summary: "Sandbox security probe",
          created_at: new Date().toISOString(),
          content: `<h3>Sandboxed Micro-App Probe</h3>
<script>
  try {
    var c = document.cookie;
    console.log("cookie_access:allowed:" + c);
  } catch (e) {
    console.error("cookie_access:blocked:" + e.name);
  }
  try {
    var p = window.parent.document.body;
    console.log("parent_dom:allowed");
  } catch (e) {
    console.error("parent_dom:blocked:" + e.name);
  }
  try {
    window["local" + "Storage"].getItem("x");
    console.log("local_storage:allowed");
  } catch (e) {
    console.error("local_storage:blocked:" + e.name);
  }
  fetch("https://example.com/exfil").then(function() {
    console.log("network_fetch:allowed");
  }).catch(function(err) {
    console.error("network_fetch:blocked:" + err.message);
  });
</script>`,
        },
      ],
    };
    setArtifactsList((prev) => {
      const filtered = prev.filter((a) => a.id !== sandboxArt.id);
      return [...filtered, sandboxArt];
    });
    setActiveArtifactId(sandboxArt.id);
    setArtifactsPanelOpen(true);
  }, []);

  const handleStopRun = async (): Promise<void> => {
    if (!activeRunId || !activeChatId) return;
    await apiClient.cancelRun(activeRunId);
    await loadChatDetail(activeChatId);
  };

  const handleSteerRun = async (text: string): Promise<void> => {
    if (!activeRunId) return;
    await apiClient.steerRun(activeRunId, text);
    addToast({ message: "Steer instruction injected into active run", variant: "info" });
  };

  const handleResolveApproval = async (
    approvalId: string,
    decision: "approve" | "deny",
    scope: "once" | "run" | "chat" | "always",
  ): Promise<void> => {
    await apiClient.resolveApproval(approvalId, decision, scope);
  };

  const activeModelCapability = useMemo(
    () => capabilities.find((c) => c.model === selectedModel),
    [capabilities, selectedModel],
  );

  const activeMessages: ReadonlyArray<ChatMessageNode> = chatDetail?.messages ?? [];
  const allMessages: ReadonlyArray<ChatMessageNode> = chatDetail?.all_messages ?? activeMessages;

  // Render Login or Forced Password Change screen when not authenticated
  if (!user || user.must_change_password) {
    return (
      <main className="odysseus-shell">
        <header className="odysseus-topbar">
          <div>
            <h1 className="odysseus-brand" data-testid="app-title">
              {t("appTitle")}
            </h1>
            <p className="odysseus-subtitle">{t("appSubtitle")}</p>
          </div>
          <div className="odysseus-topbar-right">
            <span className="odysseus-badge" data-testid="health-badge">
              {readyStatus === "ready" && degradedServices.length === 0
                ? t("statusReady")
                : t("statusDegraded")}
            </span>
            <button
              type="button"
              onClick={toggleLanguage}
              className="odysseus-btn odysseus-btn-secondary odysseus-btn-sm"
              data-testid="lang-toggle"
            >
              {t("languageSwitch")}: {locale.toUpperCase()}
            </button>
          </div>
        </header>

        <div className="odysseus-main">
          {authError ? (
            <div role="alert" className="odysseus-error" data-testid="error-banner">
              {authError}
            </div>
          ) : null}

          {!user ? (
            <section className="odysseus-card" aria-labelledby="login-heading">
              <h2 id="login-heading">{t("loginHeading")}</h2>
              <form
                onSubmit={(e) => void handleLoginSubmit(e)}
                className="odysseus-settings-grid"
                data-testid="login-form"
              >
                <div className="odysseus-field">
                  <label htmlFor="username-input" className="odysseus-label">
                    {t("usernameLabel")}
                  </label>
                  <input
                    id="username-input"
                    type="text"
                    className="odysseus-input"
                    autoComplete="username"
                    value={usernameInput}
                    onChange={(e) => setUsernameInput(e.target.value)}
                    required
                  />
                </div>
                <div className="odysseus-field">
                  <label htmlFor="password-input" className="odysseus-label">
                    {t("passwordLabel")}
                  </label>
                  <input
                    id="password-input"
                    type="password"
                    className="odysseus-input"
                    autoComplete="current-password"
                    value={passwordInput}
                    onChange={(e) => setPasswordInput(e.target.value)}
                    required
                  />
                </div>
                <div className="odysseus-row-wrap">
                  <button
                    type="submit"
                    className="odysseus-btn odysseus-btn-primary"
                    data-testid="login-submit"
                  >
                    {t("signInButton")}
                  </button>
                </div>
              </form>
            </section>
          ) : (
            <section className="odysseus-card" aria-labelledby="pw-change-heading">
              <h2 id="pw-change-heading">{t("changePasswordHeading")}</h2>
              <form
                onSubmit={(e) => void handlePasswordChangeSubmit(e)}
                className="odysseus-settings-grid"
                data-testid="password-change-form"
              >
                <div className="odysseus-field">
                  <label htmlFor="current-pw-input" className="odysseus-label">
                    {t("currentPasswordLabel")}
                  </label>
                  <input
                    id="current-pw-input"
                    type="password"
                    className="odysseus-input"
                    value={currentPasswordInput}
                    onChange={(e) => setCurrentPasswordInput(e.target.value)}
                    required
                  />
                </div>
                <div className="odysseus-field">
                  <label htmlFor="new-pw-input" className="odysseus-label">
                    {t("newPasswordLabel")}
                  </label>
                  <input
                    id="new-pw-input"
                    type="password"
                    className="odysseus-input"
                    value={newPasswordInput}
                    onChange={(e) => setNewPasswordInput(e.target.value)}
                    required
                  />
                </div>
                <div className="odysseus-row-wrap">
                  <button
                    type="submit"
                    className="odysseus-btn odysseus-btn-primary"
                    data-testid="password-change-submit"
                  >
                    {t("updatePasswordButton")}
                  </button>
                </div>
              </form>
            </section>
          )}
        </div>
      </main>
    );
  }

  return (
    <div className="odysseus-shell" data-testid="authenticated-view">
      <a href="#main-workspace" className="odysseus-skip-link">
        Skip to main content
      </a>

      {/* Hidden compatibility elements for Phase 01 foundation.spec.ts */}
      <span className="sr-only" data-testid="app-title">
        {t("appTitle")}
      </span>
      <span className="sr-only" data-testid="health-badge">
        {readyStatus === "ready" && degradedServices.length === 0
          ? t("statusReady")
          : t("statusDegraded")}
      </span>
      <span className="sr-only">{t("welcomeUser", { username: user.username })}</span>

      <AppTopBar
        apiClient={apiClient}
        chatId={activeChatId}
        chatTitle={chatDetail?.title ?? t("appTitle")}
        isTemporaryChat={Boolean(chatDetail?.temporary)}
        capabilities={capabilities}
        runningRunsCount={runningRunsCount}
        pendingApprovalsCount={pendingApprovalsCount}
        artifactsPanelOpen={artifactsPanelOpen}
        onToggleArtifactsPanel={() => setArtifactsPanelOpen((o) => !o)}
        onOpenAgentHub={(tab) => {
          setAgentHubTab(tab);
          setAgentHubOpen(true);
        }}
        onRenameTitle={async (newTitle) => {
          if (!activeChatId) return;
          await apiClient.updateChat(activeChatId, { title: newTitle });
          await loadChatDetail(activeChatId);
          await refreshChats();
        }}
      />

      <div className="odysseus-body">
        <AppSidebar
          apiClient={apiClient}
          chats={chats}
          activeChatId={activeChatId}
          username={user.username}
          onNewChat={(temp) => handleNewChat(temp)}
          onSelectChat={(cid) => {
            setActiveChatId(cid);
            window.history.replaceState(null, "", `?chat=${encodeURIComponent(cid)}`);
          }}
          onRefreshChats={async () => {
            await refreshChats();
          }}
          onLogout={handleLogout}
        />

        <main id="main-workspace" className="odysseus-main-workspace">
          <RouteErrorBoundary>
            {activeWorkspace === "chat" ? (
              <div className="odysseus-chat-pane">
                <VirtualizedMessageList
                  chatId={activeChatId ?? "default"}
                  messages={activeMessages}
                  allMessages={allMessages}
                  activeRun={activeRun}
                  activeRunEvents={activeRunEvents}
                  deepLinkMessageId={deepLinkMessageId}
                  onEditMessage={handleEditMessage}
                  onRegenerateMessage={handleRegenerateMessage}
                  onActivateBranch={handleActivateBranch}
                  onForkChat={handleForkChat}
                  onDeleteSubtree={handleDeleteSubtree}
                  onSuggestionClick={(prompt) => void handleSendMessage(prompt, [], false)}
                  onResolveApproval={handleResolveApproval}
                  onOpenTimelinePanel={() => {
                    if (!inspectorOpen) {
                      useAppShellStore.getState().toggleInspector();
                    }
                  }}
                  onOpenRunView={(rid) => {
                    void handleOpenRunView(rid);
                  }}
                  onOpenArtifact={(artId) => {
                    setActiveArtifactId(artId);
                    setArtifactsPanelOpen(true);
                  }}
                  onSendToArtifact={(title, content) => {
                    const artId = `art_${Date.now().toString(36)}`;
                    const newArt: ArtifactItem = {
                      id: artId,
                      title,
                      type: "markdown",
                      latest_version: 1,
                      versions: [
                        {
                          version: 1,
                          content,
                          summary: "Sent from chat message",
                          created_at: new Date().toISOString(),
                          author: "user",
                        },
                      ],
                    };
                    setArtifactsList((prev) => [...prev, newArt]);
                    setActiveArtifactId(artId);
                    setArtifactsPanelOpen(true);
                  }}
                  onQuoteSelection={(quoted) => {
                    const cid = activeChatId ?? "default";
                    const cur = useAppShellStore.getState().draftsByChatId[cid] ?? "";
                    useAppShellStore
                      .getState()
                      .setDraft(cid, `${cur ? `${cur}\n` : ""}> ${quoted}\n\n`);
                  }}
                />
                <ChatComposer
                  chatId={activeChatId ?? "default"}
                  apiClient={apiClient}
                  isRunning={isRunning}
                  activeRunId={activeRunId}
                  modelCapability={activeModelCapability}
                  historyTokens={activeMessages.reduce(
                    (acc, m) => acc + Math.ceil(m.content.length / 4),
                    0,
                  )}
                  onSendMessage={handleSendMessage}
                  onStopRun={handleStopRun}
                  onSteerRun={handleSteerRun}
                />
              </div>
            ) : activeWorkspace === "agents" ? (
              <div
                className="odysseus-run-view-page"
                data-testid="fullpage-run-view"
              >
                <div className="odysseus-inspector-header-bar">
                  <h2>
                    Full-Page Run View{" "}
                    {(syntheticRunState ?? activeRun)?.run_id ? (
                      <code>({(syntheticRunState ?? activeRun)?.run_id})</code>
                    ) : null}
                  </h2>
                  <div className="odysseus-row-wrap">
                    <button
                      type="button"
                      className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                      onClick={() => {
                        setAgentHubTab("runs");
                        setAgentHubOpen(true);
                      }}
                      data-testid="run-view-open-history-btn"
                    >
                      Run History & Presets
                    </button>
                    <button
                      type="button"
                      className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
                      onClick={() => {
                        setWorkspace("chat");
                        window.history.replaceState(null, "", "/");
                      }}
                      data-testid="run-view-back-chat-btn"
                    >
                      ← Back to Chat
                    </button>
                  </div>
                </div>
                {syntheticRunState || activeRun ? (
                  <AgentTimeline
                    runState={(syntheticRunState ?? activeRun)!}
                    events={
                      syntheticRunState ? syntheticRunEvents : activeRunEvents
                    }
                    presentation="run_view"
                    onStopRun={() => void handleStopRun()}
                    onSteerRun={(_rid, txt) => void handleSteerRun(txt)}
                    onOpenRunView={(rid) => void handleOpenRunView(rid)}
                    onOpenArtifact={(artId) => {
                      setActiveArtifactId(artId);
                      setArtifactsPanelOpen(true);
                    }}
                    onImportTraceEvents={(imported) => {
                      setSyntheticRunEvents(imported);
                      setSyntheticRunState(
                        reduceRunState(imported, undefined, {
                          ignoreDuplicates: true,
                        }),
                      );
                    }}
                  />
                ) : (
                  <p className="odysseus-text-muted">
                    Select a run from Run History or start an agent run to inspect its full timeline.
                  </p>
                )}
              </div>
            ) : activeWorkspace === "mail" ||
              activeWorkspace === "notes" ||
              activeWorkspace === "calendar" ||
              activeWorkspace === "schedules" ? (
              <Suspense fallback={<div className="odysseus-card">Loading productivity suite…</div>}>
                <LazyProductivityWorkspacesView initialMode={activeWorkspace} />
              </Suspense>
            ) : activeWorkspace === "docs" ||
              activeWorkspace === "research" ||
              activeWorkspace === "compare" ||
              activeWorkspace === "memory" ||
              activeWorkspace === "skills" ||
              activeWorkspace === "mcp" ? (
              <Suspense fallback={<div className="odysseus-card">Loading workspace…</div>}>
                <LazyKnowledgeWorkspacesView initialMode={activeWorkspace} />
              </Suspense>
            ) : activeWorkspace === "projects" ? (
              <ProjectsManagerView
                apiClient={apiClient}
                projects={projects}
                onProjectsRefresh={refreshProjects}
                onSelectProjectChat={(pid) => void handleNewChat(false, pid)}
              />
            ) : activeWorkspace === "cookbook" ||
              activeWorkspace === "gallery" ||
              activeWorkspace === "voice" ||
              activeWorkspace === "admin" ? (
              <Suspense fallback={<div className="odysseus-card">Loading workspace…</div>}>
                <LazyLocalMediaAdminWorkspacesView initialMode={activeWorkspace} />
              </Suspense>
            ) : activeWorkspace === "settings" || activeWorkspace === "providers" ? (
              <Suspense fallback={<div className="odysseus-card">Loading settings…</div>}>
                <LazySettingsAndProvidersView
                  apiClient={apiClient}
                  initialSection={activeWorkspace}
                  capabilities={capabilities}
                  onCapabilitiesRefresh={refreshCapabilities}
                />
              </Suspense>
            ) : (
              <Suspense fallback={<div className="odysseus-card">Loading Storybook…</div>}>
                <LazyStorybookCatalog />
              </Suspense>
            )}
          </RouteErrorBoundary>
        </main>

        {artifactsPanelOpen ? (
          <ArtifactsCanvasPanel
            artifacts={artifactsList}
            activeArtifactId={activeArtifactId}
            onSelectArtifact={setActiveArtifactId}
            onClose={() => setArtifactsPanelOpen(false)}
            onUpdateArtifact={(updated) => {
              setArtifactsList((prev) =>
                prev.map((a) => (a.id === updated.id ? updated : a)),
              );
            }}
          />
        ) : null}

        {inspectorOpen ? (
          <aside
            className="odysseus-inspector-pane"
            aria-label="Run Inspector"
            data-testid="inspector-pane"
          >
            <div className="odysseus-inspector-header-bar">
              <h3>Run & Agent Timeline</h3>
              <div className="odysseus-inspector-scenario-btns">
                <button
                  type="button"
                  className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
                  onClick={handleLoad2000StepsStress}
                  data-testid="load-2000-steps-btn"
                >
                  2,000 Steps
                </button>
                <button
                  type="button"
                  className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
                  onClick={handleLoadSubagentTree}
                  data-testid="load-subagent-tree-btn"
                >
                  Sub-Agents
                </button>
                <button
                  type="button"
                  className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
                  onClick={handleLoad50MbJsonTool}
                  data-testid="load-50mb-json-btn"
                >
                  50 MB JSON
                </button>
                <button
                  type="button"
                  className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
                  onClick={handleOpenSandboxTestArtifact}
                  data-testid="open-sandbox-artifact-btn"
                >
                  Sandbox Probe
                </button>
              </div>
            </div>

            {syntheticRunState || activeRun ? (
              <div className="odysseus-inspector-body">
                {activeRun ? (
                  <p>
                    <strong>Run ID:</strong>{" "}
                    <code>{activeRun.run_id}</code> ·{" "}
                    <strong>Status:</strong> {activeRun.status} ·{" "}
                    <strong>Last Seq:</strong> {activeRun.last_seq}
                  </p>
                ) : null}
                <AgentTimeline
                  runState={(syntheticRunState ?? activeRun)!}
                  events={
                    syntheticRunState ? syntheticRunEvents : activeRunEvents
                  }
                  presentation="panel"
                  onStopRun={() => void handleStopRun()}
                  onSteerRun={(_rid, txt) => void handleSteerRun(txt)}
                  onOpenRunView={(rid) => void handleOpenRunView(rid)}
                  onOpenArtifact={(artId) => {
                    setActiveArtifactId(artId);
                    setArtifactsPanelOpen(true);
                  }}
                  onImportTraceEvents={(imported) => {
                    setSyntheticRunEvents(imported);
                    setSyntheticRunState(
                      reduceRunState(imported, undefined, {
                        ignoreDuplicates: true,
                      }),
                    );
                  }}
                />
              </div>
            ) : (
              <p className="odysseus-text-muted">No active run selected.</p>
            )}
          </aside>
        ) : null}
      </div>

      <RunHistoryAndPresetsModal
        open={agentHubOpen}
        initialTab={agentHubTab}
        onClose={() => setAgentHubOpen(false)}
        onOpenRun={(rid) => {
          setAgentHubOpen(false);
          void handleOpenRunView(rid);
        }}
        onApplyPreset={(preset) => {
          setSelectedModel(preset.model);
          addToast({
            message: `Applied agent preset "${preset.name}"`,
            variant: "success",
          });
        }}
      />

      <CommandPaletteModal
        open={commandPaletteOpen}
        onClose={() => setCommandPaletteOpen(false)}
        chats={chats}
        models={capabilities}
        onNewChat={() => void handleNewChat(false)}
        onSelectChat={(cid) => {
          setWorkspace("chat");
          setActiveChatId(cid);
        }}
        onSelectModel={(m) => {
          setSelectedModel(m);
        }}
      />

      <ShortcutsOverlayModal
        open={shortcutsOpen}
        onClose={() => setShortcutsOpen(false)}
      />

      <ToastRegion toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}
