/**
 * Web Worker for off-main-thread Markdown block splitting and highlighting on large messages.
 */

import { type MarkdownBlock, splitMarkdownBlocks } from "../lib/markdown";

export interface MarkdownWorkerRequest {
  readonly id: number;
  readonly text: string;
  readonly isStreaming: boolean;
}

export interface MarkdownWorkerResponse {
  readonly id: number;
  readonly blocks: ReadonlyArray<MarkdownBlock>;
}

if (typeof self !== "undefined" && typeof self.addEventListener === "function") {
  self.addEventListener("message", (event: MessageEvent<MarkdownWorkerRequest>) => {
    const { id, text, isStreaming } = event.data;
    const blocks = splitMarkdownBlocks(text, isStreaming);
    const response: MarkdownWorkerResponse = { id, blocks };
    self.postMessage(response);
  });
}
