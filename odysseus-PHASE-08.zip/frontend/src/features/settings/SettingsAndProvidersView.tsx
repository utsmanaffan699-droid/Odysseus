import React, { useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { Badge, Button, Dialog, Input, Select, Tabs } from "../../design-system/primitives";
import type {
  AdminSettingsResponse,
  OdysseusApiClient,
  ProviderModelCapability,
} from "../../lib/contracts/api.gen";
import type { RawJsonEditorProps } from "../../lib/lazy/codemirrorEditor";
import { useAppShellStore } from "../../lib/store";

export interface SettingsAndProvidersProps {
  readonly apiClient: OdysseusApiClient;
  readonly initialSection?: "settings" | "providers";
  readonly capabilities: ReadonlyArray<ProviderModelCapability>;
  readonly onCapabilitiesRefresh: () => Promise<void>;
}

export function SettingsAndProvidersView({
  apiClient,
  initialSection = "settings",
  capabilities,
  onCapabilitiesRefresh,
}: SettingsAndProvidersProps): React.ReactElement {
  const { t } = useTranslation();
  const {
    theme,
    palette,
    density,
    fontSize,
    messageWidth,
    keybindings,
    addToast,
    setTheme,
    setPalette,
    setDensity,
    setFontSize,
    setMessageWidth,
    setKeybinding,
  } = useAppShellStore();

  const [section, setSection] = useState<"settings" | "providers">(initialSection);
  const [editorMode, setEditorMode] = useState<"form" | "raw">("form");
  const [adminData, setAdminData] = useState<AdminSettingsResponse | null>(null);
  const [draftOverrides, setDraftOverrides] = useState<Record<string, unknown>>({});
  const [searchFilter, setSearchFilter] = useState("");
  const [diffModalOpen, setDiffModalOpen] = useState(false);
  const [rawValid, setRawValid] = useState(true);
  const [serverError, setServerError] = useState<string | null>(null);

  // Lazy-loaded CodeMirror component
  const [LazyCmComp, setLazyCmComp] = useState<React.ComponentType<RawJsonEditorProps> | null>(
    null,
  );

  // Provider Probe Wizard state
  const [probeProvider, setProbeProvider] = useState("openai");
  const [probeBaseUrl, setProbeBaseUrl] = useState("http://127.0.0.1:11434/v1");
  const [probeApiKey, setProbeApiKey] = useState("");
  const [probeSupportsTools, setProbeSupportsTools] = useState("auto");
  const [probeResult, setProbeResult] = useState<Record<string, unknown> | null>(null);
  const [probing, setProbing] = useState(false);

  useEffect(() => {
    setSection(initialSection);
  }, [initialSection]);

  useEffect(() => {
    void apiClient
      .getAdminSettings()
      .then((res) => {
        setAdminData(res);
        const initial: Record<string, unknown> = {};
        for (const k of res.editable_keys) {
          initial[k] = res.effective[k];
        }
        setDraftOverrides(initial);
      })
      .catch(() => {
        // Non-admin users can still edit appearance settings
      });
  }, [apiClient]);

  useEffect(() => {
    if (editorMode === "raw" && !LazyCmComp) {
      void import("../../lib/lazy/codemirrorEditor").then((mod) => {
        setLazyCmComp(() => mod.LazyCodeMirrorJsonEditor);
      });
    }
  }, [editorMode, LazyCmComp]);

  const editableFields = useMemo(() => {
    if (!adminData) return [];
    const props = (adminData.json_schema.properties ?? {}) as Record<
      string,
      Record<string, unknown>
    >;
    const q = searchFilter.trim().toLowerCase();
    return adminData.editable_keys
      .filter((k) => !q || k.toLowerCase().includes(q))
      .map((key) => ({
        key,
        schema: props[key] ?? { type: "string" },
      }));
  }, [adminData, searchFilter]);

  const changedDiffs = useMemo(() => {
    if (!adminData) return [];
    return adminData.editable_keys
      .filter((k) => JSON.stringify(draftOverrides[k]) !== JSON.stringify(adminData.effective[k]))
      .map((k) => ({
        key: k,
        before: adminData.effective[k],
        after: draftOverrides[k],
      }));
  }, [adminData, draftOverrides]);

  const handleConfirmSave = async (): Promise<void> => {
    setServerError(null);
    const patch: Record<string, unknown> = {};
    for (const d of changedDiffs) {
      patch[d.key] = d.after;
    }
    try {
      const res = await apiClient.updateAdminSettings(patch);
      if (adminData) {
        setAdminData({ ...adminData, effective: res.effective });
      }
      setDiffModalOpen(false);
      addToast({ message: "Settings saved", variant: "success" });
    } catch (err) {
      setServerError(err instanceof Error ? err.message : "Failed to save settings");
    }
  };

  const handleProbe = async (): Promise<void> => {
    setProbing(true);
    setProbeResult(null);
    try {
      const res = await apiClient.probeProvider({
        provider: probeProvider,
        base_url: probeBaseUrl || null,
        api_key: probeApiKey || null,
        supports_tools: probeSupportsTools,
      });
      setProbeResult(res);
    } catch (err) {
      setProbeResult({
        healthy: false,
        error: err instanceof Error ? err.message : "Probe failed",
      });
    } finally {
      setProbing(false);
    }
  };

  const handleSaveEndpoint = async (): Promise<void> => {
    try {
      if (probeProvider === "openai" && probeBaseUrl) {
        await apiClient.updateAdminSettings({ openai_base_url: probeBaseUrl });
      }
      if (probeApiKey.trim()) {
        await apiClient.upsertSecret(`${probeProvider}_api_key`, probeApiKey.trim());
        setProbeApiKey("");
      }
      await onCapabilitiesRefresh();
      addToast({ message: "Provider endpoint updated", variant: "success" });
    } catch (err) {
      addToast({
        message: err instanceof Error ? err.message : "Failed to update provider",
        variant: "error",
      });
    }
  };

  return (
    <section className="odysseus-settings-page" data-testid="settings-view">
      <Tabs
        ariaLabel="Settings and Providers Navigation"
        activeId={section}
        onSelect={(id) => setSection(id as "settings" | "providers")}
        tabs={[
          { id: "settings", label: t("settingsHeading") },
          { id: "providers", label: t("providersHeading") },
        ]}
      />

      {section === "settings" ? (
        <div className="odysseus-settings-body">
          {/* Appearance & Accessibility Preferences (FE-SHELL-10) */}
          <div className="odysseus-card">
            <h3>Appearance, Density & Keyboard Shortcuts</h3>
            <div className="odysseus-settings-grid">
              <Select
                id="pref-theme"
                label="Theme"
                value={theme}
                onChange={(e) => setTheme(e.target.value as "light" | "dark" | "high-contrast")}
                options={[
                  { value: "dark", label: "Dark" },
                  { value: "light", label: "Light" },
                  { value: "high-contrast", label: "High Contrast" },
                ]}
                data-testid="settings-theme-select"
              />
              <Select
                id="pref-palette"
                label="Color Palette"
                value={palette}
                onChange={(e) => setPalette(e.target.value as "slate" | "amber" | "forest")}
                options={[
                  { value: "slate", label: "Odysseus Slate" },
                  { value: "amber", label: "Solar Amber" },
                  { value: "forest", label: "Emerald Forest" },
                ]}
                data-testid="settings-palette-select"
              />
              <Select
                id="pref-density"
                label="Density"
                value={density}
                onChange={(e) => setDensity(e.target.value as "comfortable" | "compact")}
                options={[
                  { value: "comfortable", label: "Comfortable" },
                  { value: "compact", label: "Compact" },
                ]}
                data-testid="settings-density-select"
              />
              <Select
                id="pref-fontsize"
                label="Font Size"
                value={fontSize}
                onChange={(e) => setFontSize(e.target.value as "sm" | "md" | "lg")}
                options={[
                  { value: "sm", label: "Small" },
                  { value: "md", label: "Medium" },
                  { value: "lg", label: "Large" },
                ]}
                data-testid="settings-fontsize-select"
              />
              <Select
                id="pref-msgwidth"
                label="Message Width"
                value={messageWidth}
                onChange={(e) => setMessageWidth(e.target.value as "narrow" | "wide")}
                options={[
                  { value: "narrow", label: "Narrow (Reading)" },
                  { value: "wide", label: "Wide" },
                ]}
              />
              <Input
                id="pref-kb-newchat"
                label="New Chat Shortcut"
                value={keybindings["newChat"] ?? "Alt+N"}
                onChange={(e) => setKeybinding("newChat", e.target.value)}
                data-testid="shortcut-rebind-newchat"
              />
            </div>
          </div>

          {/* Schema-Driven Server Settings (FE-ADMIN-01) */}
          {adminData ? (
            <div className="odysseus-card" data-testid="schema-settings-card">
              <div className="odysseus-dialog-header">
                <h3>Server Configuration (Schema-Driven)</h3>
                <div className="odysseus-row-wrap">
                  <Button
                    variant={editorMode === "form" ? "primary" : "secondary"}
                    size="sm"
                    onClick={() => setEditorMode("form")}
                    data-testid="settings-form-tab"
                  >
                    Form View
                  </Button>
                  <Button
                    variant={editorMode === "raw" ? "primary" : "secondary"}
                    size="sm"
                    onClick={() => setEditorMode("raw")}
                    data-testid="settings-raw-tab"
                  >
                    Raw JSON (CodeMirror)
                  </Button>
                </div>
              </div>

              <Input
                id="settings-search-input"
                label="Filter Settings"
                placeholder="Search setting key…"
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                data-testid="settings-search-input"
              />

              {serverError ? (
                <div className="odysseus-error" role="alert">
                  {serverError}
                </div>
              ) : null}

              {editorMode === "form" ? (
                <div className="odysseus-settings-grid" data-testid="schema-form-fields">
                  {editableFields.map(({ key, schema }) => {
                    const val = draftOverrides[key];
                    const typ = schema.type;
                    if (typ === "boolean") {
                      return (
                        <label key={key} className="odysseus-check-row">
                          <input
                            type="checkbox"
                            checked={Boolean(val)}
                            onChange={(e) =>
                              setDraftOverrides((prev) => ({ ...prev, [key]: e.target.checked }))
                            }
                            data-testid={`setting-field-${key}`}
                          />
                          <span>{key}</span>
                        </label>
                      );
                    }
                    return (
                      <Input
                        key={key}
                        id={`setting-${key}`}
                        label={key}
                        type={typ === "integer" || typ === "number" ? "number" : "text"}
                        value={String(val ?? "")}
                        onChange={(e) => {
                          const rawVal = e.target.value;
                          const coerced =
                            typ === "integer"
                              ? Number.parseInt(rawVal, 10) || 0
                              : typ === "number"
                                ? Number.parseFloat(rawVal) || 0
                                : rawVal;
                          setDraftOverrides((prev) => ({ ...prev, [key]: coerced }));
                        }}
                        data-testid={`setting-field-${key}`}
                      />
                    );
                  })}
                </div>
              ) : LazyCmComp ? (
                <LazyCmComp
                  value={JSON.stringify(draftOverrides, null, 2)}
                  schema={adminData.json_schema}
                  editableKeys={adminData.editable_keys}
                  onChange={(nextText, isValid) => {
                    setRawValid(isValid);
                    if (isValid) {
                      try {
                        setDraftOverrides(JSON.parse(nextText) as Record<string, unknown>);
                      } catch {
                        // Handled by validator
                      }
                    }
                  }}
                />
              ) : (
                <p>Loading JSON editor…</p>
              )}

              <div className="odysseus-row-wrap">
                <Button
                  variant="primary"
                  disabled={!rawValid || changedDiffs.length === 0}
                  onClick={() => setDiffModalOpen(true)}
                  data-testid="settings-review-diff-btn"
                >
                  {t("saveSettingsButton")} ({changedDiffs.length})
                </Button>
              </div>
            </div>
          ) : null}

          <Dialog
            open={diffModalOpen}
            title="Review Configuration Changes Before Saving"
            onClose={() => setDiffModalOpen(false)}
            testId="settings-diff-modal"
          >
            <ul className="odysseus-diff-list">
              {changedDiffs.map((d) => (
                <li key={d.key}>
                  <strong>{d.key}:</strong> <code>{JSON.stringify(d.before)}</code> →{" "}
                  <code>{JSON.stringify(d.after)}</code>
                </li>
              ))}
            </ul>
            <div className="odysseus-row-wrap">
              <Button
                variant="primary"
                onClick={() => void handleConfirmSave()}
                data-testid="settings-confirm-save"
              >
                Confirm & Save
              </Button>
            </div>
          </Dialog>
        </div>
      ) : (
        <div className="odysseus-settings-body" data-testid="providers-section">
          <div className="odysseus-card">
            <h3>Add / Probe Provider Endpoint (FE-ADMIN-02)</h3>
            <div className="odysseus-settings-grid">
              <Select
                id="probe-provider-select"
                label="Provider Type"
                value={probeProvider}
                onChange={(e) => setProbeProvider(e.target.value)}
                options={[
                  { value: "openai", label: "OpenAI-Compatible (/v1)" },
                  { value: "anthropic", label: "Anthropic Messages" },
                  { value: "gemini", label: "Google Gemini" },
                  { value: "fake", label: "FakeProvider (Built-in)" },
                ]}
                data-testid="provider-type-select"
              />
              <Input
                id="probe-base-url"
                label="Endpoint Base URL"
                value={probeBaseUrl}
                onChange={(e) => setProbeBaseUrl(e.target.value)}
                placeholder="http://127.0.0.1:11434/v1"
                data-testid="provider-base-url"
              />
              <Input
                id="probe-api-key"
                label="API Key (Stored Encrypted in Vault)"
                type="password"
                value={probeApiKey}
                onChange={(e) => setProbeApiKey(e.target.value)}
                placeholder="sk-••••••••••••"
                data-testid="provider-api-key"
              />
              <Select
                id="probe-supports-tools"
                label="Tool Calling Override (supports_tools)"
                value={probeSupportsTools}
                onChange={(e) => setProbeSupportsTools(e.target.value)}
                options={[
                  { value: "auto", label: "Auto (Conservative for local /v1)" },
                  { value: "true", label: "Force Native Tool Calling (true)" },
                  { value: "false", label: "Disable Tools (false)" },
                ]}
                data-testid="provider-supports-tools"
              />
            </div>
            <div className="odysseus-row-wrap">
              <Button
                variant="secondary"
                loading={probing}
                onClick={() => void handleProbe()}
                data-testid="probe-provider-btn"
              >
                {t("probeProviderButton")}
              </Button>
              <Button
                variant="primary"
                onClick={() => void handleSaveEndpoint()}
                data-testid="save-provider-endpoint-btn"
              >
                Save Endpoint & Key
              </Button>
            </div>

            {probeResult ? (
              <div className="odysseus-probe-result" data-testid="probe-result-card">
                <p>
                  <strong>Status:</strong>{" "}
                  {probeResult.healthy ? "Healthy ✓" : "Unreachable / Degraded"}{" "}
                  {typeof probeResult.latency_ms === "number"
                    ? `(${probeResult.latency_ms} ms)`
                    : ""}
                </p>
                <pre>{JSON.stringify(probeResult, null, 2)}</pre>
              </div>
            ) : null}
          </div>

          <div className="odysseus-card">
            <h3>Registered Models & Capability Matrix</h3>
            <div className="odysseus-model-list" data-testid="provider-models-list">
              {capabilities.map((cap) => (
                <div key={cap.model} className="odysseus-model-card">
                  <div>
                    <strong>{cap.model}</strong> <Badge>{cap.provider}</Badge>
                  </div>
                  <div className="odysseus-row-wrap">
                    <Badge variant={cap.supports_tools ? "success" : "default"}>
                      Tools: {cap.tool_transport}
                    </Badge>
                    {cap.supports_vision ? <Badge variant="success">Vision</Badge> : null}
                    {cap.supports_thinking ? <Badge variant="success">Thinking</Badge> : null}
                    <Badge>Window: {cap.context_window.toLocaleString()}</Badge>
                    <Badge>Cost: {cap.cost_tier}</Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
