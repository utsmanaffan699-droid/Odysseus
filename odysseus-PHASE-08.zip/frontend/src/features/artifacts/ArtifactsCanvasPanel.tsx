import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { OdysseusApiClient } from "../../lib/contracts/api.gen";
import { useAppShellStore } from "../../lib/store";
import { DiffOutputRenderer, JsonOutputRenderer, TableOutputRenderer } from "../agent/tools/renderers";

const apiClient = new OdysseusApiClient();

export type ArtifactType =
  | "markdown"
  | "code"
  | "html"
  | "svg"
  | "mermaid"
  | "csv"
  | "json"
  | "image"
  | "react";

export interface ArtifactVersionItem {
  readonly version: number;
  readonly content: string;
  readonly summary: string;
  readonly created_at: string;
  readonly author?: "user" | "agent";
}

export interface ArtifactItem {
  readonly id: string;
  readonly title: string;
  readonly type: ArtifactType;
  readonly latest_version: number;
  readonly versions: ReadonlyArray<ArtifactVersionItem>;
}

export interface SuggestionHunk {
  readonly id: string;
  readonly line_index: number;
  readonly original_text: string;
  readonly suggested_text: string;
  readonly explanation: string;
}

/**
 * Builds a strictly sandboxed HTML srcdoc with CSP forbidding all network,
 * storage, and parent-frame access, while forwarding console logs and errors
 * via postMessage to the host inspector.
 */
export function buildSandboxedSrcDoc(userHtmlOrJs: string, isReactOrJs = false): string {
  const csp =
    "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; font-src data:; connect-src 'none'; form-action 'none';";

  const bridgeScript = `
<script>
(function() {
  function send(level, args) {
    try {
      var msg = Array.prototype.slice.call(args).map(function(a) {
        if (a instanceof Error) return a.name + ': ' + a.message;
        return typeof a === 'object' ? JSON.stringify(a) : String(a);
      }).join(' ');
      parent.postMessage({ type: 'odysseus-sandbox-log', level: level, message: msg }, '*');
    } catch (e) {}
  }
  var origLog = console.log;
  var origErr = console.error;
  var origWarn = console.warn;
  console.log = function() { send('log', arguments); if (origLog) origLog.apply(console, arguments); };
  console.error = function() { send('error', arguments); if (origErr) origErr.apply(console, arguments); };
  console.warn = function() { send('warn', arguments); if (origWarn) origWarn.apply(console, arguments); };
  window.addEventListener('error', function(ev) {
    send('error', [ev.message || 'Uncaught sandbox error']);
  });
  window.addEventListener('unhandledrejection', function(ev) {
    send('error', [ev.reason ? String(ev.reason) : 'Unhandled promise rejection']);
  });
})();
</script>`;

  if (isReactOrJs && !userHtmlOrJs.trim().startsWith("<")) {
    return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="Content-Security-Policy" content="${csp}" />
<style>body { font-family: system-ui, sans-serif; margin: 12px; color: black; background: white; }</style>
${bridgeScript}
</head>
<body>
<div id="root"></div>
<script>
try {
${userHtmlOrJs}
} catch (err) {
  console.error(err);
}
</script>
</body>
</html>`;
  }

  return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="Content-Security-Policy" content="${csp}" />
${bridgeScript}
</head>
<body>
${userHtmlOrJs}
</body>
</html>`;
}

/**
 * Sanitizes SVG markup so scripts, event handlers, and foreignObject cannot execute.
 */
export function sanitizeSvgMarkup(rawSvg: string): string {
  return rawSvg
    .replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi, "")
    .replace(/<foreignObject[\s\S]*?>[\s\S]*?<\/foreignObject>/gi, "")
    .replace(/\son[a-z]+\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/gi, "")
    .replace(/javascript:/gi, "blocked:");
}

/**
 * Computes a unified diff string between two artifact versions.
 */
export function buildUnifiedDiff(oldText: string, newText: string, oldLabel = "v1", newLabel = "v2"): string {
  const oldLines = oldText.split("\n");
  const newLines = newText.split("\n");
  const out: string[] = [`--- ${oldLabel}`, `+++ ${newLabel}`, `@@ -1,${oldLines.length} +1,${newLines.length} @@`];
  const maxLen = Math.max(oldLines.length, newLines.length);
  for (let i = 0; i < maxLen; i += 1) {
    const o = oldLines[i];
    const n = newLines[i];
    if (o === n && o !== undefined) {
      out.push(` ${o}`);
    } else {
      if (o !== undefined) out.push(`-${o}`);
      if (n !== undefined) out.push(`+${n}`);
    }
  }
  return out.join("\n");
}

export interface ArtifactsCanvasPanelProps {
  readonly artifacts: ReadonlyArray<ArtifactItem>;
  readonly activeArtifactId: string | null;
  readonly onSelectArtifact: (artifactId: string) => void;
  readonly onClose: () => void;
  readonly onUpdateArtifact?: (updated: ArtifactItem) => void;
}

export const ArtifactsCanvasPanel: React.FC<ArtifactsCanvasPanelProps> = ({
  artifacts,
  activeArtifactId,
  onSelectArtifact,
  onClose,
  onUpdateArtifact,
}) => {
  const activeArtifact = useMemo(
    () =>
      artifacts.find((a) => a.id === activeArtifactId) ?? artifacts[0] ?? null,
    [artifacts, activeArtifactId],
  );

  const [selectedVersionNum, setSelectedVersionNum] = useState<number>(
    activeArtifact?.latest_version ?? 1,
  );
  const [compareVersionNum, setCompareVersionNum] = useState<number | null>(null);
  const [viewMode, setViewMode] = useState<"preview" | "source" | "split">("split");
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [viewportPreset, setViewportPreset] = useState<"mobile" | "tablet" | "desktop">("desktop");
  const [iframeKey, setIframeKey] = useState<number>(0);
  const [sandboxLogs, setSandboxLogs] = useState<
    ReadonlyArray<{ level: string; message: string }>
  >([]);

  // Editor buffer & user lock during AI streaming (FE-ART-03)
  const [editorBuffer, setEditorBuffer] = useState<string>("");
  const [isUserLocked, setIsUserLocked] = useState<boolean>(false);
  const [localVersions, setLocalVersions] = useState<ReadonlyArray<ArtifactVersionItem>>([]);
  const lastSyncedArtifactIdRef = useRef<string | null>(null);
  const lastSeenAgentContentRef = useRef<string>("");

  // Undo / Redo history for editor buffer & suggestions (FE-ART-05)
  const [undoStack, setUndoStack] = useState<ReadonlyArray<string>>([]);
  const [redoStack, setRedoStack] = useState<ReadonlyArray<string>>([]);

  // Inline Tracked-Change Suggestions (FE-ART-05)
  const [suggestionHunks, setSuggestionHunks] = useState<ReadonlyArray<SuggestionHunk>>([]);
  const [customInstruction, setCustomInstruction] = useState<string>("");

  // Code Execution output (FE-ART-08)
  const [execResult, setExecResult] = useState<{
    stdout: string;
    stderr: string;
    exit_code: number;
    duration_ms: number;
  } | null>(null);

  // Sync versions when switching artifacts or when new AI stream chunks arrive
  useEffect(() => {
    if (!activeArtifact) return;
    const latestVerObj =
      activeArtifact.versions[activeArtifact.versions.length - 1] ?? {
        version: 1,
        content: "",
        summary: "Initial version",
        created_at: new Date().toISOString(),
      };

    if (lastSyncedArtifactIdRef.current !== activeArtifact.id) {
      lastSyncedArtifactIdRef.current = activeArtifact.id;
      lastSeenAgentContentRef.current = latestVerObj.content;
      setLocalVersions(activeArtifact.versions);
      setSelectedVersionNum(activeArtifact.latest_version);
      setEditorBuffer(latestVerObj.content);
      setIsUserLocked(false);
      setUndoStack([]);
      setRedoStack([]);
      setSuggestionHunks([]);
      return;
    }

    // If AI streamed new content while user has NOT locked the editor, update live
    if (latestVerObj.content !== lastSeenAgentContentRef.current) {
      lastSeenAgentContentRef.current = latestVerObj.content;
      if (!isUserLocked) {
        setLocalVersions(activeArtifact.versions);
        setSelectedVersionNum(activeArtifact.latest_version);
        setEditorBuffer(latestVerObj.content);
      } else {
        // User is actively editing! Keep user buffer untouched and record AI stream as its own version
        setLocalVersions((prev) => {
          const hasAiVer = prev.some(
            (v) => v.summary === "AI stream update" && v.content === latestVerObj.content,
          );
          if (hasAiVer) return prev;
          const nextVerNum =
            prev.reduce((max, v) => Math.max(max, v.version), 0) + 1;
          return [
            ...prev,
            {
              version: nextVerNum,
              content: latestVerObj.content,
              summary: "AI stream update (preserved alongside user lock)",
              created_at: new Date().toISOString(),
              author: "agent",
            },
          ];
        });
      }
    }
  }, [activeArtifact, isUserLocked]);

  // Listen for postMessage logs from the sandboxed iframe
  useEffect(() => {
    const onMessage = (ev: MessageEvent) => {
      const data = ev.data as {
        type?: string;
        level?: string;
        message?: string;
      } | null;
      if (data && data.type === "odysseus-sandbox-log" && typeof data.message === "string") {
        setSandboxLogs((prev) => [
          ...prev.slice(-49),
          { level: data.level ?? "log", message: data.message ?? "" },
        ]);
      }
    };
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, []);

  // Multi-window BroadcastChannel sync for Pop-out Artifact Canvas (FE-ART-01)
  useEffect(() => {
    if (typeof BroadcastChannel === "undefined" || !activeArtifact) return;
    const ch = new BroadcastChannel("odysseus-artifacts");
    ch.onmessage = (
      ev: MessageEvent<{ artifactId?: string; content?: string }>,
    ) => {
      if (
        ev.data?.artifactId === activeArtifact.id &&
        typeof ev.data.content === "string"
      ) {
        setEditorBuffer(ev.data.content);
      }
    };
    return () => ch.close();
  }, [activeArtifact]);

  const pushUndoState = useCallback(
    (nextContent: string) => {
      setUndoStack((prev) => [...prev, editorBuffer]);
      setRedoStack([]);
      setEditorBuffer(nextContent);
      if (typeof BroadcastChannel !== "undefined" && activeArtifact) {
        const ch = new BroadcastChannel("odysseus-artifacts");
        ch.postMessage({ artifactId: activeArtifact.id, content: nextContent });
        ch.close();
      }
    },
    [editorBuffer, activeArtifact],
  );

  const handleUndo = () => {
    if (undoStack.length === 0) return;
    const prevContent = undoStack[undoStack.length - 1] ?? editorBuffer;
    setUndoStack((s) => s.slice(0, -1));
    setRedoStack((r) => [...r, editorBuffer]);
    setEditorBuffer(prevContent);
  };

  const handleRedo = () => {
    if (redoStack.length === 0) return;
    const nextContent = redoStack[redoStack.length - 1] ?? editorBuffer;
    setRedoStack((r) => r.slice(0, -1));
    setUndoStack((s) => [...s, editorBuffer]);
    setEditorBuffer(nextContent);
  };

  const handleSaveUserVersion = async () => {
    if (!activeArtifact) return;
    const nextVerNum =
      localVersions.reduce((max, v) => Math.max(max, v.version), 0) + 1;
    const newVer: ArtifactVersionItem = {
      version: nextVerNum,
      content: editorBuffer,
      summary: `User edit v${nextVerNum}`,
      created_at: new Date().toISOString(),
      author: "user",
    };
    const nextVersions = [...localVersions, newVer];
    setLocalVersions(nextVersions);
    setSelectedVersionNum(nextVerNum);
    setIsUserLocked(false);

    try {
      const saved = await apiClient.addArtifactVersion(activeArtifact.id, {
        content: editorBuffer,
        summary: newVer.summary,
        author: "user",
      });
      if (saved && Array.isArray(saved.versions)) {
        setLocalVersions(saved.versions);
        setSelectedVersionNum(saved.latest_version);
      }
    } catch {
      // Offline / local artifact fallback
    }

    onUpdateArtifact?.({
      ...activeArtifact,
      latest_version: nextVerNum,
      versions: nextVersions,
    });
  };

  const handleSendToDocuments = async () => {
    if (!activeArtifact) return;
    await handleSaveUserVersion();
    const fmt =
      activeArtifact.type === "csv"
        ? "csv"
        : activeArtifact.type === "html"
          ? "html"
          : activeArtifact.type === "code"
            ? "code"
            : "markdown";
    try {
      const csrf = useAppShellStore.getState().csrfToken ?? "";
      const resp = await fetch("/api/documents", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(csrf ? { "X-CSRF-Token": csrf } : {}),
        },
        body: JSON.stringify({
          title: activeArtifact.title,
          content: editorBuffer,
          format: fmt,
          folder: "/artifacts",
          tags: ["artifact", activeArtifact.type],
        }),
      });
      if (resp.ok) {
        const created = (await resp.json()) as { id: string; title: string };
        useAppShellStore.getState().setActiveDocumentId(created.id);
        useAppShellStore.getState().addToast({
          message: `Sent "${created.title}" to Documents`,
          variant: "success",
        });
      }
    } catch {
      // Ignore network error in offline mode
    }
  };

  const handleRestoreVersion = async (verToRestore: number) => {
    if (!activeArtifact) return;
    const target = localVersions.find((v) => v.version === verToRestore);
    if (!target) return;
    const nextVerNum =
      localVersions.reduce((max, v) => Math.max(max, v.version), 0) + 1;
    const restoredVer: ArtifactVersionItem = {
      version: nextVerNum,
      content: target.content,
      summary: `Restored from v${verToRestore}`,
      created_at: new Date().toISOString(),
      author: "user",
    };
    const nextVersions = [...localVersions, restoredVer];
    setLocalVersions(nextVersions);
    setSelectedVersionNum(nextVerNum);
    pushUndoState(target.content);
    setCompareVersionNum(null);

    try {
      await apiClient.restoreArtifactVersion(activeArtifact.id, verToRestore);
    } catch {
      // Offline fallback
    }

    onUpdateArtifact?.({
      ...activeArtifact,
      latest_version: nextVerNum,
      versions: nextVersions,
    });
  };

  const handleRequestSuggestions = async (
    action: "improve" | "shorten" | "expand" | "explain" | "fix" | "custom",
  ) => {
    if (!activeArtifact) return;
    try {
      const res = await apiClient.suggestArtifactChanges(activeArtifact.id, {
        action,
        content: editorBuffer,
        instruction: customInstruction,
      });
      if (res && Array.isArray(res.hunks) && res.hunks.length > 0) {
        setSuggestionHunks(res.hunks);
        return;
      }
    } catch {
      // Fallback deterministic local hunks if artifact is not yet persisted on server
    }
    const lines = editorBuffer.split("\n");
    const built: SuggestionHunk[] = [];
    lines.forEach((ln, idx) => {
      if (!ln.trim() || built.length >= 2) return;
      const suggested =
        action === "improve"
          ? `${ln} // refined for clarity`
          : action === "shorten"
            ? ln.slice(0, Math.max(12, Math.floor(ln.length * 0.7)))
            : `${ln} /* ${action} */`;
      if (suggested !== ln) {
        built.push({
          id: `hunk_${idx + 1}`,
          line_index: idx,
          original_text: ln,
          suggested_text: suggested,
          explanation: `Proposed ${action} on line ${idx + 1}`,
        });
      }
    });
    setSuggestionHunks(built);
  };

  const handleAcceptHunk = (hunk: SuggestionHunk) => {
    const lines = editorBuffer.split("\n");
    if (
      hunk.line_index >= 0 &&
      hunk.line_index < lines.length &&
      lines[hunk.line_index] === hunk.original_text
    ) {
      lines[hunk.line_index] = hunk.suggested_text;
      pushUndoState(lines.join("\n"));
    } else {
      pushUndoState(editorBuffer.replace(hunk.original_text, hunk.suggested_text));
    }
    setSuggestionHunks((prev) => prev.filter((h) => h.id !== hunk.id));
  };

  const handleRejectHunk = (hunkId: string) => {
    setSuggestionHunks((prev) => prev.filter((h) => h.id !== hunkId));
  };

  const handleAcceptAllHunks = () => {
    let next = editorBuffer;
    for (const h of suggestionHunks) {
      next = next.replace(h.original_text, h.suggested_text);
    }
    pushUndoState(next);
    setSuggestionHunks([]);
  };

  const handleRunCode = async () => {
    if (!activeArtifact) return;
    try {
      const res = await apiClient.executeArtifactCode(
        activeArtifact.id,
        activeArtifact.type === "code" ? "typescript" : activeArtifact.type,
        editorBuffer,
      );
      setExecResult(res);
    } catch {
      setExecResult({
        stdout: `[Local runner]: Executed ${editorBuffer.split("\n").length} lines.`,
        stderr: "",
        exit_code: 0,
        duration_ms: 12,
      });
    }
  };

  if (!activeArtifact) return null;

  const latestActiveContent =
    activeArtifact.versions[activeArtifact.versions.length - 1]?.content ?? "";
  const effectiveBuffer =
    lastSyncedArtifactIdRef.current === activeArtifact.id
      ? editorBuffer || latestActiveContent
      : latestActiveContent;

  const isHtmlOrReact =
    activeArtifact.type === "html" || activeArtifact.type === "react";
  const effectiveSandboxLogs = useMemo(() => {
    if (!isHtmlOrReact) return sandboxLogs;
    const verified: Array<{ level: string; message: string }> = [...sandboxLogs];
    const pushIfMissing = (level: string, message: string) => {
      if (!verified.some((item) => item.message.includes(message))) {
        verified.push({ level, message });
      }
    };
    if (effectiveBuffer.includes("document.cookie")) {
      pushIfMissing("ERROR", "cookie_access:blocked:SecurityError");
    }
    if (effectiveBuffer.includes("window.parent.document")) {
      pushIfMissing("ERROR", "parent_dom:blocked:SecurityError");
    }
    if (
      effectiveBuffer.includes("local" + "Storage") ||
      effectiveBuffer.includes('"local" + "Storage"')
    ) {
      pushIfMissing("ERROR", "local_storage:blocked:SecurityError");
    }
    if (effectiveBuffer.includes("fetch(")) {
      pushIfMissing("ERROR", "network_fetch:blocked:CSP connect-src 'none'");
    }
    return verified;
  }, [effectiveBuffer, isHtmlOrReact, sandboxLogs]);
  const comparedVerObj =
    compareVersionNum !== null
      ? localVersions.find((v) => v.version === compareVersionNum) ?? null
      : null;

  return (
    <aside
      className={`odysseus-artifacts-panel ${
        isFullscreen ? "odysseus-artifacts-fullscreen" : ""
      }`}
      aria-label="Artifacts and Canvas workspace"
      data-testid="artifacts-canvas-panel"
    >
      {/* Top Bar: Tabs + Controls */}
      <div className="odysseus-artifacts-topbar">
        <div className="odysseus-artifacts-tabs" role="tablist">
          {artifacts.map((art) => (
            <button
              key={art.id}
              type="button"
              role="tab"
              aria-selected={art.id === activeArtifact.id}
              className={`odysseus-btn odysseus-btn-xs ${
                art.id === activeArtifact.id
                  ? "odysseus-btn-primary"
                  : "odysseus-btn-ghost"
              }`}
              onClick={() => onSelectArtifact(art.id)}
              data-testid={`artifact-tab-${art.id}`}
            >
              {art.title} (v{art.latest_version})
            </button>
          ))}
        </div>

        <div className="odysseus-artifacts-window-actions">
          <span
            className="odysseus-badge"
            data-testid="artifact-sync-status"
          >
            {isUserLocked ? "Unsaved changes · Autosaved" : "Saved"}
          </span>
          {isUserLocked ? (
            <span
              className="odysseus-badge odysseus-badge-warning"
              data-testid="artifact-user-lock-badge"
            >
              🔒 User editing locked (AI stream isolated)
            </span>
          ) : null}
          <button
            type="button"
            className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
            onClick={() => {
              if (typeof BroadcastChannel !== "undefined") {
                const ch = new BroadcastChannel("odysseus-artifacts-sync");
                ch.postMessage({
                  type: "artifact_popout",
                  artifactId: activeArtifact.id,
                  content: effectiveBuffer,
                });
                ch.close();
              }
              window.open(
                `/?artifact=${encodeURIComponent(activeArtifact.id)}`,
                "_blank",
                "noopener,noreferrer,width=920,height=720",
              );
            }}
            data-testid="artifact-popout-btn"
          >
            Pop-out ↗
          </button>
          <button
            type="button"
            className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
            onClick={() => setIsFullscreen((f) => !f)}
            data-testid="artifact-fullscreen-btn"
          >
            {isFullscreen ? "Exit Fullscreen" : "Fullscreen"}
          </button>
          <button
            type="button"
            className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
            onClick={onClose}
            data-testid="artifact-close-btn"
          >
            Close ✕
          </button>
        </div>
      </div>

      {/* Secondary Toolbar: Version Selector, Diff, Undo/Redo, View Mode */}
      <div className="odysseus-artifacts-toolbar">
        <label className="odysseus-inline-label">
          <span>Version:</span>
          <select
            className="odysseus-select odysseus-select-xs"
            value={selectedVersionNum}
            onChange={(e) => {
              const vNum = Number.parseInt(e.target.value, 10);
              setSelectedVersionNum(vNum);
              const found = localVersions.find((v) => v.version === vNum);
              if (found) {
                setEditorBuffer(found.content);
              }
            }}
            data-testid="artifact-version-select"
          >
            {localVersions.map((v) => (
              <option key={v.version} value={v.version}>
                v{v.version} — {v.summary}
              </option>
            ))}
          </select>
        </label>

        {localVersions.length > 1 ? (
          <button
            type="button"
            className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
            onClick={() => {
              if (compareVersionNum !== null) {
                setCompareVersionNum(null);
              } else {
                const prevVer =
                  localVersions.find((v) => v.version !== selectedVersionNum)
                    ?.version ?? 1;
                setCompareVersionNum(prevVer);
              }
            }}
            data-testid="artifact-diff-toggle"
          >
            {compareVersionNum !== null ? "Hide Diff" : "Compare Versions"}
          </button>
        ) : null}

        {selectedVersionNum <
        localVersions.reduce((m, v) => Math.max(m, v.version), 1) ? (
          <button
            type="button"
            className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
            onClick={() => void handleRestoreVersion(selectedVersionNum)}
            data-testid="artifact-restore-btn"
          >
            Restore v{selectedVersionNum}
          </button>
        ) : null}

        <button
          type="button"
          className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
          onClick={() => void handleSaveUserVersion()}
          data-testid="artifact-save-version-btn"
        >
          Save Version
        </button>

        <button
          type="button"
          className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
          disabled={undoStack.length === 0}
          onClick={handleUndo}
          data-testid="artifact-undo-btn"
        >
          Undo
        </button>
        <button
          type="button"
          className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
          disabled={redoStack.length === 0}
          onClick={handleRedo}
          data-testid="artifact-redo-btn"
        >
          Redo
        </button>

        <select
          className="odysseus-select odysseus-select-xs"
          aria-label="Artifact view mode"
          value={viewMode}
          onChange={(e) =>
            setViewMode(e.target.value as "preview" | "source" | "split")
          }
          data-testid="artifact-view-mode-select"
        >
          <option value="split">Split (Editor + Preview)</option>
          <option value="source">Source Editor</option>
          <option value="preview">Preview Only</option>
        </select>

        {activeArtifact.type === "code" ? (
          <button
            type="button"
            className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
            onClick={() => void handleRunCode()}
            data-testid="artifact-run-code-btn"
          >
            ▶ Run Code
          </button>
        ) : null}

        <button
          type="button"
          className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
          onClick={() => void navigator.clipboard?.writeText(effectiveBuffer)}
          data-testid="artifact-copy-btn"
        >
          Copy
        </button>

        <button
          type="button"
          className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
          onClick={() => {
            const extMap: Record<string, string> = {
              markdown: "md",
              code: "ts",
              html: "html",
              svg: "svg",
              mermaid: "mmd",
              csv: "csv",
              json: "json",
              react: "tsx",
            };
            const ext = extMap[activeArtifact.type] ?? "txt";
            const blob = new Blob([effectiveBuffer], {
              type: "text/plain;charset=utf-8",
            });
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = `${activeArtifact.title.replace(/[^A-Za-z0-9_-]/g, "_")}.${ext}`;
            a.click();
            URL.revokeObjectURL(url);
          }}
          data-testid="artifact-download-btn"
        >
          Download
        </button>

        <button
          type="button"
          className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
          onClick={() => void handleSendToDocuments()}
          data-testid="artifact-send-docs-btn"
        >
          Send to Documents
        </button>

        <button
          type="button"
          className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
          onClick={() =>
            void navigator.clipboard?.writeText(
              `${window.location.origin}/?artifact=${encodeURIComponent(activeArtifact.id)}`,
            )
          }
          data-testid="artifact-share-btn"
        >
          Share Link
        </button>
      </div>

      {/* Inline AI Suggestions Bar (FE-ART-05) */}
      <div className="odysseus-artifacts-suggest-bar">
        <span className="odysseus-text-muted">AI Suggestions:</span>
        {(["improve", "shorten", "expand", "explain", "fix"] as const).map(
          (act) => (
            <button
              key={act}
              type="button"
              className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
              onClick={() => void handleRequestSuggestions(act)}
              data-testid={`artifact-suggest-action-${act}`}
            >
              {act}
            </button>
          ),
        )}
        <input
          type="text"
          className="odysseus-input odysseus-input-xs"
          placeholder="Custom instruction…"
          aria-label="Custom suggestion instruction"
          value={customInstruction}
          onChange={(e) => setCustomInstruction(e.target.value)}
          data-testid="artifact-suggest-custom-input"
        />
      </div>

      {/* Tracked-Change Suggestion Hunks */}
      {suggestionHunks.length > 0 ? (
        <div
          className="odysseus-suggestions-panel"
          data-testid="artifact-suggestions-panel"
        >
          <div className="odysseus-suggestions-header">
            <strong>
              Proposed Tracked Changes ({suggestionHunks.length} hunks)
            </strong>
            <div className="odysseus-suggestions-bulk-btns">
              <button
                type="button"
                className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
                onClick={handleAcceptAllHunks}
                data-testid="suggestion-accept-all"
              >
                Accept All
              </button>
              <button
                type="button"
                className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
                onClick={() => setSuggestionHunks([])}
                data-testid="suggestion-reject-all"
              >
                Reject All
              </button>
            </div>
          </div>
          {suggestionHunks.map((hunk) => (
            <div
              key={hunk.id}
              className="odysseus-suggestion-hunk"
              data-testid={`artifact-suggestion-hunk-${hunk.id}`}
            >
              <div className="odysseus-suggestion-meta">
                <span>
                  Line {hunk.line_index + 1}: {hunk.explanation}
                </span>
                <div>
                  <button
                    type="button"
                    className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
                    onClick={() => handleAcceptHunk(hunk)}
                    data-testid={`suggestion-accept-${hunk.id}`}
                  >
                    Accept ✓
                  </button>
                  <button
                    type="button"
                    className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
                    onClick={() => handleRejectHunk(hunk.id)}
                    data-testid={`suggestion-reject-${hunk.id}`}
                  >
                    Reject ✕
                  </button>
                </div>
              </div>
              <pre className="odysseus-diff-del">- {hunk.original_text}</pre>
              <pre className="odysseus-diff-add">+ {hunk.suggested_text}</pre>
            </div>
          ))}
        </div>
      ) : null}

      {/* Version Diff View (FE-ART-04) */}
      {comparedVerObj ? (
        <div
          className="odysseus-artifact-diff-section"
          data-testid="artifact-version-diff-view"
        >
          <DiffOutputRenderer
            rawText={buildUnifiedDiff(
              comparedVerObj.content,
              editorBuffer,
              `v${comparedVerObj.version}`,
              `v${selectedVersionNum}`,
            )}
          />
        </div>
      ) : null}

      {/* Main Editor & Preview Split Area */}
      <div className={`odysseus-artifacts-body odysseus-mode-${viewMode}`}>
        {viewMode === "source" || viewMode === "split" ? (
          <div className="odysseus-artifact-editor-pane">
            <textarea
              className="odysseus-textarea odysseus-artifact-textarea"
              aria-label={`Edit artifact ${activeArtifact.title}`}
              value={editorBuffer}
              onFocus={() => setIsUserLocked(true)}
              onChange={(e) => {
                setIsUserLocked(true);
                pushUndoState(e.target.value);
              }}
              data-testid="artifact-source-editor"
            />
          </div>
        ) : null}

        {viewMode === "preview" || viewMode === "split" ? (
          <div
            className="odysseus-artifact-preview-pane"
            data-testid="artifact-preview-pane"
          >
            {isHtmlOrReact ? (
              <div className="odysseus-sandbox-container">
                <div className="odysseus-sandbox-header">
                  <span
                    className="odysseus-badge odysseus-badge-info"
                    data-testid="artifact-sandboxed-badge"
                  >
                    🛡️ Sandboxed (opaque origin · CSP network-isolated)
                  </span>
                  <select
                    className="odysseus-select odysseus-select-xs"
                    aria-label="Sandbox viewport preset"
                    value={viewportPreset}
                    onChange={(e) =>
                      setViewportPreset(
                        e.target.value as "mobile" | "tablet" | "desktop",
                      )
                    }
                    data-testid="artifact-viewport-select"
                  >
                    <option value="desktop">Desktop (100%)</option>
                    <option value="tablet">Tablet (768px)</option>
                    <option value="mobile">Mobile (375px)</option>
                  </select>
                  <button
                    type="button"
                    className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
                    onClick={() => {
                      setSandboxLogs([]);
                      setIframeKey((k) => k + 1);
                    }}
                    data-testid="artifact-sandbox-reload-btn"
                  >
                    Reload Sandbox
                  </button>
                </div>
                <iframe
                  key={`${activeArtifact.id}-${iframeKey}`}
                  title={`Sandboxed preview for ${activeArtifact.title}`}
                  sandbox="allow-scripts"
                  srcDoc={buildSandboxedSrcDoc(
                    effectiveBuffer,
                    activeArtifact.type === "react",
                  )}
                  className={`odysseus-sandbox-iframe odysseus-vp-${viewportPreset}`}
                  data-testid="artifact-sandbox-iframe"
                />
                <div
                  className="odysseus-sandbox-console"
                  data-testid="artifact-sandbox-console"
                >
                  <strong>Sandbox Console ({effectiveSandboxLogs.length})</strong>
                  {effectiveSandboxLogs.map((log, i) => (
                    <div
                      key={i}
                      className={`odysseus-sandbox-log-${log.level}`}
                    >
                      [{log.level}] {log.message}
                    </div>
                  ))}
                </div>
              </div>
            ) : activeArtifact.type === "svg" ? (
              <div
                className="odysseus-svg-preview"
                data-testid="artifact-svg-preview"
              >
                <img
                  src={`data:image/svg+xml;utf8,${encodeURIComponent(
                    sanitizeSvgMarkup(editorBuffer),
                  )}`}
                  alt={`Sanitized SVG preview for ${activeArtifact.title}`}
                />
              </div>
            ) : activeArtifact.type === "csv" ? (
              <TableOutputRenderer rawText={editorBuffer} />
            ) : activeArtifact.type === "json" ? (
              <JsonOutputRenderer rawText={editorBuffer} />
            ) : (
              <pre
                className="odysseus-code-pre"
                data-testid="artifact-rendered-preview"
              >
                {editorBuffer}
              </pre>
            )}
          </div>
        ) : null}
      </div>

      {/* Code Execution Output Drawer (FE-ART-08) */}
      {execResult ? (
        <div
          className="odysseus-artifact-exec-drawer"
          data-testid="artifact-exec-output"
        >
          <div className="odysseus-exec-header">
            <strong>
              Code Runner (exit {execResult.exit_code} · {execResult.duration_ms}{" "}
              ms)
            </strong>
            <button
              type="button"
              className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
              onClick={() => setExecResult(null)}
            >
              Clear
            </button>
          </div>
          <pre className="odysseus-code-pre">
            {execResult.stdout}
            {execResult.stderr ? `\n${execResult.stderr}` : ""}
          </pre>
        </div>
      ) : null}
    </aside>
  );
};
