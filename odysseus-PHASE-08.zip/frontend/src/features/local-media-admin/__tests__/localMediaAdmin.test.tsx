import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";
import "../../../i18n";
import { LocalMediaAdminWorkspacesView } from "../LocalMediaAdminWorkspacesView";

afterEach(() => {
  cleanup();
});

describe("LocalMediaAdminWorkspacesView (Phase 08: Cookbook, Gallery, Voice, Admin)", () => {
  it("renders Cookbook hardware advisor, passthrough diagnostic, downloads, engines, serves, and SSH TOFU", async () => {
    render(<LocalMediaAdminWorkspacesView initialMode="cookbook" />);

    expect(screen.getByTestId("cookbook-hw-card")).toBeTruthy();
    expect(screen.getByTestId("cookbook-models-table")).toBeTruthy();

    fireEvent.change(screen.getByTestId("cookbook-hw-fixture-select"), {
      target: { value: "18_container_without_passthrough" },
    });
    await waitFor(() => {
      expect(screen.getByTestId("cookbook-passthrough-banner").textContent).toContain(
        "docker/gpu.nvidia.yml",
      );
    });

    fireEvent.click(screen.getByTestId("cookbook-simulate-disk-full-btn"));
    await waitFor(() => {
      expect(screen.getByTestId("cookbook-download-failure-cause").textContent).toContain(
        "disk_full",
      );
    });

    fireEvent.click(screen.getByTestId("cookbook-engine-dry-run-btn"));
    await waitFor(() => {
      expect(screen.getByTestId("cookbook-engine-status").textContent).toContain(
        "Dry-Run Preflight Passed",
      );
    });
    fireEvent.click(screen.getByTestId("cookbook-install-engine-btn"));
    await waitFor(() => {
      expect(screen.getByTestId("cookbook-engine-status").textContent).toContain("b4150");
    });

    fireEvent.click(screen.getByTestId("cookbook-crash-loop-btn"));
    await waitFor(() => {
      expect(screen.getByTestId("cookbook-serve-state").textContent).toContain("crash_loop");
    });
    fireEvent.click(screen.getByTestId("cookbook-run-bench-btn"));
    await waitFor(() => {
      expect(screen.getByTestId("cookbook-bench-summary").textContent).toContain("ctx=32768");
    });

    fireEvent.click(screen.getByTestId("cookbook-confirm-tofu-btn"));
    expect(screen.getByTestId("cookbook-remote-status").textContent).toContain(
      "connected_tofu_pinned",
    );
    fireEvent.click(screen.getByTestId("cookbook-simulate-mitm-btn"));
    expect(screen.getByTestId("cookbook-remote-status").textContent).toContain(
      "host_key_changed_hard_stop",
    );
  });

  it("supports Gallery generation, 10,000 MP bomb guard, 200-step non-destructive editor, and EXIF-stripped export", async () => {
    render(<LocalMediaAdminWorkspacesView initialMode="gallery" />);

    fireEvent.click(screen.getByTestId("gallery-upload-bomb-btn"));
    expect(screen.getByTestId("gallery-upload-guard-status").textContent).toContain(
      "10,000 MP PNG Decompression Bomb",
    );

    fireEvent.click(screen.getByTestId("gallery-op-exposure-btn"));
    await waitFor(() => {
      expect(screen.getByTestId("gallery-op-count").textContent).toBe("1");
    });

    fireEvent.click(screen.getByTestId("gallery-op-200-btn"));
    expect(screen.getByTestId("gallery-op-count").textContent).toBe("201");

    fireEvent.click(screen.getByTestId("gallery-undo-btn"));
    await waitFor(() => {
      expect(screen.getByTestId("gallery-op-count").textContent).toBe("200");
      expect(screen.getByTestId("gallery-redo-count").textContent).toBe("1");
    });

    fireEvent.click(screen.getByTestId("gallery-export-btn"));
    await waitFor(() => {
      expect(screen.getByTestId("gallery-export-result").textContent).toContain(
        "EXIF/GPS stripped=true",
      );
    });
  });

  it("supports Voice Conversation Mode STT, mic-denied UX, streaming sentence TTS, and <= 150ms barge-in", async () => {
    render(<LocalMediaAdminWorkspacesView initialMode="voice" />);

    fireEvent.click(screen.getByTestId("voice-stt-btn"));
    await waitFor(() => {
      expect(screen.getByTestId("voice-stt-output").textContent).toContain("hardware advisor");
    });

    fireEvent.click(screen.getByTestId("voice-mic-denied-btn"));
    expect(screen.getByTestId("voice-mic-denied-banner").textContent).toContain(
      "falling back to text composer",
    );

    fireEvent.click(screen.getByTestId("voice-tts-stream-btn"));
    await waitFor(() => {
      expect(screen.getByTestId("voice-tts-stream-status").textContent).toContain("true");
    });

    fireEvent.click(screen.getByTestId("voice-start-turn-btn"));
    await waitFor(() => {
      expect(screen.getByTestId("voice-state-badge").textContent).toBe("speaking");
    });

    fireEvent.click(screen.getByTestId("voice-barge-in-btn"));
    await waitFor(() => {
      expect(screen.getByTestId("voice-state-badge").textContent).toBe("listening");
      expect(screen.getByTestId("voice-barge-in-latency").textContent).toContain("150 ms");
    });
  });

  it("supports Admin Console demo-mode redaction, policy pattern tester, support bundle scrubber, backup dry-run, privacy, and Guided Tours", async () => {
    render(<LocalMediaAdminWorkspacesView initialMode="admin" />);

    fireEvent.click(screen.getByTestId("guided-tour-trigger-btn"));
    expect(screen.getByTestId("guided-tour-card")).toBeTruthy();
    fireEvent.click(screen.getByTestId("guided-tour-complete-btn"));
    expect(screen.getByTestId("guided-tour-trigger-btn").textContent).toContain(
      "Guided Tour Done",
    );

    fireEvent.click(screen.getByTestId("admin-demo-mode-toggle"));
    await waitFor(() => {
      expect(screen.getByTestId("admin-usage-list").textContent).toContain("Demo Redacted Chat");
    });

    fireEvent.click(screen.getByTestId("admin-policy-test-btn"));
    await waitFor(() => {
      expect(screen.getByTestId("admin-policy-test-result").textContent).toContain("DENY");
    });

    fireEvent.click(screen.getByTestId("admin-support-bundle-btn"));
    await waitFor(() => {
      expect(screen.getByTestId("admin-support-bundle-output").textContent).toContain(
        "[REDACTED_",
      );
    });

    fireEvent.click(screen.getByTestId("admin-create-backup-btn"));
    await waitFor(() => {
      expect(screen.getByTestId("admin-backup-status").textContent).toContain("Backup created");
    });
    fireEvent.click(screen.getByTestId("admin-restore-dry-run-btn"));
    await waitFor(() => {
      expect(screen.getByTestId("admin-backup-status").textContent).toContain("Dry-Run Verified");
    });

    fireEvent.click(screen.getByTestId("admin-privacy-export-btn"));
    await waitFor(() => {
      expect(screen.getByTestId("admin-privacy-status").textContent).toContain(
        "GDPR Data Export Ready",
      );
    });
    fireEvent.change(screen.getByTestId("admin-privacy-delete-input"), {
      target: { value: "DELETE ALL MY DATA" },
    });
    fireEvent.click(screen.getByTestId("admin-privacy-delete-btn"));
    await waitFor(() => {
      expect(screen.getByTestId("admin-privacy-status").textContent).toContain(
        "All user data deleted",
      );
    });
  });
});
