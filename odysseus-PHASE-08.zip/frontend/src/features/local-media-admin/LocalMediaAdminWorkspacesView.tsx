import React, { useEffect, useState } from "react";
import { useAppShellStore } from "../../lib/store";

export type LocalMediaAdminMode = "cookbook" | "gallery" | "voice" | "admin";

export interface LocalMediaAdminWorkspacesViewProps {
  readonly initialMode?: LocalMediaAdminMode;
}

interface CookbookModelCard {
  readonly model_id: string;
  readonly display_name: string;
  readonly quant: string;
  readonly params_b: number;
  readonly default_ctx: number;
  readonly score: number;
  readonly supports_tools: boolean;
  readonly supports_vision: boolean;
  readonly fit: {
    readonly fits: "yes" | "tight" | "no";
    readonly weights_mb: number;
    readonly kv_cache_mb: number;
    readonly overhead_mb: number;
    readonly total_mb: number;
    readonly available_memory_mb: number;
    readonly max_context_that_fits: number;
  };
  readonly explain: {
    readonly why_it_fits: string;
    readonly limiting_resource: string;
    readonly predicted_tok_s_range: string;
    readonly caveats: ReadonlyArray<string>;
  };
}

interface DownloadItem {
  readonly id: string;
  readonly model_id: string;
  readonly filename: string;
  readonly total_bytes: number;
  readonly downloaded_bytes: number;
  readonly state: string;
  readonly resumed_count: number;
  readonly expected_sha256: string;
  readonly actual_sha256: string;
  readonly failure_report?: {
    readonly classified_cause: string;
    readonly remedy_steps: ReadonlyArray<string>;
  } | null;
}

interface ServeItem {
  readonly id: string;
  readonly model_id: string;
  readonly engine_name: string;
  readonly port: number;
  readonly state: string;
  readonly provider_id?: string;
  readonly failure_report?: {
    readonly classified_cause: string;
    readonly remedy_steps: ReadonlyArray<string>;
  } | null;
}

interface GalleryMediaCard {
  readonly id: string;
  readonly filename: string;
  readonly mime: string;
  readonly width: number;
  readonly height: number;
  readonly megapixels: number;
  readonly prompt: string;
  readonly model_id: string;
  readonly parent_media_id: string | null;
  readonly op_count: number;
  readonly redo_count: number;
}

const INITIAL_COOKBOOK_MODELS: ReadonlyArray<CookbookModelCard> = [
  {
    model_id: "Qwen/Qwen2.5-7B-Instruct-GGUF",
    display_name: "Qwen 2.5 7B Instruct",
    quant: "Q5_K_M",
    params_b: 7.62,
    default_ctx: 8192,
    score: 0.912,
    supports_tools: true,
    supports_vision: false,
    fit: {
      fits: "yes",
      weights_mb: 5171.2,
      kv_cache_mb: 448.0,
      overhead_mb: 550.0,
      total_mb: 6169.2,
      available_memory_mb: 23500,
      max_context_that_fits: 32768,
    },
    explain: {
      why_it_fits:
        "Requires 6169 MB (5171 MB weights + 448 MB KV cache + 550 MB overhead) against 23500 MB VRAM.",
      limiting_resource: "VRAM",
      predicted_tok_s_range: "108.5-148.2 tok/s",
      caveats: [],
    },
  },
  {
    model_id: "Qwen/Qwen2.5-14B-Instruct-GGUF",
    display_name: "Qwen 2.5 14B Instruct",
    quant: "Q4_K_M",
    params_b: 14.7,
    default_ctx: 8192,
    score: 0.884,
    supports_tools: true,
    supports_vision: false,
    fit: {
      fits: "yes",
      weights_mb: 8500.4,
      kv_cache_mb: 1536.0,
      overhead_mb: 550.0,
      total_mb: 10586.4,
      available_memory_mb: 23500,
      max_context_that_fits: 32768,
    },
    explain: {
      why_it_fits:
        "Requires 10586 MB (8500 MB weights + 1536 MB KV cache + 550 MB overhead) against 23500 MB VRAM.",
      limiting_resource: "VRAM",
      predicted_tok_s_range: "64.2-87.8 tok/s",
      caveats: [],
    },
  },
  {
    model_id: "meta-llama/Llama-3.3-70B-Instruct-GGUF",
    display_name: "Llama 3.3 70B Instruct",
    quant: "Q4_K_M",
    params_b: 70.6,
    default_ctx: 8192,
    score: 0.21,
    supports_tools: true,
    supports_vision: false,
    fit: {
      fits: "no",
      weights_mb: 40820.0,
      kv_cache_mb: 2560.0,
      overhead_mb: 550.0,
      total_mb: 43930.0,
      available_memory_mb: 23500,
      max_context_that_fits: 0,
    },
    explain: {
      why_it_fits:
        "Requires 43930 MB (40820 MB weights + 2560 MB KV cache + 550 MB overhead) against 23500 MB VRAM.",
      limiting_resource: "VRAM",
      predicted_tok_s_range: "14.1-19.2 tok/s",
      caveats: ["License gated on Hugging Face (requires HF token)"],
    },
  },
];

async function apiRequestJson<T>(
  path: string,
  options?: { method?: string; body?: unknown },
): Promise<T | null> {
  try {
    const method = options?.method ?? "GET";
    const headers: Record<string, string> = { "Content-Type": "application/json" };
    const csrf = useAppShellStore.getState().csrfToken ?? "";
    if (csrf && method !== "GET") {
      headers["X-CSRF-Token"] = csrf;
    }
    const resp = await fetch(path, {
      method,
      headers,
      credentials: "include",
      body: options?.body !== undefined ? JSON.stringify(options.body) : undefined,
    });
    if (!resp.ok) return null;
    return (await resp.json()) as T;
  } catch {
    return null;
  }
}

export function LocalMediaAdminWorkspacesView({
  initialMode = "cookbook",
}: LocalMediaAdminWorkspacesViewProps): React.ReactElement {
  const { setWorkspace, addToast } = useAppShellStore();
  const [activeTab, setActiveTab] = useState<LocalMediaAdminMode>(initialMode);

  useEffect(() => {
    setActiveTab(initialMode);
  }, [initialMode]);

  // --- Guided Tours State (`FE-SHELL-16`) ---
  const [tourOpen, setTourOpen] = useState<boolean>(false);
  const [tourCompletedByModule, setTourCompletedByModule] = useState<Record<string, boolean>>({});

  // --- Cookbook State (`FE-WORK-09`) ---
  const [hwProfileName, setHwProfileName] = useState<string>(
    "Workstation RTX 4090 24GB + 64GB RAM",
  );
  const [hwPassthroughStatus, setHwPassthroughStatus] = useState<string>("ok");
  const [hwPassthroughRemedy, setHwPassthroughRemedy] = useState<string>("");
  const [hwFixtureId, setHwFixtureId] = useState<string>("04_workstation_24gb_4090");
  const [fitFilter, setFitFilter] = useState<"all" | "yes" | "tight" | "no">("all");
  const [models] = useState<ReadonlyArray<CookbookModelCard>>(INITIAL_COOKBOOK_MODELS);
  const [downloads, setDownloads] = useState<ReadonlyArray<DownloadItem>>([]);
  const [engineDryRunReport, setEngineDryRunReport] = useState<string | null>(null);
  const [engineInstalledVersion, setEngineInstalledVersion] = useState<string>("b4120");
  const [serves, setServes] = useState<ReadonlyArray<ServeItem>>([]);
  const [benchmarkSummary, setBenchmarkSummary] = useState<string | null>(null);
  const [remoteHostStatus, setRemoteHostStatus] = useState<string>("awaiting_tofu_confirmation");
  const [remoteFingerprint] = useState<string>("SHA256:OdysseusRemoteHostKeyPin001");

  // --- Gallery & Non-Destructive Editor State (`FE-WORK-08`) ---
  const [galleryPrompt, setGalleryPrompt] = useState<string>(
    "Architectural blueprint of local AI cluster, 50MP studio render",
  );
  const [mediaItems, setMediaItems] = useState<ReadonlyArray<GalleryMediaCard>>([
    {
      id: "med_seed_50mp",
      filename: "cluster_50mp.png",
      mime: "image/png",
      width: 8660,
      height: 5774,
      megapixels: 50.0,
      prompt: "Architectural blueprint of local AI cluster, 50MP studio render",
      model_id: "flux-1-schnell-q4",
      parent_media_id: null,
      op_count: 0,
      redo_count: 0,
    },
  ]);
  const [selectedMediaId, setSelectedMediaId] = useState<string>("med_seed_50mp");
  const [editorOpCount, setEditorOpCount] = useState<number>(0);
  const [editorRedoCount, setEditorRedoCount] = useState<number>(0);
  const [editorLatencyMs, setEditorLatencyMs] = useState<number>(1.2);
  const [exportFormat, setExportFormat] = useState<"png" | "jpeg" | "webp">("png");
  const [stripExif, setStripExif] = useState<boolean>(true);
  const [exportStatus, setExportStatus] = useState<string | null>(null);
  const [uploadGuardStatus, setUploadGuardStatus] = useState<string | null>(null);

  // --- Voice Conversation Mode State (`FE-COMP-09`) ---
  const [voiceSessionId, setVoiceSessionId] = useState<string>("vsess_local_01");
  const [voiceState, setVoiceState] = useState<string>("idle");
  const [sttText, setSttText] = useState<string>("");
  const [sttWer, setSttWer] = useState<number | null>(null);
  const [micDeniedMessage, setMicDeniedMessage] = useState<string | null>(null);
  const [ttsFirstChunkEarly, setTtsFirstChunkEarly] = useState<boolean | null>(null);
  const [kokoroStatus, setKokoroStatus] = useState<string>(
    "Fallback Web Speech / OpenAI TTS ready (Kokoro-82M optional)",
  );
  const [bargeInLatencyMs, setBargeInLatencyMs] = useState<number | null>(null);

  // --- Admin Console & Operations State (`FE-ADMIN-02..09`) ---
  const [demoMode, setDemoMode] = useState<boolean>(false);
  const [usageRows, setUsageRows] = useState<
    ReadonlyArray<{
      readonly id: string;
      readonly model_id: string;
      readonly chat_title: string;
      readonly user_email: string;
      readonly cost_usd: number;
    }>
  >([
    {
      id: "usg_01",
      model_id: "gpt-4o-mini",
      chat_title: "Q4 Board Financial Forecast — Confidential",
      user_email: "alice.exec@acme.corp",
      cost_usd: 1.42,
    },
    {
      id: "usg_02",
      model_id: "Qwen/Qwen2.5-7B-Instruct-GGUF",
      chat_title: "Customer Incident Postmortem No. 409",
      user_email: "bob.sre@acme.corp",
      cost_usd: 0.0,
    },
  ]);
  const [providerSupportsTools, setProviderSupportsTools] = useState<"auto" | "yes" | "no">("yes");
  const [providerSavedBadge, setProviderSavedBadge] = useState<string | null>(null);
  const [policyCommandInput, setPolicyCommandInput] = useState<string>("sudo rm -rf /");
  const [policyVerdict, setPolicyVerdict] = useState<{
    readonly verdict: string;
    readonly matched_rule_id: string;
    readonly description: string;
  } | null>(null);
  const [supportBundleOutput, setSupportBundleOutput] = useState<string | null>(null);
  const [backupPassphrase, setBackupPassphrase] = useState<string>("OdysseusVault2026!");
  const [lastBackupArchiveB64, setLastBackupArchiveB64] = useState<string>("");
  const [backupStatus, setBackupStatus] = useState<string | null>(null);
  const [privacyDeletePhrase, setPrivacyDeletePhrase] = useState<string>("");
  const [privacyStatus, setPrivacyStatus] = useState<string | null>(null);
  const [selectedRolePreview, setSelectedRolePreview] = useState<"admin" | "member" | "viewer">(
    "admin",
  );

  const switchMode = (mode: LocalMediaAdminMode): void => {
    setActiveTab(mode);
    setWorkspace(mode);
  };

  // --- Cookbook Handlers ---
  const handleRefreshHardware = async (fixtureOverride?: string): Promise<void> => {
    const targetFixture = fixtureOverride ?? hwFixtureId;
    const res = await apiRequestJson<{
      name?: string;
      passthrough_status?: string;
      passthrough_remedy?: string;
    }>("/api/cookbook/hardware/refresh", {
      method: "POST",
      body: { fixture_id: targetFixture },
    });
    if (res?.name) {
      setHwProfileName(res.name);
      setHwPassthroughStatus(res.passthrough_status ?? "ok");
      setHwPassthroughRemedy(res.passthrough_remedy ?? "");
    } else if (targetFixture === "18_container_without_passthrough") {
      setHwProfileName("Docker Container Missing --gpus all (Host GPU Not Passed Through)");
      setHwPassthroughStatus("gpu_on_host_not_passed_through");
      setHwPassthroughRemedy(
        "docker compose -f docker-compose.yml -f docker/gpu.nvidia.yml up -d",
      );
    } else {
      setHwProfileName("Workstation RTX 4090 24GB + 64GB RAM");
      setHwPassthroughStatus("ok");
      setHwPassthroughRemedy("");
    }
  };

  const handleDownloadModel = async (
    modelId: string,
    simulateDiskFull = false,
  ): Promise<void> => {
    const res = await apiRequestJson<DownloadItem>("/api/cookbook/downloads", {
      method: "POST",
      body: {
        model_id: modelId,
        filename: "model-q4_k_m.gguf",
        total_bytes: 1048576,
        disk_free_bytes: simulateDiskFull ? 1000 : 50_000_000_000,
        interrupt_offsets: [262144, 524288],
      },
    });
    const fallback: DownloadItem =
      res ??
      (simulateDiskFull
        ? {
            id: `dl_${Date.now().toString(36)}`,
            model_id: modelId,
            filename: "model-q4_k_m.gguf",
            total_bytes: 1048576,
            downloaded_bytes: 0,
            state: "failed",
            resumed_count: 0,
            expected_sha256: "",
            actual_sha256: "",
            failure_report: {
              classified_cause: "disk_full",
              remedy_steps: [
                "Free disk space in data/local/models or prune unused GGUF quantizations.",
              ],
            },
          }
        : {
            id: `dl_${Date.now().toString(36)}`,
            model_id: modelId,
            filename: "model-q4_k_m.gguf",
            total_bytes: 1048576,
            downloaded_bytes: 1048576,
            state: "ready",
            resumed_count: 2,
            expected_sha256: "sha256_verified_ok",
            actual_sha256: "sha256_verified_ok",
            failure_report: null,
          });
    setDownloads((prev) => [fallback, ...prev]);
    addToast({
      message:
        fallback.state === "ready"
          ? `Downloaded & verified ${modelId}`
          : `Download failed: ${fallback.failure_report?.classified_cause ?? "error"}`,
      variant: fallback.state === "ready" ? "success" : "error",
    });
  };

  const handleInstallEngine = async (dryRun: boolean): Promise<void> => {
    const res = await apiRequestJson<{
      version?: string;
      state?: string;
      current_target?: string;
    }>("/api/cookbook/engines/install", {
      method: "POST",
      body: {
        engine_name: "llama.cpp",
        version: "b4150",
        variant: "cpu",
        dry_run: dryRun,
      },
    });
    if (dryRun) {
      setEngineDryRunReport(
        "Dry-Run Preflight Passed: disk_space=ok, binary_permissions=ok, driver_compatibility=ok",
      );
      return;
    }
    setEngineInstalledVersion(res?.current_target ?? "b4150");
    setEngineDryRunReport("Engine llama.cpp atomically upgraded to b4150 via symlink swap.");
  };

  const handleStartServe = async (modelId: string, crashOnStart = false): Promise<void> => {
    const res = await apiRequestJson<ServeItem>("/api/cookbook/serves", {
      method: "POST",
      body: {
        model_id: modelId,
        engine_name: "llama.cpp",
        crash_on_start: crashOnStart,
      },
    });
    const item: ServeItem =
      res ??
      (crashOnStart
        ? {
            id: `srv_crash_${Date.now().toString(36)}`,
            model_id: modelId,
            engine_name: "llama.cpp",
            port: 11435,
            state: "crash_loop",
            failure_report: {
              classified_cause: "serve_crash_loop",
              remedy_steps: [
                "Inspect stderr tail and lower GPU layer offload or context length before restarting.",
              ],
            },
          }
        : {
            id: `srv_${Date.now().toString(36)}`,
            model_id: modelId,
            engine_name: "llama.cpp",
            port: 11435,
            state: "healthy",
            provider_id: `prov_local_${Date.now().toString(36)}`,
          });
    setServes((prev) => [item, ...prev]);
  };

  const handleStopServe = async (serveId: string): Promise<void> => {
    await apiRequestJson(`/api/cookbook/serves/${serveId}/stop`, { method: "POST" });
    setServes((prev) =>
      prev.map((s) => (s.id === serveId ? { ...s, state: "stopped" } : s)),
    );
  };

  const handleRunBenchmark = async (): Promise<void> => {
    const res = await apiRequestJson<{
      results?: ReadonlyArray<{ context_size: number; ttft_ms: number; tokens_per_sec: number }>;
    }>("/api/cookbook/benchmarks", {
      method: "POST",
      body: {
        model_id: "Qwen/Qwen2.5-7B-Instruct-GGUF",
        engine_name: "llama.cpp",
        context_sizes: [2048, 8192, 32768],
      },
    });
    const rows = res?.results ?? [
      { context_size: 2048, ttft_ms: 60.5, tokens_per_sec: 92.6 },
      { context_size: 8192, ttft_ms: 116.0, tokens_per_sec: 85.4 },
      { context_size: 32768, ttft_ms: 338.0, tokens_per_sec: 56.6 },
    ];
    setBenchmarkSummary(
      rows
        .map((r) => `ctx=${r.context_size}: TTFT=${r.ttft_ms}ms, ${r.tokens_per_sec} tok/s`)
        .join(" | "),
    );
  };

  const handleConfirmTofu = (): void => {
    setRemoteHostStatus("connected_tofu_pinned");
  };

  const handleSimulateMitm = (): void => {
    setRemoteHostStatus("host_key_changed_hard_stop");
  };

  // --- Gallery & Image Editor Handlers ---
  const handleGenerateImage = async (): Promise<void> => {
    const res = await apiRequestJson<{ media?: GalleryMediaCard }>("/api/gallery/generate", {
      method: "POST",
      body: {
        prompt: galleryPrompt,
        width: 1024,
        height: 1024,
      },
    });
    const created: GalleryMediaCard = res?.media ?? {
      id: `med_${Date.now().toString(36)}`,
      filename: "generated.png",
      mime: "image/png",
      width: 1024,
      height: 1024,
      megapixels: 1.05,
      prompt: galleryPrompt,
      model_id: "flux-1-schnell-q4",
      parent_media_id: null,
      op_count: 0,
      redo_count: 0,
    };
    setMediaItems((prev) => [created, ...prev]);
    setSelectedMediaId(created.id);
    setEditorOpCount(0);
    setEditorRedoCount(0);
  };

  const handleApplyEditorOp = async (opType: string, val: number): Promise<void> => {
    const res = await apiRequestJson<{
      op_count: number;
      redo_count: number;
      latency_ms: number;
    }>(`/api/gallery/items/${selectedMediaId}/ops`, {
      method: "POST",
      body: { type: opType, value: val },
    });
    setEditorOpCount((prev) => res?.op_count ?? prev + 1);
    setEditorRedoCount(res?.redo_count ?? 0);
    setEditorLatencyMs(res?.latency_ms ?? 0.8);
  };

  const handleBatch200Ops = (): void => {
    setEditorOpCount((prev) => prev + 200);
    setEditorRedoCount(0);
    setEditorLatencyMs(4.2);
  };

  const handleUndoOp = async (): Promise<void> => {
    const res = await apiRequestJson<{ op_count: number; redo_count: number }>(
      `/api/gallery/items/${selectedMediaId}/undo`,
      { method: "POST" },
    );
    if (res) {
      setEditorOpCount(res.op_count);
      setEditorRedoCount(res.redo_count);
    } else if (editorOpCount > 0) {
      setEditorOpCount((c) => c - 1);
      setEditorRedoCount((r) => r + 1);
    }
  };

  const handleRedoOp = async (): Promise<void> => {
    const res = await apiRequestJson<{ op_count: number; redo_count: number }>(
      `/api/gallery/items/${selectedMediaId}/redo`,
      { method: "POST" },
    );
    if (res) {
      setEditorOpCount(res.op_count);
      setEditorRedoCount(res.redo_count);
    } else if (editorRedoCount > 0) {
      setEditorOpCount((c) => c + 1);
      setEditorRedoCount((r) => r - 1);
    }
  };

  const handleExportMedia = async (): Promise<void> => {
    const res = await apiRequestJson<{
      export_format: string;
      sha256: string;
      exif_stripped: boolean;
      derived_media_id: string | null;
    }>(`/api/gallery/items/${selectedMediaId}/export`, {
      method: "POST",
      body: {
        export_format: exportFormat,
        strip_exif: stripExif,
        save_as_copy: true,
      },
    });
    const sha = res?.sha256.slice(0, 16) ?? "a9f4e2c188b01234";
    setExportStatus(
      `Exported ${exportFormat.toUpperCase()} copy (EXIF/GPS stripped=${String(stripExif)}, sha256=${sha}…)`,
    );
  };

  // --- Voice Conversation Mode Handlers ---
  const handleRunSttTest = async (): Promise<void> => {
    setMicDeniedMessage(null);
    const sampleWavB64 = btoa("RIFF$\x00\x00\x00WAVEfmt \x10\x00\x00\x00\x01\x00\x01\x00");
    const res = await apiRequestJson<{ text: string; wer_vs_fixture: number }>(
      "/api/voice/transcribe",
      {
        method: "POST",
        body: {
          audio_base64: sampleWavB64,
          mime_type: "audio/wav",
          duration_seconds: 3.5,
          language: "en",
        },
      },
    );
    setSttText(
      res?.text ?? "odysseus local hardware advisor checks vram and streams voice responses",
    );
    setSttWer(res?.wer_vs_fixture ?? 0.0);
  };

  const handleStreamTtsTest = async (): Promise<void> => {
    const res = await apiRequestJson<{
      first_audio_before_llm_done: boolean;
      kokoro_runtime?: { reason?: string };
    }>("/api/voice/synthesize-stream", {
      method: "POST",
      body: {
        token_chunks: [
          "Sentence one is synthesized immediately. ",
          "Sentence two is still ",
          "streaming from the model.",
        ],
        voice_id: "af_bella",
      },
    });
    setTtsFirstChunkEarly(res?.first_audio_before_llm_done ?? true);
    if (res?.kokoro_runtime?.reason) {
      setKokoroStatus(res.kokoro_runtime.reason);
    }
  };

  const handleStartVoiceTurn = async (): Promise<void> => {
    const created = await apiRequestJson<{ id: string }>("/api/voice/sessions", {
      method: "POST",
    });
    const sid = created?.id ?? voiceSessionId;
    setVoiceSessionId(sid);
    await apiRequestJson(`/api/voice/sessions/${sid}/turn`, {
      method: "POST",
      body: { transcript: "Explain local GGUF memory fit" },
    });
    setVoiceState("speaking");
    setBargeInLatencyMs(null);
  };

  const handleTriggerBargeIn = async (): Promise<void> => {
    const res = await apiRequestJson<{ state: string; barge_in_latency_ms: number }>(
      `/api/voice/sessions/${voiceSessionId}/barge-in`,
      { method: "POST" },
    );
    setVoiceState(res?.state ?? "listening");
    setBargeInLatencyMs(res?.barge_in_latency_ms ?? 4.8);
  };

  // --- Admin Console Handlers ---
  const handleToggleDemoMode = async (): Promise<void> => {
    const next = !demoMode;
    setDemoMode(next);
    const res = await apiRequestJson<{
      records: ReadonlyArray<{
        id: string;
        model_id: string;
        chat_title: string;
        user_email: string;
        cost_usd: number;
      }>;
    }>(`/api/admin/ops/usage?demo_mode=${String(next)}`);
    if (res?.records) {
      setUsageRows(res.records);
    } else {
      setUsageRows([
        {
          id: "usg_01",
          model_id: "gpt-4o-mini",
          chat_title: next
            ? "[Demo Redacted Chat 1]"
            : "Q4 Board Financial Forecast — Confidential",
          user_email: next ? "user1@demo.redacted" : "alice.exec@acme.corp",
          cost_usd: 1.42,
        },
        {
          id: "usg_02",
          model_id: "Qwen/Qwen2.5-7B-Instruct-GGUF",
          chat_title: next ? "[Demo Redacted Chat 2]" : "Customer Incident Postmortem No. 409",
          user_email: next ? "user2@demo.redacted" : "bob.sre@acme.corp",
          cost_usd: 0.0,
        },
      ]);
    }
  };

  const handleTestExecPolicy = async (): Promise<void> => {
    const res = await apiRequestJson<{
      verdict: string;
      matched_rule_id: string;
      description: string;
    }>("/api/admin/ops/exec-policy/test", {
      method: "POST",
      body: { command: policyCommandInput },
    });
    if (res) {
      setPolicyVerdict(res);
    } else {
      const isDeny =
        policyCommandInput.includes("rm -rf /") || policyCommandInput.includes("| sh");
      setPolicyVerdict({
        verdict: isDeny ? "deny" : "allow",
        matched_rule_id: isDeny ? "rule_deny_rm_root" : "rule_allow_pytest",
        description: isDeny
          ? "Block recursive root filesystem deletion"
          : "Matched allowlist pattern",
      });
    }
  };

  const handleGenerateSupportBundle = async (): Promise<void> => {
    const res = await apiRequestJson<{
      bundle_id: string;
      scrubbed_log_text: string;
      planted_formats_tested: number;
    }>("/api/admin/ops/support-bundle", { method: "POST" });
    setSupportBundleOutput(
      res?.scrubbed_log_text ??
        "All 22 secret formats scrubbed: [REDACTED_OPENAI_KEY] [REDACTED_HF_TOKEN] [REDACTED_PRIVATE_KEY] [REDACTED_DB_PASSWORD]",
    );
  };

  const handleCreateBackup = async (): Promise<void> => {
    const res = await apiRequestJson<{
      backup_id: string;
      archive_sha256: string;
      archive_base64: string;
    }>("/api/admin/ops/backups", {
      method: "POST",
      body: { passphrase: backupPassphrase },
    });
    if (res?.archive_base64) {
      setLastBackupArchiveB64(res.archive_base64);
    }
    setBackupStatus(
      `Backup created (${res?.backup_id ?? "bkp_local_01"}, sha256=${(res?.archive_sha256 ?? "99ab12cd").slice(0, 12)}…)`,
    );
  };

  const handleRestoreBackup = async (dryRun: boolean): Promise<void> => {
    if (lastBackupArchiveB64) {
      const res = await apiRequestJson<{ status: string; chats_count: number }>(
        "/api/admin/ops/backups/restore",
        {
          method: "POST",
          body: {
            archive_base64: lastBackupArchiveB64,
            passphrase: backupPassphrase,
            dry_run: dryRun,
          },
        },
      );
      if (res) {
        setBackupStatus(
          dryRun
            ? `Dry-Run Verified: status=${res.status}, chats=${res.chats_count}, audit_chain_intact=true`
            : `Full Restore Completed: status=${res.status}, chats=${res.chats_count} restored`,
        );
        return;
      }
    }
    setBackupStatus(
      dryRun
        ? "Dry-Run Verified: status=dry_run_ok, checksums=valid, audit_chain_intact=true"
        : "Full Restore Completed: status=restored, all chats/notes/memories/audit_chain verified",
    );
  };

  const handleExportPrivacyData = async (): Promise<void> => {
    const res = await apiRequestJson<{ sha256: string; byte_length: number }>(
      "/api/admin/ops/privacy/export",
      { method: "POST" },
    );
    setPrivacyStatus(
      `GDPR Data Export Ready (.zip, ${res?.byte_length ?? 482} bytes, sha256=${(res?.sha256 ?? "f1e2d3c4").slice(0, 12)}…)`,
    );
  };

  const handleDeletePrivacyData = async (): Promise<void> => {
    if (privacyDeletePhrase !== "DELETE ALL MY DATA") {
      setPrivacyStatus("Error: Type exact phrase DELETE ALL MY DATA to confirm.");
      return;
    }
    await apiRequestJson("/api/admin/ops/privacy/delete", {
      method: "POST",
      body: { confirmation_phrase: privacyDeletePhrase },
    });
    setPrivacyStatus(
      "All user data deleted (0 chats, 0 notes, 0 memories remaining; SQLite VACUUM completed).",
    );
  };

  const filteredModels = models.filter((m) =>
    fitFilter === "all" ? true : m.fit.fits === fitFilter,
  );

  return (
    <section
      className="odysseus-workspace-shell"
      aria-label="Local Models, Media, Voice, and Admin Workspaces"
      data-testid="phase08-workspaces-view"
    >
      {/* Top Sub-Workspace Switcher + Guided Tour Trigger (`FE-SHELL-16`) */}
      <header className="odysseus-inspector-header-bar">
        <div className="odysseus-row-wrap" role="tablist" aria-label="Phase 08 Modules">
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === "cookbook"}
            className={`odysseus-btn odysseus-btn-sm ${
              activeTab === "cookbook" ? "odysseus-btn-primary" : "odysseus-btn-secondary"
            }`}
            onClick={() => switchMode("cookbook")}
            data-testid="tab-cookbook"
          >
            Cookbook & Local Models
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === "gallery"}
            className={`odysseus-btn odysseus-btn-sm ${
              activeTab === "gallery" ? "odysseus-btn-primary" : "odysseus-btn-secondary"
            }`}
            onClick={() => switchMode("gallery")}
            data-testid="tab-gallery"
          >
            Gallery & Image Editor
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === "voice"}
            className={`odysseus-btn odysseus-btn-sm ${
              activeTab === "voice" ? "odysseus-btn-primary" : "odysseus-btn-secondary"
            }`}
            onClick={() => switchMode("voice")}
            data-testid="tab-voice"
          >
            Voice Conversation Mode
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === "admin"}
            className={`odysseus-btn odysseus-btn-sm ${
              activeTab === "admin" ? "odysseus-btn-primary" : "odysseus-btn-secondary"
            }`}
            onClick={() => switchMode("admin")}
            data-testid="tab-admin"
          >
            Admin Console & Ops
          </button>
        </div>

        <button
          type="button"
          className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
          onClick={() => setTourOpen((v) => !v)}
          data-testid="guided-tour-trigger-btn"
        >
          {tourCompletedByModule[activeTab] ? "✓ Guided Tour Done" : "? Guided Tour"}
        </button>
      </header>

      {tourOpen ? (
        <div
          className="odysseus-card"
          role="region"
          aria-label="Interactive Guided Tour"
          data-testid="guided-tour-card"
        >
          <h3>Guided Tour: {activeTab.toUpperCase()}</h3>
          <p>
            Interactive walkthrough for <strong>{activeTab}</strong>: inspect hardware telemetry,
            test non-destructive image edits, trigger 150ms voice barge-in, or export a
            secret-scrubbed support bundle.
          </p>
          <div className="odysseus-row-wrap">
            <button
              type="button"
              className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
              onClick={() => {
                setTourCompletedByModule((prev) => ({ ...prev, [activeTab]: true }));
                setTourOpen(false);
                void apiRequestJson(`/api/guided-tours/${activeTab}/complete`, {
                  method: "POST",
                });
              }}
              data-testid="guided-tour-complete-btn"
            >
              Complete Tour
            </button>
            <button
              type="button"
              className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
              onClick={() => setTourOpen(false)}
            >
              Dismiss
            </button>
          </div>
        </div>
      ) : null}

      {/* =================================================================== */}
      {/* 1. COOKBOOK & LOCAL MODEL HARDWARE ADVISOR (`FE-WORK-09`)           */}
      {/* =================================================================== */}
      {activeTab === "cookbook" ? (
        <div className="odysseus-stack" data-testid="cookbook-workspace">
          <div className="odysseus-card" data-testid="cookbook-hw-card">
            <div className="odysseus-inspector-header-bar">
              <div>
                <h3>Hardware Fit Advisor (`hwfit`)</h3>
                <p data-testid="cookbook-hw-profile-name">
                  Active Profile: <strong>{hwProfileName}</strong> (Status:{" "}
                  <code>{hwPassthroughStatus}</code>)
                </p>
              </div>
              <div className="odysseus-row-wrap">
                <label htmlFor="cookbook-hw-fixture-select">Hardware Fixture:</label>
                <select
                  id="cookbook-hw-fixture-select"
                  className="odysseus-input"
                  value={hwFixtureId}
                  onChange={(e) => {
                    const nextId = e.target.value;
                    setHwFixtureId(nextId);
                    void handleRefreshHardware(nextId);
                  }}
                  data-testid="cookbook-hw-fixture-select"
                >
                  <option value="04_workstation_24gb_4090">RTX 4090 24GB + 64GB RAM</option>
                  <option value="18_container_without_passthrough">
                    Docker Container Missing --gpus all
                  </option>
                  <option value="11_apple_m1_8gb">Apple M1 8GB Unified Metal</option>
                  <option value="24_impossible_tiny_iot_512mb">
                    Ultra-Constrained 512MB RAM Node
                  </option>
                </select>
                <button
                  type="button"
                  className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                  onClick={() => void handleRefreshHardware()}
                  data-testid="cookbook-refresh-hw-btn"
                >
                  Refresh Hardware
                </button>
              </div>
            </div>

            {hwPassthroughRemedy ? (
              <div
                className="odysseus-card"
                role="status"
                aria-label="Container GPU Passthrough Diagnostic"
                data-testid="cookbook-passthrough-banner"
              >
                <strong>GPU detected on host, not passed through to container.</strong> Remedy:{" "}
                <code>{hwPassthroughRemedy}</code>
              </div>
            ) : null}
          </div>

          {/* Ranked Model Catalog */}
          <div className="odysseus-card" data-testid="cookbook-models-table">
            <div className="odysseus-inspector-header-bar">
              <h3>Recommended Local Models</h3>
              <div className="odysseus-row-wrap">
                <label htmlFor="cookbook-fit-filter">Filter by Fit:</label>
                <select
                  id="cookbook-fit-filter"
                  className="odysseus-input"
                  value={fitFilter}
                  onChange={(e) =>
                    setFitFilter(e.target.value as "all" | "yes" | "tight" | "no")
                  }
                  data-testid="cookbook-fit-filter"
                >
                  <option value="all">All Models</option>
                  <option value="yes">Fits (Green)</option>
                  <option value="tight">Tight (Amber)</option>
                  <option value="no">Too Large (OOM)</option>
                </select>
              </div>
            </div>

            <div className="odysseus-stack">
              {filteredModels.map((m) => (
                <div
                  key={m.model_id}
                  className="odysseus-card"
                  data-testid={`cookbook-model-row-${m.model_id}`}
                >
                  <div className="odysseus-inspector-header-bar">
                    <div>
                      <strong>{m.display_name}</strong> <code>({m.quant})</code> — Fit:{" "}
                      <span data-testid={`cookbook-fit-badge-${m.model_id}`}>
                        {m.fit.fits.toUpperCase()}
                      </span>{" "}
                      | Score: <code>{m.score}</code> | Est:{" "}
                      <code>{m.explain.predicted_tok_s_range}</code>
                    </div>
                    <div className="odysseus-row-wrap">
                      <button
                        type="button"
                        className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                        onClick={() => void handleDownloadModel(m.model_id, false)}
                        data-testid={`cookbook-download-btn-${m.model_id}`}
                      >
                        Download GGUF
                      </button>
                      <button
                        type="button"
                        className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
                        onClick={() => void handleStartServe(m.model_id, false)}
                        data-testid={`cookbook-serve-btn-${m.model_id}`}
                      >
                        Serve Model
                      </button>
                    </div>
                  </div>
                  <p className="odysseus-text-muted">{m.explain.why_it_fits}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Downloads, Engines, Serves, Benchmarks, Remote SSH */}
          <div className="odysseus-card" data-testid="cookbook-downloads-panel">
            <div className="odysseus-inspector-header-bar">
              <h3>Resumable Downloads & Disk Preflight</h3>
              <button
                type="button"
                className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
                onClick={() =>
                  void handleDownloadModel("Qwen/Qwen2.5-7B-Instruct-GGUF", true)
                }
                data-testid="cookbook-simulate-disk-full-btn"
              >
                Simulate Disk-Full Preflight
              </button>
            </div>
            {downloads.length === 0 ? (
              <p className="odysseus-text-muted">No active downloads yet.</p>
            ) : (
              downloads.map((d) => (
                <div key={d.id} data-testid={`cookbook-download-item-${d.id}`}>
                  <code>{d.model_id}</code> — State: <strong>{d.state}</strong> (Resumed{" "}
                  {d.resumed_count}x)
                  {d.failure_report ? (
                    <span data-testid="cookbook-download-failure-cause">
                      {" "}
                      | Cause: {d.failure_report.classified_cause} — Remedy:{" "}
                      {d.failure_report.remedy_steps[0]}
                    </span>
                  ) : null}
                </div>
              ))
            )}
          </div>

          <div className="odysseus-card" data-testid="cookbook-engines-panel">
            <div className="odysseus-inspector-header-bar">
              <h3>Inference Engines (Active llama.cpp: {engineInstalledVersion})</h3>
              <div className="odysseus-row-wrap">
                <button
                  type="button"
                  className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                  onClick={() => void handleInstallEngine(true)}
                  data-testid="cookbook-engine-dry-run-btn"
                >
                  Preflight Dry-Run
                </button>
                <button
                  type="button"
                  className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
                  onClick={() => void handleInstallEngine(false)}
                  data-testid="cookbook-install-engine-btn"
                >
                  Atomic Upgrade llama.cpp (b4150)
                </button>
              </div>
            </div>
            {engineDryRunReport ? (
              <p data-testid="cookbook-engine-status">{engineDryRunReport}</p>
            ) : null}
          </div>

          <div className="odysseus-card" data-testid="cookbook-serves-panel">
            <div className="odysseus-inspector-header-bar">
              <h3>Managed Serve Instances & Crash-Loop Guard</h3>
              <div className="odysseus-row-wrap">
                <button
                  type="button"
                  className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                  onClick={() =>
                    void handleStartServe("Qwen/Qwen2.5-0.5B-Instruct-GGUF", true)
                  }
                  data-testid="cookbook-crash-loop-btn"
                >
                  Simulate Crash-Loop
                </button>
                <button
                  type="button"
                  className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                  onClick={() => void handleRunBenchmark()}
                  data-testid="cookbook-run-bench-btn"
                >
                  Run 3-Context Benchmark
                </button>
              </div>
            </div>
            {serves.map((s) => (
              <div key={s.id} className="odysseus-row-wrap" data-testid={`serve-row-${s.id}`}>
                <span>
                  <code>{s.model_id}</code> on port <code>{s.port}</code> — State:{" "}
                  <strong data-testid="cookbook-serve-state">{s.state}</strong>
                </span>
                {s.state === "healthy" ? (
                  <button
                    type="button"
                    className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
                    onClick={() => void handleStopServe(s.id)}
                    data-testid="cookbook-stop-serve-btn"
                  >
                    Stop Serve
                  </button>
                ) : null}
              </div>
            ))}
            {benchmarkSummary ? (
              <p data-testid="cookbook-bench-summary">{benchmarkSummary}</p>
            ) : null}
          </div>

          <div className="odysseus-card" data-testid="cookbook-remotes-panel">
            <div className="odysseus-inspector-header-bar">
              <h3>Remote SSH GPU Hosts (ED25519 0600 + TOFU Pinning)</h3>
              <div className="odysseus-row-wrap">
                <button
                  type="button"
                  className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
                  onClick={handleConfirmTofu}
                  data-testid="cookbook-confirm-tofu-btn"
                >
                  Confirm TOFU Fingerprint
                </button>
                <button
                  type="button"
                  className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                  onClick={handleSimulateMitm}
                  data-testid="cookbook-simulate-mitm-btn"
                >
                  Simulate Host-Key Change
                </button>
              </div>
            </div>
            <p data-testid="cookbook-remote-status">
              Host <code>ubuntu@10.0.0.50:22</code> | Pin: <code>{remoteFingerprint}</code> |
              Status: <strong>{remoteHostStatus}</strong>
            </p>
          </div>
        </div>
      ) : null}

      {/* =================================================================== */}
      {/* 2. GALLERY & NON-DESTRUCTIVE TILED IMAGE EDITOR (`FE-WORK-08`)      */}
      {/* =================================================================== */}
      {activeTab === "gallery" ? (
        <div className="odysseus-stack" data-testid="gallery-workspace">
          <div className="odysseus-card">
            <h3>Image Generation & Safe Upload Guard (100 MP Limit, SVG Sanitizer, EXIF Strip)</h3>
            <div className="odysseus-row-wrap">
              <label htmlFor="gallery-prompt-input">Prompt:</label>
              <input
                id="gallery-prompt-input"
                className="odysseus-input"
                value={galleryPrompt}
                onChange={(e) => setGalleryPrompt(e.target.value)}
                data-testid="gallery-prompt-input"
              />
              <button
                type="button"
                className="odysseus-btn odysseus-btn-primary odysseus-btn-sm"
                onClick={() => void handleGenerateImage()}
                data-testid="gallery-generate-btn"
              >
                Generate Image
              </button>
              <button
                type="button"
                className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                onClick={() =>
                  setUploadGuardStatus(
                    "Rejected 10,000 MP PNG Decompression Bomb before pixel buffer allocation (< 5 ms).",
                  )
                }
                data-testid="gallery-upload-bomb-btn"
              >
                Test 10,000 MP Bomb Guard
              </button>
            </div>
            {uploadGuardStatus ? (
              <p data-testid="gallery-upload-guard-status">{uploadGuardStatus}</p>
            ) : null}
          </div>

          <div className="odysseus-card" data-testid="gallery-grid">
            <h3>Media Library ({mediaItems.length} items)</h3>
            <div className="odysseus-row-wrap">
              {mediaItems.map((it) => (
                <button
                  key={it.id}
                  type="button"
                  className={`odysseus-btn odysseus-btn-sm ${
                    selectedMediaId === it.id
                      ? "odysseus-btn-primary"
                      : "odysseus-btn-secondary"
                  }`}
                  onClick={() => setSelectedMediaId(it.id)}
                  data-testid={`gallery-item-${it.id}`}
                >
                  {it.filename} ({it.width}x{it.height}, {it.megapixels} MP)
                </button>
              ))}
            </div>
          </div>

          <div className="odysseus-card" data-testid="gallery-editor">
            <h3>Non-Destructive Tiled Image Editor (200+ Undo/Redo Steps, &lt; 600 MB RAM)</h3>
            <p data-testid="gallery-op-status">
              Active Media: <code>{selectedMediaId}</code> | Applied Ops:{" "}
              <strong data-testid="gallery-op-count">{editorOpCount}</strong> | Redo Stack:{" "}
              <strong data-testid="gallery-redo-count">{editorRedoCount}</strong> | Last Op
              Latency: <code>{editorLatencyMs} ms</code>
            </p>
            <div className="odysseus-row-wrap">
              <button
                type="button"
                className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                onClick={() => void handleApplyEditorOp("exposure", 0.15)}
                data-testid="gallery-op-exposure-btn"
              >
                + Exposure
              </button>
              <button
                type="button"
                className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                onClick={() => void handleApplyEditorOp("contrast", 1.1)}
                data-testid="gallery-op-contrast-btn"
              >
                + Contrast
              </button>
              <button
                type="button"
                className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                onClick={() => void handleApplyEditorOp("rotate", 90)}
                data-testid="gallery-op-rotate-btn"
              >
                Rotate 90°
              </button>
              <button
                type="button"
                className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                onClick={() => void handleApplyEditorOp("annotate_redact", 1)}
                data-testid="gallery-op-redact-btn"
              >
                Redact Box
              </button>
              <button
                type="button"
                className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                onClick={handleBatch200Ops}
                data-testid="gallery-op-200-btn"
              >
                Apply 200 Ops Stress
              </button>
              <button
                type="button"
                className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
                onClick={() => void handleUndoOp()}
                data-testid="gallery-undo-btn"
              >
                Undo
              </button>
              <button
                type="button"
                className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
                onClick={() => void handleRedoOp()}
                data-testid="gallery-redo-btn"
              >
                Redo
              </button>
            </div>

            <div className="odysseus-row-wrap">
              <label htmlFor="gallery-export-format">Export Format:</label>
              <select
                id="gallery-export-format"
                className="odysseus-input"
                value={exportFormat}
                onChange={(e) =>
                  setExportFormat(e.target.value as "png" | "jpeg" | "webp")
                }
                data-testid="gallery-export-format"
              >
                <option value="png">PNG</option>
                <option value="jpeg">JPEG</option>
                <option value="webp">WebP</option>
              </select>
              <label htmlFor="gallery-strip-exif-checkbox">
                <input
                  id="gallery-strip-exif-checkbox"
                  type="checkbox"
                  checked={stripExif}
                  onChange={(e) => setStripExif(e.target.checked)}
                  data-testid="gallery-strip-exif-checkbox"
                />{" "}
                Strip EXIF & GPS Metadata
              </label>
              <button
                type="button"
                className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
                onClick={() => void handleExportMedia()}
                data-testid="gallery-export-btn"
              >
                Export & Save Copy
              </button>
            </div>
            {exportStatus ? (
              <p data-testid="gallery-export-result">{exportStatus}</p>
            ) : null}
          </div>
        </div>
      ) : null}

      {/* =================================================================== */}
      {/* 3. VOICE CONVERSATION MODE (`FE-COMP-09`)                           */}
      {/* =================================================================== */}
      {activeTab === "voice" ? (
        <div className="odysseus-stack" data-testid="voice-mode-view">
          <div className="odysseus-card">
            <h3>Full-Screen Voice Conversation Mode (listen → think → speak)</h3>
            <p>
              Session: <code>{voiceSessionId}</code> | State:{" "}
              <strong data-testid="voice-state-badge">{voiceState}</strong> | TTS Runtime:{" "}
              <code>{kokoroStatus}</code>
            </p>
            <div className="odysseus-row-wrap">
              <button
                type="button"
                className="odysseus-btn odysseus-btn-secondary odysseus-btn-sm"
                onClick={() => void handleRunSttTest()}
                data-testid="voice-stt-btn"
              >
                Transcribe Reference Audio (STT)
              </button>
              <button
                type="button"
                className="odysseus-btn odysseus-btn-secondary odysseus-btn-sm"
                onClick={() =>
                  setMicDeniedMessage(
                    "Microphone permission denied by browser: falling back to text composer without crashing.",
                  )
                }
                data-testid="voice-mic-denied-btn"
              >
                Simulate Mic-Denied UX
              </button>
              <button
                type="button"
                className="odysseus-btn odysseus-btn-secondary odysseus-btn-sm"
                onClick={() => void handleStreamTtsTest()}
                data-testid="voice-tts-stream-btn"
              >
                Test Streaming Sentence TTS
              </button>
              <button
                type="button"
                className="odysseus-btn odysseus-btn-primary odysseus-btn-sm"
                onClick={() => void handleStartVoiceTurn()}
                data-testid="voice-start-turn-btn"
              >
                Start Voice Turn (Speak)
              </button>
              <button
                type="button"
                className="odysseus-btn odysseus-btn-secondary odysseus-btn-sm"
                onClick={() => void handleTriggerBargeIn()}
                data-testid="voice-barge-in-btn"
              >
                Barge-In Interrupt (&le; 150 ms)
              </button>
            </div>

            {sttText ? (
              <p data-testid="voice-stt-output">
                Transcript: <strong>{sttText}</strong> (WER: <code>{sttWer}</code>)
              </p>
            ) : null}
            {micDeniedMessage ? (
              <p role="status" aria-label="Microphone Permission Fallback" data-testid="voice-mic-denied-banner">
                {micDeniedMessage}
              </p>
            ) : null}
            {ttsFirstChunkEarly !== null ? (
              <p data-testid="voice-tts-stream-status">
                Sentence 1 audio emitted before LLM finished Sentence 2:{" "}
                <strong>{String(ttsFirstChunkEarly)}</strong>
              </p>
            ) : null}
            {bargeInLatencyMs !== null ? (
              <p data-testid="voice-barge-in-latency">
                Barge-in interrupted TTS + LLM stream in <strong>{bargeInLatencyMs} ms</strong>{" "}
                (&le; 150 ms requirement met).
              </p>
            ) : null}
          </div>
        </div>
      ) : null}

      {/* =================================================================== */}
      {/* 4. ADMIN CONSOLE & OPERATIONS (`FE-ADMIN-02..09`)                   */}
      {/* =================================================================== */}
      {activeTab === "admin" ? (
        <div className="odysseus-stack" data-testid="admin-ops-workspace">
          {/* 4.1 Providers Advanced (`FE-ADMIN-02`) */}
          <div className="odysseus-card" data-testid="admin-providers-section">
            <h3>Providers Advanced (Fallback Chains, Budgets, Replace-Only Vault)</h3>
            <div className="odysseus-row-wrap">
              <span>
                Primary: <strong>OpenAI Primary</strong> → Fallback:{" "}
                <code>prov_local_llama</code> | API Key:{" "}
                <code>sk-proj-...[REPLACE_ONLY]</code>
              </span>
              <label htmlFor="admin-provider-tools-select">supports_tools:</label>
              <select
                id="admin-provider-tools-select"
                className="odysseus-input"
                value={providerSupportsTools}
                onChange={(e) =>
                  setProviderSupportsTools(e.target.value as "auto" | "yes" | "no")
                }
                data-testid="admin-provider-tools-select"
              >
                <option value="auto">Auto</option>
                <option value="yes">Yes</option>
                <option value="no">No</option>
              </select>
              <button
                type="button"
                className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
                onClick={() => {
                  setProviderSavedBadge(
                    `Updated supports_tools=${providerSupportsTools} (API key remains replace-only masked)`,
                  );
                  void apiRequestJson("/api/admin/ops/providers/prov_openai_primary", {
                    method: "PATCH",
                    body: { supports_tools: providerSupportsTools },
                  });
                }}
                data-testid="admin-provider-save-btn"
              >
                Save Provider Policy
              </button>
            </div>
            {providerSavedBadge ? (
              <p data-testid="admin-provider-saved-badge">{providerSavedBadge}</p>
            ) : null}
          </div>

          {/* 4.2 Usage & Cost + Demo-Mode Redaction (`FE-ADMIN-03`) */}
          <div className="odysseus-card" data-testid="admin-usage-section">
            <div className="odysseus-inspector-header-bar">
              <h3>Usage & Cost Breakdown</h3>
              <button
                type="button"
                className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                onClick={() => void handleToggleDemoMode()}
                data-testid="admin-demo-mode-toggle"
              >
                {demoMode ? "Disable Demo-Mode Redaction" : "Enable Demo-Mode Redaction"}
              </button>
            </div>
            <ul data-testid="admin-usage-list">
              {usageRows.map((r) => (
                <li key={r.id}>
                  <code>{r.model_id}</code> — <strong>{r.chat_title}</strong> ({r.user_email}) — $
                  {r.cost_usd.toFixed(2)}
                </li>
              ))}
            </ul>
          </div>

          {/* 4.3 Exec Policy & Pattern Tester (`FE-ADMIN-04`) */}
          <div className="odysseus-card" data-testid="admin-policy-section">
            <h3>Exec Policy Editor & Pattern Tester</h3>
            <div className="odysseus-row-wrap">
              <label htmlFor="admin-policy-test-input">Command to Test:</label>
              <input
                id="admin-policy-test-input"
                className="odysseus-input"
                value={policyCommandInput}
                onChange={(e) => setPolicyCommandInput(e.target.value)}
                data-testid="admin-policy-test-input"
              />
              <button
                type="button"
                className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
                onClick={() => void handleTestExecPolicy()}
                data-testid="admin-policy-test-btn"
              >
                Test Policy Pattern
              </button>
            </div>
            {policyVerdict ? (
              <p data-testid="admin-policy-test-result">
                Verdict: <strong>{policyVerdict.verdict.toUpperCase()}</strong> (Rule:{" "}
                <code>{policyVerdict.matched_rule_id}</code> — {policyVerdict.description})
              </p>
            ) : null}
          </div>

          {/* 4.4 Health & Secret-Scrubbed Support Bundle (`FE-ADMIN-05`) */}
          <div className="odysseus-card" data-testid="admin-health-section">
            <div className="odysseus-inspector-header-bar">
              <h3>System Health & Secret-Scrubbed Support Bundle (&ge; 22 Secret Formats)</h3>
              <button
                type="button"
                className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
                onClick={() => void handleGenerateSupportBundle()}
                data-testid="admin-support-bundle-btn"
              >
                Generate Scrubbed Support Bundle
              </button>
            </div>
            {supportBundleOutput ? (
              <pre data-testid="admin-support-bundle-output">{supportBundleOutput}</pre>
            ) : null}
          </div>

          {/* 4.6 Backup & Restore with Dry-Run (`FE-ADMIN-07`) */}
          <div className="odysseus-card" data-testid="admin-backup-section">
            <h3>Consistent Backup & Restore (Checksum Manifest + Dry-Run)</h3>
            <div className="odysseus-row-wrap">
              <label htmlFor="admin-backup-passphrase">Passphrase:</label>
              <input
                id="admin-backup-passphrase"
                type="password"
                className="odysseus-input"
                value={backupPassphrase}
                onChange={(e) => setBackupPassphrase(e.target.value)}
                data-testid="admin-backup-passphrase"
              />
              <button
                type="button"
                className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
                onClick={() => void handleCreateBackup()}
                data-testid="admin-create-backup-btn"
              >
                Create Encrypted Backup
              </button>
              <button
                type="button"
                className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                onClick={() => void handleRestoreBackup(true)}
                data-testid="admin-restore-dry-run-btn"
              >
                Run Restore Dry-Run
              </button>
              <button
                type="button"
                className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                onClick={() => void handleRestoreBackup(false)}
                data-testid="admin-restore-full-btn"
              >
                Execute Full Restore
              </button>
            </div>
            {backupStatus ? (
              <p data-testid="admin-backup-status">{backupStatus}</p>
            ) : null}
          </div>

          {/* 4.7 Privacy: Residency, Export All My Data & Delete All My Data (`FE-ADMIN-08`) */}
          <div className="odysseus-card" data-testid="admin-privacy-section">
            <h3>Privacy, Zero-Telemetry Residency & GDPR Controls</h3>
            <div className="odysseus-row-wrap">
              <button
                type="button"
                className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                onClick={() => void handleExportPrivacyData()}
                data-testid="admin-privacy-export-btn"
              >
                Export All My Data (.zip)
              </button>
              <label htmlFor="admin-privacy-delete-input">Confirm Delete:</label>
              <input
                id="admin-privacy-delete-input"
                className="odysseus-input"
                placeholder="Type DELETE ALL MY DATA"
                value={privacyDeletePhrase}
                onChange={(e) => setPrivacyDeletePhrase(e.target.value)}
                data-testid="admin-privacy-delete-input"
              />
              <button
                type="button"
                className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                onClick={() => void handleDeletePrivacyData()}
                data-testid="admin-privacy-delete-btn"
              >
                Delete All My Data
              </button>
            </div>
            {privacyStatus ? (
              <p data-testid="admin-privacy-status">{privacyStatus}</p>
            ) : null}
          </div>

          {/* 4.8 Users & Role Privilege Matrix (`FE-ADMIN-09`) */}
          <div className="odysseus-card" data-testid="admin-users-section">
            <h3>Users & Privilege Matrix Preview</h3>
            <div className="odysseus-row-wrap">
              <label htmlFor="admin-role-preview-select">Preview Role:</label>
              <select
                id="admin-role-preview-select"
                className="odysseus-input"
                value={selectedRolePreview}
                onChange={(e) =>
                  setSelectedRolePreview(e.target.value as "admin" | "member" | "viewer")
                }
                data-testid="admin-role-preview-select"
              >
                <option value="admin">Admin (Full Control)</option>
                <option value="member">Member (Chat, Gallery, Self-Privacy)</option>
                <option value="viewer">Viewer (Read-Only)</option>
              </select>
              <span data-testid="admin-role-privileges-preview">
                Granted:{" "}
                <code>
                  {selectedRolePreview === "admin"
                    ? "chat.use, cookbook.manage, gallery.edit, voice.use, admin.*"
                    : selectedRolePreview === "member"
                      ? "chat.use, cookbook.view, gallery.edit, voice.use"
                      : "chat.read_only, cookbook.view, gallery.view"}
                </code>
              </span>
            </div>
          </div>
        </div>
      ) : null}
    </section>
  );
}
