import { useVirtualizer } from "@tanstack/react-virtual";
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { Dialog } from "../../design-system/primitives";
import type { ChatMessageNode } from "../../lib/contracts/api.gen";
import type { RunEventEnvelope } from "../../lib/contracts/events.gen";
import type { RunViewState } from "../../lib/runReducer";
import { useAppShellStore } from "../../lib/store";
import { AgentTimeline } from "../agent/timeline/AgentTimeline";
import { StreamingMarkdownMessage, ThinkingBlockView } from "./StreamingMarkdownMessage";

export interface VirtualizedMessageListProps {
  readonly chatId: string;
  readonly messages: ReadonlyArray<ChatMessageNode>;
  readonly allMessages: ReadonlyArray<ChatMessageNode>;
  readonly activeRun: RunViewState | null;
  readonly activeRunEvents?: ReadonlyArray<RunEventEnvelope>;
  readonly deepLinkMessageId?: string | null;
  readonly onEditMessage: (messageId: string, newContent: string) => Promise<void>;
  readonly onRegenerateMessage: (messageId: string) => Promise<void>;
  readonly onActivateBranch: (messageId: string) => Promise<void>;
  readonly onForkChat: (messageId: string) => Promise<void>;
  readonly onDeleteSubtree: (messageId: string) => Promise<void>;
  readonly onSuggestionClick: (prompt: string) => void;
  readonly onRetryRun?: () => void;
  readonly onContinueGenerating?: () => void;
  readonly onResolveApproval?: (
    approvalId: string,
    decision: "approve" | "deny",
    scope: "once" | "run" | "chat" | "always",
  ) => Promise<void>;
  readonly onOpenTimelinePanel?: () => void;
  readonly onOpenRunView?: (runId: string) => void;
  readonly onOpenArtifact?: (artifactId: string) => void;
  readonly onSendToArtifact?: (title: string, content: string) => void;
  readonly onQuoteSelection?: (quotedText: string) => void;
}

export function VirtualizedMessageList({
  chatId,
  messages,
  allMessages,
  activeRun,
  activeRunEvents = [],
  deepLinkMessageId,
  onEditMessage,
  onRegenerateMessage,
  onActivateBranch,
  onForkChat,
  onDeleteSubtree,
  onSuggestionClick,
  onRetryRun,
  onContinueGenerating,
  onResolveApproval,
  onOpenTimelinePanel,
  onOpenRunView,
  onOpenArtifact,
  onSendToArtifact,
  onQuoteSelection,
}: VirtualizedMessageListProps): React.ReactElement {
  const { t } = useTranslation();
  const {
    showReasoning,
    devRawMode,
    bookmarks,
    toggleBookmark,
    inChatSearchOpen,
    inChatSearchQuery,
    setInChatSearch,
    scrollPositions,
    saveScrollPosition,
  } = useAppShellStore();

  const parentRef = useRef<HTMLDivElement | null>(null);
  const [stuckToBottom, setStuckToBottom] = useState(true);
  const [unreadCount, setUnreadCount] = useState(0);
  const [focusedIndex, setFocusedIndex] = useState<number>(-1);
  const [editingMsgId, setEditingMsgId] = useState<string | null>(null);
  const [editingText, setEditingText] = useState("");
  const [expandedMetaIds, setExpandedMetaIds] = useState<Record<string, boolean>>({});
  const [feedbackByMsgId, setFeedbackByMsgId] = useState<Record<string, "up" | "down">>({});
  const [lightboxImage, setLightboxImage] = useState<{ src: string; alt: string } | null>(null);
  const [searchMatchCursor, setSearchMatchCursor] = useState(0);
  const [highlightedCitationIdx, setHighlightedCitationIdx] = useState<number | null>(null);

  // Throttled polite screen-reader announcement (updates at most once every 2s, never per token)
  const [srAnnouncement, setSrAnnouncement] = useState("");
  const lastSrUpdateRef = useRef<number>(0);

  const isRunStreaming =
    activeRun !== null &&
    (activeRun.status === "running" ||
      activeRun.status === "queued" ||
      activeRun.status === "waiting_approval");

  const liveRunText = useMemo(() => {
    if (!activeRun) return "";
    return activeRun.ordered_part_ids
      .map((pid) => activeRun.parts[pid])
      .filter((p) => p && p.type !== "thinking")
      .map((p) => p!.text)
      .join("");
  }, [activeRun]);

  const liveThinkingText = useMemo(() => {
    if (!activeRun) return "";
    return activeRun.ordered_part_ids
      .map((pid) => activeRun.parts[pid])
      .filter((p) => p && p.type === "thinking")
      .map((p) => p!.text)
      .join("");
  }, [activeRun]);

  useEffect(() => {
    if (!activeRun) return;
    const now = Date.now();
    if (activeRun.status === "completed") {
      setSrAnnouncement(
        `Assistant response completed (${liveRunText.split(/\s+/).filter(Boolean).length} words).`,
      );
      lastSrUpdateRef.current = now;
    } else if (isRunStreaming && now - lastSrUpdateRef.current >= 2000) {
      const words = liveRunText.split(/\s+/).filter(Boolean).length;
      setSrAnnouncement(`Assistant streaming response: ${words} words received.`);
      lastSrUpdateRef.current = now;
    }
  }, [activeRun, isRunStreaming, liveRunText]);

  // Build parent -> sorted siblings map for O(1) branch navigation (`‹ n/m ›`)
  const siblingsByParentKey = useMemo(() => {
    const map = new Map<string, ChatMessageNode[]>();
    for (const m of allMessages) {
      const key = m.parent_id ?? "__ROOT__";
      const list = map.get(key);
      if (list) {
        list.push(m);
      } else {
        map.set(key, [m]);
      }
    }
    for (const list of map.values()) {
      list.sort((a, b) => a.branch_index - b.branch_index);
    }
    return map;
  }, [allMessages]);

  // In-chat search matches across all active-branch messages
  const searchMatchedIndices = useMemo(() => {
    const q = inChatSearchQuery.trim().toLowerCase();
    if (!q) return [];
    const indices: number[] = [];
    messages.forEach((m, idx) => {
      if (m.content.toLowerCase().includes(q)) {
        indices.push(idx);
      }
    });
    return indices;
  }, [messages, inChatSearchQuery]);

  const virtualizer = useVirtualizer({
    count: messages.length,
    getScrollElement: () => parentRef.current,
    estimateSize: () => 96,
    overscan: 8,
  });

  // Scroll to bottom when stuckToBottom is true and new content arrives
  useEffect(() => {
    if (messages.length === 0) return;
    if (stuckToBottom) {
      const el = parentRef.current;
      if (el) {
        el.scrollTop = el.scrollHeight;
      }
      setUnreadCount(0);
    } else if (isRunStreaming) {
      setUnreadCount((c) => c + 1);
    }
  }, [messages.length, liveRunText, stuckToBottom, isRunStreaming]);

  // Restore scroll position on chat switch
  useEffect(() => {
    const saved = scrollPositions[chatId];
    if (typeof saved === "number" && parentRef.current) {
      parentRef.current.scrollTop = saved;
    } else {
      setStuckToBottom(true);
    }
  }, [chatId, scrollPositions]);

  // Deep link scroll (`#m=<id>`)
  useEffect(() => {
    if (!deepLinkMessageId || messages.length === 0) return;
    const idx = messages.findIndex((m) => m.id === deepLinkMessageId);
    if (idx !== -1) {
      setFocusedIndex(idx);
      virtualizer.scrollToIndex(idx, { align: "center" });
    }
  }, [deepLinkMessageId, messages, virtualizer]);

  // Jump to in-chat search match
  useEffect(() => {
    if (searchMatchedIndices.length === 0) return;
    const targetIdx = searchMatchedIndices[searchMatchCursor % searchMatchedIndices.length];
    if (targetIdx !== undefined) {
      setFocusedIndex(targetIdx);
      virtualizer.scrollToIndex(targetIdx, { align: "center" });
    }
  }, [searchMatchedIndices, searchMatchCursor, virtualizer]);

  // j / k keyboard navigation across messages
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent): void => {
      const activeEl = document.activeElement;
      const isInput =
        activeEl instanceof HTMLInputElement ||
        activeEl instanceof HTMLTextAreaElement ||
        activeEl instanceof HTMLSelectElement ||
        activeEl?.getAttribute("contenteditable") === "true";

      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "f") {
        e.preventDefault();
        setInChatSearch(true);
        return;
      }

      if (isInput || messages.length === 0) return;

      if (e.key === "j") {
        e.preventDefault();
        setFocusedIndex((prev) => {
          const next = Math.min(messages.length - 1, prev + 1);
          virtualizer.scrollToIndex(next, { align: "center" });
          return next;
        });
      } else if (e.key === "k") {
        e.preventDefault();
        setFocusedIndex((prev) => {
          const next = Math.max(0, prev <= 0 ? 0 : prev - 1);
          virtualizer.scrollToIndex(next, { align: "center" });
          return next;
        });
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [messages.length, setInChatSearch, virtualizer]);

  const handleScroll = useCallback((): void => {
    const el = parentRef.current;
    if (!el) return;
    const distanceFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    const isNearBottom = distanceFromBottom <= 64;
    setStuckToBottom(isNearBottom);
    if (isNearBottom) {
      setUnreadCount(0);
    }
    saveScrollPosition(chatId, el.scrollTop);
  }, [chatId, saveScrollPosition]);

  const jumpToBottom = (): void => {
    setStuckToBottom(true);
    setUnreadCount(0);
    if (messages.length > 0) {
      virtualizer.scrollToIndex(messages.length - 1, { align: "end" });
    }
    if (parentRef.current) {
      parentRef.current.scrollTop = parentRef.current.scrollHeight;
    }
  };

  const handleReadAloud = (text: string): void => {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      const utter = new SpeechSynthesisUtterance(text);
      window.speechSynthesis.speak(utter);
    }
  };

  const virtualItems = virtualizer.getVirtualItems();

  return (
    <div className="odysseus-message-list-shell">
      {/* Throttled polite live region for screen readers (FE-QA-02, Acceptance #9) */}
      <div
        className="sr-only"
        role="status"
        aria-live="polite"
        aria-atomic="true"
        data-testid="sr-stream-live-region"
      >
        {srAnnouncement}
      </div>

      {/* In-chat search bar (FE-MSG-13, Acceptance #6) */}
      {inChatSearchOpen ? (
        <div className="odysseus-inchat-search" role="search" data-testid="in-chat-search-bar">
          <input
            type="search"
            aria-label={t("inChatSearchPlaceholder")}
            placeholder={t("inChatSearchPlaceholder")}
            className="odysseus-input"
            value={inChatSearchQuery}
            onChange={(e) => {
              setInChatSearch(true, e.target.value);
              setSearchMatchCursor(0);
            }}
            data-testid="in-chat-search-input"
          />
          <span className="odysseus-search-count" data-testid="in-chat-search-count">
            {searchMatchedIndices.length > 0
              ? `${(searchMatchCursor % searchMatchedIndices.length) + 1}/${searchMatchedIndices.length}`
              : "0/0"}
          </span>
          <button
            type="button"
            className="odysseus-code-btn"
            onClick={() => setSearchMatchCursor((c) => c + 1)}
            disabled={searchMatchedIndices.length === 0}
            data-testid="in-chat-search-next"
          >
            ↓
          </button>
          <button
            type="button"
            className="odysseus-code-btn"
            onClick={() => setInChatSearch(false, "")}
            data-testid="in-chat-search-close"
          >
            ✕
          </button>
        </div>
      ) : null}

      <div
        ref={parentRef}
        className="odysseus-message-viewport"
        onScroll={handleScroll}
        data-testid="message-viewport"
        role="log"
        aria-label="Conversation messages"
      >
        {messages.length === 0 ? (
          <div className="odysseus-welcome-empty" data-testid="welcome-screen">
            <h2>{t("welcomeHeading")}</h2>
            <div className="odysseus-suggestion-grid">
              {[
                t("suggestionCode"),
                t("suggestionArchitecture"),
                t("suggestionTable"),
              ].map((sugg, idx) => (
                <button
                  key={idx}
                  type="button"
                  className="odysseus-suggestion-card"
                  onClick={() => onSuggestionClick(sugg)}
                  data-testid={`welcome-suggestion-${idx}`}
                >
                  {sugg}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div
            className="odysseus-virtual-inner"
            style={{
              height: `${virtualizer.getTotalSize()}px`,
              width: "100%",
              position: "relative",
            }}
          >
            {virtualItems.map((virtualRow) => {
              const msg = messages[virtualRow.index]!;
              const isLastAssistant =
                msg.role === "assistant" && virtualRow.index === messages.length - 1;
              const isStreamingThisMsg =
                isLastAssistant &&
                isRunStreaming &&
                (msg.run_id === activeRun?.run_id || msg.status === "streaming");

              const effectiveContent =
                isStreamingThisMsg && liveRunText.length > 0 ? liveRunText : msg.content;
              const siblings = siblingsByParentKey.get(msg.parent_id ?? "__ROOT__") ?? [msg];
              const siblingPos = siblings.findIndex((s) => s.id === msg.id);
              const isFocused = focusedIndex === virtualRow.index;
              const isBookmarked = bookmarks.includes(msg.id);
              const showMeta = Boolean(expandedMetaIds[msg.id]);

              return (
                <div
                  key={msg.id}
                  data-index={virtualRow.index}
                  ref={virtualizer.measureElement}
                  style={{
                    position: "absolute",
                    top: 0,
                    left: 0,
                    width: "100%",
                    transform: `translateY(${virtualRow.start}px)`,
                  }}
                >
                  <article
                    id={`msg-${msg.id}`}
                    className={`odysseus-msg odysseus-msg-${msg.role} ${isFocused ? "odysseus-msg-focused" : ""}`}
                    data-testid={`message-item-${msg.role}`}
                    data-message-id={msg.id}
                    data-focused-message={isFocused ? "true" : "false"}
                  >
                    <header className="odysseus-msg-header">
                      <span className="odysseus-msg-role">
                        {msg.role === "user" ? "You" : msg.model ?? "Odysseus"}
                      </span>
                      {msg.status === "aborted" ||
                      msg.status === "cancelled" ||
                      (isLastAssistant && activeRun?.status === "cancelled") ? (
                        <span className="odysseus-badge odysseus-badge-warning" data-testid="msg-stopped-badge">
                          {t("stoppedBadge")}
                        </span>
                      ) : null}

                      {/* Branch Navigator `‹ n/m ›` (FE-MSG-10, Acceptance #5) */}
                      {siblings.length > 1 ? (
                        <div className="odysseus-branch-nav" data-testid="branch-nav">
                          <button
                            type="button"
                            className="odysseus-code-btn"
                            disabled={siblingPos <= 0}
                            onClick={() => {
                              const prevSib = siblings[siblingPos - 1];
                              if (prevSib) void onActivateBranch(prevSib.id);
                            }}
                            aria-label="Previous branch"
                            data-testid="branch-prev"
                          >
                            ‹
                          </button>
                          <span className="odysseus-branch-label" data-testid="branch-indicator">
                            {t("branchIndicator", {
                              current: siblingPos + 1,
                              total: siblings.length,
                            })}
                          </span>
                          <button
                            type="button"
                            className="odysseus-code-btn"
                            disabled={siblingPos >= siblings.length - 1}
                            onClick={() => {
                              const nextSib = siblings[siblingPos + 1];
                              if (nextSib) void onActivateBranch(nextSib.id);
                            }}
                            aria-label="Next branch"
                            data-testid="branch-next"
                          >
                            ›
                          </button>
                        </div>
                      ) : null}
                    </header>

                    {/* Extended Thinking Block (FE-MSG-08) */}
                    {showReasoning &&
                    msg.role === "assistant" &&
                    (isLastAssistant && liveThinkingText ? liveThinkingText : null) ? (
                      <ThinkingBlockView
                        text={liveThinkingText}
                        isStreaming={isStreamingThisMsg}
                      />
                    ) : null}

                    {/* Attachments in message (FE-MSG-18) */}
                    {msg.attachment_ids && msg.attachment_ids.length > 0 ? (
                      <div className="odysseus-msg-attachments" data-testid="msg-attachments">
                        {msg.attachment_ids.map((sha) => (
                          <a
                            key={sha}
                            href={`/api/attachments/${sha}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="odysseus-attachment-card"
                          >
                            📎 Attachment {sha.slice(0, 8)}
                          </a>
                        ))}
                      </div>
                    ) : null}

                    {/* Message Body or Inline Edit Mode */}
                    {editingMsgId === msg.id ? (
                      <div className="odysseus-msg-edit-box" data-testid="msg-edit-box">
                        <textarea
                          aria-label="Edit message content"
                          className="odysseus-input"
                          value={editingText}
                          onChange={(e) => setEditingText(e.target.value)}
                          rows={3}
                          data-testid="msg-edit-input"
                        />
                        <div className="odysseus-row-wrap">
                          <button
                            type="button"
                            className="odysseus-btn odysseus-btn-primary odysseus-btn-sm"
                            onClick={() => {
                              const nextText = editingText.trim();
                              if (nextText) {
                                setEditingMsgId(null);
                                void onEditMessage(msg.id, nextText);
                              }
                            }}
                            data-testid="msg-edit-submit"
                          >
                            Save & Submit
                          </button>
                          <button
                            type="button"
                            className="odysseus-btn odysseus-btn-secondary odysseus-btn-sm"
                            onClick={() => setEditingMsgId(null)}
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    ) : (
                      <StreamingMarkdownMessage
                        text={effectiveContent}
                        isStreaming={isStreamingThisMsg}
                        onOpenLightbox={(src, alt) => setLightboxImage({ src, alt })}
                        onCitationClick={(idx) => setHighlightedCitationIdx(idx)}
                      />
                    )}

                    {/* Inline Agent Timeline + Tool Calls & Pending Approvals from RunViewState (FE-AGENT-01..05) */}
                    {isLastAssistant &&
                    activeRun &&
                    (activeRun.ordered_tool_call_ids.length > 0 ||
                      activeRun.ordered_step_ids.length > 0 ||
                      Object.keys(activeRun.artifacts).length > 0 ||
                      Object.keys(activeRun.subagents).length > 0 ||
                      activeRun.plan.length > 0) ? (
                      <div className="odysseus-msg-tools" data-testid="msg-tool-calls">
                        <AgentTimeline
                          runState={activeRun}
                          events={activeRunEvents}
                          presentation="inline"
                          onOpenInSidePanel={onOpenTimelinePanel}
                          onOpenRunView={onOpenRunView}
                          onOpenArtifact={onOpenArtifact}
                          onApprovalResolved={(payload) => {
                            if (onResolveApproval) {
                              void onResolveApproval(
                                payload.approvalId,
                                payload.decision,
                                payload.scope,
                              );
                            }
                          }}
                        />
                        {activeRun.ordered_tool_call_ids.map((cid) => {
                          const tc = activeRun.tool_calls[cid];
                          if (!tc) return null;
                          return (
                            <div
                              key={cid}
                              className="odysseus-tool-chip"
                              data-testid={`tool-call-card-${tc.name}`}
                            >
                              <div className="odysseus-tool-chip-header">
                                <strong>🛠 {tc.name}</strong>
                                <span className="odysseus-badge">{tc.status}</span>
                              </div>
                              {tc.status === "waiting_approval" &&
                              tc.approval_id &&
                              onResolveApproval ? (
                                <div
                                  className="odysseus-approval-banner"
                                  data-testid="approval-banner"
                                >
                                  <p>Approval required for {tc.name}</p>
                                  <div className="odysseus-row-wrap">
                                    <button
                                      type="button"
                                      className="odysseus-btn odysseus-btn-primary odysseus-btn-sm"
                                      onClick={() =>
                                        void onResolveApproval(tc.approval_id!, "approve", "once")
                                      }
                                      data-testid="approve-once-btn"
                                    >
                                      Approve Once
                                    </button>
                                    <button
                                      type="button"
                                      className="odysseus-btn odysseus-btn-danger odysseus-btn-sm"
                                      onClick={() =>
                                        void onResolveApproval(tc.approval_id!, "deny", "once")
                                      }
                                      data-testid="deny-approval-btn"
                                    >
                                      Deny
                                    </button>
                                  </div>
                                </div>
                              ) : null}
                            </div>
                          );
                        })}
                      </div>
                    ) : null}

                    {/* Citations / Sources Drawer & Hover Card (FE-MSG-09) */}
                    {isLastAssistant &&
                    activeRun &&
                    (activeRun.citations.length > 0 || activeRun.sources_opened.length > 0) ? (
                      <div className="odysseus-sources-drawer" data-testid="sources-drawer">
                        <strong>
                          Sources (
                          {activeRun.citations.length > 0
                            ? activeRun.citations.length
                            : activeRun.sources_opened.length}
                          )
                        </strong>
                        {highlightedCitationIdx !== null ? (
                          <div
                            className="odysseus-card"
                            role="status"
                            aria-label="Citation preview card"
                            data-testid="citation-hover-card"
                          >
                            {(() => {
                              const found = activeRun.citations.find(
                                (c, idx) => Number(c.id ?? idx + 1) === highlightedCitationIdx,
                              );
                              if (!found) {
                                return (
                                  <span className="odysseus-badge odysseus-badge-danger">
                                    [{highlightedCitationIdx}] Unverified / Dangling source reference
                                  </span>
                                );
                              }
                              const dom = String(found.domain ?? "web");
                              return (
                                <div className="odysseus-row-wrap">
                                  <img
                                    src={`/api/knowledge/favicon?domain=${encodeURIComponent(dom)}`}
                                    alt=""
                                    width={16}
                                    height={16}
                                  />
                                  <strong>
                                    [{highlightedCitationIdx}] {String(found.title ?? found.url ?? "")}
                                  </strong>
                                  <span className="odysseus-badge">{dom}</span>
                                  {found.snippet ? (
                                    <span className="odysseus-text-muted">
                                      {String(found.snippet)}
                                    </span>
                                  ) : null}
                                </div>
                              );
                            })()}
                          </div>
                        ) : null}
                        <ul>
                          {activeRun.citations.length > 0
                            ? activeRun.citations.map((cite, i) => {
                                const cid = Number(cite.id ?? i + 1);
                                const rawUrl = String(cite.url ?? "");
                                const rawTitle = String(cite.title ?? rawUrl);
                                const rawSnippet = cite.snippet ? String(cite.snippet) : "";
                                const domain = cite.domain
                                  ? String(cite.domain)
                                  : (() => {
                                      try {
                                        return new URL(rawUrl).hostname;
                                      } catch {
                                        return "web";
                                      }
                                    })();
                                return (
                                  <li
                                    key={`cite_${cid}_${i}`}
                                    data-testid={`source-citation-item-${cid}`}
                                    data-highlighted={
                                      highlightedCitationIdx === cid ? "true" : "false"
                                    }
                                  >
                                    <img
                                      src={`/api/knowledge/favicon?domain=${encodeURIComponent(domain)}`}
                                      alt=""
                                      width={14}
                                      height={14}
                                    />{" "}
                                    <a href={rawUrl} target="_blank" rel="noopener noreferrer">
                                      [{cid}] {rawTitle}
                                    </a>
                                    {rawSnippet ? (
                                      <span className="odysseus-text-muted"> — {rawSnippet}</span>
                                    ) : null}
                                  </li>
                                );
                              })
                            : activeRun.sources_opened.map((src, i) => (
                                <li key={i}>
                                  <a href={src.url} target="_blank" rel="noopener noreferrer">
                                    [{i + 1}] {src.title || src.url}
                                  </a>
                                </li>
                              ))}
                        </ul>
                      </div>
                    ) : null}

                    {/* Error / Length-Truncated Recovery Card (FE-MSG-14) */}
                    {isLastAssistant && activeRun?.error ? (
                      <div className="odysseus-error" role="alert" data-testid="run-error-card">
                        <p>
                          <strong>{activeRun.error.code}:</strong> {activeRun.error.message}
                        </p>
                        {onRetryRun ? (
                          <button
                            type="button"
                            className="odysseus-btn odysseus-btn-secondary odysseus-btn-sm"
                            onClick={onRetryRun}
                            data-testid="run-retry-btn"
                          >
                            {t("retryRun")}
                          </button>
                        ) : null}
                      </div>
                    ) : null}

                    {isLastAssistant &&
                    activeRun?.finish_reason === "length" &&
                    onContinueGenerating ? (
                      <div className="odysseus-row-wrap">
                        <button
                          type="button"
                          className="odysseus-btn odysseus-btn-secondary odysseus-btn-sm"
                          onClick={onContinueGenerating}
                          data-testid="continue-generating-btn"
                        >
                          {t("continueGenerating")}
                        </button>
                      </div>
                    ) : null}

                    {/* Message Actions Footer (FE-MSG-10, FE-MSG-11) */}
                    <footer className="odysseus-msg-actions">
                      <button
                        type="button"
                        className="odysseus-code-btn"
                        onClick={() => {
                          if (typeof navigator !== "undefined" && navigator.clipboard) {
                            void navigator.clipboard.writeText(effectiveContent).catch(() => {});
                          }
                        }}
                        data-testid="msg-copy-btn"
                      >
                        {t("copyText")}
                      </button>

                      {msg.role === "user" ? (
                        <button
                          type="button"
                          className="odysseus-code-btn"
                          onClick={() => {
                            setEditingMsgId(msg.id);
                            setEditingText(msg.content);
                          }}
                          data-testid="msg-edit-btn"
                        >
                          {t("editMessage")}
                        </button>
                      ) : (
                        <button
                          type="button"
                          className="odysseus-code-btn"
                          onClick={() => void onRegenerateMessage(msg.id)}
                          data-testid="msg-regenerate-btn"
                        >
                          {t("regenerateMessage")}
                        </button>
                      )}

                      <button
                        type="button"
                        className="odysseus-code-btn"
                        onClick={() => void onForkChat(msg.id)}
                        data-testid="msg-fork-btn"
                      >
                        {t("forkChat")}
                      </button>

                      {onSendToArtifact ? (
                        <button
                          type="button"
                          className="odysseus-code-btn"
                          onClick={() =>
                            onSendToArtifact(
                              `Message ${msg.id.slice(-6)}`,
                              effectiveContent,
                            )
                          }
                          data-testid="msg-send-to-artifact-btn"
                        >
                          Send to Artifact
                        </button>
                      ) : null}

                      {onQuoteSelection ? (
                        <button
                          type="button"
                          className="odysseus-code-btn"
                          onClick={() =>
                            onQuoteSelection(
                              window.getSelection()?.toString().trim() ||
                                effectiveContent.slice(0, 120),
                            )
                          }
                          data-testid="msg-quote-reply-btn"
                        >
                          Quote
                        </button>
                      ) : null}

                      <button
                        type="button"
                        className="odysseus-code-btn"
                        onClick={() => handleReadAloud(effectiveContent)}
                        aria-label="Read message aloud"
                      >
                        🔊
                      </button>

                      <button
                        type="button"
                        className="odysseus-code-btn"
                        onClick={() => toggleBookmark(msg.id)}
                        aria-pressed={isBookmarked}
                        aria-label="Bookmark message"
                        data-testid="msg-bookmark-btn"
                      >
                        {isBookmarked ? "★" : "☆"}
                      </button>

                      {msg.role === "assistant" ? (
                        <>
                          <button
                            type="button"
                            className="odysseus-code-btn"
                            aria-pressed={feedbackByMsgId[msg.id] === "up"}
                            onClick={() =>
                              setFeedbackByMsgId((f) => ({ ...f, [msg.id]: "up" }))
                            }
                            aria-label="Helpful response"
                          >
                            👍
                          </button>
                          <button
                            type="button"
                            className="odysseus-code-btn"
                            aria-pressed={feedbackByMsgId[msg.id] === "down"}
                            onClick={() =>
                              setFeedbackByMsgId((f) => ({ ...f, [msg.id]: "down" }))
                            }
                            aria-label="Unhelpful response"
                          >
                            👎
                          </button>
                        </>
                      ) : null}

                      <button
                        type="button"
                        className="odysseus-code-btn"
                        onClick={() =>
                          setExpandedMetaIds((m) => ({ ...m, [msg.id]: !m[msg.id] }))
                        }
                        data-testid="msg-meta-toggle"
                      >
                        Info
                      </button>

                      <button
                        type="button"
                        className="odysseus-code-btn"
                        onClick={() => void onDeleteSubtree(msg.id)}
                        aria-label="Delete message subtree"
                      >
                        🗑
                      </button>
                    </footer>

                    {/* Per-message metadata panel (FE-MSG-11) */}
                    {showMeta ? (
                      <div className="odysseus-msg-meta" data-testid="msg-metadata-panel">
                        <span>Model: {msg.model ?? activeRun?.model ?? "default"}</span>
                        <span>
                          Tokens In: {Number(msg.usage?.input ?? activeRun?.usage.input ?? 0)}
                        </span>
                        <span>
                          Tokens Out: {Number(msg.usage?.output ?? activeRun?.usage.output ?? 0)}
                        </span>
                        <span>
                          Cost: ${Number(msg.usage?.cost ?? activeRun?.usage.cost ?? 0).toFixed(4)}
                        </span>
                      </div>
                    ) : null}

                    {/* Raw JSON view in Dev Mode (FE-MSG-10) */}
                    {devRawMode ? (
                      <pre className="odysseus-raw-json" data-testid="msg-raw-json">
                        {JSON.stringify(msg, null, 2)}
                      </pre>
                    ) : null}
                  </article>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Floating Jump-to-latest pill when scrolled up (FE-MSG-12, Acceptance #6) */}
      {!stuckToBottom && messages.length > 0 ? (
        <button
          type="button"
          className="odysseus-jump-pill"
          onClick={jumpToBottom}
          data-testid="jump-to-latest-pill"
        >
          {t("jumpToLatest", { count: unreadCount })}
        </button>
      ) : null}

      {/* Image Lightbox Modal (FE-MSG-06) */}
      <Dialog
        open={Boolean(lightboxImage)}
        title={lightboxImage?.alt ?? "Image Preview"}
        onClose={() => setLightboxImage(null)}
        testId="image-lightbox-modal"
      >
        {lightboxImage ? (
          <div className="odysseus-lightbox-body">
            <img src={lightboxImage.src} alt={lightboxImage.alt} className="odysseus-lightbox-img" />
            <a
              href={lightboxImage.src}
              download
              className="odysseus-btn odysseus-btn-secondary odysseus-btn-sm"
            >
              Download Image
            </a>
          </div>
        ) : null}
      </Dialog>
    </div>
  );
}
