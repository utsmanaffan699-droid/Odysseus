import React, { useEffect, useMemo, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import {
  type CodeBlockMeta,
  type MarkdownBlock,
  type TableBlockMeta,
  splitMarkdownBlocks,
} from "../../lib/markdown";
import { useAppShellStore } from "../../lib/store";

interface CodeBlockViewProps {
  readonly block: MarkdownBlock;
  readonly meta: CodeBlockMeta;
}

function RichCodeBlock({ block, meta }: CodeBlockViewProps): React.ReactElement {
  const { t } = useTranslation();
  const [copied, setCopied] = useState(false);
  const [wrap, setWrap] = useState(false);
  const [showLineNumbers, setShowLineNumbers] = useState(false);
  const [collapsed, setCollapsed] = useState(meta.lineCount > 30 && block.closed);
  const [diffMode, setDiffMode] = useState<"unified" | "split">("unified");

  useEffect(() => {
    // Trigger lazy chunk preload for Shiki syntax highlighter
    void import("../../lib/lazy/shikiHighlighter");
  }, []);

  const handleCopy = (): void => {
    if (typeof navigator !== "undefined" && navigator.clipboard) {
      void navigator.clipboard.writeText(meta.code).catch(() => {});
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const handleDownload = (): void => {
    const ext =
      meta.language === "python"
        ? "py"
        : meta.language === "typescript"
          ? "ts"
          : meta.language === "javascript"
            ? "js"
            : "txt";
    const fname = meta.filename ?? `snippet.${ext}`;
    const blob = new Blob([meta.code], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = fname;
    a.click();
    URL.revokeObjectURL(url);
  };

  const lines = useMemo(() => meta.code.split("\n"), [meta.code]);
  const visibleLines = collapsed ? lines.slice(0, 15) : lines;

  return (
    <div
      className={`odysseus-code-block ${meta.isTerminal ? "odysseus-code-terminal" : ""} ${meta.isDiff ? "odysseus-code-diff" : ""}`.trim()}
      data-block-hash={block.hash}
      data-language={meta.language}
      data-wrap={wrap ? "true" : "false"}
      data-testid="code-block"
      role="region"
      aria-label={`Code block ${meta.filename ?? meta.language}`}
    >
      <div className="odysseus-code-header">
        <div className="odysseus-code-title-group">
          <span className="odysseus-code-lang">{meta.language}</span>
          {meta.filename ? (
            <span className="odysseus-code-filename" data-testid="code-filename">
              {meta.filename}
            </span>
          ) : null}
        </div>
        <div className="odysseus-code-actions">
          {meta.isDiff ? (
            <button
              type="button"
              className="odysseus-code-btn"
              onClick={() => setDiffMode((m) => (m === "unified" ? "split" : "unified"))}
              data-testid="code-diff-toggle"
            >
              {diffMode === "unified" ? "Side-by-side" : "Unified"}
            </button>
          ) : null}
          <button
            type="button"
            className="odysseus-code-btn"
            onClick={() => setWrap((w) => !w)}
            aria-pressed={wrap}
            data-testid="code-wrap-toggle"
          >
            Wrap
          </button>
          <button
            type="button"
            className="odysseus-code-btn"
            onClick={() => setShowLineNumbers((ln) => !ln)}
            aria-pressed={showLineNumbers}
            data-testid="code-lines-toggle"
          >
            #
          </button>
          {meta.lineCount > 30 ? (
            <button
              type="button"
              className="odysseus-code-btn"
              onClick={() => setCollapsed((c) => !c)}
              data-testid="code-collapse-toggle"
            >
              {collapsed ? `Expand (${meta.lineCount} lines)` : "Collapse"}
            </button>
          ) : null}
          <button
            type="button"
            className="odysseus-code-btn"
            onClick={() => useAppShellStore.getState().toggleInspector()}
            data-testid="code-open-canvas-btn"
          >
            Canvas
          </button>
          <button
            type="button"
            className="odysseus-code-btn"
            onClick={handleDownload}
            data-testid="code-download-btn"
          >
            Download
          </button>
          <button
            type="button"
            className="odysseus-code-btn"
            onClick={handleCopy}
            data-testid="code-copy-btn"
          >
            {copied ? t("copiedText") : t("copyText")}
          </button>
        </div>
      </div>
      {meta.isDiff && diffMode === "split" ? (
        <div className="odysseus-diff-split" data-testid="code-diff-split">
          <pre className="odysseus-code-pre">
            <code>
              {visibleLines
                .filter((l) => !l.startsWith("+") || l.startsWith("+++"))
                .map((line, idx) => (
                  <div
                    key={idx}
                    className={
                      line.startsWith("-") && !line.startsWith("---")
                        ? "diff-line diff-del"
                        : "diff-line"
                    }
                  >
                    <span>{line}</span>
                  </div>
                ))}
            </code>
          </pre>
          <pre className="odysseus-code-pre">
            <code>
              {visibleLines
                .filter((l) => !l.startsWith("-") || l.startsWith("---"))
                .map((line, idx) => (
                  <div
                    key={idx}
                    className={
                      line.startsWith("+") && !line.startsWith("+++")
                        ? "diff-line diff-add"
                        : "diff-line"
                    }
                  >
                    <span>{line}</span>
                  </div>
                ))}
            </code>
          </pre>
        </div>
      ) : (
        <pre className={`odysseus-code-pre ${wrap ? "odysseus-code-pre-wrap" : ""}`}>
          <code>
            {visibleLines.map((line, idx) => {
              const diffCls =
                meta.isDiff && line.startsWith("+") && !line.startsWith("+++")
                  ? "diff-line diff-add"
                  : meta.isDiff && line.startsWith("-") && !line.startsWith("---")
                    ? "diff-line diff-del"
                    : "diff-line";
              return (
                <div key={idx} className={diffCls}>
                  {showLineNumbers ? (
                    <span className="odysseus-code-ln" aria-hidden="true">
                      {idx + 1}
                    </span>
                  ) : null}
                  <span>{line}</span>
                </div>
              );
            })}
            {collapsed ? (
              <div className="odysseus-code-collapsed-notice">
                … {meta.lineCount - 15} more lines
              </div>
            ) : null}
          </code>
        </pre>
      )}
    </div>
  );
}

function RichTableBlock({
  block,
  meta,
}: {
  readonly block: MarkdownBlock;
  readonly meta: TableBlockMeta;
}): React.ReactElement {
  const [copiedMode, setCopiedMode] = useState<"csv" | "md" | null>(null);

  const copyTable = (mode: "csv" | "md"): void => {
    const payload = mode === "csv" ? meta.csv : meta.markdown;
    if (typeof navigator !== "undefined" && navigator.clipboard) {
      void navigator.clipboard.writeText(payload).catch(() => {});
    }
    setCopiedMode(mode);
    setTimeout(() => setCopiedMode(null), 1200);
  };

  return (
    <div className="odysseus-table-container" data-block-hash={block.hash} data-testid="md-table-block">
      <div className="odysseus-table-toolbar">
        <button
          type="button"
          className="odysseus-code-btn"
          onClick={() => copyTable("csv")}
          data-testid="copy-table-csv"
        >
          {copiedMode === "csv" ? "Copied CSV" : "Copy CSV"}
        </button>
        <button
          type="button"
          className="odysseus-code-btn"
          onClick={() => copyTable("md")}
          data-testid="copy-table-md"
        >
          {copiedMode === "md" ? "Copied MD" : "Copy Markdown"}
        </button>
      </div>
      {/* Safe sanitized HTML generated by parseTableBlock in lib/markdown.ts */}
      <div dangerouslySetInnerHTML={{ __html: block.html }} />
    </div>
  );
}

function SingleBlockRenderer({ block }: { readonly block: MarkdownBlock }): React.ReactElement {
  useEffect(() => {
    if (block.kind === "math") {
      void import("../../lib/lazy/katexRenderer");
    } else if (block.kind === "mermaid") {
      void import("../../lib/lazy/mermaidRenderer");
    }
  }, [block.kind]);

  if (block.kind === "code" && block.codeMeta) {
    return <RichCodeBlock block={block} meta={block.codeMeta} />;
  }
  if (block.kind === "table" && block.tableMeta) {
    return <RichTableBlock block={block} meta={block.tableMeta} />;
  }
  // Centralized sanitized rendering path (FE-QA-06): block.html has all raw HTML escaped and URLs sanitized
  return (
    <div
      className="odysseus-md-block"
      data-block-hash={block.hash}
      data-block-closed={block.closed ? "true" : "false"}
      dangerouslySetInnerHTML={{ __html: block.html }}
    />
  );
}

const MemoizedClosedBlock = React.memo(
  SingleBlockRenderer,
  (prev, next) => prev.block.closed && next.block.closed && prev.block.hash === next.block.hash,
);

export interface StreamingMarkdownProps {
  readonly text: string;
  readonly isStreaming: boolean;
  readonly onOpenLightbox?: (src: string, alt: string) => void;
  readonly onCitationClick?: (index: number) => void;
}

export function StreamingMarkdownMessage({
  text,
  isStreaming,
  onOpenLightbox,
  onCitationClick,
}: StreamingMarkdownProps): React.ReactElement {
  const [coalescedText, setCoalescedText] = useState(text);
  const rafRef = useRef<number | null>(null);
  const latestTextRef = useRef(text);
  latestTextRef.current = text;

  useEffect(() => {
    if (!isStreaming) {
      if (rafRef.current !== null) {
        cancelAnimationFrame(rafRef.current);
        rafRef.current = null;
      }
      setCoalescedText(text);
      return;
    }

    if (rafRef.current === null) {
      rafRef.current = requestAnimationFrame(() => {
        rafRef.current = null;
        setCoalescedText(latestTextRef.current);
      });
    }
  }, [text, isStreaming]);

  useEffect(() => {
    return () => {
      if (rafRef.current !== null) {
        cancelAnimationFrame(rafRef.current);
      }
    };
  }, []);

  const effectiveText = isStreaming ? coalescedText : text;
  const blocks = useMemo(
    () => splitMarkdownBlocks(effectiveText, isStreaming),
    [effectiveText, isStreaming],
  );
  const streamContainerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const el = streamContainerRef.current;
    if (!el) return;
    const handleContainerClick = (e: MouseEvent): void => {
      const target = e.target as HTMLElement | null;
      if (!target) return;
      const imgSrc = target.getAttribute("data-lightbox-src");
      if (imgSrc && onOpenLightbox) {
        onOpenLightbox(imgSrc, target.getAttribute("alt") ?? "Image");
        return;
      }
      const citationIdx = target.getAttribute("data-citation-index");
      if (citationIdx && onCitationClick) {
        onCitationClick(Number.parseInt(citationIdx, 10));
      }
    };
    el.addEventListener("click", handleContainerClick);
    return () => el.removeEventListener("click", handleContainerClick);
  }, [onOpenLightbox, onCitationClick]);

  return (
    <div
      ref={streamContainerRef}
      className="odysseus-markdown-stream"
      data-testid="markdown-stream"
      data-streaming={isStreaming ? "true" : "false"}
    >
      {blocks.map((block) =>
        block.closed ? (
          <MemoizedClosedBlock key={`closed_${block.index}_${block.hash}`} block={block} />
        ) : (
          <SingleBlockRenderer key={`open_${block.index}`} block={block} />
        ),
      )}
    </div>
  );
}

export function ThinkingBlockView({
  text,
  isStreaming,
  durationMs = 0,
}: {
  readonly text: string;
  readonly isStreaming: boolean;
  readonly durationMs?: number;
}): React.ReactElement {
  const { t } = useTranslation();
  const [expanded, setExpanded] = useState(false);
  const [elapsedSec, setElapsedSec] = useState(
    Math.max(1, Math.round(durationMs / 1000) || 1),
  );

  useEffect(() => {
    if (!isStreaming) {
      if (durationMs > 0) {
        setElapsedSec(Math.max(1, Math.round(durationMs / 1000)));
      }
      return;
    }
    const timer = setInterval(() => {
      setElapsedSec((s) => s + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [isStreaming, durationMs]);

  return (
    <div className="odysseus-thinking-block" data-testid="thinking-block">
      <button
        type="button"
        className="odysseus-thinking-header"
        aria-expanded={expanded}
        onClick={() => setExpanded((e) => !e)}
        data-testid="thinking-toggle"
      >
        <span className="odysseus-thinking-icon" aria-hidden="true">
          {expanded ? "▾" : "▸"}
        </span>
        <span>
          {isStreaming
            ? t("thinkingStreaming", { seconds: elapsedSec })
            : t("thoughtFinished", { seconds: elapsedSec })}
        </span>
      </button>
      {expanded ? (
        <div className="odysseus-thinking-body" data-testid="thinking-content">
          {text}
        </div>
      ) : null}
    </div>
  );
}
