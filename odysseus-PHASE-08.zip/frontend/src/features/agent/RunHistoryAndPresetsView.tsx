import React, { useCallback, useEffect, useState } from "react";
import { OdysseusApiClient } from "../../lib/contracts/api.gen";
import { validateExecApprovalPattern } from "./approvalSecurity";

const apiClient = new OdysseusApiClient();

export interface RunHistoryRow {
  readonly id: string;
  readonly chat_id: string;
  readonly mode: string;
  readonly model: string;
  readonly status: string;
  readonly finish_reason: string;
  readonly cost_usd: number;
  readonly created_at: string;
  readonly finished_at: string | null;
}

export interface AgentPresetItem {
  readonly id: string;
  readonly name: string;
  readonly description: string;
  readonly system_prompt: string;
  readonly model: string;
  readonly mode: string;
  readonly allowed_tools: ReadonlyArray<string>;
}

export interface ExecPolicyRuleItem {
  readonly id: string;
  readonly tool_name: string;
  readonly pattern: string;
  readonly scope: string;
  readonly created_at: string;
}

export interface RunHistoryAndPresetsModalProps {
  readonly open: boolean;
  readonly initialTab?: "runs" | "presets" | "policies";
  readonly onClose: () => void;
  readonly onOpenRun?: (runId: string) => void;
  readonly onApplyPreset?: (preset: AgentPresetItem) => void;
}

export const RunHistoryAndPresetsModal: React.FC<
  RunHistoryAndPresetsModalProps
> = ({ open, initialTab = "runs", onClose, onOpenRun, onApplyPreset }) => {
  const [activeTab, setActiveTab] = useState<"runs" | "presets" | "policies">(
    initialTab,
  );
  const [runs, setRuns] = useState<ReadonlyArray<RunHistoryRow>>([]);
  const [statusFilter, setStatusFilter] = useState<string>("");
  const [modelFilter, setModelFilter] = useState<string>("");
  const [sortBy, setSortBy] = useState<"recent" | "cost" | "duration">("recent");
  const [triageOnly, setTriageOnly] = useState<boolean>(false);
  const [selectedRunIds, setSelectedRunIds] = useState<Record<string, boolean>>(
    {},
  );

  // Presets state (FE-AGENT-13)
  const [presets, setPresets] = useState<ReadonlyArray<AgentPresetItem>>([]);
  const [newPresetName, setNewPresetName] = useState<string>("");
  const [newPresetDesc, setNewPresetDesc] = useState<string>("");
  const [newPresetPrompt, setNewPresetPrompt] = useState<string>("");

  // Exec Policies state (FE-ADMIN-05)
  const [rules, setRules] = useState<ReadonlyArray<ExecPolicyRuleItem>>([]);
  const [ruleToolName, setRuleToolName] = useState<string>("run_shell");
  const [rulePattern, setRulePattern] = useState<string>(
    "tool:run_shell:pytest*",
  );
  const [ruleSampleCmd, setRuleSampleCmd] = useState<string>("pytest -q");
  const [ruleFeedback, setRuleFeedback] = useState<string | null>(null);

  const refreshAll = useCallback(async () => {
    try {
      const [runsRes, presetsRes, policiesRes] = await Promise.all([
        apiClient.listRuns({
          status: statusFilter || undefined,
          model: modelFilter || undefined,
        }),
        apiClient.listAgentPresets(),
        apiClient.listExecPolicies(),
      ]);
      setRuns((runsRes.runs as unknown as ReadonlyArray<RunHistoryRow>) ?? []);
      setPresets(
        (presetsRes.presets as unknown as ReadonlyArray<AgentPresetItem>) ?? [],
      );
      setRules(policiesRes.rules ?? []);
    } catch {
      // Allow graceful rendering if backend is unreachable
    }
  }, [statusFilter, modelFilter]);

  useEffect(() => {
    if (open) {
      setActiveTab(initialTab);
      void refreshAll();
    }
  }, [open, initialTab, refreshAll]);

  const handleBulkDelete = async () => {
    const ids = Object.entries(selectedRunIds)
      .filter(([, checked]) => checked)
      .map(([id]) => id);
    if (ids.length === 0) return;
    try {
      await apiClient.bulkDeleteRuns(ids);
      setSelectedRunIds({});
      await refreshAll();
    } catch {
      setRuns((prev) => prev.filter((r) => !ids.includes(r.id)));
      setSelectedRunIds({});
    }
  };

  const handleExportRunTrace = async (runId: string) => {
    try {
      const trace = await apiClient.exportRunTrace(runId);
      const blob = new Blob([JSON.stringify(trace, null, 2)], {
        type: "application/json",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `trace-${runId}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } catch {
      // Ignore export error
    }
  };

  const handleSavePreset = async () => {
    if (!newPresetName.trim()) return;
    try {
      const res = await apiClient.upsertAgentPreset({
        name: newPresetName.trim(),
        description: newPresetDesc.trim() || "Custom agent persona",
        system_prompt:
          newPresetPrompt.trim() || "You are a helpful Odysseus agent.",
        model: "fake-gpt",
        mode: "agent",
      });
      setPresets(
        (res.presets as unknown as ReadonlyArray<AgentPresetItem>) ?? [],
      );
      setNewPresetName("");
      setNewPresetDesc("");
      setNewPresetPrompt("");
    } catch {
      // Offline fallback
    }
  };

  const handleDeletePreset = async (presetId: string) => {
    try {
      const res = await apiClient.deleteAgentPreset(presetId);
      setPresets(
        (res.presets as unknown as ReadonlyArray<AgentPresetItem>) ?? [],
      );
    } catch {
      setPresets((prev) => prev.filter((p) => p.id !== presetId));
    }
  };

  const handleAddRule = async () => {
    const check = validateExecApprovalPattern(rulePattern, ruleToolName);
    if (!check.valid) {
      setRuleFeedback(check.reason);
      return;
    }
    try {
      await apiClient.addExecPolicyRule({
        tool_name: ruleToolName,
        pattern: rulePattern.trim(),
        scope: "always",
      });
      setRuleFeedback("Saved rule.");
      await refreshAll();
    } catch (err) {
      setRuleFeedback(
        err instanceof Error ? err.message : "Failed to save rule",
      );
    }
  };

  const handleTestPattern = async () => {
    const check = validateExecApprovalPattern(rulePattern, ruleToolName);
    if (!check.valid) {
      setRuleFeedback(`Invalid: ${check.reason}`);
      return;
    }
    try {
      const res = await apiClient.testExecPolicyPattern({
        tool_name: ruleToolName,
        pattern: rulePattern.trim(),
        sample_args: { command: ruleSampleCmd },
      });
      setRuleFeedback(
        res.valid
          ? `Valid pattern — Matches sample command: ${res.matches ? "YES ✓" : "NO ✕"}`
          : `Invalid: ${res.reason}`,
      );
    } catch {
      setRuleFeedback("Pattern valid locally.");
    }
  };

  const handleDeleteRule = async (ruleId: string) => {
    try {
      await apiClient.deleteExecPolicyRule(ruleId);
      await refreshAll();
    } catch {
      setRules((prev) => prev.filter((r) => r.id !== ruleId));
    }
  };

  if (!open) return null;

  return (
    <div
      className="odysseus-modal-backdrop"
      role="dialog"
      aria-modal="true"
      aria-label="Agent Run History, Presets, and Execution Policies"
      data-testid="agent-hub-modal"
    >
      <div className="odysseus-modal-surface odysseus-modal-lg">
        <div className="odysseus-modal-header">
          <div className="odysseus-tab-group" role="tablist">
            <button
              type="button"
              role="tab"
              aria-selected={activeTab === "runs"}
              className={`odysseus-btn odysseus-btn-xs ${
                activeTab === "runs"
                  ? "odysseus-btn-primary"
                  : "odysseus-btn-ghost"
              }`}
              onClick={() => setActiveTab("runs")}
              data-testid="agent-hub-tab-runs"
            >
              Run History ({runs.length})
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={activeTab === "presets"}
              className={`odysseus-btn odysseus-btn-xs ${
                activeTab === "presets"
                  ? "odysseus-btn-primary"
                  : "odysseus-btn-ghost"
              }`}
              onClick={() => setActiveTab("presets")}
              data-testid="agent-hub-tab-presets"
            >
              Agent Presets ({presets.length})
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={activeTab === "policies"}
              className={`odysseus-btn odysseus-btn-xs ${
                activeTab === "policies"
                  ? "odysseus-btn-primary"
                  : "odysseus-btn-ghost"
              }`}
              onClick={() => setActiveTab("policies")}
              data-testid="agent-hub-tab-policies"
            >
              Exec Policies ({rules.length})
            </button>
          </div>
          <button
            type="button"
            className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
            onClick={onClose}
            data-testid="agent-hub-close-btn"
          >
            Close ✕
          </button>
        </div>

        {/* Tab 1: Run History (FE-AGENT-12) */}
        {activeTab === "runs" ? (
          <div className="odysseus-run-history-view" data-testid="run-history-view">
            <div className="odysseus-run-history-filters">
              <select
                className="odysseus-select odysseus-select-xs"
                aria-label="Filter runs by status"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                data-testid="run-history-status-filter"
              >
                <option value="">All statuses</option>
                <option value="running">running</option>
                <option value="waiting_approval">waiting_approval</option>
                <option value="completed">completed</option>
                <option value="error">error</option>
                <option value="cancelled">cancelled</option>
              </select>
              <input
                type="search"
                className="odysseus-input odysseus-input-xs"
                placeholder="Filter by model…"
                aria-label="Filter runs by model"
                value={modelFilter}
                onChange={(e) => setModelFilter(e.target.value)}
                data-testid="run-history-model-filter"
              />
              <select
                className="odysseus-select odysseus-select-xs"
                aria-label="Sort runs by"
                value={sortBy}
                onChange={(e) =>
                  setSortBy(e.target.value as "recent" | "cost" | "duration")
                }
                data-testid="run-history-sort-select"
              >
                <option value="recent">Sort: Most Recent</option>
                <option value="cost">Sort: Highest Cost</option>
                <option value="duration">Sort: Longest Duration</option>
              </select>
              <button
                type="button"
                className={`odysseus-btn odysseus-btn-xs ${
                  triageOnly ? "odysseus-btn-primary" : "odysseus-btn-ghost"
                }`}
                onClick={() => setTriageOnly((v) => !v)}
                data-testid="run-history-triage-toggle"
              >
                {triageOnly ? "Showing Failed Triage" : "Failed-Run Triage"}
              </button>
              <button
                type="button"
                className="odysseus-btn odysseus-btn-danger odysseus-btn-xs"
                onClick={() => void handleBulkDelete()}
                data-testid="run-history-bulk-delete-btn"
              >
                Bulk Delete Selected
              </button>
            </div>

            <table className="odysseus-data-table" data-testid="run-history-table">
              <thead>
                <tr>
                  <th>Select</th>
                  <th>Run ID</th>
                  <th>Mode / Model</th>
                  <th>Status</th>
                  <th>Cost</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {[...runs]
                  .filter((r) =>
                    triageOnly
                      ? r.status === "error" ||
                        r.status === "failed" ||
                        r.status === "cancelled" ||
                        r.finish_reason === "budget_exceeded"
                      : true,
                  )
                  .sort((a, b) => {
                    if (sortBy === "cost") {
                      return (b.cost_usd || 0) - (a.cost_usd || 0);
                    }
                    if (sortBy === "duration") {
                      const durA = a.finished_at
                        ? Date.parse(a.finished_at) - Date.parse(a.created_at)
                        : 0;
                      const durB = b.finished_at
                        ? Date.parse(b.finished_at) - Date.parse(b.created_at)
                        : 0;
                      return durB - durA;
                    }
                    return (
                      Date.parse(b.created_at || "") -
                      Date.parse(a.created_at || "")
                    );
                  })
                  .map((run) => (
                  <tr key={run.id} data-testid={`run-history-row-${run.id}`}>
                    <td>
                      <input
                        type="checkbox"
                        aria-label={`Select run ${run.id}`}
                        checked={Boolean(selectedRunIds[run.id])}
                        onChange={(e) =>
                          setSelectedRunIds((prev) => ({
                            ...prev,
                            [run.id]: e.target.checked,
                          }))
                        }
                        data-testid={`run-select-${run.id}`}
                      />
                    </td>
                    <td>
                      <code>{run.id}</code>
                    </td>
                    <td>
                      {run.mode} · {run.model}
                    </td>
                    <td>
                      <span
                        className={`odysseus-badge odysseus-status-${run.status}`}
                      >
                        {run.status}
                      </span>
                      {run.finish_reason && run.finish_reason !== "stop" ? (
                        <span className="odysseus-badge odysseus-badge-warning">
                          {run.finish_reason}
                        </span>
                      ) : null}
                    </td>
                    <td>${(run.cost_usd || 0).toFixed(4)}</td>
                    <td>
                      {onOpenRun ? (
                        <button
                          type="button"
                          className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
                          onClick={() => {
                            onOpenRun(run.id);
                            onClose();
                          }}
                          data-testid={`run-history-open-${run.id}`}
                        >
                          Inspect
                        </button>
                      ) : null}
                      <button
                        type="button"
                        className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                        onClick={() => void handleExportRunTrace(run.id)}
                        data-testid={`run-history-export-${run.id}`}
                      >
                        Export Trace
                      </button>
                      {(run.status === "error" ||
                        run.status === "failed" ||
                        run.finish_reason === "budget_exceeded") &&
                      onApplyPreset ? (
                        <button
                          type="button"
                          className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
                          onClick={() => {
                            onApplyPreset({
                              id: `retry_${run.id}`,
                              name: `Retry ${run.id}`,
                              description: "Retry failed run with fallback model",
                              system_prompt: "Retry failed run with careful verification.",
                              model: run.model || "fake/default",
                              mode: "agent",
                              allowed_tools: ["*"],
                            });
                            onClose();
                          }}
                          data-testid={`run-retry-model-${run.id}`}
                        >
                          Retry with model
                        </button>
                      ) : null}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : null}

        {/* Tab 2: Agent Presets (FE-AGENT-13) */}
        {activeTab === "presets" ? (
          <div className="odysseus-presets-view" data-testid="agent-presets-view">
            <div className="odysseus-preset-form">
              <input
                type="text"
                className="odysseus-input odysseus-input-xs"
                placeholder="Preset name (e.g. Security Auditor)…"
                aria-label="New preset name"
                value={newPresetName}
                onChange={(e) => setNewPresetName(e.target.value)}
                data-testid="preset-name-input"
              />
              <input
                type="text"
                className="odysseus-input odysseus-input-xs"
                placeholder="Description…"
                aria-label="New preset description"
                value={newPresetDesc}
                onChange={(e) => setNewPresetDesc(e.target.value)}
                data-testid="preset-desc-input"
              />
              <input
                type="text"
                className="odysseus-input odysseus-input-xs"
                placeholder="System prompt…"
                aria-label="New preset system prompt"
                value={newPresetPrompt}
                onChange={(e) => setNewPresetPrompt(e.target.value)}
                data-testid="preset-prompt-input"
              />
              <button
                type="button"
                className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
                onClick={() => void handleSavePreset()}
                data-testid="preset-save-btn"
              >
                Save Preset
              </button>
              <button
                type="button"
                className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                onClick={() => {
                  const blob = new Blob([JSON.stringify(presets, null, 2)], {
                    type: "application/json",
                  });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement("a");
                  a.href = url;
                  a.download = "agent-presets.json";
                  a.click();
                  URL.revokeObjectURL(url);
                }}
                data-testid="presets-export-btn"
              >
                Export Presets
              </button>
              <label className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs">
                Import Presets
                <input
                  type="file"
                  accept=".json"
                  style={{ display: "none" }}
                  onChange={async (e) => {
                    const f = e.target.files?.[0];
                    if (!f) return;
                    try {
                      const parsed = JSON.parse(await f.text()) as unknown;
                      if (Array.isArray(parsed)) {
                        setPresets(parsed as ReadonlyArray<AgentPresetItem>);
                      }
                    } catch {
                      // Ignore malformed preset file
                    }
                  }}
                  data-testid="presets-import-input"
                />
              </label>
            </div>

            <div className="odysseus-preset-list" data-testid="preset-list">
              {presets.map((p) => (
                <div
                  key={p.id}
                  className="odysseus-preset-card"
                  data-testid={`preset-card-${p.id}`}
                >
                  <div>
                    <strong>{p.name}</strong>{" "}
                    <span className="odysseus-badge">{p.mode}</span>{" "}
                    <span className="odysseus-badge">{p.model}</span>
                    <p className="odysseus-text-muted">{p.description}</p>
                  </div>
                  <div className="odysseus-preset-card-actions">
                    {onApplyPreset ? (
                      <button
                        type="button"
                        className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
                        onClick={() => {
                          onApplyPreset(p);
                          onClose();
                        }}
                        data-testid={`preset-apply-${p.id}`}
                      >
                        Apply Preset
                      </button>
                    ) : null}
                    <button
                      type="button"
                      className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                      onClick={() => {
                        setNewPresetName(`${p.name} (Copy)`);
                        setNewPresetDesc(p.description);
                        setNewPresetPrompt(p.system_prompt);
                      }}
                      data-testid={`preset-duplicate-${p.id}`}
                    >
                      Duplicate
                    </button>
                    <button
                      type="button"
                      className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
                      onClick={() => void handleDeletePreset(p.id)}
                      data-testid={`preset-delete-${p.id}`}
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : null}

        {/* Tab 3: Exec Policy Editor & Pattern Tester (FE-ADMIN-05) */}
        {activeTab === "policies" ? (
          <div
            className="odysseus-exec-policies-view"
            data-testid="exec-policies-view"
          >
            <div
              className="odysseus-row-wrap"
              data-testid="exec-policy-risk-defaults"
            >
              <span className="odysseus-badge">read_only: auto-allow</span>
              <span className="odysseus-badge">write_scoped: auto-allow</span>
              <span className="odysseus-badge odysseus-badge-warning">
                exec / network_external / destructive: ask approval
              </span>
            </div>
            <div className="odysseus-exec-policy-form">
              <input
                type="text"
                className="odysseus-input odysseus-input-xs"
                value={ruleToolName}
                aria-label="Tool name for policy rule"
                onChange={(e) => setRuleToolName(e.target.value)}
                data-testid="exec-policy-tool-input"
              />
              <input
                type="text"
                className="odysseus-input odysseus-input-xs"
                value={rulePattern}
                aria-label="Allowlist pattern"
                onChange={(e) => setRulePattern(e.target.value)}
                data-testid="exec-policy-pattern-input"
              />
              <input
                type="text"
                className="odysseus-input odysseus-input-xs"
                value={ruleSampleCmd}
                aria-label="Sample command to test against pattern"
                onChange={(e) => setRuleSampleCmd(e.target.value)}
                data-testid="exec-policy-sample-input"
              />
              <button
                type="button"
                className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                onClick={() => void handleTestPattern()}
                data-testid="exec-policy-test-btn"
              >
                Test Pattern
              </button>
              <button
                type="button"
                className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
                onClick={() => void handleAddRule()}
                data-testid="exec-policy-add-btn"
              >
                Add Allowlist Rule
              </button>
            </div>
            {ruleFeedback ? (
              <div
                className="odysseus-policy-feedback"
                role="status"
                data-testid="exec-policy-test-result"
              >
                {ruleFeedback}
              </div>
            ) : null}

            <div
              className="odysseus-exec-policy-list"
              data-testid="exec-policy-rules-list"
            >
              {rules.map((r) => (
                <div
                  key={r.id}
                  className="odysseus-policy-rule-row"
                  data-testid={`exec-policy-rule-${r.id}`}
                >
                  <code>{r.tool_name}</code> → <code>{r.pattern}</code>{" "}
                  <span className="odysseus-badge">{r.scope}</span>
                  <button
                    type="button"
                    className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
                    onClick={() => void handleDeleteRule(r.id)}
                    data-testid={`exec-policy-delete-${r.id}`}
                  >
                    Revoke
                  </button>
                </div>
              ))}
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
};
