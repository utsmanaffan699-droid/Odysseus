export type SpoofWarningCode =
  | "RTL_OVERRIDE"
  | "ZERO_WIDTH"
  | "HOMOGLYPH"
  | "MULTILINE"
  | "LONG_ARG";

export interface NormalizedApprovalText {
  readonly rawLength: number;
  readonly previewNormalized: string;
  readonly fullNormalized: string;
  readonly hiddenCharCount: number;
  readonly isTruncated: boolean;
  readonly warnings: ReadonlyArray<SpoofWarningCode>;
}

const BIDI_CP = new Set<number>([
  0x061c, 0x200e, 0x200f, 0x202a, 0x202b, 0x202c, 0x202d, 0x202e, 0x2066, 0x2067, 0x2068,
  0x2069,
]);

const ZERO_WIDTH_CP = new Set<number>([
  0x00ad, 0x200b, 0x200c, 0x200d, 0x2060, 0xfeff,
]);

function formatHexCode(cp: number): string {
  return `U+${cp.toString(16).toUpperCase().padStart(4, "0")}`;
}

function isConfusableHomoglyph(cp: number, hasAsciiLetters: boolean): boolean {
  if (!hasAsciiLetters) return false;
  // Cyrillic or Greek ranges mixed with ASCII command text
  return (cp >= 0x0400 && cp <= 0x04ff) || (cp >= 0x0370 && cp <= 0x03ff);
}

export function inspectAndNormalizeApprovalText(
  raw: string,
  maxInlineChars = 10000,
): NormalizedApprovalText {
  const warnings = new Set<SpoofWarningCode>();
  const hasAsciiLetters = /[A-Za-z]/.test(raw);

  if (raw.includes("\n") || raw.includes("\r")) {
    warnings.add("MULTILINE");
  }
  if (raw.length > maxInlineChars) {
    warnings.add("LONG_ARG");
  }

  const normalizeSlice = (input: string): string => {
    let out = "";
    for (const ch of input) {
      const cp = ch.codePointAt(0) ?? 0;
      if (BIDI_CP.has(cp)) {
        warnings.add("RTL_OVERRIDE");
        out += `[RTL:${formatHexCode(cp)}]`;
      } else if (ZERO_WIDTH_CP.has(cp) || (cp < 0x20 && cp !== 0x09 && cp !== 0x0a && cp !== 0x0d)) {
        warnings.add("ZERO_WIDTH");
        out += `[ZW:${formatHexCode(cp)}]`;
      } else if (isConfusableHomoglyph(cp, hasAsciiLetters)) {
        warnings.add("HOMOGLYPH");
        out += `[HOMOGLYPH:${ch}/${formatHexCode(cp)}]`;
      } else if (ch === "\n") {
        out += " ↵\n";
      } else {
        out += ch;
      }
    }
    return out;
  };

  const fullNormalized = normalizeSlice(raw);
  const isTruncated = raw.length > maxInlineChars;
  const hiddenCharCount = isTruncated ? raw.length - maxInlineChars : 0;
  const previewNormalized = isTruncated
    ? normalizeSlice(raw.slice(0, maxInlineChars))
    : fullNormalized;

  return {
    rawLength: raw.length,
    previewNormalized,
    fullNormalized,
    hiddenCharCount,
    isTruncated,
    warnings: Array.from(warnings),
  };
}

export interface ApprovalProvenance {
  readonly isTainted: boolean;
  readonly sourceLabel: string | null;
}

export function extractApprovalProvenance(
  reason: string,
  taintedSource?: string | null,
): ApprovalProvenance {
  if (taintedSource && taintedSource.trim().length > 0) {
    return {
      isTainted: true,
      sourceLabel: `Requested after reading web page ${taintedSource.trim()}`,
    };
  }
  const match = /Requested after reading ([^\n]+)/i.exec(reason);
  if (match && match[1]) {
    return {
      isTainted: true,
      sourceLabel: `Requested after reading ${match[1].trim()}`,
    };
  }
  return { isTainted: false, sourceLabel: null };
}

export interface PatternValidationResult {
  readonly valid: boolean;
  readonly reason: string;
}

const OVERBROAD_PATTERNS = new Set([
  "*",
  "**",
  "tool:*",
  "shell:*",
  "run_shell:*",
  "rm",
  "rm *",
  "sudo*",
  "sh*",
  "bash*",
]);

export function validateExecApprovalPattern(
  pattern: string,
  toolName: string,
): PatternValidationResult {
  const clean = pattern.trim();
  if (!clean) {
    return { valid: false, reason: "Pattern cannot be empty." };
  }
  if (OVERBROAD_PATTERNS.has(clean.toLowerCase()) || clean.endsWith(":*")) {
    return {
      valid: false,
      reason: `Pattern '${clean}' is overly broad and rejected; specify a concrete prefix such as 'tool:${toolName}:pytest*'.`,
    };
  }
  if (clean.length < 4) {
    return { valid: false, reason: "Pattern must be at least 4 characters long." };
  }
  return { valid: true, reason: "Valid structured pattern." };
}

export const ANTI_CLICKJACK_GUARD_MS = 400;

export function isApprovalActionUnlocked(params: {
  readonly mountedAtMs: number;
  readonly lastLayoutShiftAtMs: number;
  readonly nowMs: number;
  readonly isVisibleInViewport: boolean;
}): boolean {
  if (!params.isVisibleInViewport) {
    return false;
  }
  const referenceMs = Math.max(params.mountedAtMs, params.lastLayoutShiftAtMs);
  return params.nowMs - referenceMs >= ANTI_CLICKJACK_GUARD_MS;
}
