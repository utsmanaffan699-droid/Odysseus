import React from "react";
import { createRoot } from "react-dom/client";
import { QueryClientProvider } from "@tanstack/react-query";
import "./design-system/tokens.css";
import "./styles.css";
import "./i18n";
import { App } from "./app/App";
import { odysseusQueryClient } from "./lib/queryClient";
import { useAppShellStore } from "./lib/store";

// Synchronously apply persisted theme/palette/density/fontSize before first React paint (FE-SHELL-10)
const initState = useAppShellStore.getState();
if (typeof document !== "undefined") {
  document.documentElement.dataset.theme = initState.theme;
  document.documentElement.dataset.palette = initState.palette;
  document.documentElement.dataset.density = initState.density;
  document.documentElement.dataset.fontsize = initState.fontSize;
}

const rootEl = document.getElementById("root");
if (rootEl) {
  createRoot(rootEl).render(
    <React.StrictMode>
      <QueryClientProvider client={odysseusQueryClient}>
        <App />
      </QueryClientProvider>
    </React.StrictMode>,
  );
}
