import React, { useEffect, useRef, useState } from "react";

// 1. Button
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  readonly variant?: "primary" | "secondary" | "danger" | "ghost";
  readonly size?: "sm" | "md";
  readonly loading?: boolean;
}

export function Button({
  variant = "primary",
  size = "md",
  loading = false,
  disabled,
  className = "",
  children,
  ...rest
}: ButtonProps): React.ReactElement {
  return (
    <button
      type="button"
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      className={`odysseus-btn odysseus-btn-${variant} odysseus-btn-${size} ${className}`.trim()}
      {...rest}
    >
      {loading ? <span className="odysseus-spinner" aria-hidden="true" /> : null}
      <span>{children}</span>
    </button>
  );
}

// 2. IconButton
export interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  readonly label: string;
  readonly active?: boolean;
}

export function IconButton({
  label,
  active = false,
  className = "",
  children,
  ...rest
}: IconButtonProps): React.ReactElement {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      aria-pressed={active || undefined}
      className={`odysseus-icon-btn ${active ? "odysseus-icon-btn-active" : ""} ${className}`.trim()}
      {...rest}
    >
      {children}
    </button>
  );
}

// 3. Input
export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  readonly label?: string;
  readonly error?: string | null;
}

export function Input({
  id,
  label,
  error,
  className = "",
  ...rest
}: InputProps): React.ReactElement {
  return (
    <div className="odysseus-field">
      {label && id ? (
        <label htmlFor={id} className="odysseus-label">
          {label}
        </label>
      ) : null}
      <input
        id={id}
        aria-invalid={Boolean(error) || undefined}
        className={`odysseus-input ${error ? "odysseus-input-error" : ""} ${className}`.trim()}
        {...rest}
      />
      {error ? (
        <span className="odysseus-field-error" role="alert">
          {error}
        </span>
      ) : null}
    </div>
  );
}

// 4. Select
export interface SelectOption {
  readonly value: string;
  readonly label: string;
}

export interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  readonly label?: string;
  readonly options: ReadonlyArray<SelectOption>;
}

export function Select({
  id,
  label,
  options,
  className = "",
  ...rest
}: SelectProps): React.ReactElement {
  return (
    <div className="odysseus-field">
      {label && id ? (
        <label htmlFor={id} className="odysseus-label">
          {label}
        </label>
      ) : null}
      <select id={id} className={`odysseus-select ${className}`.trim()} {...rest}>
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>
    </div>
  );
}

// 5. Combobox
export interface ComboboxProps {
  readonly label: string;
  readonly value: string;
  readonly options: ReadonlyArray<SelectOption>;
  readonly onChange: (val: string) => void;
  readonly testId?: string;
}

export function Combobox({
  label,
  value,
  options,
  onChange,
  testId,
}: ComboboxProps): React.ReactElement {
  const [filter, setFilter] = useState("");
  const filtered = options.filter(
    (o) =>
      o.label.toLowerCase().includes(filter.toLowerCase()) ||
      o.value.toLowerCase().includes(filter.toLowerCase()),
  );

  return (
    <div className="odysseus-combobox" data-testid={testId}>
      <input
        type="text"
        aria-label={label}
        placeholder={label}
        className="odysseus-input"
        value={filter}
        onChange={(e) => setFilter(e.target.value)}
      />
      <select
        aria-label={`${label} options`}
        className="odysseus-select"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      >
        {filtered.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </div>
  );
}

// 6. Tabs
export interface TabItem {
  readonly id: string;
  readonly label: string;
}

export interface TabsProps {
  readonly tabs: ReadonlyArray<TabItem>;
  readonly activeId: string;
  readonly onSelect: (id: string) => void;
  readonly ariaLabel: string;
}

export function Tabs({ tabs, activeId, onSelect, ariaLabel }: TabsProps): React.ReactElement {
  return (
    <div role="tablist" aria-label={ariaLabel} className="odysseus-tabs">
      {tabs.map((tab) => {
        const selected = tab.id === activeId;
        return (
          <button
            key={tab.id}
            type="button"
            role="tab"
            aria-selected={selected}
            tabIndex={selected ? 0 : -1}
            className={`odysseus-tab ${selected ? "odysseus-tab-active" : ""}`}
            onClick={() => onSelect(tab.id)}
            data-testid={`tab-${tab.id}`}
          >
            {tab.label}
          </button>
        );
      })}
    </div>
  );
}

// 7. Dialog (Focus-trapped accessible modal)
export interface DialogProps {
  readonly open: boolean;
  readonly title: string;
  readonly onClose: () => void;
  readonly children: React.ReactNode;
  readonly testId?: string;
}

export function Dialog({
  open,
  title,
  onClose,
  children,
  testId,
}: DialogProps): React.ReactElement | null {
  const dialogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const handleKeyDown = (e: KeyboardEvent): void => {
      if (e.key === "Escape") {
        e.stopPropagation();
        onClose();
      } else if (e.key === "Tab" && dialogRef.current) {
        const focusables = dialogRef.current.querySelectorAll<HTMLElement>(
          'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])',
        );
        if (focusables.length === 0) return;
        const first = focusables[0]!;
        const last = focusables[focusables.length - 1]!;
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="odysseus-dialog-backdrop" data-testid={testId}>
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="odysseus-dialog"
      >
        <div className="odysseus-dialog-header">
          <h2>{title}</h2>
          <IconButton label="Close dialog" onClick={onClose} data-testid="dialog-close">
            ✕
          </IconButton>
        </div>
        <div className="odysseus-dialog-body">{children}</div>
      </div>
    </div>
  );
}

// 8. Drawer (Mobile / Side sheet with focus trap)
export function Drawer({
  open,
  title,
  onClose,
  children,
  testId,
}: DialogProps): React.ReactElement | null {
  if (!open) return null;
  return (
    <div className="odysseus-dialog-backdrop" data-testid={testId}>
      <aside
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="odysseus-drawer"
      >
        <div className="odysseus-dialog-header">
          <h2>{title}</h2>
          <IconButton label="Close drawer" onClick={onClose}>
            ✕
          </IconButton>
        </div>
        <div className="odysseus-drawer-body">{children}</div>
      </aside>
    </div>
  );
}

// 9. Popover
export interface PopoverProps {
  readonly triggerLabel: string;
  readonly triggerContent: React.ReactNode;
  readonly children: React.ReactNode;
  readonly testId?: string;
}

export function Popover({
  triggerLabel,
  triggerContent,
  children,
  testId,
}: PopoverProps): React.ReactElement {
  const [open, setOpen] = useState(false);
  return (
    <div className="odysseus-popover-wrap" data-testid={testId}>
      <Button
        variant="secondary"
        size="sm"
        aria-expanded={open}
        aria-haspopup="dialog"
        aria-label={triggerLabel}
        onClick={() => setOpen((o) => !o)}
      >
        {triggerContent}
      </Button>
      {open ? (
        <div role="dialog" aria-label={triggerLabel} className="odysseus-popover-panel">
          {children}
        </div>
      ) : null}
    </div>
  );
}

// 10. Tooltip
export function Tooltip({
  text,
  children,
}: {
  readonly text: string;
  readonly children: React.ReactNode;
}): React.ReactElement {
  return (
    <span className="odysseus-tooltip-wrap" title={text}>
      {children}
    </span>
  );
}

// 11. Toast
export interface ToastRegionProps {
  readonly toasts: ReadonlyArray<{
    readonly id: string;
    readonly message: string;
    readonly variant: string;
    readonly actionLabel?: string;
    readonly onAction?: () => void;
  }>;
  readonly onDismiss: (id: string) => void;
}

export function ToastRegion({ toasts, onDismiss }: ToastRegionProps): React.ReactElement {
  return (
    <div
      className="odysseus-toast-region"
      role="status"
      aria-live="polite"
      aria-atomic="false"
      data-testid="toast-region"
    >
      {toasts.map((t) => (
        <div
          key={t.id}
          className={`odysseus-toast odysseus-toast-${t.variant}`}
          data-testid="toast-item"
        >
          <span>{t.message}</span>
          <div className="odysseus-toast-actions">
            {t.actionLabel && t.onAction ? (
              <Button
                variant="secondary"
                size="sm"
                onClick={() => {
                  t.onAction?.();
                  onDismiss(t.id);
                }}
                data-testid="toast-undo-btn"
              >
                {t.actionLabel}
              </Button>
            ) : null}
            <IconButton label="Dismiss notification" onClick={() => onDismiss(t.id)}>
              ✕
            </IconButton>
          </div>
        </div>
      ))}
    </div>
  );
}

// 12. Menu (Roving tabindex keyboard navigation)
export interface MenuItem {
  readonly id: string;
  readonly label: string;
  readonly danger?: boolean;
  readonly onSelect: () => void;
}

export function Menu({
  label,
  items,
  testId,
}: {
  readonly label: string;
  readonly items: ReadonlyArray<MenuItem>;
  readonly testId?: string;
}): React.ReactElement {
  const [activeIndex, setActiveIndex] = useState(0);
  const itemRefs = useRef<Array<HTMLButtonElement | null>>([]);

  const handleKeyDown = (e: React.KeyboardEvent): void => {
    if (items.length === 0) return;
    if (e.key === "ArrowDown") {
      e.preventDefault();
      const next = (activeIndex + 1) % items.length;
      setActiveIndex(next);
      itemRefs.current[next]?.focus();
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      const prev = (activeIndex - 1 + items.length) % items.length;
      setActiveIndex(prev);
      itemRefs.current[prev]?.focus();
    }
  };

  return (
    <div
      role="menu"
      tabIndex={-1}
      aria-label={label}
      className="odysseus-menu"
      onKeyDown={handleKeyDown}
      data-testid={testId}
    >
      {items.map((item, idx) => (
        <button
          key={item.id}
          ref={(el) => {
            itemRefs.current[idx] = el;
          }}
          type="button"
          role="menuitem"
          tabIndex={idx === activeIndex ? 0 : -1}
          className={`odysseus-menu-item ${item.danger ? "odysseus-menu-item-danger" : ""}`}
          onClick={item.onSelect}
          data-testid={`menu-item-${item.id}`}
        >
          {item.label}
        </button>
      ))}
    </div>
  );
}

// 13. Table
export function Table({
  headers,
  rows,
  caption,
}: {
  readonly headers: ReadonlyArray<string>;
  readonly rows: ReadonlyArray<ReadonlyArray<React.ReactNode>>;
  readonly caption?: string;
}): React.ReactElement {
  return (
    <div className="odysseus-table-wrap" role="region" aria-label={caption ?? "Data table"}>
      <table className="odysseus-md-table">
        {caption ? <caption className="sr-only">{caption}</caption> : null}
        <thead>
          <tr>
            {headers.map((h, i) => (
              <th key={i}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, rIdx) => (
            <tr key={rIdx}>
              {r.map((cell, cIdx) => (
                <td key={cIdx}>{cell}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// 14. Tree
export interface TreeNodeItem {
  readonly id: string;
  readonly label: string;
  readonly children?: ReadonlyArray<TreeNodeItem>;
}

export function Tree({
  nodes,
  ariaLabel,
}: {
  readonly nodes: ReadonlyArray<TreeNodeItem>;
  readonly ariaLabel: string;
}): React.ReactElement {
  return (
    <ul role="tree" aria-label={ariaLabel} className="odysseus-tree">
      {nodes.map((n) => (
        <li
          key={n.id}
          role="treeitem"
          aria-selected={false}
          aria-expanded={Boolean(n.children?.length)}
        >
          <span>{n.label}</span>
          {n.children && n.children.length > 0 ? (
            <ul role="group">
              {n.children.map((ch) => (
                <li key={ch.id} role="treeitem" aria-selected={false}>
                  {ch.label}
                </li>
              ))}
            </ul>
          ) : null}
        </li>
      ))}
    </ul>
  );
}

// 15. Skeleton
export function Skeleton({
  lines = 3,
  testId = "skeleton-loader",
}: {
  readonly lines?: number;
  readonly testId?: string;
}): React.ReactElement {
  return (
    <div
      role="status"
      className="odysseus-skeleton-group"
      aria-busy="true"
      aria-label="Loading content"
      data-testid={testId}
    >
      {Array.from({ length: lines }, (_, idx) => (
        <div key={idx} className="odysseus-skeleton-line" />
      ))}
    </div>
  );
}

// 16. Badge
export function Badge({
  children,
  variant = "default",
  testId,
}: {
  readonly children: React.ReactNode;
  readonly variant?: "default" | "success" | "warning" | "danger";
  readonly testId?: string;
}): React.ReactElement {
  return (
    <span className={`odysseus-badge odysseus-badge-${variant}`} data-testid={testId}>
      {children}
    </span>
  );
}

// 17. Progress
export function Progress({
  value,
  label,
}: {
  readonly value: number;
  readonly label: string;
}): React.ReactElement {
  const clamped = Math.max(0, Math.min(100, Math.round(value)));
  return (
    <div
      role="progressbar"
      aria-label={label}
      aria-valuenow={clamped}
      aria-valuemin={0}
      aria-valuemax={100}
      className="odysseus-progress"
    >
      <div className="odysseus-progress-bar" data-pct={clamped} />
    </div>
  );
}

// 18. Switch
export function Switch({
  label,
  checked,
  onChange,
  testId,
}: {
  readonly label: string;
  readonly checked: boolean;
  readonly onChange: (next: boolean) => void;
  readonly testId?: string;
}): React.ReactElement {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      className={`odysseus-switch ${checked ? "odysseus-switch-on" : ""}`}
      onClick={() => onChange(!checked)}
      data-testid={testId}
    >
      <span className="odysseus-switch-thumb" />
      <span className="odysseus-switch-label">{label}</span>
    </button>
  );
}

// 19. Slider
export function Slider({
  id,
  label,
  value,
  min = 0,
  max = 100,
  onChange,
}: {
  readonly id: string;
  readonly label: string;
  readonly value: number;
  readonly min?: number;
  readonly max?: number;
  readonly onChange: (val: number) => void;
}): React.ReactElement {
  return (
    <div className="odysseus-field">
      <label htmlFor={id} className="odysseus-label">
        {label}: {value}
      </label>
      <input
        id={id}
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="odysseus-slider"
      />
    </div>
  );
}

// 20. Kbd
export function Kbd({ children }: { readonly children: React.ReactNode }): React.ReactElement {
  return <kbd className="odysseus-kbd">{children}</kbd>;
}
