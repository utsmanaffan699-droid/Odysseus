import type { RunEventEnvelope } from "./contracts/events.gen";

export type CrossTabMessage =
  | {
      readonly type: "theme_changed";
      readonly theme: "light" | "dark" | "high-contrast" | "system";
      readonly palette: "slate" | "amber" | "forest";
      readonly density: "comfortable" | "compact";
    }
  | {
      readonly type: "draft_changed";
      readonly chatId: string;
      readonly draft: string;
    }
  | {
      readonly type: "auth_changed";
      readonly authenticated: boolean;
    }
  | {
      readonly type: "run_event";
      readonly chatId: string;
      readonly event: RunEventEnvelope;
    }
  | {
      readonly type: "active_run_lock";
      readonly chatId: string;
      readonly runId: string | null;
    };

export class CrossTabSyncBus {
  private channel: BroadcastChannel | null = null;
  private readonly listeners = new Set<(msg: CrossTabMessage) => void>();

  constructor(channelName = "odysseus_sync_v1") {
    if (typeof BroadcastChannel !== "undefined") {
      try {
        this.channel = new BroadcastChannel(channelName);
        this.channel.onmessage = (ev: MessageEvent<CrossTabMessage>) => {
          if (ev.data && typeof ev.data.type === "string") {
            for (const listener of this.listeners) {
              listener(ev.data);
            }
          }
        };
      } catch {
        this.channel = null;
      }
    }
  }

  public publish(msg: CrossTabMessage): void {
    try {
      this.channel?.postMessage(msg);
    } catch {
      // Ignore closed channel errors
    }
  }

  public subscribe(listener: (msg: CrossTabMessage) => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  public close(): void {
    this.listeners.clear();
    this.channel?.close();
    this.channel = null;
  }
}

export const sharedCrossTabBus = new CrossTabSyncBus();
