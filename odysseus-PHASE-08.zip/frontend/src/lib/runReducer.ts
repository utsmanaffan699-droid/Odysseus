import type { EventPayloadMap, RunEventEnvelope } from "./contracts/events.gen";

export interface PartViewState {
  readonly part_id: string;
  readonly message_id: string;
  readonly type: string;
  readonly text: string;
  readonly finished: boolean;
}

export interface ApprovalViewState {
  readonly approval_id: string;
  readonly call_id: string;
  readonly reason: string;
  readonly expires_at: string;
  readonly status: "pending" | "approved" | "denied";
  readonly decision: string | null;
  readonly suggested_pattern?: string;
}

export interface ToolCallViewState {
  readonly call_id: string;
  readonly name: string;
  readonly args: Record<string, unknown>;
  readonly risk: string;
  readonly status: string;
  readonly approval_id: string | null;
  readonly approval_decision: string | null;
  readonly stdout: string;
  readonly stderr: string;
  readonly pct: number | null;
  readonly progress_label: string;
  readonly ok: boolean | null;
  readonly summary: string;
  readonly render_hint: string;
  readonly duration_ms?: number;
  readonly output_ref?: string;
  readonly truncated?: boolean;
}

export interface ArtifactViewState {
  readonly artifact_id: string;
  readonly type: string;
  readonly title: string;
  readonly version: number;
  readonly content: string;
  readonly summary: string;
}

export interface SubagentViewState {
  readonly child_run_id: string;
  readonly task: string;
  readonly status: string;
  readonly summary: string;
}

export interface StepViewState {
  readonly step_id: string;
  readonly index: number;
  readonly kind: string;
  readonly status: string;
  readonly duration_ms: number;
  readonly note?: string;
  readonly started_at?: string;
}

export interface RunViewState {
  readonly run_id: string;
  readonly model: string;
  readonly status: string;
  readonly finish_reason: string | null;
  readonly last_seq: number;
  readonly ordered_part_ids: ReadonlyArray<string>;
  readonly ordered_step_ids: ReadonlyArray<string>;
  readonly ordered_tool_call_ids: ReadonlyArray<string>;
  readonly steps: Record<string, StepViewState>;
  readonly parts: Record<string, PartViewState>;
  readonly plan: ReadonlyArray<{ id: string; title: string; status: string }>;
  readonly tool_calls: Record<string, ToolCallViewState>;
  readonly approvals: Record<string, ApprovalViewState>;
  readonly subagents: Record<string, SubagentViewState>;
  readonly artifacts: Record<string, ArtifactViewState>;
  readonly citations: ReadonlyArray<Record<string, unknown>>;
  readonly sources_opened: ReadonlyArray<{ url: string; title: string }>;
  readonly memories_used: ReadonlyArray<string>;
  readonly memories_updated: ReadonlyArray<{ id: string; op: string }>;
  readonly notices: ReadonlyArray<{ level: string; code: string; text: string }>;
  readonly steers: ReadonlyArray<string>;
  readonly usage: {
    readonly input: number;
    readonly output: number;
    readonly cached: number;
    readonly reasoning: number;
    readonly cost: number;
    readonly context_used?: number;
    readonly context_window?: number;
  };
  readonly error: { code: string; message: string; retryable: boolean } | null;
  readonly resync_cursor: number | null;
  readonly seq_gap_detected: boolean;
}

export function createInitialRunViewState(): RunViewState {
  return {
    run_id: "",
    model: "",
    status: "queued",
    finish_reason: null,
    last_seq: 0,
    ordered_part_ids: [],
    ordered_step_ids: [],
    ordered_tool_call_ids: [],
    steps: {},
    parts: {},
    plan: [],
    tool_calls: {},
    approvals: {},
    subagents: {},
    artifacts: {},
    citations: [],
    sources_opened: [],
    memories_used: [],
    memories_updated: [],
    notices: [],
    steers: [],
    usage: {
      input: 0,
      output: 0,
      cached: 0,
      reasoning: 0,
      cost: 0,
    },
    error: null,
    resync_cursor: null,
    seq_gap_detected: false,
  };
}

export interface ReduceRunOptions {
  readonly rejectSeqGaps?: boolean;
  readonly ignoreDuplicates?: boolean;
}

export function reduceSingleRunEvent(
  state: RunViewState,
  ev: RunEventEnvelope,
  options?: ReduceRunOptions,
): RunViewState {
  if (state.run_id && ev.run_id !== state.run_id) {
    throw new Error(`Mismatched run_id in stream: ${ev.run_id} !== ${state.run_id}`);
  }
  if (ev.seq <= state.last_seq) {
    if (options?.ignoreDuplicates) {
      return state;
    }
    throw new Error(
      `Non-monotonic event sequence: got seq=${ev.seq} after last_seq=${state.last_seq}`,
    );
  }
  if (
    options?.rejectSeqGaps &&
    state.last_seq > 0 &&
    ev.seq > state.last_seq + 1 &&
    ev.type !== "stream.resync"
  ) {
    return {
      ...state,
      seq_gap_detected: true,
      resync_cursor: state.last_seq,
    };
  }

  return applySingleEvent(
    {
      ...state,
      run_id: ev.run_id,
      last_seq: ev.seq,
      seq_gap_detected: false,
    },
    ev,
  );
}

export function reduceRunState(
  events: ReadonlyArray<RunEventEnvelope>,
  initial?: RunViewState,
  options?: ReduceRunOptions,
): RunViewState {
  let state: RunViewState = initial ?? createInitialRunViewState();
  for (const ev of events) {
    state = reduceSingleRunEvent(state, ev, options);
    if (state.seq_gap_detected && options?.rejectSeqGaps) {
      break;
    }
  }
  return state;
}

function applySingleEvent(state: RunViewState, ev: RunEventEnvelope): RunViewState {
  switch (ev.type) {
    case "run.started": {
      const d = ev.data as EventPayloadMap["run.started"];
      return { ...state, model: d.model, status: "running" };
    }
    case "run.status": {
      const d = ev.data as EventPayloadMap["run.status"];
      return { ...state, status: d.status };
    }
    case "run.finished": {
      const d = ev.data as EventPayloadMap["run.finished"];
      const closedSteps: Record<string, StepViewState> = { ...state.steps };
      let anyClosed = false;
      for (const [sid, step] of Object.entries(closedSteps)) {
        if (step.status === "running") {
          closedSteps[sid] = {
            ...step,
            status: d.reason === "completed" ? "completed" : d.reason,
            note: "closed by run end",
          };
          anyClosed = true;
        }
      }
      return {
        ...state,
        finish_reason: d.reason,
        status: d.reason === "completed" ? "completed" : d.reason,
        steps: anyClosed ? closedSteps : state.steps,
        usage: {
          ...state.usage,
          input: d.usage.input ?? state.usage.input,
          output: d.usage.output ?? state.usage.output,
          cached: d.usage.cached ?? state.usage.cached,
          reasoning: d.usage.reasoning ?? state.usage.reasoning,
          cost: d.usage.cost ?? state.usage.cost,
        },
      };
    }
    case "run.error": {
      const d = ev.data as EventPayloadMap["run.error"];
      const closedSteps: Record<string, StepViewState> = { ...state.steps };
      let anyClosed = false;
      for (const [sid, step] of Object.entries(closedSteps)) {
        if (step.status === "running") {
          closedSteps[sid] = {
            ...step,
            status: "failed",
            note: "closed by run end",
          };
          anyClosed = true;
        }
      }
      return {
        ...state,
        status: "error",
        steps: anyClosed ? closedSteps : state.steps,
        error: {
          code: d.code,
          message: d.message,
          retryable: Boolean(d.retryable),
        },
      };
    }
    case "step.started": {
      const d = ev.data as EventPayloadMap["step.started"];
      const ordered =
        d.step_id in state.steps
          ? state.ordered_step_ids
          : [...state.ordered_step_ids, d.step_id];
      return {
        ...state,
        ordered_step_ids: ordered,
        steps: {
          ...state.steps,
          [d.step_id]: {
            step_id: d.step_id,
            index: d.index,
            kind: d.kind,
            status: "running",
            duration_ms: 0,
          },
        },
      };
    }
    case "step.finished": {
      const d = ev.data as EventPayloadMap["step.finished"];
      const prev = state.steps[d.step_id];
      if (!prev) {
        return state;
      }
      return {
        ...state,
        steps: {
          ...state.steps,
          [d.step_id]: {
            ...prev,
            status: d.status,
            duration_ms: d.duration_ms,
          },
        },
      };
    }
    case "message.part.started": {
      const d = ev.data as EventPayloadMap["message.part.started"];
      const ordered =
        d.part_id in state.parts
          ? state.ordered_part_ids
          : [...state.ordered_part_ids, d.part_id];
      return {
        ...state,
        ordered_part_ids: ordered,
        parts: {
          ...state.parts,
          [d.part_id]: {
            part_id: d.part_id,
            message_id: d.message_id,
            type: d.type,
            text: "",
            finished: false,
          },
        },
      };
    }
    case "message.text.delta":
    case "message.thinking.delta": {
      const d = ev.data as EventPayloadMap["message.text.delta"];
      const prev = state.parts[d.part_id];
      if (!prev) {
        return state;
      }
      return {
        ...state,
        parts: {
          ...state.parts,
          [d.part_id]: {
            ...prev,
            text: prev.text + d.text,
          },
        },
      };
    }
    case "message.part.finished": {
      const d = ev.data as EventPayloadMap["message.part.finished"];
      const prev = state.parts[d.part_id];
      if (!prev) {
        return state;
      }
      return {
        ...state,
        parts: {
          ...state.parts,
          [d.part_id]: {
            ...prev,
            finished: true,
          },
        },
      };
    }
    case "message.finished": {
      const d = ev.data as EventPayloadMap["message.finished"];
      return {
        ...state,
        usage: {
          ...state.usage,
          input: d.usage.input ?? state.usage.input,
          output: d.usage.output ?? state.usage.output,
          cached: d.usage.cached ?? state.usage.cached,
          reasoning: d.usage.reasoning ?? state.usage.reasoning,
          cost: d.usage.cost ?? state.usage.cost,
        },
      };
    }
    case "plan.updated": {
      const d = ev.data as EventPayloadMap["plan.updated"];
      return {
        ...state,
        plan: d.items.map((item) => ({
          id: item.id,
          title: item.title,
          status: item.status,
        })),
      };
    }
    case "tool.call.proposed": {
      const d = ev.data as EventPayloadMap["tool.call.proposed"];
      const prev = state.tool_calls[d.call_id];
      const ordered =
        d.call_id in state.tool_calls
          ? state.ordered_tool_call_ids
          : [...state.ordered_tool_call_ids, d.call_id];
      return {
        ...state,
        ordered_tool_call_ids: ordered,
        tool_calls: {
          ...state.tool_calls,
          [d.call_id]: prev
            ? {
                ...prev,
                name: d.name,
                args: d.args,
                risk: d.risk,
              }
            : {
                call_id: d.call_id,
                name: d.name,
                args: d.args,
                risk: d.risk,
                status: "proposed",
                approval_id: null,
                approval_decision: null,
                stdout: "",
                stderr: "",
                pct: null,
                progress_label: "",
                ok: null,
                summary: "",
                render_hint: "text",
              },
        },
      };
    }
    case "tool.approval.requested": {
      const d = ev.data as EventPayloadMap["tool.approval.requested"];
      const prev = state.tool_calls[d.call_id];
      const nextCalls = prev
        ? {
            ...state.tool_calls,
            [d.call_id]: {
              ...prev,
              status: "waiting_approval",
              approval_id: d.approval_id,
            },
          }
        : state.tool_calls;
      return {
        ...state,
        status: "waiting_approval",
        tool_calls: nextCalls,
        approvals: {
          ...state.approvals,
          [d.approval_id]: {
            approval_id: d.approval_id,
            call_id: d.call_id,
            reason: d.reason,
            expires_at: d.expires_at ?? "",
            status: "pending",
            decision: null,
          },
        },
      };
    }
    case "tool.approval.resolved": {
      const d = ev.data as EventPayloadMap["tool.approval.resolved"];
      const updatedCalls: Record<string, ToolCallViewState> = { ...state.tool_calls };
      for (const [cid, tc] of Object.entries(updatedCalls)) {
        if (tc.approval_id === d.approval_id) {
          updatedCalls[cid] = {
            ...tc,
            approval_decision: d.decision,
            status: d.decision === "approve" ? "approved" : "denied",
          };
        }
      }
      const prevApp = state.approvals[d.approval_id];
      const nextApprovals = prevApp
        ? {
            ...state.approvals,
            [d.approval_id]: {
              ...prevApp,
              status: (d.decision === "approve" ? "approved" : "denied") as "approved" | "denied",
              decision: d.decision,
            },
          }
        : state.approvals;
      return {
        ...state,
        status: state.status === "waiting_approval" ? "running" : state.status,
        tool_calls: updatedCalls,
        approvals: nextApprovals,
      };
    }
    case "tool.started": {
      const d = ev.data as EventPayloadMap["tool.started"];
      const prev = state.tool_calls[d.call_id];
      if (!prev) {
        return state;
      }
      if (
        prev.status === "succeeded" ||
        prev.status === "failed" ||
        prev.status === "denied" ||
        prev.ok !== null
      ) {
        return state;
      }
      return {
        ...state,
        tool_calls: {
          ...state.tool_calls,
          [d.call_id]: { ...prev, status: "running" },
        },
      };
    }
    case "tool.output.delta": {
      const d = ev.data as EventPayloadMap["tool.output.delta"];
      const prev = state.tool_calls[d.call_id];
      if (!prev) {
        return state;
      }
      return {
        ...state,
        tool_calls: {
          ...state.tool_calls,
          [d.call_id]: {
            ...prev,
            stdout: d.stream === "stderr" ? prev.stdout : prev.stdout + d.text,
            stderr: d.stream === "stderr" ? prev.stderr + d.text : prev.stderr,
          },
        },
      };
    }
    case "tool.progress": {
      const d = ev.data as EventPayloadMap["tool.progress"];
      const prev = state.tool_calls[d.call_id];
      if (!prev) {
        return state;
      }
      return {
        ...state,
        tool_calls: {
          ...state.tool_calls,
          [d.call_id]: {
            ...prev,
            pct: d.pct ?? null,
            progress_label: d.label,
          },
        },
      };
    }
    case "tool.result": {
      const d = ev.data as EventPayloadMap["tool.result"];
      const prev = state.tool_calls[d.call_id];
      if (!prev) {
        const ordered =
          d.call_id in state.tool_calls
            ? state.ordered_tool_call_ids
            : [...state.ordered_tool_call_ids, d.call_id];
        return {
          ...state,
          ordered_tool_call_ids: ordered,
          tool_calls: {
            ...state.tool_calls,
            [d.call_id]: {
              call_id: d.call_id,
              name: "tool",
              args: {},
              risk: "read",
              status: d.ok ? "succeeded" : "failed",
              approval_id: null,
              approval_decision: null,
              stdout: "",
              stderr: "",
              pct: null,
              progress_label: "",
              ok: d.ok,
              summary: d.summary,
              render_hint: d.render_hint ?? "text",
            },
          },
        };
      }
      return {
        ...state,
        tool_calls: {
          ...state.tool_calls,
          [d.call_id]: {
            ...prev,
            ok: d.ok,
            status: d.ok ? "succeeded" : "failed",
            summary: d.summary,
            render_hint: d.render_hint ?? "text",
          },
        },
      };
    }
    case "tool.denied": {
      const d = ev.data as EventPayloadMap["tool.denied"];
      const prev = state.tool_calls[d.call_id];
      if (!prev) {
        return state;
      }
      return {
        ...state,
        tool_calls: {
          ...state.tool_calls,
          [d.call_id]: {
            ...prev,
            status: "denied",
            summary: d.reason,
          },
        },
      };
    }
    case "subagent.started": {
      const d = ev.data as EventPayloadMap["subagent.started"];
      return {
        ...state,
        subagents: {
          ...state.subagents,
          [d.child_run_id]: {
            child_run_id: d.child_run_id,
            task: d.task,
            status: "running",
            summary: "",
          },
        },
      };
    }
    case "subagent.finished": {
      const d = ev.data as EventPayloadMap["subagent.finished"];
      const prev = state.subagents[d.child_run_id];
      if (!prev) {
        return state;
      }
      return {
        ...state,
        subagents: {
          ...state.subagents,
          [d.child_run_id]: {
            ...prev,
            status: d.status,
            summary: d.summary,
          },
        },
      };
    }
    case "citation.added": {
      const d = ev.data as EventPayloadMap["citation.added"];
      return {
        ...state,
        citations: [...state.citations, d.citation as unknown as Record<string, unknown>],
      };
    }
    case "source.opened": {
      const d = ev.data as EventPayloadMap["source.opened"];
      return {
        ...state,
        sources_opened: [...state.sources_opened, { url: d.url, title: d.title }],
      };
    }
    case "memory.used": {
      const d = ev.data as EventPayloadMap["memory.used"];
      const merged = new Set([...state.memories_used, ...d.ids]);
      return {
        ...state,
        memories_used: Array.from(merged),
      };
    }
    case "memory.updated": {
      const d = ev.data as EventPayloadMap["memory.updated"];
      return {
        ...state,
        memories_updated: [...state.memories_updated, { id: d.id, op: d.op }],
      };
    }
    case "artifact.created": {
      const d = ev.data as EventPayloadMap["artifact.created"];
      return {
        ...state,
        artifacts: {
          ...state.artifacts,
          [d.artifact_id]: {
            artifact_id: d.artifact_id,
            type: d.type,
            title: d.title,
            version: 1,
            content: "",
            summary: "",
          },
        },
      };
    }
    case "artifact.delta": {
      const d = ev.data as EventPayloadMap["artifact.delta"];
      const prev = state.artifacts[d.artifact_id];
      if (!prev) {
        return state;
      }
      return {
        ...state,
        artifacts: {
          ...state.artifacts,
          [d.artifact_id]: {
            ...prev,
            version: d.version,
            content: prev.content + d.text,
          },
        },
      };
    }
    case "artifact.version": {
      const d = ev.data as EventPayloadMap["artifact.version"];
      const prev = state.artifacts[d.artifact_id];
      if (!prev) {
        return state;
      }
      return {
        ...state,
        artifacts: {
          ...state.artifacts,
          [d.artifact_id]: {
            ...prev,
            version: d.version,
            summary: d.summary,
          },
        },
      };
    }
    case "usage.updated": {
      const d = ev.data as EventPayloadMap["usage.updated"];
      return {
        ...state,
        usage: {
          input: d.input,
          output: d.output,
          cached: d.cached,
          reasoning: d.reasoning,
          cost: d.cost,
          context_used: d.context_used,
          context_window: d.context_window,
        },
      };
    }
    case "context.compacted": {
      const d = ev.data as EventPayloadMap["context.compacted"];
      return {
        ...state,
        notices: [
          ...state.notices,
          {
            level: "info",
            code: "context_compacted",
            text: `Compacted ${d.removed_tokens} tokens`,
          },
        ],
      };
    }
    case "notice": {
      const d = ev.data as EventPayloadMap["notice"];
      return {
        ...state,
        notices: [...state.notices, { level: d.level, code: d.code, text: d.text }],
      };
    }
    case "steer.received": {
      const d = ev.data as EventPayloadMap["steer.received"];
      return {
        ...state,
        steers: [...state.steers, d.text],
      };
    }
    case "stream.resync": {
      const d = ev.data as EventPayloadMap["stream.resync"];
      return {
        ...state,
        resync_cursor: d.cursor,
        seq_gap_detected: false,
      };
    }
    case "stream.keepalive": {
      return state;
    }
  }
}

export type TimelineItemKind =
  | "thinking"
  | "tool"
  | "subagent"
  | "plan"
  | "artifact"
  | "approval"
  | "compaction"
  | "notice"
  | "error";

export interface TimelineItem {
  readonly id: string;
  readonly stepId: string;
  readonly index: number;
  readonly kind: TimelineItemKind;
  readonly title: string;
  readonly subtitle: string;
  readonly status: string;
  readonly durationMs: number;
  readonly defaultExpanded: boolean;
  readonly note?: string;
  readonly toolCall?: ToolCallViewState;
  readonly approval?: ApprovalViewState;
  readonly subagent?: SubagentViewState;
  readonly artifact?: ArtifactViewState;
  readonly thinkingText?: string;
}

export function explainToolCall(name: string, args: Record<string, unknown>): string {
  const str = (key: string): string => {
    const val = args[key];
    if (typeof val === "string") return val;
    if (typeof val === "number" || typeof val === "boolean") return String(val);
    return "";
  };
  switch (name) {
    case "run_shell": {
      const cmd = str("command").split("\n")[0]?.slice(0, 64) ?? "command";
      const cwd = str("cwd") || "/workspace";
      return `Run \`${cmd}\` in \`${cwd}\``;
    }
    case "read_file":
      return `Read \`${str("path") || "file"}\``;
    case "write_file":
      return `Write \`${str("path") || "file"}\``;
    case "edit_file":
      return `Edit \`${str("path") || "file"}\``;
    case "list_directory":
      return `List directory \`${str("path") || "."}\``;
    case "web_search":
      return `Search web for "${str("query") || "query"}"`;
    case "fetch_url":
      return `Fetch \`${str("url") || "url"}\``;
    case "browser_snapshot":
      return `Inspect browser page \`${str("url") || "page"}\``;
    case "query_db":
      return `Query \`${(str("sql") || "SELECT").slice(0, 48)}\``;
    default: {
      const keys = Object.keys(args);
      if (keys.length === 0) return `Call \`${name}\``;
      const firstKey = keys[0] ?? "";
      const firstVal = str(firstKey).slice(0, 40);
      return firstVal ? `${name}(${firstKey}: ${firstVal})` : `Call \`${name}\``;
    }
  }
}

export function selectTimelineItems(state: RunViewState): ReadonlyArray<TimelineItem> {
  const items: TimelineItem[] = [];
  let seqIndex = 0;

  // 1. Thinking parts
  for (const partId of state.ordered_part_ids) {
    const part = state.parts[partId];
    if (part && part.type === "thinking") {
      const status = part.finished ? "completed" : "running";
      items.push({
        id: `think_${part.part_id}`,
        stepId: `s_${seqIndex}`,
        index: seqIndex++,
        kind: "thinking",
        title: part.finished ? "Thought process" : "Thinking…",
        subtitle: `${part.text.length} chars`,
        status,
        durationMs: 120,
        defaultExpanded: !part.finished,
        thinkingText: part.text,
      });
    }
  }

  // 2. Plan item if present
  if (state.plan.length > 0) {
    const doneCount = state.plan.filter((p) => p.status === "done").length;
    const allDone = doneCount === state.plan.length;
    items.push({
      id: "plan_main",
      stepId: `s_${seqIndex}`,
      index: seqIndex++,
      kind: "plan",
      title: `Plan (${doneCount}/${state.plan.length} completed)`,
      subtitle: state.plan.map((p) => p.title).join(" · "),
      status: allDone ? "completed" : "running",
      durationMs: 40,
      defaultExpanded: !allDone,
    });
  }

  // 3. Tool calls (and associated approvals)
  const stepList = state.ordered_step_ids.map((id) => state.steps[id]).filter(Boolean);
  let toolStepIdx = 0;
  for (const callId of state.ordered_tool_call_ids) {
    const tc = state.tool_calls[callId];
    if (!tc) continue;
    const matchingStep = stepList[toolStepIdx];
    toolStepIdx += 1;
    const stepDuration = tc.duration_ms ?? matchingStep?.duration_ms ?? 40;
    const stepNote = matchingStep?.note;
    const isExpanded =
      state.ordered_tool_call_ids.length === 1 ||
      tc.status === "running" ||
      tc.status === "waiting_approval" ||
      tc.status === "failed" ||
      tc.status === "denied";

    items.push({
      id: `tc_${tc.call_id}`,
      stepId: matchingStep?.step_id ?? `s_${seqIndex}`,
      index: seqIndex++,
      kind: "tool",
      title: explainToolCall(tc.name, tc.args),
      subtitle: tc.summary || tc.name,
      status: tc.status,
      durationMs: stepDuration,
      defaultExpanded: isExpanded,
      ...(stepNote ? { note: stepNote } : {}),
      toolCall: tc,
      ...(tc.approval_id && state.approvals[tc.approval_id]
        ? { approval: state.approvals[tc.approval_id] }
        : {}),
    });
  }

  // 4. Orphan steps (e.g., synthetic or model steps when no tool calls matched them)
  for (let i = toolStepIdx; i < stepList.length; i += 1) {
    const st = stepList[i];
    if (!st) continue;
    if (state.ordered_tool_call_ids.length === 0 && st.kind !== "model") {
      items.push({
        id: `step_${st.step_id}`,
        stepId: st.step_id,
        index: seqIndex++,
        kind: "thinking",
        title: `Step ${st.index + 1} (${st.kind})`,
        subtitle: st.note ?? st.status,
        status: st.status,
        durationMs: st.duration_ms,
        defaultExpanded: st.status === "running" || st.status === "failed",
        ...(st.note ? { note: st.note } : {}),
      });
    } else if (st.note) {
      items.push({
        id: `step_${st.step_id}`,
        stepId: st.step_id,
        index: seqIndex++,
        kind: "notice",
        title: `Step ${st.index + 1} (${st.kind}) — ${st.note}`,
        subtitle: st.status,
        status: st.status,
        durationMs: st.duration_ms,
        defaultExpanded: false,
        note: st.note,
      });
    }
  }

  // 5. Sub-agents
  for (const sub of Object.values(state.subagents)) {
    items.push({
      id: `sub_${sub.child_run_id}`,
      stepId: `s_${seqIndex}`,
      index: seqIndex++,
      kind: "subagent",
      title: `Sub-agent: ${sub.task}`,
      subtitle: sub.summary || sub.status,
      status: sub.status,
      durationMs: 180,
      defaultExpanded: true,
      subagent: sub,
    });
  }

  // 6. Artifacts
  for (const art of Object.values(state.artifacts)) {
    items.push({
      id: `art_${art.artifact_id}`,
      stepId: `s_${seqIndex}`,
      index: seqIndex++,
      kind: "artifact",
      title: `Artifact: ${art.title} (v${art.version})`,
      subtitle: art.summary || art.type,
      status: "completed",
      durationMs: 35,
      defaultExpanded: false,
      artifact: art,
    });
  }

  // 7. Compaction & notices
  for (let i = 0; i < state.notices.length; i += 1) {
    const n = state.notices[i];
    if (!n) continue;
    const isCompaction = n.code === "context_compacted";
    items.push({
      id: `notice_${i}_${n.code}`,
      stepId: `s_${seqIndex}`,
      index: seqIndex++,
      kind: isCompaction ? "compaction" : "notice",
      title: isCompaction ? `Context compacted: ${n.text}` : n.text,
      subtitle: n.code,
      status: "completed",
      durationMs: 10,
      defaultExpanded: false,
    });
  }

  // 8. Error item if present
  if (state.error) {
    items.push({
      id: "run_error",
      stepId: `s_${seqIndex}`,
      index: seqIndex++,
      kind: "error",
      title: `Error (${state.error.code}): ${state.error.message}`,
      subtitle: state.error.retryable ? "Retryable" : "Fatal",
      status: "error",
      durationMs: 0,
      defaultExpanded: true,
    });
  }

  return items;
}

export interface RunSummaryMetrics {
  readonly durationMs: number;
  readonly durationSeconds: number;
  readonly stepCount: number;
  readonly toolCount: number;
  readonly inlineHeaderLabel: string;
  readonly totalTokens: number;
  readonly costUsd: number;
  readonly contextPct: number;
  readonly contextTone: "neutral" | "warning" | "danger";
}

export function selectRunSummaryMetrics(state: RunViewState): RunSummaryMetrics {
  const stepDurations = Object.values(state.steps).reduce(
    (acc, s) => acc + (s.duration_ms || 0),
    0,
  );
  const toolCount = state.ordered_tool_call_ids.length;
  const stepCount = Math.max(
    state.ordered_step_ids.length,
    toolCount + (state.plan.length > 0 ? 1 : 0),
  );
  const durationMs = Math.max(stepDurations, toolCount * 40, stepCount > 0 ? 1000 : 0);
  const durationSeconds = Math.max(1, Math.round(durationMs / 1000));
  const prefix =
    state.status === "running"
      ? `Working (${durationSeconds} s)`
      : state.status === "waiting_approval"
        ? `Waiting for approval (${durationSeconds} s)`
        : `Worked for ${durationSeconds} s`;
  const inlineHeaderLabel = `${prefix} · ${stepCount} ${
    stepCount === 1 ? "step" : "steps"
  } · ${toolCount} ${toolCount === 1 ? "tool" : "tools"}`;
  const totalTokens =
    (state.usage.input || 0) + (state.usage.output || 0) + (state.usage.reasoning || 0);
  const contextWindow = state.usage.context_window || 128000;
  const contextUsed = state.usage.context_used ?? totalTokens;
  const contextPct = Math.min(100, Math.round((contextUsed / contextWindow) * 100));
  const contextTone: "neutral" | "warning" | "danger" =
    contextPct >= 95 ? "danger" : contextPct >= 80 ? "warning" : "neutral";

  return {
    durationMs,
    durationSeconds,
    stepCount,
    toolCount,
    inlineHeaderLabel,
    totalTokens,
    costUsd: state.usage.cost || 0,
    contextPct,
    contextTone,
  };
}

export function replayRunEventsUpTo(
  events: ReadonlyArray<RunEventEnvelope>,
  maxSeq: number,
): RunViewState {
  const filtered = events.filter((ev) => ev.seq <= maxSeq);
  return reduceRunState(filtered, undefined, { ignoreDuplicates: true });
}
