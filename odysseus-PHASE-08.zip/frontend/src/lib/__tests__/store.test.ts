import { describe, expect, it } from "vitest";
import { CrossTabSyncBus } from "../broadcast";
import type { RunEventEnvelope } from "../contracts/events.gen";
import {
  clearClientDiagnostics,
  exportDiagnosticsJson,
  getClientDiagnostics,
  recordClientDiagnostic,
  scrubDiagnosticText,
} from "../diagnostics";
import { validateJsonAgainstSchema } from "../lazy/codemirrorEditor";
import { renderMermaidToSafeHtml } from "../lazy/mermaidRenderer";
import { normalizeLanguage } from "../lazy/shikiHighlighter";
import { createOdysseusQueryClient, odysseusQueryClient } from "../queryClient";
import { useAppShellStore } from "../store";
import { computeClientContextMeter, estimateTextTokens } from "../tokens";

describe("useAppShellStore, tokens, diagnostics, broadcast, and lazy modules", () => {
  it("manages auth, UI, theme, composer, and run reducer slices", () => {
    const s = useAppShellStore.getState();
    expect(s.locale).toBe("en");
    expect(s.user).toBeNull();

    s.setLocale("id");
    expect(useAppShellStore.getState().locale).toBe("id");
    s.setLocale("en");

    s.setUser(
      {
        id: "u_1",
        username: "admin",
        email: "admin@odysseus.local",
        privileges: ["admin", "chat"],
        must_change_password: false,
        totp_enabled: false,
        mfa_pending: false,
      },
      "csrf_123",
    );
    expect(useAppShellStore.getState().user?.username).toBe("admin");
    expect(useAppShellStore.getState().csrfToken).toBe("csrf_123");

    // UI actions
    s.setWorkspace("settings");
    expect(useAppShellStore.getState().activeWorkspace).toBe("settings");
    s.setWorkspace("chat");

    s.setActiveChatId("c_1");
    s.setActiveProjectId("p_1");
    s.setSidebarCollapsed(true);
    s.setSidebarWidth(320);
    s.setMobileDrawerOpen(true);
    s.setCommandPaletteOpen(true);
    s.setShortcutsModalOpen(true);
    s.setOnboardingOpen(true);
    s.setInChatSearch(true, "quantum");
    s.setConnectionStatus("reconnecting");
    s.setDegradedServices([
      { service: "chromadb", status: "degraded", reason: "offline", fix_hint: "start chroma" },
    ]);
    s.setTemporaryChatMode(true);
    s.setDevRawMode(true);
    s.toggleBookmark("m_1");
    expect(useAppShellStore.getState().bookmarks).toContain("m_1");
    s.toggleBookmark("m_1");
    expect(useAppShellStore.getState().bookmarks).not.toContain("m_1");
    s.saveScrollPosition("c_1", 420);
    expect(useAppShellStore.getState().scrollPositions["c_1"]).toBe(420);

    const tid = s.addToast({ message: "Deleted chat", variant: "info" });
    expect(useAppShellStore.getState().toasts.some((t) => t.id === tid)).toBe(true);
    s.dismissToast(tid);
    expect(useAppShellStore.getState().toasts.some((t) => t.id === tid)).toBe(false);

    // Theme & Settings actions
    s.setTheme("light");
    s.setPalette("amber");
    s.setDensity("compact");
    s.setFontSize("lg");
    s.setMessageWidth("wide");
    s.setShowReasoning(false);
    s.setEnterToSend(false);
    s.setKeybinding("newChat", "Ctrl+Shift+N");
    expect(useAppShellStore.getState().theme).toBe("light");
    expect(useAppShellStore.getState().palette).toBe("amber");
    expect(useAppShellStore.getState().keybindings["newChat"]).toBe("Ctrl+Shift+N");

    // Composer actions
    s.setSelectedModel("fake/reasoning");
    s.setDraft("c_1", "Hello draft");
    expect(useAppShellStore.getState().draftsByChatId["c_1"]).toBe("Hello draft");
    s.setDraft("c_1", "");
    expect(useAppShellStore.getState().draftsByChatId["c_1"]).toBeUndefined();

    s.setQueuedMessage("c_1", "Follow-up question");
    expect(useAppShellStore.getState().queuedMessagesByChatId["c_1"]).toBe("Follow-up question");
    s.setQueuedMessage("c_1", null);
    expect(useAppShellStore.getState().queuedMessagesByChatId["c_1"]).toBeUndefined();

    s.upsertAttachment("c_1", {
      id: "att_1",
      sha256: "abc",
      filename: "notes.txt",
      mimeType: "text/plain",
      sizeBytes: 120,
      progressPct: 50,
      status: "uploading",
    });
    s.upsertAttachment("c_1", {
      id: "att_1",
      sha256: "abc",
      filename: "notes.txt",
      mimeType: "text/plain",
      sizeBytes: 120,
      progressPct: 100,
      status: "ready",
    });
    expect(useAppShellStore.getState().attachmentsByChatId["c_1"]?.[0]?.status).toBe("ready");
    s.removeAttachment("c_1", "att_1");
    expect(useAppShellStore.getState().attachmentsByChatId["c_1"]).toHaveLength(0);
    s.clearAttachments("c_1");

    s.setComposerModes("c_1", { webSearch: true, thinkingEffort: "high" });
    expect(useAppShellStore.getState().modesByChatId["c_1"]?.webSearch).toBe(true);
    s.pushPromptHistory("First prompt");
    s.pushPromptHistory("Second prompt");
    expect(useAppShellStore.getState().promptHistory[0]).toBe("Second prompt");

    // Runs actions
    s.setActiveRunForChat("c_1", "r_store_1");
    const ev1: RunEventEnvelope = {
      seq: 1,
      run_id: "r_store_1",
      ts: "2026-10-03T00:00:00Z",
      type: "run.started",
      data: {
        model: "fake/default",
        budget: { max_iters: 10, max_tokens: 1000, max_cost: 1, max_seconds: 60 },
      },
    };
    const ev2: RunEventEnvelope = {
      seq: 2,
      run_id: "r_store_1",
      ts: "2026-10-03T00:00:01Z",
      type: "run.finished",
      data: {
        reason: "completed",
        usage: { input: 10, output: 20, cached: 0, reasoning: 0, cost: 0 },
      },
    };
    s.applyRunEvent("c_1", ev1);
    expect(useAppShellStore.getState().activeRunIdByChatId["c_1"]).toBe("r_store_1");
    s.applyRunEvents("c_1", "r_store_1", [ev1, ev2]);
    expect(useAppShellStore.getState().activeRunIdByChatId["c_1"]).toBeNull();
    expect(useAppShellStore.getState().runsById["r_store_1"]?.status).toBe("completed");
  });

  it("computes token estimates and context meter warning levels", () => {
    expect(estimateTextTokens("")).toBe(0);
    expect(estimateTextTokens("12345678")).toBe(2);

    const normal = computeClientContextMeter({
      model: "fake/default",
      contextWindow: 4096,
      userPrompt: "Hello world",
    });
    expect(normal.warningLevel).toBe("normal");

    const critical = computeClientContextMeter({
      model: "fake/small-4k",
      contextWindow: 4096,
      userPrompt: "A".repeat(16000),
    });
    expect(critical.warningLevel).toBe("critical");
    expect(critical.utilizationPct).toBeGreaterThanOrEqual(95);
  });

  it("records scrubbed client diagnostics and exports JSON bundle", () => {
    clearClientDiagnostics();
    expect(scrubDiagnosticText("Authorization: Bearer ody_secret_12345")).toContain("[REDACTED]");
    recordClientDiagnostic({
      category: "ui_error",
      route: "#/c/1",
      message: "Failed with token=sk-1234567890abcdef",
      code: "ERR_UI",
    });
    expect(getClientDiagnostics()).toHaveLength(1);
    const exported = exportDiagnosticsJson();
    expect(exported).toContain("[REDACTED]");
    expect(exported).not.toContain("sk-1234567890abcdef");
  });

  it("validates JSON settings against backend schema and handles Mermaid/Shiki edge cases", () => {
    const schema = {
      properties: {
        log_level: { type: "string" },
        rate_limit_burst: { type: "integer" },
        memory_enabled: { type: "boolean" },
      },
    };
    const editable = ["log_level", "rate_limit_burst", "memory_enabled"];

    expect(validateJsonAgainstSchema("{bad json", schema, editable).valid).toBe(false);
    expect(validateJsonAgainstSchema("[]", schema, editable).valid).toBe(false);
    expect(
      validateJsonAgainstSchema('{"secret_key": "x"}', schema, editable).errors[0],
    ).toContain("not runtime-editable");
    expect(
      validateJsonAgainstSchema('{"rate_limit_burst": "not_int"}', schema, editable).valid,
    ).toBe(false);
    expect(
      validateJsonAgainstSchema('{"rate_limit_burst": 50, "memory_enabled": true}', schema, editable)
        .valid,
    ).toBe(true);

    expect(renderMermaidToSafeHtml("").ok).toBe(false);
    expect(renderMermaidToSafeHtml("not_a_diagram\nA --> B").ok).toBe(false);
    expect(renderMermaidToSafeHtml("sequenceDiagram\nAlice->>Bob: Hi").ok).toBe(true);

    expect(normalizeLanguage("py")).toBe("python");
    expect(normalizeLanguage("tsx")).toBe("typescript");
    expect(normalizeLanguage("jsx")).toBe("javascript");
    expect(normalizeLanguage("rs")).toBe("rust");
    expect(normalizeLanguage("sh")).toBe("bash");

    const bus = new CrossTabSyncBus("test_chan");
    const unsub = bus.subscribe(() => {});
    bus.publish({ type: "auth_changed", authenticated: true });
    unsub();
    bus.close();

    const qc = createOdysseusQueryClient();
    qc.setQueryData(["chats"], [{ id: "c1", title: "Test" }]);
    expect(qc.getQueryData(["chats"])).toEqual([{ id: "c1", title: "Test" }]);
    odysseusQueryClient.setQueryData(["projects"], []);
    expect(odysseusQueryClient.getQueryData(["projects"])).toEqual([]);
  });
});
