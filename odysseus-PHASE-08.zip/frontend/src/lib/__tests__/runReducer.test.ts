import fs from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";
import type { RunEventEnvelope } from "../contracts/events.gen";
import { createInitialRunViewState, reduceRunState, reduceSingleRunEvent } from "../runReducer";

const FIXTURES_DIR = path.resolve(__dirname, "../../../../contracts/fixtures");

function loadGoldenFixture(filename: string): ReadonlyArray<RunEventEnvelope> {
  const raw = fs.readFileSync(path.join(FIXTURES_DIR, filename), "utf-8");
  return JSON.parse(raw) as ReadonlyArray<RunEventEnvelope>;
}

describe("reduceRunState against all 13 golden fixtures", () => {
  it("replays all 13 golden JSON fixtures in contracts/fixtures deterministically", () => {
    const files = fs
      .readdirSync(FIXTURES_DIR)
      .filter((f) => f.endsWith(".json"))
      .sort();
    expect(files.length).toBeGreaterThanOrEqual(13);

    for (const file of files) {
      const events = loadGoldenFixture(file);
      const stateOneShot = reduceRunState(events);
      let stateStepByStep = createInitialRunViewState();
      for (const ev of events) {
        stateStepByStep = reduceSingleRunEvent(stateStepByStep, ev);
      }
      expect(stateStepByStep).toEqual(stateOneShot);
      expect(stateOneShot.last_seq).toBe(events[events.length - 1]?.seq);
    }
  });

  it("01_plain_chat.json reconstructs completed chat message", () => {
    const events = loadGoldenFixture("01_plain_chat.json");
    const state = reduceRunState(events);
    expect(state.run_id).toBe("r_fixture_01_plain");
    expect(state.status).toBe("completed");
    expect(state.finish_reason).toBe("completed");
    expect(state.parts["p_text_1"]?.text).toBe("Hello! How can I help you today?");
    expect(state.parts["p_text_1"]?.finished).toBe(true);
    expect(state.ordered_part_ids).toEqual(["p_text_1"]);
    expect(state.usage.output).toBe(128);
  });

  it("02_long_code_answer.json reconstructs thinking and code parts", () => {
    const events = loadGoldenFixture("02_long_code_answer.json");
    const state = reduceRunState(events);
    expect(state.status).toBe("completed");
    expect(state.parts["p_think_1"]?.type).toBe("thinking");
    expect(state.parts["p_think_1"]?.text).toContain("token bucket");
    expect(state.parts["p_code_1"]?.text).toContain("class RateLimiter:");
  });

  it("03_agent_six_tools_approval.json reconstructs 6 tools, approval, and plan", () => {
    const events = loadGoldenFixture("03_agent_six_tools_approval.json");
    const state = reduceRunState(events);
    expect(state.status).toBe("completed");
    expect(Object.keys(state.tool_calls)).toHaveLength(6);
    expect(state.ordered_tool_call_ids).toHaveLength(6);
    expect(state.tool_calls["tc_6"]?.approval_decision).toBe("approve");
    expect(state.tool_calls["tc_6"]?.status).toBe("succeeded");
    expect(state.tool_calls["tc_6"]?.stdout).toContain("run_shell: ok");
    expect(state.plan).toHaveLength(2);
    expect(state.plan[0]?.status).toBe("done");
  });

  it("04_research_run.json reconstructs sources, citations, memory, and artifacts", () => {
    const events = loadGoldenFixture("04_research_run.json");
    const state = reduceRunState(events);
    expect(state.status).toBe("completed");
    expect(state.memories_used).toEqual(["mem_1", "mem_2"]);
    expect(state.memories_updated).toEqual([{ id: "mem_3", op: "created" }]);
    expect(state.sources_opened).toHaveLength(1);
    expect(state.citations).toHaveLength(1);
    expect(state.artifacts["art_1"]?.content).toContain("# Research Findings");
    expect(state.artifacts["art_1"]?.summary).toBe("Initial synthesis report");
  });

  it("05_subagent_tree.json reconstructs subagents, steers, compaction, and usage", () => {
    const events = loadGoldenFixture("05_subagent_tree.json");
    const state = reduceRunState(events);
    expect(state.status).toBe("completed");
    expect(state.subagents["r_child_01"]?.status).toBe("completed");
    expect(state.steers).toHaveLength(1);
    expect(state.notices.length).toBeGreaterThanOrEqual(2);
  });

  it("06_cancelled_run.json records cancelled status and preserves partial text", () => {
    const events = loadGoldenFixture("06_cancelled_run.json");
    const state = reduceRunState(events);
    expect(state.status).toBe("cancelled");
    expect(state.finish_reason).toBe("cancelled");
    expect(state.parts["p_6"]?.text).toBe("Partial response before ");
  });

  it("07_error_run.json records tool denial and run error", () => {
    const events = loadGoldenFixture("07_error_run.json");
    const state = reduceRunState(events);
    expect(state.status).toBe("error");
    expect(state.tool_calls["tc_err_1"]?.status).toBe("denied");
    expect(state.error?.code).toBe("provider_rate_limit");
    expect(state.error?.retryable).toBe(true);
  });

  it("08_interrupted_and_resumed_run.json handles interruption, resync, and completion", () => {
    const events = loadGoldenFixture("08_interrupted_and_resumed_run.json");
    const midState = reduceRunState(events.slice(0, 4));
    expect(midState.status).toBe("interrupted");

    const finalState = reduceRunState(events.slice(4), midState);
    expect(finalState.resync_cursor).toBe(4);
    expect(finalState.status).toBe("completed");
    expect(finalState.parts["p_8"]?.text).toBe(
      "Step 1 before restart. Resumed after restart!",
    );
  });

  it("rejects non-monotonic sequence numbers, detects seq gaps, and handles ignoreDuplicates", () => {
    const initial = createInitialRunViewState();
    const e1: RunEventEnvelope = {
      seq: 1,
      run_id: "r_1",
      ts: "2026-10-03T00:00:00Z",
      type: "run.status",
      data: { status: "running" },
    };
    const e2Gap: RunEventEnvelope = {
      seq: 4,
      run_id: "r_1",
      ts: "2026-10-03T00:00:01Z",
      type: "run.status",
      data: { status: "paused" },
    };

    const gapped = reduceRunState([e1, e2Gap], initial, { rejectSeqGaps: true });
    expect(gapped.seq_gap_detected).toBe(true);
    expect(gapped.resync_cursor).toBe(1);
    expect(gapped.last_seq).toBe(1);

    // Duplicate seq is ignored when ignoreDuplicates=true, throws when false
    const dup = reduceRunState([e1, e1], initial, { ignoreDuplicates: true });
    expect(dup.last_seq).toBe(1);
    expect(() => reduceRunState([e1, e1], initial)).toThrow(/Non-monotonic/);

    const eOtherRun: RunEventEnvelope = {
      seq: 2,
      run_id: "r_2",
      ts: "2026-10-03T00:00:02Z",
      type: "run.status",
      data: { status: "running" },
    };
    expect(() => reduceRunState([e1, eOtherRun], initial)).toThrow(/Mismatched run_id/);
  });
});
