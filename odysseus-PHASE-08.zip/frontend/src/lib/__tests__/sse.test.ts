import { describe, expect, it } from "vitest";
import type { RunEventEnvelope } from "../contracts/events.gen";
import {
  IncrementalSseFrameParser,
  SseStreamClient,
  type SseConnectionStatus,
  computeBackoffWithJitter,
} from "../sse";

function makeReadableStream(chunks: ReadonlyArray<string>): ReadableStream<Uint8Array> {
  const encoder = new TextEncoder();
  let idx = 0;
  return new ReadableStream<Uint8Array>({
    pull(controller) {
      if (idx < chunks.length) {
        controller.enqueue(encoder.encode(chunks[idx]!));
        idx += 1;
      } else {
        controller.close();
      }
    },
  });
}

describe("IncrementalSseFrameParser and SseStreamClient", () => {
  it("parses multi-line data, comments, id, event, retry across arbitrary chunk splits", () => {
    const parser = new IncrementalSseFrameParser();
    const raw =
      ": keepalive\r\n" +
      "id: 1\r\n" +
      "event: message.text.delta\r\n" +
      "retry: 500\r\n" +
      'data: {"seq":1,\r\n' +
      'data: "run_id":"r_1","ts":"2026-10-03T00:00:00Z","type":"message.text.delta","data":{"message_id":"m1","part_id":"p1","text":"hi"}}\r\n\r\n';

    // Feed 3 characters at a time
    const frames = [];
    for (let i = 0; i < raw.length; i += 3) {
      frames.push(...parser.feed(raw.slice(i, i + 3)));
    }
    expect(frames).toHaveLength(1);
    expect(frames[0]?.id).toBe("1");
    expect(frames[0]?.event).toBe("message.text.delta");
    expect(frames[0]?.retryMs).toBe(500);
    const parsed = JSON.parse(frames[0]!.data.replace("\n", "")) as RunEventEnvelope;
    expect(parsed.seq).toBe(1);
  });

  it("reconnects with Last-Event-ID & after=<cursor>, handles stream.resync, and stops on run.finished", async () => {
    const receivedUrls: string[] = [];
    const receivedLastEventIds: Array<string | null> = [];
    const statuses: SseConnectionStatus[] = [];
    const events: RunEventEnvelope[] = [];
    let resyncCalledWith: number | null = null;

    let callCount = 0;
    const fakeFetch: typeof fetch = async (input, init) => {
      callCount += 1;
      receivedUrls.push(String(input));
      const hdrs = (init?.headers ?? {}) as Record<string, string>;
      receivedLastEventIds.push(hdrs["Last-Event-ID"] ?? null);

      if (callCount === 1) {
        // First connection sends seq 1 then drops mid-stream
        const e1: RunEventEnvelope = {
          seq: 1,
          run_id: "r_sse_1",
          ts: "2026-10-03T00:00:01Z",
          type: "run.started",
          data: {
            model: "fake/default",
            budget: { max_iters: 10, max_tokens: 1000, max_cost: 1, max_seconds: 60 },
          },
        };
        return new Response(makeReadableStream([`id: 1\ndata: ${JSON.stringify(e1)}\n\n`]), {
          status: 200,
          headers: { "Content-Type": "text/event-stream" },
        });
      }

      // Second connection receives stream.resync and run.finished
      const eResync: RunEventEnvelope = {
        seq: 2,
        run_id: "r_sse_1",
        ts: "2026-10-03T00:00:02Z",
        type: "stream.resync",
        data: { reason: "slow_consumer", cursor: 2 },
      };
      const eFin: RunEventEnvelope = {
        seq: 3,
        run_id: "r_sse_1",
        ts: "2026-10-03T00:00:03Z",
        type: "run.finished",
        data: {
          reason: "completed",
          usage: { input: 5, output: 10, cached: 0, reasoning: 0, cost: 0 },
        },
      };
      return new Response(
        makeReadableStream([
          `id: 2\ndata: ${JSON.stringify(eResync)}\n\n`,
          `id: 3\ndata: ${JSON.stringify(eFin)}\n\n`,
        ]),
        {
          status: 200,
          headers: { "Content-Type": "text/event-stream" },
        },
      );
    };

    const client = new SseStreamClient({
      url: "http://localhost/api/runs/r_sse_1/events",
      fetchImpl: fakeFetch,
      baseBackoffMs: 10,
      maxBackoffMs: 25,
      onEvent: (ev) => events.push(ev),
      onResync: (cursor) => {
        resyncCalledWith = cursor;
        return cursor;
      },
      onStatusChange: (st) => statuses.push(st),
    });

    await client.start();

    expect(callCount).toBe(2);
    expect(receivedUrls[0]).toContain("after=0");
    expect(receivedLastEventIds[0]).toBeNull();
    expect(receivedUrls[1]).toContain("after=1");
    expect(receivedLastEventIds[1]).toBe("1");
    expect(resyncCalledWith).toBe(2);
    expect(events.map((e) => e.type)).toEqual(["run.started", "stream.resync", "run.finished"]);
    expect(client.getCursor()).toBe(3);
    expect(statuses).toContain("connected");
    expect(statuses[statuses.length - 1]).toBe("closed");
  });

  it("computes bounded exponential backoff with jitter", () => {
    const b0 = computeBackoffWithJitter(0, 100, 2000, () => 0.5);
    const b3 = computeBackoffWithJitter(3, 100, 2000, () => 0.5);
    const b10 = computeBackoffWithJitter(10, 100, 2000, () => 1.0);
    expect(b0).toBe(75);
    expect(b3).toBe(600);
    expect(b10).toBe(2000);
  });
});
