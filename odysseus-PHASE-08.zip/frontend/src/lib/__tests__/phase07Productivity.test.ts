import { describe, expect, it } from "vitest";
import {
  describeCronHumanReadable,
  extractSanitizedLinks,
} from "../../features/productivity/ProductivityWorkspacesView";
import { useAppShellStore } from "../store";

describe("Phase 07 Productivity Suite — Helpers & Workspace Store", () => {
  it("describes cron expressions in human-readable form (FE-WORK-07)", () => {
    expect(describeCronHumanReadable("0 9 * * 1-5")).toBe("Weekdays (Mon–Fri) at 09:00");
    expect(describeCronHumanReadable("0 8 * * *")).toBe("Every day at 08:00");
    expect(describeCronHumanReadable("*/15 * * * *")).toBe("Every 15 minutes");
    expect(describeCronHumanReadable("0 0 * * 0")).toBe("Sundays at midnight");
    expect(describeCronHumanReadable("5 4 * * *")).toContain("5 4 * * *");
  });

  it("extracts destination URLs and flags blocked spoofed links in sanitized email HTML (FE-WORK-04)", () => {
    const html = `
      <p>Read the <a href="https://docs.odysseus.example/spec">Spec Doc</a> or
      <a href="about:blank#blocked-spoofed-link">https://bank.example/login</a></p>
    `;
    const links = extractSanitizedLinks(html);
    expect(links).toHaveLength(2);
    expect(links[0]).toEqual({
      href: "https://docs.odysseus.example/spec",
      text: "Spec Doc",
      spoofed: false,
    });
    expect(links[1]?.spoofed).toBe(true);
  });

  it("supports switching activeWorkspace to mail, notes, calendar, and schedules", () => {
    const store = useAppShellStore.getState();
    for (const route of ["mail", "notes", "calendar", "schedules"] as const) {
      store.setWorkspace(route);
      expect(useAppShellStore.getState().activeWorkspace).toBe(route);
    }
    store.setWorkspace("chat");
  });
});
