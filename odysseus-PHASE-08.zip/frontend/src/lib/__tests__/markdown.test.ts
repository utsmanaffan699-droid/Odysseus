import fc from "fast-check";
import { describe, expect, it } from "vitest";
import {
  type MarkdownBlock,
  clearMarkdownBlockCache,
  renderMarkdownToHtml,
  sanitizeUrl,
  splitMarkdownBlocks,
} from "../markdown";

const MARKDOWN_SNIPPETS: ReadonlyArray<string> = [
  "# Heading 1\n\nParagraph with **bold**, *italic*, ~~strike~~, and `inline_code()`.",
  '```python title="limiter.py"\ndef allow(tokens: int) -> bool:\n    return tokens > 0\n```',
  "| Service | Status | Latency |\n| --- | --- | --- |\n| Database | Ready | 1.2ms |\n| Vector | Degraded | 45ms |",
  "- [x] Complete reducer\n- [ ] Verify streaming\n- Regular bullet with [1] citation",
  "> Blockquote line 1\n> Blockquote line 2 with $E = mc^2$",
  "$$\n\\int_0^\\infty e^{-x^2} dx = \\frac{\\sqrt{\\pi}}{2}\n$$",
  "```mermaid\ngraph TD\n  A[Start] --> B[Finish]\n```",
  "```diff\n@@ -1,2 +1,2 @@\n-old_line = 1\n+new_line = 2\n```",
  "<details><summary>Expand details</summary>Hidden body content</details>",
  "RTL: مرحبا بالعالم שָׁלוֹם | Emoji ZWJ: 👨‍👩‍👧‍👦 🏳️‍🌈 👩🏽‍🔬 | Combining: e\u0301 a\u0308",
  "Safe link [Odysseus](https://example.com/docs) and footnote ref [^fn1]\n\n[^fn1]: Footnote explanation.",
];

export function buildXssCorpus(): ReadonlyArray<string> {
  const basePayloads: string[] = [
    '<script>window.__xss = 1;</script>',
    '<SCRIPT SRC="http://evil.example/xss.js"></SCRIPT>',
    '<img src="x" onerror="window.__xss=1">',
    '<img src=x onerror=alert(1)//>',
    '<svg onload="window.__xss=1"><circle r="10"/></svg>',
    '<svg><script>alert(1)</script></svg>',
    '<svg><animate onbegin="alert(1)" attributeName="x"/></svg>',
    '<svg><foreignObject><iframe srcdoc="<script>alert(1)</script>"></iframe></foreignObject></svg>',
    '<math><mtext><option><FAKEFAKE><option></option><mglyph><svg><mtext><style><a title="</style><img src=x onerror=alert(1)>">',
    '<math href="javascript:alert(1)">CLICK</math>',
    '<noscript><p title="</noscript><img src=x onerror=alert(1)>">',
    '<form><math><mtext></form><form><mglyph><style></math><img src onerror=alert(1)>',
    '<iframe src="javascript:alert(1)"></iframe>',
    '<object data="javascript:alert(1)"></object>',
    '<embed src="javascript:alert(1)">',
    '<details open ontoggle="alert(1)"><summary>Summary</summary>Body</details>',
    '<body onload="alert(1)">',
    '<input autofocus onfocus="alert(1)">',
    '<a href="javascript:alert(1)">Click</a>',
    '[Click](javascript:alert(1))',
    '[Click](JaVaScRiPt:alert(1))',
    '[Click](&#106;&#97;&#118;&#97;&#115;&#99;&#114;&#105;&#112;&#116;&#58;alert(1))',
    '[Click](&#x6a;&#x61;&#x76;&#x61;&#x73;&#x63;&#x72;&#x69;&#x70;&#x74;:alert(1))',
    '[Click](java\u0000script:alert(1))',
    '[Click](java\tscript:alert(1))',
    '[Click](java\u200bscript:alert(1))',
    '[Click](vbscript:msgbox(1))',
    '[Click](data:text/html;base64,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==)',
    '![Alt](javascript:alert(1))',
    '![Alt](data:image/svg+xml;base64,PHN2ZyBvbmxvYWQ9ImFsZXJ0KDEpIj48L3N2Zz4=)',
    '![Alt](https://example.com/pic.png" onerror="alert(1))',
    '<div style="background:url(javascript:alert(1))">CSS</div>',
    '<style>@import "javascript:alert(1)"; body { width: expression(alert(1)); }</style>',
    '$$\\href{javascript:alert(1)}{ClickMath}$$',
    '$$\\url{javascript:alert(1)}$$',
    '$$\\htmlData{foo=bar}{x}$$',
    '$$\\write18{rm -rf /}$$',
    '```mermaid\n%%{init: {"securityLevel": "loose"}}%%\ngraph TD\n  A --> B\n  click A "javascript:alert(1)"\n```',
    '```mermaid\ngraph TD\n  A["<script>alert(1)</script>"] --> B["<img src=x onerror=alert(1)>"]\n```',
  ];

  // Expand systematically across HTML tags, event handlers, and encoding variants to exceed 210 payloads
  const tags = ["div", "span", "p", "a", "img", "svg", "math", "table", "td", "video", "audio", "marquee", "bgsound", "keygen", "isindex"];
  const events = ["onload", "onerror", "onclick", "onmouseover", "onfocus", "onblur", "onanimationstart", "ontoggle", "onpointerenter", "onauxclick", "onwheel", "oncopy"];

  for (const tag of tags) {
    for (const ev of events) {
      basePayloads.push(`<${tag} ${ev}="window.__xss=1">test</${tag}>`);
      if (basePayloads.length >= 220) break;
    }
    if (basePayloads.length >= 220) break;
  }

  return basePayloads;
}

describe("Markdown Streaming Renderer — Acceptance #2, #11 & Adversarial Torture", () => {
  it("Acceptance #2: Chunking invariance & closed-block immutability (fast-check, 2,000 runs)", () => {
    clearMarkdownBlockCache();

    const docArb = fc
      .array(fc.constantFrom(...MARKDOWN_SNIPPETS), { minLength: 1, maxLength: 5 })
      .map((parts) => parts.join("\n\n"));

    const chunkLengthsArb = fc.array(fc.integer({ min: 1, max: 37 }), {
      minLength: 1,
      maxLength: 60,
    });

    fc.assert(
      fc.property(docArb, chunkLengthsArb, (fullText, chunkSizes) => {
        const oneShotBlocks = splitMarkdownBlocks(fullText, false);
        const oneShotHtml = renderMarkdownToHtml(fullText, false);

        let cursor = 0;
        let stepIdx = 0;
        const committedClosedBlocks = new Map<number, MarkdownBlock>();

        while (cursor < fullText.length) {
          const step = chunkSizes[stepIdx % chunkSizes.length] ?? 7;
          cursor = Math.min(fullText.length, cursor + Math.max(1, step));
          stepIdx += 1;
          const prefix = fullText.slice(0, cursor);
          const isStillStreaming = cursor < fullText.length;

          const blocks = splitMarkdownBlocks(prefix, isStillStreaming);

          for (const b of blocks) {
            const previouslyClosed = committedClosedBlocks.get(b.index);
            if (previouslyClosed) {
              // Closed blocks must NEVER mutate in raw, hash, kind, or html!
              expect(b.closed).toBe(true);
              expect(b.hash).toBe(previouslyClosed.hash);
              expect(b.raw).toBe(previouslyClosed.raw);
              expect(b.kind).toBe(previouslyClosed.kind);
              expect(b.html).toBe(previouslyClosed.html);
            } else if (b.closed) {
              committedClosedBlocks.set(b.index, b);
            }
          }
        }

        const finalStreamedBlocks = splitMarkdownBlocks(fullText, false);
        const finalStreamedHtml = finalStreamedBlocks.map((b) => b.html).join("\n");

        expect(finalStreamedBlocks).toEqual(oneShotBlocks);
        expect(finalStreamedHtml).toBe(oneShotHtml);

        for (const [idx, closedBlock] of committedClosedBlocks.entries()) {
          expect(finalStreamedBlocks[idx]?.hash).toBe(closedBlock.hash);
          expect(finalStreamedBlocks[idx]?.html).toBe(closedBlock.html);
        }
      }),
      { numRuns: 2000 },
    );
  });

  it("Adversarial Streaming Torture Script: unclosed nested fences, cell-by-cell tables, 50 KB single line, 10k-line code block, RTL/ZWJ splits, repeated fence restarts", () => {
    // 1. Unclosed fences inside lists inside blockquotes
    const nestedUnclosed = "> - Item 1\n>   ```python\n>   def inside_quote():\n>       return 42";
    const b1 = splitMarkdownBlocks(nestedUnclosed, true);
    expect(b1.length).toBe(1);
    expect(b1[0]?.closed).toBe(false);

    // 2. Tables arriving cell by cell
    const tableSrc = "| Col A | Col B | Col C |\n| :--- | :---: | ---: |\n| val 1 | val 2 | val 3 |\n| r2c1 | r2c2 | r2c3 |";
    for (let i = 1; i <= tableSrc.length; i += 4) {
      const partial = splitMarkdownBlocks(tableSrc.slice(0, i), i < tableSrc.length);
      expect(partial.length).toBe(1);
    }
    const finalTable = splitMarkdownBlocks(tableSrc, false);
    expect(finalTable[0]?.kind).toBe("table");
    expect(finalTable[0]?.tableMeta?.headers).toEqual(["Col A", "Col B", "Col C"]);
    expect(finalTable[0]?.tableMeta?.rows).toHaveLength(2);

    // 3. 50 KB single line without newlines
    const line50kb = "A".repeat(51200);
    const t0 = performance.now();
    const res50kb = splitMarkdownBlocks(line50kb, false);
    const dt50kb = performance.now() - t0;
    expect(res50kb).toHaveLength(1);
    expect(dt50kb).toBeLessThan(100);

    // 4. 10,000-line code block
    const lines10k = "```python\n" + Array.from({ length: 10000 }, (_, i) => `x_${i} = ${i}`).join("\n") + "\n```";
    const t1 = performance.now();
    const res10k = splitMarkdownBlocks(lines10k, false);
    const dt10k = performance.now() - t1;
    expect(res10k).toHaveLength(1);
    expect(res10k[0]?.kind).toBe("code");
    expect(res10k[0]?.codeMeta?.lineCount).toBe(10000);
    expect(dt10k).toBeLessThan(250);

    // 5. RTL + emoji ZWJ sequences + combining marks split across chunk boundaries
    const unicodeTorture = "مرحبا 👨‍👩‍👧‍👦 שָׁלוֹם 👩🏽‍🔬 Z̸̢̛͚a̴̡l̵̛g̷̨o e\u0301";
    for (let i = 1; i <= unicodeTorture.length; i++) {
      expect(() => renderMarkdownToHtml(unicodeTorture.slice(0, i), i < unicodeTorture.length)).not.toThrow();
    }
    expect(renderMarkdownToHtml(unicodeTorture, false)).toContain("👨‍👩‍👧‍👦");

    // 6. Stream that restarts a fence repeatedly
    const repeatedFences = Array.from(
      { length: 12 },
      (_, idx) => `\`\`\`ts\nconst block_${idx} = ${idx};\n\`\`\``,
    ).join("\n\n");
    const fenceBlocks = splitMarkdownBlocks(repeatedFences, false);
    expect(fenceBlocks).toHaveLength(12);
    expect(fenceBlocks.every((b) => b.kind === "code" && b.closed)).toBe(true);
  });

  it("Acceptance #11: XSS corpus (>= 210 payloads) neutralizes all scripts, event handlers, and unsafe URLs", () => {
    const corpus = buildXssCorpus();
    expect(corpus.length).toBeGreaterThanOrEqual(210);

    const container = document.createElement("div");
    for (const payload of corpus) {
      const html = renderMarkdownToHtml(payload, false);
      container.innerHTML = html;

      expect(container.querySelector("script, iframe, object, embed, style")).toBeNull();

      const allElements = container.querySelectorAll("*");
      for (const el of Array.from(allElements)) {
        for (const attr of Array.from(el.attributes)) {
          expect(attr.name.toLowerCase().startsWith("on")).toBe(false);
          if (attr.name === "href" || attr.name === "src") {
            expect(attr.value).not.toMatch(/^\s*(?:javascript|vbscript|data:text\/html|data:image\/svg)/i);
          }
        }
      }
    }

    expect(sanitizeUrl("javascript:alert(1)").blocked).toBe(true);
    expect(sanitizeUrl("data:text/html,<script>alert(1)</script>").blocked).toBe(true);
    expect(sanitizeUrl("https://odysseus.local/docs").blocked).toBe(false);
  });
});
