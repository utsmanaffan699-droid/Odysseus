import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const SRC_ROOT = path.resolve(__dirname, "..", "..");

function walkFiles(dir: string, out: string[] = []): string[] {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (entry.name === "__tests__" || entry.name === "node_modules") continue;
      walkFiles(full, out);
    } else if (/\.(ts|tsx|css)$/.test(entry.name)) {
      out.push(full);
    }
  }
  return out;
}

describe("CI Contract Single-Source, Design Token Lint & Security Self-Audit", () => {
  it("forbids hand-written duplicate contract interfaces outside lib/contracts/*.gen.ts", () => {
    const files = walkFiles(SRC_ROOT).filter(
      (f) => !f.endsWith("api.gen.ts") && !f.endsWith("events.gen.ts"),
    );

    const forbiddenPatterns = [
      /interface\s+RunEventEnvelope\b/,
      /interface\s+HealthResponse\b/,
      /interface\s+AuthStatusResponse\b/,
      /interface\s+ChatDetailResponse\b/,
      /interface\s+ProviderModelCapability\b/,
    ];

    for (const file of files) {
      const content = fs.readFileSync(file, "utf-8");
      for (const pat of forbiddenPatterns) {
        expect(
          pat.test(content),
          `Duplicate contract interface ${pat} found in ${path.relative(SRC_ROOT, file)}`,
        ).toBe(false);
      }
    }
  });

  it("forbids hard-coded hex/rgb/hsl color literals outside design-system/tokens.css", () => {
    const files = walkFiles(SRC_ROOT).filter(
      (f) => !f.endsWith("tokens.css") && !f.endsWith("shikiHighlighter.ts"),
    );

    const colorRegex = /(#[0-9a-fA-F]{3,8}\b|\brgba?\s*\(|\bhsla?\s*\()/;

    for (const file of files) {
      const content = fs.readFileSync(file, "utf-8");
      expect(
        colorRegex.test(content),
        `Hard-coded color literal found in ${path.relative(SRC_ROOT, file)}`,
      ).toBe(false);
    }
  });

  it("audits dangerouslySetInnerHTML, innerHTML, eval, Function, and localStorage usage", () => {
    const files = walkFiles(SRC_ROOT);
    const allowedDangerouslySetFiles = new Set([
      path.join("features", "messages", "StreamingMarkdownMessage.tsx"),
      path.join("features", "shell", "AppSidebar.tsx"),
    ]);

    for (const file of files) {
      const rel = path.relative(SRC_ROOT, file);
      const content = fs.readFileSync(file, "utf-8");

      expect(/\beval\s*\(/.test(content), `eval() found in ${rel}`).toBe(false);
      expect(/\bnew\s+Function\s*\(/.test(content), `new Function() found in ${rel}`).toBe(false);
      expect(/\.innerHTML\s*=/.test(content), `Direct .innerHTML assignment in ${rel}`).toBe(
        false,
      );

      if (content.includes("dangerouslySetInnerHTML")) {
        expect(
          allowedDangerouslySetFiles.has(rel),
          `Unauthorized dangerouslySetInnerHTML in ${rel}`,
        ).toBe(true);
      }

      if (content.includes("localStorage")) {
        // Must only exist in lib/store.ts for UI prefs and drafts, never storing tokens or keys
        expect(rel, `Unexpected localStorage access in ${rel}`).toBe(
          path.join("lib", "store.ts"),
        );
        expect(/api_key|password|secret|bearer/i.test(content)).toBe(false);
      }
    }
  });
});
