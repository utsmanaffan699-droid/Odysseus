import { QueryClient } from "@tanstack/react-query";

/**
 * Shared TanStack Query client for Odysseus server state (FE-QA-04).
 * Configured with conservative retry/stale defaults suitable for local + self-hosted deployments.
 */
export function createOdysseusQueryClient(): QueryClient {
  return new QueryClient({
    defaultOptions: {
      queries: {
        staleTime: 5_000,
        gcTime: 5 * 60_000,
        retry: 1,
        refetchOnWindowFocus: false,
      },
    },
  });
}

export const odysseusQueryClient = createOdysseusQueryClient();
