import type { RunEventEnvelope } from "./contracts/events.gen";

export type SseConnectionStatus = "idle" | "connecting" | "connected" | "reconnecting" | "offline" | "closed";

export interface SseFrame {
  readonly id: string | null;
  readonly event: string | null;
  readonly data: string;
  readonly retryMs: number | null;
}

export class IncrementalSseFrameParser {
  private buffer = "";
  private currentId: string | null = null;
  private currentEvent: string | null = null;
  private currentDataLines: string[] = [];
  private currentRetryMs: number | null = null;

  public feed(chunk: string): ReadonlyArray<SseFrame> {
    this.buffer += chunk;
    const frames: SseFrame[] = [];

    let newlineIdx = this.buffer.indexOf("\n");
    while (newlineIdx !== -1) {
      let line = this.buffer.slice(0, newlineIdx);
      this.buffer = this.buffer.slice(newlineIdx + 1);
      if (line.endsWith("\r")) {
        line = line.slice(0, -1);
      }

      if (line === "") {
        // Blank line dispatches accumulated frame if data was seen
        if (this.currentDataLines.length > 0) {
          frames.push({
            id: this.currentId,
            event: this.currentEvent,
            data: this.currentDataLines.join("\n"),
            retryMs: this.currentRetryMs,
          });
        }
        this.currentId = null;
        this.currentEvent = null;
        this.currentDataLines = [];
        this.currentRetryMs = null;
      } else if (line.startsWith(":")) {
        // SSE comment / heartbeat (`: keepalive`) — ignored
      } else {
        const colonIdx = line.indexOf(":");
        const field = colonIdx === -1 ? line : line.slice(0, colonIdx);
        let value = colonIdx === -1 ? "" : line.slice(colonIdx + 1);
        if (value.startsWith(" ")) {
          value = value.slice(1);
        }

        if (field === "id") {
          this.currentId = value;
        } else if (field === "event") {
          this.currentEvent = value;
        } else if (field === "data") {
          this.currentDataLines.push(value);
        } else if (field === "retry") {
          const parsed = Number.parseInt(value, 10);
          if (!Number.isNaN(parsed) && parsed >= 0) {
            this.currentRetryMs = parsed;
          }
        }
      }

      newlineIdx = this.buffer.indexOf("\n");
    }

    return frames;
  }

  public reset(): void {
    this.buffer = "";
    this.currentId = null;
    this.currentEvent = null;
    this.currentDataLines = [];
    this.currentRetryMs = null;
  }
}

export function computeBackoffWithJitter(
  attempt: number,
  baseMs = 250,
  maxMs = 10000,
  randomFn: () => number = Math.random,
): number {
  const exp = Math.min(maxMs, baseMs * 2 ** Math.max(0, attempt));
  const jitter = 0.5 + randomFn() * 0.5;
  return Math.max(25, Math.round(exp * jitter));
}

export interface SseClientOptions {
  readonly url: string;
  readonly initialCursor?: number;
  readonly headers?: Record<string, string>;
  readonly fetchImpl?: typeof fetch;
  readonly maxRetries?: number;
  readonly baseBackoffMs?: number;
  readonly maxBackoffMs?: number;
  readonly onEvent: (envelope: RunEventEnvelope) => void;
  readonly onResync?: (cursor: number) => Promise<number | void> | number | void;
  readonly onStatusChange?: (status: SseConnectionStatus) => void;
  readonly onError?: (err: Error) => void;
}

const TERMINAL_RUN_EVENTS = new Set(["run.finished", "run.error"]);

export class SseStreamClient {
  private readonly options: SseClientOptions;
  private cursor: number;
  private abortController: AbortController | null = null;
  private status: SseConnectionStatus = "idle";
  private closedByCaller = false;
  private terminalReached = false;
  private retryAttempt = 0;
  private visibilityHidden = false;
  private pendingVisibilityQueue: RunEventEnvelope[] = [];
  private visibilityTimer: ReturnType<typeof setTimeout> | null = null;

  private readonly handleOnline = (): void => {
    if (!this.closedByCaller && !this.terminalReached && this.status === "offline") {
      this.setStatus("reconnecting");
    }
  };

  private readonly handleOffline = (): void => {
    if (!this.closedByCaller && !this.terminalReached) {
      this.setStatus("offline");
      this.abortController?.abort();
    }
  };

  private readonly handleVisibilityChange = (): void => {
    if (typeof document !== "undefined") {
      this.visibilityHidden = document.visibilityState === "hidden";
      if (!this.visibilityHidden) {
        this.flushVisibilityQueue();
      }
    }
  };

  constructor(options: SseClientOptions) {
    this.options = options;
    this.cursor = options.initialCursor ?? 0;
  }

  public getCursor(): number {
    return this.cursor;
  }

  public getStatus(): SseConnectionStatus {
    return this.status;
  }

  public async start(): Promise<void> {
    this.closedByCaller = false;
    this.terminalReached = false;
    if (typeof window !== "undefined") {
      window.addEventListener("online", this.handleOnline);
      window.addEventListener("offline", this.handleOffline);
    }
    if (typeof document !== "undefined") {
      document.addEventListener("visibilitychange", this.handleVisibilityChange);
    }

    const maxRetries = this.options.maxRetries ?? 8;
    const fetchFn = this.options.fetchImpl ?? fetch;

    while (!this.closedByCaller && !this.terminalReached) {
      if (typeof navigator !== "undefined" && navigator.onLine === false) {
        this.setStatus("offline");
        await this.sleep(200);
        continue;
      }

      this.setStatus(this.retryAttempt === 0 ? "connecting" : "reconnecting");
      this.abortController = new AbortController();

      const sep = this.options.url.includes("?") ? "&" : "?";
      const targetUrl = `${this.options.url}${sep}after=${this.cursor}`;
      const headers: Record<string, string> = {
        Accept: "text/event-stream",
        ...this.options.headers,
      };
      if (this.cursor > 0) {
        headers["Last-Event-ID"] = String(this.cursor);
      }

      try {
        const response = await fetchFn(targetUrl, {
          method: "GET",
          headers,
          credentials: "same-origin",
          signal: this.abortController.signal,
        });

        if (!response.ok || !response.body) {
          throw new Error(`SSE HTTP ${response.status}: ${response.statusText}`);
        }

        this.setStatus("connected");
        this.retryAttempt = 0;

        const reader = response.body.getReader();
        const decoder = new TextDecoder("utf-8");
        const parser = new IncrementalSseFrameParser();

        while (!this.closedByCaller && !this.terminalReached) {
          const { value, done } = await reader.read();
          if (done) {
            break;
          }
          const textChunk = decoder.decode(value, { stream: true });
          const frames = parser.feed(textChunk);
          for (const frame of frames) {
            await this.processFrame(frame);
            if (this.terminalReached || this.closedByCaller) {
              break;
            }
          }
        }

        // Flush remaining decoder bytes
        const tail = decoder.decode();
        if (tail) {
          for (const frame of parser.feed(tail + "\n\n")) {
            await this.processFrame(frame);
          }
        }

        if (this.terminalReached || this.closedByCaller) {
          break;
        }
      } catch (err) {
        if (this.closedByCaller) {
          break;
        }
        const errorObj = err instanceof Error ? err : new Error(String(err));
        this.options.onError?.(errorObj);
      }

      if (this.terminalReached || this.closedByCaller) {
        break;
      }

      this.retryAttempt += 1;
      if (this.retryAttempt > maxRetries) {
        this.setStatus("closed");
        break;
      }

      const waitMs = computeBackoffWithJitter(
        this.retryAttempt - 1,
        this.options.baseBackoffMs ?? 150,
        this.options.maxBackoffMs ?? 5000,
      );
      this.setStatus("reconnecting");
      await this.sleep(waitMs);
    }

    this.flushVisibilityQueue();
    this.cleanupListeners();
    this.setStatus("closed");
  }

  public stop(): void {
    this.closedByCaller = true;
    this.abortController?.abort();
    this.flushVisibilityQueue();
    this.cleanupListeners();
    this.setStatus("closed");
  }

  public retryNow(): void {
    if (!this.closedByCaller && !this.terminalReached) {
      this.retryAttempt = 0;
      this.setStatus("reconnecting");
    }
  }

  private async processFrame(frame: SseFrame): Promise<void> {
    let envelope: RunEventEnvelope;
    try {
      envelope = JSON.parse(frame.data) as RunEventEnvelope;
    } catch {
      return;
    }

    if (typeof envelope.seq === "number" && envelope.seq > this.cursor) {
      this.cursor = envelope.seq;
    }

    if (envelope.type === "stream.resync") {
      const resyncCursor =
        (envelope.data as { cursor?: number }).cursor ?? this.cursor;
      if (this.options.onResync) {
        const updatedCursor = await this.options.onResync(resyncCursor);
        if (typeof updatedCursor === "number") {
          this.cursor = updatedCursor;
        } else {
          this.cursor = resyncCursor;
        }
      } else {
        this.cursor = resyncCursor;
      }
    }

    if (this.visibilityHidden && !TERMINAL_RUN_EVENTS.has(envelope.type)) {
      this.pendingVisibilityQueue.push(envelope);
      if (!this.visibilityTimer) {
        this.visibilityTimer = setTimeout(() => {
          this.visibilityTimer = null;
          this.flushVisibilityQueue();
        }, 250);
      }
    } else {
      this.flushVisibilityQueue();
      this.options.onEvent(envelope);
    }

    if (TERMINAL_RUN_EVENTS.has(envelope.type)) {
      this.terminalReached = true;
    }
  }

  private flushVisibilityQueue(): void {
    if (this.visibilityTimer) {
      clearTimeout(this.visibilityTimer);
      this.visibilityTimer = null;
    }
    if (this.pendingVisibilityQueue.length > 0) {
      const batch = this.pendingVisibilityQueue.splice(0);
      for (const ev of batch) {
        this.options.onEvent(ev);
      }
    }
  }

  private setStatus(next: SseConnectionStatus): void {
    if (this.status !== next) {
      this.status = next;
      this.options.onStatusChange?.(next);
    }
  }

  private cleanupListeners(): void {
    if (typeof window !== "undefined") {
      window.removeEventListener("online", this.handleOnline);
      window.removeEventListener("offline", this.handleOffline);
    }
    if (typeof document !== "undefined") {
      document.removeEventListener("visibilitychange", this.handleVisibilityChange);
    }
  }

  private sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}
