export interface DiagnosticEntry {
  readonly id: string;
  readonly timestamp: string;
  readonly category: "ui_error" | "network_error" | "sse_error" | "route_boundary";
  readonly route: string;
  readonly message: string;
  readonly code?: string;
}

const MAX_RING_ENTRIES = 100;
const RING_BUFFER: DiagnosticEntry[] = [];

const SECRET_SCRUB_PATTERNS: ReadonlyArray<RegExp> = [
  /Bearer\s+[A-Za-z0-9._-]+/gi,
  /ody_[A-Za-z0-9_-]+/g,
  /sk-[A-Za-z0-9_-]{12,}/g,
  /(?:password|secret|api_key|token|csrf_token)\s*[:=]\s*["']?[^\s"',}]+/gi,
];

export function scrubDiagnosticText(input: string): string {
  let out = input;
  for (const pat of SECRET_SCRUB_PATTERNS) {
    out = out.replace(pat, "[REDACTED]");
  }
  return out.slice(0, 500);
}

export function recordClientDiagnostic(params: {
  category: DiagnosticEntry["category"];
  route?: string;
  message: string;
  code?: string;
}): DiagnosticEntry {
  const entry: DiagnosticEntry = {
    id: `diag_${Date.now()}_${RING_BUFFER.length}`,
    timestamp: new Date().toISOString(),
    category: params.category,
    route: params.route ?? (typeof window !== "undefined" ? window.location.hash || "/" : "/"),
    message: scrubDiagnosticText(params.message),
    ...(params.code ? { code: scrubDiagnosticText(params.code) } : {}),
  };

  if (RING_BUFFER.length >= MAX_RING_ENTRIES) {
    RING_BUFFER.shift();
  }
  RING_BUFFER.push(entry);
  return entry;
}

export function getClientDiagnostics(): ReadonlyArray<DiagnosticEntry> {
  return [...RING_BUFFER];
}

export function clearClientDiagnostics(): void {
  RING_BUFFER.length = 0;
}

export function exportDiagnosticsJson(): string {
  return JSON.stringify(
    {
      exportedAt: new Date().toISOString(),
      telemetry: "none",
      userAgent: typeof navigator !== "undefined" ? navigator.userAgent : "headless",
      entries: getClientDiagnostics(),
    },
    null,
    2,
  );
}

export function installGlobalDiagnosticsListeners(): () => void {
  if (typeof window === "undefined") {
    return () => {};
  }
  const onError = (ev: ErrorEvent): void => {
    recordClientDiagnostic({
      category: "ui_error",
      message: ev.message || "Unhandled error event",
    });
  };
  const onRejection = (ev: PromiseRejectionEvent): void => {
    recordClientDiagnostic({
      category: "ui_error",
      message: String(ev.reason ?? "Unhandled promise rejection"),
    });
  };
  window.addEventListener("error", onError);
  window.addEventListener("unhandledrejection", onRejection);
  return () => {
    window.removeEventListener("error", onError);
    window.removeEventListener("unhandledrejection", onRejection);
  };
}

