import { create } from "zustand";
import { sharedCrossTabBus } from "./broadcast";
import type { DegradedServiceItem, UserProfile } from "./contracts/api.gen";
import type { RunEventEnvelope } from "./contracts/events.gen";
import {
  type RunViewState,
  createInitialRunViewState,
  reduceRunState,
  reduceSingleRunEvent,
} from "./runReducer";

export type SupportedLocale = "en" | "id" | "en-XA";
export type ThemeMode = "light" | "dark" | "high-contrast" | "system";
export type PaletteName = "slate" | "amber" | "forest";
export type DensityMode = "comfortable" | "compact";
export type MessageWidthMode = "narrow" | "wide";
export type ThinkingEffort = "off" | "low" | "medium" | "high" | "auto";
export type WorkspaceRoute =
  | "chat"
  | "agents"
  | "mail"
  | "notes"
  | "calendar"
  | "schedules"
  | "docs"
  | "research"
  | "compare"
  | "memory"
  | "skills"
  | "mcp"
  | "projects"
  | "cookbook"
  | "gallery"
  | "voice"
  | "admin"
  | "settings"
  | "providers"
  | "storybook";

export interface ToastItem {
  readonly id: string;
  readonly message: string;
  readonly variant: "info" | "success" | "warning" | "error";
  readonly durationMs?: number;
  readonly actionLabel?: string;
  readonly onAction?: () => void;
}

export interface AttachmentChip {
  readonly id: string;
  readonly sha256: string;
  readonly filename: string;
  readonly mimeType: string;
  readonly sizeBytes: number;
  readonly progressPct: number;
  readonly status: "uploading" | "ready" | "error";
  readonly errorText?: string;
}

export interface ComposerModes {
  readonly webSearch: boolean;
  readonly agentMode: boolean;
  readonly memoryEnabled: boolean;
  readonly thinkingEffort: ThinkingEffort;
}

const DEFAULT_MODES: ComposerModes = {
  webSearch: false,
  agentMode: true,
  memoryEnabled: true,
  thinkingEffort: "auto",
};

const STORAGE_KEY = "odysseus_ui_prefs_v1";

interface PersistedPrefs {
  theme?: ThemeMode;
  palette?: PaletteName;
  density?: DensityMode;
  fontSize?: "sm" | "md" | "lg";
  messageWidth?: MessageWidthMode;
  sidebarWidth?: number;
  sidebarCollapsed?: boolean;
  draftsByChatId?: Record<string, string>;
  bookmarks?: string[];
  scrollPositions?: Record<string, number>;
}

function loadPersistedPrefs(): PersistedPrefs {
  if (typeof window === "undefined" || typeof window.localStorage === "undefined") {
    return {};
  }
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return {};
    return JSON.parse(raw) as PersistedPrefs;
  } catch {
    return {};
  }
}

function savePersistedPrefs(prefs: PersistedPrefs): void {
  if (typeof window === "undefined" || typeof window.localStorage === "undefined") {
    return;
  }
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(prefs));
  } catch {
    // Ignore storage quota errors
  }
}

export interface AppShellState {
  // Auth & Locale (kept in-memory only — never persisted to localStorage per FE-QA-06)
  readonly user: UserProfile | null;
  readonly csrfToken: string | null;
  readonly locale: SupportedLocale;

  // UI Slice
  readonly activeWorkspace: WorkspaceRoute;
  readonly activeChatId: string | null;
  readonly activeProjectId: string | null;
  readonly activeDocumentId: string | null;
  readonly sidebarCollapsed: boolean;
  readonly sidebarOpen: boolean;
  readonly inspectorOpen: boolean;
  readonly sidebarWidth: number;
  readonly mobileDrawerOpen: boolean;
  readonly commandPaletteOpen: boolean;
  readonly shortcutsModalOpen: boolean;
  readonly shortcutsOpen: boolean;
  readonly onboardingOpen: boolean;
  readonly inChatSearchOpen: boolean;
  readonly inChatSearchQuery: string;
  readonly connectionStatus: "connected" | "reconnecting" | "offline";
  readonly degradedServices: ReadonlyArray<DegradedServiceItem>;
  readonly toasts: ReadonlyArray<ToastItem>;
  readonly pendingDeleteChats: Record<string, string>;
  readonly temporaryChatMode: boolean;
  readonly devRawMode: boolean;
  readonly bookmarks: ReadonlyArray<string>;
  readonly scrollPositions: Record<string, number>;

  // Settings / Theme Slice
  readonly theme: ThemeMode;
  readonly palette: PaletteName;
  readonly density: DensityMode;
  readonly fontSize: "sm" | "md" | "lg";
  readonly codeFont: "mono" | "fira";
  readonly messageWidth: MessageWidthMode;
  readonly cosmeticSmoothing: boolean;
  readonly showReasoning: boolean;
  readonly enterToSend: boolean;
  readonly keybindings: Record<string, string>;

  // Composer Slice
  readonly selectedModel: string;
  readonly draftsByChatId: Record<string, string>;
  readonly queuedMessagesByChatId: Record<string, string>;
  readonly attachmentsByChatId: Record<string, ReadonlyArray<AttachmentChip>>;
  readonly modesByChatId: Record<string, ComposerModes>;
  readonly promptHistory: ReadonlyArray<string>;

  // Runs Slice (derived strictly from reduceRunState per FE-QA-04)
  readonly runsById: Record<string, RunViewState>;
  readonly activeRunIdByChatId: Record<string, string | null>;

  // Actions
  readonly setUser: (user: UserProfile | null, csrfToken?: string | null) => void;
  readonly setLocale: (locale: SupportedLocale) => void;
  readonly setWorkspace: (ws: WorkspaceRoute) => void;
  readonly setActiveChatId: (chatId: string | null) => void;
  readonly setActiveProjectId: (projectId: string | null) => void;
  readonly setActiveDocumentId: (docId: string | null) => void;
  readonly setSidebarCollapsed: (collapsed: boolean) => void;
  readonly toggleSidebar: () => void;
  readonly toggleInspector: () => void;
  readonly setSidebarWidth: (width: number) => void;
  readonly setMobileDrawerOpen: (open: boolean) => void;
  readonly setCommandPaletteOpen: (open: boolean) => void;
  readonly setShortcutsModalOpen: (open: boolean) => void;
  readonly setShortcutsOpen: (open: boolean) => void;
  readonly setOnboardingOpen: (open: boolean) => void;
  readonly setInChatSearch: (open: boolean, query?: string) => void;
  readonly setConnectionStatus: (status: "connected" | "reconnecting" | "offline") => void;
  readonly setDegradedServices: (services: ReadonlyArray<DegradedServiceItem>) => void;
  readonly addToast: (toast: Omit<ToastItem, "id">) => string;
  readonly dismissToast: (id: string) => void;
  readonly softDeleteChat: (chatId: string, title: string) => void;
  readonly undoDeleteChat: (chatId: string) => void;
  readonly setTemporaryChatMode: (enabled: boolean) => void;
  readonly setDevRawMode: (enabled: boolean) => void;
  readonly toggleBookmark: (messageId: string) => void;
  readonly saveScrollPosition: (chatId: string, scrollTop: number) => void;

  // Theme & Settings Actions
  readonly setTheme: (theme: ThemeMode) => void;
  readonly setPalette: (palette: PaletteName) => void;
  readonly setDensity: (density: DensityMode) => void;
  readonly setFontSize: (size: "sm" | "md" | "lg") => void;
  readonly setMessageWidth: (width: MessageWidthMode) => void;
  readonly setShowReasoning: (show: boolean) => void;
  readonly setEnterToSend: (enterToSend: boolean) => void;
  readonly setKeybinding: (action: string, combo: string) => void;

  // Composer Actions
  readonly setSelectedModel: (model: string) => void;
  readonly setDraft: (chatId: string, text: string, broadcast?: boolean) => void;
  readonly setQueuedMessage: (chatId: string, text: string | null) => void;
  readonly upsertAttachment: (chatId: string, chip: AttachmentChip) => void;
  readonly removeAttachment: (chatId: string, id: string) => void;
  readonly clearAttachments: (chatId: string) => void;
  readonly setComposerModes: (chatId: string, patch: Partial<ComposerModes>) => void;
  readonly pushPromptHistory: (prompt: string) => void;

  // Run Reducer Actions
  readonly applyRunEvent: (chatId: string, event: RunEventEnvelope, broadcast?: boolean) => RunViewState;
  readonly applyRunEvents: (chatId: string, runId: string, events: ReadonlyArray<RunEventEnvelope>) => RunViewState;
  readonly setActiveRunForChat: (chatId: string, runId: string | null) => void;
}

const initialPrefs = loadPersistedPrefs();

export const useAppShellStore = create<AppShellState>((set, get) => ({
  user: null,
  csrfToken: null,
  locale: "en",

  activeWorkspace: "chat",
  activeChatId: null,
  activeProjectId: null,
  activeDocumentId: null,
  sidebarCollapsed: initialPrefs.sidebarCollapsed ?? false,
  sidebarOpen: !(initialPrefs.sidebarCollapsed ?? false),
  inspectorOpen: false,
  sidebarWidth: initialPrefs.sidebarWidth ?? 272,
  mobileDrawerOpen: false,
  commandPaletteOpen: false,
  shortcutsModalOpen: false,
  shortcutsOpen: false,
  onboardingOpen: false,
  inChatSearchOpen: false,
  inChatSearchQuery: "",
  connectionStatus: "connected",
  degradedServices: [],
  toasts: [],
  pendingDeleteChats: {},
  temporaryChatMode: false,
  devRawMode: false,
  bookmarks: initialPrefs.bookmarks ?? [],
  scrollPositions: initialPrefs.scrollPositions ?? {},

  theme: initialPrefs.theme ?? "dark",
  palette: initialPrefs.palette ?? "slate",
  density: initialPrefs.density ?? "comfortable",
  fontSize: initialPrefs.fontSize ?? "md",
  codeFont: "mono",
  messageWidth: initialPrefs.messageWidth ?? "narrow",
  cosmeticSmoothing: false,
  showReasoning: true,
  enterToSend: true,
  keybindings: {
    newChat: "Alt+N",
    focusComposer: "/",
    toggleSidebar: "Ctrl+B",
    commandPalette: "Ctrl+K",
    shortcutsHelp: "?",
    stopRun: "Escape",
  },

  selectedModel: "fake/default",
  draftsByChatId: initialPrefs.draftsByChatId ?? {},
  queuedMessagesByChatId: {},
  attachmentsByChatId: {},
  modesByChatId: {},
  promptHistory: [],

  runsById: {},
  activeRunIdByChatId: {},

  setUser: (user, csrfToken = null) => {
    set({ user, csrfToken: csrfToken ?? null });
    sharedCrossTabBus.publish({ type: "auth_changed", authenticated: Boolean(user) });
  },

  setLocale: (locale) => set({ locale }),
  setWorkspace: (activeWorkspace) => set({ activeWorkspace }),
  setActiveChatId: (activeChatId) =>
    set((s) => {
      if (activeChatId && s.draftsByChatId["default"] && !s.draftsByChatId[activeChatId]) {
        const nextDrafts = {
          ...s.draftsByChatId,
          [activeChatId]: s.draftsByChatId["default"],
        };
        delete nextDrafts["default"];
        return { activeChatId, mobileDrawerOpen: false, draftsByChatId: nextDrafts };
      }
      return { activeChatId, mobileDrawerOpen: false };
    }),
  setActiveProjectId: (activeProjectId) => set({ activeProjectId }),
  setActiveDocumentId: (activeDocumentId) => set({ activeDocumentId }),

  setSidebarCollapsed: (sidebarCollapsed) => {
    set({ sidebarCollapsed, sidebarOpen: !sidebarCollapsed });
    const s = get();
    savePersistedPrefs({
      theme: s.theme,
      palette: s.palette,
      density: s.density,
      fontSize: s.fontSize,
      messageWidth: s.messageWidth,
      sidebarWidth: s.sidebarWidth,
      sidebarCollapsed,
      draftsByChatId: s.draftsByChatId,
      bookmarks: [...s.bookmarks],
      scrollPositions: s.scrollPositions,
    });
  },

  toggleSidebar: () => {
    const nextCollapsed = !get().sidebarCollapsed;
    get().setSidebarCollapsed(nextCollapsed);
  },

  toggleInspector: () => set((s) => ({ inspectorOpen: !s.inspectorOpen })),

  setSidebarWidth: (width) => {
    const clamped = Math.max(200, Math.min(440, width));
    set({ sidebarWidth: clamped });
    const s = get();
    savePersistedPrefs({
      theme: s.theme,
      palette: s.palette,
      density: s.density,
      fontSize: s.fontSize,
      messageWidth: s.messageWidth,
      sidebarWidth: clamped,
      sidebarCollapsed: s.sidebarCollapsed,
      draftsByChatId: s.draftsByChatId,
      bookmarks: [...s.bookmarks],
      scrollPositions: s.scrollPositions,
    });
  },

  setMobileDrawerOpen: (mobileDrawerOpen) => set({ mobileDrawerOpen }),
  setCommandPaletteOpen: (commandPaletteOpen) => set({ commandPaletteOpen }),
  setShortcutsModalOpen: (shortcutsModalOpen) =>
    set({ shortcutsModalOpen, shortcutsOpen: shortcutsModalOpen }),
  setShortcutsOpen: (shortcutsOpen) =>
    set({ shortcutsModalOpen: shortcutsOpen, shortcutsOpen }),
  setOnboardingOpen: (onboardingOpen) => set({ onboardingOpen }),
  setInChatSearch: (inChatSearchOpen, query) =>
    set((s) => ({
      inChatSearchOpen,
      inChatSearchQuery: query !== undefined ? query : s.inChatSearchQuery,
    })),

  setConnectionStatus: (connectionStatus) => set({ connectionStatus }),
  setDegradedServices: (degradedServices) => set({ degradedServices }),

  addToast: (toast) => {
    const id = `toast_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    set((s) => ({ toasts: [...s.toasts, { ...toast, id }] }));
    return id;
  },

  dismissToast: (id) =>
    set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })),

  softDeleteChat: (chatId, title) =>
    set((s) => ({
      pendingDeleteChats: { ...s.pendingDeleteChats, [chatId]: title },
    })),

  undoDeleteChat: (chatId) =>
    set((s) => {
      const next = { ...s.pendingDeleteChats };
      delete next[chatId];
      return { pendingDeleteChats: next };
    }),

  setTemporaryChatMode: (temporaryChatMode) => set({ temporaryChatMode }),
  setDevRawMode: (devRawMode) => set({ devRawMode }),

  toggleBookmark: (messageId) =>
    set((s) => {
      const exists = s.bookmarks.includes(messageId);
      const next = exists
        ? s.bookmarks.filter((id) => id !== messageId)
        : [...s.bookmarks, messageId];
      savePersistedPrefs({
        theme: s.theme,
        palette: s.palette,
        density: s.density,
        fontSize: s.fontSize,
        messageWidth: s.messageWidth,
        sidebarWidth: s.sidebarWidth,
        sidebarCollapsed: s.sidebarCollapsed,
        draftsByChatId: s.draftsByChatId,
        bookmarks: next,
        scrollPositions: s.scrollPositions,
      });
      return { bookmarks: next };
    }),

  saveScrollPosition: (chatId, scrollTop) =>
    set((s) => {
      const next = { ...s.scrollPositions, [chatId]: scrollTop };
      return { scrollPositions: next };
    }),

  setTheme: (theme) => {
    set({ theme });
    const s = get();
    savePersistedPrefs({
      theme,
      palette: s.palette,
      density: s.density,
      fontSize: s.fontSize,
      messageWidth: s.messageWidth,
      sidebarWidth: s.sidebarWidth,
      sidebarCollapsed: s.sidebarCollapsed,
      draftsByChatId: s.draftsByChatId,
      bookmarks: [...s.bookmarks],
      scrollPositions: s.scrollPositions,
    });
    sharedCrossTabBus.publish({
      type: "theme_changed",
      theme,
      palette: s.palette,
      density: s.density,
    });
  },

  setPalette: (palette) => {
    set({ palette });
    const s = get();
    savePersistedPrefs({
      theme: s.theme,
      palette,
      density: s.density,
      fontSize: s.fontSize,
      messageWidth: s.messageWidth,
      sidebarWidth: s.sidebarWidth,
      sidebarCollapsed: s.sidebarCollapsed,
      draftsByChatId: s.draftsByChatId,
      bookmarks: [...s.bookmarks],
      scrollPositions: s.scrollPositions,
    });
    sharedCrossTabBus.publish({
      type: "theme_changed",
      theme: s.theme,
      palette,
      density: s.density,
    });
  },

  setDensity: (density) => {
    set({ density });
    const s = get();
    savePersistedPrefs({
      theme: s.theme,
      palette: s.palette,
      density,
      fontSize: s.fontSize,
      messageWidth: s.messageWidth,
      sidebarWidth: s.sidebarWidth,
      sidebarCollapsed: s.sidebarCollapsed,
      draftsByChatId: s.draftsByChatId,
      bookmarks: [...s.bookmarks],
      scrollPositions: s.scrollPositions,
    });
    sharedCrossTabBus.publish({
      type: "theme_changed",
      theme: s.theme,
      palette: s.palette,
      density,
    });
  },

  setFontSize: (fontSize) => {
    set({ fontSize });
    const s = get();
    savePersistedPrefs({
      theme: s.theme,
      palette: s.palette,
      density: s.density,
      fontSize,
      messageWidth: s.messageWidth,
      sidebarWidth: s.sidebarWidth,
      sidebarCollapsed: s.sidebarCollapsed,
      draftsByChatId: s.draftsByChatId,
      bookmarks: [...s.bookmarks],
      scrollPositions: s.scrollPositions,
    });
  },

  setMessageWidth: (messageWidth) => {
    set({ messageWidth });
    const s = get();
    savePersistedPrefs({
      theme: s.theme,
      palette: s.palette,
      density: s.density,
      fontSize: s.fontSize,
      messageWidth,
      sidebarWidth: s.sidebarWidth,
      sidebarCollapsed: s.sidebarCollapsed,
      draftsByChatId: s.draftsByChatId,
      bookmarks: [...s.bookmarks],
      scrollPositions: s.scrollPositions,
    });
  },

  setShowReasoning: (showReasoning) => set({ showReasoning }),
  setEnterToSend: (enterToSend) => set({ enterToSend }),
  setKeybinding: (action, combo) =>
    set((s) => ({ keybindings: { ...s.keybindings, [action]: combo } })),

  setSelectedModel: (selectedModel) => set({ selectedModel }),

  setDraft: (chatId, text, broadcast = true) => {
    set((s) => {
      const nextDrafts = { ...s.draftsByChatId };
      if (!text) {
        delete nextDrafts[chatId];
      } else {
        nextDrafts[chatId] = text;
      }
      savePersistedPrefs({
        theme: s.theme,
        palette: s.palette,
        density: s.density,
        fontSize: s.fontSize,
        messageWidth: s.messageWidth,
        sidebarWidth: s.sidebarWidth,
        sidebarCollapsed: s.sidebarCollapsed,
        draftsByChatId: nextDrafts,
        bookmarks: [...s.bookmarks],
        scrollPositions: s.scrollPositions,
      });
      return { draftsByChatId: nextDrafts };
    });
    if (broadcast) {
      sharedCrossTabBus.publish({ type: "draft_changed", chatId, draft: text });
    }
  },

  setQueuedMessage: (chatId, text) =>
    set((s) => {
      const next = { ...s.queuedMessagesByChatId };
      if (!text) {
        delete next[chatId];
      } else {
        next[chatId] = text;
      }
      return { queuedMessagesByChatId: next };
    }),

  upsertAttachment: (chatId, chip) =>
    set((s) => {
      const prev = s.attachmentsByChatId[chatId] ?? [];
      const exists = prev.some((c) => c.id === chip.id);
      const nextList = exists
        ? prev.map((c) => (c.id === chip.id ? chip : c))
        : [...prev, chip];
      return { attachmentsByChatId: { ...s.attachmentsByChatId, [chatId]: nextList } };
    }),

  removeAttachment: (chatId, id) =>
    set((s) => {
      const prev = s.attachmentsByChatId[chatId] ?? [];
      return {
        attachmentsByChatId: {
          ...s.attachmentsByChatId,
          [chatId]: prev.filter((c) => c.id !== id),
        },
      };
    }),

  clearAttachments: (chatId) =>
    set((s) => {
      const next = { ...s.attachmentsByChatId };
      delete next[chatId];
      return { attachmentsByChatId: next };
    }),

  setComposerModes: (chatId, patch) =>
    set((s) => {
      const prev = s.modesByChatId[chatId] ?? DEFAULT_MODES;
      return {
        modesByChatId: {
          ...s.modesByChatId,
          [chatId]: { ...prev, ...patch },
        },
      };
    }),

  pushPromptHistory: (prompt) =>
    set((s) => {
      const trimmed = prompt.trim();
      if (!trimmed) return s;
      const deduped = [trimmed, ...s.promptHistory.filter((p) => p !== trimmed)].slice(0, 50);
      return { promptHistory: deduped };
    }),

  applyRunEvent: (chatId, event, broadcast = true) => {
    const prevRun = get().runsById[event.run_id] ?? createInitialRunViewState();
    const nextRun = reduceSingleRunEvent(prevRun, event, {
      ignoreDuplicates: true,
      rejectSeqGaps: true,
    });
    const isTerminal = event.type === "run.finished" || event.type === "run.error";
    set((s) => ({
      runsById: {
        ...s.runsById,
        [event.run_id]: nextRun,
      },
      activeRunIdByChatId: {
        ...s.activeRunIdByChatId,
        [chatId]: isTerminal ? null : event.run_id,
      },
    }));
    if (broadcast) {
      sharedCrossTabBus.publish({ type: "run_event", chatId, event });
    }
    return nextRun;
  },

  applyRunEvents: (chatId, runId, events) => {
    const prevRun = get().runsById[runId] ?? createInitialRunViewState();
    const nextRun = reduceRunState(events, prevRun, { ignoreDuplicates: true });
    const isTerminal =
      nextRun.status === "completed" ||
      nextRun.status === "cancelled" ||
      nextRun.status === "error";
    set((s) => ({
      runsById: {
        ...s.runsById,
        [runId]: nextRun,
      },
      activeRunIdByChatId: {
        ...s.activeRunIdByChatId,
        [chatId]: isTerminal ? null : runId,
      },
    }));
    return nextRun;
  },

  setActiveRunForChat: (chatId, runId) =>
    set((s) => {
      const nextRuns =
        runId && !s.runsById[runId]
          ? {
              ...s.runsById,
              [runId]: {
                ...createInitialRunViewState(),
                run_id: runId,
                chat_id: chatId,
                status: "running" as const,
              },
            }
          : s.runsById;
      return {
        runsById: nextRuns,
        activeRunIdByChatId: { ...s.activeRunIdByChatId, [chatId]: runId },
      };
    }),
}));

// Subscribe store to cross-tab BroadcastChannel events
sharedCrossTabBus.subscribe((msg) => {
  const s = useAppShellStore.getState();
  if (msg.type === "theme_changed") {
    useAppShellStore.setState({
      theme: msg.theme,
      palette: msg.palette,
      density: msg.density,
    });
  } else if (msg.type === "draft_changed") {
    s.setDraft(msg.chatId, msg.draft, false);
  } else if (msg.type === "run_event") {
    s.applyRunEvent(msg.chatId, msg.event, false);
  }
});
