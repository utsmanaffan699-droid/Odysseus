import { renderMathToSafeHtml } from "./lazy/katexRenderer";
import { renderMermaidToSafeHtml } from "./lazy/mermaidRenderer";
import { highlightCodeBlockSync, normalizeLanguage } from "./lazy/shikiHighlighter";

export type MarkdownBlockKind =
  | "heading"
  | "code"
  | "math"
  | "mermaid"
  | "table"
  | "list"
  | "blockquote"
  | "hr"
  | "details"
  | "paragraph";

export interface CodeBlockMeta {
  readonly language: string;
  readonly filename: string | null;
  readonly code: string;
  readonly lineCount: number;
  readonly isDiff: boolean;
  readonly isTerminal: boolean;
  readonly isUnclosed: boolean;
}

export interface TableBlockMeta {
  readonly headers: ReadonlyArray<string>;
  readonly rows: ReadonlyArray<ReadonlyArray<string>>;
  readonly csv: string;
  readonly markdown: string;
}

export interface MarkdownBlock {
  readonly index: number;
  readonly hash: string;
  readonly raw: string;
  readonly closed: boolean;
  readonly kind: MarkdownBlockKind;
  readonly html: string;
  readonly codeMeta?: CodeBlockMeta;
  readonly tableMeta?: TableBlockMeta;
}

export function fnv1aHash(input: string): string {
  let h1 = 0x811c9dc5;
  let h2 = 0x811c9dc5 ^ 0x9e3779b9;
  for (let i = 0; i < input.length; i++) {
    const code = input.charCodeAt(i);
    h1 ^= code;
    h1 = Math.imul(h1, 0x01000193);
    h2 ^= code ^ (i & 0xff);
    h2 = Math.imul(h2, 0x01000193);
  }
  return `${(h1 >>> 0).toString(16).padStart(8, "0")}${(h2 >>> 0).toString(16).padStart(8, "0")}`;
}

export function escapeHtml(raw: string): string {
  return raw
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function decodeHtmlEntitiesForSchemeCheck(str: string): string {
  return str
    .replace(/&#x([0-9a-f]+);?/gi, (_, hex: string) => {
      const cp = Number.parseInt(hex, 16);
      return Number.isNaN(cp) ? "" : String.fromCodePoint(Math.min(cp, 0x10ffff));
    })
    .replace(/&#(\d+);?/g, (_, dec: string) => {
      const cp = Number.parseInt(dec, 10);
      return Number.isNaN(cp) ? "" : String.fromCodePoint(Math.min(cp, 0x10ffff));
    })
    .replace(/&colon;/gi, ":")
    .replace(/&tab;/gi, "")
    .replace(/&newline;/gi, "");
}

export function sanitizeUrl(
  rawUrl: string,
  allowSafeDataImage = false,
): { url: string; blocked: boolean; domain: string | null } {
  const trimmed = rawUrl.trim();
  if (!trimmed) {
    return { url: "about:blank#blocked-empty", blocked: true, domain: null };
  }

  let decoded = decodeHtmlEntitiesForSchemeCheck(trimmed);
  try {
    decoded = decodeURIComponent(decoded);
  } catch {
    // Keep decoded entity string if URI component is malformed
  }
  // Strip control chars, zero-width spaces, BiDi controls, and whitespace before checking scheme
  // eslint-disable-next-line no-control-regex
  const normalized = decoded.replace(/[\u0000-\u0020\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]/g, "").toLowerCase();

  if (normalized.startsWith("#") || (normalized.startsWith("/") && !normalized.startsWith("//"))) {
    return { url: escapeHtml(trimmed), blocked: false, domain: null };
  }

  if (allowSafeDataImage && /^data:image\/(?:png|jpeg|jpg|gif|webp);base64,[a-z0-9+/=]+$/i.test(normalized)) {
    return { url: escapeHtml(trimmed), blocked: false, domain: "data-image" };
  }

  if (/^(?:https?:|mailto:)/i.test(normalized)) {
    let domain: string | null = null;
    try {
      const parsed = new URL(trimmed);
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:" && parsed.protocol !== "mailto:") {
        return { url: "about:blank#blocked-unsafe-scheme", blocked: true, domain: null };
      }
      domain = parsed.hostname || null;
    } catch {
      return { url: "about:blank#blocked-invalid-url", blocked: true, domain: null };
    }
    return { url: escapeHtml(trimmed), blocked: false, domain };
  }

  return { url: "about:blank#blocked-unsafe-scheme", blocked: true, domain: null };
}

interface FenceState {
  readonly markerChar: "`" | "~";
  readonly markerLen: number;
}

/**
 * Strip optional blockquote `>` and list `- ` / `1. ` prefixes from a line to detect nested fences.
 */
function stripQuoteAndListPrefix(line: string): string {
  let rest = line;
  for (let depth = 0; depth < 6; depth++) {
    const next = rest.replace(/^(?:[ \t]*>[ \t]?|[ \t]*(?:[-*+]|\d+\.)[ \t]+)/, "");
    if (next === rest) break;
    rest = next;
  }
  return rest;
}

function scanFenceAndMathState(segment: string): { openFence: FenceState | null; openMath: boolean } {
  const lines = segment.split("\n");
  let openFence: FenceState | null = null;
  let openMath = false;

  for (const rawLine of lines) {
    const stripped = stripQuoteAndListPrefix(rawLine).trimStart();

    if (openFence !== null) {
      const closeRe = new RegExp(`^${openFence.markerChar}{${openFence.markerLen},}[ \\t]*$`);
      if (closeRe.test(stripped)) {
        openFence = null;
      }
      continue;
    }

    const fenceMatch = /^(`{3,}|~{3,})(.*)$/.exec(stripped);
    if (fenceMatch) {
      const marker = fenceMatch[1]!;
      const info = fenceMatch[2] ?? "";
      // Backtick fences cannot contain backticks in their info string on the same line
      if (marker[0] === "`" && info.includes("`")) {
        continue;
      }
      openFence = {
        markerChar: marker[0] as "`" | "~",
        markerLen: marker.length,
      };
      continue;
    }

    // Count `$$` tokens on the line outside inline code
    const mathMatches = stripped.match(/\$\$/g);
    if (mathMatches && mathMatches.length % 2 === 1) {
      openMath = !openMath;
    }
  }

  return { openFence, openMath };
}

/**
 * Split raw Markdown into stable top-level blocks.
 *
 * Mathematical Invariant:
 * A block boundary is committed ONLY at a blank-line separator `\n[ \t]*\n+` where:
 * 1) The accumulated text before the separator has `openFence === null` and `openMath === false`, AND
 * 2) At least one non-whitespace character exists after the separator.
 *
 * Because condition (2) requires a non-whitespace character after the blank-line run, the separator
 * run can never be extended by future appended characters, and condition (1) depends solely on the
 * prefix before the separator. Therefore:
 * - Every block with `closed: true` is 100% immutable across all future stream chunks.
 * - Final blocks when `isStreaming === false` are 100% invariant to how the input was chunked.
 */
export function splitMarkdownBlocks(
  rawText: string,
  isStreaming = false,
): ReadonlyArray<MarkdownBlock> {
  if (!rawText) {
    return [];
  }

  // Normalize \r\n -> \n (preserve a trailing \r if streaming so a split \r\n doesn't mutate)
  const trailingCr = isStreaming && rawText.endsWith("\r");
  const coreText = trailingCr ? rawText.slice(0, -1) : rawText;
  const normalized = coreText.replace(/\r\n?/g, "\n") + (trailingCr ? "\r" : "");

  const rawSegments: Array<{ raw: string; closed: boolean }> = [];
  const sepRegex = /\n[ \t]*\n+/g;
  let blockStart = 0;
  let match: RegExpExecArray | null = sepRegex.exec(normalized);

  while (match !== null) {
    const sepStart = match.index;
    const sepEnd = sepStart + match[0].length;
    const candidate = normalized.slice(blockStart, sepStart);
    const afterChar = normalized[sepEnd];

    // Only split if there is non-whitespace content before and after the separator
    if (candidate.trim().length > 0 && afterChar !== undefined && !/\s/.test(afterChar)) {
      const state = scanFenceAndMathState(candidate);
      if (state.openFence === null && !state.openMath) {
        rawSegments.push({ raw: candidate, closed: true });
        blockStart = sepEnd;
      }
    }
    match = sepRegex.exec(normalized);
  }

  const tail = normalized.slice(blockStart);
  if (tail.trim().length > 0 || (isStreaming && tail.length > 0 && rawSegments.length === 0)) {
    const finalRaw = isStreaming ? tail : tail.replace(/\n[ \t]*$/, "");
    if (finalRaw.length > 0) {
      rawSegments.push({ raw: finalRaw, closed: !isStreaming });
    }
  }

  return rawSegments.map((seg, idx) => buildMarkdownBlock(seg.raw, idx, seg.closed));
}

const CLOSED_BLOCK_CACHE = new Map<string, Omit<MarkdownBlock, "index">>();
const MAX_CACHE_ENTRIES = 4000;

function buildMarkdownBlock(raw: string, index: number, closed: boolean): MarkdownBlock {
  const hash = fnv1aHash(raw);
  if (closed) {
    const cached = CLOSED_BLOCK_CACHE.get(hash);
    if (cached && cached.raw === raw) {
      return { ...cached, index };
    }
  }

  const parsed = parseSingleBlockContent(raw, closed, hash);
  if (closed) {
    if (CLOSED_BLOCK_CACHE.size >= MAX_CACHE_ENTRIES) {
      const oldestKey = CLOSED_BLOCK_CACHE.keys().next().value;
      if (oldestKey !== undefined) {
        CLOSED_BLOCK_CACHE.delete(oldestKey);
      }
    }
    CLOSED_BLOCK_CACHE.set(hash, parsed);
  }
  return { ...parsed, index };
}

export function renderInlineMarkdown(text: string): string {
  if (!text) return "";

  // Extract inline code spans (`...`) and inline math ($...$ or \(...\)) first using placeholders
  const placeholders: string[] = [];
  const putPlaceholder = (html: string): string => {
    const id = placeholders.length;
    placeholders.push(html);
    return `\uE000PH_${id}_\uE001`;
  };

  let working = text.replace(/`([^`\n]+)`/g, (_, code: string) =>
    putPlaceholder(`<code class="odysseus-inline-code">${escapeHtml(code)}</code>`),
  );

  working = working.replace(/\\\((.+?)\\\)/g, (_, latex: string) =>
    putPlaceholder(renderMathToSafeHtml(latex, false)),
  );

  working = working.replace(/(?<![\\$])\$(?!\s)([^$\n]+?)(?<!\s)\$(?!\$)/g, (_, latex: string) =>
    putPlaceholder(renderMathToSafeHtml(latex, false)),
  );

  // Escape all remaining HTML tags/entities so no raw HTML can execute
  working = escapeHtml(working);

  // Images: ![alt](url)
  working = working.replace(/!\[([^\]]*)\]\(([^)\s]+)(?:\s+&quot;([^&]*)&quot;)?\)/g, (_, alt: string, rawUrl: string) => {
    const safe = sanitizeUrl(rawUrl, true);
    if (safe.blocked) {
      return `<span class="odysseus-blocked-media" data-unsafe-url="blocked">[Blocked unsafe image: ${alt}]</span>`;
    }
    return `<span class="odysseus-image-wrap"><img src="${safe.url}" alt="${alt}" class="odysseus-md-image" loading="lazy" data-lightbox-src="${safe.url}" /></span>`;
  });

  // Links: [label](url)
  working = working.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (_, label: string, rawUrl: string) => {
    const safe = sanitizeUrl(rawUrl, false);
    if (safe.blocked) {
      return `<a href="about:blank#blocked-unsafe-scheme" class="odysseus-md-link odysseus-md-link-blocked" data-unsafe-url="blocked" title="Blocked unsafe link">${label}</a>`;
    }
    const domainAttr = safe.domain ? ` data-domain="${escapeHtml(safe.domain)}" title="External link: ${escapeHtml(safe.domain)}"` : "";
    return `<a href="${safe.url}" target="_blank" rel="noopener noreferrer" class="odysseus-md-link"${domainAttr}>${label}</a>`;
  });

  // Citations `[1]`, `[2]` (when not followed by `(`)
  working = working.replace(/\[(\d{1,2})\](?!\()/g, (_, num: string) => {
    return `<button type="button" class="odysseus-citation-chip" data-citation-index="${num}" aria-label="Citation ${num}">[${num}]</button>`;
  });

  // Footnote references `[^1]`
  working = working.replace(/\[\^([A-Za-z0-9_-]+)\]/g, (_, fnId: string) => {
    return `<sup class="odysseus-footnote-ref"><a href="#fn-${fnId}" id="fnref-${fnId}">[${fnId}]</a></sup>`;
  });

  // Bold, italic, strikethrough
  working = working.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  working = working.replace(/~~([^~]+)~~/g, "<del>$1</del>");
  working = working.replace(/(^|[\s(])\*([^*\n]+)\*(?=$|[\s.,!?:;)])/g, "$1<em>$2</em>");

  // Restore placeholders
  working = working.replace(/\uE000PH_(\d+)_\uE001/g, (_, idxStr: string) => {
    return placeholders[Number.parseInt(idxStr, 10)] ?? "";
  });

  return working;
}

function parseCodeFenceBlock(
  raw: string,
  closed: boolean,
  hash: string,
): Omit<MarkdownBlock, "index"> | null {
  const lines = raw.split("\n");
  const firstLine = stripQuoteAndListPrefix(lines[0] ?? "").trimStart();
  const fenceMatch = /^(`{3,}|~{3,})(.*)$/.exec(firstLine);
  if (!fenceMatch) {
    return null;
  }

  const marker = fenceMatch[1]!;
  const infoStr = (fenceMatch[2] ?? "").trim();
  const langMatch = /^([A-Za-z0-9_+-]+)/.exec(infoStr);
  const rawLang = langMatch ? langMatch[1]! : "text";
  const titleMatch = /(?:title|filename|file)=["']([^"']+)["']/.exec(infoStr);
  const filename = titleMatch ? titleMatch[1]! : null;

  let endIdx = lines.length;
  let isUnclosed = true;
  if (lines.length > 1) {
    const lastStripped = stripQuoteAndListPrefix(lines[lines.length - 1] ?? "").trim();
    const closeRe = new RegExp(`^${marker[0]}{${marker.length},}$`);
    if (closeRe.test(lastStripped)) {
      endIdx = lines.length - 1;
      isUnclosed = false;
    }
  }

  const codeLines = lines.slice(1, endIdx);
  const code = codeLines.join("\n");
  const normLang = normalizeLanguage(rawLang);

  if (normLang === "mermaid") {
    if (!closed && isUnclosed) {
      return {
        hash,
        raw,
        closed,
        kind: "mermaid",
        html: `<div class="odysseus-mermaid-streaming" data-block-hash="${hash}"><pre>${escapeHtml(code)}</pre></div>`,
      };
    }
    const mRes = renderMermaidToSafeHtml(code);
    return {
      hash,
      raw,
      closed,
      kind: "mermaid",
      html: mRes.svgHtml,
    };
  }

  const isDiff = normLang === "diff" || normLang === "patch";
  const isTerminal = normLang === "bash" || rawLang.toLowerCase() === "console" || rawLang.toLowerCase() === "terminal";

  let highlightedInner: string;
  if (isDiff) {
    highlightedInner = codeLines
      .map((line) => {
        const esc = escapeHtml(line);
        if (line.startsWith("+") && !line.startsWith("+++")) {
          return `<span class="diff-line diff-add">${esc}</span>`;
        }
        if (line.startsWith("-") && !line.startsWith("---")) {
          return `<span class="diff-line diff-del">${esc}</span>`;
        }
        if (line.startsWith("@@")) {
          return `<span class="diff-line diff-hunk">${esc}</span>`;
        }
        return `<span class="diff-line">${esc}</span>`;
      })
      .join("\n");
  } else if (closed || codeLines.length <= 200) {
    highlightedInner = highlightCodeBlockSync(code, normLang);
  } else {
    highlightedInner = escapeHtml(code);
  }

  const codeMeta: CodeBlockMeta = {
    language: normLang,
    filename,
    code,
    lineCount: codeLines.length,
    isDiff,
    isTerminal,
    isUnclosed,
  };

  const headerTitle = filename ? `<span class="odysseus-code-filename">${escapeHtml(filename)}</span>` : "";
  const termClass = isTerminal ? " odysseus-code-terminal" : "";
  const diffClass = isDiff ? " odysseus-code-diff" : "";
  const html = `<div class="odysseus-code-block${termClass}${diffClass}" data-block-hash="${hash}" data-language="${escapeHtml(normLang)}" tabindex="0" role="region" aria-label="Code block ${escapeHtml(filename ?? normLang)}"><div class="odysseus-code-header"><span class="odysseus-code-lang">${escapeHtml(normLang)}</span>${headerTitle}</div><pre class="odysseus-code-pre"><code>${highlightedInner}</code></pre></div>`;

  return {
    hash,
    raw,
    closed,
    kind: "code",
    html,
    codeMeta,
  };
}

function parseTableBlock(
  raw: string,
  closed: boolean,
  hash: string,
): Omit<MarkdownBlock, "index"> | null {
  const lines = raw.split("\n").map((l) => l.trim()).filter(Boolean);
  if (lines.length < 1 || !lines[0]!.includes("|")) {
    return null;
  }
  const isSeparatorLine = (l: string): boolean => /^\|?[\s:|-]+\|[\s:|-]*$/.test(l) && l.includes("-");
  if (lines.length >= 2 && !isSeparatorLine(lines[1]!)) {
    return null;
  }
  // If only 1 line so far, only treat as streaming table if it starts and ends with `|` or has >=2 pipes
  if (lines.length === 1 && !/^\|.*\|/.test(lines[0]!)) {
    return null;
  }

  const splitCells = (rowLine: string): string[] => {
    const trimmed = rowLine.replace(/^\|/, "").replace(/\|$/, "");
    return trimmed.split("|").map((c) => c.trim());
  };

  const headers = splitCells(lines[0]!);
  const bodyLines = lines.length >= 2 ? lines.slice(2) : [];
  const rows = bodyLines.map(splitCells);

  const thHtml = headers.map((h) => `<th>${renderInlineMarkdown(h)}</th>`).join("");
  const trHtml = rows
    .map(
      (r) =>
        `<tr>${headers.map((_, colIdx) => `<td>${renderInlineMarkdown(r[colIdx] ?? "")}</td>`).join("")}</tr>`,
    )
    .join("");

  const csvRows = [headers, ...rows]
    .map((r) => r.map((cell) => `"${cell.replace(/"/g, '""')}"`).join(","))
    .join("\n");

  const html = `<div class="odysseus-table-wrap" data-block-hash="${hash}" role="region" aria-label="Data table" tabindex="0"><table class="odysseus-md-table"><thead><tr>${thHtml}</tr></thead><tbody>${trHtml}</tbody></table></div>`;

  return {
    hash,
    raw,
    closed,
    kind: "table",
    html,
    tableMeta: {
      headers,
      rows,
      csv: csvRows,
      markdown: raw,
    },
  };
}

function parseSingleBlockContent(
  raw: string,
  closed: boolean,
  hash: string,
): Omit<MarkdownBlock, "index"> {
  const trimmed = raw.trim();

  // 1. Fenced code or Mermaid block (including fences nested inside list/blockquote)
  const fenceBlock = parseCodeFenceBlock(trimmed, closed, hash);
  if (fenceBlock) {
    return fenceBlock;
  }

  // 2. Display math block `$$ ... $$`
  if (trimmed.startsWith("$$")) {
    const inner = trimmed.replace(/^\$\$/, "").replace(/\$\$$/, "").trim();
    return {
      hash,
      raw,
      closed,
      kind: "math",
      html: renderMathToSafeHtml(inner, true),
    };
  }

  // 3. Horizontal rule
  if (/^(?:-{3,}|\*{3,}|_{3,})$/.test(trimmed)) {
    return {
      hash,
      raw,
      closed,
      kind: "hr",
      html: `<hr class="odysseus-md-hr" data-block-hash="${hash}" />`,
    };
  }

  // 4. Heading (# .. ######)
  const headingMatch = /^(#{1,6})\s+(.+)$/.exec(trimmed);
  if (headingMatch && !trimmed.includes("\n")) {
    const level = headingMatch[1]!.length;
    const content = renderInlineMarkdown(headingMatch[2]!);
    return {
      hash,
      raw,
      closed,
      kind: "heading",
      html: `<h${level} class="odysseus-md-h${level}" data-block-hash="${hash}">${content}</h${level}>`,
    };
  }

  // 5. Details / summary collapsible block (safe stripped attributes)
  const detailsMatch = /^<details>\s*<summary>([\s\S]*?)<\/summary>([\s\S]*?)(?:<\/details>)?$/i.exec(trimmed);
  if (detailsMatch) {
    const summaryHtml = renderInlineMarkdown(detailsMatch[1]!.trim());
    const bodyHtml = renderInlineMarkdown(detailsMatch[2]!.trim());
    return {
      hash,
      raw,
      closed,
      kind: "details",
      html: `<details class="odysseus-md-details" data-block-hash="${hash}"><summary>${summaryHtml}</summary><div class="odysseus-md-details-body">${bodyHtml}</div></details>`,
    };
  }

  // 6. GFM Table
  const tableBlock = parseTableBlock(trimmed, closed, hash);
  if (tableBlock) {
    return tableBlock;
  }

  // 7. Blockquote
  const lines = raw.split("\n");
  if (lines.every((l) => l.trim().startsWith(">"))) {
    const innerLines = lines.map((l) => l.replace(/^\s*>\s?/, ""));
    const innerText = innerLines.join("\n").trim();
    // Check if blockquote wraps a code fence
    const innerFence = parseCodeFenceBlock(innerText, closed, hash);
    const bodyHtml = innerFence
      ? innerFence.html
      : innerLines.map((l) => renderInlineMarkdown(l)).join("<br />");
    return {
      hash,
      raw,
      closed,
      kind: "blockquote",
      html: `<blockquote class="odysseus-md-quote" data-block-hash="${hash}">${bodyHtml}</blockquote>`,
    };
  }

  // 8. Unordered, Ordered, or Task List
  if (/^\s*(?:[-*+]|\d+\.)\s+/.test(lines[0] ?? "")) {
    // Check if the list item contains a nested code fence
    for (let i = 0; i < lines.length; i++) {
      const stripped = stripQuoteAndListPrefix(lines[i] ?? "").trimStart();
      if (/^(`{3,}|~{3,})/.test(stripped)) {
        const prefixItems = lines.slice(0, i).map((l) => renderInlineMarkdown(stripQuoteAndListPrefix(l))).join("<br />");
        const fencePart = parseCodeFenceBlock(lines.slice(i).join("\n"), closed, hash);
        if (fencePart) {
          return {
            hash,
            raw,
            closed,
            kind: "list",
            html: `<div class="odysseus-md-list-fence" data-block-hash="${hash}"><div class="odysseus-md-list-lead">${prefixItems}</div>${fencePart.html}</div>`,
            codeMeta: fencePart.codeMeta,
          };
        }
      }
    }

    const isOrdered = /^\s*\d+\.\s+/.test(lines[0] ?? "");
    const listTag = isOrdered ? "ol" : "ul";
    const itemsHtml = lines
      .filter((l) => l.trim().length > 0)
      .map((line) => {
        const itemBody = line.replace(/^\s*(?:[-*+]|\d+\.)\s+/, "");
        const taskMatch = /^\[([ xX])\]\s+(.*)$/.exec(itemBody);
        if (taskMatch) {
          const checked = taskMatch[1]!.toLowerCase() === "x";
          return `<li class="odysseus-task-item"><input type="checkbox" disabled ${checked ? "checked" : ""} aria-label="Task item" /> <span>${renderInlineMarkdown(taskMatch[2]!)}</span></li>`;
        }
        return `<li>${renderInlineMarkdown(itemBody)}</li>`;
      })
      .join("");
    return {
      hash,
      raw,
      closed,
      kind: "list",
      html: `<${listTag} class="odysseus-md-list" data-block-hash="${hash}">${itemsHtml}</${listTag}>`,
    };
  }

  // 9. Footnote definition `[^1]: ...`
  const fnDefMatch = /^\[\^([A-Za-z0-9_-]+)\]:\s+([\s\S]+)$/.exec(trimmed);
  if (fnDefMatch) {
    const fnId = fnDefMatch[1]!;
    return {
      hash,
      raw,
      closed,
      kind: "paragraph",
      html: `<div class="odysseus-footnote-def" id="fn-${escapeHtml(fnId)}" data-block-hash="${hash}"><strong>[${escapeHtml(fnId)}]</strong> ${renderInlineMarkdown(fnDefMatch[2]!)}</div>`,
    };
  }

  // 10. Default Paragraph
  const paraHtml = lines.map((l) => renderInlineMarkdown(l)).join("<br />");
  return {
    hash,
    raw,
    closed,
    kind: "paragraph",
    html: `<p class="odysseus-md-p" data-block-hash="${hash}" dir="auto">${paraHtml}</p>`,
  };
}

export function renderMarkdownToHtml(text: string, isStreaming = false): string {
  const blocks = splitMarkdownBlocks(text, isStreaming);
  return blocks.map((b) => b.html).join("\n");
}

export function clearMarkdownBlockCache(): void {
  CLOSED_BLOCK_CACHE.clear();
}
