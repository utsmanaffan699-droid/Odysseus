/**
 * Lazy-loaded CodeMirror-compatible JSON schema-validated raw config editor.
 * Loaded on demand when the user opens the Raw JSON tab in Settings (FE-ADMIN-01).
 */

import React, { useState } from "react";

export interface RawJsonEditorProps {
  readonly value: string;
  readonly schema?: Record<string, unknown>;
  readonly editableKeys?: ReadonlyArray<string>;
  readonly onChange: (nextJson: string, isValid: boolean, errors: ReadonlyArray<string>) => void;
}

export function validateJsonAgainstSchema(
  rawText: string,
  schema?: Record<string, unknown>,
  editableKeys?: ReadonlyArray<string>,
): { valid: boolean; parsed: Record<string, unknown> | null; errors: string[] } {
  let parsed: unknown;
  try {
    parsed = JSON.parse(rawText);
  } catch (err) {
    return {
      valid: false,
      parsed: null,
      errors: [err instanceof Error ? err.message : "Invalid JSON syntax"],
    };
  }

  if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
    return {
      valid: false,
      parsed: null,
      errors: ["Root value must be a JSON object"],
    };
  }

  const obj = parsed as Record<string, unknown>;
  const errors: string[] = [];
  const props = (schema?.properties ?? {}) as Record<string, Record<string, unknown>>;
  const allowedSet = editableKeys ? new Set(editableKeys) : null;

  for (const [key, val] of Object.entries(obj)) {
    if (allowedSet && !allowedSet.has(key)) {
      errors.push(`Key "${key}" is not runtime-editable`);
      continue;
    }
    const propSchema = props[key];
    if (!propSchema) continue;
    const expectedType = propSchema.type;
    if (expectedType === "integer" || expectedType === "number") {
      if (typeof val !== "number" || Number.isNaN(val)) {
        errors.push(`"${key}" must be a ${String(expectedType)}`);
      } else if (expectedType === "integer" && !Number.isInteger(val)) {
        errors.push(`"${key}" must be an integer`);
      }
    } else if (expectedType === "boolean" && typeof val !== "boolean") {
      errors.push(`"${key}" must be a boolean`);
    } else if (expectedType === "string" && typeof val !== "string") {
      errors.push(`"${key}" must be a string`);
    }
  }

  return {
    valid: errors.length === 0,
    parsed: obj,
    errors,
  };
}

export function LazyCodeMirrorJsonEditor({
  value,
  schema,
  editableKeys,
  onChange,
}: RawJsonEditorProps): React.ReactElement {
  const [text, setText] = useState<string>(value);
  const [errors, setErrors] = useState<ReadonlyArray<string>>([]);

  const handleTextChange = (next: string): void => {
    setText(next);
    const res = validateJsonAgainstSchema(next, schema, editableKeys);
    setErrors(res.errors);
    onChange(next, res.valid, res.errors);
  };

  const lineCount = Math.max(1, text.split("\n").length);

  return React.createElement(
    "div",
    { className: "odysseus-cm-editor", "data-testid": "raw-json-codemirror" },
    React.createElement(
      "div",
      { className: "odysseus-cm-gutter", "aria-hidden": "true" },
      Array.from({ length: lineCount }, (_, idx) =>
        React.createElement("div", { key: idx + 1, className: "odysseus-cm-line-num" }, idx + 1),
      ),
    ),
    React.createElement(
      "div",
      { className: "odysseus-cm-body" },
      React.createElement("textarea", {
        "aria-label": "Raw JSON Settings Editor",
        className: "odysseus-cm-textarea",
        value: text,
        onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => handleTextChange(e.target.value),
        spellCheck: false,
        rows: Math.min(24, Math.max(10, lineCount + 1)),
        "data-testid": "raw-json-textarea",
      }),
      errors.length > 0
        ? React.createElement(
            "ul",
            { className: "odysseus-cm-errors", role: "alert", "data-testid": "raw-json-errors" },
            errors.map((err, i) => React.createElement("li", { key: i }, err)),
          )
        : React.createElement(
            "div",
            { className: "odysseus-cm-valid", "data-testid": "raw-json-valid" },
            "Schema valid",
          ),
    ),
  );
}
