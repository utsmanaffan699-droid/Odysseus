/**
 * Lazy-loaded KaTeX-compatible math renderer with strict XSS/command sanitization.
 * Never throws on malformed LaTeX; strips unsafe commands like \href{javascript:...}.
 */

function escapeHtml(raw: string): string {
  return raw
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

const UNSAFE_LATEX_PATTERNS = [
  /\\href\s*\{[^}]*(?:javascript|vbscript|data)\s*:[^}]*\}\s*\{([^}]*)\}/gi,
  /\\url\s*\{[^}]*(?:javascript|vbscript|data)\s*:[^}]*\}/gi,
  /\\html(?:Data|Id|Class|Style)\s*\{[^}]*\}/gi,
  /\\input\s*\{[^}]*\}/gi,
  /\\include\s*\{[^}]*\}/gi,
  /\\write18\s*\{[^}]*\}/gi,
];

const GREEK_AND_SYMBOLS: ReadonlyArray< readonly [RegExp, string]> = [
  [/\\alpha\b/g, "α"],
  [/\\beta\b/g, "β"],
  [/\\gamma\b/g, "γ"],
  [/\\delta\b/g, "δ"],
  [/\\epsilon\b/g, "ϵ"],
  [/\\pi\b/g, "π"],
  [/\\sigma\b/g, "σ"],
  [/\\omega\b/g, "ω"],
  [/\\infty\b/g, "∞"],
  [/\\int\b/g, "∫"],
  [/\\sum\b/g, "∑"],
  [/\\prod\b/g, "∏"],
  [/\\sqrt\{([^}]+)\}/g, "√($1)"],
  [/\\frac\{([^}]+)\}\{([^}]+)\}/g, "($1)/($2)"],
  [/\\times\b/g, "×"],
  [/\\cdot\b/g, "·"],
  [/\\pm\b/g, "±"],
  [/\\leq\b/g, "≤"],
  [/\\geq\b/g, "≥"],
  [/\\neq\b/g, "≠"],
  [/\\approx\b/g, "≈"],
  [/\\rightarrow\b/g, "→"],
  [/\\leftarrow\b/g, "←"],
  [/\\Rightarrow\b/g, "⇒"],
];

export function sanitizeLatexSource(latex: string): { clean: string; blockedUnsafe: boolean } {
  let clean = latex;
  let blockedUnsafe = false;
  for (const pat of UNSAFE_LATEX_PATTERNS) {
    if (pat.test(clean)) {
      blockedUnsafe = true;
      clean = clean.replace(pat, "[blocked-latex-cmd]");
    }
  }
  return { clean, blockedUnsafe };
}

export function renderMathToSafeHtml(latex: string, displayMode: boolean): string {
  const { clean, blockedUnsafe } = sanitizeLatexSource(latex);

  // Detect unbalanced braces as non-fatal syntax warning
  let depth = 0;
  for (const ch of clean) {
    if (ch === "{") depth += 1;
    else if (ch === "}") depth -= 1;
    if (depth < 0) break;
  }

  let formatted = clean;
  for (const [pat, rep] of GREEK_AND_SYMBOLS) {
    formatted = formatted.replace(pat, rep);
  }
  const escaped = escapeHtml(formatted);
  const rawAttr = escapeHtml(clean);
  const tag = displayMode ? "div" : "span";
  const cls = displayMode ? "odysseus-math odysseus-math-block" : "odysseus-math odysseus-math-inline";
  const errAttr = depth !== 0 ? ' data-math-error="unbalanced-braces"' : "";
  const unsafeAttr = blockedUnsafe ? ' data-math-sanitized="true"' : "";

  return `<${tag} class="${cls}" role="math" aria-label="${rawAttr}" data-latex="${rawAttr}"${errAttr}${unsafeAttr}><span class="katex-rendered">${escaped}</span></${tag}>`;
}
