/**
 * Lazy-loaded syntax highlighting engine (Shiki-compatible tokenizer & theme renderer).
 * Loaded on demand via dynamic `import()` when code blocks close, keeping initial bundle tiny.
 */

export interface HighlightToken {
  readonly text: string;
  readonly kind: "keyword" | "string" | "comment" | "number" | "type" | "function" | "operator" | "plain";
}

const LANGUAGE_KEYWORDS: Record<string, ReadonlySet<string>> = {
  python: new Set([
    "def", "class", "return", "if", "elif", "else", "for", "while", "in", "import",
    "from", "as", "try", "except", "finally", "with", "async", "await", "yield",
    "True", "False", "None", "and", "or", "not", "lambda", "raise", "assert",
  ]),
  typescript: new Set([
    "const", "let", "var", "function", "return", "if", "else", "for", "while",
    "import", "export", "from", "type", "interface", "class", "extends", "implements",
    "async", "await", "new", "try", "catch", "finally", "true", "false", "null", "undefined",
    "readonly", "public", "private", "protected", "switch", "case", "default",
  ]),
  javascript: new Set([
    "const", "let", "var", "function", "return", "if", "else", "for", "while",
    "import", "export", "from", "class", "extends", "async", "await", "new",
    "try", "catch", "finally", "true", "false", "null", "undefined",
  ]),
  rust: new Set([
    "fn", "let", "mut", "pub", "struct", "enum", "impl", "trait", "for", "in",
    "if", "else", "match", "return", "use", "mod", "crate", "async", "await",
    "where", "Self", "self", "true", "false", "Some", "None", "Ok", "Err",
  ]),
  sql: new Set([
    "SELECT", "FROM", "WHERE", "INSERT", "INTO", "VALUES", "UPDATE", "SET",
    "DELETE", "CREATE", "TABLE", "INDEX", "JOIN", "LEFT", "INNER", "ON",
    "GROUP", "BY", "ORDER", "LIMIT", "AND", "OR", "NOT", "NULL", "AS",
  ]),
  bash: new Set([
    "if", "then", "else", "fi", "for", "in", "do", "done", "while", "case",
    "esac", "function", "export", "local", "return", "exit", "echo", "cd", "curl",
  ]),
};

function escapeHtml(raw: string): string {
  return raw
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

export function normalizeLanguage(lang: string): string {
  const clean = lang.trim().toLowerCase();
  if (clean === "py") return "python";
  if (clean === "ts" || clean === "tsx") return "typescript";
  if (clean === "js" || clean === "jsx") return "javascript";
  if (clean === "rs") return "rust";
  if (clean === "sh" || clean === "zsh" || clean === "shell" || clean === "console") return "bash";
  return clean || "text";
}

export function highlightCodeLine(line: string, lang: string): string {
  const norm = normalizeLanguage(lang);
  const keywords = LANGUAGE_KEYWORDS[norm] ?? LANGUAGE_KEYWORDS.typescript!;

  const commentIdx =
    norm === "python" || norm === "bash"
      ? line.indexOf("#")
      : norm === "sql"
        ? line.indexOf("--")
        : line.indexOf("//");

  let codePart = line;
  let commentPart = "";
  if (commentIdx !== -1) {
    codePart = line.slice(0, commentIdx);
    commentPart = line.slice(commentIdx);
  }

  const tokenRegex = /("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`|\b[A-Za-z_][A-Za-z0-9_]*\b|\b\d+(?:\.\d+)?\b)/g;
  let out = "";
  let lastIdx = 0;
  let match: RegExpExecArray | null = tokenRegex.exec(codePart);

  while (match !== null) {
    if (match.index > lastIdx) {
      out += escapeHtml(codePart.slice(lastIdx, match.index));
    }
    const token = match[0];
    if (token.startsWith('"') || token.startsWith("'") || token.startsWith("`")) {
      out += `<span class="tok-string">${escapeHtml(token)}</span>`;
    } else if (/^\d/.test(token)) {
      out += `<span class="tok-number">${escapeHtml(token)}</span>`;
    } else if (keywords.has(token) || (norm === "sql" && keywords.has(token.toUpperCase()))) {
      out += `<span class="tok-keyword">${escapeHtml(token)}</span>`;
    } else if (/^[A-Z]/.test(token)) {
      out += `<span class="tok-type">${escapeHtml(token)}</span>`;
    } else {
      out += escapeHtml(token);
    }
    lastIdx = match.index + token.length;
    match = tokenRegex.exec(codePart);
  }

  if (lastIdx < codePart.length) {
    out += escapeHtml(codePart.slice(lastIdx));
  }
  if (commentPart) {
    out += `<span class="tok-comment">${escapeHtml(commentPart)}</span>`;
  }
  return out;
}

export function highlightCodeBlockSync(code: string, lang: string): string {
  const lines = code.split("\n");
  if ( lines.length > 5000) {
    return escapeHtml(code);
  }
  return lines.map((l) => highlightCodeLine(l, lang)).join("\n");
}
