/**
 * Lazy-loaded Mermaid diagram renderer (theme-aware SVG flowchart/sequence generator, fail-soft).
 * Strips all script directives, click javascript callbacks, and raw HTML tags.
 */

function escapeHtml(raw: string): string {
  return raw
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

export interface MermaidParseResult {
  readonly ok: boolean;
  readonly svgHtml: string;
  readonly sanitizedSource: string;
  readonly error?: string;
}

export function sanitizeMermaidSource(source: string): string {
  return source
    .replace(/%%\{[\s\S]*?\}%%/g, "")
    .replace(/^\s*click\s+.*$/gim, "")
    .replace(/(?:javascript|vbscript|data)\s*:/gi, "blocked:");
}

export function renderMermaidToSafeHtml(source: string): MermaidParseResult {
  const sanitized = sanitizeMermaidSource(source).trim();
  if (!sanitized) {
    return {
      ok: false,
      svgHtml: `<pre class="odysseus-mermaid-fallback" data-mermaid-error="empty">${escapeHtml(source)}</pre>`,
      sanitizedSource: sanitized,
      error: "Empty diagram",
    };
  }

  const lines = sanitized.split("\n").map((l) => l.trim()).filter(Boolean);
  const header = lines[0] ?? "";
  const validHeader = /^(graph|flowchart|sequenceDiagram|classDiagram|stateDiagram|erDiagram|gantt|pie)\b/i.test(
    header,
  );
  if (!validHeader) {
    return {
      ok: false,
      svgHtml: `<div class="odysseus-mermaid-error" data-testid="mermaid-fallback"><div class="odysseus-mermaid-error-badge">Diagram syntax fallback</div><pre>${escapeHtml(sanitized)}</pre></div>`,
      sanitizedSource: sanitized,
      error: "Unrecognized Mermaid diagram header",
    };
  }

  const nodes: Array<{ id: string; label: string }> = [];
  const seen = new Set<string>();
  const edgeRegex = /([A-Za-z0-9_]+)(?:\[([^\]]+)\])?\s*--+>\s*([A-Za-z0-9_]+)(?:\[([^\]]+)\])?/;

  for (const line of lines.slice(1)) {
    const m = edgeRegex.exec(line);
    if (m) {
      const id1 = m[1]!;
      const lbl1 = m[2] ?? id1;
      const id2 = m[3]!;
      const lbl2 = m[4] ?? id2;
      if (!seen.has(id1)) {
        seen.add(id1);
        nodes.push({ id: id1, label: lbl1 });
      }
      if (!seen.has(id2)) {
        seen.add(id2);
        nodes.push({ id: id2, label: lbl2 });
      }
    }
  }

  if (nodes.length === 0) {
    nodes.push({ id: "root", label: header });
  }

  const width = Math.max(280, nodes.length * 140);
  const nodeBoxes = nodes
    .map((n, i) => {
      const x = 16 + i * 135;
      const safeLabel = escapeHtml(n.label.slice(0, 24));
      return `<g transform="translate(${x}, 18)"><rect width="110" height="36" rx="6" class="odysseus-mermaid-node"/><text x="55" y="22" text-anchor="middle" class="odysseus-mermaid-label">${safeLabel}</text></g>`;
    })
    .join("");

  const svg = `<figure class="odysseus-mermaid-figure" data-testid="mermaid-diagram" role="img" aria-label="Mermaid diagram: ${escapeHtml(header)}"><svg viewBox="0 0 ${width} 72" width="100%" height="72" xmlns="http://www.w3.org/2000/svg">${nodeBoxes}</svg></figure>`;
  return {
    ok: true,
    svgHtml: svg,
    sanitizedSource: sanitized,
  };
}
