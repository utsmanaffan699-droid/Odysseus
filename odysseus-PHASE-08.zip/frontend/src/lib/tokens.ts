export interface ContextBreakdown {
  readonly system: number;
  readonly tools: number;
  readonly memory: number;
  readonly history: number;
  readonly attachments: number;
  readonly userPrompt: number;
}

export interface ContextMeterSummary {
  readonly model: string;
  readonly contextWindow: number;
  readonly totalTokens: number;
  readonly utilizationPct: number;
  readonly warningLevel: "normal" | "warning" | "critical";
  readonly breakdown: ContextBreakdown;
}

export function estimateTextTokens(text: string): number {
  if (!text) return 0;
  // ~4 chars per token heuristic matching backend PromptBuilder fallback
  return Math.max(1, Math.ceil(text.length / 4));
}

export function computeClientContextMeter(params: {
  model: string;
  contextWindow?: number;
  userPrompt: string;
  systemPrompt?: string | null;
  historyTokens?: number;
  attachmentBytes?: number;
  toolsCount?: number;
  memoriesCount?: number;
}): ContextMeterSummary {
  const windowSize = Math.max(1024, params.contextWindow ?? 128000);
  const system = estimateTextTokens(params.systemPrompt ?? "You are Odysseus.");
  const tools = Math.max(0, (params.toolsCount ?? 6) * 48);
  const memory = Math.max(0, (params.memoriesCount ?? 0) * 32);
  const history = Math.max(0, params.historyTokens ?? 0);
  const attachments = Math.ceil((params.attachmentBytes ?? 0) / 16);
  const userPrompt = estimateTextTokens(params.userPrompt);

  const totalTokens = system + tools + memory + history + attachments + userPrompt;
  const utilizationPct = Math.min(100, Number(((totalTokens / windowSize) * 100).toFixed(2)));
  const warningLevel: "normal" | "warning" | "critical" =
    utilizationPct >= 95 ? "critical" : utilizationPct >= 80 ? "warning" : "normal";

  return {
    model: params.model,
    contextWindow: windowSize,
    totalTokens,
    utilizationPct,
    warningLevel,
    breakdown: {
      system,
      tools,
      memory,
      history,
      attachments,
      userPrompt,
    },
  };
}
