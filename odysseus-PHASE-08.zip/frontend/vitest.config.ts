import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    environment: "jsdom",
    include: ["src/**/__tests__/**/*.test.ts", "src/**/__tests__/**/*.test.tsx"],
    coverage: {
      provider: "v8",
      include: ["src/lib/**/*.ts"],
      exclude: ["src/lib/contracts/*.gen.ts", "src/lib/__tests__/**"],
      thresholds: {
        lines: 85,
        functions: 85,
        statements: 85,
      },
    },
  },
});
