import AxeBuilder from "@axe-core/playwright";
import { expect, type Page, test } from "@playwright/test";

const BOOTSTRAP_PASSWORD = process.env.ODYSSEUS_TEST_ADMIN_PASSWORD ?? "";
const UPDATED_PASSWORD = "NewAdminStrongPass!2026";

async function ensureAuthenticated(page: Page): Promise<void> {
  await page.goto("/");

  const authView = page.getByTestId("authenticated-view");
  if (await authView.isVisible().catch(() => false)) {
    return;
  }

  await page.locator("#username-input").fill("admin");
  await page.locator("#password-input").fill(UPDATED_PASSWORD);
  await page.getByTestId("login-submit").click();

  const errVisible = await page
    .getByTestId("error-banner")
    .isVisible({ timeout: 1500 })
    .catch(() => false);

  if (errVisible && BOOTSTRAP_PASSWORD) {
    await page.locator("#username-input").fill("admin");
    await page.locator("#password-input").fill(BOOTSTRAP_PASSWORD);
    await page.getByTestId("login-submit").click();
  }

  const pwChangeForm = page.getByTestId("password-change-form");
  if (await pwChangeForm.isVisible({ timeout: 1500 }).catch(() => false)) {
    await page.locator("#current-pw-input").fill(BOOTSTRAP_PASSWORD);
    await page.locator("#new-pw-input").fill(UPDATED_PASSWORD);
    await page.getByTestId("password-change-submit").click();
  }

  await expect(page.getByTestId("authenticated-view")).toBeVisible({ timeout: 10000 });
}

test.describe("Odysseus Phase 08 — Cookbook, Gallery & Editor, Voice Mode, Admin Console & Guided Tours E2E", () => {
  test("Cookbook (FE-WORK-09), Gallery & 200-Step Editor (FE-WORK-08), Voice Barge-In (FE-COMP-09), Admin Ops (FE-ADMIN-02..09), Guided Tours (FE-SHELL-16) + WCAG AA", async ({
    page,
  }) => {
    await ensureAuthenticated(page);

    // 1. Navigate to Cookbook & Local Models Workspace (FE-WORK-09)
    await page.getByTestId("workspace-nav-cookbook").click();
    await expect(page.getByTestId("cookbook-workspace")).toBeVisible();
    await expect(page.getByTestId("cookbook-hw-card")).toBeVisible();
    await expect(page.getByTestId("cookbook-models-table")).toBeVisible();

    // Switch hardware fixture to Container Without Passthrough -> shows remedy command
    await page
      .getByTestId("cookbook-hw-fixture-select")
      .selectOption("18_container_without_passthrough");
    await expect(page.getByTestId("cookbook-passthrough-banner")).toContainText(
      "docker/gpu.nvidia.yml",
    );

    // Simulate Disk-Full Download Preflight & Engine Dry-Run + Atomic Install
    await page.getByTestId("cookbook-simulate-disk-full-btn").click();
    await expect(page.getByTestId("cookbook-download-failure-cause")).toContainText("disk_full");

    await page.getByTestId("cookbook-engine-dry-run-btn").click();
    await expect(page.getByTestId("cookbook-engine-status")).toContainText(
      "Dry-Run Preflight Passed",
    );
    await page.getByTestId("cookbook-install-engine-btn").click();
    await expect(page.getByTestId("cookbook-engine-status")).toContainText("b4150");

    // Simulate Crash-Loop Detector, 3-Context Benchmark, and SSH TOFU Pinning
    await page.getByTestId("cookbook-crash-loop-btn").click();
    await expect(page.getByTestId("cookbook-serve-state")).toContainText("crash_loop");

    await page.getByTestId("cookbook-run-bench-btn").click();
    await expect(page.getByTestId("cookbook-bench-summary")).toContainText("ctx=32768");

    await page.getByTestId("cookbook-confirm-tofu-btn").click();
    await expect(page.getByTestId("cookbook-remote-status")).toContainText(
      "connected_tofu_pinned",
    );

    // 2. Navigate to Gallery & Non-Destructive Tiled Image Editor (FE-WORK-08)
    await page.getByTestId("tab-gallery").click();
    await expect(page.getByTestId("gallery-workspace")).toBeVisible();
    await page.getByTestId("gallery-upload-bomb-btn").click();
    await expect(page.getByTestId("gallery-upload-guard-status")).toContainText(
      "10,000 MP PNG Decompression Bomb",
    );

    await page.getByTestId("gallery-op-200-btn").click();
    await expect(page.getByTestId("gallery-op-count")).toHaveText("200");
    await page.getByTestId("gallery-undo-btn").click();
    await expect(page.getByTestId("gallery-op-count")).toHaveText("199");
    await expect(page.getByTestId("gallery-redo-count")).toHaveText("1");

    await page.getByTestId("gallery-export-btn").click();
    await expect(page.getByTestId("gallery-export-result")).toContainText(
      "EXIF/GPS stripped=true",
    );

    // 3. Navigate to Voice Conversation Mode (FE-COMP-09)
    await page.getByTestId("tab-voice").click();
    await expect(page.getByTestId("voice-mode-view")).toBeVisible();
    await page.getByTestId("voice-stt-btn").click();
    await expect(page.getByTestId("voice-stt-output")).toContainText("hardware advisor");

    await page.getByTestId("voice-tts-stream-btn").click();
    await expect(page.getByTestId("voice-tts-stream-status")).toContainText("true");

    await page.getByTestId("voice-start-turn-btn").click();
    await expect(page.getByTestId("voice-state-badge")).toHaveText("speaking");
    await page.getByTestId("voice-barge-in-btn").click();
    await expect(page.getByTestId("voice-state-badge")).toHaveText("listening");
    await expect(page.getByTestId("voice-barge-in-latency")).toContainText("150 ms");

    // 4. Navigate to Admin Console & Operations + Guided Tours (FE-ADMIN-02..09, FE-SHELL-16)
    await page.getByTestId("tab-admin").click();
    await expect(page.getByTestId("admin-ops-workspace")).toBeVisible();

    await page.getByTestId("guided-tour-trigger-btn").click();
    await expect(page.getByTestId("guided-tour-card")).toBeVisible();
    await page.getByTestId("guided-tour-complete-btn").click();
    await expect(page.getByTestId("guided-tour-trigger-btn")).toContainText("Guided Tour Done");

    await page.getByTestId("admin-demo-mode-toggle").click();
    await expect(page.getByTestId("admin-usage-list")).toContainText("Demo Redacted Chat");

    await page.getByTestId("admin-policy-test-btn").click();
    await expect(page.getByTestId("admin-policy-test-result")).toContainText("DENY");

    await page.getByTestId("admin-support-bundle-btn").click();
    await expect(page.getByTestId("admin-support-bundle-output")).toContainText("[REDACTED_");

    await page.getByTestId("admin-create-backup-btn").click();
    await expect(page.getByTestId("admin-backup-status")).toContainText("Backup created");
    await page.getByTestId("admin-restore-dry-run-btn").click();
    await expect(page.getByTestId("admin-backup-status")).toContainText("Dry-Run Verified");

    // 5. Run @axe-core/playwright WCAG 2.2 AA accessibility scan
    const axeResults = await new AxeBuilder({ page })
      .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"])
      .analyze();
    const seriousOrCritical = axeResults.violations.filter(
      (v) => v.impact === "serious" || v.impact === "critical",
    );
    expect(seriousOrCritical).toEqual([]);
  });
});
