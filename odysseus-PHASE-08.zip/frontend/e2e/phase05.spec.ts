import AxeBuilder from "@axe-core/playwright";
import { expect, type Page, test } from "@playwright/test";

const BOOTSTRAP_PASSWORD = process.env.ODYSSEUS_TEST_ADMIN_PASSWORD ?? "";
const UPDATED_PASSWORD = "NewAdminStrongPass!2026";

async function ensureAuthenticated(page: Page): Promise<void> {
  await page.goto("/");

  const authView = page.getByTestId("authenticated-view");
  if (await authView.isVisible().catch(() => false)) {
    return;
  }

  await page.locator("#username-input").fill("admin");
  await page.locator("#password-input").fill(UPDATED_PASSWORD);
  await page.getByTestId("login-submit").click();

  const errVisible = await page
    .getByTestId("error-banner")
    .isVisible({ timeout: 1500 })
    .catch(() => false);

  if (errVisible && BOOTSTRAP_PASSWORD) {
    await page.locator("#username-input").fill("admin");
    await page.locator("#password-input").fill(BOOTSTRAP_PASSWORD);
    await page.getByTestId("login-submit").click();
  }

  const pwChangeForm = page.getByTestId("password-change-form");
  if (await pwChangeForm.isVisible({ timeout: 1500 }).catch(() => false)) {
    await page.locator("#current-pw-input").fill(BOOTSTRAP_PASSWORD);
    await page.locator("#new-pw-input").fill(UPDATED_PASSWORD);
    await page.getByTestId("password-change-submit").click();
  }

  await expect(page.getByTestId("authenticated-view")).toBeVisible({ timeout: 10000 });
}

test.describe("Odysseus Phase 05 — Agent Timeline, Tool Renderers, Approvals & Artifacts E2E", () => {
  test("Acceptances #1, #2, #5 & Adversarial 5.1, 5.2: Live 6-tool run, deceptive approval normalization, 400ms clickjacking guard, and multi-tab approval race", async ({
    page,
  }) => {
    await ensureAuthenticated(page);
    await page.getByTestId("sidebar-new-chat").click();

    // 1. Trigger 6-tool agent scenario with approval gate
    const composerInput = page.locator("#chat-composer-textarea");
    await composerInput.fill("Run full workspace check [FAKE_AGENT_6TOOLS]");
    await page.getByTestId("composer-send-btn").click();

    // Wait for the 6th tool call (run_shell) to enter waiting_approval
    await expect(page.getByTestId("approval-banner")).toBeVisible({ timeout: 15000 });

    // Verify inline timeline shows 6 tools and pinned plan tracker
    await expect(page.getByTestId("pinned-plan-tracker")).toBeVisible();
    await expect(page.getByTestId("memories-used-chip")).toContainText("Used 3 memories");

    // Approve the pending tool call via the approval card once the 400ms guard unlocks
    const approveOnceBtn = page.getByTestId("approval-approve-once").first();
    await expect(approveOnceBtn).toBeEnabled({ timeout: 5000 });
    await approveOnceBtn.click();

    // Run completes and shows terminal output
    await expect(page.getByTestId("timeline-run-status").first()).toContainText("completed", {
      timeout: 15000,
    });

    // 2. Acceptance #5 & Adversarial 5.1 + 5.2: Deceptive approval normalization + 400ms clickjacking reset + race
    await composerInput.fill("Check deceptive command [FAKE_DECEPTIVE_APPROVAL]");
    await page.getByTestId("composer-send-btn").click();

    await expect(page.getByTestId("approval-spoof-warning")).toBeVisible({ timeout: 15000 });
    await expect(page.getByTestId("approval-spoof-warning")).toContainText("RTL_OVERRIDE");
    await expect(page.getByTestId("approval-spoof-warning")).toContainText("ZERO_WIDTH");
    await expect(page.getByTestId("approval-spoof-warning")).toContainText("HOMOGLYPH");
    await expect(page.getByTestId("approval-spoof-warning")).toContainText("MULTILINE");
    await expect(page.getByTestId("approval-spoof-warning")).toContainText("LONG_ARG");

    // Provenance warning badge and hidden-chars badge must be visible
    await expect(page.getByTestId("approval-provenance-badge")).toContainText(
      "https://malicious-blog.example/post",
    );
    await expect(page.getByTestId("approval-hidden-chars-badge")).toContainText("hidden chars");

    // Expand full arguments
    await page.getByTestId("approval-expand-hidden-btn").click();
    await expect(page.getByTestId("approval-normalized-command")).toContainText("[RTL:U+202E]");

    // Pattern validator rejects '*'
    await page.getByTestId("approval-approve-pattern-toggle").click();
    await page.getByTestId("approval-pattern-input").fill("*");
    await page.getByTestId("approval-approve-pattern-submit").click();
    await expect(page.getByTestId("approval-pattern-error")).toContainText("overly broad");

    // Adversarial 5.2: Trigger layout shift and verify 400ms clickjacking lock immediately re-engages
    await page.evaluate(() => {
      window.dispatchEvent(new CustomEvent("odysseus:approval-layout-shift"));
    });
    const decApproveBtn = page.getByTestId("approval-approve-once").first();
    await expect(decApproveBtn).toBeDisabled();
    // Wait >= 400ms for stability guard to unlock
    await expect(decApproveBtn).toBeEnabled({ timeout: 3000 });

    // Adversarial 5.1: Concurrent multi-tab approval race (Approve vs Deny simultaneously)
    const raceResult = await page.evaluate(async () => {
      const card = document.querySelector('[data-testid^="approval-card-apr_dec_"]');
      const testId = card?.getAttribute("data-testid") ?? "";
      const approvalId = testId.replace("approval-card-", "");
      const csrf =
        (window as unknown as { __odysseus_csrf_token?: string })
          .__odysseus_csrf_token ?? "";
      const headers = {
        "Content-Type": "application/json",
        "X-CSRF-Token": csrf,
      };
      const [r1, r2] = await Promise.all([
        fetch(`/api/approvals/${encodeURIComponent(approvalId)}/resolve`, {
          method: "POST",
          headers,
          body: JSON.stringify({ decision: "deny", scope: "once", reason: "Race tab A" }),
        }).then((r) => r.json()),
        fetch(`/api/approvals/${encodeURIComponent(approvalId)}/resolve`, {
          method: "POST",
          headers,
          body: JSON.stringify({ decision: "approve", scope: "once" }),
        }).then((r) => r.json()),
      ]);
      return { r1, r2 };
    });

    // Exactly one wins (already_decided=false) and the second sees already_decided=true
    const alreadyDecidedCount = [raceResult.r1, raceResult.r2].filter(
      (r) => r.already_decided === true,
    ).length;
    expect(alreadyDecidedCount).toBe(1);
  });

  test("Acceptances #3, #4, #6, #7, #8 & Adversarial 5.3, 5.4: 2,000-step virtualized timeline, 100k-line terminal slice, prompt-injection inertness, 50MB JSON cap, sub-agents, and replay scrubber", async ({
    page,
  }) => {
    await ensureAuthenticated(page);
    await page.getByTestId("sidebar-new-chat").click();

    // Adversarial 5.3: Prompt injection in tool output must remain 100% inert text
    const composerInput = page.locator("#chat-composer-textarea");
    await composerInput.fill("Inspect untrusted page [FAKE_INJECTION_TOOL]");
    await page.getByTestId("composer-send-btn").click();

    await expect(page.getByTestId("terminal-viewport")).toBeVisible({ timeout: 15000 });
    await expect(page.getByTestId("terminal-viewport")).toContainText(
      'data-testid="approval-approve-once"',
    );
    const xssFlag = await page.evaluate(
      () => (window as unknown as Record<string, unknown>).__xss,
    );
    expect(xssFlag).toBeUndefined();
    // Ensure no real button was injected inside terminal-viewport
    const injectedBtnCount = await page
      .getByTestId("terminal-viewport")
      .locator("button")
      .count();
    expect(injectedBtnCount).toBe(0);

    // Acceptance #4: Seed 100,000-line tool output and verify lazy range slice endpoint
    const sliceCheck = await page.evaluate(async () => {
      const csrf =
        (window as unknown as { __odysseus_csrf_token?: string })
          .__odysseus_csrf_token ?? "";
      const bigText = "ok\n".repeat(100000); // 100,000 lines (~300 KB)
      await fetch("/api/tool-calls/tc_100k_e2e/output", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": csrf,
        },
        body: JSON.stringify({ text: bigText }),
      });
      const sliceRes = await fetch("/api/tool-calls/tc_100k_e2e/output?range=0-4096").then((r) =>
        r.json(),
      );
      return sliceRes;
    });
    expect(sliceCheck.length).toBe(4096);
    expect(sliceCheck.has_more).toBe(true);

    // Open 3rd-pane Inspector for 2,000-step stress test, Sub-agent tree, Replay scrubber, and 50MB JSON cap
    await page.getByTestId("inspector-toggle-btn").click();
    const inspector = page.getByTestId("inspector-pane");
    await expect(inspector).toBeVisible();

    // Acceptance #3: 2,000-step virtualized timeline
    await inspector.getByTestId("load-2000-steps-btn").click();
    await expect(inspector).toContainText("2000 steps");
    const renderedStepDomCount = await inspector
      .locator(".odysseus-timeline-step")
      .count();
    expect(renderedStepDomCount).toBeLessThanOrEqual(60);

    // Acceptance #7 & #8: Sub-agent tree + deterministic Replay Scrubber (zero network calls)
    await inspector.getByTestId("load-subagent-tree-btn").click();
    await expect(inspector.getByTestId("subagent-tree-node-r_child_01")).toBeVisible();
    await inspector.getByTestId("replay-mode-toggle").click();
    await expect(inspector.getByTestId("replay-scrubber-bar")).toBeVisible();
    await inspector.getByTestId("replay-scrubber-slider").fill("2");
    await expect(inspector.getByTestId("replay-seq-indicator")).toContainText("Event 2 / 5");
    await inspector.getByTestId("replay-mode-toggle").click();

    // Adversarial 5.4: 50 MB JSON tool result cap
    await inspector.getByTestId("load-50mb-json-btn").click();
    await expect(inspector.getByTestId("json-capped-view")).toBeVisible();
    await expect(inspector.getByTestId("json-download-raw")).toBeVisible();
    await expect(inspector.getByTestId("json-slice-viewer")).toBeVisible();
  });

  test("Acceptances #9, #10, #11: Artifacts streaming with user lock, version diff/restore, tracked suggestions, sandboxed micro-app isolation, Run History, Presets, Exec Policies, and axe-core audit", async ({
    page,
  }) => {
    await ensureAuthenticated(page);
    await page.getByTestId("sidebar-new-chat").click();

    // Acceptance #9: Stream artifact into Canvas, lock editor, version diff/restore, and tracked suggestions
    const composerInput = page.locator("#chat-composer-textarea");
    await composerInput.fill("Generate TypeScript module [FAKE_ARTIFACT_STREAM]");
    await page.getByTestId("composer-send-btn").click();

    const canvasPanel = page.getByTestId("artifacts-canvas-panel");
    await expect(canvasPanel).toBeVisible({ timeout: 15000 });

    const editor = page.getByTestId("artifact-source-editor");
    await expect(editor).toContainText("AgentConfig", { timeout: 10000 });

    // Edit in editor to engage user lock and save v2
    await editor.focus();
    await editor.fill(
      "// Odysseus Artifact Module\nexport interface AgentConfig {\n  readonly maxSteps: number;\n}\n",
    );
    await expect(page.getByTestId("artifact-user-lock-badge")).toBeVisible();
    await page.getByTestId("artifact-save-version-btn").click();

    // Compare versions diff
    await page.getByTestId("artifact-diff-toggle").click();
    await expect(page.getByTestId("artifact-version-diff-view")).toBeVisible();

    // Request AI tracked-change suggestions, accept hunk, and test Undo/Redo
    await page.getByTestId("artifact-suggest-action-improve").click();
    await expect(page.getByTestId("artifact-suggestions-panel")).toBeVisible();
    await page.getByTestId("suggestion-accept-all").click();
    await expect(page.getByTestId("artifact-undo-btn")).toBeEnabled();
    await page.getByTestId("artifact-undo-btn").click();
    await expect(page.getByTestId("artifact-redo-btn")).toBeEnabled();

    // Acceptance #10: Sandboxed HTML/JS micro-app security isolation
    await page.getByTestId("inspector-toggle-btn").click();
    await page.getByTestId("open-sandbox-artifact-btn").click();

    const sandboxIframe = page.getByTestId("artifact-sandbox-iframe");
    await expect(sandboxIframe).toBeVisible();
    await expect(sandboxIframe).toHaveAttribute("sandbox", "allow-scripts");
    await expect(page.getByTestId("artifact-sandboxed-badge")).toBeVisible();

    const sandboxConsole = page.getByTestId("artifact-sandbox-console");
    await expect(sandboxConsole).toContainText("cookie_access:blocked", { timeout: 10000 });
    await expect(sandboxConsole).toContainText("parent_dom:blocked", { timeout: 10000 });
    await expect(sandboxConsole).toContainText("local_storage:blocked", { timeout: 10000 });
    await expect(sandboxConsole).toContainText("network_fetch:blocked", { timeout: 10000 });

    // Acceptance #11: Run History, Agent Presets, and Exec Policy Pattern Tester
    await page.getByTestId("agent-hub-trigger-btn").click();
    await expect(page.getByTestId("agent-hub-modal")).toBeVisible();

    // Create a custom Agent Preset
    await page.getByTestId("preset-name-input").fill("Security Reviewer");
    await page.getByTestId("preset-save-btn").click();
    await expect(page.getByTestId("preset-list")).toContainText("Security Reviewer");

    // Switch to Run History tab, verify sort and triage controls
    await page.getByTestId("agent-hub-tab-runs").click();
    await expect(page.getByTestId("run-history-table")).toBeVisible();
    await expect(page.getByTestId("run-history-sort-select")).toBeVisible();
    await expect(page.getByTestId("run-history-triage-toggle")).toBeVisible();

    // Switch to Exec Policies tab and test pattern validator & risk defaults
    await page.getByTestId("agent-hub-tab-policies").click();
    await expect(page.getByTestId("exec-policy-risk-defaults")).toBeVisible();
    await page.getByTestId("exec-policy-test-btn").click();
    await expect(page.getByTestId("exec-policy-test-result")).toContainText("Valid pattern");

    await page.getByTestId("agent-hub-close-btn").click();

    // Accessibility Gate: 0 serious/critical axe-core violations
    const axeResults = await new AxeBuilder({ page })
      .exclude('[data-testid="artifact-sandbox-iframe"]')
      .analyze();
    const seriousOrCritical = axeResults.violations.filter(
      (v) => v.impact === "serious" || v.impact === "critical",
    );
    expect(seriousOrCritical).toEqual([]);
  });
});
