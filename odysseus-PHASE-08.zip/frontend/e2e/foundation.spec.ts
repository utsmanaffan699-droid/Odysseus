import { expect, test } from "@playwright/test";

const BOOTSTRAP_PASSWORD = process.env.ODYSSEUS_TEST_ADMIN_PASSWORD ?? "";

test.describe("Odysseus Phase 01 Foundation & CSP E2E", () => {
  test("Acceptance #5: strict CSP header is present on HTML and blocks injected inline scripts", async ({
    page,
  }) => {
    const response = await page.goto("/");
    expect(response).not.toBeNull();
    const headers = response!.headers();
    const csp = headers["content-security-policy"] ?? "";
    expect(csp).toContain("script-src 'self'");
    expect(csp).not.toContain("unsafe-inline");

    // Attempt to inject an inline script and assert that Chromium blocks it via CSP violation
    const violationPromise = page.evaluate(() => {
      return new Promise<{ blockedURI: string; effectiveDirective: string }>((resolve) => {
        document.addEventListener(
          "securitypolicyviolation",
          (e) => {
            resolve({
              blockedURI: e.blockedURI,
              effectiveDirective: e.effectiveDirective,
            });
          },
          { once: true },
        );
        const s = document.createElement("script");
        s.textContent = "window.__inline_script_executed = true;";
        document.body.appendChild(s);
      });
    });

    const violation = await violationPromise;
    expect(violation.blockedURI).toBe("inline");
    expect(violation.effectiveDirective).toContain("script-src");

    const executed = await page.evaluate(
      () => (window as unknown as Record<string, unknown>).__inline_script_executed,
    );
    expect(executed).toBeUndefined();
  });

  test("Deliverable #1: i18n switch (en/id), bootstrap admin login, and forced password change", async ({
    page,
  }) => {
    await page.goto("/");
    await expect(page.getByTestId("app-title")).toHaveText("Odysseus Workspace");
    await expect(page.getByTestId("health-badge")).toHaveText("System Ready");

    // Switch language to Bahasa Indonesia and back to English
    await page.getByTestId("lang-toggle").click();
    await expect(page.getByTestId("app-title")).toHaveText("Ruang Kerja Odysseus");
    await page.getByTestId("lang-toggle").click();
    await expect(page.getByTestId("app-title")).toHaveText("Odysseus Workspace");

    // Sign in with bootstrap temporary password
    expect(BOOTSTRAP_PASSWORD.length).toBeGreaterThan(8);
    await page.locator("#username-input").fill("admin");
    await page.locator("#password-input").fill(BOOTSTRAP_PASSWORD);
    await page.getByTestId("login-submit").click();

    // Must land on forced password change screen
    await expect(page.getByTestId("password-change-form")).toBeVisible();
    await page.locator("#current-pw-input").fill(BOOTSTRAP_PASSWORD);
    await page.locator("#new-pw-input").fill("NewAdminStrongPass!2026");
    await page.getByTestId("password-change-submit").click();

    // Now authenticated view is shown
    await expect(page.getByTestId("authenticated-view")).toBeVisible();
    await expect(page.getByTestId("authenticated-view")).toContainText("Signed in as admin");

    // Sign out
    await page.getByTestId("logout-btn").click();
    await expect(page.getByTestId("login-form")).toBeVisible();
  });
});
