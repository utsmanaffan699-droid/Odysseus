import AxeBuilder from "@axe-core/playwright";
import { expect, type Page, test } from "@playwright/test";

const BOOTSTRAP_PASSWORD = process.env.ODYSSEUS_TEST_ADMIN_PASSWORD ?? "";
const UPDATED_PASSWORD = "NewAdminStrongPass!2026";

async function ensureAuthenticated(page: Page): Promise<void> {
  await page.goto("/");

  const authView = page.getByTestId("authenticated-view");
  if (await authView.isVisible().catch(() => false)) {
    return;
  }

  await page.locator("#username-input").fill("admin");
  await page.locator("#password-input").fill(UPDATED_PASSWORD);
  await page.getByTestId("login-submit").click();

  const errVisible = await page
    .getByTestId("error-banner")
    .isVisible({ timeout: 1500 })
    .catch(() => false);

  if (errVisible && BOOTSTRAP_PASSWORD) {
    await page.locator("#username-input").fill("admin");
    await page.locator("#password-input").fill(BOOTSTRAP_PASSWORD);
    await page.getByTestId("login-submit").click();
  }

  const pwChangeForm = page.getByTestId("password-change-form");
  if (await pwChangeForm.isVisible({ timeout: 1500 }).catch(() => false)) {
    await page.locator("#current-pw-input").fill(BOOTSTRAP_PASSWORD);
    await page.locator("#new-pw-input").fill(UPDATED_PASSWORD);
    await page.getByTestId("password-change-submit").click();
  }

  await expect(page.getByTestId("authenticated-view")).toBeVisible({ timeout: 10000 });
}

test.describe("Odysseus Phase 07 — Productivity Suite (Email, Notes & Todos, Calendar/CalDAV, Schedules, Notifications & Webhooks) E2E", () => {
  test("Email & Triage (FE-WORK-04), Notes & Assign-to-Agent (FE-WORK-05), Calendar Quick-Add & 2-Way Conflict (FE-WORK-06), Schedules/Webhooks/DLQ/Tokens (FE-WORK-07, FE-ADMIN-04, FE-AGENT-14) + WCAG AA", async ({
    page,
  }) => {
    await ensureAuthenticated(page);

    // 1. Navigate to Email & Triage Workspace (FE-WORK-04)
    await page.getByTestId("workspace-nav-mail").click();
    await expect(page.getByTestId("mail-workspace-pane")).toBeVisible();
    await expect(page.getByTestId("mail-keyboard-triage-chip")).toBeVisible();
    await expect(page.getByTestId("mail-reader-subject")).toContainText(
      "Q4 Architecture Review & Security Milestone",
    );
    // Remote tracking pixel blocked by default
    await expect(page.getByTestId("mail-remote-blocked-banner")).toBeVisible();
    await expect(page.getByTestId("mail-sanitized-iframe")).toHaveAttribute("sandbox", "");

    // Run human-supervised AI Triage (creates draft, never auto-sends)
    await page.getByTestId("mail-triage-btn").click();
    await expect(page.getByTestId("mail-triage-result")).toBeVisible();
    await expect(page.getByTestId("mail-triage-result")).toContainText("Suggest Only: true");

    // Compose with Undo-Send window and cancel send
    await page.getByTestId("mail-compose-subject").fill("Test Outbox Undo Send");
    await page.getByTestId("mail-compose-body").fill("Testing 10s undo window.");
    await page.getByTestId("mail-send-btn").click();
    await expect(page.getByTestId("mail-undo-send-btn")).toBeVisible();
    await page.getByTestId("mail-undo-send-btn").click();
    await expect(page.getByTestId("mail-undo-send-btn")).toHaveCount(0);

    // 2. Navigate to Notes & Todos Workspace (FE-WORK-05)
    await page.getByTestId("prod-tab-notes").click();
    await expect(page.getByTestId("notes-todos-workspace-pane")).toBeVisible();
    await expect(page.getByTestId("selected-note-title")).toContainText("Release Roadmap");
    await expect(page.getByTestId("selected-note-backlinks")).toContainText(
      "CalDAV Sync Architecture",
    );
    await expect(page.getByTestId("note-pin-toggle-btn")).toBeVisible();

    // Create a Todo and Assign to Agent
    await page.getByTestId("todo-create-title").fill("Generate Phase 07 Security Audit");
    await page.getByTestId("todo-create-submit").click();
    const firstAssignBtn = page.locator('[data-testid^="todo-assign-agent-"]').first();
    await firstAssignBtn.click();
    await expect(page.locator('[data-testid^="todo-agent-run-"]').first()).toContainText(
      "succeeded",
    );

    // 3. Navigate to Calendar & CalDAV Workspace (FE-WORK-06)
    await page.getByTestId("prod-tab-calendar").click();
    await expect(page.getByTestId("calendar-workspace-pane")).toBeVisible();
    await page.getByTestId("cal-quick-add-preview-btn").click();
    await expect(page.getByTestId("cal-quick-add-preview-card")).toContainText(
      "deterministic_grammar",
    );
    await expect(page.getByTestId("cal-quick-add-preview-card")).toContainText("Lunch with Sara");
    await page.getByTestId("cal-quick-add-commit-btn").click();

    // Simulate CalDAV 2-way ETag conflict and resolve without silent overwrite
    await page.getByTestId("cal-simulate-conflict-btn").click();
    await expect(page.getByTestId("cal-conflict-panel")).toBeVisible();
    await page.getByTestId("cal-conflict-resolve-keep_local").click();
    await expect(page.getByTestId("cal-conflict-panel")).toHaveCount(0);

    // 4. Navigate to Schedules, Notifications, Webhooks & Scoped API Tokens (FE-WORK-07, FE-ADMIN-04, FE-AGENT-14)
    await page.getByTestId("notifications-bell-btn").click();
    await expect(page.getByTestId("schedules-workspace-pane")).toBeVisible();
    await expect(page.getByTestId("sched-cron-human-preview")).toContainText(
      "Weekdays (Mon–Fri) at 09:00",
    );
    await expect(page.getByTestId("notifications-inbox-list")).toContainText(
      "Approval requested",
    );

    // Trigger schedule Run Now
    await page.locator('[data-testid^="sched-run-now-"]').first().click();
    await expect(page.getByTestId("sched-last-run-status")).toContainText("succeeded");

    // Mint a Scoped API Token (shown once)
    await page.getByTestId("token-create-name").fill("E2E Operator Token");
    await page.getByTestId("token-create-submit").click();
    await expect(page.getByTestId("token-shown-once-banner")).toContainText("odys_tok_");

    // Verify SSRF-Safe Outbound Webhook blocks loopback target
    await page.getByTestId("webhook-target-url-input").fill("http://127.0.0.1:8000/api/admin");
    await page.getByTestId("webhook-register-submit").click();
    await expect(page.getByTestId("webhook-ssrf-error")).toBeVisible();

    // Register valid external webhook, simulate 3x failure -> DLQ, and replay DLQ
    await page
      .getByTestId("webhook-target-url-input")
      .fill("https://hooks.partner.example/odysseus-e2e");
    await page.getByTestId("webhook-register-submit").click();
    await page.locator('[data-testid^="webhook-simulate-dlq-"]').first().click();
    await expect(page.getByTestId("webhook-dlq-replay-btn")).toBeVisible();
    await page.getByTestId("webhook-dlq-replay-btn").click();
    await expect(page.getByTestId("webhook-dlq-replay-btn")).toHaveCount(0);

    // 5. Run @axe-core/playwright WCAG AA accessibility scan
    const axe = await new AxeBuilder({ page })
      .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa"])
      .analyze();
    const seriousOrCritical = axe.violations.filter(
      (v) => v.impact === "serious" || v.impact === "critical",
    );
    expect(seriousOrCritical).toEqual([]);
  });
});
