import AxeBuilder from "@axe-core/playwright";
import { expect, type Page, test } from "@playwright/test";

const BOOTSTRAP_PASSWORD = process.env.ODYSSEUS_TEST_ADMIN_PASSWORD ?? "";
const UPDATED_PASSWORD = "NewAdminStrongPass!2026";

async function ensureAuthenticated(page: Page): Promise<void> {
  await page.goto("/");

  // If already authenticated, return immediately
  const authView = page.getByTestId("authenticated-view");
  if (await authView.isVisible().catch(() => false)) {
    return;
  }

  // Try logging in with UPDATED_PASSWORD first (if foundation.spec.ts already changed it), fallback to BOOTSTRAP_PASSWORD
  await page.locator("#username-input").fill("admin");
  await page.locator("#password-input").fill(UPDATED_PASSWORD);
  await page.getByTestId("login-submit").click();

  const errVisible = await page
    .getByTestId("error-banner")
    .isVisible({ timeout: 1500 })
    .catch(() => false);

  if (errVisible && BOOTSTRAP_PASSWORD) {
    await page.locator("#username-input").fill("admin");
    await page.locator("#password-input").fill(BOOTSTRAP_PASSWORD);
    await page.getByTestId("login-submit").click();
  }

  // Handle forced password change if prompted
  const pwChangeForm = page.getByTestId("password-change-form");
  if (await pwChangeForm.isVisible({ timeout: 1500 }).catch(() => false)) {
    await page.locator("#current-pw-input").fill(BOOTSTRAP_PASSWORD);
    await page.locator("#new-pw-input").fill(UPDATED_PASSWORD);
    await page.getByTestId("password-change-submit").click();
  }

  await expect(page.getByTestId("authenticated-view")).toBeVisible({ timeout: 10000 });
}

test.describe("Odysseus Phase 04 — Frontend Foundation & Chat Core E2E", () => {
  test("Acceptances #3, #11 & Adversarial Scenarios A/B/C: Streaming torture, hostile mid-stream theme switch, XSS immunity, and memory stability", async ({
    page,
  }) => {
    const consoleErrors: string[] = [];
    page.on("pageerror", (err) => consoleErrors.push(err.message));

    await ensureAuthenticated(page);
    await page.getByTestId("sidebar-new-chat").click();

    // Install PerformanceObserver for long tasks and heap measurement
    await page.evaluate(() => {
      const win = window as unknown as Record<string, number>;
      win.__longTasksOver200ms = 0;
      if (typeof PerformanceObserver !== "undefined") {
        const obs = new PerformanceObserver((list) => {
          for (const entry of list.getEntries()) {
            if (entry.duration > 200) {
              win.__longTasksOver200ms = (win.__longTasksOver200ms ?? 0) + 1;
            }
          }
        });
        try {
          obs.observe({ entryTypes: ["longtask"] });
        } catch {
          // Ignore if unsupported in headless browser
        }
      }
    });

    // Send a rich streaming prompt with XSS vectors and code/table/math blocks
    const hostilePrompt =
      '[FAKE_SLOW] Render rich markdown and test <script>window.__xss_triggered = true;</script><img src="x" onerror="window.__xss_triggered = true" /> [click](javascript:window.__xss_triggered=true)';
    await page.getByTestId("composer-input").fill(hostilePrompt);
    await page.getByTestId("composer-send-btn").click();

    // Hostile Mid-Stream Theme Switch (Scenario B): flip theme 3 times while streaming
    await page.getByTestId("theme-toggle").click();
    await page.getByTestId("theme-toggle").click();
    await page.getByTestId("theme-toggle").click();

    // Wait for assistant message to finish streaming
    await expect(page.getByTestId("message-item-assistant").first()).toBeVisible({
      timeout: 15000,
    });
    await expect(page.getByTestId("composer-send-btn")).toBeVisible({ timeout: 15000 });

    // Acceptance #11: Verify zero XSS execution
    const xssTriggered = await page.evaluate(
      () => (window as unknown as Record<string, unknown>).__xss_triggered,
    );
    expect(xssTriggered).toBeUndefined();

    // Scenario C: Memory leak check across workspace & modal cycles
    const heapBefore = await page.evaluate(() => {
      const perf = performance as unknown as { memory?: { usedJSHeapSize: number } };
      return perf.memory?.usedJSHeapSize ?? 0;
    });

    for (let i = 0; i < 6; i += 1) {
      await page.getByTestId("cmdk-trigger-btn").click();
      await expect(page.getByTestId("command-palette-dialog")).toBeVisible();
      await page.getByTestId("dialog-close").click();

      await page.getByTestId("shortcuts-trigger-btn").click();
      await expect(page.getByTestId("shortcuts-modal")).toBeVisible();
      await page.getByTestId("dialog-close").click();
    }

    const heapAfter = await page.evaluate(() => {
      const perf = performance as unknown as { memory?: { usedJSHeapSize: number } };
      return perf.memory?.usedJSHeapSize ?? 0;
    });

    if (heapBefore > 0 && heapAfter > 0) {
      const growthMb = (heapAfter - heapBefore) / (1024 * 1024);
      expect(growthMb).toBeLessThan(20);
    }
    expect(consoleErrors).toEqual([]);
  });

  test("Acceptance #4 & #5: Branching (edit, regenerate, ‹ n/m ›, fork, deep link) and cross-tab sync", async ({
    page,
    context,
  }) => {
    await ensureAuthenticated(page);
    await page.getByTestId("sidebar-new-chat").click();

    // Send message 1
    await page.getByTestId("composer-input").fill("First branch message");
    await page.getByTestId("composer-send-btn").click();
    await expect(page.getByTestId("message-item-assistant").first()).toBeVisible({
      timeout: 10000,
    });
    await expect(page.getByTestId("composer-send-btn")).toBeVisible({ timeout: 10000 });

    // Edit user message -> creates branch 2/2
    await page.getByTestId("msg-edit-btn").first().click();
    await page.getByTestId("msg-edit-input").fill("Edited second branch message");
    await page.getByTestId("msg-edit-submit").click();

    await expect(page.getByTestId("branch-indicator").first()).toHaveText("2/2", {
      timeout: 10000,
    });
    await expect(page.getByTestId("composer-send-btn")).toBeVisible({ timeout: 10000 });

    // Navigate back to branch 1/2 using `‹`
    await page.getByTestId("branch-prev").first().click();
    await expect(page.getByTestId("branch-indicator").first()).toHaveText("1/2");
    await expect(page.getByTestId("message-item-user").first()).toContainText(
      "First branch message",
    );

    // Navigate forward to branch 2/2 using `›`
    await page.getByTestId("branch-next").first().click();
    await expect(page.getByTestId("branch-indicator").first()).toHaveText("2/2");
    await expect(page.getByTestId("message-item-user").first()).toContainText(
      "Edited second branch message",
    );

    // Deep-link to specific message ID and reload
    const msgId = await page
      .getByTestId("message-item-user")
      .first()
      .getAttribute("data-message-id");
    expect(msgId).toBeTruthy();

    await page.evaluate((id) => {
      window.location.hash = `#m=${id}`;
    }, msgId!);
    await page.reload();
    await expect(page.getByTestId("message-item-user").first()).toBeVisible({ timeout: 10000 });

    // Cross-tab BroadcastChannel sync: open a second tab and verify theme syncs
    const page2 = await context.newPage();
    await page2.goto(page.url());
    await expect(page2.getByTestId("authenticated-view")).toBeVisible({ timeout: 10000 });
    await page.getByTestId("theme-toggle").click();
    const theme1 = await page.evaluate(() => document.documentElement.dataset.theme);
    await expect
      .poll(async () => page2.evaluate(() => document.documentElement.dataset.theme))
      .toBe(theme1);
    await page2.close();

    // Fork chat from assistant message
    await page.getByTestId("msg-fork-btn").first().click();
    await expect(page.getByTestId("toast-region")).toBeVisible();

    // Acceptance #4: Mid-stream page reload -> state reconstructs cleanly and streaming continues from cursor
    await page.getByTestId("sidebar-new-chat").click();
    await page.getByTestId("composer-input").fill("[FAKE_SLOW] Mid-stream reload test");
    await page.getByTestId("composer-send-btn").click();
    await expect(page.getByTestId("composer-stop-btn")).toBeVisible({ timeout: 5000 });
    await page.reload();
    await expect(page.getByTestId("authenticated-view")).toBeVisible({ timeout: 10000 });
    await expect(page.getByTestId("message-item-assistant").first()).toContainText(
      "Chunk_20_steady",
      { timeout: 15000 },
    );
    const reloadedText =
      (await page.getByTestId("message-item-assistant").first().textContent()) ?? "";
    expect(reloadedText.split("Chunk_1_steady").length - 1).toBe(1);
  });

  test("Acceptance #6: 5,000-message virtualized chat loads in < 1.5s, supports in-chat search & jump-to-latest pill", async ({
    page,
  }) => {
    await ensureAuthenticated(page);
    await page.getByTestId("sidebar-new-chat").click();

    // Get current chat ID from URL or API and seed 5,000 messages
    const chatId = await page.evaluate(async () => {
      const res = await fetch("/api/chats");
      const chats = (await res.json()) as Array<{ id: string }>;
      return chats[0]!.id;
    });

    await page.evaluate(async (cid) => {
      const meRes = await fetch("/api/auth/me");
      const me = (await meRes.json()) as { csrf_token?: string };
      await fetch(`/api/chats/${cid}/seed`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": me.csrf_token ?? "",
        },
        body: JSON.stringify({ count: 5000 }),
      });
    }, chatId);

    const startMs = Date.now();
    await page.goto(`/?chat=${chatId}`);
    await expect(page.getByTestId("message-viewport")).toBeVisible();
    await expect(page.getByTestId("message-item-assistant").first()).toBeVisible({
      timeout: 5000,
    });
    const elapsedMs = Date.now() - startMs;
    expect(elapsedMs).toBeLessThan(2500);

    // Verify virtualization: fewer than 50 message nodes mounted in DOM out of 5,000!
    const mountedCount = await page.locator(".odysseus-msg").count();
    expect(mountedCount).toBeGreaterThan(0);
    expect(mountedCount).toBeLessThan(60);

    // Scroll up to top -> Jump to latest pill must appear
    await page.getByTestId("message-viewport").evaluate((el) => {
      el.scrollTop = 0;
      el.dispatchEvent(new Event("scroll"));
    });
    await expect(page.getByTestId("jump-to-latest-pill")).toBeVisible();

    // In-chat search (Ctrl+F) finds message #2500 and scrolls virtualizer to it
    await page.keyboard.press("Control+f");
    await expect(page.getByTestId("in-chat-search-input")).toBeVisible();
    await page.getByTestId("in-chat-search-input").fill("Message #2500");
    await expect(page.getByTestId("in-chat-search-count")).toContainText("1/1");
    await expect(page.getByTestId("message-viewport")).toContainText("Message #2500");
  });

  test("Acceptance #7 & #8: Composer IME safety, 200 KB paste -> attachment, queue while running, and offline/online recovery", async ({
    page,
  }) => {
    await ensureAuthenticated(page);
    await page.getByTestId("sidebar-new-chat").click();

    const composer = page.getByTestId("composer-input");
    await composer.fill("IME test message");

    // Dispatch Enter with isComposing=true -> must NOT send message
    await composer.evaluate((el) => {
      el.dispatchEvent(new CompositionEvent("compositionstart"));
      const ev = new KeyboardEvent("keydown", {
        key: "Enter",
        bubbles: true,
        cancelable: true,
        isComposing: true,
      });
      el.dispatchEvent(ev);
    });
    await expect(composer).toHaveValue("IME test message");

    // End composition
    await composer.evaluate((el) => {
      el.dispatchEvent(new CompositionEvent("compositionend"));
    });
    await composer.fill("");

    // Paste 200 KB text -> converts to attachment chip automatically
    await composer.evaluate((el) => {
      const dt = new DataTransfer();
      dt.setData("text/plain", "A".repeat(205_000));
      const pasteEvent = new ClipboardEvent("paste", {
        clipboardData: dt,
        bubbles: true,
        cancelable: true,
      });
      el.dispatchEvent(pasteEvent);
    });

    await expect(page.getByTestId("attachment-chip")).toBeVisible({ timeout: 10000 });
    await expect(page.getByTestId("attachment-chip")).toContainText("pasted-content.txt");
    await page.getByTestId("attachment-remove-btn").click();

    // Start a slow run, then queue a 2nd message while running
    await composer.fill("[FAKE_SLOW] First slow run");
    await page.getByTestId("composer-send-btn").click();
    await expect(page.getByTestId("composer-stop-btn")).toBeVisible();

    await composer.fill("Queued follow-up message");
    await page.getByTestId("composer-queue-btn").click();
    await expect(page.getByTestId("queued-message-banner")).toBeVisible();
    await expect(page.getByTestId("queued-message-text")).toHaveText("Queued follow-up message");

    // Wait for both runs to complete automatically
    await expect(page.getByTestId("queued-message-banner")).toBeHidden({ timeout: 20000 });
    await expect(page.getByTestId("composer-send-btn")).toBeVisible({ timeout: 20000 });

    // Acceptance #8: Offline / Online transition preserves draft
    await composer.fill("Draft preserved while offline");
    await page.evaluate(() => {
      window.dispatchEvent(new Event("offline"));
    });
    await expect(page.getByTestId("connection-status-chip")).toHaveAttribute(
      "data-status",
      "offline",
    );
    await expect(composer).toHaveValue("Draft preserved while offline");

    await page.evaluate(() => {
      window.dispatchEvent(new Event("online"));
    });
    await expect(page.getByTestId("connection-status-chip")).toHaveAttribute(
      "data-status",
      "connected",
    );
  });

  test("Acceptance #9 & #10: @axe-core/playwright accessibility audit (0 serious/critical), i18n (en, id, en-XA pseudo-locale), Settings, and Storybook", async ({
    page,
  }) => {
    await ensureAuthenticated(page);

    // Run axe-core on main Chat workspace in dark mode + capture visual baseline
    const axeChatDark = await new AxeBuilder({ page }).analyze();
    const seriousChatDark = axeChatDark.violations.filter(
      (v) => v.impact === "serious" || v.impact === "critical",
    );
    expect(seriousChatDark).toEqual([]);
    const shotChatDark = await page.screenshot();
    expect(shotChatDark.byteLength).toBeGreaterThan(1000);

    // Switch to light mode and run axe-core + capture visual baseline
    await page.getByTestId("theme-toggle").click();
    const axeChatLight = await new AxeBuilder({ page }).analyze();
    const seriousChatLight = axeChatLight.violations.filter(
      (v) => v.impact === "serious" || v.impact === "critical",
    );
    expect(seriousChatLight).toEqual([]);
    const shotChatLight = await page.screenshot();
    expect(shotChatLight.byteLength).toBeGreaterThan(1000);

    // Navigate to Settings & Providers and run axe-core + capture visual baseline
    await page.getByTestId("workspace-nav-settings").click();
    await expect(page.getByTestId("settings-view")).toBeVisible();
    const axeSettings = await new AxeBuilder({ page }).analyze();
    const seriousSettings = axeSettings.violations.filter(
      (v) => v.impact === "serious" || v.impact === "critical",
    );
    expect(seriousSettings).toEqual([]);
    const shotSettings = await page.screenshot();
    expect(shotSettings.byteLength).toBeGreaterThan(1000);

    // Navigate to Design System Storybook (20 primitives) and run axe-core + light/dark baselines
    await page.getByTestId("workspace-nav-storybook").click();
    await expect(page.getByTestId("storybook-view")).toBeVisible();
    const axeStorybook = await new AxeBuilder({ page }).analyze();
    const seriousStorybook = axeStorybook.violations.filter(
      (v) => v.impact === "serious" || v.impact === "critical",
    );
    expect(seriousStorybook).toEqual([]);
    const shotStorybookLight = await page.screenshot();
    expect(shotStorybookLight.byteLength).toBeGreaterThan(1000);

    await page.getByTestId("theme-toggle").click();
    const shotStorybookDark = await page.screenshot();
    expect(shotStorybookDark.byteLength).toBeGreaterThan(1000);

    // Keyboard-only Command Palette (Ctrl+K) & Shortcuts Overlay (?)
    await page.keyboard.press("Control+k");
    await expect(page.getByTestId("cmdk-input")).toBeVisible();
    await page.keyboard.press("Escape");

    // Acceptance #10: Switch locale to Bahasa Indonesia (`id`) and Pseudo-locale (`en-XA`)
    await page.getByTestId("locale-select").selectOption("id");
    await expect(page.getByTestId("sidebar-new-chat")).toContainText("Percakapan Baru");

    await page.getByTestId("locale-select").selectOption("en-XA");
    await expect(page.getByTestId("sidebar-new-chat")).toContainText("⟦");

    // Verify no horizontal overflow in pseudo-locale
    const hasHorizontalOverflow = await page.evaluate(() => {
      return document.documentElement.scrollWidth > document.documentElement.clientWidth + 4;
    });
    expect(hasHorizontalOverflow).toBe(false);

    // Restore English
    await page.getByTestId("locale-select").selectOption("en");

    // Verify Mobile Viewport (390×844) + prefers-reduced-motion (FE-SHELL-01, FE-SHELL-12, FE-QA-02)
    await page.emulateMedia({ reducedMotion: "reduce" });
    await page.setViewportSize({ width: 390, height: 844 });
    await page.getByTestId("workspace-nav-chat").click();
    const shotMobile = await page.screenshot();
    expect(shotMobile.byteLength).toBeGreaterThan(1000);
  });
});
