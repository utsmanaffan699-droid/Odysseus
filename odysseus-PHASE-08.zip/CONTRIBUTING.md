# Contributing to Odysseus

## Development Workflow

1. **Install dependencies and run verification:**
   ```bash
   make verify
   ```
2. **Conventional Commits:**
   All commits must follow Conventional Commits (`feat:`, `fix:`, `security:`, `test:`, `docs:`, `chore:`, `ci:`, `refactor:`, `perf:`, `build:`). This is enforced by `.githooks/commit-msg` and CI.
3. **Contract-First Development:**
   - Update Pydantic models in `backend/contracts/` or routers in `backend/app/routers/`.
   - Run `make gen-contracts` to regenerate `contracts/openapi.json`, `contracts/event-schema.json`, and TypeScript client/types under `frontend/src/lib/contracts/`.
   - CI fails if generated contracts drift from the committed schemas.
4. **Quality Gates:**
   - `ruff check` and `mypy --strict` must pass with 0 errors.
   - Every route must declare an explicit authentication/authorization policy in `ROUTE_POLICIES`.
   - Unit, integration, migration, and adversarial security tests must pass (`make verify`).
