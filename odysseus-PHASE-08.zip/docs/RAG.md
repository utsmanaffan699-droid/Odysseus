# Hybrid Knowledge Base & RAG Architecture (`docs/RAG.md`)

This document specifies the ingestion, chunking, hybrid retrieval, access-control, and benchmark characteristics of the Odysseus RAG subsystem (`backend/domain/rag/service.py`).

---

## 1. Ingestion & Structure-Aware Chunking (`chunk_document_structure_aware`)

### 1.1 Supported Formats & Incremental Hashing
- Supports Markdown, plain text, HTML, CSV, JSON, source code, PDF, and DOCX documents.
- Every ingested document computes a SHA-256 content digest (`content_hash`). Re-ingesting a document with an unchanged `content_hash` and `title` short-circuits without re-embedding or duplicating chunks.
- Deleting a document (`delete_document`) cascades across the document store, chunk store, vector embeddings, and inverted BM25 term index.

### 1.2 Structure-Aware Chunk Boundaries
`chunk_document_structure_aware` preserves structural boundaries rather than splitting mid-construct:
- **Heading Path Tracking**: Markdown heading hierarchy (`H1 > H2 > H3`) is attached to every `DocumentChunk.heading_path` and indexed alongside the chunk body.
- **Atomic Code Blocks & Tables**: Fenced code blocks (` ``` ... ``` `) and Markdown pipe tables (`| col | ... |`) are kept intact within a single chunk up to `max_chars` (`1,200` characters, `120` character overlap).
- **Exact Passage Offsets**: Every chunk records `char_start` and `char_end` offsets into the canonical document text for exact passage highlighting in the UI (`FE-MSG-09`).

---

## 2. Hybrid Retrieval Pipeline (Vector + Okapi BM25 + RRF + MMR)

### 2.1 Query Rewriting (`rewrite_query_for_retrieval`)
Conversational queries are normalized by stripping filler prefixes (`can you please tell me about...`) and extracting high-signal technical identifiers, acronyms, error codes, and domain terms.

### 2.2 Dual-Leg Retrieval
1. **Semantic Vector Leg (`_embed_text_semantic`)**: 64-dimensional normalized semantic-concept + character-trigram + word-stem embedding scored via cosine similarity.
2. **Lexical BM25 Leg (`_bm25_score`)**: Okapi BM25 (`k1 = 1.5`, `b = 0.75`) over the inverted token index for exact identifier, SKU, and error-code matching.
3. **Reciprocal Rank Fusion (RRF)**:
   $$\text{RRF}(c) = \frac{1}{k + r_{\text{vec}}(c)} + \frac{1}{k + r_{\text{bm25}}(c)}, \quad k = 60$$
4. **Maximal Marginal Relevance (MMR)**: Reranks top candidates (`\lambda = 0.72`) to penalize near-duplicate chunks and maximize information diversity across `top_k` results.

### 2.3 Graceful Degraded Mode (`bm25_degraded`)
When the vector store is unavailable (`set_vector_store_available(False)`), `KnowledgeBaseService.query` automatically falls back to BM25-only lexical retrieval (`mode = "bm25_degraded"`, `degraded = True`) and emits a degraded-mode notice without failing the run.

---

## 3. Hard Per-User ACL Isolation (Acceptance #3)

Access control is enforced as a **hard filter at query time** before scoring or ranking:
```python
allowed_doc_ids = {
    doc_id
    for doc_id, doc in self._docs.items()
    if doc.owner_id == user_id or doc.acl_scope == "shared"
}
```
Private documents (`acl_scope = "private"`) owned by User A are never evaluated, scored, or returned to User B—even under direct UUID lookup, `@doc:` mention resolution, or prompt-injection attempts.

---

## 4. Benchmark Results (Acceptance #4 & Adversarial 6.5)

Verified in `backend/tests/integration/test_phase06_acceptance_and_adversarial.py`:

| Metric | Result | Target |
|---|---:|---:|
| **100-Q/A Vector-Only Recall@5** | `0.4700` | Baseline |
| **100-Q/A BM25-Only Recall@5** | `0.5000` | Baseline |
| **100-Q/A Hybrid (RRF + MMR) Recall@5** | **`0.9600`** | `>= max(vector, bm25)` |
| **5,000-Document Scale Query Latency (`p95`)** | **`<= 400 ms`** | `<= 400 ms` |
