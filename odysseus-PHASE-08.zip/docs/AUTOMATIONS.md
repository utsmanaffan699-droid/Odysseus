# Odysseus Scheduler, Automations, Webhooks & Scoped API Tokens

## 1. Scheduler Engine (`backend/domain/schedules`)
- **Cron / Interval / One-Shot**: Validated with `croniter` in IANA timezones (`zoneinfo.ZoneInfo`) with DST-accurate next-run computation (`compute_next_cron_runs`).
- **Restart-Storm Deduplication**: Each firing window `(schedule_id, scheduled_slot_iso)` is claimed atomically by idempotency key so even 10× worker kills/restarts during a firing window result in at most 1 execution.
- **Misfire & Overlap Policies**: Supports `skip`, `run_once`, and `catch_up` (capped at `catch_up_cap`) for misfires, and `skip`, `queue`, and `cancel_previous` for overlaps.
- **Circuit Breaker (`flapping` & `auto_disabled`)**: Marks a schedule `flapping` after 3 consecutive errors and auto-disables it (`enabled=False, auto_disabled=True`) at `auto_disable_threshold` (default 5), emitting a `schedule.auto_disabled` notification.
- **Background Approvals**: Default to deny-on-timeout (`denied_on_approval_timeout`), never hanging or auto-allowing.

## 2. Notifications (`backend/domain/notifications`)
- Delivers alerts across **In-App Inbox**, **Web Push (VAPID)**, **ntfy**, and **Email Digests** in `< 5 s`.

## 3. Signed Inbound & SSRF-Safe Outbound Webhooks
- **Inbound Webhooks (`POST /api/webhooks/inbound/{endpoint_id}`)**: Verifies `X-Odysseus-Signature` (`HMAC-SHA256(secret, "{timestamp}.{body}")`), enforces a `±300 s` timestamp window, and tracks `X-Odysseus-Nonce` to block replay attacks (`409 replay_detected`).
- **Outbound Webhooks**: Re-validates target URLs through `validate_ssrf_safe_url` at both registration and delivery time (blocking `127.0.0.1`, `169.254.169.254`, `localhost`, RFC1918, IPv6 loopback), retries with exponential backoff (`[100, 400, 1600]` ms), and moves 3× failed deliveries to the Dead-Letter Queue (`replay_dead_letter`).

## 4. Scoped API Tokens & `odysseus` CLI (`backend/cli.py`)
- Personal API tokens (`odys_tok_...`) are shown only once on creation, stored as SHA-256 hashes at rest, scoped (`chats:write`, `todos:write`, `mail:read`, etc.), rate-limited per minute, and revocable.
- The `odysseus` CLI (`python3 -m backend.cli`) supports `chat`, `todos list|add`, `schedules`, and `token` subcommands.
