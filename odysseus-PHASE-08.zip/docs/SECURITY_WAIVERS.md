# Security Waivers (`docs/SECURITY_WAIVERS.md`)

All high/critical findings from `pip-audit`, `npm audit --omit=dev`, and container scans must be zero or explicitly documented and justified here with remediation plans.

| Tool | Package / Advisory | Severity | Scope | Justification & Mitigation | Expiry |
|---|---|---|---|---|---|
| `pip-audit` | Pre-installed global image scientific packages (e.g. `jupyter`/`tornado` in base e2b sandbox image outside Odysseus runtime) | Low/Moderate | Base VM image only | Not imported or packaged by Odysseus (`Dockerfile` builds an isolated slim virtualenv with only Odysseus dependencies). Odysseus dependencies themselves have 0 high/critical vulnerabilities. | 2026-12-31 |
