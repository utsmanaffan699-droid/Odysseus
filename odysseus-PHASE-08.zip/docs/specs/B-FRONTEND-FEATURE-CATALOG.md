# B — FRONTEND FEATURE CATALOG (professional AI-agent UI standard)

> Attach to Phases 04–08. Derived from the feature sets of Claude (artifacts side panel, collapsible extended thinking, projects, citations, sharing), ChatGPT (edit→branch, regenerate, canvas, memory indicator, projects, scheduled tasks, agent mode with a to-do list, temporary chat, voice, search chats), OpenClaw's Control UI (live streaming with tool-call output, abort, sessions with thinking/verbose overrides, cron jobs with history, skills install/enable, exec-approval allowlists, schema-driven config editor, context %/token/cost dashboards, sub-agent activity, cron flapping detection), and Odysseus itself (writing-first documents, email triage, compare, Cookbook, guided tours).

## HOW TO USE THIS CATALOG

- Every line has an ID. You must create `docs/FRONTEND_TRACEABILITY.md`: a table `ID | status (done/partial/gap) | implementing files | test file::name | notes`. A phase cannot close with an ID in its scope missing from the table.
- **"Done" requires an automated test** (Playwright for behavior, Vitest for logic, axe for a11y). Visual states (loading/empty/error/offline/streaming) each need a Storybook story and a screenshot baseline.
- Priority tags: **[M]** must-have for v1, **[S]** should-have, **[C]** could-have (ship if time remains, otherwise KNOWN_GAPS).
- Each feature must work on: Chrome, Firefox, Safari (latest), mobile viewport 390×844, and with `prefers-reduced-motion` and keyboard only.

---

## 1. APP SHELL & NAVIGATION (FE-SHELL)

- FE-SHELL-01 [M] Collapsible, resizable sidebar (persisted width); mobile = drawer with swipe + focus trap.
- FE-SHELL-02 [M] "New chat", chat search (full-text across titles and message bodies, highlighted matches, keyboard navigable), Recents grouped Today / Yesterday / 7 days / 30 days / Older.
- FE-SHELL-03 [M] Chat context menu: rename inline, pin, archive, move to project/folder, duplicate, export, delete (with undo toast, 10 s).
- FE-SHELL-04 [M] Projects: list, create, instructions editor, files/sources, default model, per-project tool allowlist, project-scoped memory; chats listed under the project.
- FE-SHELL-05 [M] Top bar: model selector (capability badges: vision / tools / thinking / context window / cost tier; provider health dot), chat title (editable), share/export, overflow menu.
- FE-SHELL-06 [M] Command palette (Ctrl/Cmd+K): navigate, run actions, switch model, search chats/docs/notes/emails, run slash-commands; fuzzy search; recent items.
- FE-SHELL-07 [M] Global keyboard shortcuts + `?` cheat-sheet overlay (new chat, focus composer, toggle sidebar, next/prev message `j/k`, stop run `Esc`, toggle thinking, open timeline, toggle artifact panel). User-rebindable in Settings.
- FE-SHELL-08 [M] Routing with deep links to chat, message (`#m=<id>`), run step (`#s=<id>`), artifact version, document, email thread, calendar date. Back/forward correct.
- FE-SHELL-09 [M] Workspace switcher: Chat · Documents · Email · Notes & Tasks · Calendar · Research · Compare · Gallery · Cookbook · Agents/Runs · Admin (visibility by privilege).
- FE-SHELL-10 [M] Themes (light/dark/system + at least 3 curated palettes), density (compact/comfortable), font size, code font, message width (narrow/wide). All via CSS variables; no flash of wrong theme on load.
- FE-SHELL-11 [M] PWA: installable, service worker with versioned cache + update prompt ("New version available — Reload"), offline shell, offline-banner, queued composer drafts.
- FE-SHELL-12 [M] Responsive layout system: single-pane mobile, two-pane tablet, three-pane desktop (sidebar | chat | side panel). Safe-area insets; virtual keyboard–aware composer.
- FE-SHELL-13 [S] Multi-window/pop-out for artifacts, timeline, documents.
- FE-SHELL-14 [S] Temporary chat (not saved, not memorized, visible indicator).
- FE-SHELL-15 [M] Global toast/notification system (stacking, undo actions, a11y live regions), error boundary per route with "copy diagnostics".
- FE-SHELL-16 [M] First-run onboarding (admin password change, add provider wizard with live probe, optional services status) + skippable guided tours built on one shared `tour-core`.
- FE-SHELL-17 [M] Connection status indicator (SSE/WebSocket health, reconnecting…, degraded services chip → opens health panel).
- FE-SHELL-18 [M] i18n (`en`, `id`), RTL-safe layout (logical CSS properties), per-message automatic text direction, locale-aware dates/numbers.

## 2. COMPOSER (FE-COMP)

- FE-COMP-01 [M] Auto-growing multiline input; Enter=send, Shift+Enter=newline (configurable, IME-safe: never send during composition); Ctrl/Cmd+Enter alt.
- FE-COMP-02 [M] Attachments: drag-drop anywhere, paste images/files, picker, camera on mobile; chips with thumbnail, size, progress, cancel, retry; type/size validation with friendly errors; very long pasted text offered as an attachment.
- FE-COMP-03 [M] Slash commands (`/agent`, `/research`, `/compare`, `/canvas`, `/summarize`, `/clear`, `/model`, `/skill …`) with inline menu; user-defined prompt shortcuts.
- FE-COMP-04 [M] `@` mentions: files, documents, notes, emails, projects, agents, skills, tools; inserted as structured tokens (backspace removes whole token).
- FE-COMP-05 [M] Mode toggles in a tools popover: Web search, Deep research, Agent mode, Canvas/Artifacts, Memory, Thinking effort (off/low/medium/high/auto) with per-chat persistence and visible active-state pills.
- FE-COMP-06 [M] Send ↔ Stop button swap while running; **queue** a message while streaming (shown as "queued", editable/removable) and **steer** an active run (send guidance mid-run → `steer` API).
- FE-COMP-07 [M] Context meter: live token estimate vs model window, warning at 80%/95%, click → breakdown (system, tools, memory, history, attachments) + "compact now".
- FE-COMP-08 [M] Draft persistence per chat (survives reload/crash), prompt history via ArrowUp on empty input, undo/redo.
- FE-COMP-09 [M] Voice input (mic button): browser STT or server STT; push-to-talk and toggle; waveform; interim transcript.
- FE-COMP-10 [S] Prompt library / saved prompts with variables `{{name}}`, quick-insert.
- FE-COMP-11 [M] Pre-flight validation: unsupported attachment for model (e.g., image on text-only), context overflow, missing provider key → inline actionable message (never a silent failure).
- FE-COMP-12 [S] Edit-in-place of the last user message with diff preview before resubmit.

## 3. MESSAGE RENDERING & STREAMING (FE-MSG)

- FE-MSG-01 [M] **Incremental streaming render**: text appears token-by-token with no layout thrash; Markdown is parsed incrementally and *stably* — unclosed code fences, lists, tables, bold, links, math, and HTML mid-stream must render sensibly and never flicker or reflow earlier blocks. Only the last block re-renders (memoized blocks). Tests with adversarial stream scripts.
- FE-MSG-02 [M] Smooth-but-honest streaming: render at network pace, optional cosmetic smoothing (setting), never delay content > 100 ms; `prefers-reduced-motion` disables animation.
- FE-MSG-03 [M] GitHub-flavored Markdown: tables (scrollable, sticky header, copy as CSV/Markdown), task lists, footnotes, strikethrough, autolinks, nested lists, blockquotes, horizontal rules, details/summary.
- FE-MSG-04 [M] **Code blocks**: syntax highlighting (shiki, lazy language loading, light/dark themes), language label, **copy** (with success state), word-wrap toggle, line numbers toggle, collapse/expand for > 30 lines, download as file, "open in artifact/canvas", diff blocks (unified + side-by-side), terminal/console blocks styled differently, filename header when provided (```ts title="x.ts"), inline code styling, line highlighting, accessible (focusable, labelled) and keyboard-copyable. Highlighting runs incrementally and falls back to plain text instantly, never blocks.
- FE-MSG-05 [M] Math (KaTeX; `$…$`, `$$…$$`, `\( \)`), Mermaid diagrams (lazy, error fallback shows source, theme-aware), LaTeX errors non-fatal.
- FE-MSG-06 [M] Images (lightbox, zoom, download, alt text), generated images with regenerate, SVG sanitized, audio/video players for media outputs.
- FE-MSG-07 [M] Links: open in new tab with `noopener noreferrer`; external-link hover preview; unsafe schemes blocked; optional "confirm leaving" for untrusted domains.
- FE-MSG-08 [M] **Thinking block**: collapsed by default with live "Thinking… 12 s" header while streaming, expandable, auto-collapse on finish showing "Thought for 14 s"; respects per-chat "show/hide reasoning" and server-side redaction.
- FE-MSG-09 [M] **Citations/sources**: inline numbered chips `[1]` with hover card (title, domain, favicon via local proxy, snippet), click scrolls to source list; sources drawer at message end and a per-message "Sources (n)" panel; broken/blocked source states.
- FE-MSG-10 [M] Message actions (hover on desktop, long-press/overflow on mobile): copy (rich + markdown), regenerate (with model picker), **edit & resubmit** (user messages), **branch navigation `‹ 2/3 ›`** at every fork point, fork-from-here into a new chat, feedback 👍/👎 with reason chips + free text, read aloud (TTS) with highlight, bookmark, share, quote-reply (select text → "Reply"), delete (subtree-aware), raw view (dev mode: raw JSON parts + raw provider request/response, secrets redacted).
- FE-MSG-11 [M] Per-message metadata (toggle): model, latency, time-to-first-token, tokens in/out/cached/reasoning, cost, tool count.
- FE-MSG-12 [M] **Scroll behavior**: stick-to-bottom while streaming, auto-release when the user scrolls up, floating "Jump to latest ↓ (n new)" pill, scroll anchoring when content above changes, restore position per chat, `j/k` message navigation, "scroll to message" from search/deep link.
- FE-MSG-13 [M] **Virtualized message list** that remains correct with variable-height streaming content, in-page find (Ctrl+F interplay with virtualization → provide in-chat search), 5,000+ messages smooth.
- FE-MSG-14 [M] Error & edge states: provider error card with retry/switch model, partial response preserved when aborted (labelled "Stopped"), network-lost state with auto-resume, rate-limit countdown, content-filtered notice, "Continue generating" for length-truncated replies.
- FE-MSG-15 [M] Skeletons for loading; empty-chat welcome with suggestions (customizable), capability hints, recent projects.
- FE-MSG-16 [S] Text-selection toolbar on assistant text (explain, rewrite, to canvas, add to notes, ask follow-up).
- FE-MSG-17 [M] Export a chat/branch: Markdown, JSON, PDF (print stylesheet), HTML standalone; share link (read-only, revocable, optional expiry) when enabled by admin.
- FE-MSG-18 [M] Attachments in messages: rendered cards (PDF page preview, image grid, file icon+meta), click opens viewer panel.

## 4. AGENT EXPERIENCE (FE-AGENT) — the timeline

- FE-AGENT-01 [M] **Agent timeline** component: a vertical, live-updating, replayable record of the run, derived solely from `reduceRunState(events)`. Shows ordered steps: thinking, tool calls, sub-agents, compaction notices, plan updates, artifact creations, approvals — each with status icon, title, duration, and expandable detail. Inline in the chat message *and* available as a dedicated side panel / full-page "Run view".
- FE-AGENT-02 [M] Collapsed summary mode: "Worked for 42 s · 7 steps · 5 tools" with expand-all; auto-collapse completed runs, auto-expand the running step; user override persists.
- FE-AGENT-03 [M] **Plan/To-do tracker** (live): pinned checklist with pending / in-progress / done / skipped / failed states, updates as `plan.updated` arrives, progress ring, collapsible.
- FE-AGENT-04 [M] **Tool-call cards** with per-tool renderers chosen by `render_hint`: JSON viewer (collapsible tree, copy path), table (virtualized), diff (file edits with accept-info), terminal (ANSI colors, streaming stdout/stderr, scrollback cap, copy, "follow output"), search results (title/URL/snippet list), file tree, image/screenshot thumbnails (browser tool) with lightbox, key-value summary, generic text. Header: tool icon, name, args summary, status (queued/awaiting approval/running/succeeded/failed/denied), duration, retry. Large outputs lazy-loaded via `/tool-calls/{id}/output` with "Show full output".
- FE-AGENT-05 [M] **Approval UX**: when `tool.approval.requested` arrives → prominent inline card with exact command/args (syntax highlighted), risk badge, rationale; actions **Approve once / Approve for this run / Always allow pattern… / Deny (with optional reason sent to the model)**; pattern editor with live preview of what it matches; keyboard shortcuts (`Y`/`N`); countdown if expiring; notification (browser + ntfy) when tab hidden; mobile-friendly large targets. Resolved approvals stay in the timeline as an audit trail.
- FE-AGENT-06 [M] Run controls: **Stop** (immediate), **Pause/Resume**, **Steer** (guidance mid-run), **Retry step**, **Re-run from step**, **Continue** after interruption; each reflects server confirmation state (optimistic with rollback).
- FE-AGENT-07 [M] Budgets & live stats strip: elapsed, iteration n/max, tokens, cost, context % — turns amber/red near limits; "budget exceeded" end state with "Extend budget & continue".
- FE-AGENT-08 [M] Sub-agent tree: nested, collapsible child timelines with their own status/summary; jump-to-child; aggregate usage.
- FE-AGENT-09 [M] Resumability: reload/reconnect shows identical state; "Reconnecting…" → resync banner; second tab mirrors live; interrupted-by-restart runs show clear state and **Continue**.
- FE-AGENT-10 [S] Timeline scrubber/replay: play/pause/seek through a finished run at 1×–8×; share a deterministic replay (export events JSON; import to view offline).
- FE-AGENT-11 [M] Raw event inspector (dev mode): filter by type, search, copy event JSON, latency per event.
- FE-AGENT-12 [M] Run history page: filter by status/model/agent/date, sort by cost/duration, open any run, export trace, bulk delete; failed-run triage view with error classification and "retry with different model".
- FE-AGENT-13 [M] Agent presets/personas: name, system prompt, model, tool set, skills, budget, memory scope; quick-switch in the composer; duplicate/export/import.
- FE-AGENT-14 [M] Background runs: start, leave, get notified on completion (in-app badge, browser notification, ntfy); "Running (3)" tray with progress.
- FE-AGENT-15 [S] Browser-tool view: live screenshot stream panel with step annotations and user takeover request.
- FE-AGENT-16 [M] Memory visibility in-run: "Memory used (3)" chip → shows which memories were injected; "Memory updated" indicator with undo; per-chat memory off switch.
- FE-AGENT-17 [M] Skills in-run: shows which skill was loaded and why; link to edit it.
- FE-AGENT-18 [M] Safety banners: when untrusted content (web/email/file) influenced a tool request, the approval card says so ("Requested after reading web page example.com") — provenance shown.

## 5. ARTIFACTS / CANVAS (FE-ART)

- FE-ART-01 [M] Side panel that opens beside the chat (resizable, fullscreen, pop-out), with tabs for multiple artifacts; deep-linkable.
- FE-ART-02 [M] Types: Markdown doc, code file (any language, CodeMirror), HTML page (sandboxed iframe preview + source toggle), SVG, Mermaid, CSV/table, JSON, React/JS micro-app (sandboxed, no network by default), image.
- FE-ART-03 [M] **Live streaming into the artifact** (`artifact.delta`) with a stable editor — no cursor jumps; user edits are never overwritten by in-flight deltas (conflict handling: user edit locks a region; AI proposes a new version).
- FE-ART-04 [M] Version history: every AI or user change = version; compare any two (diff), restore, name/pin versions, "revert to this".
- FE-ART-05 [M] Canvas editing: select text/code → floating menu (improve, shorten, expand, explain, fix, custom instruction); results arrive as **suggestions** (inline tracked changes) with accept/reject per hunk and accept-all.
- FE-ART-06 [M] Copy, download (appropriate extension), export (PDF/DOCX where supported), "send to Documents" (persist), share read-only link.
- FE-ART-07 [M] Preview safety: HTML/JS artifacts run in `sandbox` iframes with strict CSP, no `allow-same-origin`, no top navigation, resource caps, a visible "Sandboxed" badge, console capture panel.
- FE-ART-08 [S] Run code artifacts (Python/JS) in a server-side or WASM sandbox with output panel.
- FE-ART-09 [M] Empty/loading/error states, unsaved indicator, autosave, offline edit queue.

## 6. KNOWLEDGE & PRODUCTIVITY VIEWS (FE-WORK)

- FE-WORK-01 [M] **Documents**: multi-tab writing-first editor (CodeMirror 6; Markdown with live preview, HTML, CSV grid editing, code), AI assist on selection, suggestion mode (accept/reject), word count, outline, find/replace, autosave, version history, export, drag to reorder tabs, mobile-usable.
- FE-WORK-02 [M] **Deep Research view**: plan, live query/source graph, sources list with fetch status, progress per stage, ability to steer/stop, final report viewer (sanitized, TOC, citations, export), history.
- FE-WORK-03 [M] **Compare**: pick N models, blind side-by-side streaming columns, per-column latency/tokens/cost, vote/rank, reveal identities, "synthesize best answer", save results, leaderboard of your own votes.
- FE-WORK-04 [M] **Email**: accounts, folders, threaded list (virtualized), reader (sanitized HTML, remote content blocked until allowed), compose with attachments, AI triage chips (urgency, tags, summary, spam), draft-reply panel, reminders, search, keyboard triage (`j/k/e/#/r`), offline-safe sending states and error recovery.
- FE-WORK-05 [M] **Notes & Todos**: rich Markdown notes, tags, pin, search; todos with due dates, priority, subtasks, "assign to agent" button (creates a run), linked notes.
- FE-WORK-06 [M] **Calendar**: month/week/day/agenda, drag-move/resize, quick-add natural language, recurrence editor (RRULE round-trip), CalDAV account sync status & conflict UI, `.ics` import/export, agent-scheduled tasks overlay.
- FE-WORK-07 [M] **Scheduler / Automations**: cron builder with human-readable preview and next-5-runs, enable/disable, run now, history with logs, failure/"flapping" badges, delivery status (ntfy/email), per-job agent preset and budget.
- FE-WORK-08 [M] **Gallery / Image editor**: grid, lightbox, metadata, generation history, editor (crop/rotate/adjust/mask/inpaint/upscale) with undo stack and non-destructive layers, mobile-friendly.
- FE-WORK-09 [M] **Cookbook**: hardware scan card, ranked model recommendations with fit explanation (VRAM/RAM, quant, backend), download queue with progress/ETA/pause/resume, serve controls, **streaming job log terminal with copyable full command/output/error and suggested next step**, remote servers manager (SSH key display), engine/dependency manager.
- FE-WORK-10 [M] **Memory browser**: search, filter by scope/source, edit, pin, delete, import/export, "why was this remembered" provenance, bulk operations.
- FE-WORK-11 [M] **Skills manager**: list with eligibility/install status, editor (Markdown + metadata), enable per agent, test-run in a scratch chat, untrusted-content warning for imported skills.
- FE-WORK-12 [M] **MCP manager** (admin): servers list with status/logs, tools discovered, per-tool policy, OAuth connect flow, test call.

## 7. SETTINGS, USAGE & ADMIN (FE-ADMIN)

- FE-ADMIN-01 [M] Settings are **schema-driven forms** generated from backend JSON Schema, plus a validated raw-JSON editor for power users, with search-in-settings, diff-before-save, reset-to-default, import/export, and per-field help.
- FE-ADMIN-02 [M] Providers/models: add endpoint wizard with live probe (latency, model list, tool-calling capability test, vision test), key vault UI (masked, replace-only), capability overrides (`supports_tools` auto/true/false), default/fallback chains.
- FE-ADMIN-03 [M] **Usage & cost dashboard**: tokens/cost by model/day/project/user, context % per chat, budget alerts, CSV export; "hide sensitive" demo mode (blur titles/emails/keys).
- FE-ADMIN-04 [M] Users & privileges matrix, invites, disable signup, forced 2FA, sessions list with revoke, API tokens (scoped, expiring, last-used), webhooks with delivery log and replay.
- FE-ADMIN-05 [M] Exec policy editor: per-agent allowlists/denylists with pattern tester, default approval modes per risk class, pending-approvals queue across all runs.
- FE-ADMIN-06 [M] Health & diagnostics: service status (DB, ChromaDB, SearXNG, ntfy, IMAP/SMTP, providers), degraded reasons with fix hints, log viewer (filter/search/tail), downloadable support bundle (secrets scrubbed).
- FE-ADMIN-07 [M] Audit log viewer with filters and export.
- FE-ADMIN-08 [M] Backup/restore UI for `data/` (create, download, verify checksum, restore with dry-run).
- FE-ADMIN-09 [M] Privacy controls: memory on/off, delete all data, export all data (GDPR-style), telemetry = none by default.

## 8. CROSS-CUTTING QUALITY (FE-QA)

- FE-QA-01 [M] **Design system** in Storybook: tokens (color, spacing, type, radii, elevation, motion), primitives (Button, IconButton, Input, Select, Combobox, Tabs, Dialog, Drawer, Popover, Tooltip, Toast, Menu, Table, Tree, Skeleton, Badge, Progress, Switch, Slider, Kbd), each with states, a11y notes, and visual baselines in light/dark.
- FE-QA-02 [M] Accessibility: landmarks, heading order, focus-visible, focus trapping in dialogs, `aria-live` for streaming (polite, throttled; do not announce every token), roving tabindex in lists/menus, 4.5:1 contrast, 44 px touch targets, reduced motion, high-contrast mode, zoom 200% without loss.
- FE-QA-03 [M] Performance budgets enforced in CI (bundle-size check, Lighthouse CI, long-task counter in Playwright), route-level code splitting, worker offloading for Markdown parse/highlight on large messages.
- FE-QA-04 [M] State architecture: server state in TanStack Query, run state only from `reduceRunState`, UI state in Zustand slices; no global mutable singletons; cross-tab sync via BroadcastChannel; every store has tests.
- FE-QA-05 [M] Resilience: error boundaries, retry with backoff + jitter, offline detection, request deduplication, optimistic updates with rollback, SSE reconnect with cursor, protection against double submit.
- FE-QA-06 [M] Security in the UI: CSP-compatible (no inline scripts/styles except hashed), sanitized rendering paths centralized in one module with tests (XSS corpus), no secrets in localStorage (use HttpOnly cookies / in-memory), clipboard & download safety.
- FE-QA-07 [M] Visual regression (Playwright screenshots) for all Storybook stories + key flows; flake budget < 1%.
- FE-QA-08 [M] Telemetry-free diagnostics: client error ring-buffer exportable via "Copy diagnostics" (no content, no secrets).
- FE-QA-09 [S] Docs-in-product: contextual help popovers, "What's new" changelog panel.

---

## STREAMING RENDERER — SPECIAL SPEC (read twice)

The streaming Markdown pipeline is the most failure-prone part of any AI UI. Required architecture:
1. Text deltas append to a per-part buffer in the run reducer.
2. A **block splitter** (fence/list/table-aware, tolerant of unterminated constructs) turns the buffer into stable blocks; completed blocks are **immutable and memoized** (keyed by content hash); only the trailing open block is re-parsed on each frame (coalesced with `requestAnimationFrame`, max 1 parse/frame).
3. Heavy work (highlight, KaTeX, Mermaid) is deferred until a block is closed, with instant plain fallback and in-place upgrade without layout jump (reserve height).
4. Property-based tests (fast-check): for any random chunking of a Markdown corpus, the final DOM equals the DOM of rendering the full text at once; no intermediate state throws; no block above the cursor ever changes after it closes.
5. Perf test: 120 tok/s for 60 s, 10 concurrent streams in one page → no long task > 50 ms, memory stable (no leaks after 20 runs).
