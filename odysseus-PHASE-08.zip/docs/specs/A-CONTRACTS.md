# A — CONTRACTS: Data Model, REST surface, and the Run Event Protocol

> Attach to Phases 02, 03, 04, 05 (and any phase that touches runs, messages, or tools). This is the **spine** of the product. The agent timeline, streaming UI, resumability, approvals, and artifacts all derive from it. Treat it as a versioned public API (`protocol_version: 1`). Changing it requires an ADR + migration + regenerated clients.

## 1. Core principle: durable runs, thin connections

An **agent run executes on the server, independent of any HTTP connection.** Every observable thing the run does is appended to a **durable, ordered event log** (`run_events`). Clients (browser tabs, mobile, CLI) *subscribe* to that log over SSE and may disconnect/reconnect at any time and resume from a cursor. Closing the tab does not stop a run; **Stop** does.

Consequences you must implement and test:
- Multiple tabs/devices watch the same run simultaneously.
- Reload mid-stream → UI reconstructs the exact state by replaying events from `seq=0` (or from a snapshot + cursor).
- Server restart mid-run → run is marked `interrupted`, is resumable ("Continue"), and no event is lost or duplicated.
- Event ordering is total per run (`seq` strictly increasing, gap-free).

## 2. Entities (logical; choose exact columns yourself, record in DECISIONS.md)

- `users`, `sessions`, `api_tokens`, `privileges` (per-user capability flags), `audit_log`
- `projects` (name, instructions, sources/files, default model, tools allowlist)
- `chats` (project_id?, title, pinned, archived, folder, model/preset, temporary flag, created/updated)
- `messages` — a **tree**: `id, chat_id, parent_id, role(user|assistant|system|tool), status(streaming|complete|aborted|error), parts[], model, usage, latency, created_at, branch_index`. The active path is `chats.active_leaf_id`. Edit-and-resubmit, regenerate, and "fork from here" all create sibling/child nodes — **never mutate history**.
- **Message parts** (typed, ordered): `text`, `thinking{signature?,duration_ms}`, `tool_call{id,name,args,status}`, `tool_result{call_id,output_ref,is_error}`, `image`, `file`, `citation{id,source,url,title,snippet,span}`, `artifact_ref{artifact_id,version}`, `plan{items[]}`, `notice` (system notices like "context compacted").
- `runs` (`id, chat_id, message_id, status, model, started/finished, budget{max_iters,max_tokens,max_cost,max_seconds}, usage_totals, parent_run_id` for sub-agents, `error`)
- `run_events` (`run_id, seq, ts, type, data(json)`) — append-only; index `(run_id, seq)`.
- `tool_calls` (`id, run_id, name, args, risk, policy_decision, approval_id?, started/finished, status, output_ref, output_bytes, truncated`) — large outputs stored as blobs on disk/DB, referenced by `output_ref`.
- `approvals` (`id, run_id, tool_call_id, requested_at, decided_at, decision(approve|deny), scope(once|run|chat|always), pattern?, decided_by`)
- `artifacts` + `artifact_versions` (type, title, content blob, created_by(run|user), parent_version, diff_summary)
- `attachments` (sha256-addressed blobs, mime, size, extracted_text_ref, scan_status)
- `memories` (scope user|project, text, source_chat, embedding_ref, pinned, created/updated), `skills`, `mcp_servers`, `jobs` (durable scheduler/background work), `schedules` (cron agent tasks), `usage_ledger` (tokens, cost, per message/run/provider/day).
- Domain tables for email, notes, todos, calendar, research, compare, gallery, cookbook jobs arrive in their phases.

## 3. REST surface (minimum; extend as needed, keep it consistent)

```
POST   /api/auth/login | /logout | /2fa/verify ;  GET /api/auth/me
GET    /api/chats?query=&project=&archived=      POST /api/chats
PATCH  /api/chats/{id}  (rename|pin|archive|move)   DELETE /api/chats/{id}
GET    /api/chats/{id}/tree                      # full message tree + active path
POST   /api/chats/{id}/messages                  # {parent_id, parts, model?, options{thinking,tools,web,agent}} -> {run_id,user_msg_id,assistant_msg_id}
POST   /api/messages/{id}/regenerate | /edit | /fork | /feedback
GET    /api/runs/{id}                            # snapshot (status, usage, pending approvals)
GET    /api/runs/{id}/events?after=<seq>         # SSE, resumable; honors Last-Event-ID
POST   /api/runs/{id}/cancel | /pause | /resume | /steer {text}
POST   /api/runs/{id}/approvals/{approval_id}    # {decision, scope, pattern?}
GET    /api/tool-calls/{id}/output?range=        # lazy, paginated big outputs
GET/POST/PATCH /api/artifacts/{id}[/versions]    GET /api/artifacts/{id}/versions/{n}
GET    /api/health/live | /ready | /degraded     GET /metrics (admin/internal)
POST   /api/uploads (resumable/tus-style or chunked) ; GET /api/attachments/{sha}
GET    /api/models | /api/providers (probe, capabilities: tools, vision, thinking, ctx window, cost)
GET    /api/usage?range=&group=                  # tokens, cost, per model/day
```

All mutating endpoints are idempotent where it matters (`Idempotency-Key` on message creation so double-click / retry never double-posts).

## 4. SSE framing

```
id: 128
event: tool.output.delta
data: {"seq":128,"run_id":"r_…","ts":"2026-…Z","type":"tool.output.delta","data":{…}}

```
- `id` = `seq`. Server sends `: keepalive` comments every 15 s. Supports `?after=` and `Last-Event-ID`.
- Backpressure: if a client lags beyond N events, send `stream.resync` with a snapshot cursor instead of dropping silently.
- Large deltas are chunked (≤ 8 KB/event). Tool stdout is coalesced at ≤ 20 events/s per call.

## 5. Event types (v1) — payloads are JSON-schema'd; generate TS types

**Run lifecycle:** `run.started{model,budget}`, `run.status{status}` (queued|running|paused|waiting_approval|interrupted), `run.finished{reason: completed|cancelled|error|budget_exceeded|max_iterations, usage}`, `run.error{code,message,retryable}`

**Iteration/steps:** `step.started{step_id,index,kind: model|tool|subagent|compaction}`, `step.finished{step_id,status,duration_ms}`

**Model output:** `message.part.started{message_id,part_id,type}`, `message.text.delta{part_id,text}`, `message.thinking.delta{part_id,text}`, `message.part.finished{part_id}`, `message.finished{message_id,stop_reason,usage}`

**Plan/todo (agent timeline backbone):** `plan.updated{items:[{id,title,status: pending|in_progress|done|skipped|failed}]}`

**Tools:** `tool.call.proposed{call_id,name,args,risk}`, `tool.approval.requested{approval_id,call_id,reason,suggested_pattern,expires_at?}`, `tool.approval.resolved{approval_id,decision,scope,by}`, `tool.started{call_id}`, `tool.output.delta{call_id,stream: stdout|stderr|log,text}`, `tool.progress{call_id,pct?,label}`, `tool.result{call_id,ok,summary,output_ref,truncated,duration_ms,render_hint}` where `render_hint ∈ text|json|table|diff|image|search_results|file_tree|terminal|browser_snapshot`, `tool.denied{call_id,reason}`

**Sub-agents:** `subagent.started{child_run_id,task}`, `subagent.finished{child_run_id,status,summary}` (child events are fetchable by `child_run_id` and nest in the UI)

**Knowledge:** `citation.added{citation}`, `source.opened{url,title}` (research/web), `memory.used{ids}`, `memory.updated{id,op}`

**Artifacts:** `artifact.created{artifact_id,type,title}`, `artifact.delta{artifact_id,version,text}` (live-streamed content), `artifact.version{artifact_id,version,summary}`

**Context & cost:** `usage.updated{input,output,cached,reasoning,cost,context_used,context_window}`, `context.compacted{removed_tokens,summary_ref}`, `notice{level,code,text}`

**Control:** `steer.received{text}`, `stream.resync{cursor}`, `stream.keepalive` (comment only)

Every event type has: a JSON schema, a Pydantic model, a generated TS type, a **golden fixture** in `contracts/fixtures/`, and a reducer test on the frontend (`reduceRunState(events) → RunViewState`). The frontend **only** derives UI from the reducer's state — no ad-hoc mutation from raw events.

## 6. Determinism & test support

- `FakeProvider` accepts a **script** (YAML/JSON): sequence of deltas with delays, thinking blocks, tool calls, malformed tool-call JSON, mid-stream disconnects, 429/5xx injections, very long outputs, unclosed Markdown fences, emoji/RTL/combining characters. All e2e tests use it; no test depends on a real model.
- `contracts/fixtures/` contains recorded event streams for: plain chat, long code answer, agent with 6 tools + approval, research run, sub-agent tree, cancelled run, error run, interrupted-and-resumed run. Frontend and backend both replay them.
