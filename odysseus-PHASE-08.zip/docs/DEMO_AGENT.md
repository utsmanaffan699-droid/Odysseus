# Odysseus Phase 05 — Agent Experience Walkthrough (`docs/DEMO_AGENT.md`)

This guide walks through a complete multi-step Odysseus agent task exercising the **Agent Timeline**, **Tool-Call Renderers**, **Deceptive Approval Guard**, **Artifacts / Canvas**, **Sub-Agents**, **Replay Scrubber**, and **Agent Hub**.

---

## 1. Prerequisites & Starting the Stack

```bash
# Start backend + frontend production bundle locally
cd frontend && npm run build && cd ..
uvicorn backend.app.main:app --host 0.0.0.0 --port 8000
```

Or run the automated E2E walkthrough directly:

```bash
python3 scripts/run_e2e.py
```

---

## 2. Step-by-Step Interactive Walkthrough (10 Steps)

1. **Sign In & Open a New Conversation**:
   - Open `http://127.0.0.1:8000` and sign in with `admin` (complete the first-run password change if prompted).
   - Click **`+ New Chat`** in the sidebar.

2. **Launch a 6-Tool Agent Run (`[FAKE_AGENT_6TOOLS]`)**:
   - In the composer, enter:
     ```text
     Run full workspace check [FAKE_AGENT_6TOOLS]
     ```
   - Press **Enter**.

3. **Inspect Live Pinned Plan, Memory Chips & Tool Renderers**:
   - Observe the **Pinned Plan Tracker** (`3/3` checklist items with progress badge) and **`Used 3 memories`** transparency chip (`FE-AGENT-03, 16`).
   - Expand any completed step card in the inline timeline to inspect specialized tool output renderers (`file_tree`, `text`, `search_results`, `diff`, `table`, and `terminal`).

4. **Review & Approve the Gated Shell Execution (`FE-AGENT-05`)**:
   - The 6th tool call (`run_shell`: `pytest -q tests/unit`) pauses in `waiting_approval` and surfaces both the inline **Approval Card** and the global **Pending Approvals Banner**.
   - After the **400 ms anti-clickjacking stability guard** unlocks the action buttons, click **`Approve Once`** (or press `Y` while the card is focused).
   - The run resumes, streams ANSI terminal output, and transitions to **`completed`**.

5. **Inspect Deceptive Command Normalization & Provenance (`FE-AGENT-18`, Adversarial 5.1 & 5.2)**:
   - Send:
     ```text
     Check deceptive command [FAKE_DECEPTIVE_APPROVAL]
     ```
   - Observe the **`Untrusted provenance: https://malicious-blog.example/post`** badge, the **`RTL_OVERRIDE · ZERO_WIDTH · HOMOGLYPH · MULTILINE · LONG_ARG`** spoof warning banner, and the **`hidden chars`** badge.
   - Click **`Expand all`** to inspect explicit `[RTL:U+202E]` and `[ZW:U+200B]` badges.
   - Click **`Always allow pattern…`**, enter `*`, and verify the validator rejects overly broad patterns.

6. **Stream & Edit an Artifact with User Lock (`FE-ART-01…06`)**:
   - Send:
     ```text
     Generate TypeScript module [FAKE_ARTIFACT_STREAM]
     ```
   - The **Artifacts / Canvas** side panel opens automatically (`agent_config.ts`).
   - Edit the code in the **Source** editor — notice the **`🔒 Locked by user edit`** badge (`FE-ART-04`) preventing incoming agent deltas from clobbering your cursor.
   - Click **`Save Version`** to create `v2`, then click **`Compare Diff`** to view the unified diff between `v1` and `v2`.

7. **Apply Tracked-Change AI Suggestions with Undo/Redo (`FE-ART-06`)**:
   - In the Artifacts toolbar, click **`✨ Improve`**.
   - Review the proposed diff hunks in the **AI Tracked-Change Suggestions** drawer and click **`Accept All`**.
   - Click **`↶ Undo`** and **`↷ Redo`** to step backward and forward through the versioned edit stack cleanly.

8. **Verify Sandboxed HTML/JS Micro-App Isolation (`FE-ART-03`)**:
   - Open the right-hand **Inspector** pane (`▥` button in the top bar) and click **`Open Sandboxed HTML Probe`**.
   - Verify the **`Sandboxed (allow-scripts)`** badge and inspect the **Sandbox Console** showing `cookie_access:blocked`, `parent_dom:blocked`, `local_storage:blocked`, and `network_fetch:blocked`.

9. **Scrub & Replay a Run Deterministically (`FE-AGENT-08, 09, 10`)**:
   - In the Inspector pane, click **`Load Sub-Agent Tree`** to view the nested `r_child_01` (`Audit dependencies`) and `r_child_02` (`Generate SBOM`) tree.
   - Click **`Replay Run`** to open the **Replay Scrubber**, drag the slider across events `1..5` (or play at `1x / 2x / 4x / 8x`), and verify the timeline reconstructs each historical state with **zero network calls**.
   - Click **`Load 2,000 Steps`** to verify smooth virtualized scrolling (`<= 60` DOM nodes) and **`Load 50 MB JSON`** to verify the capped JSON slice viewer.

10. **Manage Run History, Agent Presets & Exec Policies (`FE-AGENT-12, 13`, `FE-ADMIN-05`)**:
    - Click **`Agents & History`** in the top bar.
    - Create a custom preset (`Security Reviewer`) in **Agent Presets**, inspect past runs in **Run History**, and test `tool:run_shell:pytest*` against `pytest -q` in **Exec Policies**.
