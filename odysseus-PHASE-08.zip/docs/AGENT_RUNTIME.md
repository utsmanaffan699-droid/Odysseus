# Odysseus Agent Runtime (`backend/domain/agents`)

This document describes the Phase 03 Agent Engine architecture: the explicit state machine in `backend/domain/agents/loop.py`, dual tool-calling transports, bounded concurrency, context budgeting and reversible compaction, MCP client lifecycle, progressive-disclosure skills, and hybrid semantic + BM25 memory.

---

## 1. Agent State Machine & Deterministic Event Log

Each run executes an explicit, step-indexed state machine managed by `RunManager._execute_run` (`backend/domain/runs/manager.py`) and `execute_agent_tool_batch` (`backend/domain/agents/loop.py`):

```text
plan? ──► model_step ──► (tool_calls ──► policy ──► [approval] ──► execute ──► observe)* ──► finalize
```

1. **Step Boundaries (`step.started` / `step.finished`)**:
   - Every model iteration opens with `step.started(step_index, kind="model")` and closes with `step.finished(step_index, duration_ms)`.
   - Every tool batch opens with `step.started(step_index, kind="tool")` and closes with `step.finished(step_index, duration_ms)`.
   - Before each model step, the loop checks `ctrl.pause_event`, `ctrl.cancel_event`, and drains `ctrl.steer_queue` (injecting any user steering messages delimited with `<user_steer>`).
2. **Tool Call Lifecycle**:
   - `tool.call.started`: Emitted with normalized arguments, `risk`, and anti-spoofed `explain` text.
   - `tool.approval.requested` / `tool.approval.resolved`: Emitted when `ToolPolicyEngine.evaluate()` returns `ask`. In `interactive` mode, `run.status` transitions to `waiting_approval` before the `ApprovalRecord` becomes visible; in `background` mode, expiry or absence of interactive approver auto-denies (`deny`).
   - `tool.output.delta`: Coalesced (`<= 20` events/s) live stdout/stderr stream from `shell` and `python`.
   - `tool.result` or `tool.denied`: Terminal tool event with `output_ref` pointing to `data/tool_outputs/{call_id}.txt`.
3. **Finalization**:
   - Assistant Markdown output passes through `sanitize_assistant_markdown_exfiltration` (blocking external image beacons and secret-bearing URLs) before `message.finished` and `run.finished`.

---

## 2. Dual Tool-Calling Transports

Selected automatically from `ModelCapabilities` (`backend/providers/capabilities.py`):

1. **Native Structured Tool Calls (`supports_tools=True`, `prefer_fenced_tool_calls=False`)**:
   - Passes JSON Schema definitions via `ProviderChatRequest.tools` and parses streamed `ProviderStreamDelta(kind="tool_call_delta")`.
2. **Text-Fenced Tool Calls (`prefer_fenced_tool_calls=True` or weak local models)**:
   - Injects compact ```tool_call fence instructions via `render_fenced_tool_system_instructions()`.
   - Parses assistant text via `parse_fenced_tool_calls()` (`backend/domain/agents/fenced_parser.py`), which tolerates single quotes, trailing commas, unquoted keys, Python `True`/`False`/`None`, and nested fences, and is Hypothesis-fuzzed over `>= 10,000` random inputs without raising unhandled exceptions.
   - If a fenced block is malformed, the loop performs **at most 1 cheap repair re-ask** (`build_repair_reask_prompt`) before surfacing a structured error.

---

## 3. Concurrency & Loop Safety Guards

- **Bounded Parallel Read vs. Serialized Write/Exec**:
  - When a model emits multiple tool calls in a single turn, `execute_agent_tool_batch` partitions them:
    - Independent `read` (and idempotent `network`) tools execute concurrently under `asyncio.Semaphore(max_parallel_read_tools)` (default `4`).
    - Any `write`, `exec`, or `admin` tool executes strictly serially (`1` at a time) in declaration order.
- **Loop Safety**:
  - **Iteration Cap**: `settings.agent_max_steps` (default `12`).
  - **Repeated-Identical-Call Detection**: Signatures `(tool_name, canonical_json(args))` are tracked across steps. On the 2nd identical call, a system nudge is injected (`[Loop Guard] You already invoked ...`); on the 3rd identical call (`repeat_limit=3`), the loop aborts tool execution and forces a graceful `"I'm stuck"` summary response.
  - **Budget Enforcement**: Token and USD cost budgets are checked after every step; exceeding budget terminates the run with `reason="budget_exceeded"`.

---

## 4. Sub-Agents (`spawn_agent`)

- `spawn_agent(task, preset, max_steps, budget_tokens)` creates a child `RunRecord` with `parent_run_id` set to the parent's `run_id`.
- **Safety Bounds**:
  - Recursion depth is capped at `settings.agent_max_subagent_depth` (default `2`).
  - Per-run fan-out is capped at `settings.agent_max_subagent_fanout` (default `3`).
  - Child tool set excludes `spawn_agent`, `shell`, and `python` unless explicitly permitted by preset, and child token budget is clamped to `min(requested, parent_remaining // 2)`.
  - Emits `subagent.started` and `subagent.finished(child_run_id, status, summary)` on the parent stream and returns only the concise summary to the parent's context window.

---

## 5. Context Management & Reversible Compaction (`ContextBudgeter`)

`ContextBudgeter` (`backend/domain/agents/context.py`) enforces token budgets across 5 tested profiles (`4k`, `8k`, `16k`, `32k`, `large`):

1. **Dynamic Top-K Tool Selection**:
   - Always includes the core tool set (`read_file`, `write_file`, `edit_file`, `list_dir`, `web_search`, `fetch_url`, `memory_search`, `read_tool_output`, `discover_tools`) and scores remaining tools by lexical overlap with the active user query, capping total schemas at `profile.top_k_tools` (e.g., `6` tools on `4k`).
2. **Reversible History Compaction (`context.compacted`)**:
   - When conversation history exceeds `profile.history_budget`, older turns are compacted into a structured `<compacted_history_memo>` while keeping the most recent `preserve_recent_messages` verbatim.
   - Lines matching key technical identifiers (`_FACT_LINE_RE`: URLs, file paths, port numbers, error codes, `KEY=VALUE` constraints, and needle facts) are prioritized so critical facts survive even `3x` window overflow.
   - Every tool output is persisted in full to `data/tool_outputs/{call_id}.txt` so the agent can always inspect omitted ranges via `read_tool_output(call_id, offset, length)`.

---

## 6. MCP Client Manager, Skills & Memory

- **MCP (`backend/mcp/manager.py`)**:
  - Supports `stdio`, `sse`, and `streamable_http` transports (`mcp<2` JSON-RPC 2.0 protocol).
  - Includes bundled workspace-jailed `filesystem_server.py` and SSRF-safe `fetch_server.py` (`backend/mcp/bundled/`).
  - Unknown MCP tools default to `risk="exec"` (`ask` approval), descriptions are stripped of prompt-injection directives and capped at `400` chars, outputs are tagged `untrusted`, and crashed `stdio` subprocesses auto-restart with exponential backoff during `check_health_and_restart()`.
- **Skills (`backend/domain/skills/service.py`)**:
  - Markdown files with YAML frontmatter (`name`, `description`, `when_to_use`, `requires`, `tools`, `version`).
  - Progressive disclosure: only `name + description + when_to_use` is injected into the system prompt index; full body is loaded on demand via `load_skill(name)`.
  - Skills imported from `.zip` archives or URLs are marked `untrusted=True` (`review_required=True`) and cannot auto-activate until reviewed.
- **Memory (`backend/domain/memory/service.py`)**:
  - Hybrid semantic vector similarity (384-d local hash/fastembed embeddings + ChromaDB) combined with Okapi BM25 lexical scoring.
  - If ChromaDB is unreachable or corrupted, `probe_chromadb()` records the degradation reason on `/api/health/degraded` and seamlessly falls back to local BM25 + cosine similarity in SQLite/PostgreSQL.
  - **Single Hard Privacy Switch (`memory_enabled`)**: Checked in `_enforce_privacy_gate()` before every read, write, search, and extraction method.
