# Odysseus Run Event Protocol v1 (`docs/PROTOCOL.md`)

Odysseus uses a single-writer, append-only, replayable event log (`run_events`) as the source of truth for all streaming LLM and agent runs.

---

## 1. Envelope Schema (`v: 1`)

Every persisted and streamed event conforms to `RunEventEnvelope` (`contracts/event-schema.json`):

```json
{
  "v": 1,
  "run_id": "run_0000000000000001",
  "seq": 5,
  "ts": "2026-01-01T00:00:05Z",
  "type": "message.text.delta",
  "data": {
    "part_id": "part_msg_001_text",
    "text": "Hello from Odysseus!"
  }
}
```

### Invariants
- **Single Writer (`RunManager.append_event`)**: All writes to `run_events` for a given `run_id` are serialized via a per-run lock and committed transactionally before being broadcast to in-process pub/sub subscribers.
- **Gap-Free Monotonic `seq`**: Sequence numbers start at `1` and increment by `1` with `UNIQUE(run_id, seq)` enforced at the database level.
- **Strict Payload Validation**: All 35 v1 event types (`run.*`, `step.*`, `message.*`, `tool.*`, `subagent.*`, `memory.*`, `citation.added`, `artifact.created`, `usage.updated`, `notice`, `stream.resync`) are validated with Pydantic `extra="forbid"` before persistence.

---

## 2. SSE Transport (`GET /api/runs/{id}/events`)

### Headers
- `Content-Type: text/event-stream; charset=utf-8`
- `Cache-Control: no-cache, no-transform`
- `Connection: keep-alive`
- `X-Accel-Buffering: no`

### Frame Format
```text
id: 5
event: message.text.delta
data: {"v":1,"run_id":"run_001","seq":5,"ts":"2026-01-01T00:00:05Z","type":"message.text.delta","data":{"part_id":"part_1","text":"Hello"}}

```

### Keepalives, Chunking, and Coalescing
- **Keepalive comments**: `: keepalive\n\n` emitted every 15 seconds when idle.
- **Delta chunking**: Individual `message.text.delta` and `message.thinking.delta` chunks are split on UTF-8 character boundaries to `<= 8 KB` (`sse_max_chunk_bytes`).
- **Coalescing**: High-frequency provider token bursts are coalesced across a configurable window (`delta_coalesce_interval_ms`, default 20 ms) before committing to `run_events` so 5,000 deltas/sec floods cannot starve the event loop or database.

---

## 3. Reconnection & Slow-Reader Backpressure

### Cursor Resumption (`?after=<seq>` & `Last-Event-ID`)
- Clients may pass either `?after=<seq>` or the standard `Last-Event-ID: <seq>` HTTP header.
- On connect, `RunManager.stream_sse` replays all committed `run_events` with `seq > cursor` in ascending order, then seamlessly switches to the live pub/sub queue without gaps or duplicate frames.

### Bounded Subscriber Queues & `stream.resync`
- Each SSE subscriber has a bounded in-memory queue (`sse_subscriber_queue_size`).
- If a slow reader falls behind by more than `sse_max_lag_events`, its queue is drained and a `stream.resync` event (`{"cursor": <last_delivered_seq>}`) is emitted, instructing the client to re-fetch missed frames from durable storage while keeping server RSS bounded.
- Per-user concurrent SSE streams are capped by `max_sse_connections_per_user` (HTTP 429 on excess).

---

## 4. Run Lifecycle, Controls, and Crash Recovery

- **Status Values**: `queued`, `running`, `paused`, `waiting_approval`, `interrupted`, `succeeded`, `failed`, `cancelled`.
- **Cancel (`POST /api/runs/{id}/cancel`)**: Signals cooperative cancellation, closes the upstream provider stream immediately, saves any partial assistant text with `status="aborted"`, and appends `message.finished{stop_reason: "cancelled"}` + `run.finished{reason: "cancelled"}`.
- **Pause / Resume (`POST /api/runs/{id}/pause`, `/resume`)**: Suspends execution at the next safe checkpoint (`run.status{status: "paused"}`) and resumes on `/resume`.
- **Steer (`POST /api/runs/{id}/steer`)**: Queues user guidance (`steer.received`) injected into the next model step.
- **Crash Recovery**: On boot, `JobSupervisor.recover_interrupted_work()` transitions any `running` or `waiting_approval` runs to `interrupted` and appends `run.status{status: "interrupted"}`. Calling `POST /api/runs/{id}/resume` reconstructs prior state via `reduce_run_state` and resumes without duplicating already-emitted text.
