# Odysseus Email Architecture (`backend/domain/mail`)

## 1. Accounts, TLS Enforcement & OAuth / XOAUTH2
- **Vault Credential Isolation**: Account passwords and OAuth refresh/access tokens are committed to the vault and never serialized in API responses (`secret_masked: "••••••••"`) or logs.
- **Plaintext-over-Non-TLS Rejection**: Non-loopback IMAP/SMTP servers with `use_tls=False` are rejected with status `tls_required` and actionable fix hint: `"Plaintext auth disallowed — enable TLS (IMAPS 993 / STARTTLS)"`.
- **Gmail OAuth 2.0 (`build_gmail_oauth_url`)**: Resolves redirect URI from `GOOGLE_OAUTH_REDIRECT_URI` or the active request origin (`/api/mail/oauth/google/callback`).
- **Microsoft 365 / Outlook OAuth 2.0 (`build_m365_oauth_url`, `build_xoauth2_sasl_string`)**: Implements RFC 7628 / Microsoft `XOAUTH2` SASL framing (`base64("user=" + email + "\x01auth=Bearer " + token + "\x01\x01")`).

## 2. Sync Engine (`UIDVALIDITY` / `UIDNEXT` / `MODSEQ` & IMAP IDLE)
- **Bounded-Memory 20k+ Sync**: Stores compact header tuples `(msg_id, subject, sender, date_iso, unread, modseq)` in streaming batches (`batch_size=500`), keeping peak memory delta `< 50 MB` for 20,000+ message mailboxes while materializing full bodies and attachments lazily.
- **`UIDVALIDITY` Reset Handling**: When a folder's remote `UIDVALIDITY` changes, all cached messages for that folder are invalidated before resyncing, preventing duplicate or stale UID collisions.
- **IMAP IDLE Push**: Subscribed queues receive real-time new-message push events in `< 3 s`.

## 3. Safe HTML Sanitization (`nh3`) & Tracking Pixel Defense
- Uses `nh3.clean` with a strict tag/attribute allowlist after stripping `<script>`, `<style>`, `<svg>`, `<form>`, `<input>`, `<meta>`, `<base>`, and `<iframe>` blocks.
- **Remote Images Blocked by Default**: External `http://` and `https://` `<img src>` URLs are rewritten to `about:blank#blocked-remote-image` with `data-blocked-remote-src` until the user explicitly allows the sender.
- **`cid:` Inline Attachment Verification**: Only `cid:` keys present in the message's verified `allowed_cid_map` are resolved; unmapped or anchor `cid:` URLs are blocked.
- **Unicode / IDN Homograph & Link Spoofing Detection**: Punycode (`xn--`), mixed-script Cyrillic/Greek/Latin hostnames, BiDi overrides, `@` userinfo tricks, and visible-URL mismatches are rewritten to `about:blank#blocked-spoofed-link`.
- **Sandboxed Rendering**: The frontend renders sanitized HTML inside `<iframe sandbox="" srcDoc={...}>`.

## 4. Idempotent Outbox & Human-Supervised AI Triage
- **Idempotent Send Queue (`OutboxEntry`)**: Deduplicates outgoing messages by `idempotency_key` and `Message-ID` across SMTP timeouts after `DATA` and offline-to-online outbox flushes, guaranteeing at-most-once delivery.
- **Undo-Send Window**: Configurable `undo_window_seconds` allows cancelling a pending send and restoring it to `Drafts`.
- **Supervised AI Triage (`triage_message`)**: Classifies urgency/tags/spam, extracts dates/tasks, and creates a draft reply (`suggest_only=True` by default, **never auto-sends**). Untrusted emails taint the run context (`source="email:<sender>"`) so any downstream write/exec tool call requires explicit user approval.

## 5. Slow Mail Latency Benchmark (`scripts/bench_mail.py`)
| Simulated RTT (ms) | Adaptive Batch | Operation | p50 (ms) | p95 (ms) | Budget (ms) | UI Stalls |
|---:|---:|---|---:|---:|---:|---:|
| 50 | 50 | `open_mailbox` | 19.03 | 19.65 | 100.00 | 0 |
| 50 | 50 | `open_message` | 22.53 | 22.57 | 100.00 | 0 |
| 50 | 50 | `search` | 12.52 | 12.53 | 100.00 | 0 |
| 50 | 50 | `delete` | 15.00 | 15.01 | 100.00 | 0 |
| 50 | 50 | `send` | 42.53 | 42.55 | 100.00 | 0 |
| 200 | 25 | `open_mailbox` | 70.95 | 71.10 | 325.00 | 0 |
| 200 | 25 | `open_message` | 90.04 | 90.04 | 325.00 | 0 |
| 200 | 25 | `search` | 50.02 | 50.03 | 325.00 | 0 |
| 200 | 25 | `delete` | 60.00 | 60.01 | 325.00 | 0 |
| 200 | 25 | `send` | 170.03 | 170.06 | 325.00 | 0 |
| 800 | 10 | `open_mailbox` | 280.49 | 280.61 | 1225.00 | 0 |
| 800 | 10 | `open_message` | 360.03 | 360.05 | 1225.00 | 0 |
| 800 | 10 | `search` | 200.02 | 200.05 | 1225.00 | 0 |
| 800 | 10 | `delete` | 240.00 | 240.00 | 1225.00 | 0 |
| 800 | 10 | `send` | 680.03 | 680.04 | 1225.00 | 0 |
