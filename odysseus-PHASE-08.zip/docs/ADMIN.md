# Odysseus Operator & Admin Console Guide (`docs/ADMIN.md`)

## 1. Clean VM Installation & First Boot
1. Copy `.env.example` to `.env` and set `ODYSSEUS_SECRET_KEY` (`>= 32` chars).
2. Start the stack: `docker compose up -d` (or `make dev` for bare-metal development).
3. Read the one-time bootstrap admin password from stdout or `data/.bootstrap_admin` and sign in at `http://localhost:8000`.
4. Complete the forced password change and optional TOTP 2FA enrollment.

## 2. Adding a Local Model & Serving via Cookbook (`FE-WORK-09`)
1. Open **Cookbook & Hardware Advisor** from the sidebar (`workspace-nav-cookbook`).
2. Click **Refresh Hardware Scan** (`GET /api/cookbook/hardware`, `POST /api/cookbook/hardware/refresh`). If running inside Docker without GPU passthrough, copy the displayed overlay command (`docker compose -f docker-compose.yml -f docker/gpu.nvidia.yml up -d`).
3. Browse ranked models with the **Fit Meter** (`yes` / `tight` / `no`). Click **Download** (`POST /api/cookbook/downloads`) and monitor byte-range progress and SHA-256 verification.
4. Click **Install Engine** (`POST /api/cookbook/engines/llama.cpp/install`) to verify and link the prebuilt `llama.cpp` binary (`data/local/engines/llama.cpp/current`).
5. Click **Serve & Use in Chat** (`POST /api/cookbook/serve`). Once the readiness completion probe succeeds, the model is automatically registered in **Providers** and deregistered when stopped (`POST /api/cookbook/serve/{id}/stop`).

## 3. Enabling HTTPS
- Place TLS certificates in `certs/` or configure Caddy/Nginx reverse proxy with `ODYSSEUS_SESSION_COOKIE_SECURE=true` and `ODYSSEUS_TRUSTED_PROXIES`.

## 4. Backups, Restore & Upgrades (`FE-ADMIN-08`)
- See `website/backup-restore.md` for creating consistent snapshots (`POST /api/admin/backups`), running a **Restore Dry-Run** (`POST /api/admin/backups/{id}/restore` with `dry_run=true`), and restoring into a clean instance.
- Before upgrading Odysseus, create a verified backup, pull the new release image/tag, and start the service (Alembic migrations run automatically with advisory locking).
