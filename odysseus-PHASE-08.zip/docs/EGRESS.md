# Network Egress Audit (`docs/EGRESS.md`)

Per Phase 08 §6 Self-Review Gate, every network egress call site in Odysseus is enumerated and justified below. When offline mode is enabled or egress is blocked at the network layer, Odysseus boots cleanly and serves local chats with **zero** unsolicited external requests.

| Module & Function | Destination | Trigger | Offline Behavior & Safeguards |
|---|---|---|---|
| `backend/domain/cookbook/service.py::search_hf_models` | `huggingface.co` (optional) | Operator searches HF Hub in Cookbook | Uses cached `cookbook_models` metadata when offline or when `offline_mode=True`; never called at boot. |
| `backend/domain/cookbook/service.py::start_download` | `huggingface.co` / configured artifact mirror | Operator explicitly clicks "Download Model" | Resumable byte-range fetch; never runs without explicit admin action. |
| `backend/domain/cookbook/service.py::probe_serve_health` | `http://127.0.0.1:<port>/v1/chat/completions` | Local loopback readiness probe for managed `llama.cpp` / `vllm` instance | Strictly loopback (`127.0.0.1`). |
| `backend/domain/cookbook/service.py::execute_remote_template` | Operator-configured SSH host (`port 22`) | Operator runs allowlisted remote GPU probe/serve | TOFU fingerprint verified + `0600` ED25519 key; zero password/agent forwarding. |
| `backend/domain/gallery/service.py::generate_image` | Configured local ComfyUI / OpenAI-compatible image endpoint | User submits image generation prompt | Uses deterministic local generator when offline. |
| `backend/domain/voice/service.py` | Configured local `faster-whisper` / `Kokoro` or OpenAI-compatible audio endpoint | User invokes STT/TTS | Falls back to local synthesis / browser Web Speech API; zero boot-time egress. |
| `backend/domain/tools/web_tools.py` | Internal SearXNG / user-requested `fetch_url` | Agent tool call | Guarded by `SSRFSafeHttpFetcher` (`validate_url_against_ssrf`). |
| `backend/domain/notifications/service.py` | Operator-configured outbound webhook / ntfy URL | Event notification | Guarded by `validate_ssrf_safe_url` at both registration and delivery time. |

**Telemetry Policy**: Odysseus contains **zero** analytics, crash-reporting, phone-home, or version-check beacons.
