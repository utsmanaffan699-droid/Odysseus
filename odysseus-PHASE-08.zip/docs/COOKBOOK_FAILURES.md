# Odysseus Cookbook Classified Failure Catalog (`docs/COOKBOOK_FAILURES.md`)

Every failed Cookbook operation produces a `FailureReport` mapped against these 32 ordered heuristic/regex rules:

| # | Cause Code | Pattern / Trigger | Concrete Remedy Steps |
|---:|---|---|---|
| 1 | `cuda_not_found` | `libcudart.so` / `CUDA runtime not found` | Install NVIDIA CUDA Toolkit 12.x or select the `cpu` / `vulkan` prebuilt engine binary. |
| 2 | `driver_runtime_mismatch` | `CUDA driver version is insufficient for CUDA runtime` | Upgrade host NVIDIA driver (`>= 550.54`) or select an older CUDA 11.8 compatible wheel. |
| 3 | `gpu_no_container_passthrough` | `/dev/nvidia0 missing` while host GPU detected | Restart container with `docker compose -f docker-compose.yml -f docker/gpu.nvidia.yml up -d` (`--gpus all`). |
| 4 | `vram_oom_at_load` | `cudaMalloc failed: out of memory` / `ggml_backend_cuda_buffer_type_alloc_buffer` | Lower `-ngl` (GPU layers), reduce context `-c` to `4096`, or pick a smaller quantization (`Q4_K_M`). |
| 5 | `mmproj_missing` | `mmproj file required for vision model` | Download the companion `mmproj-model-f16.gguf` file via Cookbook before serving with vision enabled. |
| 6 | `chat_template_error` | `TemplateSyntaxError` / `SecurityError` in Jinja chat template | Override with the standard ChatML or Llama-3 safe template in Model Settings. |
| 7 | `hf_gated_repo_401` | `401 Unauthorized` / `Access to model ... is restricted` | Add a valid Hugging Face token (`hf_...`) in Key Vault and accept the model license on huggingface.co. |
| 8 | `hf_gated_repo_403` | `403 Forbidden: GatedRepoError` | Accept the upstream repository license agreement on Hugging Face with the configured account. |
| 9 | `disk_full` | `No space left on device` / `ENOSPC` | Free disk space in `data/local/models` or prune unused GGUF quantizations. |
| 10 | `checksum_mismatch` | `sha256 mismatch` / `expected ... got ...` | Quarantine corrupted file and click "Retry & Re-verify Download". |
| 11 | `port_in_use` | `Address already in use` / `EADDRINUSE` | Stop the conflicting serve instance or allow Cookbook to auto-assign the next free port (`11435+`). |
| 12 | `tmux_missing` | `tmux: command not found` | Install `tmux` (`apt-get install -y tmux`) or switch session supervisor to direct POSIX process group mode. |
| 13 | `windows_long_path` | ` WinError 206` / `The filename or extension is too long` | Enable Windows `LongPathsEnabled` in registry or move `ODYSSEUS_DATA_DIR` closer to drive root (`C:\odysseus`). |
| 14 | `rocm_gfx_unsupported` | `HSA_STATUS_ERROR_INVALID_ISA` / `Unsupported gfx` | Set `HSA_OVERRIDE_GFX_VERSION=10.3.0` (or matching RDNA architecture) in serve preset environment. |
| 15 | `wheel_abi_mismatch` | `undefined symbol` / `is not a supported wheel on this platform` | Rebuild the engine virtualenv using the pinned Python 3.11–3.13 wheel matrix. |
| 16 | `ssl_interception_proxy` | `CERTIFICATE_VERIFY_FAILED` / `self-signed certificate in certificate chain` | Configure `REQUESTS_CA_BUNDLE` / `SSL_CERT_FILE` with your corporate root CA certificate. |
| 17 | `hf_rate_limit_429` | `429 Too Many Requests` from `huggingface.co` | Configure a Hugging Face API token in Vault to raise rate limits and wait for automatic backoff retry. |
| 18 | `partial_lfs_pointer` | `version https://git-lfs.github.com/spec/v1` found instead of binary weights | Re-fetch via the resolved LFS media URL rather than the raw Git pointer endpoint. |
| 19 | `windows_symlink_privilege` | `WinError 1314: A required privilege is not held by the client` | Enable Windows Developer Mode or allow Cookbook to fall back to directory junction / atomic rename. |
| 20 | `antivirus_file_lock` | `PermissionError: [WinError 32] The process cannot access the file` | Exclude `data/local/engines` and `data/local/models` from real-time antivirus scanning. |
| 21 | `host_oom_killer_sigkill` | `exit_code=-9` / `Killed` / `Out of memory: Killed process` | System RAM exhausted; reduce `--ctx-size`, enable `--no-mmap`, or pick a smaller parameter count. |
| 22 | `cpu_illegal_instruction` | `exit_code=-4` / `SIGILL` / `Illegal instruction (core dumped)` | Host CPU lacks AVX2/AVX-512; install the `cpu-baseline` (SSE4.2/NEON) llama.cpp binary variant. |
| 23 | `ssh_host_key_changed` | `REMOTE HOST IDENTIFICATION HAS CHANGED` / `host_key_changed_hard_stop` | Verify with the server operator whether the host was reinstalled before resetting the pinned TOFU fingerprint. |
| 24 | `ssh_key_permissions_too_open` | `Permissions 0644 for '.../id_ed25519' are too open` | Fix key permissions to `chmod 0600 data/ssh/id_ed25519`. |
| 25 | `ssh_connection_timeout` | `Connection timed out` / `Operation timed out` on port 22 | Verify remote host IP, firewall rules, and `sshd` status. |
| 26 | `speculative_draft_tokenizer_mismatch` | `draft model vocabulary size mismatch` | Select a draft model from the exact same tokenizer family (e.g. `Qwen2.5-0.5B` for `Qwen2.5-32B`). |
| 27 | `vulkan_icd_missing` | `vkCreateInstance failed` / `ERROR_INCOMPATIBLE_DRIVER` | Install `mesa-vulkan-drivers` / vendor Vulkan ICD loader or switch backend to `cpu`. |
| 28 | `apple_metal_unsupported_arch` | `MTLCompilerService` / `Metal not supported on Intel Mac` | Use the `cpu` build on Intel macOS; Metal acceleration requires Apple Silicon (M1/M2/M3/M4). |
| 29 | `gguf_magic_corrupt` | `invalid magic` / `bad GGUF header` | File is truncated or not a valid GGUF v3 model; delete and re-download. |
| 30 | `vllm_nccl_p2p_failure` | `NCCL WARN P2P is disabled` / `ncclUnhandledCudaError` | Add `NCCL_P2P_DISABLE=1` on consumer multi-GPU setups without NVLink or PCIe ACS disabled. |
| 31 | `nvidia_smi_timeout` | `nvidia-smi timed out after 5s` | Kernel NVIDIA driver is wedged; check `dmesg` for Xid errors and reboot host GPU node. |
| 32 | `serve_crash_loop` | `Instance crashed 3 times within 5 minutes` | Inspect the attached stderr tail and lower GPU layer offload or context length before restarting. |
