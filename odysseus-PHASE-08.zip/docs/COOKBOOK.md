# Odysseus Cookbook & Local Model Hardware Advisor (`docs/COOKBOOK.md`)

## 1. Domain Model & Database Tables

| Table | Purpose | Key Columns |
|---|---|---|
| `hw_snapshots` | Persisted hardware & container passthrough scans | `id`, `cpu_model`, `cpu_cores`, `cpu_threads`, `isa_flags_json`, `ram_total_mb`, `ram_avail_mb`, `swap_total_mb`, `disk_free_gb`, `gpus_json`, `backend_recommended`, `passthrough_status`, `passthrough_remedy`, `created_at` |
| `cookbook_models` | Cached Hugging Face Hub & GGUF metadata | `model_id`, `author`, `architecture`, `params_b`, `layers`, `kv_heads`, `head_dim`, `context_length`, `quant`, `weights_bytes`, `mmproj_bytes`, `supports_tools`, `supports_vision`, `license`, `gated`, `chat_template`, `etag`, `updated_at` |
| `downloads` | Resumable multi-file model downloads | `id`, `model_id`, `quant`, `state`, `total_bytes`, `downloaded_bytes`, `eta_seconds`, `speed_bps`, `failure_report_json`, `created_at`, `updated_at` |
| `download_files` | Per-file byte-range & SHA-256 verification state | `id`, `download_id`, `filename`, `size_bytes`, `downloaded_bytes`, `sha256_expected`, `sha256_actual`, `etag`, `verified`, `quarantined_path` |
| `engines` | Supported inference engines (`llama.cpp`, `vllm`, `sglang`, `ollama`) | `name`, `display_name`, `supported_backends_json`, `pinned_version`, `current_version`, `installed_path` |
| `engine_installs` | Engine installation job history & atomic swap state | `id`, `engine_name`, `version`, `backend_variant`, `state`, `checksum_sha256`, `install_dir`, `failure_report_json`, `created_at` |
| `serve_instances` | Managed model serving processes | `id`, `model_id`, `engine_name`, `port`, `pid`, `session_name`, `state`, `preset_json`, `vram_estimated_mb`, `provider_id`, `crash_count`, `last_health_at`, `failure_report_json` |
| `remote_hosts` | SSH remote GPU servers with TOFU host-key pinning | `id`, `name`, `hostname`, `port`, `username`, `ssh_key_path`, `pinned_fingerprint`, `tofu_confirmed`, `status`, `hw_snapshot_json` |
| `bench_results` | Local & remote throughput/latency benchmarks | `id`, `model_id`, `engine_name`, `hw_snapshot_id`, `context_size`, `ttft_ms`, `tokens_per_sec`, `vram_peak_mb`, `created_at` |
| `cookbook_jobs` | Durable job state transitions | `id`, `kind`, `target_id`, `state`, `progress_pct`, `created_at`, `updated_at` |
| `job_logs` | Rotating structured stdout/stderr lines | `id`, `job_id`, `seq`, `stream`, `line`, `created_at` |

---

## 2. Explicit Durable State Machines

Every external operation is governed by a deterministic state machine that persists every transition and emits SSE events:

1. **Download State Machine**:
   `queued → preflight → downloading(file k/n) → verifying → ready`
   - Terminal / side states: `paused`, `failed(cause)`, `cancelled`.
   - Resumable by HTTP `Range: bytes=<offset>-`; idempotent on restart (verified files are never re-downloaded).
2. **Engine Install State Machine**:
   `queued → preflight → fetching → verifying(checksum) → extracting|building → smoke_test → installed`
   - On `failed(cause)`, the previous `data/local/engines/<name>/current` symlink remains untouched (atomic swap).
3. **Serve State Machine**:
   `requested → preflight → starting → loading(model) → healthy → (idle_stopping) → stopped`
   - Error states: `crash_loop`, `failed(cause)`.
   - `healthy` requires a real tiny completion response from `/v1/chat/completions`, not merely an open TCP socket.
   - Auto-registers the healthy instance in `ProviderRegistry` and deregisters it on `stopped` or `crash_loop`.
4. **Remote SSH State Machine**:
   Executes the identical state transitions over SSH using allowlisted command templates after verifying `0600` ED25519 private key permissions and TOFU host-key fingerprint pinning.

---

## 3. Memory-Fit Math & Ranking Weights

### 3.1 Memory-Fit Formula (`calculate_model_memory_fit`)
$$\text{Total Bytes} = \text{Weights}_{\text{quant}} + \underbrace{2 \times L \times H_{kv} \times D_{head} \times C \times B_{kv}}_{\text{KV Cache Bytes}} + \text{Overhead}_{\text{backend}} + \text{Vision}_{\text{mmproj}}$$
- `fits = "yes"` when $\text{Total Bytes} \le 0.85 \times \text{Available Budget}$.
- `fits = "tight"` when $0.85 < \text{Total Bytes} / \text{Available Budget} \le 0.96$.
- `fits = "no"` when $\text{Total Bytes} > 0.96 \times \text{Available Budget}$.
- Roofline token throughput estimate: $\text{tok/s} \approx \eta \cdot \frac{\text{Memory Bandwidth (GB/s)}}{\text{Bytes per Token}}$.

### 3.2 Ranking Weights (`RANKING_WEIGHTS_V1`)
- `fit_headroom`: `0.30`
- `quant_quality_prior`: `0.22` (`FP16=1.00`, `Q8_0=0.96`, `Q6_K=0.91`, `Q5_K_M=0.86`, `Q4_K_M=0.80`, `AWQ_4BIT=0.79`, `GPTQ_4BIT=0.77`, `IQ3_XXS=0.62`, `Q2_K=0.45`)
- `tool_calling_reliability`: `0.18`
- `architecture_recency`: `0.12`
- `backend_compatibility`: `0.10`
- `measured_benchmark_boost`: `0.05`
- `popularity_log`: `0.03`
