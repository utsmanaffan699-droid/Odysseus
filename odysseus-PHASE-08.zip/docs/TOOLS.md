# Odysseus Tool Framework (`backend/tools`)

Odysseus provides a capability-driven, policy-enforced tool framework in `backend/domain/tools/` (re-exported at `backend/tools/`). Every tool declaration is a strongly-typed `ToolDefinition` with a Pydantic v2 input model, risk classification, required privilege, output rendering hint, timeout, output size cap, idempotency semantics, and a spoofing-hardened `explain(args)` summary generator.

---

## 1. Risk Taxonomy & Privilege Requirements

| Risk Class | Required Privilege | Default Mode | Execution Concurrency | Examples |
| :--- | :--- | :--- | :--- | :--- |
| `read` | `chat` | `auto` | Parallel batch (`max_parallel=4`) | `read_file`, `list_dir`, `glob`, `grep`, `memory_search`, `load_skill`, `update_plan`, `read_tool_output`, `discover_tools` |
| `network` | `tools.net` | `auto` (read) / `ask` (tainted) | Parallel if idempotent | `web_search`, `fetch_url`, `youtube_transcript` |
| `write` | `tools.fs.write` | `ask` | Serialized (1 at a time) | `write_file`, `edit_file`, `memory_save`, `create_artifact`, `update_artifact` |
| `exec` | `tools.exec` (Admin) | `ask` | Serialized (1 at a time) | `shell`, `python`, `spawn_agent`, unknown MCP tools |
| `admin` | `admin` | `ask` | Serialized (1 at a time) | Administrative system mutations |

Non-admin users are **hard-denied** (`deny`) for `exec` and `admin` tools regardless of preset or saved approval rules.

---

## 2. Built-in Tool Catalog

### 2.1 Web & Research Tools (`backend/domain/tools/web_tools.py`)
- **`web_search(query, max_results=5)`** (`risk=network`, `render_hint=citation_list`): Queries SearXNG (`ODYSSEUS_SEARXNG_URL`) and returns normalized results (`title`, `url`, `snippet`, `engine`) tagged with `ProvenanceTag(source="web_search", trust="untrusted")`.
- **`fetch_url(url, max_bytes=65536)`** (`risk=network`, `render_hint=markdown`): SSRF-safe HTTP/HTTPS fetcher. Rejects loopback (`127.0.0.0/8`, `::1`), RFC1918 (`10/8`, `172.16/12`, `192.168/16`), link-local (`169.254/16`, `fe80::/10`), CGNAT (`100.64/10`), IPv4-mapped IPv6 (`::ffff:127.0.0.1`), decimal/hex/octal IP encodings (`2130706433`, `0x7f000001`, `0177.0.0.1`), non-HTTP schemes, and internal service hostnames/ports. Re-validates every redirect hop and DNS resolution, strips HTML `<script>`, `<style>`, comments, and CSS-hidden (`display:none`, `opacity:0`, `font-size:0`) spans, and marks output `untrusted`.
- **`youtube_transcript(video_url_or_id, language="en")`** (`risk=network`, `render_hint=text`): Validates video ID and retrieves timed transcript segments tagged `untrusted`.

### 2.2 Workspace-Jailed Filesystem Tools (`backend/domain/tools/filesystem.py`)
All paths are resolved via `resolve_workspace_path(ws_root, raw_path)`, which rejects null bytes, control characters, absolute paths outside the workspace root, `..` traversal escapes, symlinks pointing outside the root, and special files (FIFOs, sockets, block/character devices).
- **`read_file(path, start_line=1, end_line=200)`** (`risk=read`, `render_hint=code`): UTF-8 safe line-numbered reader with binary detection.
- **`write_file(path, content)`** (`risk=write`, `render_hint=code`): Atomic temp-file + `os.replace` writer within the workspace jail.
- **`edit_file(path, old_text, new_text)`** (`risk=write`, `render_hint=diff`): Exact single-occurrence search/replace returning a unified diff (`--- a/path`, `+++ b/path`) for UI inspection.
- **`list_dir(path=".")`**, **`glob(pattern="**/*")`**, **`grep(pattern, path=".")`** (`risk=read`, `render_hint=table`/`json`): Bounded directory listing, glob matching, and regex search skipping binary files.

### 2.3 Sandboxed Execution Tools (`backend/domain/tools/exec_sandbox.py`)
- **`shell(command, timeout_seconds=10)`** & **`python(code, timeout_seconds=10)`** (`risk=exec`, `render_hint=terminal`):
  - Dedicated per-run working directory (`data/workspaces/{chat_id}`) and `.sandbox_tmp`.
  - New session & process group (`os.setsid()`) so `os.killpg(pgid, SIGKILL)` reaps the entire descendant process tree on timeout or cancellation.
  - POSIX `resource.setrlimit` caps: `RLIMIT_CPU`, `RLIMIT_FSIZE` (disk-fill protection), `RLIMIT_NOFILE`, `RLIMIT_CORE=0`, and optional `RLIMIT_NPROC`.
  - Clean environment scrubbed of `ODYSSEUS_SECRET_KEY`, `DATABASE_URL`, provider API keys, and vault secrets.
  - Python audit hook (`sys.addaudithook`) blocking outbound socket/network operations unless explicitly granted.
  - Live `tool.output.delta` streaming coalesced at `<= 20` events/sec (`50 ms` window).

### 2.4 Agent, Memory, Skill, Artifact & Context Tools (`backend/domain/tools/registry.py`)
- **`memory_search(query, limit=5)`** (`risk=read`) & **`memory_save(text, scope="user", pinned=False)`** (`risk=write`): Hybrid semantic + BM25 memory retrieval and opt-in persistence (gated by the single hard privacy switch `memory_enabled`).
- **`load_skill(name)`** (`risk=read`): Progressive disclosure loader for Markdown skills (`SKILL.md`).
- **`update_plan(steps)`** (`risk=read`, `render_hint=plan`): Side-effect-free step checklist emitter (`plan.updated`).
- **`create_artifact(title, kind, content, language=None)`** & **`update_artifact(artifact_id, content, title=None)`** (`risk=write`, `render_hint=artifact`): Versioned artifact creation/mutation emitting `artifact.created` and `artifact.updated`.
- **`spawn_agent(task, preset="researcher", max_steps=4, budget_tokens=4000)`** (`risk=exec`): Spawns a bounded child agent run (`parent_run_id`) with depth cap (`<= 2`), fan-out cap, reduced tool set, and budget capped by the parent's remaining budget.
- **`read_tool_output(call_id, offset=0, length=4096)`** (`risk=read`): Paginates through full persisted tool outputs (`data/tool_outputs/{call_id}.txt`) when large outputs are truncated in the model prompt.
- **`discover_tools(query)`** (`risk=read`): Searches the full tool catalog when `ContextBudgeter` prunes the active schema list on small-context models.
- **Enabled Phase-07 Productivity Suite Tools (`enabled=True`)**:
  - **Email**: `email_search` (`risk=read`, tags `untrusted` email provenance), `email_read` (`risk=read`, returns `nh3`-sanitized HTML + `untrusted` provenance), `email_draft_reply` (`risk=write`), `email_send` (`risk=exec`, **always asks** for approval and uses idempotent outbox), `email_tag` (`risk=write`).
  - **Notes**: `notes_search` (`risk=read`), `notes_read` (`risk=read`, with `[[wikilinks]]` + backlinks), `notes_create` (`risk=write`), `notes_update` (`risk=write`, increments version history).
  - **Todos**: `todos_list` (`risk=read`), `todos_create` (`risk=write`), `todos_update` (`risk=write`), `todos_complete` (`risk=write`).
  - **Calendar**: `calendar_list` (`risk=read`, expands `RRULE` occurrences across IANA timezones), `calendar_create` (`risk=write`), `calendar_update` (`risk=write`, ETag concurrency), `calendar_delete` (`risk=write`).

---

## 3. Structured Approval Patterns & Anti-Spoofing (`Tool.explain`)

Approvals support four scopes: `once`, `run`, `chat`, and `always(pattern)`. Patterns are **structured prefix/glob expressions**, never raw regexes over free text:
- **`argv_prefix:["git", "status"]`** (`shell`): Parsed via `shlex.split` only after verifying zero shell metacharacters (`;`, `|`, `&`, `` ` ``, `$()`, `>`, `<`, `\n`). Commands like `git status; rm -rf /` never match.
- **`path_glob:src/**`** (`read_file`, `write_file`, `edit_file`): Pure path glob against normalized workspace-relative paths.
- **`host_allow:docs.python.org`** (`fetch_url`): Exact lowercase hostname match.
- **`tool_exact:<name>`**: Exact tool name match for tools without path/host/argv parameters.

Before rendering an approval request (`tool.approval.requested`), `normalize_and_flag_approval_args` inspects all string arguments and `Tool.explain(args)` output for:
1. Unicode BiDi override characters (`U+202A..U+202E`, `U+2066..U+2069`)
2. Zero-width and Unicode Tag characters (`U+200B..U+200F`, `U+E0000..U+E007F`)
3. Mixed-script Cyrillic/Greek/Latin homoglyphs (e.g., Cyrillic `а` in `admin`)
4. Embedded control characters or multiline command smuggling

Any hit prepends `[SPOOF WARNING: ...]` to `explain_text` and populates `spoof_warnings` on the approval card.

---

## 4. How to Add a New Tool in `< 30` Lines

Adding a new built-in tool requires only a Pydantic schema, an async handler, and `registry.register(ToolDefinition(...))` in `backend/domain/tools/registry.py`:

```python
from pydantic import BaseModel, Field
from backend.domain.tools.policy import ToolDefinition
from backend.domain.tools.registry import ToolExecutionContext, ToolRegistry


class WordCountArgs(BaseModel):
    text: str = Field(min_length=1, max_length=65536, description="Text to count words in.")


async def _handle_word_count(args: WordCountArgs, _ctx: ToolExecutionContext) -> dict[str, int]:
    lines = args.text.splitlines()
    words = args.text.split()
    return {"lines": len(lines), "words": len(words), "chars": len(args.text)}


def register_word_count_tool(registry: ToolRegistry) -> None:
    registry.register(
        ToolDefinition(
            name="word_count",
            description="Count lines, words, and characters in a text snippet.",
            args_schema=WordCountArgs,
            risk="read",
            required_privilege="chat",
            default_approval="auto",
            render_hint="json",
            idempotent=True,
            explain_fn=lambda a: f"Count words in {len(str(a.get('text', '')))} chars of text",
        ),
        _handle_word_count,
    )
```
