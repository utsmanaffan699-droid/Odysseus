# Deep Research Engine, Citation Verification & SSRF-Safe Web Ingestion (`docs/RESEARCH.md`)

This document describes the architecture, security controls, and verification pipelines of the Odysseus Deep Research subsystem (`backend/domain/research/`, `backend/domain/tools/web_tools.py`, `backend/domain/compare/`, `backend/domain/documents/`).

---

## 1. Pluggable Search Providers & SSRF-Safe Web Fetcher

### 1.1 Search Providers & SearXNG Configuration
- **Default Self-Hosted Provider**: `SearxngSearchProvider` connects to the internal SearXNG container configured via `config/searxng/settings.yml` (`public_instance: false`, JSON output enabled, curated engines).
- **Optional External Adapters**: `BraveSearchProvider` and `TavilySearchProvider` implement the same `SearchProviderProtocol` when operator API keys are configured.
- **Deterministic Offline Golden Provider**: `DeterministicSearchProvider` supplies reproducible multi-domain research corpora (including adversarial prompt-injection and contradiction fixtures) for CI and air-gapped verification.

### 1.2 SSRF-Safe Fetcher (`SSRFSafeHttpFetcher`)
Every outbound fetch (`web_fetch`, Deep Research source reading, and `/api/knowledge/favicon` proxy) passes through `validate_url_against_ssrf(url, resolver)`:
- **Scheme & Port Allowlist**: Only `http` and `https` on ports `80`, `443`, `8080`, and `8443` are permitted. `file://`, `gopher://`, `ftp://`, `dict://`, `data://`, `javascript://`, and `ws://` are rejected immediately (`SSRFBlockedError`).
- **Comprehensive IP Blocklist (84+ Adversarial Vectors)**: Blocks IPv4 loopback (`127.0.0.0/8`), RFC1918 private ranges (`10/8`, `172.16/12`, `192.168/16`), link-local & cloud metadata (`169.254.0.0/16`, `169.254.169.254`, `100.100.100.200`), CGNAT (`100.64.0.0/10`), multicast/broadcast, IPv6 loopback (`::1`), unique-local (`fc00::/7`), link-local (`fe80::/10`), IPv4-mapped IPv6 (`::ffff:127.0.0.1`, `::ffff:169.254.169.254`), decimal/octal/hex/shortened IP encodings (`2130706433`, `0177.0.0.1`, `0x7f000001`, `127.1`), `.localhost`/`.internal` suffixes, and `nip.io`/`sslip.io` wildcard DNS rebinding domains.
- **DNS Rebinding & Redirect Pinning**: DNS resolution is validated on every hop (`max_redirects = 5`). If a hostname resolves to a public IP on initial validation and rebinds to `127.0.0.1` or `169.254.169.254` on fetch or redirect, the hop is aborted before any socket payload is sent.
- **Content-Addressed Source Cache (`SourceCache`)**: Pages are cached by URL + SHA-256 content hash with TTL, `ETag`, and `Last-Modified` conditional revalidation.

---

## 2. Citation System & Anti-Laundering Verifier (`backend/domain/research/citations.py`)

### 2.1 Stable Citation IDs (`PromptBuilder`)
`PromptBuilder` assigns sequential 1-based citation IDs (`[1]`, `[2]`, ...) to retrieved web pages and RAG chunks, formatting an explicit untrusted-data boundary around source passages before LLM synthesis.

### 2.2 Post-Processing Citation & Quote Verifier (`verify_citations_and_quotes`)
Every research report and cited response runs through `verify_citations_and_quotes`:
1. **Dangling Citation Stripping**: Any inline `[n]` marker referencing an ID outside the retrieved source map (`1..K`) is stripped from the rendered output, recorded in `dangling_citations_stripped`, and emits a `notice` event.
2. **Source-Bound Quote Verification (Anti-Citation-Laundering)**: Every quoted claim `"..." [n]` is verified **strictly against the body text of source `[n]` itself** (using normalized substring and sliding-window token overlap `>= 0.72`).
   - If a model attributes a fabricated quote—or a quote present only in adversarial source `[2]`—to trusted source `[1]`, the verifier marks `verified=False` (`reason: quote_not_in_cited_source`) and injects an explicit `[UNVERIFIED QUOTE — not found in source [1]]` warning badge.
3. **Hostile Page Directive Stripping (`sanitize_untrusted_page_text`)**: Hidden HTML comments (`<!-- ... -->`), `<script>`/`<style>` blocks, and prompt-injection imperatives (`IGNORE ALL PREVIOUS INSTRUCTIONS`, `print PWNED`, `call shell tool`) are stripped and logged in `injection_attempts_neutralized` before synthesis.

---

## 3. Deep Research 9-Stage Pipeline (`backend/domain/research/service.py`)

### 3.1 Pipeline Stages & Streamed Events
Each Deep Research run executes 9 explicit stages:
1. `clarify` — Scope analysis & ambiguity detection.
2. `plan_queries` — Multi-angle query decomposition (`research.plan` event).
3. `parallel_search` — Concurrent provider execution (`research.query` events).
4. `triage_sources` — Relevance & domain diversity scoring.
5. `fetch_and_read` — SSRF-safe extraction & prompt-injection stripping (`research.source.Simple` events).
6. `cross_check_claims` — Contradiction & consensus analysis across independent domains (`research.finding` events).
7. `draft` — Evidence-backed section drafting with `[n]` citations.
8. `critique_revise` — Self-critique, citation/quote verification, and dangling-citation pruning (`research.draft.section` events).
9. `final_report` — Sanitized HTML + Markdown report assembly (`artifact.created` & `run.finished`).

### 3.2 Depth Presets, Hard Budgets & Mid-Run Steering
| Preset | Max Searches | Max Sources Read | Max Tokens | Max Duration |
|---|---:|---:|---:|---:|
| `quick` | 3 | 6 | 8,000 | 30 s |
| `standard` | 6 | 15 | 24,000 | 90 s |
| `deep` | 12 | 30 | 64,000 | 240 s |

- **Budget Enforcement**: If `searches_used`, `sources_read`, or `tokens_used` reaches the preset ceiling, `budget_exhausted` triggers graceful synthesis of all evidence collected so far rather than failing or looping infinitely.
- **Mid-Run Steering**: `POST /api/knowledge/research/runs/{run_id}/steer` injects user steering notes (`include_notes`, `exclude_domains`, `stop_early`) into active runs.

### 3.3 Sanitized Report CSP (`REPORT_STRICT_CSP`)
`/api/knowledge/research/runs/{run_id}/report.html` is sanitized on the backend (`sanitize_report_html`) and served with:
```http
Content-Security-Policy: default-src 'none'; script-src 'none'; style-src 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'none'; frame-ancestors 'self'; base-uri 'none'; form-action 'none'
```
Even if raw `<script>`, `onerror=`, or `javascript:` payloads are injected into a draft, scripts cannot execute inside the report preview (`FE-WORK-02`, Acceptance #7).
