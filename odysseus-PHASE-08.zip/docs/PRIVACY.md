# Odysseus Privacy & Untrusted-Content Isolation (`docs/PRIVACY.md`)

## 1. Email Tracking Pixel & Remote Resource Blocking
- All external `<img src="http(s)://...">`, CSS `url(...)`, and `@import` references in incoming HTML emails are blocked by default (`allow_remote_content=False`), preventing sender read-receipt tracking pixels and IP/user-agent leakage.
- Users may explicitly allow remote images for a trusted sender via `POST /api/mail/messages/{id}/allow-remote`.

## 2. Untrusted Email Taint & Lethal-Trifecta Prevention
- Every email read via `email_search` or `email_read` carries `ProvenanceTag(source="email:<sender>", trust="untrusted")`.
- When untrusted email content is in context, `ToolPolicyEngine` escalates any `write`, `exec`, `network`, or `admin` tool (`email_send`, `calendar_create`, `notes_create`, `todos_create`, `shell`) to `decision="ask"` (or `"deny"` in unattended background mode), even if an allowlist pattern would otherwise match.
- AI email triage (`triage_message`) creates only drafts (`suggest_only=True`) and **never auto-sends**.

## 3. Credential & Token Privacy
- IMAP/SMTP passwords, OAuth refresh tokens, webhook signing secrets, and personal API tokens are never returned in list endpoints or written to logs.
- Personal API tokens are displayed once at creation and stored solely as SHA-256 digests.
