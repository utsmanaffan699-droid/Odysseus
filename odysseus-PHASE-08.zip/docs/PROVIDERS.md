# Odysseus Provider Layer (`docs/PROVIDERS.md`)

`backend/providers/` provides a unified, resilient, provider-agnostic streaming abstraction for cloud and local LLM endpoints.

---

## 1. Unified Streaming Interface (`backend/providers/base.py`)

Every adapter implements `stream_chat(request: ProviderChatRequest) -> AsyncIterator[ProviderEvent]` and normalizes upstream streams into:
- `thinking_delta` (`text`)
- `text_delta` (`text`)
- `tool_call_start` / `tool_call_args_delta` / `tool_call_end` (`call_id`, `tool_name`, `args_delta`)
- `usage` (`input_tokens`, `output_tokens`, `cached_tokens`, `reasoning_tokens`)
- `stop` (`stop_reason`: `stop | length | tool_calls | content_filter | cancelled | error`)

### Error Taxonomy (`ClassifiedProviderError`)
All HTTP, network, timeout, and framing errors are classified into 9 canonical categories with explicit `retryable: bool` and optional `retry_after: float | None`:
- `auth` (HTTP 401/403 — `retryable=False`)
- `rate_limit` (HTTP 429 — `retryable=True`, honors `Retry-After`)
- `overloaded` (HTTP 502/503/529 — `retryable=True`)
- `context_length` (HTTP 400/413 context window exceeded — `retryable=False`)
- `content_filter` (safety/moderation block — `retryable=False`)
- `invalid_request` (HTTP 400/404/422, oversized SSE frames, invalid UTF-8, duplicate JSON keys, embedded `\u0000` — `retryable=False`)
- `network` (connect/read transport errors — `retryable=True`)
- `timeout` (connect/read/total timeout — `retryable=True`)
- `unknown` (HTTP 500 — `retryable=True`)

---

## 2. Concrete Adapters (`backend/providers/adapters.py`)

1. **`OpenAICompatibleAdapter`**:
   - Supports OpenAI, Groq, Together, DeepSeek, Fireworks, OpenRouter, Ollama (`/v1`), llama.cpp, vLLM, and LM Studio.
   - Supports `/v1/chat/completions` SSE streaming and `/v1/responses` (`use_responses_api=True`).
   - Supports both native `tool_calls` deltas and local `text_fenced` tool extraction (` ```tool_call ... ``` `).
2. **`AnthropicMessagesAdapter`**:
   - Supports `/v1/messages` streaming (`content_block_start`, `thinking_delta`, `text_delta`, `input_json_delta`, `message_delta`), extended thinking blocks, tool use, and `anthropic-beta: prompt-caching-2024-07-31` ephemeral cache headers.
3. **`GeminiAdapter`**:
   - Supports Google Gemini `streamGenerateContent?alt=sse` with thought parts, text parts, `functionCall` parts, and `usageMetadata`.
4. **`FakeProviderAdapter` & `FakeProvider` (`backend/providers/fake.py`)**:
   - Deterministic scriptable provider and mock HTTP servers (`create_fake_openai_app`, `create_fake_anthropic_app`, `create_fake_gemini_app`) used in contract, chaos, and E2E tests.

---

## 3. Capabilities, Local `/v1` Defaults & Probing (`backend/providers/capabilities.py`)

- **Capabilities Matrix**: Tracks `tools` (`native | text_fenced | none`), `supports_tools` (`true | false | null`), `vision`, `thinking`, `context_window`, `max_output`, `cost_per_mtok_in`, `cost_per_mtok_out`, `cost_per_mtok_cached`, and `supports_json_mode`.
- **Conservative Local `/v1` Default**: Unprobed local `/v1` models default to `tools="text_fenced"` unless live probing confirms native tool calling or the user sets `supports_tools: true`.
- **Manual Tri-State Override**: `supports_tools: true | false | null` forces `native`, `none`, or `auto` per endpoint.
- **Auto-Probing (`probe_openai_compatible_endpoint`)**: Executes model listing (`GET /v1/models`), completion ping, a single-turn tool-call canary (`canary_ping`), and a 1x1 PNG vision canary.

---

## 4. Resilience & Privacy (`backend/providers/resilience.py`)

- **Retries & Backoff**: Exponential backoff with full jitter on retryable errors before stream output begins, honoring `Retry-After` headers and emitting `notice{code: "provider_retry"}` events.
- **Circuit Breaker**: Per-provider state machine (`closed -> open -> half_open`) opening after `provider_circuit_breaker_threshold` consecutive failures.
- **Fallback Chain**: Configurable model fallback (`model_a -> model_b`) when a primary provider fails or its circuit is open, emitting `notice{code: "provider_fallback"}`.
- **Redaction & Encrypted Exchange Capture**: API keys and bearer tokens are scrubbed via `redact_text`/`redact_mapping`. Prompts and completions are never logged; optional raw exchange capture is dev-only, AES-256-GCM encrypted at rest, and subject to TTL expiry.
