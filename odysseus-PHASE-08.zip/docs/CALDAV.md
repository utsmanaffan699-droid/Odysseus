# Odysseus Calendar & CalDAV Architecture (`backend/domain/calendar`)

## 1. Discovery & Incremental Sync (`RFC 4791` / `RFC 6578`)
- **Discovery**: Resolves `/.well-known/caldav`, principal URL, and `calendar-home-set` via `PROPFIND` (`discover_caldav_collections`).
- **Incremental `sync-token` / `ctag` Sync (`sync_caldav_collection`)**: Transfers only changed or deleted `.ics` resources since the previous `sync-token`, recording `wire_resources_transferred`.
- **Offline Edit Queue (`replay_offline_queue`)**: Queues local creates, updates, and deletes while offline and replays them in order upon reconnection.

## 2. ETag Optimistic Concurrency & 2-Way Conflict Resolution
- Every event tracks its server `etag`.
- If a local update provides an `expected_etag` that differs from the current remote `etag`, `update_event` records a `CalDAVConflictItem` preserving both `local_version` and `remote_version` rather than silently overwriting remote changes.
- Operators resolve conflicts via `resolve_conflict(conflict_id, strategy="keep_local" | "keep_remote" | "merge")`.

## 3. RFC 5545 Recurrence (`RRULE`, `EXDATE`, `RECURRENCE-ID`) & Timezones
- Expands `RRULE` patterns (`DAILY`, `WEEKLY`, `MONTHLY` by weekday/monthday/`BYSETPOS` such as `-1FR`, `YEARLY` including Feb 29 leap years) in local wall-clock time before attaching `zoneinfo.ZoneInfo`, ensuring local hour:minute never drifts across spring-forward or fall-back DST transitions across 40 IANA timezones (`SUPPORTED_30_IANA_TIMEZONES`).
- Supports `EXDATE` exclusions (`exclude_occurrence`) and `RECURRENCE-ID` single-occurrence overrides (`override_single_occurrence`).
- Enforces `ODYSSEUS_ICS_MAX_BYTES` on `.ics` imports and recovers gracefully from malformed vendor `.ics` files.
- Parses natural-language quick-add strings using a deterministic regex grammar first (`parse_natural_language_event`) and a structured fallback second.
