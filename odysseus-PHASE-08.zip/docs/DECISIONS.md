# Architectural Decision Records (DECISIONS.md)

## ADR-0001: Database Schema & Concurrency Strategy (SQLite WAL + PostgreSQL Parity)
- **Date:** 2026-10-03
- **Status:** Accepted
- **Context:** Odysseus must run self-hosted out-of-the-box with zero external DB setup (SQLite) while also supporting multi-user production deployments on PostgreSQL. SQLite suffers from `database is locked` errors under heavy write concurrency unless configured and retried properly.
- **Options:**
  1. SQLite default rollback journal without application-level retry.
  2. SQLite in WAL mode (`PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL; PRAGMA busy_timeout=30000; PRAGMA foreign_keys=ON`) combined with an application-level write lock / exponential jitter retry wrapper (`with_db_write_retry`) and SQLAlchemy 2.x async (`aiosqlite` / `asyncpg` / `psycopg`).
- **Decision:** Option 2. Every SQLite connection sets WAL mode, 30s busy timeout, and foreign keys ON at connect time, and write transactions in the Unit of Work use bounded exponential backoff retry on transient `OperationalError` (`database is locked`).
- **Consequences:** Zero `database is locked` errors leak to clients even under a 100-concurrent-writer storm; identical ORM models and Alembic migrations run on both SQLite and PostgreSQL 17.

## ADR-0002: Explicit Route Authorization Registry (`ROUTE_POLICIES`)
- **Date:** 2026-10-03
- **Status:** Accepted
- **Context:** In an admin-capable AI workspace, accidentally shipping a route without authentication or authorization is a critical vulnerability.
- **Options:**
  1. Rely on developer discipline to add `Depends(...)` to each endpoint.
  2. Maintain a central `ROUTE_POLICIES` registry + `@policy(...)` / `require(privilege)` dependency and enforce via an automated test that inspects every route in `app.routes`.
- **Decision:** Option 2. Every route has an explicit policy (`public`, `authenticated`, or specific privilege flag such as `chat`, `agent`, `admin`). A test (`test_every_route_has_explicit_policy`) fails CI if any route is unregistered or if its runtime behavior diverges from its declared policy.
- **Consequences:** Impossible to add an unprotected endpoint silently.

## ADR-0003: Envelope Encryption for Secrets at Rest
- **Date:** 2026-10-03
- **Status:** Accepted
- **Context:** Provider API keys, TOTP secrets, and IMAP/SMTP credentials must be stored encrypted at rest with support for key rotation.
- **Options:**
  1. Single static Fernet key encrypting values directly.
  2. Envelope encryption: a master Key Encryption Key (KEK) stored in `data/master.key` (`0600` permissions) or external KMS hook encrypts a unique random 256-bit Data Encryption Key (DEK) per secret using AES-256-GCM; the DEK encrypts the secret payload with AES-256-GCM.
- **Decision:** Option 2.
- **Consequences:** Each secret has its own random DEK and nonce; rotating the master KEK only requires re-wrapping DEKs without decrypting secret payloads in bulk.

## ADR-0004: Append-Only Hash-Chained Audit Log
- **Date:** 2026-10-03
- **Status:** Accepted
- **Context:** Security-sensitive actions (login, 2FA, password changes, token creation, privilege modifications, admin actions) require tamper-evident logging.
- **Decision:** Each `audit_log` row stores `prev_hash` (the `record_hash` of the preceding row, or `"0"*64` for genesis) and `record_hash = sha256( canonical_json(id, timestamp, actor_user_id, actor_ip, action, resource_type, resource_id, details_json, prev_hash) )`. A CLI and service method `verify_audit_chain()` verifies integrity end-to-end.
- **Consequences:** Any manual SQL tampering or row deletion breaks the cryptographic hash chain and is immediately detected.

## ADR-0005: Durable Job Supervisor & Lease Recovery
- **Date:** 2026-10-03
- **Status:** Accepted
- **Context:** Background jobs and agent runs must survive unexpected process crashes (`SIGKILL` / `kill -9`).
- **Decision:** Jobs use database-backed leases (`status='leased'`, `lease_owner`, `leased_until`, `heartbeat_at`). Workers heartbeat every `ODYSSEUS_JOB_HEARTBEAT_SECONDS`. If a worker dies via `kill -9`, once `leased_until` expires (or on new server startup recovery), an atomic conditional update re-leases the job to a single active worker and marks any mid-flight `runs` as `interrupted` with a durable `run.status` event.
- **Consequences:** At-least-once lease recovery without duplicate concurrent execution; clean `interrupted` state for in-flight runs.

## ADR-0006: Provenance Taint Escalation & Structured Approval Patterns
- **Date:** 2026-10-03
- **Status:** Accepted
- **Context:** Indirect prompt injection via untrusted web pages, attachments, or MCP outputs can coerce an LLM into invoking pre-approved `write`, `exec`, or `network` tools. Additionally, regex-based `always` approval rules over shell commands are vulnerable to command-chaining smuggling (`git status; rm -rf /`).
- **Decision:**
  1. Every run tracks provenance taint (`RunTaintTracker`). Once any `untrusted` output enters the run context, `ToolPolicyEngine` escalates **all** `write`, `exec`, `network`, and `admin` tool calls to `ask` (or `deny` in background runs), overriding saved `always` allow rules.
  2. Persistent `always(pattern)` rules use structured matchers (`argv_prefix:[...]` rejecting shell metacharacters, workspace-relative `path_glob:...`, and exact `host_allow:...`), never free-text regular expressions.
- **Consequences:** Indirect prompt injections cannot silently chain into tool execution or data exfiltration even when a user has configured convenience `always` rules for normal interactive turns.

## ADR-0007: Block-Level Incremental Streaming Markdown & Pure `runReducer`
- **Date:** 2026-10-03
- **Status:** Accepted
- **Context:** Streaming LLM responses at 120+ tokens/sec with fenced code blocks, LaTeX math, Mermaid diagrams, and GFM tables causes severe main-thread jank and layout thrashing if the entire Markdown message is re-parsed and re-mounted on every token delta.
- **Options:**
  1. Re-run a full Markdown AST parser on the full message text on every SSE `message.part.delta` event.
  2. Split the Markdown document into closed blocks (`closed: true`, hashed with FNV-1a and memoized via `React.memo`) and at most one open tail block (`closed: false`, coalesced to at most 1 parse per `requestAnimationFrame`), paired with a pure $O(1)$ `runReducer` and a `fetch` + `ReadableStream` SSE client.
- **Decision:** Option 2, verified by a 2,000-run `fast-check` chunking-invariance property suite and a 220-payload XSS corpus.
- **Consequences:** Zero closed-block DOM re-mounts during streaming, 0 long tasks > 50 ms at 120 tokens/sec, deterministic chunking invariance, and < 150 KB gzip initial shell bundle via lazy chunks for Shiki, KaTeX, Mermaid, and CodeMirror.

## ADR-0008: Cookbook State Machines, Roofline Fit Math, Non-Destructive Image Op-Log & Subprocess Argv Policy
- **Date:** 2026-10-04
- **Status:** Accepted
- **Context:** Phase 08 introduces local model downloads, engine installation, model serving, remote SSH management, 50 MP image editing, and voice STT/TTS. Ad-hoc shell invocations (`shell=True`) or full-bitmap undo stacks cause command injection, OOM crashes, and silent failure states.
- **Decision:**
  1. **Explicit Durable State Machines**: Downloads (`queued → preflight → downloading → verifying → ready`), Engine Installs (`queued → preflight → fetching → verifying → extracting|building → smoke_test → installed` with atomic symlink swap), and Serves (`requested → preflight → starting → loading → healthy → stopped` with completion readiness probe and automatic provider registration/deregistration) persist every transition and classify failures against a 32-rule `FailureReport` catalog.
  2. **Strict `argv`-Only Subprocess Policy**: `shell=True`, `os.system`, and `os.popen` are statically banned across Phase 08 modules. Remote SSH uses `0600` ED25519 keys, TOFU fingerprint confirmation (`hard_stop` on key change), and allowlisted command templates.
  3. **Non-Destructive Image Operation Log**: Image editing records an immutable sequence of vector/pixel operations (`crop`, `rotate`, `adjust`, `mask`, `inpaint`, `upscale`) processed in tiles (`<= 2048x2048`) so 50 MP images stay under `< 600 MB` RAM and support `>= 200` exact undo/redo steps.
- **Consequences:** Deterministic failure recovery, zero command-injection surface across 10,000 fuzz payloads, and bounded memory usage for 50 MP media editing.



