# Subprocess & Filesystem Write Audit (`docs/SUBPROCESSES.md`)

Per Phase 08 §6 Self-Review Gate, every subprocess call site and every filesystem write in Phase 08 is enumerated below.

## 1. Static Enforcement: `shell=True` and `os.system` Banned
- All subprocess invocations across `backend/domain/cookbook/`, `backend/domain/gallery/`, `backend/domain/voice/`, and `backend/domain/admin_ops/` pass `argv: list[str]` arrays with `shell=False` (default), explicit timeouts (`<= 5 s` for hardware probes), output byte caps (`<= 256 KB`), and scrubbed environment variables.
- Automated test `test_adversarial_command_injection_10k_and_static_no_shell_check` parses the AST of all Phase 08 modules and fails CI if `shell=True`, `os.system`, `os.popen`, or `pty.spawn` appears anywhere.

## 2. Subprocess Call Sites

| Call Site | `argv` Array | Timeout | Purpose & Input Validation |
|---|---|---|---|
| `backend/domain/cookbook/service.py::run_safe_probe_argv` | `["nvidia-smi", "--query-gpu=index,name,memory.total,memory.free,driver_version", "--format=csv,noheader,nounits"]` | `5.0 s` | GPU detection; fixed constant argv array, zero user input. |
| `backend/domain/cookbook/service.py::ServeStateMachine.start_real_cpu_serve` | `[sys.executable, "-m", "backend.domain.cookbook.tiny_gguf_server", "--port", str(port), "--model", model_id]` | Managed process (`SIGTERM` → grace → `SIGKILL`) | Validated port (`1024..65535`) and strict regex-validated `model_id` (`^[A-Za-z0-9._/-]+$`). |
| `backend/domain/cookbook/service.py::RemoteHostManager.build_ssh_argv` | `["ssh", "-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=yes", "-o", "ForwardAgent=no", "-o", "ForwardX11=no", "-i", key_path, "-p", str(port), f"{user}@{host}", "--", *template_argv]` | `10.0 s` | Remote hardware/serve template execution; `host`, `user`, and template parameters validated against strict allowlist regexes (`_SAFE_TOKEN_RE`), rejecting `-` leading option injection and shell metacharacters. |
| `backend/domain/tools/exec_sandbox.py` | Sandboxed `shell` / `python` agent tool | `timeout_seconds` (`<= 60 s`) | Gated by `ToolPolicyEngine` (`risk="exec"`, admin-only, `os.setsid()` process group + `RLIMIT_*`). |

## 3. Filesystem Writes Audit
- All runtime writes occur strictly inside `settings.data_dir` (`data/local/models/`, `data/local/engines/`, `data/ssh/`, `data/gallery/`, `data/backups/`) or temporary test directories (`tmp_path`).
- Zero files are written outside `data/` or `tmp_path`.
