# Security Policy

## Threat Model & Security Charter

Odysseus is treated as a high-privilege administrative workspace (shell, files, email, local model serving, API tokens).

### Core Security Principles

1. **Secure Defaults:**
   - Authentication enabled by default (`Argon2id` password hashing + TOTP 2FA).
   - Server binds to `127.0.0.1` by default (`ODYSSEUS_BIND_HOST=127.0.0.1`).
   - Internal services (ChromaDB, SearXNG, ntfy, PostgreSQL) bind strictly to `127.0.0.1` or internal container networks.
   - No Docker socket mounted by default.
2. **Untrusted Content Isolation:**
   - All content originating outside the user's keyboard (web pages, emails, documents, skills, notes, memories, tool outputs, MCP results, files) is untrusted data.
   - Tool execution policy is enforced in backend code via explicit privilege and risk checks (`auto` / `ask` / `deny`), never delegated to prompt instructions.
3. **Web Application Hardening:**
   - Strict Content Security Policy (`script-src 'self'`, no `unsafe-inline` or `unsafe-eval`).
   - Double-submit CSRF protection on all cookie-authenticated unsafe HTTP methods (`POST`, `PUT`, `PATCH`, `DELETE`).
   - Session fixation prevention, opaque hashed session tokens in DB, idle + absolute timeouts.
4. **Secrets & Audit:**
   - Envelope encryption (`AES-256-GCM` + `Fernet` KEK) for secrets at rest (`data/master.key` with `0600` permissions).
   - Automatic secret redaction in structured logs, error responses, and diagnostic bundles.
   - Append-only, SHA-256 hash-chained audit log for tamper evidence.

## Reporting a Vulnerability

Do **not** open a public issue for security vulnerabilities.
Report vulnerabilities privately to `security@odysseus.local` with:
- Reproduction steps or proof-of-concept
- Affected route/component and configuration
- Impact assessment
