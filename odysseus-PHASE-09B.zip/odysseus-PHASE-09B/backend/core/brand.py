"""Runtime brand metadata shared by exports and operator-facing surfaces."""

from __future__ import annotations

import html
import json
from pathlib import Path
from typing import Any

_ROOT = Path(__file__).resolve().parents[2]
_CONFIG_PATH = _ROOT / "brand" / "brand.config.json"
_DEFAULT: dict[str, Any] = {
    "productName": "PRODUCT_NAME",
    "tagline": "A quiet workspace for consequential work.",
    "brand": {"primary": "#3F6D68", "secondary": "#D38B5D", "ink": "#172522", "paper": "#F5F2EB"},
}


def load_brand_config() -> dict[str, Any]:
    """Load the repository brand config with a safe fallback for packaged installs."""
    try:
        value = json.loads(_CONFIG_PATH.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else dict(_DEFAULT)
    except (OSError, ValueError):
        return dict(_DEFAULT)


def brand_value(key: str, default: str) -> str:
    value = load_brand_config().get(key, default)
    return str(value) if isinstance(value, str) else default


def cli_banner() -> str:
    """Return a narrow-terminal-safe, NO_COLOR-safe operator banner."""
    name = brand_value("productName", "PRODUCT_NAME")
    tagline = brand_value("tagline", "A quiet workspace for consequential work.")
    return f"{name}\n{tagline}"


def render_branded_error_html(status_code: int, message: str, *, locale: str = "en") -> str:
    """Render a small accessible HTML error page for browser-facing non-API requests."""
    title = f"{status_code} · {brand_value('productName', 'PRODUCT_NAME')}"
    body = f'<section class="error"><p class="code">{status_code}</p><h1>{html.escape(message)}</h1><p>Return to the workspace or try the request again.</p></section>'
    return render_branded_export_html(title, body, locale=locale)


def render_branded_export_html(title: str, articles: str, *, locale: str = "en") -> str:
    """Render a standalone, offline export with inline CSS and print-safe page breaks."""
    cfg = load_brand_config()
    name = html.escape(str(cfg.get("productName", "PRODUCT_NAME")))
    tagline = html.escape(str(cfg.get("tagline", "A quiet workspace for consequential work.")))
    colors = cfg.get("brand", {})
    primary = html.escape(str(colors.get("primary", "#3F6D68")))
    secondary = html.escape(str(colors.get("secondary", "#D38B5D")))
    paper = html.escape(str(colors.get("paper", "#F5F2EB")))
    ink = html.escape(str(colors.get("ink", "#172522")))
    safe_title = html.escape(title)
    lang = "id" if locale == "id" else "en"
    return f'''<!doctype html>
<html lang="{lang}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{safe_title} · {name}</title>
<style>
:root{{--primary:{primary};--secondary:{secondary};--paper:{paper};--ink:{ink}}}
*{{box-sizing:border-box}} body{{margin:0;background:var(--paper);color:var(--ink);font:16px/1.6 system-ui,sans-serif}}
main{{max-width:820px;margin:0 auto;padding:48px 28px}} header{{border-bottom:3px solid var(--primary);padding-bottom:18px;margin-bottom:30px}}
.brand{{display:flex;justify-content:space-between;gap:16px;align-items:baseline;color:var(--primary);font-weight:700;letter-spacing:.02em}}
h1{{font:700 clamp(2rem,5vw,3.4rem)/1.1 Georgia,serif;margin:.7em 0 .2em}} h2{{break-after:avoid}}
article{{break-inside:avoid;margin:0 0 28px;padding:20px 0;border-bottom:1px solid color-mix(in srgb,var(--primary) 24%,transparent)}}
article h3{{color:var(--secondary);font-size:.78rem;text-transform:uppercase;letter-spacing:.12em}} pre{{white-space:pre-wrap;overflow-wrap:anywhere;background:#172522;color:#F5F2EB;padding:16px;border-radius:10px}}
footer{{margin-top:48px;padding-top:16px;border-top:1px solid var(--primary);font-size:.85rem;opacity:.75}}
@media print{{body{{background:#fff}} main{{padding:12mm 0}} header{{margin-bottom:16mm}} footer{{position:fixed;bottom:0;left:0;right:0}}}}
@media(prefers-color-scheme:dark){{body{{background:#101A19;color:#F5F2EB}}}}
</style></head><body><main><header><div class="brand"><span>{name}</span><span>{tagline}</span></div><h1>{safe_title}</h1></header>{articles}<footer>{name} · self-hosted export · page metadata preserved locally</footer></main></body></html>'''
