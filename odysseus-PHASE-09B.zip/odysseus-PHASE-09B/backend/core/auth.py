"""Authentication, Argon2id hashing, TOTP 2FA, sessions, API tokens, and login throttling."""

from __future__ import annotations

import base64
import hashlib
import hmac
import io
import secrets
import time
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta

import pyotp
import qrcode
from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError, VerifyMismatchError

from backend.core.crypto import EnvelopeVault
from backend.core.models import ApiToken, SessionRecord, User
from backend.core.settings import Settings
from backend.core.uow import UnitOfWork, _ensure_utc

ALL_PRIVILEGES: tuple[str, ...] = (
    "chat",
    "agent",
    "shell",
    "files",
    "email",
    "calendar",
    "research",
    "cookbook",
    "admin",
)

DEFAULT_USER_PRIVILEGES: tuple[str, ...] = (
    "chat",
    "agent",
    "files",
    "research",
)

_PASSWORD_HASHER = PasswordHasher(
    time_cost=2,
    memory_cost=19456,
    parallelism=1,
    hash_len=32,
    salt_len=16,
)

# Pre-computed Argon2id hash for constant-time dummy verification when username is not found
_DUMMY_HASH = _PASSWORD_HASHER.hash("odysseus-timing-safe-dummy-password-do-not-use")


def hash_password(password: str) -> str:
    """Hash a plaintext password using Argon2id."""
    return str(_PASSWORD_HASHER.hash(password))


def verify_password_constant_time(password: str, stored_hash: str | None) -> bool:
    """Verify password against Argon2id hash; run dummy verify if user does not exist."""
    target_hash = stored_hash if stored_hash is not None else _DUMMY_HASH
    try:
        matched = bool(_PASSWORD_HASHER.verify(target_hash, password))
    except (VerifyMismatchError, VerificationError, InvalidHashError):
        matched = False
    return matched if stored_hash is not None else False


def sha256_hex(value: str) -> str:
    """Compute SHA-256 hex digest of an opaque token or recovery code."""
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def constant_time_equals(a: str, b: str) -> bool:
    """Timing-safe string comparison."""
    return hmac.compare_digest(a.encode("utf-8"), b.encode("utf-8"))


@dataclass
class ThrottleBucket:
    """Sliding window failure tracker with exponential lockout."""

    failures: list[float] = field(default_factory=list)
    locked_until: float = 0.0


class LoginThrottler:
    """Per-IP, per-(IP,user) and per-account login/2FA limiter with bounded memory.

    Hardening notes:
    - A per-account bucket bounds *distributed* brute force against one username from
      many IPs. To avoid locking a legitimate user out (the reason the per-account
      check was previously skipped), it applies a bounded progressive *delay* rather
      than a long lockout.
    - Bucket dictionaries are bounded and stale entries are evicted, so an attacker
      cannot grow process memory without limit by spraying usernames/IPs.
    """

    _MAX_TRACKED_KEYS = 8192
    _ACCOUNT_DELAY_CAP_SECONDS = 5

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self._ip_buckets: dict[str, ThrottleBucket] = {}
        self._user_buckets: dict[str, ThrottleBucket] = {}
        self._totp_buckets: dict[str, ThrottleBucket] = {}
        self._account_buckets: dict[str, ThrottleBucket] = {}

    def _evict_stale(self, now: float, window: int) -> None:
        """Bound memory: drop buckets whose failures are stale and that are unlocked."""
        for store in (
            self._ip_buckets,
            self._user_buckets,
            self._totp_buckets,
            self._account_buckets,
        ):
            if len(store) <= self._MAX_TRACKED_KEYS:
                continue
            stale_cutoff = now - window
            for key in [
                k
                for k, b in store.items()
                if b.locked_until <= now and all(t < stale_cutoff for t in b.failures)
            ]:
                store.pop(key, None)

    def check_login_allowed(self, ip: str, username: str, *, now: float | None = None) -> int:
        """Return 0 if allowed, or positive retry_after seconds if throttled."""
        ts = now if now is not None else time.monotonic()
        self._evict_stale(ts, self.settings.login_window_seconds)
        ip_wait = self._check_bucket(
            self._ip_buckets.get(ip),
            ts,
            self.settings.login_window_seconds,
            self.settings.login_max_attempts_per_ip,
        )
        # Only apply the per-(ip,user) lockout if the IP itself also has prior failures,
        # so an attacker from IP A cannot DoS a legitimate user logging in from IP B.
        ip_bucket = self._ip_buckets.get(ip)
        ip_has_failures = ip_bucket is not None and len(ip_bucket.failures) > 0
        user_wait = 0
        if ip_has_failures:
            user_wait = self._check_bucket(
                self._user_buckets.get(f"{ip}:{username.lower()}"),
                ts,
                self.settings.login_window_seconds,
                self.settings.login_max_attempts_per_user,
            )
        account_wait = self._account_wait(username.lower(), ts)
        return max(ip_wait, user_wait, account_wait)

    def _account_wait(self, account: str, now: float) -> int:
        bucket = self._account_buckets.get(account)
        if bucket is None:
            return 0
        self._prune(bucket, now, self.settings.login_window_seconds)
        over = len(bucket.failures) - self.settings.login_max_attempts_per_user
        if over <= 0:
            return 0
        return min(self._ACCOUNT_DELAY_CAP_SECONDS, 1 + over)

    def record_login_failure(self, ip: str, username: str, *, now: float | None = None) -> int:
        """Record a failed login attempt and return retry_after seconds if now locked."""
        ts = now if now is not None else time.monotonic()
        self._evict_stale(ts, self.settings.login_window_seconds)
        account = username.lower()
        ip_bucket = self._ip_buckets.setdefault(ip, ThrottleBucket())
        user_bucket = self._user_buckets.setdefault(f"{ip}:{account}", ThrottleBucket())
        account_bucket = self._account_buckets.setdefault(account, ThrottleBucket())

        ip_retry = self._record_failure(
            ip_bucket,
            ts,
            self.settings.login_window_seconds,
            self.settings.login_max_attempts_per_ip,
            self.settings.login_base_lockout_seconds,
        )
        user_retry = self._record_failure(
            user_bucket,
            ts,
            self.settings.login_window_seconds,
            self.settings.login_max_attempts_per_user,
            self.settings.login_base_lockout_seconds,
        )
        self._prune(account_bucket, ts, self.settings.login_window_seconds)
        account_bucket.failures.append(ts)
        return max(ip_retry, user_retry, self._account_wait(account, ts))

    def record_login_success(self, ip: str, username: str) -> None:
        """Clear failure counters for (ip, username) and the account-wide bucket."""
        account = username.lower()
        self._user_buckets.pop(f"{ip}:{account}", None)
        self._account_buckets.pop(account, None)

    def check_totp_allowed(self, user_id: str, *, now: float | None = None) -> int:
        ts = now if now is not None else time.monotonic()
        return self._check_bucket(
            self._totp_buckets.get(user_id),
            ts,
            self.settings.login_window_seconds,
            self.settings.totp_max_attempts,
        )

    def record_totp_failure(self, user_id: str, *, now: float | None = None) -> int:
        ts = now if now is not None else time.monotonic()
        bucket = self._totp_buckets.setdefault(user_id, ThrottleBucket())
        return self._record_failure(
            bucket,
            ts,
            self.settings.login_window_seconds,
            self.settings.totp_max_attempts,
            self.settings.login_base_lockout_seconds,
        )

    def record_totp_success(self, user_id: str) -> None:
        self._totp_buckets.pop(user_id, None)

    @staticmethod
    def _prune(bucket: ThrottleBucket, now: float, window: int) -> None:
        cutoff = now - window
        bucket.failures = [t for t in bucket.failures if t >= cutoff]

    def _check_bucket(
        self,
        bucket: ThrottleBucket | None,
        now: float,
        window: int,
        max_attempts: int,
    ) -> int:
        if bucket is None:
            return 0
        self._prune(bucket, now, window)
        if bucket.locked_until > now:
            return max(1, int(bucket.locked_until - now + 0.999))
        if len(bucket.failures) >= max_attempts:
            return max(1, self.settings.login_base_lockout_seconds)
        return 0

    @staticmethod
    def _record_failure(
        bucket: ThrottleBucket,
        now: float,
        window: int,
        max_attempts: int,
        base_lockout: int,
    ) -> int:
        LoginThrottler._prune(bucket, now, window)
        bucket.failures.append(now)
        count = len(bucket.failures)
        if count >= max_attempts:
            exponent = min(6, count - max_attempts)
            lock_duration = base_lockout * (2**exponent)
            bucket.locked_until = max(bucket.locked_until, now + lock_duration)
            return max(1, int(bucket.locked_until - now + 0.999))
        return 0


@dataclass
class BootstrapAdminResult:
    """Result of first-boot admin initialization."""

    created: bool
    username: str
    temporary_password: str | None = None


async def bootstrap_first_admin(
    uow: UnitOfWork,
    settings: Settings,
) -> BootstrapAdminResult:
    """Ensure the initial admin user exists on first boot.

    If no users exist, creates `settings.admin_user` with a random temporary password,
    flags `must_change_password=True`, grants all privileges, and returns the password
    to be printed ONCE to stdout.
    """
    existing_count = await uow.users.count_users()
    if existing_count > 0:
        return BootstrapAdminResult(created=False, username=settings.admin_user)

    temp_password = secrets.token_urlsafe(18)
    now = datetime.now(UTC)
    user_id = f"u_{uuid.uuid4().hex[:16]}"
    user = User(
        id=user_id,
        username=settings.admin_user,
        email=settings.admin_email,
        password_hash=hash_password(temp_password),
        must_change_password=True,
        totp_secret_encrypted=None,
        totp_enabled=False,
        recovery_codes_hashes=[],
        is_active=True,
        created_at=now,
        updated_at=now,
    )
    await uow.users.add(user)
    await uow.users.set_privileges(user, list(ALL_PRIVILEGES), granted_by="system")
    await uow.audit.record(
        action="auth.admin_bootstrapped",
        resource_type="user",
        resource_id=user.id,
        details={"username": user.username, "must_change_password": True},
    )
    return BootstrapAdminResult(
        created=True,
        username=settings.admin_user,
        temporary_password=temp_password,
    )


async def create_user_session(
    uow: UnitOfWork,
    settings: Settings,
    *,
    user: User,
    ip_address: str,
    user_agent: str,
    mfa_pending: bool = False,
) -> tuple[str, SessionRecord]:
    """Mint a brand-new server-side opaque session (never reuses any client-supplied ID)."""
    raw_token = secrets.token_urlsafe(32)
    csrf_token = secrets.token_urlsafe(32)
    now = datetime.now(UTC)
    record = SessionRecord(
        id=f"ses_{uuid.uuid4().hex[:16]}",
        token_hash=sha256_hex(raw_token),
        user_id=user.id,
        csrf_token=csrf_token,
        mfa_pending=mfa_pending,
        ip_address=ip_address,
        user_agent=user_agent[:512],
        created_at=now,
        last_active_at=now,
        expires_at=now + timedelta(seconds=settings.session_absolute_timeout_seconds),
        revoked_at=None,
    )
    await uow.sessions.add(record)
    return raw_token, record


def is_session_valid(
    record: SessionRecord,
    settings: Settings,
    *,
    now: datetime | None = None,
) -> tuple[bool, str]:
    """Check session revocation, absolute timeout, and idle timeout."""
    current = _ensure_utc(now or datetime.now(UTC))
    if record.revoked_at is not None:
        return False, "session_revoked"
    if current >= _ensure_utc(record.expires_at):
        return False, "session_expired_absolute"
    idle_deadline = _ensure_utc(record.last_active_at) + timedelta(
        seconds=settings.session_idle_timeout_seconds
    )
    if current >= idle_deadline:
        return False, "session_expired_idle"
    return True, "ok"


def generate_totp_enrollment(
    username: str,
    vault: EnvelopeVault,
) -> tuple[str, str, str, list[str], list[str]]:
    """Generate TOTP secret, encrypted secret, QR PNG data-URI, and 8 recovery codes."""
    secret = pyotp.random_base32()
    encrypted = vault.encrypt(secret, associated_data="totp-secret")
    totp = pyotp.TOTP(secret)
    uri = totp.provisioning_uri(name=username, issuer_name="Odysseus")

    qr = qrcode.QRCode(version=1, box_size=6, border=2)
    qr.add_data(uri)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    qr_data_uri = "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode("ascii")

    recovery_codes = [
        f"{secrets.token_hex(2).upper()}-{secrets.token_hex(2).upper()}" for _ in range(8)
    ]
    recovery_hashes = [sha256_hex(code) for code in recovery_codes]
    return secret, encrypted, qr_data_uri, recovery_codes, recovery_hashes


def verify_totp_or_recovery(
    user: User,
    code: str,
    vault: EnvelopeVault,
) -> tuple[bool, bool]:
    """Verify a TOTP 6-digit code or single-use recovery code.

    Returns (verified, used_recovery_code).
    """
    normalized = code.strip().upper()
    if user.totp_secret_encrypted:
        secret = vault.decrypt(user.totp_secret_encrypted, associated_data="totp-secret")
        totp = pyotp.TOTP(secret)
        if totp.verify(normalized, valid_window=1):
            return True, False

    candidate_hash = sha256_hex(normalized)
    remaining: list[str] = []
    matched = False
    for existing_hash in user.recovery_codes_hashes:
        if not matched and constant_time_equals(existing_hash, candidate_hash):
            matched = True
        else:
            remaining.append(existing_hash)
    if matched:
        user.recovery_codes_hashes = remaining
        return True, True
    return False, False


async def mint_api_token(
    uow: UnitOfWork,
    *,
    user: User,
    name: str,
    scopes: list[str],
    expires_in_days: int | None = 30,
    caller_scopes: frozenset[str] | None = None,
) -> tuple[str, ApiToken]:
    """Create a scoped, expiring API token (`ody_<random>`) and store only its SHA-256 hash.

    Scope-escalation defense: a new token may only carry scopes the *user* holds, and when
    it is minted by a bearer token (`caller_scopes` provided) only scopes that calling token
    already has — so a leaked narrow `chat` token can never mint `shell`/`admin` tokens.
    """
    user_privs = {p.privilege for p in user.privileges}
    invalid_scopes = [s for s in scopes if s not in user_privs]
    if invalid_scopes:
        raise ValueError(
            f"Cannot grant scopes not held by user: {', '.join(sorted(invalid_scopes))}"
        )
    if caller_scopes is not None:
        escalated = [s for s in scopes if s not in caller_scopes]
        if escalated:
            raise ValueError(
                "Cannot grant scopes exceeding the calling token's scopes: "
                f"{', '.join(sorted(escalated))}"
            )
    raw_secret = f"ody_{secrets.token_urlsafe(32)}"
    now = datetime.now(UTC)
    expires_at = now + timedelta(days=expires_in_days) if expires_in_days is not None else None
    record = ApiToken(
        id=f"tok_{uuid.uuid4().hex[:16]}",
        user_id=user.id,
        name=name,
        token_prefix=raw_secret[:12],
        token_hash=sha256_hex(raw_secret),
        scopes=sorted(set(scopes)),
        expires_at=expires_at,
        last_used_at=None,
        revoked_at=None,
        created_at=now,
    )
    await uow.api_tokens.add(record)
    return raw_secret, record
