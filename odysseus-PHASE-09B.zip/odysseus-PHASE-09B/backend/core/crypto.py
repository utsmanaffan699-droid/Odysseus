"""Envelope encryption for secrets at rest (AES-256-GCM + Master Key / KMS hook)."""

from __future__ import annotations

import base64
import hashlib
import json
import os
import secrets
from collections.abc import Callable
from pathlib import Path
from typing import Any

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

ENVELOPE_VERSION = 1

# Key ids are derived from the KEK itself, making rotation observable in the envelope.
KID_LENGTH = 12
# Number of rotated-out KEKs kept so old envelopes stay decryptable (and re-wrappable).
MAX_PREVIOUS_KEKS = 8
_OVERRIDE_SALT = b"odysseus.master-key.v1"
_OVERRIDE_ITERATIONS = 600_000


class MasterKeyMissingError(RuntimeError):
    """Raised when `master.key` is gone while the data directory still holds vault data."""


class UnknownKeyIdError(ValueError):
    """Raised when an envelope references a key id that is not in the keyring."""


def _derive_kek_from_override(override: str) -> bytes:
    """Derive a 256-bit KEK from a human-supplied secret with PBKDF2-HMAC-SHA256.

    A bare `sha256(secret)` is a fingerprint, not a KDF: it offers no work factor against
    an attacker who obtains the override value. PBKDF2 with an explicit iteration count
    makes offline guessing expensive while remaining deterministic (same override -> same
    KEK, so restarting the process keeps existing envelopes decryptable).
    """
    return hashlib.pbkdf2_hmac(
        "sha256",
        override.encode("utf-8"),
        _OVERRIDE_SALT,
        _OVERRIDE_ITERATIONS,
        dklen=32,
    )


def _kid_for(kek: bytes) -> str:
    digest = hashlib.sha256(kek).digest()
    return base64.urlsafe_b64encode(digest).decode("ascii")[:KID_LENGTH]


def _atomic_write_private(path: Path, data: bytes) -> None:
    """Write `data` to `path` atomically with 0600 permissions and fsync durability."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = path.with_name(f".{path.name}.tmp-{secrets.token_hex(6)}")
    fd = os.open(
        str(tmp_path),
        os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_CLOEXEC", 0),
        0o600,
    )
    try:
        os.write(fd, data)
        os.fsync(fd)
    finally:
        os.close(fd)
    os.chmod(tmp_path, 0o600)
    os.replace(tmp_path, path)
    # fsync the directory so the rename itself survives a crash.
    try:
        dir_fd = os.open(str(path.parent), os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
    except OSError:
        return
    try:
        os.fsync(dir_fd)
    finally:
        os.close(dir_fd)


def _aad_for(associated_data: str, kid: str) -> bytes:
    """Bind the caller's context to the envelope version and key id.

    A single constant AAD let an attacker with write access to the store move a ciphertext
    between contexts (e.g. a token valid for `secret:A` replayed as `secret:B`) and left the
    key id unauthenticated. Binding context + version + kid makes every envelope
    context-specific and ties it to the exact KEK that wrapped it.
    """
    return f"{associated_data}\x1fv={ENVELOPE_VERSION}\x1fkid={kid}".encode("utf-8")


class EnvelopeVault:
    """Envelope encryption service using AES-256-GCM.

    A 256-bit Master Key (KEK) stored in `data/master.key` with 0600 permissions
    (or provided via an external KMS hook) wraps a unique per-secret 256-bit
    Data Encryption Key (DEK). The DEK encrypts the plaintext payload.

    Hardening properties:

    * `master.key` is created with ``O_CREAT|O_EXCL`` and fsynced: two processes racing at
      first boot cannot silently overwrite each other's key (the loser adopts the winner's).
    * A missing `master.key` while the data directory holds state raises
      :class:`MasterKeyMissingError` instead of silently minting a fresh key and stranding
      every existing envelope.
    * Rotation writes `master.key` atomically and persists rotated-out KEKs to
      `master.key.prev`, so envelopes wrapped by an older key keep decrypting after a
      restart (previously the previous-key list lived only in memory).
    * Every envelope carries a `kid`; decryption selects the matching KEK from the keyring.
    """

    def __init__(
        self,
        data_dir: Path,
        *,
        master_key_override: str | None = None,
        kms_wrap_hook: Callable[[bytes], bytes] | None = None,
        kms_unwrap_hook: Callable[[bytes], bytes] | None = None,
        allow_regenerate: bool | None = None,
    ) -> None:
        self._data_dir = data_dir
        self._key_path = data_dir / "master.key"
        self._prev_key_path = data_dir / "master.key.prev"
        # Sentinel proving a KEK once lived in this data directory. It lets a missing
        # master.key be distinguished from "directory simply has other files in it",
        # so refusing to regenerate never produces false positives.
        self._sentinel_path = data_dir / ".vault_initialized"
        self._kms_wrap_hook = kms_wrap_hook
        self._kms_unwrap_hook = kms_unwrap_hook
        if allow_regenerate is None:
            allow_regenerate = os.environ.get("ODYSSEUS_ALLOW_MASTER_KEY_RECREATE", "") in (
                "1",
                "true",
                "True",
            )
        self._allow_regenerate = allow_regenerate
        self._persisted = master_key_override is None
        self._keyring: dict[str, bytes] = {}
        if master_key_override:
            kek = _derive_kek_from_override(master_key_override)
            self._keyring[_kid_for(kek)] = kek
        else:
            self._load_or_create_keys()
        self._current_kid = next(iter(self._keyring))

    # ------------------------------------------------------------------ key lifecycle

    def _keyring_file_entries(self) -> list[dict[str, str]]:
        return [
            {"kid": kid, "key": base64.urlsafe_b64encode(kek).decode("ascii")}
            for kid, kek in self._keyring.items()
        ]

    def _persist_previous_keys(self) -> None:
        entries = self._keyring_file_entries()[1:]
        if not entries:
            return
        _atomic_write_private(
            self._prev_key_path,
            json.dumps(entries, separators=(",", ":")).encode("utf-8"),
        )

    def _load_or_create_keys(self) -> None:
        current: bytes | None = None
        self._data_dir.mkdir(parents=True, exist_ok=True)
        if self._key_path.exists():
            try:
                os.chmod(self._key_path, 0o600)
            except OSError:
                pass
            self._mark_initialized()
            raw = self._key_path.read_bytes().strip()
            decoded = base64.urlsafe_b64decode(raw)
            if len(decoded) != 32:
                raise ValueError("Corrupted master.key: expected 32 bytes after base64 decode")
            current = decoded
        else:
            if self._sentinel_path.exists() and not self._allow_regenerate:
                raise MasterKeyMissingError(
                    f"master.key is missing from {self._data_dir}, which still contains vault "
                    "data. Refusing to generate a new key (that would make every stored "
                    "secret unreadable). Restore the key from backup, or set "
                    "ODYSSEUS_ALLOW_MASTER_KEY_RECREATE=1 to explicitly start over."
                )
            current = self._create_key_exclusive()
            self._mark_initialized()
            if current is None:
                # Another process won the creation race: adopt its key.
                raw = self._key_path.read_bytes().strip()
                current = base64.urlsafe_b64decode(raw)
                if len(current) != 32:
                    raise ValueError("Corrupted master.key: expected 32 bytes after base64 decode")

        self._keyring[_kid_for(current)] = current
        if self._prev_key_path.exists():
            try:
                entries = json.loads(self._prev_key_path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                entries = []
            for entry in entries[:MAX_PREVIOUS_KEKS]:
                try:
                    kek = base64.urlsafe_b64decode(entry["key"])
                except (KeyError, ValueError):
                    continue
                if len(kek) != 32:
                    continue
                self._keyring.setdefault(str(entry.get("kid") or _kid_for(kek)), kek)

    def _mark_initialized(self) -> None:
        """Record that this data directory has (or had) a KEK, for the missing-key guard."""
        try:
            if not self._sentinel_path.exists():
                _atomic_write_private(
                    self._sentinel_path,
                    b"odysseus envelope vault initialized\n",
                )
        except OSError:
            # Never fail startup because of a bookkeeping file.
            pass

    def _create_key_exclusive(self) -> bytes | None:
        new_kek = secrets.token_bytes(32)
        encoded = base64.urlsafe_b64encode(new_kek)
        try:
            fd = os.open(
                str(self._key_path),
                os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_CLOEXEC", 0),
                0o600,
            )
        except FileExistsError:
            return None
        try:
            os.write(fd, encoded)
            os.fsync(fd)
        finally:
            os.close(fd)
        os.chmod(self._key_path, 0o600)
        return new_kek

    @property
    def current_kid(self) -> str:
        return self._current_kid

    def rotate_master_key(self, new_kek_bytes: bytes | None = None) -> str:
        """Rotate the master KEK atomically, keeping previous KEKs for re-wrapping.

        Returns the new key id. Old KEKs are persisted to `master.key.prev` so envelopes
        wrapped before the rotation remain decryptable after a process restart.
        """
        if new_kek_bytes is not None and len(new_kek_bytes) != 32:
            raise ValueError("new KEK must be exactly 32 bytes")
        if not self._key_path.exists() and not self._keyring:
            raise MasterKeyMissingError("Cannot rotate: no keyring loaded")
        old_kid = self._current_kid
        new_kek = new_kek_bytes if new_kek_bytes is not None else secrets.token_bytes(32)
        new_kid = _kid_for(new_kek)
        # Order: new current first, then previous (most recent first), capped.
        ordered = [(new_kid, new_kek)] + [
            (kid, kek) for kid, kek in self._keyring.items() if kid != new_kid
        ]
        self._keyring = dict(ordered[: MAX_PREVIOUS_KEKS + 1])
        self._current_kid = new_kid
        if self._persisted:
            _atomic_write_private(self._key_path, base64.urlsafe_b64encode(new_kek))
            self._persist_previous_keys()
        _ = old_kid
        return new_kid

    def _kek_for_kid(self, kid: str | None) -> bytes:
        if kid is None:
            # Legacy envelope without a key id: fall back to the current KEK.
            return next(iter(self._keyring.values()))
        kek = self._keyring.get(kid)
        if kek is None:
            raise UnknownKeyIdError(
                f"Envelope references unknown key id {kid!r}; available: {sorted(self._keyring)}"
            )
        return kek

    # ------------------------------------------------------------------- encryption

    def encrypt(self, plaintext: str, *, associated_data: str = "") -> str:
        """Encrypt a secret string into a versioned envelope token."""
        dek = secrets.token_bytes(32)
        dek_nonce = secrets.token_bytes(12)
        data_nonce = secrets.token_bytes(12)
        kid = self._current_kid
        aad = _aad_for(associated_data, kid)

        data_cipher = AESGCM(dek).encrypt(data_nonce, plaintext.encode("utf-8"), aad)
        if self._kms_wrap_hook is not None:
            wrapped_dek = self._kms_wrap_hook(dek)
        else:
            wrapped_dek = AESGCM(self._kek_for_kid(kid)).encrypt(dek_nonce, dek, aad)

        envelope: dict[str, Any] = {
            "v": ENVELOPE_VERSION,
            "alg": "AES-256-GCM",
            "kid": kid,
            "dn": base64.urlsafe_b64encode(dek_nonce).decode("ascii"),
            "wd": base64.urlsafe_b64encode(wrapped_dek).decode("ascii"),
            "cn": base64.urlsafe_b64encode(data_nonce).decode("ascii"),
            "ct": base64.urlsafe_b64encode(data_cipher).decode("ascii"),
        }
        serialized = json.dumps(envelope, separators=(",", ":"), sort_keys=True).encode("utf-8")
        return base64.urlsafe_b64encode(serialized).decode("ascii")

    def decrypt(self, token: str, *, associated_data: str = "") -> str:
        """Decrypt a versioned envelope token back into plaintext."""
        raw_json = base64.urlsafe_b64decode(token.encode("ascii"))
        envelope = json.loads(raw_json.decode("utf-8"))
        if envelope.get("v") != ENVELOPE_VERSION:
            raise ValueError(f"Unsupported envelope version: {envelope.get('v')}")

        kid = envelope.get("kid")
        # Legacy envelopes (no kid) were bound to the then-current key id.
        aad = _aad_for(associated_data, str(kid) if kid else self._current_kid)

        dek_nonce = base64.urlsafe_b64decode(envelope["dn"])
        wrapped_dek = base64.urlsafe_b64decode(envelope["wd"])
        data_nonce = base64.urlsafe_b64decode(envelope["cn"])
        ciphertext = base64.urlsafe_b64decode(envelope["ct"])

        if self._kms_unwrap_hook is not None:
            dek = self._kms_unwrap_hook(wrapped_dek)
        else:
            if kid is None:
                dek = self._unwrap_dek_with_keyring(dek_nonce, wrapped_dek, aad)
            else:
                kek = self._kek_for_kid(str(kid))
                dek = AESGCM(kek).decrypt(dek_nonce, wrapped_dek, aad)

        plaintext_bytes = AESGCM(dek).decrypt(data_nonce, ciphertext, aad)
        return plaintext_bytes.decode("utf-8")

    def _unwrap_dek_with_keyring(self, dek_nonce: bytes, wrapped_dek: bytes, aad: bytes) -> bytes:
        last_err: Exception | None = None
        for candidate_kek in self._keyring.values():
            try:
                return AESGCM(candidate_kek).decrypt(dek_nonce, wrapped_dek, aad)
            except Exception as exc:
                last_err = exc
        raise ValueError("Failed to unwrap DEK with current or previous master keys") from last_err

    def rewrap_token(self, token: str, *, associated_data: str = "") -> str:
        """Re-encrypt an existing envelope token under the current master KEK."""
        plaintext = self.decrypt(token, associated_data=associated_data)
        return self.encrypt(plaintext, associated_data=associated_data)
