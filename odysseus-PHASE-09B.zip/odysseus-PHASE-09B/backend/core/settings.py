"""Layered configuration and strict validation for Odysseus."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, ClassVar, Literal

from pydantic import BaseModel, Field, ValidationError, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class SettingsConfigurationError(ValueError):
    """Raised when one or more configuration values are invalid.

    Lists every configuration problem at once in a human-readable format.
    """

    def __init__(self, problems: list[str]) -> None:
        self.problems = problems
        header = f"Invalid Odysseus configuration ({len(problems)} problem(s) found):"
        bullet_list = "\n".join(f"  - {p}" for p in problems)
        super().__init__(f"{header}\n{bullet_list}")


def parse_dotenv_utf8_sig(env_path: Path) -> dict[str, str]:
    """Parse a .env file encoded in UTF-8 (with or without BOM) and LF/CRLF line endings."""
    if not env_path.exists():
        return {}
    raw = env_path.read_text(encoding="utf-8-sig")
    parsed: dict[str, str] = {}
    for raw_line in raw.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[len("export ") :].strip()
        if "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
            value = value[1:-1]
        if key:
            parsed[key] = value
    return parsed


class Settings(BaseSettings):
    """Application settings with strict positive-integer and cross-field validation."""

    model_config = SettingsConfigDict(
        env_prefix="ODYSSEUS_",
        extra="ignore",
        validate_default=True,
    )

    RUNTIME_EDITABLE_KEYS: ClassVar[frozenset[str]] = frozenset(
        {
            "session_idle_timeout_seconds",
            "session_absolute_timeout_seconds",
            "rate_limit_requests_per_minute",
            "rate_limit_burst",
            "login_max_attempts_per_ip",
            "login_max_attempts_per_user",
            "default_model",
            "otel_enabled",
            "memory_enabled",
            "memory_auto_confirm",
        }
    )

    SECRET_KEYS: ClassVar[frozenset[str]] = frozenset(
        {
            "master_key_override",
            "canary_secret",
            "openai_api_key",
            "anthropic_api_key",
            "gemini_api_key",
            "smtp_password",
            "imap_password",
        }
    )

    # Environment & Server
    environment: Literal["development", "test", "staging", "production"] = "production"
    bind_host: str = Field(default="127.0.0.1", min_length=1)
    port: int = Field(default=8000, gt=0, le=65535)
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = "INFO"
    data_dir: Path = Field(default=Path("./data"))
    logs_dir: Path = Field(default=Path("./logs"))
    frontend_dist_dir: Path = Field(default=Path("./frontend/dist"))

    # Admin Bootstrap
    admin_user: str = Field(default="admin", min_length=2, max_length=64)
    admin_email: str = Field(default="admin@odysseus.local", min_length=3, max_length=255)

    # Database
    database_url: str = Field(
        default="sqlite+aiosqlite:///./data/odysseus.db",
        min_length=8,
    )
    db_pool_size: int = Field(default=10, gt=0, le=500)
    db_max_overflow: int = Field(default=20, gt=0, le=500)
    db_busy_timeout_ms: int = Field(default=30000, gt=0, le=600000)

    # Authentication & Sessions
    session_idle_timeout_seconds: int = Field(default=3600, gt=0, le=2592000)
    session_absolute_timeout_seconds: int = Field(default=86400, gt=0, le=7776000)
    login_max_attempts_per_ip: int = Field(default=10, gt=0, le=1000)
    login_max_attempts_per_user: int = Field(default=5, gt=0, le=1000)
    login_window_seconds: int = Field(default=300, gt=0, le=86400)
    login_base_lockout_seconds: int = Field(default=30, gt=0, le=86400)
    totp_max_attempts: int = Field(default=5, gt=0, le=100)
    cookie_secure: bool = False
    # ClamAV (clamd INSTREAM over TCP). Enabled by default in the reference deployment:
    # uploads are the main ingress for hostile files, and fail-closed scanning rejects
    # uploads when clamd is enabled but unreachable. Set ODYSSEUS_CLAMAV_ENABLED=false
    # only when no clamd sidecar is deployed.
    clamav_enabled: bool = False
    clamav_host: str = Field(default="127.0.0.1", min_length=1, max_length=255)
    clamav_port: int = Field(default=3310, ge=1, le=65535)
    session_cookie_name: str = Field(default="odysseus_session", min_length=3, max_length=64)

    # Network, CORS, Proxies & Request Limits
    allowed_hosts: list[str] = Field(
        default_factory=lambda: ["127.0.0.1", "localhost", "testserver"]
    )
    allowed_origins: list[str] = Field(
        default_factory=lambda: [
            "http://127.0.0.1:8000",
            "http://localhost:8000",
            "http://127.0.0.1:5173",
            "http://localhost:5173",
        ]
    )
    trusted_proxies: list[str] = Field(default_factory=lambda: ["127.0.0.1", "::1"])
    max_header_bytes: int = Field(default=16384, gt=0, le=1048576)
    max_header_count: int = Field(default=100, gt=0, le=1000)
    max_body_bytes_default: int = Field(default=2097152, gt=0, le=1073741824)
    max_body_bytes_auth: int = Field(default=65536, gt=0, le=10485760)
    max_body_bytes_upload: int = Field(default=52428800, gt=0, le=5368709120)
    request_read_timeout_seconds: int = Field(default=15, gt=0, le=600)

    # Rate Limiting
    rate_limit_requests_per_minute: int = Field(default=300, gt=0, le=1000000)
    rate_limit_burst: int = Field(default=60, gt=0, le=100000)

    # Background Jobs & Run Supervisor
    job_worker_concurrency: int = Field(default=4, gt=0, le=128)
    job_lease_seconds: int = Field(default=30, gt=0, le=3600)
    job_heartbeat_seconds: int = Field(default=10, gt=0, le=1800)
    job_max_attempts: int = Field(default=3, gt=0, le=50)
    sse_keepalive_seconds: int = Field(default=15, gt=0, le=300)
    sse_max_lag_events: int = Field(default=500, gt=0, le=100000)
    sse_max_chunk_bytes: int = Field(default=8192, gt=0, le=65536)
    max_sse_connections_per_user: int = Field(default=16, gt=0, le=1024)
    max_concurrent_runs_global: int = Field(default=64, gt=0, le=4096)
    max_concurrent_runs_per_user: int = Field(default=8, gt=0, le=512)
    delta_coalesce_interval_ms: int = Field(default=20, ge=0, le=5000)

    # Provider Resilience & Timeouts
    provider_connect_timeout_seconds: float = Field(default=5.0, gt=0.0, le=120.0)
    provider_read_timeout_seconds: float = Field(default=30.0, gt=0.0, le=600.0)
    provider_total_timeout_seconds: float = Field(default=120.0, gt=0.0, le=3600.0)
    provider_max_retries: int = Field(default=3, ge=0, le=10)
    provider_circuit_breaker_threshold: int = Field(default=3, gt=0, le=100)
    provider_circuit_breaker_cooldown_seconds: float = Field(default=30.0, gt=0.0, le=3600.0)
    capture_raw_exchanges: bool = False
    raw_exchange_ttl_seconds: int = Field(default=3600, gt=0, le=604800)

    # Optional External Services & Defaults
    default_model: str = Field(default="fake/default", min_length=1)
    chromadb_url: str = Field(default="http://127.0.0.1:8100", min_length=7)
    searxng_url: str = Field(default="http://127.0.0.1:8080", min_length=7)
    ntfy_url: str = Field(default="http://127.0.0.1:8090", min_length=7)
    otel_enabled: bool = False
    otel_endpoint: str = Field(default="http://127.0.0.1:4318", min_length=7)
    oauth_redirect_base_url: str = Field(default="http://127.0.0.1:8000", min_length=7)

    # Agent Runtime, Tool Sandbox, Memory & Sub-agents
    agent_approval_timeout_seconds: float = Field(default=300.0, gt=0.0, le=86400.0)
    agent_background_approval_timeout_seconds: float = Field(default=5.0, gt=0.0, le=3600.0)
    agent_max_parallel_read_tools: int = Field(default=4, gt=0, le=32)
    agent_loop_breaker_threshold: int = Field(default=3, ge=2, le=20)
    agent_max_subagent_depth: int = Field(default=2, ge=1, le=5)
    agent_max_subagent_fanout: int = Field(default=4, ge=1, le=16)
    tool_default_timeout_seconds: float = Field(default=15.0, gt=0.0, le=600.0)
    tool_max_output_bytes: int = Field(default=65536, gt=0, le=10485760)
    tool_model_view_bytes: int = Field(default=4096, gt=0, le=262144)
    sandbox_backend: Literal["subprocess_rlimit", "bwrap", "docker"] = "subprocess_rlimit"
    sandbox_cpu_seconds: int = Field(default=5, gt=0, le=300)
    sandbox_max_fsize_bytes: int = Field(default=10485760, gt=0, le=1073741824)
    sandbox_max_nproc: int = Field(default=32, gt=0, le=4096)
    sandbox_max_memory_bytes: int = Field(default=1073741824, gt=0, le=68719476736)
    # Explicit, loud opt-in required to run shell/python tools WITHOUT kernel isolation
    # in `environment=production`. Default False = fail closed.
    allow_unsandboxed_exec: bool = False
    # Per-workspace disk quota enforced by the file tools (write_file/edit_file).
    workspace_quota_bytes: int = Field(default=268435456, gt=0, le=107374182400)
    memory_enabled: bool = True
    memory_auto_confirm: bool = False

    # Optional Secrets (always redacted in logs/diagnostics)
    master_key_override: str | None = Field(default=None)
    canary_secret: str | None = Field(default=None)
    openai_api_key: str | None = Field(default=None)
    anthropic_api_key: str | None = Field(default=None)
    gemini_api_key: str | None = Field(default=None)
    smtp_password: str | None = Field(default=None)
    imap_password: str | None = Field(default=None)

    @field_validator("admin_email")
    @classmethod
    def _validate_email(cls, v: str) -> str:
        if "@" not in v or v.startswith("@") or v.endswith("@"):
            raise ValueError("admin_email must be a valid email address containing '@'")
        return v

    @field_validator("database_url")
    @classmethod
    def _validate_db_url(cls, v: str) -> str:
        allowed_prefixes = (
            "sqlite+aiosqlite://",
            "sqlite://",
            "postgresql+asyncpg://",
            "postgresql+psycopg://",
            "postgresql://",
        )
        if not v.startswith(allowed_prefixes):
            raise ValueError(f"database_url must start with one of {', '.join(allowed_prefixes)}")
        return v

    @field_validator("chromadb_url", "searxng_url", "ntfy_url", "otel_endpoint")
    @classmethod
    def _validate_http_url(cls, v: str) -> str:
        if not (v.startswith("http://") or v.startswith("https://")):
            raise ValueError("service URL must start with http:// or https://")
        return v

    @field_validator("allowed_hosts")
    @classmethod
    def _validate_allowed_hosts(cls, v: list[str]) -> list[str]:
        if not v:
            raise ValueError("allowed_hosts must contain at least one host")
        for host in v:
            if not host or " " in host or "/" in host:
                raise ValueError(f"invalid host in allowed_hosts: {host!r}")
        return v

    @field_validator("allowed_origins")
    @classmethod
    def _validate_allowed_origins(cls, v: list[str]) -> list[str]:
        for origin in v:
            if origin == "*":
                raise ValueError("wildcard '*' is not permitted in allowed_origins")
            if not (origin.startswith("http://") or origin.startswith("https://")):
                raise ValueError(f"invalid origin in allowed_origins: {origin!r}")
        return v

    @model_validator(mode="after")
    def _validate_cross_fields(self) -> Settings:
        problems: list[str] = []
        if self.session_absolute_timeout_seconds < self.session_idle_timeout_seconds:
            problems.append(
                "session_absolute_timeout_seconds must be >= session_idle_timeout_seconds"
            )
        if self.job_lease_seconds <= self.job_heartbeat_seconds:
            problems.append("job_lease_seconds must be strictly greater than job_heartbeat_seconds")
        if self.max_body_bytes_upload < self.max_body_bytes_default:
            problems.append("max_body_bytes_upload must be >= max_body_bytes_default")
        if problems:
            raise ValueError("; ".join(problems))
        return self

    def production_warnings(self) -> list[str]:
        """Return non-fatal hardening warnings to surface loudly at startup."""
        warnings: list[str] = []
        if self.environment == "production" and not self.cookie_secure:
            warnings.append(
                "cookie_secure=False in a production deployment: session cookies can be "
                "captured over plain HTTP. Terminate TLS and set ODYSSEUS_COOKIE_SECURE=true."
            )
        if self.environment == "production" and self.rate_limit_requests_per_minute >= 600:
            warnings.append(
                "rate_limit_requests_per_minute is very high (>=600); login and API abuse "
                "protection is weakened."
            )
        if self.environment == "production" and not self.trusted_proxies:
            warnings.append(
                "trusted_proxies is empty: client IPs behind a reverse proxy will all "
                "collapse to the proxy address, sharing one rate-limit bucket."
            )
        return warnings

    def exec_isolation_posture_error(self) -> str | None:
        """Return a human-readable reason when exec tools must be refused, else None.

        Fail-closed posture rules:
        - ``docker`` backend is unimplemented -> always refuse.
        - ``bwrap`` backend without the binary installed -> refuse.
        - ``subprocess_rlimit`` (no filesystem/network isolation) in ``production``
          -> refuse unless the operator explicitly sets ``allow_unsandboxed_exec=True``.
        """
        if self.sandbox_backend == "docker":
            return (
                "sandbox_backend='docker' is not implemented; refusing to execute agent "
                "shell/python tools. Select 'bwrap' (recommended) or explicitly opt in to "
                "'subprocess_rlimit' in non-production environments."
            )
        if self.sandbox_backend == "bwrap":
            import shutil as _shutil

            if _shutil.which("bwrap") is None:
                return (
                    "sandbox_backend='bwrap' selected but the bubblewrap binary is not "
                    "installed; refusing to execute agent shell/python tools."
                )
            return None
        if self.environment == "production" and not self.allow_unsandboxed_exec:
            return (
                "sandbox_backend='subprocess_rlimit' provides no filesystem or network "
                "isolation and is refused in environment='production'. Use "
                "sandbox_backend='bwrap', or set allow_unsandboxed_exec=true to accept "
                "the risk explicitly."
            )
        return None

    def redacted_dict(self) -> dict[str, Any]:
        """Return settings dictionary with all secret keys replaced by '[REDACTED]'."""
        raw = self.model_dump(mode="json")
        for key in list(raw.keys()):
            if (
                key in self.SECRET_KEYS
                or "secret" in key.lower()
                or "password" in key.lower()
                or "key" in key.lower()
                or "token" in key.lower()
            ):
                if raw[key] is not None:
                    raw[key] = "[REDACTED]"
        return raw

    def collect_secret_values(self) -> list[str]:
        """Return non-empty secret values for active log/diagnostic scrubbing."""
        values: list[str] = []
        for key in self.SECRET_KEYS:
            val = getattr(self, key, None)
            if isinstance(val, str) and len(val) >= 4:
                values.append(val)
        return values

    def apply_runtime_overrides(self, overrides: dict[str, Any]) -> Settings:
        """Return a new validated Settings instance with non-secret DB overrides applied."""
        filtered: dict[str, Any] = {}
        for k, v in overrides.items():
            if k in self.SECRET_KEYS:
                raise ValueError(f"Secret key '{k}' cannot be overridden via runtime settings")
            if k not in self.RUNTIME_EDITABLE_KEYS:
                raise ValueError(f"Key '{k}' is not runtime-editable")
            filtered[k] = v
        merged = self.model_dump()
        merged.update(filtered)
        return load_settings(overrides=merged, env_file=None, ignore_process_env=True)


def load_settings(
    *,
    env_file: Path | str | None = Path(".env"),
    overrides: dict[str, Any] | None = None,
    ignore_process_env: bool = False,
) -> Settings:
    """Load layered configuration and aggregate ALL validation errors into a readable error."""
    layered: dict[str, Any] = {}

    if env_file is not None:
        env_path = Path(env_file)
        if env_path.exists():
            dotenv_vars = parse_dotenv_utf8_sig(env_path)
            for k, v in dotenv_vars.items():
                if k.startswith("ODYSSEUS_"):
                    field_name = k[len("ODYSSEUS_") :].lower()
                    layered[field_name] = _coerce_json_if_list(field_name, v)

    if not ignore_process_env:
        for k, v in os.environ.items():
            if k.startswith("ODYSSEUS_"):
                field_name = k[len("ODYSSEUS_") :].lower()
                layered[field_name] = _coerce_json_if_list(field_name, v)

    if overrides:
        for k, v in overrides.items():
            field_name = k[len("ODYSSEUS_") :].lower() if k.startswith("ODYSSEUS_") else k.lower()
            layered[field_name] = _coerce_json_if_list(field_name, v)

    try:
        return Settings(**layered)
    except ValidationError as exc:
        problems: list[str] = []
        for err in exc.errors():
            loc = ".".join(str(part) for part in err.get("loc", ())) or "settings"
            msg = err.get("msg", "Invalid value")
            inp = err.get("input")
            if any(s in loc.lower() for s in ("secret", "password", "key", "token")):
                inp_repr = "[REDACTED]"
            else:
                inp_repr = repr(inp)
            problems.append(f"ODYSSEUS_{loc.upper()} (got {inp_repr}): {msg}")
        raise SettingsConfigurationError(problems) from exc


def _coerce_json_if_list(field_name: str, value: Any) -> Any:
    if isinstance(value, str) and field_name in {
        "allowed_hosts",
        "allowed_origins",
        "trusted_proxies",
    }:
        stripped = value.strip()
        if stripped.startswith("["):
            try:
                return json.loads(stripped)
            except json.JSONDecodeError:
                return value
        return [item.strip() for item in stripped.split(",") if item.strip()]
    return value


class SettingsFormSchema(BaseModel):
    """JSON Schema wrapper for schema-driven settings UI."""

    json_schema: dict[str, Any]
    editable_keys: list[str]
