"""Attachment ownership + upload integrity: attachment_owners table, upload_sessions.expected_sha256.

Revision ID: 0004_attachment_ownership
Revises: 0003_phase03_agent_engine
Create Date: 2026-10-04 15:00:00
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "0004_attachment_ownership"
down_revision: str | None = "0003_phase03_agent_engine"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.add_column(
        "upload_sessions",
        sa.Column("expected_sha256", sa.String(length=64), nullable=True),
    )
    op.create_table(
        "attachment_owners",
        sa.Column("sha256", sa.String(length=64), nullable=False),
        sa.Column("user_id", sa.String(length=64), nullable=False),
        sa.Column("filename", sa.String(length=255), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["sha256"], ["attachments.sha256"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("sha256", "user_id"),
    )
    op.create_index("ix_attachment_owners_user_id", "attachment_owners", ["user_id"])
    # Backfill: existing attachments keep being visible to their original uploader.
    op.execute(
        "INSERT INTO attachment_owners (sha256, user_id, filename, created_at) "
        "SELECT sha256, user_id, filename, created_at FROM attachments"
    )


def downgrade() -> None:
    op.drop_index("ix_attachment_owners_user_id", table_name="attachment_owners")
    op.drop_table("attachment_owners")
    op.drop_column("upload_sessions", "expected_sha256")
