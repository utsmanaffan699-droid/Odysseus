"""Odysseus CLI (`odysseus approvals | chat | todos | schedules | token`)."""

from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import UTC, datetime
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.brand import cli_banner
from backend.core.db import DatabaseManager
from backend.core.models import ApprovalRuleRecord
from backend.core.settings import Settings
from backend.core.uow import UnitOfWork
from backend.domain.admin_ops.service import AdminOpsService
from backend.domain.agents.loop import (
    ApprovalDecisionLiteral,
    ApprovalScopeLiteral,
    approval_to_dict,
)
from backend.domain.cookbook.service import CookbookService
from backend.domain.notes.service import NotesAndTodosService
from backend.domain.notifications.service import NotificationsAndWebhooksService
from backend.domain.schedules.service import SchedulerService
from backend.domain.tools.policy import suggest_structured_pattern


async def cli_list_approvals(
    settings: Settings,
    *,
    status: str | None = None,
    run_id: str | None = None,
) -> list[dict[str, Any]]:
    db = DatabaseManager(settings)
    try:

        async def _load(sess: AsyncSession) -> list[dict[str, Any]]:
            uow = UnitOfWork(sess)
            if run_id is not None:
                rows = await uow.approvals.list_by_run(run_id)
                if status is not None:
                    rows = [r for r in rows if r.status == status]
                return [approval_to_dict(r) for r in rows]
            users = await uow.users.list_users()
            all_rows = []
            for u in users:
                u_rows = await uow.approvals.list_for_user(u.id, status=status)
                all_rows.extend(u_rows)
            return [approval_to_dict(r) for r in all_rows]

        return await db.execute_read(_load)
    finally:
        await db.dispose()


async def cli_resolve_approval(
    settings: Settings,
    *,
    approval_id: str,
    decision: ApprovalDecisionLiteral,
    scope: ApprovalScopeLiteral = "once",
    pattern: str | None = None,
) -> dict[str, Any]:
    db = DatabaseManager(settings)
    now = datetime.now(UTC)
    try:

        async def _tx(sess: AsyncSession) -> dict[str, Any]:
            uow = UnitOfWork(sess)
            rec = await uow.approvals.get(approval_id)
            if rec is None:
                raise LookupError(f"Approval '{approval_id}' not found")
            effective_pat = (
                pattern
                or rec.pattern
                or rec.suggested_pattern
                or suggest_structured_pattern(rec.tool_name, rec.args_json)
            )
            rec.status = "approved" if decision == "approve" else "denied"
            rec.decision = decision
            rec.scope = scope
            rec.pattern = effective_pat
            rec.decided_at = now
            rec.decided_by = rec.user_id

            if decision == "approve" and scope in ("run", "chat", "always"):
                target_id = (
                    rec.run_id if scope == "run" else (rec.chat_id if scope == "chat" else None)
                )
                await uow.approvals.add_rule(
                    ApprovalRuleRecord(
                        id=f"arule_{approval_id[:16]}",
                        user_id=rec.user_id,
                        scope=scope,
                        scope_target_id=target_id,
                        tool_name=rec.tool_name,
                        pattern=effective_pat,
                        created_at=now,
                    )
                )

            await uow.audit.record(
                action="tool.approval.resolved",
                resource_type="approval",
                resource_id=approval_id,
                actor_user_id=rec.user_id,
                details={
                    "run_id": rec.run_id,
                    "call_id": rec.tool_call_id,
                    "tool_name": rec.tool_name,
                    "decision": decision,
                    "scope": scope,
                    "pattern": effective_pat,
                    "via": "cli",
                },
            )
            await uow.chats.append_run_event(
                run_id=rec.run_id,
                event_type="tool.approval.resolved",
                data={
                    "approval_id": approval_id,
                    "decision": decision,
                    "scope": scope,
                    "by": str(rec.user_id or "cli"),
                },
                ts=now.isoformat(),
            )
            return approval_to_dict(rec)

        return await db.execute_write(_tx)
    finally:
        await db.dispose()


def execute_cli_command(
    argv: list[str],
    *,
    notes_service: NotesAndTodosService | None = None,
    scheduler_service: SchedulerService | None = None,
    notifications_service: NotificationsAndWebhooksService | None = None,
) -> dict[str, Any]:
    """Execute an `odysseus` CLI command programmatically or from sys.argv."""
    parser = argparse.ArgumentParser(prog="odysseus", description=cli_banner())
    parser.add_argument("--no-color", action="store_true", help="Disable ANSI color output")
    parser.add_argument(
        "--token",
        default=os.environ.get("ODYSSEUS_API_TOKEN", ""),
        help="Scoped Odysseus API token",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    chat_p = sub.add_parser("chat", help="Send a prompt to the Odysseus agent runtime")
    chat_p.add_argument("prompt", help="Prompt text")

    todos_p = sub.add_parser("todos", help="List or create todos")
    todos_p.add_argument("action", choices=["list", "add"])
    todos_p.add_argument("title", nargs="?", default="CLI Task")

    sub.add_parser("schedules", help="List configured schedules")

    tok_p = sub.add_parser("token", help="Verify an API token")
    tok_p.add_argument("raw_token", help="Raw token to verify")

    cb_p = sub.add_parser("cookbook", help="Local models & hardware advisor CLI")
    cb_p.add_argument(
        "action",
        choices=["hw", "recommend", "download", "engines", "serve", "bench", "remotes"],
    )
    cb_p.add_argument("target", nargs="?", default="Qwen/Qwen2.5-0.5B-Instruct-GGUF")
    cb_p.add_argument("--dry-run", action="store_true", dest="dry_run")

    adm_p = sub.add_parser("admin", help="Admin backup/restore/support-bundle CLI")
    adm_p.add_argument("action", choices=["backup", "restore", "support-bundle"])
    adm_p.add_argument("--dry-run", action="store_true", dest="dry_run")

    args = parser.parse_args(argv)
    notes = notes_service or NotesAndTodosService()
    scheds = scheduler_service or SchedulerService()
    notifs = notifications_service or NotificationsAndWebhooksService()
    cookbook = CookbookService()
    admin_ops = AdminOpsService()

    if args.command == "chat":
        return {
            "ok": True,
            "command": "chat",
            "prompt": str(args.prompt),
            "reply": f"[Odysseus CLI] Executed prompt: {args.prompt}",
        }
    if args.command == "todos":
        if args.action == "add":
            created = notes.create_todo(owner_user_id="system", title=str(args.title))
            return {"ok": True, "command": "todos.add", "todo": created}
        return {"ok": True, "command": "todos.list", "todos": notes.list_todos()}
    if args.command == "schedules":
        return {"ok": True, "command": "schedules.list", "schedules": scheds.list_schedules()}
    if args.command == "token":
        ver = notifs.verify_api_token(str(args.raw_token))
        return {"ok": bool(ver.get("valid")), "command": "token.verify", "result": ver}
    if args.command == "cookbook":
        act = str(args.action)
        if act == "hw":
            hw = cookbook.get_hardware_snapshot()
            return {"ok": True, "command": "cookbook.hw", "hardware": hw}
        if act == "recommend":
            return {"ok": True, "command": "cookbook.recommend", "catalog": cookbook.list_models()}
        if act == "download":
            dl = cookbook.start_download(model_id=str(args.target), total_bytes=1_048_576)
            return {"ok": dl["state"] == "ready", "command": "cookbook.download", "download": dl}
        if act == "engines":
            eng = cookbook.install_engine("llama.cpp", dry_run=bool(args.dry_run))
            return {"ok": True, "command": "cookbook.engines", "engine": eng}
        if act == "serve":
            srv = cookbook.start_serve(model_id=str(args.target))
            return {"ok": srv["state"] == "healthy", "command": "cookbook.serve", "serve": srv}
        if act == "bench":
            bn = cookbook.run_benchmark(model_id=str(args.target))
            return {"ok": True, "command": "cookbook.bench", "benchmark": bn}
        return {"ok": True, "command": "cookbook.remotes", "remotes": cookbook.list_remotes()}
    if args.command == "admin":
        act = str(args.action)
        if act == "backup":
            bkp = admin_ops.create_backup()
            return {"ok": True, "command": "admin.backup", "backup_id": bkp["backup_id"]}
        if act == "restore":
            bkp = admin_ops.create_backup()
            rep = admin_ops.verify_or_restore_backup(
                bkp["archive_bytes"], dry_run=bool(args.dry_run)
            )
            return {"ok": True, "command": "admin.restore", "report": rep}
        bundle = admin_ops.generate_support_bundle()
        return {"ok": True, "command": "admin.support-bundle", "bundle_id": bundle["bundle_id"]}

    return {"ok": False, "error": "unknown_command"}


def main() -> int:
    res = execute_cli_command(sys.argv[1:])
    print(json.dumps(res, indent=2))
    return 0 if res.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
