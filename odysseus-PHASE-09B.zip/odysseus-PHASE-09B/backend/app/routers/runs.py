"""Chats, message trees, projects, durable runs, SSE streaming, uploads, usage, and debug client."""

from __future__ import annotations

import json
import uuid
from datetime import UTC, datetime
from typing import Any
from urllib.parse import quote

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from fastapi.responses import HTMLResponse, StreamingResponse
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.brand import render_branded_export_html
from backend.core.db import DatabaseManager
from backend.core.logging import run_id_var
from backend.core.models import ChatRecord
from backend.core.security import Principal, register_route_policy, require
from backend.core.uow import UnitOfWork, _ensure_utc
from backend.domain.chats import (
    AttachmentService,
    AttachmentValidationError,
    ChatService,
    MessageTreeError,
    PromptBuilder,
    PromptSectionBudget,
    estimate_tokens,
    search_chats_and_messages,
)
from backend.domain.events import RunBudget
from backend.domain.runs import (
    RunManager,
    RunNotFoundError,
    RunStateConflictError,
    SseConnectionLimitError,
    UsageService,
)
from backend.providers.capabilities import (
    BUILTIN_CAPABILITY_TABLE,
    probe_openai_compatible_endpoint,
    resolve_model_capabilities,
)

router = APIRouter(tags=["runs"])


# --- Request / Response Models ---


class CreateChatRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    title: str = Field(default="New Chat", min_length=1, max_length=255)
    model: str = Field(default="fake/default", min_length=1, max_length=128)
    project_id: str | None = None
    system_prompt: str | None = None
    temporary: bool = False


class UpdateChatRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    title: str | None = Field(default=None, min_length=1, max_length=255)
    model: str | None = Field(default=None, min_length=1, max_length=128)
    system_prompt: str | None = None
    project_id: str | None = None
    pinned: bool | None = None
    archived: bool | None = None


class ChatItemResponse(BaseModel):
    id: str
    title: str
    model: str
    pinned: bool
    archived: bool
    temporary: bool = False
    project_id: str | None = None
    system_prompt: str | None = None
    active_leaf_id: str | None
    created_at: str
    updated_at: str


class PostMessageRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    content: str = Field(min_length=1, max_length=200000)
    parent_id: str | None = "__active_leaf__"
    model: str | None = None
    attachment_ids: list[str] = Field(default_factory=list)
    budget: dict[str, Any] | None = None
    thinking_enabled: bool = False


class EditMessageRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    content: str = Field(min_length=1, max_length=200000)
    model: str | None = None
    attachment_ids: list[str] | None = None
    budget: dict[str, Any] | None = None
    thinking_enabled: bool = False


class RegenerateMessageRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    model: str | None = None
    budget: dict[str, Any] | None = None
    thinking_enabled: bool = False


class ForkChatRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    up_to_message_id: str = Field(min_length=1, max_length=64)
    title: str | None = Field(default=None, max_length=255)


class SeedMessagesRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    count: int = Field(default=5000, ge=1, le=10000)


class ProjectCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1, max_length=255)
    description: str = Field(default="", max_length=4000)
    instructions: str = Field(default="", max_length=64000)
    token_budget: int = Field(default=2048, gt=0, le=65536)


class ProjectUpdateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str | None = Field(default=None, min_length=1, max_length=255)
    description: str | None = Field(default=None, max_length=4000)
    instructions: str | None = Field(default=None, max_length=64000)
    token_budget: int | None = Field(default=None, gt=0, le=65536)


class SteerRunRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    text: str = Field(min_length=1, max_length=16000)


class RunSnapshotResponse(BaseModel):
    id: str
    chat_id: str
    message_id: str
    status: str
    model: str
    budget: dict[str, Any]
    usage: dict[str, Any]
    last_seq: int


class UploadResponse(BaseModel):
    sha256: str = ""
    size_bytes: int = 0
    mime_type: str = "application/octet-stream"
    filename: str = "blob"
    extraction_status: str = "ready"
    extracted_text: str | None = None
    upload_id: str | None = None
    received_bytes: int | None = None
    total_bytes: int | None = None
    status: str | None = None


class TokenEstimateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    text: str = ""
    model: str = "fake/default"
    system_prompt: str | None = None
    project_instructions: str | None = None
    history: list[dict[str, Any]] | None = None


class ProviderProbeRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    base_url: str = Field(min_length=7, max_length=512)
    api_key: str | None = None
    model_id: str | None = None


# --- Chat & Search Routes ---


register_route_policy("GET", "/api/chats", "chat")


@router.get("/api/chats", response_model=list[ChatItemResponse])
async def list_chats(
    request: Request,
    project_id: str | None = None,
    include_archived: bool = False,
    principal: Principal = Depends(require("chat")),
) -> list[ChatItemResponse]:
    """List chats belonging to the current user."""
    db: DatabaseManager = request.app.state.db
    async with db.session() as sess:
        uow = UnitOfWork(sess)
        chats = await uow.chats.list_chats(
            principal.user.id,
            project_id=project_id,
            include_archived=include_archived,
        )
        return [
            ChatItemResponse(
                id=c.id,
                title=c.title,
                model=c.model,
                pinned=c.pinned,
                archived=c.archived,
                temporary=c.temporary,
                project_id=c.project_id,
                system_prompt=c.folder,
                active_leaf_id=c.active_leaf_id,
                created_at=_ensure_utc(c.created_at).isoformat(),
                updated_at=_ensure_utc(c.updated_at).isoformat(),
            )
            for c in chats
        ]


register_route_policy("POST", "/api/chats", "chat")


@router.post("/api/chats", response_model=ChatItemResponse)
async def create_chat(
    body: CreateChatRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> ChatItemResponse:
    """Create a new chat container."""
    db: DatabaseManager = request.app.state.db
    now = datetime.now(UTC)

    async def _op(sess: AsyncSession) -> ChatItemResponse:
        uow = UnitOfWork(sess)
        chat = ChatRecord(
            id=f"c_{uuid.uuid4().hex[:16]}",
            user_id=principal.user.id,
            project_id=body.project_id,
            title=body.title,
            pinned=False,
            archived=False,
            folder=body.system_prompt,
            model=body.model,
            temporary=body.temporary,
            active_leaf_id=None,
            created_at=now,
            updated_at=now,
        )
        await uow.chats.create_chat(chat)
        return ChatItemResponse(
            id=chat.id,
            title=chat.title,
            model=chat.model,
            pinned=chat.pinned,
            archived=chat.archived,
            temporary=chat.temporary,
            project_id=chat.project_id,
            system_prompt=chat.folder,
            active_leaf_id=chat.active_leaf_id,
            created_at=_ensure_utc(chat.created_at).isoformat(),
            updated_at=_ensure_utc(chat.updated_at).isoformat(),
        )

    return await db.execute_write(_op)


register_route_policy("GET", "/api/chats/search", "chat")


@router.get("/api/chats/search")
async def search_chats(
    q: str,
    request: Request,
    limit: int = 20,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    """Full-text search across user's chats and messages with snippet highlighting."""
    db: DatabaseManager = request.app.state.db

    async def _op(sess: AsyncSession) -> list[dict[str, Any]]:
        return await search_chats_and_messages(
            sess,
            user_id=principal.user.id,
            query=q,
            limit=max(1, min(100, limit)),
        )

    hits = await db.execute_write(_op)
    return {"query": q, "results": hits}


register_route_policy("GET", "/api/chats/{chat_id}", "chat")


@router.get("/api/chats/{chat_id}")
async def get_chat_detail(
    chat_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    chat_service: ChatService = request.app.state.chat_service
    detail = await chat_service.get_chat_detail(chat_id=chat_id, user_id=principal.user.id)
    if detail is None:
        raise HTTPException(status_code=404, detail="Chat not found")
    return detail


register_route_policy("PATCH", "/api/chats/{chat_id}", "chat")


@router.patch("/api/chats/{chat_id}")
async def update_chat(
    chat_id: str,
    body: UpdateChatRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    chat_service: ChatService = request.app.state.chat_service
    updated = await chat_service.update_chat(
        chat_id=chat_id,
        user_id=principal.user.id,
        title=body.title,
        model=body.model,
        system_prompt=body.system_prompt,
        project_id=body.project_id,
        pinned=body.pinned,
        archived=body.archived,
    )
    if updated is None:
        raise HTTPException(status_code=404, detail="Chat not found")
    return updated


register_route_policy("DELETE", "/api/chats/{chat_id}", "chat")


@router.delete("/api/chats/{chat_id}")
async def delete_chat(
    chat_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    chat_service: ChatService = request.app.state.chat_service
    deleted = await chat_service.delete_chat(chat_id=chat_id, user_id=principal.user.id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Chat not found")
    return {"ok": True, "deleted": chat_id}


register_route_policy("POST", "/api/chats/{chat_id}/messages", "chat")


@router.post("/api/chats/{chat_id}/messages")
async def post_message(
    chat_id: str,
    body: PostMessageRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    """Append a user message and start a durable run (honors Idempotency-Key)."""
    run_manager: RunManager = request.app.state.run_manager
    idem_key = request.headers.get("Idempotency-Key")
    try:
        return await run_manager.post_user_message_and_start_run(
            chat_id=chat_id,
            user_id=principal.user.id,
            content=body.content,
            parent_id=body.parent_id,
            model=body.model,
            attachment_ids=body.attachment_ids,
            budget=body.budget,
            thinking_enabled=body.thinking_enabled,
            idempotency_key=idem_key,
        )
    except MessageTreeError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("POST", "/api/chats/{chat_id}/messages/{message_id}/edit", "chat")


@router.post("/api/chats/{chat_id}/messages/{message_id}/edit")
async def edit_and_resubmit_message(
    chat_id: str,
    message_id: str,
    body: EditMessageRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    """Edit a user message (creating a sibling branch) and start a new assistant run."""
    chat_service: ChatService = request.app.state.chat_service
    run_manager: RunManager = request.app.state.run_manager
    try:
        user_msg = await chat_service.edit_user_message(
            chat_id=chat_id,
            user_id=principal.user.id,
            message_id=message_id,
            new_content=body.content,
            attachment_ids=body.attachment_ids,
        )
        run_info = await run_manager.start_run_for_user_message(
            chat_id=chat_id,
            user_id=principal.user.id,
            user_message_id=user_msg["id"],
            model=body.model,
            budget=body.budget,
            thinking_enabled=body.thinking_enabled,
        )
        return {
            "user_message": user_msg,
            "assistant_message_id": run_info["message_id"],
            "run": run_info,
        }
    except MessageTreeError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


register_route_policy("POST", "/api/chats/{chat_id}/messages/{message_id}/regenerate", "chat")


@router.post("/api/chats/{chat_id}/messages/{message_id}/regenerate")
async def regenerate_assistant_message(
    chat_id: str,
    message_id: str,
    body: RegenerateMessageRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    """Regenerate an assistant message by creating a sibling assistant branch."""
    chat_service: ChatService = request.app.state.chat_service
    run_manager: RunManager = request.app.state.run_manager
    try:
        user_parent_id = await chat_service.resolve_regenerate_parent(
            chat_id=chat_id,
            user_id=principal.user.id,
            assistant_message_id=message_id,
        )
        run_info = await run_manager.start_run_for_user_message(
            chat_id=chat_id,
            user_id=principal.user.id,
            user_message_id=user_parent_id,
            model=body.model,
            budget=body.budget,
            thinking_enabled=body.thinking_enabled,
        )
        return {
            "user_message_id": user_parent_id,
            "assistant_message_id": run_info["message_id"],
            "run": run_info,
        }
    except MessageTreeError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


register_route_policy("POST", "/api/chats/{chat_id}/messages/{message_id}/activate", "chat")


@router.post("/api/chats/{chat_id}/messages/{message_id}/activate")
async def activate_message_branch(
    chat_id: str,
    message_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    """Move active_leaf_id to the branch descending from message_id."""
    chat_service: ChatService = request.app.state.chat_service
    try:
        return await chat_service.activate_branch(
            chat_id=chat_id,
            user_id=principal.user.id,
            message_id=message_id,
        )
    except MessageTreeError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


register_route_policy("DELETE", "/api/chats/{chat_id}/messages/{message_id}", "chat")


@router.delete("/api/chats/{chat_id}/messages/{message_id}")
async def delete_message_subtree(
    chat_id: str,
    message_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    """Delete a message and all of its descendants."""
    chat_service: ChatService = request.app.state.chat_service
    try:
        return await chat_service.delete_subtree(
            chat_id=chat_id,
            user_id=principal.user.id,
            message_id=message_id,
        )
    except MessageTreeError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


register_route_policy("POST", "/api/chats/{chat_id}/fork", "chat")


@router.post("/api/chats/{chat_id}/fork")
async def fork_chat(
    chat_id: str,
    body: ForkChatRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    """Fork a chat from root up to up_to_message_id into a new chat."""
    chat_service: ChatService = request.app.state.chat_service
    try:
        return await chat_service.fork_chat(
            chat_id=chat_id,
            user_id=principal.user.id,
            up_to_message_id=body.up_to_message_id,
            title=body.title,
        )
    except MessageTreeError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


register_route_policy("POST", "/api/chats/{chat_id}/seed", "chat")


@router.post("/api/chats/{chat_id}/seed")
async def seed_chat_messages(
    chat_id: str,
    body: SeedMessagesRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    """Bulk-seed alternating user/assistant messages into a chat for virtualization testing."""
    chat_service: ChatService = request.app.state.chat_service
    try:
        return await chat_service.seed_messages(
            chat_id=chat_id,
            user_id=principal.user.id,
            count=body.count,
        )
    except MessageTreeError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("GET", "/api/chats/{chat_id}/export", "chat")


@router.get("/api/chats/{chat_id}/export")
async def export_chat(
    chat_id: str,
    request: Request,
    format: str = "markdown",
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    """Export the active branch of a chat as Markdown, JSON, or standalone HTML."""
    chat_service: ChatService = request.app.state.chat_service
    detail = await chat_service.get_chat_detail(chat_id=chat_id, user_id=principal.user.id)
    if detail is None:
        raise HTTPException(status_code=404, detail="Chat not found")
    msgs: list[dict[str, Any]] = list(detail.get("messages", []))
    title = str(detail.get("title", "Chat Export"))
    fmt = format.lower()
    if fmt == "json":
        return {"format": "json", "title": title, "content": json.dumps(detail, indent=2)}
    if fmt == "html":
        import html as html_lib

        items_html = "".join(
            f"<article class='msg msg-{html_lib.escape(str(m.get('role')))}'>"
            f"<h3>{html_lib.escape(str(m.get('role')).title())}</h3>"
            f"<pre>{html_lib.escape(str(m.get('content', '')))}</pre></article>"
            for m in msgs
        )
        doc = render_branded_export_html(title, items_html)
        return {"format": "html", "title": title, "content": doc}
    md_lines = [f"# {title}", ""]
    for m in msgs:
        role_label = str(m.get("role", "user")).upper()
        md_lines.append(f"## {role_label}\n\n{m.get('content', '')}\n")
    return {"format": "markdown", "title": title, "content": "\n".join(md_lines)}


# --- Projects Routes ---


register_route_policy("GET", "/api/projects", "chat")


@router.get("/api/projects")
async def list_projects(
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> list[dict[str, Any]]:
    chat_service: ChatService = request.app.state.chat_service
    return await chat_service.list_projects(user_id=principal.user.id)


register_route_policy("POST", "/api/projects", "chat")


@router.post("/api/projects")
async def create_project(
    body: ProjectCreateRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    chat_service: ChatService = request.app.state.chat_service
    return await chat_service.create_project(
        user_id=principal.user.id,
        name=body.name,
        description=body.description,
        instructions=body.instructions,
        token_budget=body.token_budget,
    )


register_route_policy("PATCH", "/api/projects/{project_id}", "chat")


@router.patch("/api/projects/{project_id}")
async def update_project(
    project_id: str,
    body: ProjectUpdateRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    chat_service: ChatService = request.app.state.chat_service
    updated = await chat_service.update_project(
        project_id=project_id,
        user_id=principal.user.id,
        name=body.name,
        description=body.description,
        instructions=body.instructions,
        token_budget=body.token_budget,
    )
    if updated is None:
        raise HTTPException(status_code=404, detail="Project not found")
    return updated


register_route_policy("DELETE", "/api/projects/{project_id}", "chat")


@router.delete("/api/projects/{project_id}")
async def delete_project(
    project_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    chat_service: ChatService = request.app.state.chat_service
    deleted = await chat_service.delete_project(project_id=project_id, user_id=principal.user.id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Project not found")
    return {"ok": True, "deleted": project_id}


# --- Runs & SSE Routes ---


register_route_policy("GET", "/api/runs/{run_id}", "chat")


@router.get("/api/runs/{run_id}", response_model=RunSnapshotResponse)
async def get_run_snapshot(
    run_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> RunSnapshotResponse:
    """Return durable run status, usage totals, and latest event cursor."""
    db: DatabaseManager = request.app.state.db
    run_id_var.set(run_id)
    async with db.session() as sess:
        uow = UnitOfWork(sess)
        run = await uow.chats.get_run(run_id)
        if run is None or (
            run.user_id != principal.user.id and "admin" not in principal.privileges
        ):
            raise HTTPException(status_code=404, detail="Run not found")
        events = await uow.chats.list_run_events(run_id, after_seq=0)
        last_seq = events[-1].seq if events else 0
        return RunSnapshotResponse(
            id=run.id,
            chat_id=run.chat_id,
            message_id=run.message_id,
            status=run.status,
            model=run.model,
            budget=run.budget_json or RunBudget().model_dump(),
            usage=run.usage_json or {},
            last_seq=last_seq,
        )


register_route_policy("GET", "/api/runs/{run_id}/events", "chat")


@router.get("/api/runs/{run_id}/events", response_model=None)
async def stream_run_events(
    run_id: str,
    request: Request,
    after: int | None = None,
    principal: Principal = Depends(require("chat")),
) -> Response:
    """Resumable Server-Sent Events stream for a durable run (`?after=` or `Last-Event-ID`)."""
    db: DatabaseManager = request.app.state.db
    run_manager: RunManager = request.app.state.run_manager
    run_id_var.set(run_id)

    after_seq = after if after is not None else 0
    last_event_id = request.headers.get("Last-Event-ID")
    if after is None and last_event_id and last_event_id.lstrip("-").isdigit():
        after_seq = max(0, int(last_event_id))

    async with db.session() as sess:
        uow = UnitOfWork(sess)
        run = await uow.chats.get_run(run_id)
        if run is None or (
            run.user_id != principal.user.id and "admin" not in principal.privileges
        ):
            raise HTTPException(status_code=404, detail="Run not found")

    try:
        run_manager.acquire_sse_slot(principal.user.id)
    except SseConnectionLimitError as exc:
        raise HTTPException(status_code=429, detail=str(exc)) from exc

    return StreamingResponse(
        run_manager.stream_sse(
            run_id=run_id,
            user_id=principal.user.id,
            after_seq=after_seq,
        ),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache, no-transform",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


register_route_policy("POST", "/api/runs/{run_id}/cancel", "chat")


@router.post("/api/runs/{run_id}/cancel")
async def cancel_run(
    run_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    """Cancel an active, queued, or paused run."""
    run_manager: RunManager = request.app.state.run_manager
    run_id_var.set(run_id)
    uid = None if "admin" in principal.privileges else principal.user.id
    try:
        updated = await run_manager.cancel_run(run_id, user_id=uid)
        return {"id": updated["id"], "status": updated["status"]}
    except RunNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("POST", "/api/runs/{run_id}/pause", "chat")


@router.post("/api/runs/{run_id}/pause")
async def pause_run(
    run_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    run_manager: RunManager = request.app.state.run_manager
    run_id_var.set(run_id)
    uid = None if "admin" in principal.privileges else principal.user.id
    try:
        return await run_manager.pause_run(run_id, user_id=uid)
    except RunNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except RunStateConflictError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


register_route_policy("POST", "/api/runs/{run_id}/resume", "chat")


@router.post("/api/runs/{run_id}/resume")
async def resume_run(
    run_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    """Resume a paused run or recover an interrupted run without duplicating tokens."""
    run_manager: RunManager = request.app.state.run_manager
    run_id_var.set(run_id)
    uid = None if "admin" in principal.privileges else principal.user.id
    try:
        return await run_manager.resume_run(run_id, user_id=uid)
    except RunNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except RunStateConflictError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


register_route_policy("POST", "/api/runs/{run_id}/steer", "chat")


@router.post("/api/runs/{run_id}/steer")
async def steer_run(
    run_id: str,
    body: SteerRunRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    run_manager: RunManager = request.app.state.run_manager
    run_id_var.set(run_id)
    uid = None if "admin" in principal.privileges else principal.user.id
    try:
        return await run_manager.steer_run(run_id, body.text, user_id=uid)
    except RunNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except RunStateConflictError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


# --- Uploads & Content-Addressed Attachments ---


register_route_policy("POST", "/api/uploads", "files")


@router.post("/api/uploads", response_model=UploadResponse)
async def upload_blob(
    request: Request,
    principal: Principal = Depends(require("files")),
) -> UploadResponse:
    """Handle single-shot attachment upload OR initiate a resumable chunked upload session."""
    att_service: AttachmentService = request.app.state.attachment_service
    content_type = request.headers.get("content-type", "").lower()
    raw_body = await request.body()

    if "application/json" in content_type and raw_body.startswith(b"{"):
        try:
            parsed = json.loads(raw_body.decode("utf-8"))
            if isinstance(parsed, dict) and parsed.get("mode") == "chunked_init":
                session_info = await att_service.start_upload_session(
                    user_id=principal.user.id,
                    filename=str(parsed.get("filename", "upload.bin")),
                    total_bytes=int(parsed.get("total_bytes", 0)),
                    expected_sha256=parsed.get("expected_sha256"),
                )
                return UploadResponse(
                    upload_id=session_info["upload_id"],
                    filename=session_info["filename"],
                    total_bytes=session_info["total_bytes"],
                    received_bytes=session_info["received_bytes"],
                    status=session_info["status"],
                )
        except AttachmentValidationError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except ValueError:
            parsed = None

    filename = request.headers.get("X-Upload-Filename", "upload.bin")
    try:
        stored = await att_service.store_bytes(
            user_id=principal.user.id,
            filename=filename,
            data=raw_body,
        )
        return UploadResponse(
            sha256=stored["sha256"],
            size_bytes=stored["size_bytes"],
            mime_type=stored["mime_type"],
            filename=stored["filename"],
            extraction_status=stored["extraction_status"],
            extracted_text=stored.get("extracted_text"),
        )
    except AttachmentValidationError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


register_route_policy("POST", "/api/uploads/{upload_id}/chunks", "files")


@router.post("/api/uploads/{upload_id}/chunks")
async def upload_chunk(
    upload_id: str,
    request: Request,
    offset: int | None = None,
    finalize: bool = False,
    principal: Principal = Depends(require("files")),
) -> dict[str, Any]:
    """Append a byte chunk to an open resumable upload session."""
    att_service: AttachmentService = request.app.state.attachment_service
    chunk = await request.body()
    try:
        return await att_service.append_upload_chunk(
            upload_id=upload_id,
            user_id=principal.user.id,
            chunk=chunk,
            offset=offset,
            finalize=finalize,
        )
    except AttachmentValidationError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


register_route_policy("POST", "/api/uploads/{upload_id}/complete", "files")


@router.post("/api/uploads/{upload_id}/complete")
async def finalize_upload(
    upload_id: str,
    request: Request,
    principal: Principal = Depends(require("files")),
) -> dict[str, Any]:
    att_service: AttachmentService = request.app.state.attachment_service
    try:
        return await att_service.finalize_upload_session(
            upload_id=upload_id,
            user_id=principal.user.id,
        )
    except AttachmentValidationError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


register_route_policy("GET", "/api/attachments/{sha256}", "files")


@router.get("/api/attachments/{sha256}", response_model=None)
async def get_attachment(
    sha256: str,
    request: Request,
    meta: bool = False,
    principal: Principal = Depends(require("files")),
) -> Response:
    """Download an attachment by SHA-256 or inspect its extracted metadata (`?meta=true`)."""
    att_service: AttachmentService = request.app.state.attachment_service
    found = await att_service.get_attachment(sha256, user_id=principal.user.id)
    if found is None:
        raise HTTPException(status_code=404, detail="Attachment not found")
    rec, raw_bytes = found
    if meta:
        from fastapi.responses import JSONResponse

        return JSONResponse(
            content={
                "sha256": rec.sha256,
                "filename": rec.filename,
                "mime_type": rec.mime_type,
                "size_bytes": rec.size_bytes,
                "extraction_status": rec.extraction_status,
                "extracted_text": rec.extracted_text,
                "scan_status": rec.scan_status,
                "metadata": rec.metadata_json,
            }
        )
    return Response(
        content=raw_bytes,
        media_type=rec.mime_type,
        headers={
            # Never interpolate a user-controlled filename into a header raw: quote it
            # (RFC 5987) and strip CR/LF so a crafted name cannot split the response.
            "Content-Disposition": (
                "attachment; filename*=UTF-8''"
                + quote(rec.filename.replace("\r", "").replace("\n", ""), safe="")
            ),
            "X-Content-Type-Options": "nosniff",
        },
    )


# --- Usage, Token Estimation & Provider Probing ---


register_route_policy("GET", "/api/usage", "chat")


@router.get("/api/usage")
async def get_usage_rollups(
    request: Request,
    project_id: str | None = None,
    model: str | None = None,
    all_users: bool = False,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    usage_service: UsageService = request.app.state.usage_service
    target_uid = None if (all_users and "admin" in principal.privileges) else principal.user.id
    return await usage_service.get_rollups(
        user_id=target_uid,
        project_id=project_id,
        model=model,
    )


register_route_policy("POST", "/api/tokens/estimate", "chat")


@router.post("/api/tokens/estimate")
async def estimate_prompt_tokens(
    body: TokenEstimateRequest,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    text_tokens = estimate_tokens(body.text, body.model)
    builder = PromptBuilder(PromptSectionBudget())
    hist = list(body.history or [])
    if body.text:
        hist.append({"role": "user", "content": body.text})
    built = builder.build(
        base_system_prompt=body.system_prompt or "",
        project_instructions=body.project_instructions,
        history=hist,
        model=body.model,
    )
    return {
        "model": body.model,
        "text_tokens": text_tokens,
        "total_tokens": built.total_tokens,
        "section_tokens": built.section_tokens,
        "truncated_sections": built.truncated_sections,
    }


register_route_policy("GET", "/api/providers/capabilities", "chat")


@router.get("/api/providers/capabilities")
async def list_provider_capabilities(
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    models_out = []
    for mid in sorted(BUILTIN_CAPABILITY_TABLE.keys()):
        caps = resolve_model_capabilities(mid)
        models_out.append(caps.to_dict())
    return {"models": models_out}


register_route_policy("POST", "/api/providers/probe", "admin")


@router.post("/api/providers/probe")
async def probe_provider_endpoint(
    body: ProviderProbeRequest,
    _principal: Principal = Depends(require("admin")),
) -> dict[str, Any]:
    return await probe_openai_compatible_endpoint(
        body.base_url,
        api_key=body.api_key,
        model_id=body.model_id,
    )


# --- Minimal Admin-Only Debug Client (disabled in production) ---


DEBUG_STREAM_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Odysseus Stream Debugger</title>
</head>
<body>
  <h1>Odysseus Run Event Protocol v1 — Stream Debugger</h1>
  <form id="debug-form">
    <input id="prompt" name="prompt" type="text" placeholder="Enter prompt..." required />
    <button type="submit">Start Run &amp; Stream</button>
  </form>
  <ul id="events"></ul>
</body>
</html>
"""

register_route_policy("GET", "/debug/stream", "admin")


@router.get("/debug/stream", response_model=None)
async def debug_stream_page(
    request: Request,
    _principal: Principal = Depends(require("admin")),
) -> Response:
    """Minimal admin-only debug page rendering raw SSE events (disabled in production)."""
    if request.app.state.settings.environment == "production":
        raise HTTPException(status_code=404, detail="Debug client is disabled in production")
    return HTMLResponse(content=DEBUG_STREAM_HTML)
