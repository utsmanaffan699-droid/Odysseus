"""Authentication, session management, forced password change, TOTP 2FA, and API token routes."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.auth import (
    create_user_session,
    generate_totp_enrollment,
    hash_password,
    mint_api_token,
    sha256_hex,
    verify_password_constant_time,
    verify_totp_or_recovery,
)
from backend.core.db import DatabaseManager
from backend.core.middleware import resolve_client_ip, resolve_request_proto
from backend.core.security import Principal, register_route_policy, require
from backend.core.uow import UnitOfWork

router = APIRouter(tags=["auth"])


class LoginRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    username: str = Field(min_length=1, max_length=64)
    password: str = Field(min_length=1, max_length=256)


class UserProfileResponse(BaseModel):
    id: str
    username: str
    email: str
    privileges: list[str]
    must_change_password: bool
    totp_enabled: bool
    mfa_pending: bool = False
    csrf_token: str | None = None


class LoginResponse(BaseModel):
    authenticated: bool
    mfa_required: bool
    must_change_password: bool
    csrf_token: str
    user: UserProfileResponse


class PasswordChangeRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    current_password: str = Field(min_length=1, max_length=256)
    new_password: str = Field(min_length=10, max_length=256)


class TotpEnrollResponse(BaseModel):
    secret: str
    qr_code_data_uri: str
    recovery_codes: list[str]


class TotpVerifyRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    code: str = Field(min_length=4, max_length=32)


class TotpVerifyResponse(BaseModel):
    verified: bool
    used_recovery_code: bool
    totp_enabled: bool


class SessionItemResponse(BaseModel):
    id: str
    ip_address: str
    user_agent: str
    created_at: str
    last_active_at: str
    expires_at: str
    current: bool


class CreateApiTokenRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1, max_length=128)
    scopes: list[str] = Field(min_length=1)
    expires_in_days: int | None = Field(default=30, ge=1, le=365)


class CreateApiTokenResponse(BaseModel):
    id: str
    name: str
    token: str
    token_prefix: str
    scopes: list[str]
    expires_at: str | None


class ApiTokenItemResponse(BaseModel):
    id: str
    name: str
    token_prefix: str
    scopes: list[str]
    expires_at: str | None
    last_used_at: str | None
    revoked_at: str | None
    created_at: str


register_route_policy("POST", "/api/auth/login", "public")


@router.post("/api/auth/login", response_model=LoginResponse)
async def login(body: LoginRequest, request: Request) -> Response:
    """Authenticate credentials with Argon2id, prevent session fixation, and issue cookie."""
    app_state = request.app.state
    settings = app_state.settings
    db: DatabaseManager = app_state.db
    throttler = app_state.throttler
    client_ip = resolve_client_ip(request, settings)
    proto = resolve_request_proto(request, settings)

    retry_wait = throttler.check_login_allowed(client_ip, body.username)
    if retry_wait > 0:
        return JSONResponse(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            content={"detail": "Too many failed login attempts. Please try again later."},
            headers={"Retry-After": str(retry_wait)},
        )

    pre_login_cookie = request.cookies.get(settings.session_cookie_name)
    user_agent = request.headers.get("User-Agent", "")

    async def _op(sess: Any) -> tuple[str | None, LoginResponse | None, int]:
        uow = UnitOfWork(sess)
        user = await uow.users.get_by_username(body.username)
        stored_hash = user.password_hash if (user is not None and user.is_active) else None
        ok = verify_password_constant_time(body.password, stored_hash)

        if not ok or user is None:
            lock_wait = throttler.record_login_failure(client_ip, body.username)
            await uow.audit.record(
                action="auth.login_failed",
                resource_type="user",
                actor_ip=client_ip,
                details={"username": body.username, "throttled": lock_wait > 0},
            )
            return None, None, lock_wait

        # Session fixation defense: once credentials are verified, revoke pre-login cookie
        if pre_login_cookie:
            old_rec = await uow.sessions.get_by_token_hash(sha256_hex(pre_login_cookie))
            if old_rec is not None and old_rec.revoked_at is None:
                await uow.sessions.revoke(old_rec)

        throttler.record_login_success(client_ip, body.username)
        raw_token, session_rec = await create_user_session(
            uow,
            settings,
            user=user,
            ip_address=client_ip,
            user_agent=user_agent,
            mfa_pending=bool(user.totp_enabled),
        )
        await uow.audit.record(
            action="auth.login_succeeded",
            resource_type="session",
            actor_user_id=user.id,
            actor_ip=client_ip,
            resource_id=session_rec.id,
            details={"mfa_required": bool(user.totp_enabled)},
        )
        privs = sorted(p.privilege for p in user.privileges)
        profile = UserProfileResponse(
            id=user.id,
            username=user.username,
            email=user.email,
            privileges=privs,
            must_change_password=user.must_change_password,
            totp_enabled=user.totp_enabled,
            mfa_pending=session_rec.mfa_pending,
            csrf_token=session_rec.csrf_token,
        )
        resp_model = LoginResponse(
            authenticated=True,
            mfa_required=bool(user.totp_enabled),
            must_change_password=user.must_change_password,
            csrf_token=session_rec.csrf_token,
            user=profile,
        )
        return raw_token, resp_model, 0

    raw_token, login_resp, lock_wait = await db.execute_write(_op)

    if login_resp is None or raw_token is None:
        if lock_wait > 0:
            return JSONResponse(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                content={"detail": "Too many failed login attempts. Please try again later."},
                headers={"Retry-After": str(lock_wait)},
            )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password",
        )

    response = JSONResponse(
        status_code=status.HTTP_200_OK,
        content=login_resp.model_dump(mode="json"),
    )
    is_secure = settings.cookie_secure or (proto == "https")
    response.set_cookie(
        key=settings.session_cookie_name,
        value=raw_token,
        httponly=True,
        samesite="lax",
        secure=is_secure,
        max_age=settings.session_absolute_timeout_seconds,
        path="/",
    )
    return response


register_route_policy(
    "POST",
    "/api/auth/logout",
    "authenticated",
    allow_mfa_pending=True,
    allow_must_change_password=True,
)


@router.post("/api/auth/logout")
async def logout(
    request: Request,
    response: Response,
    principal: Principal = Depends(
        require("authenticated", allow_mfa_pending=True, allow_must_change_password=True)
    ),
) -> dict[str, Any]:
    """Revoke current session and clear session cookie."""
    settings = request.app.state.settings
    db = request.app.state.db
    client_ip = resolve_client_ip(request, settings)

    if principal.session_record is not None:
        session_id = principal.session_record.id

        async def _op(sess: Any) -> None:
            uow = UnitOfWork(sess)
            rec = await uow.sessions.get_by_id(session_id)
            if rec is not None:
                await uow.sessions.revoke(rec)
            await uow.audit.record(
                action="auth.logout",
                resource_type="session",
                actor_user_id=principal.user.id,
                actor_ip=client_ip,
                resource_id=session_id,
            )

        await db.execute_write(_op)

    response.delete_cookie(key=settings.session_cookie_name, path="/")
    return {"ok": True}


register_route_policy(
    "GET",
    "/api/auth/me",
    "authenticated",
    allow_mfa_pending=True,
    allow_must_change_password=True,
)


@router.get("/api/auth/me", response_model=UserProfileResponse)
async def get_me(
    principal: Principal = Depends(
        require("authenticated", allow_mfa_pending=True, allow_must_change_password=True)
    ),
) -> UserProfileResponse:
    """Return current authenticated user profile, privileges, and CSRF token."""
    return UserProfileResponse(
        id=principal.user.id,
        username=principal.user.username,
        email=principal.user.email,
        privileges=sorted(principal.privileges),
        must_change_password=principal.user.must_change_password,
        totp_enabled=principal.user.totp_enabled,
        mfa_pending=bool(
            principal.session_record.mfa_pending if principal.session_record else False
        ),
        csrf_token=(principal.session_record.csrf_token if principal.session_record else None),
    )


register_route_policy(
    "POST",
    "/api/auth/password/change",
    "authenticated",
    allow_must_change_password=True,
)


@router.post("/api/auth/password/change")
async def change_password(
    body: PasswordChangeRequest,
    request: Request,
    principal: Principal = Depends(require("authenticated", allow_must_change_password=True)),
) -> dict[str, Any]:
    """Change the current user's password and clear `must_change_password`."""
    settings = request.app.state.settings
    db = request.app.state.db
    client_ip = resolve_client_ip(request, settings)

    if body.current_password == body.new_password:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="New password must differ from current password",
        )

    current_session_id = principal.session_record.id if principal.session_record else None

    async def _op(sess: Any) -> dict[str, Any]:
        uow = UnitOfWork(sess)
        user = await uow.users.get_by_id(principal.user.id)
        if user is None or not verify_password_constant_time(
            body.current_password, user.password_hash
        ):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Current password is incorrect",
            )
        user.password_hash = hash_password(body.new_password)
        user.must_change_password = False
        user.updated_at = datetime.now(UTC)

        # Credential change must invalidate everything the old password could have
        # authorized, otherwise a stolen session/token survives the reset.
        revoked_sessions = 0
        for other in await uow.sessions.list_for_user(user.id):
            if other.id == current_session_id:
                continue
            await uow.sessions.revoke(other)
            revoked_sessions += 1
        revoked_tokens = 0
        now = datetime.now(UTC)
        for tok in await uow.api_tokens.list_for_user(user.id):
            if tok.revoked_at is None:
                tok.revoked_at = now
                revoked_tokens += 1

        await uow.audit.record(
            action="auth.password_changed",
            resource_type="user",
            actor_user_id=user.id,
            actor_ip=client_ip,
            resource_id=user.id,
            details={
                "revoked_sessions": revoked_sessions,
                "revoked_api_tokens": revoked_tokens,
            },
        )
        return {"revoked_sessions": revoked_sessions, "revoked_api_tokens": revoked_tokens}

    revoked = await db.execute_write(_op)
    return {
        "ok": True,
        "must_change_password": False,
        "revoked_other_sessions": revoked["revoked_sessions"],
        "revoked_api_tokens": revoked["revoked_api_tokens"],
    }


register_route_policy("POST", "/api/auth/2fa/enroll", "authenticated")


@router.post("/api/auth/2fa/enroll", response_model=TotpEnrollResponse)
async def enroll_2fa(
    request: Request,
    principal: Principal = Depends(require("authenticated")),
) -> TotpEnrollResponse:
    """Generate TOTP secret (encrypted at rest), QR code PNG data URI, and 8 recovery codes.

    Enrollment replaces the account's TOTP secret and recovery codes, so it requires an
    interactive session: a bearer token must never be able to (re)bind the second factor
    of the account it belongs to.
    """
    settings = request.app.state.settings
    db = request.app.state.db
    vault = request.app.state.vault
    client_ip = resolve_client_ip(request, settings)

    if principal.auth_method == "bearer":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Two-factor enrollment requires an interactive session, not an API token.",
        )

    secret, encrypted, qr_uri, recovery_codes, recovery_hashes = generate_totp_enrollment(
        principal.user.username,
        vault,
    )

    async def _op(sess: Any) -> None:
        uow = UnitOfWork(sess)
        user = await uow.users.get_by_id(principal.user.id)
        if user is None:
            raise HTTPException(status_code=404, detail="User not found")
        user.totp_secret_encrypted = encrypted
        user.recovery_codes_hashes = recovery_hashes
        user.updated_at = datetime.now(UTC)
        await uow.audit.record(
            action="auth.2fa_enrolled",
            resource_type="user",
            actor_user_id=user.id,
            actor_ip=client_ip,
            resource_id=user.id,
        )

    await db.execute_write(_op)
    return TotpEnrollResponse(
        secret=secret,
        qr_code_data_uri=qr_uri,
        recovery_codes=recovery_codes,
    )


register_route_policy(
    "POST",
    "/api/auth/2fa/verify",
    "authenticated",
    allow_mfa_pending=True,
)


@router.post("/api/auth/2fa/verify", response_model=TotpVerifyResponse)
async def verify_2fa(
    body: TotpVerifyRequest,
    request: Request,
    principal: Principal = Depends(require("authenticated", allow_mfa_pending=True)),
) -> Response:
    """Verify a TOTP code or recovery code (rate-limited), enabling 2FA and clearing mfa_pending."""
    settings = request.app.state.settings
    db = request.app.state.db
    vault = request.app.state.vault
    throttler = request.app.state.throttler
    client_ip = resolve_client_ip(request, settings)

    wait = throttler.check_totp_allowed(principal.user.id)
    if wait > 0:
        return JSONResponse(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            content={"detail": "Too many 2FA verification attempts"},
            headers={"Retry-After": str(wait)},
        )

    async def _op(sess: Any) -> tuple[bool, bool, int]:
        uow = UnitOfWork(sess)
        user = await uow.users.get_by_id(principal.user.id)
        if user is None or not user.totp_secret_encrypted:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="TOTP 2FA is not enrolled for this user",
            )
        verified, used_recovery = verify_totp_or_recovery(user, body.code, vault)
        if not verified:
            lock_wait = throttler.record_totp_failure(user.id)
            await uow.audit.record(
                action="auth.2fa_verify_failed",
                resource_type="user",
                actor_user_id=user.id,
                actor_ip=client_ip,
                resource_id=user.id,
            )
            return False, False, lock_wait

        throttler.record_totp_success(user.id)
        user.totp_enabled = True
        user.updated_at = datetime.now(UTC)
        if principal.session_record is not None:
            rec = await uow.sessions.get_by_id(principal.session_record.id)
            if rec is not None:
                rec.mfa_pending = False
        await uow.audit.record(
            action="auth.2fa_verified",
            resource_type="user",
            actor_user_id=user.id,
            actor_ip=client_ip,
            resource_id=user.id,
            details={"used_recovery_code": used_recovery},
        )
        return True, used_recovery, 0

    verified, used_recovery, lock_wait = await db.execute_write(_op)
    if not verified:
        if lock_wait > 0:
            return JSONResponse(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                content={"detail": "Too many 2FA verification attempts"},
                headers={"Retry-After": str(lock_wait)},
            )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid TOTP or recovery code",
        )

    return JSONResponse(
        status_code=status.HTTP_200_OK,
        content=TotpVerifyResponse(
            verified=True,
            used_recovery_code=used_recovery,
            totp_enabled=True,
        ).model_dump(mode="json"),
    )


register_route_policy("GET", "/api/auth/sessions", "authenticated")


@router.get("/api/auth/sessions", response_model=list[SessionItemResponse])
async def list_sessions(
    request: Request,
    principal: Principal = Depends(require("authenticated")),
) -> list[SessionItemResponse]:
    """List active sessions for the current user."""
    db = request.app.state.db
    current_id = principal.session_record.id if principal.session_record else None
    async with db.session() as sess:
        uow = UnitOfWork(sess)
        records = await uow.sessions.list_for_user(principal.user.id)
        return [
            SessionItemResponse(
                id=r.id,
                ip_address=r.ip_address,
                user_agent=r.user_agent,
                created_at=r.created_at.isoformat(),
                last_active_at=r.last_active_at.isoformat(),
                expires_at=r.expires_at.isoformat(),
                current=(r.id == current_id),
            )
            for r in records
        ]


register_route_policy("DELETE", "/api/auth/sessions/{session_id}", "authenticated")


@router.delete("/api/auth/sessions/{session_id}")
async def revoke_session(
    session_id: str,
    request: Request,
    principal: Principal = Depends(require("authenticated")),
) -> dict[str, Any]:
    """Revoke a specific session belonging to the current user (or any session if admin)."""
    settings = request.app.state.settings
    db = request.app.state.db
    client_ip = resolve_client_ip(request, settings)

    async def _op(sess: Any) -> None:
        uow = UnitOfWork(sess)
        rec = await uow.sessions.get_by_id(session_id)
        if rec is None:
            raise HTTPException(status_code=404, detail="Session not found")
        if rec.user_id != principal.user.id and "admin" not in principal.privileges:
            raise HTTPException(status_code=403, detail="Cannot revoke another user's session")
        await uow.sessions.revoke(rec)
        await uow.audit.record(
            action="auth.session_revoked",
            resource_type="session",
            actor_user_id=principal.user.id,
            actor_ip=client_ip,
            resource_id=session_id,
        )

    await db.execute_write(_op)
    return {"ok": True, "revoked": session_id}


register_route_policy("POST", "/api/auth/tokens", "authenticated")


@router.post("/api/auth/tokens", response_model=CreateApiTokenResponse)
async def create_token(
    body: CreateApiTokenRequest,
    request: Request,
    principal: Principal = Depends(require("authenticated")),
) -> CreateApiTokenResponse:
    """Mint a new scoped API token (`ody_...`). Plaintext is returned only once.

    Privilege-escalation defense: tokens cannot be minted with a bearer token (a leaked
    narrow-scope token must not be able to mint wider-scope tokens), and scopes are
    additionally bounded by the caller's own scopes when the caller is a token.
    """
    settings = request.app.state.settings
    db: DatabaseManager = request.app.state.db
    client_ip = resolve_client_ip(request, settings)

    if principal.auth_method == "bearer":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=(
                "API tokens cannot mint new API tokens; authenticate with an interactive "
                "session (password + 2FA) to create credentials."
            ),
        )

    async def _op(sess: AsyncSession) -> CreateApiTokenResponse:
        uow = UnitOfWork(sess)
        user = await uow.users.get_by_id(principal.user.id)
        if user is None:
            raise HTTPException(status_code=404, detail="User not found")
        try:
            raw_secret, record = await mint_api_token(
                uow,
                user=user,
                name=body.name,
                scopes=body.scopes,
                expires_in_days=body.expires_in_days,
                caller_scopes=(
                    principal.privileges if principal.auth_method == "bearer" else None
                ),
            )
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        await uow.audit.record(
            action="auth.api_token_created",
            resource_type="api_token",
            actor_user_id=user.id,
            actor_ip=client_ip,
            resource_id=record.id,
            details={"name": record.name, "scopes": record.scopes},
        )
        return CreateApiTokenResponse(
            id=record.id,
            name=record.name,
            token=raw_secret,
            token_prefix=record.token_prefix,
            scopes=record.scopes,
            expires_at=record.expires_at.isoformat() if record.expires_at else None,
        )

    return await db.execute_write(_op)


register_route_policy("GET", "/api/auth/tokens", "authenticated")


@router.get("/api/auth/tokens", response_model=list[ApiTokenItemResponse])
async def list_tokens(
    request: Request,
    principal: Principal = Depends(require("authenticated")),
) -> list[ApiTokenItemResponse]:
    """List API tokens for the current user."""
    db = request.app.state.db
    async with db.session() as sess:
        uow = UnitOfWork(sess)
        records = await uow.api_tokens.list_for_user(principal.user.id)
        return [
            ApiTokenItemResponse(
                id=t.id,
                name=t.name,
                token_prefix=t.token_prefix,
                scopes=t.scopes,
                expires_at=t.expires_at.isoformat() if t.expires_at else None,
                last_used_at=t.last_used_at.isoformat() if t.last_used_at else None,
                revoked_at=t.revoked_at.isoformat() if t.revoked_at else None,
                created_at=t.created_at.isoformat(),
            )
            for t in records
        ]


register_route_policy("DELETE", "/api/auth/tokens/{token_id}", "authenticated")


@router.delete("/api/auth/tokens/{token_id}")
async def revoke_token(
    token_id: str,
    request: Request,
    principal: Principal = Depends(require("authenticated")),
) -> dict[str, Any]:
    """Revoke an API token (interactive sessions only; a token cannot revoke others)."""
    settings = request.app.state.settings
    db = request.app.state.db
    client_ip = resolve_client_ip(request, settings)

    if principal.auth_method == "bearer":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="API tokens cannot revoke credentials; use an interactive session.",
        )

    async def _op(sess: Any) -> None:
        uow = UnitOfWork(sess)
        tok = await uow.api_tokens.get_by_id(token_id)
        if tok is None or tok.user_id != principal.user.id:
            raise HTTPException(status_code=404, detail="API token not found")
        tok.revoked_at = datetime.now(UTC)
        await uow.audit.record(
            action="auth.api_token_revoked",
            resource_type="api_token",
            actor_user_id=principal.user.id,
            actor_ip=client_ip,
            resource_id=token_id,
        )

    await db.execute_write(_op)
    return {"ok": True, "revoked": token_id}
