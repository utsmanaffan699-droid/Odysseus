"""FastAPI router for Phase 07 Productivity Suite: Mail, Notes, Todos, Calendar, and Schedules."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, ConfigDict, Field

from backend.core.security import Principal, register_route_policy, require
from backend.domain.calendar.service import CalendarService, parse_natural_language_event
from backend.domain.mail.service import MailService
from backend.domain.notes.service import NotesAndTodosService
from backend.domain.notifications.service import NotificationsAndWebhooksService
from backend.domain.schedules.service import SchedulerService
from backend.domain.tools.web_tools import SsrfBlockedError

router = APIRouter(tags=["productivity"])


# --- Request Schemas ---


class MailAccountCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    email_address: str = Field(min_length=3, max_length=254)
    display_name: str = Field(default="", max_length=128)
    imap_host: str = Field(min_length=1, max_length=255)
    imap_port: int = Field(default=993, ge=1, le=65535)
    smtp_host: str = Field(default="127.0.0.1", min_length=1, max_length=255)
    smtp_port: int = Field(default=465, ge=1, le=65535)
    use_tls: bool = True
    auth_method: str = Field(default="password", max_length=32)
    secret_credential: str = Field(default="", max_length=2048)


class MailSendRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    account_id: str = Field(default="acc_default", max_length=64)
    to: list[str] = Field(min_length=1)
    subject: str = Field(min_length=1, max_length=512)
    body_text: str = Field(default="", max_length=262144)
    body_html: str = Field(default="", max_length=262144)
    idempotency_key: str | None = Field(default=None, max_length=128)
    undo_window_seconds: float = Field(default=0.0, ge=0.0, le=60.0)


class MailMoveRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    target_folder: str = Field(default="Trash", max_length=64)
    delete_permanently: bool = False


class MailSnoozeRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    snoozed_until: str = Field(min_length=10, max_length=64)


class NoteCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    title: str = Field(min_length=1, max_length=256)
    content: str = Field(default="", max_length=524288)
    folder: str = Field(default="General", max_length=128)
    tags: list[str] = Field(default_factory=list)
    pinned: bool = False


class NoteUpdateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    title: str | None = Field(default=None, max_length=256)
    content: str | None = Field(default=None, max_length=524288)
    folder: str | None = Field(default=None, max_length=128)
    tags: list[str] | None = None
    pinned: bool | None = None


class TodoCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    title: str = Field(min_length=1, max_length=256)
    description: str = Field(default="", max_length=16384)
    due_date: str | None = Field(default=None, max_length=64)
    priority: str = Field(default="medium", max_length=16)
    status: str = Field(default="todo", max_length=32)
    subtasks: list[str] = Field(default_factory=list)
    recurrence_rule: str | None = Field(default=None, max_length=128)
    linked_entities: list[dict[str, str]] = Field(default_factory=list)


class TodoUpdateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    title: str | None = Field(default=None, max_length=256)
    description: str | None = Field(default=None, max_length=16384)
    due_date: str | None = Field(default=None, max_length=64)
    priority: str | None = Field(default=None, max_length=16)
    status: str | None = Field(default=None, max_length=32)
    completed: bool | None = None


class TodoAssignAgentRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    agent_instructions: str = Field(default="", max_length=4096)
    simulate_failure: bool = False


class CalendarEventCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    title: str = Field(min_length=1, max_length=256)
    start_local: str = Field(min_length=10, max_length=64)
    duration_minutes: int = Field(default=60, ge=5, le=1440)
    timezone: str = Field(default="UTC", max_length=64)
    description: str = Field(default="", max_length=8192)
    location: str = Field(default="", max_length=256)
    all_day: bool = False
    rrule: str | None = Field(default=None, max_length=256)
    exdates: list[str] = Field(default_factory=list)
    reminders_minutes_before: list[int] = Field(default_factory=lambda: [15])


class CalendarEventUpdateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    title: str | None = Field(default=None, max_length=256)
    description: str | None = Field(default=None, max_length=8192)
    location: str | None = Field(default=None, max_length=256)
    start_local: str | None = Field(default=None, max_length=64)
    duration_minutes: int | None = Field(default=None, ge=5, le=1440)
    rrule: str | None = Field(default=None, max_length=256)
    expected_etag: str | None = Field(default=None, max_length=128)


class CalendarQuickAddRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    text: str = Field(min_length=1, max_length=512)
    timezone: str = Field(default="UTC", max_length=64)
    commit: bool = False


class CalendarConflictResolveRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    strategy: str = Field(default="keep_local", max_length=32)


class CalendarIcsImportRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    ics_text: str = Field(min_length=1, max_length=4_194_304)


class ScheduleCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1, max_length=256)
    kind: str = Field(default="cron", max_length=32)
    cron_expr: str = Field(default="0 9 * * *", max_length=128)
    timezone: str = Field(default="UTC", max_length=64)
    prompt_template: str = Field(
        default="Briefing for {{date}}. Prior: {{last_run_summary}}",
        max_length=8192,
    )
    misfire_policy: str = Field(default="run_once", max_length=32)
    overlap_policy: str = Field(default="skip", max_length=32)
    delivery_targets: list[str] = Field(default_factory=lambda: ["in_app"])


class ScheduleToggleRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    enabled: bool = True


class ScheduleRunNowRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    scheduled_slot_iso: str = Field(default="2026-10-04T09:00:00Z", max_length=64)
    simulate_error: str | None = Field(default=None, max_length=256)


class NotificationEmitRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    event_class: str = Field(default="run.approval_needed", max_length=64)
    title: str = Field(min_length=1, max_length=256)
    body: str = Field(default="", max_length=4096)
    severity: str = Field(default="info", max_length=32)
    channels: list[str] | None = None


class OutboundWebhookCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1, max_length=128)
    target_url: str = Field(min_length=8, max_length=1024)
    event_types: list[str] = Field(default_factory=lambda: ["run.completed", "todo.completed"])
    signing_secret: str | None = Field(default=None, max_length=256)


class OutboundWebhookDispatchRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    event_type: str = Field(default="run.completed", max_length=64)
    payload: dict[str, Any] = Field(default_factory=dict)
    simulate_failures: int = Field(default=0, ge=0, le=10)


class ApiTokenCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1, max_length=128)
    scopes: list[str] = Field(default_factory=lambda: ["chats:write", "todos:write"])
    expires_in_days: int = Field(default=30, ge=1, le=365)
    rate_limit_per_minute: int = Field(default=60, ge=1, le=6000)


def _get_mail_svc(request: Request) -> MailService:
    svc: MailService = request.app.state.mail_service
    return svc


def _get_notes_svc(request: Request) -> NotesAndTodosService:
    svc: NotesAndTodosService = request.app.state.notes_service
    return svc


def _get_cal_svc(request: Request) -> CalendarService:
    svc: CalendarService = request.app.state.calendar_service
    return svc


def _get_sched_svc(request: Request) -> SchedulerService:
    svc: SchedulerService = request.app.state.scheduler_service
    return svc


def _get_notif_svc(request: Request) -> NotificationsAndWebhooksService:
    svc: NotificationsAndWebhooksService = request.app.state.notifications_service
    return svc


# --- 1. Mail Endpoints ---


register_route_policy("GET", "/api/mail/accounts", "chat")


@router.get("/api/mail/accounts")
async def list_mail_accounts(
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_mail_svc(request)
    return {"accounts": svc.list_accounts(principal.user.id)}


register_route_policy("POST", "/api/mail/accounts", "chat")


@router.post("/api/mail/accounts")
async def create_mail_account(
    body: MailAccountCreateRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_mail_svc(request)
    acc = svc.add_account(
        owner_user_id=principal.user.id,
        email_address=body.email_address,
        display_name=body.display_name,
        imap_host=body.imap_host,
        imap_port=body.imap_port,
        smtp_host=body.smtp_host,
        smtp_port=body.smtp_port,
        use_tls=body.use_tls,
        auth_method=body.auth_method,
        secret_credential=body.secret_credential,
    )
    return {"account": acc.to_public_dict()}


register_route_policy("GET", "/api/mail/messages", "chat")


@router.get("/api/mail/messages")
async def list_mail_messages(
    request: Request,
    query: str = "",
    folder: str | None = None,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_mail_svc(request)
    msgs = svc.search_messages(query, owner_user_id=principal.user.id, folder=folder)
    return {"messages": msgs}


register_route_policy("GET", "/api/mail/messages/{message_id}", "chat")


@router.get("/api/mail/messages/{message_id}")
async def get_mail_message(
    message_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_mail_svc(request)
    try:
        return {
            "message": svc.get_message(
                message_id,
                owner_user_id=principal.user.id,
                requester_user_id=principal.user.id,
            )
        }
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("POST", "/api/mail/messages/{message_id}/triage", "chat")


@router.post("/api/mail/messages/{message_id}/triage")
async def triage_mail_message(
    message_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_mail_svc(request)
    try:
        res = svc.triage_message(
            message_id,
            owner_user_id=principal.user.id,
            requester_user_id=principal.user.id,
        )
        return {"triage": res.to_dict()}
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("POST", "/api/mail/messages/{message_id}/allow-remote", "chat")


@router.post("/api/mail/messages/{message_id}/allow-remote")
async def allow_mail_remote_content(
    message_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_mail_svc(request)
    try:
        msg = svc.get_message(
            message_id,
            owner_user_id=principal.user.id,
            requester_user_id=principal.user.id,
        )
        svc.allow_remote_content_for_sender(principal.user.id, str(msg["sender"]))
        return {
            "message": svc.get_message(
                message_id,
                owner_user_id=principal.user.id,
                requester_user_id=principal.user.id,
            )
        }
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("POST", "/api/mail/messages/{message_id}/move", "chat")


@router.post("/api/mail/messages/{message_id}/move")
async def move_mail_message(
    message_id: str,
    body: MailMoveRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_mail_svc(request)
    try:
        return svc.move_or_delete_message(
            message_id,
            target_folder=body.target_folder,
            delete_permanently=body.delete_permanently,
            requester_user_id=principal.user.id,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("POST", "/api/mail/messages/{message_id}/snooze", "chat")


@router.post("/api/mail/messages/{message_id}/snooze")
async def snooze_mail_message(
    message_id: str,
    body: MailSnoozeRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_mail_svc(request)
    try:
        return svc.snooze_message(
            message_id, body.snoozed_until, requester_user_id=principal.user.id
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("POST", "/api/mail/send", "chat")


@router.post("/api/mail/send")
async def send_mail_message(
    body: MailSendRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_mail_svc(request)
    return svc.send_message(
        owner_user_id=principal.user.id,
        account_id=body.account_id,
        to=body.to,
        subject=body.subject,
        body_text=body.body_text,
        body_html=body.body_html,
        idempotency_key=body.idempotency_key,
        undo_window_seconds=body.undo_window_seconds,
    )


register_route_policy("POST", "/api/mail/outbox/{outbox_id}/cancel", "chat")


@router.post("/api/mail/outbox/{outbox_id}/cancel")
async def cancel_mail_outbox_send(
    outbox_id: str,
    request: Request,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_mail_svc(request)
    try:
        return svc.cancel_undo_send(outbox_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


# --- 2. Notes & Todos Endpoints ---


register_route_policy("GET", "/api/notes", "chat")


@router.get("/api/notes")
async def list_notes(
    request: Request,
    query: str = "",
    tag: str | None = None,
    folder: str | None = None,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_notes_svc(request)
    return {
        "notes": svc.search_notes(
            query,
            owner_user_id=principal.user.id,
            tag=tag,
            folder=folder,
        )
    }


register_route_policy("POST", "/api/notes", "chat")


@router.post("/api/notes")
async def create_note(
    body: NoteCreateRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_notes_svc(request)
    note = svc.create_note(
        owner_user_id=principal.user.id,
        title=body.title,
        content=body.content,
        folder=body.folder,
        tags=body.tags,
        pinned=body.pinned,
    )
    return {"note": note}


register_route_policy("GET", "/api/notes/{note_id}", "chat")


@router.get("/api/notes/{note_id}")
async def get_note(
    note_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_notes_svc(request)
    try:
        return {"note": svc.get_note(note_id, requester_user_id=principal.user.id)}
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("PUT", "/api/notes/{note_id}", "chat")


@router.put("/api/notes/{note_id}")
async def update_note(
    note_id: str,
    body: NoteUpdateRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_notes_svc(request)
    try:
        return {
            "note": svc.update_note(
                note_id,
                title=body.title,
                content=body.content,
                folder=body.folder,
                tags=body.tags,
                pinned=body.pinned,
                requester_user_id=principal.user.id,
            )
        }
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("GET", "/api/notes/export/zip", "chat")


@router.get("/api/notes/export/zip")
async def export_notes_zip(
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> Response:
    svc = _get_notes_svc(request)
    payload = svc.export_notes_zip(owner_user_id=principal.user.id)
    return Response(
        content=payload,
        media_type="application/zip",
        headers={"Content-Disposition": 'attachment; filename="odysseus-notes.zip"'},
    )


register_route_policy("GET", "/api/todos", "chat")


@router.get("/api/todos")
async def list_todos(
    request: Request,
    status: str | None = None,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_notes_svc(request)
    return {
        "todos": svc.list_todos(owner_user_id=principal.user.id, status=status),
        "kanban": svc.get_kanban_board(owner_user_id=principal.user.id),
    }


register_route_policy("POST", "/api/todos", "chat")


@router.post("/api/todos")
async def create_todo(
    body: TodoCreateRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_notes_svc(request)
    todo = svc.create_todo(
        owner_user_id=principal.user.id,
        title=body.title,
        description=body.description,
        due_date=body.due_date,
        priority=body.priority,
        status=body.status,
        subtasks=body.subtasks,
        recurrence_rule=body.recurrence_rule,
        linked_entities=body.linked_entities,
    )
    return {"todo": todo}


register_route_policy("PUT", "/api/todos/{todo_id}", "chat")


@router.put("/api/todos/{todo_id}")
async def update_todo(
    todo_id: str,
    body: TodoUpdateRequest,
    request: Request,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_notes_svc(request)
    try:
        return {
            "todo": svc.update_todo(
                todo_id,
                title=body.title,
                description=body.description,
                due_date=body.due_date,
                priority=body.priority,
                status=body.status,
                completed=body.completed,
            )
        }
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("POST", "/api/todos/{todo_id}/complete", "chat")


@router.post("/api/todos/{todo_id}/complete")
async def complete_todo(
    todo_id: str,
    request: Request,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_notes_svc(request)
    try:
        return {"todo": svc.complete_todo(todo_id)}
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("POST", "/api/todos/{todo_id}/assign-agent", "chat")


@router.post("/api/todos/{todo_id}/assign-agent")
async def assign_todo_to_agent(
    todo_id: str,
    body: TodoAssignAgentRequest,
    request: Request,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_notes_svc(request)
    try:
        return {
            "todo": svc.assign_todo_to_agent(
                todo_id,
                agent_instructions=body.agent_instructions,
                simulate_failure=body.simulate_failure,
            )
        }
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


# --- 3. Calendar & CalDAV Endpoints ---


register_route_policy("GET", "/api/calendar/events", "chat")


@router.get("/api/calendar/events")
async def list_calendar_events(
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_cal_svc(request)
    return {
        "calendars": svc.list_calendars(principal.user.id),
        "events": svc.list_events(owner_user_id=principal.user.id),
        "conflicts": svc.list_conflicts(),
    }


register_route_policy("POST", "/api/calendar/events", "chat")


@router.post("/api/calendar/events")
async def create_calendar_event(
    body: CalendarEventCreateRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_cal_svc(request)
    ev = svc.create_event(
        owner_user_id=principal.user.id,
        title=body.title,
        start_local=body.start_local,
        duration_minutes=body.duration_minutes,
        timezone=body.timezone,
        description=body.description,
        location=body.location,
        all_day=body.all_day,
        rrule=body.rrule,
        exdates=body.exdates,
        reminders_minutes_before=body.reminders_minutes_before,
    )
    return {"event": ev}


register_route_policy("PUT", "/api/calendar/events/{event_id}", "chat")


@router.put("/api/calendar/events/{event_id}")
async def update_calendar_event(
    event_id: str,
    body: CalendarEventUpdateRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_cal_svc(request)
    try:
        return svc.update_event(
            event_id,
            requester_user_id=principal.user.id,
            title=body.title,
            description=body.description,
            location=body.location,
            start_local=body.start_local,
            duration_minutes=body.duration_minutes,
            rrule=body.rrule,
            expected_etag=body.expected_etag,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("DELETE", "/api/calendar/events/{event_id}", "chat")


@router.delete("/api/calendar/events/{event_id}")
async def delete_calendar_event(
    event_id: str,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_cal_svc(request)
    try:
        return svc.delete_event(event_id, requester_user_id=principal.user.id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("POST", "/api/calendar/quick-add", "chat")


@router.post("/api/calendar/quick-add")
async def quick_add_calendar_event(
    body: CalendarQuickAddRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_cal_svc(request)
    parsed = parse_natural_language_event(body.text, timezone=body.timezone)
    created = None
    if body.commit:
        created = svc.create_event(
            owner_user_id=principal.user.id,
            title=str(parsed["title"]),
            start_local=str(parsed["start_iso"])[:19],
            duration_minutes=int(parsed["duration_minutes"]),
            timezone=body.timezone,
        )
    return {"preview": parsed, "event": created}


register_route_policy("POST", "/api/calendar/sync", "chat")


@router.post("/api/calendar/sync")
async def sync_caldav_calendar(
    request: Request,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_cal_svc(request)
    return svc.sync_caldav_collection("cal_default")


register_route_policy("POST", "/api/calendar/conflicts/{conflict_id}/resolve", "chat")


@router.post("/api/calendar/conflicts/{conflict_id}/resolve")
async def resolve_caldav_conflict(
    conflict_id: str,
    body: CalendarConflictResolveRequest,
    request: Request,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_cal_svc(request)
    try:
        return svc.resolve_conflict(conflict_id, strategy=body.strategy)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("GET", "/api/calendar/free-busy", "chat")


@router.get("/api/calendar/free-busy")
async def get_calendar_free_busy(
    request: Request,
    day_iso: str = "2026-10-05",
    timezone: str = "UTC",
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_cal_svc(request)
    return svc.find_free_busy_slots(day_iso=day_iso, timezone=timezone)


register_route_policy("GET", "/api/calendar/export.ics", "chat")


@router.get("/api/calendar/export.ics")
async def export_calendar_ics(
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> Response:
    svc = _get_cal_svc(request)
    ics_text = svc.export_ics(owner_user_id=principal.user.id)
    return Response(
        content=ics_text,
        media_type="text/calendar",
        headers={"Content-Disposition": 'attachment; filename="odysseus.ics"'},
    )


register_route_policy("POST", "/api/calendar/import.ics", "chat")


@router.post("/api/calendar/import.ics")
async def import_calendar_ics(
    body: CalendarIcsImportRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_cal_svc(request)
    try:
        return svc.import_ics(body.ics_text, owner_user_id=principal.user.id)
    except ValueError as exc:
        raise HTTPException(status_code=413, detail=str(exc)) from exc


# --- 4. Schedules & Automations Endpoints ---


register_route_policy("GET", "/api/schedules", "chat")


@router.get("/api/schedules")
async def list_schedules(
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_sched_svc(request)
    return {"schedules": svc.list_schedules(owner_user_id=principal.user.id)}


register_route_policy("POST", "/api/schedules", "chat")


@router.post("/api/schedules")
async def create_schedule(
    body: ScheduleCreateRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_sched_svc(request)
    try:
        sched = svc.create_schedule(
            owner_user_id=principal.user.id,
            name=body.name,
            kind=body.kind,
            cron_expr=body.cron_expr,
            timezone=body.timezone,
            prompt_template=body.prompt_template,
            misfire_policy=body.misfire_policy,
            overlap_policy=body.overlap_policy,
            delivery_targets=body.delivery_targets,
        )
        return {"schedule": sched}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


register_route_policy("GET", "/api/schedules/{schedule_id}", "chat")


@router.get("/api/schedules/{schedule_id}")
async def get_schedule(
    schedule_id: str,
    request: Request,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_sched_svc(request)
    try:
        return {"schedule": svc.get_schedule(schedule_id)}
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("POST", "/api/schedules/{schedule_id}/toggle", "chat")


@router.post("/api/schedules/{schedule_id}/toggle")
async def toggle_schedule(
    schedule_id: str,
    body: ScheduleToggleRequest,
    request: Request,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_sched_svc(request)
    try:
        return {"schedule": svc.toggle_schedule(schedule_id, enabled=body.enabled)}
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("POST", "/api/schedules/{schedule_id}/run-now", "chat")


@router.post("/api/schedules/{schedule_id}/run-now")
async def run_schedule_now(
    schedule_id: str,
    body: ScheduleRunNowRequest,
    request: Request,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_sched_svc(request)
    try:
        return svc.execute_firing_window(
            schedule_id,
            scheduled_slot_iso=body.scheduled_slot_iso,
            simulate_error=body.simulate_error,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


# --- 5. Notifications, Webhooks, API Tokens & Admin-Gated /api/docs ---


register_route_policy("GET", "/api/notifications", "chat")


@router.get("/api/notifications")
async def list_notifications(
    request: Request,
    unread_only: bool = False,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_notif_svc(request)
    items = svc.list_notifications(owner_user_id=principal.user.id, unread_only=unread_only)
    return {
        "notifications": items,
        "unread_count": sum(1 for n in items if not n["read"]),
        "vapid_public_key": svc.get_vapid_public_key(),
    }


register_route_policy("POST", "/api/notifications", "chat")


@router.post("/api/notifications")
async def emit_notification_route(
    body: NotificationEmitRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_notif_svc(request)
    notif = svc.emit_notification(
        owner_user_id=principal.user.id,
        event_class=body.event_class,
        title=body.title,
        body=body.body,
        severity=body.severity,
        channels=body.channels,
    )
    return {"notification": notif}


register_route_policy("POST", "/api/notifications/{notification_id}/read", "chat")


@router.post("/api/notifications/{notification_id}/read")
async def mark_notification_read_route(
    notification_id: str,
    request: Request,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_notif_svc(request)
    try:
        return {"notification": svc.mark_notification_read(notification_id)}
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("POST", "/api/webhooks/inbound/{endpoint_id}", "public")


@router.post("/api/webhooks/inbound/{endpoint_id}")
async def receive_inbound_webhook(
    endpoint_id: str,
    request: Request,
    _principal: Principal = Depends(require("public")),
) -> dict[str, Any]:
    svc = _get_notif_svc(request)
    raw_bytes = await request.body()
    raw_body = raw_bytes.decode("utf-8", errors="replace")
    ts_hdr = request.headers.get("X-Odysseus-Timestamp", "")
    sig_hdr = request.headers.get("X-Odysseus-Signature", "")
    nonce_hdr = request.headers.get("X-Odysseus-Nonce", "")
    res = svc.verify_and_dispatch_inbound_webhook(
        endpoint_id=endpoint_id,
        raw_body=raw_body,
        timestamp_header=ts_hdr,
        signature_header=sig_hdr,
        nonce_header=nonce_hdr,
    )
    if not res["accepted"]:
        raise HTTPException(status_code=int(res["status_code"]), detail=str(res["error"]))
    return res


register_route_policy("GET", "/api/webhooks/outbound", "chat")


@router.get("/api/webhooks/outbound")
async def list_outbound_webhooks_route(
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_notif_svc(request)
    return {
        "webhooks": svc.list_outbound_webhooks(principal.user.id),
        "dead_letters": svc.list_dead_letters(),
    }


register_route_policy("POST", "/api/webhooks/outbound", "chat")


@router.post("/api/webhooks/outbound")
async def register_outbound_webhook_route(
    body: OutboundWebhookCreateRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_notif_svc(request)
    try:
        wh = svc.register_outbound_webhook(
            owner_user_id=principal.user.id,
            name=body.name,
            target_url=body.target_url,
            event_types=body.event_types,
            signing_secret=body.signing_secret,
        )
        return {"webhook": wh}
    except SsrfBlockedError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


register_route_policy("POST", "/api/webhooks/outbound/{webhook_id}/dispatch", "chat")


@router.post("/api/webhooks/outbound/{webhook_id}/dispatch")
async def dispatch_outbound_webhook_route(
    webhook_id: str,
    body: OutboundWebhookDispatchRequest,
    request: Request,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_notif_svc(request)
    try:
        return svc.dispatch_outbound_webhook(
            webhook_id,
            event_type=body.event_type,
            payload=body.payload,
            simulate_failures=body.simulate_failures,
        )
    except SsrfBlockedError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("POST", "/api/webhooks/dead-letters/{delivery_id}/replay", "chat")


@router.post("/api/webhooks/dead-letters/{delivery_id}/replay")
async def replay_dead_letter_route(
    delivery_id: str,
    request: Request,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_notif_svc(request)
    try:
        return {"delivery": svc.replay_dead_letter(delivery_id)}
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("GET", "/api/tokens", "chat")


@router.get("/api/tokens")
async def list_api_tokens_route(
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_notif_svc(request)
    return {"tokens": svc.list_api_tokens(owner_user_id=principal.user.id)}


register_route_policy("POST", "/api/tokens", "chat")


@router.post("/api/tokens")
async def create_api_token_route(
    body: ApiTokenCreateRequest,
    request: Request,
    principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_notif_svc(request)
    return {
        "token": svc.create_api_token(
            owner_user_id=principal.user.id,
            name=body.name,
            scopes=body.scopes,
            expires_in_days=body.expires_in_days,
            rate_limit_per_minute=body.rate_limit_per_minute,
        )
    }


register_route_policy("DELETE", "/api/tokens/{token_id}", "chat")


@router.delete("/api/tokens/{token_id}")
async def revoke_api_token_route(
    token_id: str,
    request: Request,
    _principal: Principal = Depends(require("chat")),
) -> dict[str, Any]:
    svc = _get_notif_svc(request)
    try:
        return {"token": svc.revoke_api_token(token_id)}
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


register_route_policy("GET", "/api/docs", "admin")


@router.get("/api/docs")
async def get_admin_api_docs(
    request: Request,
    _principal: Principal = Depends(require("admin")),
) -> dict[str, Any]:
    """Admin-gated OpenAPI specification and interactive API reference metadata."""
    schema = request.app.openapi()
    return {
        "title": schema.get("info", {}).get("title", "Odysseus API"),
        "version": schema.get("info", {}).get("version", "0.1.0"),
        "route_count": len(schema.get("paths", {})),
        "openapi": schema,
    }
