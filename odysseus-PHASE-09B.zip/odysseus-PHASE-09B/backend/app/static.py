"""Static asset serving with immutable cache control, br/gzip negotiation, and SPA fallback."""

from __future__ import annotations

import asyncio
import mimetypes
from pathlib import Path

from fastapi import APIRouter, Request, Response
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse

from backend.core.security import register_route_policy

router = APIRouter(tags=["static"])

NO_CACHE_FILES: frozenset[str] = frozenset(
    {
        "index.html",
        "sw.js",
        "service-worker.js",
        "manifest.webmanifest",
        "manifest.json",
    }
)

FALLBACK_HTML = """<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="theme-color" content="#3F6D68" />
    <link rel="icon" href="/favicon.svg" type="image/svg+xml" />
    <title>PRODUCT_NAME — A quiet workspace for consequential work.</title>
  </head>
  <body>
    <main id="root">
      <h1>PRODUCT_NAME</h1>
      <p>A quiet workspace for consequential work.</p>
    </main>
  </body>
</html>
"""


def _serve_file_with_encoding(
    target: Path,
    accept_encoding: str,
    *,
    immutable: bool,
) -> Response:
    media_type, _ = mimetypes.guess_type(str(target))
    content_type = media_type or "application/octet-stream"
    headers: dict[str, str] = {}

    if immutable:
        headers["Cache-Control"] = "public, max-age=31536000, immutable"
    else:
        headers["Cache-Control"] = "no-cache, no-store, must-revalidate"

    ae_lower = accept_encoding.lower()
    br_path = Path(str(target) + ".br")
    gz_path = Path(str(target) + ".gz")

    if "br" in ae_lower and br_path.is_file():
        headers["Content-Encoding"] = "br"
        headers["Vary"] = "Accept-Encoding"
        return FileResponse(br_path, media_type=content_type, headers=headers)

    if "gzip" in ae_lower and gz_path.is_file():
        headers["Content-Encoding"] = "gzip"
        headers["Vary"] = "Accept-Encoding"
        return FileResponse(gz_path, media_type=content_type, headers=headers)

    return FileResponse(target, media_type=content_type, headers=headers)


def _resolve_static_response(
    dist_dir: Path,
    full_path: str | None,
    accept_enc: str,
) -> Response:
    resolved_dist = dist_dir.resolve()
    if full_path is not None and resolved_dist.is_dir():
        candidate = (resolved_dist / full_path).resolve()
        if str(candidate).startswith(str(resolved_dist)) and candidate.is_file():
            is_hashed_asset = full_path.startswith("assets/") and (
                candidate.name not in NO_CACHE_FILES
            )
            return _serve_file_with_encoding(candidate, accept_enc, immutable=is_hashed_asset)

    index_path = resolved_dist / "index.html"
    if index_path.is_file():
        return _serve_file_with_encoding(index_path, accept_enc, immutable=False)

    return HTMLResponse(
        content=FALLBACK_HTML,
        headers={"Cache-Control": "no-cache, no-store, must-revalidate"},
    )


register_route_policy("GET", "/", "public")


@router.get("/", include_in_schema=False)
async def serve_spa_root(request: Request) -> Response:
    """Serve the built frontend SPA index.html with no-cache headers."""
    dist_dir: Path = request.app.state.settings.frontend_dist_dir
    accept_enc = request.headers.get("Accept-Encoding", "")
    return await asyncio.to_thread(_resolve_static_response, dist_dir, None, accept_enc)


register_route_policy("GET", "/{full_path:path}", "public")


@router.get("/{full_path:path}", include_in_schema=False)
async def serve_spa_or_asset(full_path: str, request: Request) -> Response:
    """Serve hashed static assets with immutable caching or SPA fallback to index.html."""
    if full_path.startswith("api/") or full_path == "api":
        return JSONResponse(status_code=404, content={"detail": "API route not found"})

    dist_dir: Path = request.app.state.settings.frontend_dist_dir
    accept_enc = request.headers.get("Accept-Encoding", "")
    return await asyncio.to_thread(_resolve_static_response, dist_dir, full_path, accept_enc)
