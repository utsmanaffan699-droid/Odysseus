"""FastAPI application factory and lifespan management for Odysseus."""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse

from backend.app.routers import admin as admin_router
from backend.app.routers import agents as agents_router
from backend.app.routers import auth as auth_router
from backend.app.routers import health as health_router
from backend.app.routers import knowledge as knowledge_router
from backend.app.routers import phase08 as phase08_router
from backend.app.routers import productivity as productivity_router
from backend.app.routers import runs as runs_router
from backend.app.static import router as static_router
from backend.core.auth import LoginThrottler, bootstrap_first_admin
from backend.core.brand import render_branded_error_html
from backend.core.crypto import EnvelopeVault
from backend.core.db import DatabaseManager, set_disk_degraded
from backend.core.jobs import JobSupervisor
from backend.core.logging import (
    configure_logging,
    get_logger,
    register_secret_for_redaction,
)
from backend.core.middleware import (
    BodySizeAndTimeoutEnforcerMiddleware,
    InMemoryRateLimiter,
    SecurityAndObservabilityMiddleware,
)
from backend.core.migrations import upgrade_db_async
from backend.core.settings import Settings, load_settings
from backend.core.uow import UnitOfWork
from backend.domain.admin_ops import AdminOpsService
from backend.domain.chats import AttachmentService, ChatService
from backend.domain.compare import CompareService
from backend.domain.cookbook import CookbookService
from backend.domain.documents import DocumentsService
from backend.domain.gallery import GalleryService
from backend.domain.memory import MemoryService
from backend.domain.notifications import NotificationsAndWebhooksService
from backend.domain.rag import RagService
from backend.domain.research import DeepResearchService
from backend.domain.runs import RunManager, UsageService
from backend.domain.schedules import SchedulerService
from backend.domain.skills import SkillService
from backend.domain.tools import ToolPolicyEngine, ToolRegistry
from backend.domain.voice import VoiceService
from backend.mcp import McpClientManager
from backend.providers.fake import FakeProvider
from backend.providers.resilience import ResilientProviderRouter

logger = get_logger("odysseus.app")


def create_app(
    settings: Settings | None = None,
    *,
    start_job_workers: bool = True,
    fake_provider: FakeProvider | None = None,
) -> FastAPI:
    """Construct the Odysseus FastAPI application with full middleware and lifespan hooks."""
    effective_settings = settings if settings is not None else load_settings()
    configure_logging(effective_settings.log_level)

    for secret_val in effective_settings.collect_secret_values():
        register_secret_for_redaction(secret_val)

    set_disk_degraded(None)
    db = DatabaseManager(effective_settings)
    vault = EnvelopeVault(
        effective_settings.data_dir,
        master_key_override=effective_settings.master_key_override,
    )
    throttler = LoginThrottler(effective_settings)
    rate_limiter = InMemoryRateLimiter(
        requests_per_minute=effective_settings.rate_limit_requests_per_minute,
        burst=effective_settings.rate_limit_burst,
    )
    job_supervisor = JobSupervisor(db, effective_settings)
    effective_fake = fake_provider or FakeProvider()
    provider_router = ResilientProviderRouter(
        effective_settings,
        db=db,
        vault=vault,
        default_fake=effective_fake,
    )
    chat_service = ChatService(db)
    attachment_service = AttachmentService(
        db,
        effective_settings,
        jobs=job_supervisor,
        storage_root=effective_settings.data_dir / "attachments",
    )
    usage_service = UsageService(db)
    tool_registry = ToolRegistry()
    policy_engine = ToolPolicyEngine()
    memory_service = MemoryService(db, effective_settings)
    skill_service = SkillService(db)
    mcp_manager = McpClientManager(db, effective_settings, vault=vault)
    rag_service = RagService()
    research_service = DeepResearchService()
    compare_service = CompareService()
    documents_service = DocumentsService()
    mail_service = tool_registry.mail_service
    notes_service = tool_registry.notes_service
    calendar_service = tool_registry.calendar_service
    scheduler_service = SchedulerService()
    notifications_service = NotificationsAndWebhooksService()
    cookbook_service = CookbookService(data_dir=effective_settings.data_dir)
    gallery_service = GalleryService()
    voice_service = VoiceService()
    admin_ops_service = AdminOpsService()
    run_manager = RunManager(
        db,
        effective_settings,
        provider_router,
        chat_service,
        usage_service,
        jobs=job_supervisor,
        tool_registry=tool_registry,
        policy_engine=policy_engine,
        memory_service=memory_service,
        skill_service=skill_service,
        mcp_manager=mcp_manager,
    )

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        app.state.settings.data_dir.mkdir(parents=True, exist_ok=True)
        app.state.settings.logs_dir.mkdir(parents=True, exist_ok=True)

        # 1. Run database migrations to head
        await upgrade_db_async(db.engine, "head")

        # 2. Load any DB-stored runtime settings overrides and bootstrap initial admin user
        async def _bootstrap_op(sess: object) -> None:
            from sqlalchemy.ext.asyncio import AsyncSession

            assert isinstance(sess, AsyncSession)
            uow = UnitOfWork(sess)
            runtime_overrides = await uow.settings.get_all_runtime()
            if runtime_overrides:
                app.state.settings = app.state.settings.apply_runtime_overrides(runtime_overrides)

            boot_res = await bootstrap_first_admin(uow, app.state.settings)
            app.state.bootstrap_admin_result = boot_res
            if boot_res.created and boot_res.temporary_password:
                # Print temporary admin password ONCE to stdout as required by spec
                print(
                    f"[ODYSSEUS BOOTSTRAP] Initial admin user '{boot_res.username}' created. "
                    f"Temporary password (must_change=true): {boot_res.temporary_password}",
                    flush=True,
                )
                # Register temporary password for redaction in all subsequent logs
                register_secret_for_redaction(boot_res.temporary_password)

        await db.execute_write(_bootstrap_op)

        # 3. Recover interrupted runs/leases and optionally start job supervisor workers
        if start_job_workers:
            await job_supervisor.start()
        else:
            await job_supervisor.recover_interrupted_work(reclaim_expired_only=False)

        for warning in app.state.settings.production_warnings():
            logger.warning("security_posture_warning", detail=warning)
        posture_error = app.state.settings.exec_isolation_posture_error()
        if posture_error is not None and app.state.settings.environment == "production":
            logger.warning("exec_posture_refusal", detail=posture_error)

        logger.info(
            "odysseus_started",
            environment=app.state.settings.environment,
            bind_host=app.state.settings.bind_host,
            port=app.state.settings.port,
        )
        try:
            yield
        finally:
            await run_manager.shutdown()
            await chat_service.shutdown()
            await job_supervisor.stop()
            await db.dispose()
            logger.info("odysseus_stopped")

    app = FastAPI(
        title="Odysseus API",
        version="0.1.0",
        description="Production-grade self-hosted AI workspace and durable agent runtime.",
        docs_url=None,
        redoc_url=None,
        openapi_url=None,
        lifespan=lifespan,
    )

    app.state.settings = effective_settings
    app.state.db = db
    app.state.vault = vault
    app.state.throttler = throttler
    app.state.rate_limiter = rate_limiter
    app.state.job_supervisor = job_supervisor
    app.state.fake_provider = effective_fake
    app.state.provider_router = provider_router
    app.state.chat_service = chat_service
    app.state.attachment_service = attachment_service
    app.state.usage_service = usage_service
    app.state.tool_registry = tool_registry
    app.state.policy_engine = policy_engine
    app.state.memory_service = memory_service
    app.state.skill_service = skill_service
    app.state.mcp_manager = mcp_manager
    app.state.rag_service = rag_service
    app.state.research_service = research_service
    app.state.compare_service = compare_service
    app.state.documents_service = documents_service
    app.state.mail_service = mail_service
    app.state.notes_service = notes_service
    app.state.calendar_service = calendar_service
    app.state.scheduler_service = scheduler_service
    app.state.notifications_service = notifications_service
    app.state.cookbook_service = cookbook_service
    app.state.gallery_service = gallery_service
    app.state.voice_service = voice_service
    app.state.admin_ops_service = admin_ops_service
    app.state.run_manager = run_manager
    app.state.bootstrap_admin_result = None

    @app.exception_handler(HTTPException)
    async def branded_http_error(
        request: Request, exc: HTTPException
    ) -> JSONResponse | HTMLResponse:
        """Keep API errors machine-readable and browser errors branded/localizable."""
        if request.url.path.startswith("/api"):
            return JSONResponse(
                status_code=exc.status_code, content={"detail": exc.detail}, headers=exc.headers
            )
        detail = (
            str(exc.detail)
            if isinstance(exc.detail, str)
            else "The request could not be completed."
        )
        return HTMLResponse(
            status_code=exc.status_code, content=render_branded_error_html(exc.status_code, detail)
        )

    @app.exception_handler(Exception)
    async def branded_internal_error(
        request: Request, exc: Exception
    ) -> JSONResponse | HTMLResponse:
        """Prevent raw tracebacks on browser/API error surfaces while retaining server logs."""
        logger.error("unhandled_request_error", path=request.url.path, error=repr(exc))
        if request.url.path.startswith("/api"):
            return JSONResponse(status_code=500, content={"detail": "Internal server error"})
        return HTMLResponse(
            status_code=500,
            content=render_branded_error_html(
                500, "The workspace could not complete that request."
            ),
        )

    app.add_middleware(
        SecurityAndObservabilityMiddleware,
        settings=effective_settings,
        rate_limiter=rate_limiter,
    )
    app.add_middleware(
        BodySizeAndTimeoutEnforcerMiddleware,
        settings=effective_settings,
    )

    app.include_router(health_router.router)
    app.include_router(auth_router.router)
    app.include_router(runs_router.router)
    app.include_router(agents_router.router)
    app.include_router(knowledge_router.router)
    app.include_router(productivity_router.router)
    app.include_router(phase08_router.router)
    app.include_router(admin_router.router)
    app.include_router(static_router)

    return app


app = create_app()
