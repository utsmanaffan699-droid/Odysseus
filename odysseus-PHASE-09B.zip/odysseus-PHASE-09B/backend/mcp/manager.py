"""MCP Client Manager: stdio, SSE, streamable-HTTP lifecycle, poisoning defense, logs."""

from __future__ import annotations

import asyncio
import collections
import contextlib
import json
import os
import re
import shutil
import sys
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal

import httpx
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.crypto import EnvelopeVault
from backend.core.db import DatabaseManager
from backend.core.logging import register_secret_for_redaction
from backend.core.models import McpServerRecord
from backend.core.settings import Settings
from backend.core.uow import UnitOfWork, _ensure_utc
from backend.domain.events import ToolRiskLiteral
from backend.domain.tools.provenance import strip_invisible_and_tag_chars
from backend.providers.base import ProviderToolSpec

McpTransportLiteral = Literal["stdio", "sse", "streamable_http"]
_REPO_ROOT_STR = str(Path(__file__).resolve().parents[2])

_POISON_PATTERNS = (
    re.compile(r"ignore\s+(?:all\s+)?(?:previous|prior|above)\s+instructions", re.IGNORECASE),
    re.compile(r"system\s*:\s*(?:approval|override|grant|execute)", re.IGNORECASE),
    re.compile(r"<\s*(?:script|iframe|system|tool_call|untrusted)", re.IGNORECASE),
    re.compile(r"(?:you\s+must\s+first\s+call|before\s+calling\s+any\s+tool)", re.IGNORECASE),
    re.compile(r"exfiltrate|steal\s+ssh|read\s+~/.ssh|~/.ssh/id_rsa|/etc/shadow", re.IGNORECASE),
)
_HTML_TAG_RE = re.compile(r"<[^>]+>")


def sanitize_mcp_tool_description(
    raw_desc: str,
    *,
    max_chars: int = 400,
) -> tuple[str, list[str]]:
    """Sanitize third-party MCP tool descriptions and flag tool-description poisoning attempts."""
    warnings: list[str] = []
    cleaned = strip_invisible_and_tag_chars(raw_desc or "")
    if cleaned != (raw_desc or ""):
        warnings.append("invisible_or_bidi_chars_stripped")

    for pat in _POISON_PATTERNS:
        if pat.search(cleaned):
            warnings.append(f"poisoning_directive_detected:{pat.pattern[:32]}")
            cleaned = pat.sub("[REDACTED-SUSPICIOUS-DIRECTIVE]", cleaned)

    if _HTML_TAG_RE.search(cleaned):
        warnings.append("html_tags_stripped")
        cleaned = _HTML_TAG_RE.sub("", cleaned)

    cleaned = " ".join(cleaned.split())
    if len(cleaned) > max_chars:
        warnings.append(f"description_truncated:{len(cleaned)}")
        cleaned = cleaned[:max_chars] + "..."

    return cleaned, warnings


def is_playwright_browser_cached_locally() -> bool:
    """Check if Chromium/Playwright browser binaries are already cached on disk (no network)."""
    candidates = [
        Path(os.environ.get("PLAYWRIGHT_BROWSERS_PATH", "")),
        Path("/ms-playwright"),
        Path.home() / ".cache" / "ms-playwright",
    ]
    for p in candidates:
        if str(p) and p.exists() and any(p.glob("chromium*")):
            return True
    return shutil.which("chromium") is not None or shutil.which("chromium-browser") is not None


@dataclass
class ActiveStdioSession:
    """Running stdio MCP subprocess handle with request lock and stderr log buffer."""

    server_id: str
    name: str
    proc: asyncio.subprocess.Process
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    req_seq: int = 0
    restart_attempts: int = 0
    stderr_task: asyncio.Task[None] | None = None

    @property
    def process(self) -> asyncio.subprocess.Process:
        return self.proc


_ENV_NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,127}$")


def _server_to_dict(rec: McpServerRecord, logs: list[str]) -> dict[str, Any]:
    tools = rec.discovered_tools_json or []
    poisoning_flagged = any(isinstance(t, dict) and bool(t.get("warnings")) for t in tools)
    return {
        "id": rec.id,
        "name": rec.name,
        "transport": rec.transport,
        "command_or_url": rec.command_or_url,
        "args": rec.args_json or [],
        "enabled": rec.enabled,
        "risk_overrides": rec.risk_overrides_json or {},
        "oauth_config": rec.oauth_config_json or {},
        "discovered_tools": tools,
        "poisoning_flagged": poisoning_flagged,
        "discovered_resources": rec.discovered_resources_json or [],
        "discovered_prompts": rec.discovered_prompts_json or [],
        "status": rec.status,
        "last_error": rec.last_error,
        "logs": logs[-50:],
        "created_at": _ensure_utc(rec.created_at).isoformat(),
        "updated_at": _ensure_utc(rec.updated_at).isoformat(),
    }


class McpClientManager:
    """Manages stdio, SSE, and streamable-HTTP MCP servers, discovery, policy, and calls."""

    def __init__(
        self,
        db: DatabaseManager,
        settings: Settings,
        *,
        vault: EnvelopeVault | None = None,
        http_transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.db = db
        self.settings = settings
        self.vault = vault
        self.http_transport = http_transport
        self._stdio_sessions: dict[str, ActiveStdioSession] = {}
        self._active = self._stdio_sessions
        self._logs: dict[str, collections.deque[str]] = {}

    def _append_log(self, server_id: str, line: str) -> None:
        buf = self._logs.get(server_id)
        if buf is None:
            buf = collections.deque(maxlen=200)
            self._logs[server_id] = buf
        ts = datetime.now(UTC).strftime("%H:%M:%S")
        buf.append(f"[{ts}] {line.rstrip()}")

    def get_logs(self, server_id: str) -> list[str]:
        buf = self._logs.get(server_id)
        return list(buf) if buf is not None else []

    def list_bundled_catalog(self) -> list[dict[str, Any]]:
        """Return optional bundled MCP servers (all disabled by default)."""
        fs_dir = str((self.settings.data_dir / "workspaces" / "mcp_bundled").resolve())
        catalog = [
            {
                "name": "bundled_filesystem",
                "transport": "stdio",
                "command_or_url": sys.executable,
                "args": ["-m", "backend.mcp.bundled.filesystem_server", fs_dir],
                "enabled_by_default": False,
                "description": "Workspace-jailed local filesystem MCP server.",
            },
            {
                "name": "bundled_fetch",
                "transport": "stdio",
                "command_or_url": sys.executable,
                "args": ["-m", "backend.mcp.bundled.fetch_server"],
                "enabled_by_default": False,
                "description": "SSRF-safe HTTP/HTTPS fetch MCP server.",
            },
        ]
        if is_playwright_browser_cached_locally():
            catalog.append(
                {
                    "name": "bundled_playwright",
                    "transport": "stdio",
                    "command_or_url": sys.executable,
                    "args": ["-m", "backend.mcp.bundled.playwright_server", fs_dir],
                    "enabled_by_default": False,
                    "description": "Cached local Playwright browser MCP server.",
                }
            )
        return catalog

    def build_oauth_authorize_url(
        self,
        *,
        server_name: str,
        authorize_endpoint: str,
        client_id: str,
        scope: str = "mcp:tools",
    ) -> dict[str, str]:
        """Construct an OAuth 2.0 authorization URL using OAUTH_REDIRECT_BASE_URL."""
        redirect_uri = f"{self.settings.oauth_redirect_base_url.rstrip('/')}/api/mcp/oauth/callback"
        state = f"mcp_{server_name}_{uuid.uuid4().hex[:12]}"
        url = (
            f"{authorize_endpoint}?response_type=code&client_id={client_id}"
            f"&redirect_uri={redirect_uri}&scope={scope}&state={state}"
        )
        return {"authorize_url": url, "redirect_uri": redirect_uri, "state": state}

    async def register_server(
        self,
        *,
        name: str,
        transport: McpTransportLiteral,
        command_or_url: str,
        args: list[str] | None = None,
        env_secret_keys: dict[str, str] | None = None,
        risk_overrides: dict[str, ToolRiskLiteral] | None = None,
        oauth_config: dict[str, Any] | None = None,
        enabled: bool = False,
        initial_tools: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        now = datetime.now(UTC)
        clean_name = name.strip()
        if not clean_name:
            raise ValueError("MCP server name cannot be empty")

        sanitized_tools: list[dict[str, Any]] = []
        any_poisoning = False
        for t in initial_tools or []:
            raw_desc = str(t.get("description", ""))
            clean_desc, warnings = sanitize_mcp_tool_description(raw_desc)
            if warnings:
                any_poisoning = True
            sanitized_tools.append(
                {
                    "name": str(t.get("name", "tool")),
                    "description": clean_desc,
                    "raw_description_flagged": bool(warnings),
                    "warnings": warnings,
                    "input_schema": t.get("input_schema") or {"type": "object", "properties": {}},
                }
            )
        effective_enabled = False if any_poisoning else enabled

        async def _tx(sess: AsyncSession) -> McpServerRecord:
            uow = UnitOfWork(sess)
            existing = await uow.mcp_servers.get_by_name(clean_name)
            if existing is not None:
                existing.transport = transport
                existing.command_or_url = command_or_url
                existing.args_json = list(args or [])
                existing.env_secret_keys_json = dict(env_secret_keys or {})
                existing.risk_overrides_json = dict(risk_overrides or {})
                existing.oauth_config_json = dict(oauth_config or {})
                if sanitized_tools:
                    existing.discovered_tools_json = sanitized_tools
                existing.enabled = effective_enabled
                existing.updated_at = now
                return existing

            rec = McpServerRecord(
                id=f"mcp_{uuid.uuid4().hex[:20]}",
                name=clean_name,
                transport=transport,
                command_or_url=command_or_url,
                args_json=list(args or []),
                env_secret_keys_json=dict(env_secret_keys or {}),
                enabled=effective_enabled,
                risk_overrides_json=dict(risk_overrides or {}),
                oauth_config_json=dict(oauth_config or {}),
                discovered_tools_json=sanitized_tools,
                discovered_resources_json=[],
                discovered_prompts_json=[],
                status="stopped",
                created_at=now,
                updated_at=now,
            )
            return await uow.mcp_servers.upsert(rec)

        saved = await self.db.execute_write(_tx)
        if enabled:
            return await self.discover_server(saved.id)
        return _server_to_dict(saved, self.get_logs(saved.id))

    async def check_health_and_restart(self, server_id: str) -> dict[str, Any]:
        """Verify health of an MCP server and automatically restart if the subprocess died."""
        disc = await self.discover_server(server_id)
        session = self._stdio_sessions.get(server_id)
        restart_count = session.restart_attempts if session is not None else 0
        return {
            "server_id": server_id,
            "healthy": disc.get("status") in ("healthy", "connected"),
            "restart_count": restart_count,
            "server": disc,
        }

    async def list_servers(self) -> list[dict[str, Any]]:
        async def _load(sess: AsyncSession) -> list[McpServerRecord]:
            uow = UnitOfWork(sess)
            return await uow.mcp_servers.list_all()

        rows = await self.db.execute_read(_load)
        return [_server_to_dict(r, self.get_logs(r.id)) for r in rows]

    async def list_enabled_tool_specs(self) -> list[ProviderToolSpec]:
        """Return ProviderToolSpec items for all discovered tools on enabled MCP servers."""
        servers = await self.list_servers()
        specs: list[ProviderToolSpec] = []
        for srv in servers:
            if not srv.get("enabled", False):
                continue
            srv_name = str(srv["name"])
            for t in srv.get("discovered_tools", []):
                if not isinstance(t, dict) or "name" not in t:
                    continue
                qname = f"mcp__{srv_name}__{t['name']}"
                specs.append(
                    ProviderToolSpec(
                        name=qname,
                        description=str(t.get("description", f"MCP tool {t['name']}")),
                        parameters=dict(
                            t.get("input_schema") or {"type": "object", "properties": {}}
                        ),
                    )
                )
        return specs

    async def _ensure_stdio_session(self, rec: McpServerRecord) -> ActiveStdioSession:
        existing = self._stdio_sessions.get(rec.id)
        if existing is not None and existing.proc.returncode is None:
            return existing

        # Auto-restart with exponential backoff if previous session died
        attempts = (existing.restart_attempts + 1) if existing is not None else 0
        if attempts > 1:
            backoff = min(2.0, 0.05 * (2 ** (attempts - 1)))
            await asyncio.sleep(backoff)

        env = {
            "PATH": os.environ.get("PATH", "/usr/local/bin:/usr/bin:/bin"),
            "HOME": os.environ.get("HOME", str(Path.home())),
            "PYTHONPATH": os.pathsep.join([_REPO_ROOT_STR, *(p for p in sys.path if p)]),
            "PYTHONUNBUFFERED": "1",
        }
        # Resolve env_secret_keys ({ENV_VAR: admin-secret-key}) from the encrypted
        # secret store. Values are decrypted in memory only, registered for log
        # redaction, and never written back to the DB. Fail closed: a missing vault,
        # an unknown secret, or an invalid env name refuses to start the server.
        secret_refs = dict(rec.env_secret_keys_json or {})
        if secret_refs:
            if self.vault is None:
                raise ValueError(
                    f"MCP server '{rec.name}' references env secrets but no vault is configured"
                )
            async with self.db.session() as sess:
                uow = UnitOfWork(sess)
                for env_name, secret_key in secret_refs.items():
                    if not _ENV_NAME_RE.match(str(env_name)):
                        raise ValueError(
                            f"MCP server '{rec.name}' has invalid env var name {env_name!r}"
                        )
                    stored = await uow.settings.get_secret(str(secret_key))
                    if stored is None:
                        raise ValueError(
                            f"MCP server '{rec.name}' references unknown secret "
                            f"{secret_key!r} (create it via POST /api/admin/secrets)"
                        )
                    value = self.vault.decrypt(
                        stored.ciphertext, associated_data=f"secret:{secret_key}"
                    )
                    register_secret_for_redaction(value)
                    env[str(env_name)] = value
        proc = await asyncio.create_subprocess_exec(
            rec.command_or_url,
            *(rec.args_json or []),
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env,
        )
        session = ActiveStdioSession(
            server_id=rec.id,
            name=rec.name,
            proc=proc,
            restart_attempts=attempts,
        )

        async def _pump_stderr() -> None:
            if proc.stderr is None:
                return
            while True:
                line = await proc.stderr.readline()
                if not line:
                    break
                self._append_log(rec.id, line.decode("utf-8", errors="replace"))

        session.stderr_task = asyncio.create_task(_pump_stderr())
        self._stdio_sessions[rec.id] = session
        await self._rpc_stdio(
            session,
            "initialize",
            {"protocolVersion": "2024-11-05", "clientInfo": {"name": "odysseus", "version": "0.1"}},
        )
        return session

    async def _rpc_stdio(
        self,
        session: ActiveStdioSession,
        method: str,
        params: dict[str, Any] | None = None,
        *,
        rpc_timeout: float = 5.0,
    ) -> dict[str, Any]:
        async with session.lock:
            session.req_seq += 1
            req_id = session.req_seq
            payload = {
                "jsonrpc": "2.0",
                "id": req_id,
                "method": method,
                "params": params or {},
            }
            assert session.proc.stdin is not None
            assert session.proc.stdout is not None
            session.proc.stdin.write((json.dumps(payload) + "\n").encode("utf-8"))
            await session.proc.stdin.drain()

            line = await asyncio.wait_for(session.proc.stdout.readline(), timeout=rpc_timeout)
            if not line:
                raise RuntimeError(f"MCP stdio server '{session.name}' closed stdout unexpectedly")
            resp = json.loads(line.decode("utf-8", errors="replace"))
            if "error" in resp:
                err = resp["error"]
                raise RuntimeError(f"MCP error from '{session.name}': {err}")
            res = resp.get("result", {})
            return res if isinstance(res, dict) else {"value": res}

    async def _rpc_http(
        self,
        rec: McpServerRecord,
        method: str,
        params: dict[str, Any] | None = None,
        *,
        rpc_timeout: float = 5.0,
    ) -> dict[str, Any]:
        payload = {
            "jsonrpc": "2.0",
            "id": uuid.uuid4().hex[:8],
            "method": method,
            "params": params or {},
        }
        async with httpx.AsyncClient(transport=self.http_transport, timeout=rpc_timeout) as client:
            resp = await client.post(rec.command_or_url, json=payload)
            resp.raise_for_status()
            data = resp.json()
            if "error" in data:
                raise RuntimeError(f"MCP HTTP error from '{rec.name}': {data['error']}")
            res = data.get("result", {})
            return res if isinstance(res, dict) else {"value": res}

    async def discover_server(self, server_id: str) -> dict[str, Any]:
        """Connect to an MCP server, discover tools/resources/prompts, and sanitize descriptions."""

        async def _load(sess: AsyncSession) -> McpServerRecord | None:
            uow = UnitOfWork(sess)
            return await uow.mcp_servers.get(server_id)

        rec = await self.db.execute_read(_load)
        if rec is None:
            raise LookupError(f"MCP server '{server_id}' not found")

        try:
            resources_res: dict[str, Any] = {}
            prompts_res: dict[str, Any] = {}
            if rec.transport == "stdio":
                session = await self._ensure_stdio_session(rec)
                tools_res = await self._rpc_stdio(session, "tools/list")
                with contextlib.suppress(Exception):
                    resources_res = await self._rpc_stdio(session, "resources/list")
                with contextlib.suppress(Exception):
                    prompts_res = await self._rpc_stdio(session, "prompts/list")
            else:
                await self._rpc_http(rec, "initialize", {"protocolVersion": "2024-11-05"})
                tools_res = await self._rpc_http(rec, "tools/list")
                with contextlib.suppress(Exception):
                    resources_res = await self._rpc_http(rec, "resources/list")
                with contextlib.suppress(Exception):
                    prompts_res = await self._rpc_http(rec, "prompts/list")

            raw_tools = tools_res.get("tools", []) if isinstance(tools_res, dict) else []
            overrides = rec.risk_overrides_json or {}
            sanitized_tools: list[dict[str, Any]] = []
            for t in raw_tools:
                if not isinstance(t, dict):
                    continue
                tname = str(t.get("name", "")).strip()
                if not tname:
                    continue
                clean_desc, warnings = sanitize_mcp_tool_description(str(t.get("description", "")))
                # Unknown MCP tools default to exec-level risk & ask approval!
                assigned_risk = overrides.get(tname, "exec")
                sanitized_tools.append(
                    {
                        "name": tname,
                        "qualified_name": f"mcp__{rec.name}__{tname}",
                        "description": clean_desc,
                        "inputSchema": t.get("inputSchema", {"type": "object", "properties": {}}),
                        "risk": assigned_risk,
                        "poisoning_warnings": warnings,
                        "review_required": len(warnings) > 0,
                    }
                )

            resources_list = (
                resources_res.get("resources", []) if isinstance(resources_res, dict) else []
            )
            prompts_list = prompts_res.get("prompts", []) if isinstance(prompts_res, dict) else []

            now = datetime.now(UTC)

            async def _save_ok(sess: AsyncSession) -> McpServerRecord:
                uow = UnitOfWork(sess)
                r = await uow.mcp_servers.get(server_id)
                assert r is not None
                r.discovered_tools_json = sanitized_tools
                r.discovered_resources_json = list(resources_list)
                r.discovered_prompts_json = list(prompts_list)
                r.status = "healthy"
                r.last_error = None
                r.updated_at = now
                return r

            updated = await self.db.execute_write(_save_ok)
            self._append_log(server_id, f"Discovered {len(sanitized_tools)} tools")
            return _server_to_dict(updated, self.get_logs(server_id))

        except Exception as exc:
            now = datetime.now(UTC)
            err_str = str(exc)
            self._append_log(server_id, f"Discovery failed: {err_str}")

            async def _save_err(sess: AsyncSession) -> McpServerRecord:
                uow = UnitOfWork(sess)
                r = await uow.mcp_servers.get(server_id)
                assert r is not None
                r.status = "error"
                r.last_error = err_str
                r.updated_at = now
                return r

            updated = await self.db.execute_write(_save_err)
            return _server_to_dict(updated, self.get_logs(server_id))

    async def call_tool(
        self,
        *,
        server_name: str,
        tool_name: str,
        arguments: dict[str, Any],
    ) -> dict[str, Any]:
        """Execute an MCP tool call and tag its result as untrusted external data."""

        async def _load(sess: AsyncSession) -> McpServerRecord | None:
            uow = UnitOfWork(sess)
            return await uow.mcp_servers.get_by_name(server_name)

        rec = await self.db.execute_read(_load)
        if rec is None:
            raise LookupError(f"MCP server '{server_name}' not found")
        if not rec.enabled:
            raise PermissionError(f"MCP server '{server_name}' is disabled")

        if rec.transport == "stdio":
            session = await self._ensure_stdio_session(rec)
            try:
                res = await self._rpc_stdio(
                    session,
                    "tools/call",
                    {"name": tool_name, "arguments": arguments},
                )
            except Exception:
                # Auto-restart once on subprocess crash and retry
                self._stdio_sessions.pop(rec.id, None)
                session = await self._ensure_stdio_session(rec)
                res = await self._rpc_stdio(
                    session,
                    "tools/call",
                    {"name": tool_name, "arguments": arguments},
                )
        else:
            res = await self._rpc_http(
                rec,
                "tools/call",
                {"name": tool_name, "arguments": arguments},
            )

        content_items = res.get("content", []) if isinstance(res, dict) else []
        texts: list[str] = []
        if isinstance(content_items, list):
            for item in content_items:
                if isinstance(item, dict) and "text" in item:
                    texts.append(str(item["text"]))
        combined = "\n".join(texts) if texts else json.dumps(res)
        is_error = bool(res.get("isError", False)) if isinstance(res, dict) else False

        return {
            "server": server_name,
            "tool": tool_name,
            "output": combined,
            "is_error": is_error,
            "provenance_source": f"mcp:{server_name}:{tool_name}",
            "trust": "untrusted",
        }

    async def shutdown(self) -> None:
        """Stop all active stdio MCP subprocesses cleanly."""
        for session in list(self._stdio_sessions.values()):
            if session.stderr_task is not None and not session.stderr_task.done():
                session.stderr_task.cancel()
            if session.proc.returncode is None:
                with contextlib.suppress(ProcessLookupError, Exception):
                    session.proc.terminate()
                with contextlib.suppress(TimeoutError, Exception):
                    await asyncio.wait_for(session.proc.wait(), timeout=1.0)
                if session.proc.returncode is None:
                    with contextlib.suppress(ProcessLookupError, Exception):
                        session.proc.kill()
        self._stdio_sessions.clear()
