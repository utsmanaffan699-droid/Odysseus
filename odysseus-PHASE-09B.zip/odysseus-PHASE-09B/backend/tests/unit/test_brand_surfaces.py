from __future__ import annotations

from backend.core.brand import brand_value, render_branded_error_html, render_branded_export_html
from backend.domain.brand.email import render_transactional_email


def test_branded_email_pairs_are_offline_safe() -> None:
    rendered = render_transactional_email(
        "invite", recipient_name="A <B>", action_url="https://example.invalid/invite", detail="Welcome"
    )
    assert rendered.subject.startswith(f"{brand_value('productName', 'PRODUCT_NAME')}:")
    assert "<script" not in rendered.html.lower()
    assert "<img" not in rendered.html.lower()
    assert "A &lt;B&gt;" in rendered.html
    assert "A <B>" in rendered.text


def test_branded_export_and_browser_error_have_inline_styles() -> None:
    export = render_branded_export_html("A report", "<article><h2>Run</h2></article>")
    error = render_branded_error_html(404, "Not found")
    assert "<style>" in export and brand_value("productName", "PRODUCT_NAME") in export
    assert "404" in error and "Not found" in error
    assert "https://" not in export
