from backend.domain.tools.policy import ToolDefinition, ToolPolicyEngine


def test_lockdown_is_enforced_by_policy_engine() -> None:
    engine = ToolPolicyEngine()
    for risk in ("exec", "network", "admin"):
        decision = engine.evaluate(
            ToolDefinition(name=f"demo_{risk}", risk=risk, required_privilege="agent"),
            {},
            user_privileges=frozenset({"agent", "admin"}),
            lockdown=True,
        )
        assert decision.decision == "deny"
        assert "Lockdown mode" in decision.reason


def test_lockdown_keeps_local_read_tools_available() -> None:
    decision = ToolPolicyEngine().evaluate(
        ToolDefinition(name="read_file", risk="read", required_privilege="agent"),
        {"path": "README.md"},
        user_privileges=frozenset({"agent"}),
        lockdown=True,
    )
    assert decision.decision in {"auto", "ask"}
