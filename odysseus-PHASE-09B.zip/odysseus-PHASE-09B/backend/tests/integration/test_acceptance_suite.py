"""Executable Acceptance Tests (Phase 01 §3: #1, #2, #3, #4, #6)."""

from __future__ import annotations

import asyncio
import multiprocessing
import os
import signal
import time
from datetime import UTC, datetime, timedelta
from pathlib import Path

import httpx
import pyotp
from backend.app.main import create_app
from backend.core.db import DatabaseManager
from backend.core.jobs import JobSupervisor
from backend.core.models import JobRecord, RunRecord, SessionRecord
from backend.core.settings import Settings
from backend.core.uow import UnitOfWork
from sqlalchemy import select


def _make_test_settings(tmp_path: Path, **overrides: object) -> Settings:
    data_dir = tmp_path / "data"
    logs_dir = tmp_path / "logs"
    base: dict[str, object] = {
        "environment": "test",
        "data_dir": data_dir,
        "logs_dir": logs_dir,
        "database_url": f"sqlite+aiosqlite:///{data_dir / 'acceptance.db'}",
        "trusted_proxies": ["127.0.0.1"],
        "login_max_attempts_per_ip": 10,
        "login_max_attempts_per_user": 5,
        "session_idle_timeout_seconds": 60,
        "session_absolute_timeout_seconds": 3600,
    }
    base.update(overrides)
    return Settings(**base)  # type: ignore[arg-type]


async def test_acceptance_1_health_ready_and_prometheus_metrics(tmp_path: Path) -> None:
    """Acceptance #1: /api/health/ready returns 200; /metrics exposes all mandated series."""
    settings = _make_test_settings(tmp_path)
    app = create_app(settings, start_job_workers=False)

    async with app.router.lifespan_context(app):
        transport = httpx.ASGITransport(app=app)
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client:
            r_live = await client.get("/api/health/live")
            assert r_live.status_code == 200

            r_ready = await client.get("/api/health/ready")
            assert r_ready.status_code == 200
            assert r_ready.json()["status"] == "ready"

            r_deg = await client.get("/api/health/degraded")
            assert r_deg.status_code == 200
            assert r_deg.json()["degraded"] is False

            r_metrics = await client.get("/metrics")
            assert r_metrics.status_code == 200
            text = r_metrics.text
            for required_series in (
                "http_requests",
                "http_latency",
                "db_pool",
                "sse_clients",
                "runs_active",
                "events_appended",
                "provider_latency",
                "provider_errors",
            ):
                assert required_series in text, (
                    f"Missing Prometheus metric series: {required_series}"
                )


async def test_acceptance_2_bruteforce_20_bad_logins_throttled_per_ip(tmp_path: Path) -> None:
    """Acceptance #2: 20 bad logins from one IP -> 429 + Retry-After; other IP unaffected."""
    settings = _make_test_settings(tmp_path)
    app = create_app(settings, start_job_workers=False)

    async with app.router.lifespan_context(app):
        boot = app.state.bootstrap_admin_result
        assert boot is not None and boot.created and boot.temporary_password
        admin_password = boot.temporary_password

        transport = httpx.ASGITransport(app=app, client=("127.0.0.1", 50000))
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client:
            statuses: list[int] = []
            retry_after_headers: list[str] = []

            for i in range(20):
                resp = await client.post(
                    "/api/auth/login",
                    json={"username": "admin", "password": f"wrong_password_{i}"},
                    headers={"X-Forwarded-For": "203.0.113.50"},
                )
                statuses.append(resp.status_code)
                if resp.status_code == 429:
                    retry_after_headers.append(resp.headers.get("Retry-After", ""))

            assert 429 in statuses
            assert statuses[-1] == 429
            assert any(h.isdigit() and int(h) >= 1 for h in retry_after_headers)

            # Legitimate user logging in from another IP (198.51.100.77) must succeed unaffected
            legit_resp = await client.post(
                "/api/auth/login",
                json={"username": "admin", "password": admin_password},
                headers={"X-Forwarded-For": "198.51.100.77"},
            )
            assert legit_resp.status_code == 200
            assert legit_resp.json()["authenticated"] is True


async def test_acceptance_3_session_fixation_revocation_idle_expiry_and_2fa(tmp_path: Path) -> None:
    """Acceptance #3: Session rotation on login, revocation, idle expiry, and 2FA verify."""
    settings = _make_test_settings(tmp_path, session_idle_timeout_seconds=30)
    app = create_app(settings, start_job_workers=False)

    async with app.router.lifespan_context(app):
        admin_pw = app.state.bootstrap_admin_result.temporary_password
        transport = httpx.ASGITransport(app=app)
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client:
            # 1. Pre-login session fixation attempt
            fixed_session_id = "attacker_pre_login_session_token_123456"
            client.cookies.set(settings.session_cookie_name, fixed_session_id, domain="localhost")

            r_login = await client.post(
                "/api/auth/login",
                json={"username": "admin", "password": admin_pw},
            )
            assert r_login.status_code == 200
            issued_cookie = r_login.cookies.get(settings.session_cookie_name)
            assert issued_cookie is not None
            assert issued_cookie != fixed_session_id
            csrf = r_login.json()["csrf_token"]

            # Using the attacker's pre-login token must fail with 401
            async with httpx.AsyncClient(
                transport=transport, base_url="http://localhost"
            ) as attacker_client:
                attacker_client.cookies.set(settings.session_cookie_name, fixed_session_id)
                r_fixed = await attacker_client.get("/api/auth/me")
                assert r_fixed.status_code == 401

            # 2. Complete forced password change
            r_pw = await client.post(
                "/api/auth/password/change",
                json={
                    "current_password": admin_pw,
                    "new_password": "NewSecureAdminPassword!2026",
                },
                headers={"X-CSRF-Token": csrf},
            )
            assert r_pw.status_code == 200

            # 3. Enroll and verify TOTP 2FA + test recovery code
            r_enroll = await client.post(
                "/api/auth/2fa/enroll",
                headers={"X-CSRF-Token": csrf},
            )
            assert r_enroll.status_code == 200
            enroll_data = r_enroll.json()
            totp_secret = enroll_data["secret"]
            assert enroll_data["qr_code_data_uri"].startswith("data:image/png;base64,")
            assert len(enroll_data["recovery_codes"]) == 8

            valid_code = pyotp.TOTP(totp_secret).now()
            r_verify = await client.post(
                "/api/auth/2fa/verify",
                json={"code": valid_code},
                headers={"X-CSRF-Token": csrf},
            )
            assert r_verify.status_code == 200
            assert r_verify.json()["totp_enabled"] is True

            # 4. Simulate idle session expiration by rewinding `last_active_at` in DB
            db: DatabaseManager = app.state.db
            async with db.session() as sess:
                rec = (await sess.execute(select(SessionRecord))).scalars().first()
                assert rec is not None
                rec.last_active_at = datetime.now(UTC) - timedelta(seconds=120)
                await sess.commit()

            r_idle_expired = await client.get("/api/auth/me")
            assert r_idle_expired.status_code == 401
            assert "session_expired_idle" in r_idle_expired.json()["detail"]

            # 5. Re-login (now requires 2FA!) and test immediate session revocation
            r_login2 = await client.post(
                "/api/auth/login",
                json={"username": "admin", "password": "NewSecureAdminPassword!2026"},
            )
            assert r_login2.status_code == 200
            assert r_login2.json()["mfa_required"] is True
            csrf2 = r_login2.json()["csrf_token"]

            # Before 2FA verify, accessing /api/chats must return 403
            r_blocked = await client.get("/api/chats")
            assert r_blocked.status_code == 403

            # Verify 2FA using one of the recovery codes
            r_rec_verify = await client.post(
                "/api/auth/2fa/verify",
                json={"code": enroll_data["recovery_codes"][0]},
                headers={"X-CSRF-Token": csrf2},
            )
            assert r_rec_verify.status_code == 200
            assert r_rec_verify.json()["used_recovery_code"] is True

            # Now /api/chats succeeds
            assert (await client.get("/api/chats")).status_code == 200

            # Revoke session via logout -> subsequent use of same cookie fails immediately
            saved_cookie = r_login2.cookies.get(settings.session_cookie_name)
            assert saved_cookie is not None
            r_logout = await client.post(
                "/api/auth/logout",
                headers={"X-CSRF-Token": csrf2},
            )
            assert r_logout.status_code == 200

            client.cookies.clear()
            client.cookies.set(settings.session_cookie_name, saved_cookie, domain="localhost")
            r_revoked = await client.get("/api/auth/me")
            assert r_revoked.status_code == 401


async def test_acceptance_4_csrf_cookie_enforced_and_bearer_exempt(tmp_path: Path) -> None:
    """Acceptance #4: Cookie POST without CSRF -> 403; with CSRF -> 200; bearer exempt."""
    settings = _make_test_settings(tmp_path)
    app = create_app(settings, start_job_workers=False)

    async with app.router.lifespan_context(app):
        admin_pw = app.state.bootstrap_admin_result.temporary_password
        transport = httpx.ASGITransport(app=app)
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as client:
            r_login = await client.post(
                "/api/auth/login",
                json={"username": "admin", "password": admin_pw},
            )
            csrf = r_login.json()["csrf_token"]
            await client.post(
                "/api/auth/password/change",
                json={"current_password": admin_pw, "new_password": "StrongAdminPassword!2026"},
                headers={"X-CSRF-Token": csrf},
            )

            # 1. Cookie-authenticated POST without X-CSRF-Token -> 403 Forbidden
            r_no_csrf = await client.post("/api/chats", json={"title": "Blocked Chat"})
            assert r_no_csrf.status_code == 403
            assert "CSRF" in r_no_csrf.json()["detail"]

            # 2. Cookie-authenticated POST with valid X-CSRF-Token -> 200 OK
            r_with_csrf = await client.post(
                "/api/chats",
                json={"title": "Allowed Chat"},
                headers={"X-CSRF-Token": csrf},
            )
            assert r_with_csrf.status_code == 200
            assert r_with_csrf.json()["title"] == "Allowed Chat"

            # 3. Mint an API token and send Bearer-authenticated POST without CSRF token -> 200 OK
            r_tok = await client.post(
                "/api/auth/tokens",
                json={"name": "cli-token", "scopes": ["chat"]},
                headers={"X-CSRF-Token": csrf},
            )
            assert r_tok.status_code == 200
            bearer_token = r_tok.json()["token"]

        async with httpx.AsyncClient(
            transport=transport, base_url="http://localhost"
        ) as api_client:
            r_bearer = await api_client.post(
                "/api/chats",
                json={"title": "Bearer Chat"},
                headers={"Authorization": f"Bearer {bearer_token}"},
            )
            assert r_bearer.status_code == 200
            assert r_bearer.json()["title"] == "Bearer Chat"


def _doomed_worker_process(db_url: str, data_dir_str: str, job_id: str, ready_file: str) -> None:
    """Child process that acquires a job lease, signals readiness, and waits for SIGKILL."""

    async def _run() -> None:
        settings = Settings(
            database_url=db_url,
            data_dir=Path(data_dir_str),
            job_lease_seconds=2,
            job_heartbeat_seconds=1,
        )
        db = DatabaseManager(settings)
        sup = JobSupervisor(db, settings)
        leased = await sup.acquire_next_lease("doomed_worker_pid")
        assert leased is not None and leased.id == job_id
        await asyncio.to_thread(Path(ready_file).write_text, "leased", "utf-8")
        # Hold the lease without completing while parent sends SIGKILL
        await asyncio.sleep(60)

    asyncio.run(_run())


async def test_acceptance_6_kill_minus_9_recovers_job_once_and_marks_run_interrupted(
    tmp_path: Path,
) -> None:
    """Acceptance #6: Kill -9 the server during a job -> on restart the job is leased again
    exactly once (no double execution) and `interrupted` state is recorded for runs-in-flight.
    """
    data_dir = tmp_path / "data"
    db_path = data_dir / "crash.db"
    db_url = f"sqlite+aiosqlite:///{db_path}"
    marker_file = tmp_path / "job_completions.log"
    ready_file = tmp_path / "worker_leased.flag"

    settings = Settings(
        database_url=db_url,
        data_dir=data_dir,
        job_lease_seconds=2,
        job_heartbeat_seconds=1,
    )
    db = DatabaseManager(settings)
    await db.create_schema_if_needed()

    try:
        sup = JobSupervisor(db, settings)
        job = await sup.enqueue(
            "sleep_job",
            {"sleep_seconds": 0.05, "marker_file": str(marker_file)},
            max_attempts=3,
        )

        # Also create an in-flight RunRecord (`status="running"`) to verify interrupted state
        async def _seed_run(sess: object) -> None:
            from sqlalchemy.ext.asyncio import AsyncSession

            assert isinstance(sess, AsyncSession)
            uow = UnitOfWork(sess)
            from backend.core.auth import bootstrap_first_admin

            await bootstrap_first_admin(uow, settings)
            users = await uow.users.list_users()
            user = users[0]
            from backend.core.models import ChatRecord

            now = datetime.now(UTC)
            chat = ChatRecord(
                id="c_crash_1",
                user_id=user.id,
                title="Crash Test Chat",
                model="fake/default",
                created_at=now,
                updated_at=now,
            )
            await uow.chats.create_chat(chat)
            run = RunRecord(
                id="r_inflight_1",
                chat_id=chat.id,
                message_id="m_1",
                user_id=user.id,
                status="running",
                model="fake/default",
                budget_json={},
                usage_json={},
                started_at=now,
                created_at=now,
            )
            await uow.chats.create_run(run)
            await uow.chats.append_run_event(
                run_id=run.id,
                event_type="run.started",
                data={
                    "model": "fake/default",
                    "budget": {
                        "max_iters": 10,
                        "max_tokens": 1000,
                        "max_cost": 1.0,
                        "max_seconds": 60,
                    },
                },
            )

        await db.execute_write(_seed_run)

        # Spawn real child process that leases the job, then kill -9 (SIGKILL) it mid-flight!
        ctx = multiprocessing.get_context("spawn")
        proc = ctx.Process(
            target=_doomed_worker_process,
            args=(db_url, str(data_dir), job.id, str(ready_file)),
        )
        proc.start()
        assert proc.pid is not None

        deadline = time.monotonic() + 10.0
        while not ready_file.exists() and time.monotonic() < deadline:  # noqa: ASYNC110
            await asyncio.sleep(0.05)
        assert ready_file.exists(), "Child process did not acquire lease in time"

        # Send SIGKILL (kill -9) to the child process while it holds the job lease!
        os.kill(proc.pid, signal.SIGKILL)
        proc.join(timeout=5)
        assert proc.exitcode == -signal.SIGKILL

        # Now simulate server restart: recover_interrupted_work + 5 concurrent workers racing
        recovery_summary = await sup.recover_interrupted_work(reclaim_expired_only=False)
        assert recovery_summary["interrupted_runs"] == 1
        assert recovery_summary["reclaimed_jobs"] == 1

        # Race 5 concurrent workers to execute the recovered job — atomic lease ensures 1 wins!
        results = await asyncio.gather(*[sup.execute_one(f"restart_worker_{i}") for i in range(5)])
        non_none = [r for r in results if r is not None]
        assert len(non_none) == 1
        assert non_none[0].status == "completed"
        assert non_none[0].attempts == 2

        # Verify marker file shows the job completed EXACTLY ONCE
        lines = marker_file.read_text(encoding="utf-8").strip().splitlines()
        assert len(lines) == 1
        assert lines[0] == f"completed:{job.id}:attempt=2"

        # Verify in-flight run is marked `interrupted` and has the `run.status` event persisted
        async with db.session() as sess:
            uow = UnitOfWork(sess)
            run_after = await uow.chats.get_run("r_inflight_1")
            assert run_after is not None
            assert run_after.status == "interrupted"
            events = await uow.chats.list_run_events("r_inflight_1")
            assert events[-1].type == "run.status"
            assert events[-1].data_json == {"status": "interrupted"}

            job_after = (
                await sess.execute(select(JobRecord).where(JobRecord.id == job.id))
            ).scalar_one()
            assert job_after.status == "completed"
    finally:
        await db.dispose()


REPO_ROOT = Path(__file__).resolve().parents[3]


async def _run_cmd(*args: str, cwd: Path | None = None) -> tuple[int, str, str]:
    proc = await asyncio.create_subprocess_exec(
        *args,
        cwd=str(cwd) if cwd else None,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    out_b, err_b = await proc.communicate()
    return (
        proc.returncode or 0,
        out_b.decode("utf-8", errors="replace").strip(),
        err_b.decode("utf-8", errors="replace").strip(),
    )


async def test_acceptance_7_docker_container_hardening_and_image_size() -> None:
    """Acceptance #7: Container runs as uid 10001 with read-only rootfs, cap-drop ALL,
    no-new-privileges, image size < 450 MB, and passes /api/health/ready inside Docker.
    """
    dockerfile = await asyncio.to_thread((REPO_ROOT / "Dockerfile").read_text, "utf-8")
    compose = await asyncio.to_thread((REPO_ROOT / "docker-compose.yml").read_text, "utf-8")

    assert "USER 10001:10001" in dockerfile
    assert "/usr/bin/tini" in dockerfile
    assert "HEALTHCHECK" in dockerfile
    assert "read_only: true" in compose
    assert "no-new-privileges:true" in compose

    rc_info, _, _ = await _run_cmd("docker", "info")
    assert rc_info == 0, "Docker daemon must be reachable for Acceptance #7"

    rc_inspect, size_str, _ = await _run_cmd(
        "docker", "image", "inspect", "odysseus:phase02", "--format", "{{.Size}}"
    )
    if rc_inspect != 0:
        rc_build, _, err_build = await _run_cmd(
            "docker", "build", "-t", "odysseus:phase02", ".", cwd=REPO_ROOT
        )
        assert rc_build == 0, f"docker build failed: {err_build}"
        rc_inspect, size_str, _ = await _run_cmd(
            "docker", "image", "inspect", "odysseus:phase02", "--format", "{{.Size}}"
        )
        assert rc_inspect == 0

    image_size_bytes = int(size_str.strip())
    assert image_size_bytes < 450 * 1024 * 1024, (
        f"Image size {image_size_bytes} exceeds 450 MB budget"
    )

    container_name = f"odysseus-acc7-{os.getpid()}"
    await _run_cmd("docker", "rm", "-f", container_name)
    try:
        rc_run, _, err_run = await _run_cmd(
            "docker",
            "run",
            "-d",
            "--name",
            container_name,
            "--read-only",
            "--tmpfs",
            "/tmp:uid=10001,gid=10001,mode=1777",
            "--tmpfs",
            "/data:uid=10001,gid=10001,mode=0700",
            "--tmpfs",
            "/logs:uid=10001,gid=10001,mode=0700",
            "--cap-drop=ALL",
            "--security-opt=no-new-privileges",
            "odysseus:phase02",
        )
        assert rc_run == 0, f"docker run failed: {err_run}"

        rc_uid, uid_out, _ = await _run_cmd("docker", "exec", container_name, "id", "-u")
        assert rc_uid == 0 and uid_out.strip() == "10001"

        rc_ro, _, _ = await _run_cmd(
            "docker", "exec", container_name, "sh", "-c", "touch /app/ro_probe"
        )
        assert rc_ro != 0, "Root filesystem must be read-only inside hardened container"

        ready_ok = False
        for _ in range(30):
            # The runtime image intentionally ships no curl/wget (no ready-made
            # exfiltration client for the agent shell tool); probe with stdlib Python.
            rc_ready, ready_out, _ = await _run_cmd(
                "docker",
                "exec",
                container_name,
                "python3",
                "-c",
                (
                    "import urllib.request; "
                    "print(urllib.request.urlopen("
                    "'http://127.0.0.1:8000/api/health/ready', timeout=3).read().decode())"
                ),
            )
            if rc_ready == 0 and '"status":"ready"' in ready_out.replace(" ", ""):
                ready_ok = True
                break
            await asyncio.sleep(0.25)
        assert ready_ok, "Container /api/health/ready did not return ready within timeout"
    finally:
        await _run_cmd("docker", "rm", "-f", container_name)
