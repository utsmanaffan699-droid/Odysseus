"""Attachments pipeline: chunked/resumable upload, SHA-256 addressing, MIME sniffing, extraction."""

from __future__ import annotations

import hashlib
import io
import re
import socket
import uuid
import zipfile
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as DefusedET

from PIL import Image

# PIL refuses to decode above 2x this value; pin an explicit ceiling so a small upload
# cannot expand into a multi-hundred-megabyte bitmap.
MAX_IMAGE_PIXELS = 40_000_000
Image.MAX_IMAGE_PIXELS = MAX_IMAGE_PIXELS
from pypdf import PdfReader
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.db import DatabaseManager
from backend.core.jobs import JobSupervisor
from backend.core.logging import get_logger
from backend.core.models import (
    AttachmentOwnerRecord,
    AttachmentRecord,
    JobRecord,
    UploadSessionRecord,
)
from backend.core.settings import Settings
from backend.core.uow import UnitOfWork

logger = get_logger("odysseus.attachments")


class AttachmentValidationError(ValueError):
    """Raised when an upload violates size, MIME, or integrity checks."""


def sniff_mime_type(data: bytes, filename: str = "") -> str:
    """Detect MIME type from magic bytes with safe filename fallback for text/office."""
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if data.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if data.startswith((b"GIF87a", b"GIF89a")):
        return "image/gif"
    if len(data) >= 12 and data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image/webp"
    if data.startswith(b"%PDF-"):
        return "application/pdf"
    if data.startswith(b"PK\x03\x04"):
        lower_fn = filename.lower()
        if lower_fn.endswith(".docx"):
            return "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        if lower_fn.endswith(".xlsx"):
            return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        if lower_fn.endswith(".pptx"):
            return "application/vnd.openxmlformats-officedocument.presentationml.presentation"
        return "application/zip"

    # Check if valid UTF-8 text
    try:
        sample = data[:4096]
        if b"\x00" not in sample:
            sample.decode("utf-8")
            lower_fn = filename.lower()
            if lower_fn.endswith((".md", ".markdown")):
                return "text/markdown"
            if lower_fn.endswith(".json"):
                return "application/json"
            if lower_fn.endswith(".csv"):
                return "text/csv"
            return "text/plain"
    except UnicodeDecodeError:
        return "application/octet-stream"
    return "application/octet-stream"


def _append_chunk_sync(temp_path: Path, chunk: bytes, offset: int | None, max_bytes: int) -> int:
    current_size = temp_path.stat().st_size if temp_path.exists() else 0
    if offset is not None and offset != current_size:
        raise AttachmentValidationError(
            f"Chunk offset mismatch: expected {current_size}, got {offset}"
        )
    if current_size + len(chunk) > max_bytes:
        raise AttachmentValidationError("Chunk exceeds maximum attachment size")
    with temp_path.open("ab") as f:
        f.write(chunk)
    return current_size + len(chunk)


def _consume_temp_file_sync(temp_path: Path) -> bytes:
    if not temp_path.exists():
        raise AttachmentValidationError("Temporary upload file missing")
    data = temp_path.read_bytes()
    temp_path.unlink(missing_ok=True)
    return data


def _read_file_if_exists_sync(path: Path) -> bytes | None:
    if not path.exists():
        return None
    return path.read_bytes()


def _write_if_missing_sync(path: Path, data: bytes) -> None:
    if not path.exists():
        path.write_bytes(data)


def _create_empty_file_sync(path: Path) -> None:
    path.write_bytes(b"")


def scan_bytes_clamav(
    data: bytes,
    *,
    enabled: bool = False,
    host: str = "127.0.0.1",
    port: int = 3310,
    timeout_seconds: float = 10.0,
) -> tuple[bool, str]:
    """Scan upload bytes with ClamAV (clamd INSTREAM) plus an always-on EICAR check.

    Fail-closed policy: when ClamAV is enabled but unreachable or over the size limit, the
    upload is rejected instead of being waved through ("scan skipped" used to be the
    default, which made the scanner purely decorative).
    """
    if b"X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*" in data:
        return False, "Eicar-Test-Signature"
    if not enabled:
        return True, "skipped"
    try:
        with socket.create_connection((host, port), timeout=timeout_seconds) as sock:
            sock.sendall(b"zINSTREAM\x00")
            view = memoryview(data)
            chunk_size = 1 << 16
            for offset in range(0, len(view), chunk_size):
                chunk = view[offset : offset + chunk_size]
                sock.sendall(len(chunk).to_bytes(4, "big") + chunk)
            sock.sendall((0).to_bytes(4, "big"))
            response = sock.recv(4096).decode("utf-8", errors="replace").strip("\x00 \r\n")
    except OSError as exc:
        return False, f"clamav_unreachable:{exc}"
    if "FOUND" in response:
        return False, response.split(":", 1)[-1].strip() or "malware"
    if response.endswith("OK") or response.strip() == "OK":
        return True, "clean"
    return False, f"clamav_unexpected:{response[:120]}"


# --- Extraction limits (decompression / parser bombs) -------------------------------
MAX_PDF_PAGES = 300
MAX_IMAGE_PIXELS = 40_000_000  # ~40 MP; above this a thumbnail would be a DoS vector
MAX_ZIP_MEMBERS = 512
MAX_ZIP_MEMBER_BYTES = 8 * 1024 * 1024
MAX_ZIP_TOTAL_BYTES = 32 * 1024 * 1024
MAX_ZIP_COMPRESSION_RATIO = 200
MAX_EXTRACTED_TEXT_CHARS = 100_000


def _extract_ooxml_text(raw: bytes, meta: dict[str, Any]) -> str:
    """Extract OOXML text with zip-bomb guards (member count, sizes, compression ratio)."""
    texts: list[str] = []
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as zf:
            infos = zf.infolist()
            if len(infos) > MAX_ZIP_MEMBERS:
                meta["extraction_warning"] = (
                    f"OOXML archive has {len(infos)} members; only the first "
                    f"{MAX_ZIP_MEMBERS} were inspected"
                )
                infos = infos[:MAX_ZIP_MEMBERS]
            total_uncompressed = 0
            for info in infos:
                name = info.filename
                if not name.endswith(".xml") or not (
                    "document" in name or "sheet" in name or "slide" in name
                ):
                    continue
                if info.file_size > MAX_ZIP_MEMBER_BYTES:
                    meta["extraction_warning"] = f"Skipped oversized member {name}"
                    continue
                ratio = info.file_size / max(1, info.compress_size)
                if ratio > MAX_ZIP_COMPRESSION_RATIO:
                    meta["extraction_warning"] = (
                        f"Skipped member {name}: compression ratio {ratio:.0f}x exceeds "
                        f"{MAX_ZIP_COMPRESSION_RATIO}x (decompression-bomb guard)"
                    )
                    continue
                if total_uncompressed + info.file_size > MAX_ZIP_TOTAL_BYTES:
                    meta["extraction_warning"] = "OOXML decompression budget exhausted"
                    break
                total_uncompressed += info.file_size
                xml_bytes = zf.read(name)
                root = DefusedET.fromstring(xml_bytes)  # noqa: S314 (defusedxml/ElementTree)
                chunk = " ".join(t.strip() for t in root.itertext() if t.strip())
                if chunk:
                    texts.append(chunk)
    except Exception as exc:
        meta["extraction_warning"] = str(exc)
    return "\n\n".join(texts)[:MAX_EXTRACTED_TEXT_CHARS]


def extract_attachment_content(
    file_path: Path,
    mime_type: str,
    thumb_dir: Path,
    sha256: str,
) -> tuple[str | None, str | None, dict[str, Any]]:
    """Extract searchable text and/or generate image thumbnail.

    Every branch is bounded: uploads are attacker-controlled, so a malformed PDF/DOCX/image
    must fail fast instead of hanging the worker or exhausting memory (parse bombs).
    """
    raw = file_path.read_bytes()
    meta: dict[str, Any] = {"size_bytes": len(raw)}

    if mime_type == "application/pdf":
        reader = PdfReader(io.BytesIO(raw))
        page_count = len(reader.pages)
        meta["page_count"] = page_count
        pages_text: list[str] = []
        for idx, page in enumerate(reader.pages):
            if idx >= MAX_PDF_PAGES:
                meta["extraction_warning"] = (
                    f"PDF has {page_count} pages; text extracted from the first "
                    f"{MAX_PDF_PAGES} only"
                )
                break
            txt = page.extract_text() or ""
            if txt.strip():
                pages_text.append(f"[Page {idx + 1}]\n{txt.strip()}")
            if sum(len(t) for t in pages_text) > MAX_EXTRACTED_TEXT_CHARS:
                break
        return "\n\n".join(pages_text)[:MAX_EXTRACTED_TEXT_CHARS], None, meta

    if mime_type.startswith("image/"):
        with Image.open(io.BytesIO(raw)) as img:
            width, height = img.size
            if width * height > MAX_IMAGE_PIXELS:
                raise ValueError(
                    f"Image {width}x{height} ({width * height} px) exceeds the "
                    f"{MAX_IMAGE_PIXELS} px decoding limit"
                )
            meta["width"] = width
            meta["height"] = height
            meta["format"] = img.format
            thumb = img.copy()
            thumb.thumbnail((256, 256))
            thumb_dir.mkdir(parents=True, exist_ok=True)
            thumb_path = thumb_dir / f"{sha256}_thumb.png"
            thumb.save(thumb_path, format="PNG")
            return f"[Image {width}x{height} {mime_type}]", str(thumb_path), meta

    if mime_type in ("text/plain", "text/markdown", "application/json", "text/csv"):
        # Decode a bounded prefix instead of the whole payload.
        prefix = raw[: MAX_EXTRACTED_TEXT_CHARS * 4]
        decoded = prefix.decode("utf-8", errors="replace")
        return decoded[:MAX_EXTRACTED_TEXT_CHARS], None, meta

    if mime_type.startswith("application/vnd.openxmlformats-officedocument"):
        return _extract_ooxml_text(raw, meta), None, meta

    return None, None, meta


class AttachmentService:
    """Service managing chunked/resumable uploads, SHA-256 content store, and extraction jobs."""

    def __init__(
        self,
        db: DatabaseManager,
        settings: Settings,
        jobs: JobSupervisor | None = None,
        storage_root: Path | None = None,
    ) -> None:
        self.db = db
        self.settings = settings
        self.jobs = jobs
        self.storage_root = storage_root or Path("/home/user/.odysseus_storage/attachments")
        self.chunks_dir = self.storage_root / "chunks"
        self.blobs_dir = self.storage_root / "blobs"
        self.thumbs_dir = self.storage_root / "thumbs"
        self.chunks_dir.mkdir(parents=True, exist_ok=True)
        self.blobs_dir.mkdir(parents=True, exist_ok=True)
        self.thumbs_dir.mkdir(parents=True, exist_ok=True)

        if self.jobs is not None:
            self.jobs.register_handler("attachment.extract", self._handle_extraction_job)

    async def _handle_extraction_job(
        self, _job: JobRecord, payload: dict[str, Any]
    ) -> dict[str, Any] | None:
        sha256 = str(payload["sha256"])

        async def _load(sess: AsyncSession) -> tuple[str, str] | None:
            uow = UnitOfWork(sess)
            rec = await uow.attachments.get_by_sha256(sha256)
            if rec is None:
                return None
            return rec.storage_path, rec.mime_type

        loaded = await self.db.execute_read(_load)
        if loaded is None:
            return None
        storage_path_str, mime_type = loaded
        file_path = Path(storage_path_str)
        if _read_file_if_exists_sync(file_path) is None:
            return None

        try:
            extracted_text, thumb_path, meta = extract_attachment_content(
                file_path, mime_type, self.thumbs_dir, sha256
            )
            status = "ready"
        except Exception as exc:
            logger.warning("attachment_extraction_failed", sha256=sha256, error=str(exc))
            extracted_text = None
            thumb_path = None
            meta = {"error": str(exc)}
            status = "failed"

        async def _save(sess: AsyncSession) -> None:
            uow = UnitOfWork(sess)
            rec = await uow.attachments.get_by_sha256(sha256)
            if rec is not None:
                rec.extracted_text = extracted_text
                rec.thumbnail_path = thumb_path
                rec.metadata_json = meta
                rec.extraction_status = status

        await self.db.execute_write(_save)
        return {"sha256": sha256, "status": status}

    async def start_upload_session(
        self,
        *,
        user_id: str,
        filename: str,
        total_bytes: int,
        expected_sha256: str | None = None,
    ) -> dict[str, Any]:
        if expected_sha256 is not None:
            expected_sha256 = expected_sha256.strip().lower()
            if not re.fullmatch(r"[0-9a-f]{64}", expected_sha256):
                raise AttachmentValidationError(
                    "expected_sha256 must be a 64-character lowercase hex SHA-256 digest"
                )
        max_bytes = self.settings.max_body_bytes_upload
        if total_bytes < 0 or total_bytes > max_bytes:
            raise AttachmentValidationError(
                f"Upload size {total_bytes} exceeds maximum allowed {max_bytes} bytes"
            )
        upload_id = f"upl_{uuid.uuid4().hex[:20]}"
        temp_path = self.chunks_dir / f"{upload_id}.part"
        _create_empty_file_sync(temp_path)
        now = datetime.now(UTC)

        async def _tx(sess: AsyncSession) -> dict[str, Any]:
            uow = UnitOfWork(sess)
            rec = UploadSessionRecord(
                id=upload_id,
                user_id=user_id,
                filename=filename,
                expected_size=total_bytes,
                received_bytes=0,
                temp_path=str(temp_path),
                expected_sha256=expected_sha256,
                completed_sha256=None,
                created_at=now,
                updated_at=now,
            )
            await uow.attachments.add_session(rec)
            return {
                "upload_id": rec.id,
                "filename": rec.filename,
                "total_bytes": rec.expected_size,
                "received_bytes": rec.received_bytes,
                "expected_sha256": rec.expected_sha256,
                "status": "open",
            }

        return await self.db.execute_write(_tx)

    async def append_upload_chunk(
        self,
        *,
        upload_id: str,
        user_id: str,
        chunk: bytes,
        offset: int | None = None,
        finalize: bool = False,
    ) -> dict[str, Any]:
        async def _load(sess: AsyncSession) -> UploadSessionRecord | None:
            uow = UnitOfWork(sess)
            return await uow.attachments.get_session(upload_id)

        rec = await self.db.execute_read(_load)
        if rec is None or rec.user_id != user_id:
            raise AttachmentValidationError(f"Upload session '{upload_id}' not found")
        if rec.completed_sha256 is not None:
            raise AttachmentValidationError(f"Upload session '{upload_id}' is completed")

        temp_path = Path(rec.temp_path)
        new_size = _append_chunk_sync(temp_path, chunk, offset, self.settings.max_body_bytes_upload)

        async def _upd(sess: AsyncSession) -> None:
            uow = UnitOfWork(sess)
            s = await uow.attachments.get_session(upload_id)
            if s is not None:
                s.received_bytes = new_size
                s.updated_at = datetime.now(UTC)

        await self.db.execute_write(_upd)

        if finalize or (rec.expected_size > 0 and new_size >= rec.expected_size):
            return await self.finalize_upload_session(upload_id=upload_id, user_id=user_id)

        return {
            "upload_id": upload_id,
            "received_bytes": new_size,
            "total_bytes": rec.expected_size,
            "status": "open",
        }

    async def finalize_upload_session(
        self,
        *,
        upload_id: str,
        user_id: str,
    ) -> dict[str, Any]:
        async def _load(sess: AsyncSession) -> UploadSessionRecord | None:
            uow = UnitOfWork(sess)
            return await uow.attachments.get_session(upload_id)

        rec = await self.db.execute_read(_load)
        if rec is None or rec.user_id != user_id:
            raise AttachmentValidationError(f"Upload session '{upload_id}' not found")

        temp_path = Path(rec.temp_path)
        data = _consume_temp_file_sync(temp_path)
        actual_sha = hashlib.sha256(data).hexdigest()

        if rec.expected_sha256 is not None and actual_sha != rec.expected_sha256:
            raise AttachmentValidationError(
                "Upload integrity check failed: declared sha256 "
                f"{rec.expected_sha256} does not match received content {actual_sha}"
            )

        att = await self.store_bytes(user_id=user_id, filename=rec.filename, data=data)

        async def _mark_done(sess: AsyncSession) -> None:
            uow = UnitOfWork(sess)
            s = await uow.attachments.get_session(upload_id)
            if s is not None:
                s.completed_sha256 = actual_sha
                s.received_bytes = len(data)
                s.updated_at = datetime.now(UTC)

        await self.db.execute_write(_mark_done)
        return {**att, "upload_id": upload_id, "status": "completed"}

    async def store_bytes(
        self,
        *,
        user_id: str,
        filename: str,
        data: bytes,
    ) -> dict[str, Any]:
        """Store raw bytes by SHA-256 content address, sniff MIME, scan, and extract."""
        if len(data) > self.settings.max_body_bytes_upload:
            raise AttachmentValidationError(
                f"Attachment size {len(data)} exceeds limit {self.settings.max_body_bytes_upload}"
            )

        clean, scan_msg = scan_bytes_clamav(
            data,
            enabled=self.settings.clamav_enabled,
            host=self.settings.clamav_host,
            port=self.settings.clamav_port,
        )
        if not clean:
            raise AttachmentValidationError(f"Malware detected in upload: {scan_msg}")

        sha256 = hashlib.sha256(data).hexdigest()
        mime_type = sniff_mime_type(data, filename)
        blob_path = self.blobs_dir / sha256
        _write_if_missing_sync(blob_path, data)

        # Perform immediate synchronous extraction so extracted_text is available right away,
        # and also enqueue background job if JobSupervisor is registered.
        try:
            extracted_text, thumb_path, meta = extract_attachment_content(
                blob_path, mime_type, self.thumbs_dir, sha256
            )
            extraction_status = "ready"
        except Exception as exc:
            extracted_text = None
            thumb_path = None
            meta = {"error": str(exc)}
            extraction_status = "failed"

        now = datetime.now(UTC)

        async def _tx(sess: AsyncSession) -> dict[str, Any]:
            uow = UnitOfWork(sess)
            existing = await uow.attachments.get_by_sha256(sha256)
            if existing is not None:
                await uow.attachments.add_owner(
                    sha256=sha256, user_id=user_id, filename=filename, created_at=now
                )
                return {
                    "sha256": existing.sha256,
                    "filename": filename,
                    "mime_type": existing.mime_type,
                    "size_bytes": existing.size_bytes,
                    "extraction_status": existing.extraction_status,
                    "extracted_text": existing.extracted_text,
                    "metadata": existing.metadata_json,
                }
            record = AttachmentRecord(
                sha256=sha256,
                user_id=user_id,
                filename=filename,
                mime_type=mime_type,
                size_bytes=len(data),
                storage_path=str(blob_path),
                extraction_status=extraction_status,
                extracted_text=extracted_text,
                thumbnail_path=thumb_path,
                scan_status=scan_msg,
                metadata_json=meta,
                created_at=now,
            )
            await uow.attachments.add_attachment(record)
            await uow.attachments.add_owner(
                sha256=record.sha256, user_id=user_id, filename=filename, created_at=now
            )
            return {
                "sha256": record.sha256,
                "filename": record.filename,
                "mime_type": record.mime_type,
                "size_bytes": record.size_bytes,
                "extraction_status": record.extraction_status,
                "extracted_text": record.extracted_text,
                "metadata": record.metadata_json,
            }

        res = await self.db.execute_write(_tx)
        if self.jobs is not None:
            await self.jobs.enqueue("attachment.extract", {"sha256": sha256})
        return res

    async def get_attachment(
        self, sha256: str, *, user_id: str
    ) -> tuple[AttachmentRecord, bytes] | None:
        """Return (record, bytes) only when `user_id` has an ownership row for the blob."""

        async def _load(sess: AsyncSession) -> tuple[AttachmentOwnerRecord | None, AttachmentRecord | None]:
            uow = UnitOfWork(sess)
            owner = await uow.attachments.get_owner(sha256=sha256, user_id=user_id)
            rec = await uow.attachments.get_by_sha256(sha256)
            return owner, rec

        owner, rec = await self.db.execute_read(_load)
        if owner is None or rec is None:
            return None
        path = Path(rec.storage_path)
        raw = _read_file_if_exists_sync(path)
        if raw is None:
            return None
        return rec, raw
