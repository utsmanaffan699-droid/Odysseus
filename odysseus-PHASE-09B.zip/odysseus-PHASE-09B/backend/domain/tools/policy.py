"""Code-enforced tool execution policy engine, structured approval patterns, and taint rules."""

from __future__ import annotations

import fnmatch
import hashlib
import json
import posixpath
import shlex
from dataclasses import dataclass, field
from typing import Any, Literal
from urllib.parse import urlparse

from backend.domain.events import RenderHintLiteral, ToolRiskLiteral

ApprovalMode = Literal["auto", "ask", "deny"]
RunModeLiteral = Literal["interactive", "background"]

# Characters that give the shell control over what actually runs. `$` covers `$(...)`
# and `${...}`. Extended beyond the original set to include subshell/composition/escape
# and glob characters that change the effective argv after approval.
_SHELL_METACHARS = frozenset(
    {
        ";",
        "|",
        "&",
        "$",
        ">",
        "<",
        "`",
        "\n",
        "\r",
        "(",
        ")",
        "{",
        "}",
        "\\",
        "*",
        "?",
        "[",
        "]",
        "~",
        "!",
        "#",
        "'",
        '"',
        "=",
    }
)

# Binaries that can execute arbitrary code, mutate the workspace, or pivot into other
# interpreters. A 1-2 token argv prefix is NEVER auto-suggested for these: the user must
# approve the exact command hash instead.
_DANGEROUS_ARGV_HEADS = frozenset(
    {
        "python",
        "python3",
        "python3.12",
        "python3.13",
        "py",
        "sh",
        "bash",
        "dash",
        "zsh",
        "fish",
        "env",
        "xargs",
        "find",
        "git",
        "make",
        "cmake",
        "npm",
        "npx",
        "yarn",
        "pnpm",
        "node",
        "deno",
        "bun",
        "pytest",
        "tox",
        "nox",
        "uv",
        "pip",
        "pip3",
        "pipx",
        "poetry",
        "conda",
        "ruby",
        "perl",
        "php",
        "lua",
        "go",
        "cargo",
        "rustc",
        "javac",
        "java",
        "sed",
        "awk",
        "gawk",
        "tar",
        "cpio",
        "rsync",
        "scp",
        "ssh",
        "sftp",
        "curl",
        "wget",
        "nc",
        "ncat",
        "netcat",
        "socat",
        "telnet",
        "openssl",
        "gpg",
        "base64",
        "tee",
        "dd",
        "chmod",
        "chown",
        "ln",
        "rm",
        "mv",
        "cp",
        "touch",
        "truncate",
        "install",
        "systemctl",
        "service",
        "crontab",
        "at",
        "kill",
        "pkill",
        "killall",
        "mount",
        "umount",
        "docker",
        "podman",
        "kubectl",
        "helm",
        "eval",
        "exec",
        "source",
        "screen",
        "tmux",
        "nohup",
    }
)

# Subset used to REJECT user/API-supplied argv_prefix patterns: shells, interpreters and
# utilities that execute arbitrary code from extra arguments.
_CODE_EXEC_ARGV_HEADS = frozenset(
    {
        "sh",
        "bash",
        "dash",
        "zsh",
        "fish",
        "python",
        "python3",
        "python3.12",
        "python3.13",
        "py",
        "perl",
        "ruby",
        "php",
        "lua",
        "node",
        "deno",
        "bun",
        "env",
        "xargs",
        "find",
        "make",
        "git",
        "npm",
        "npx",
        "yarn",
        "pnpm",
        "sed",
        "awk",
        "gawk",
        "tar",
        "tee",
        "dd",
        "curl",
        "wget",
        "nc",
        "ncat",
        "netcat",
        "socat",
        "telnet",
        "ssh",
        "scp",
        "rsync",
        "docker",
        "podman",
        "kubectl",
        "helm",
        "eval",
        "exec",
        "source",
        "chmod",
        "chown",
        "ln",
        "rm",
        "mv",
        "truncate",
        "install",
        "systemctl",
        "service",
        "crontab",
        "at",
        "kill",
        "pkill",
        "killall",
        "mount",
        "umount",
        "nohup",
        "screen",
        "tmux",
        "base64",
        "gpg",
        "openssl",
        "pytest",
        "tox",
        "nox",
        "uv",
        "pip",
        "pip3",
        "pipx",
        "poetry",
        "conda",
        "go",
        "cargo",
        "rustc",
        "java",
        "javac",
    }
)

# Path segments that must never be auto-approved by a glob: they hold executable hooks or
# credentials that other tooling trusts (a "notes.txt" approval must not become ".git/hooks/*").
_SENSITIVE_PATH_SEGMENTS = frozenset(
    {".git", ".gitconfig", ".ssh", ".sandbox_tmp", ".env", ".bashrc", ".profile", ".zshrc"}
)


def _has_hidden_or_sensitive_segments(segments: list[str]) -> bool:
    return any(seg.startswith(".") or seg in _SENSITIVE_PATH_SEGMENTS for seg in segments)


def _path_pattern_matches(norm_path: str, glob_pat: str) -> bool:
    """Segment-aware `path_glob` matching.

    `*` never crosses a `/` boundary, so `path_glob:write_file:*` (the pattern suggested
    when approving a top-level file) can no longer match `.git/hooks/pre-commit`.
    A trailing `**` segment matches any remaining depth when explicitly requested.
    """
    path_segments = [s for s in norm_path.split("/") if s not in ("", ".")]
    pat_segments = [s for s in glob_pat.split("/") if s not in ("", ".")]
    if not pat_segments:
        return False

    recursive = pat_segments[-1] == "**"
    if recursive:
        pat_segments = pat_segments[:-1]
    if len(path_segments) < len(pat_segments):
        return False
    if not recursive and len(path_segments) != len(pat_segments):
        return False

    for path_seg, pat_seg in zip(path_segments, pat_segments):
        if pat_seg == "**":
            # `**` in the middle matches one-or-more segments
            return True
        if path_seg in _SENSITIVE_PATH_SEGMENTS and path_seg != pat_seg:
            # Hidden/sensitive segments require a literal match in the approved pattern
            return False
        if not fnmatch.fnmatchcase(path_seg, pat_seg):
            return False
    return True


@dataclass(frozen=True)
class ToolDefinition:
    """Declarative metadata for a built-in or MCP tool."""

    name: str
    risk: ToolRiskLiteral
    required_privilege: str
    default_approval: ApprovalMode = "ask"
    description: str = ""
    render_hint: RenderHintLiteral = "text"
    timeout_seconds: float = 15.0
    max_output_bytes: int = 65536
    idempotent: bool = False
    enabled: bool = True
    disabled_until_phase: str | None = None


@dataclass(frozen=True)
class PolicyDecision:
    """Result of evaluating a proposed tool call against the code-enforced policy engine."""

    decision: ApprovalMode
    reason: str
    tainted_by_untrusted_source: str | None = None
    suggested_pattern: str = ""


DEFAULT_RISK_POLICY: dict[ToolRiskLiteral, ApprovalMode] = {
    "read": "auto",
    "write": "ask",
    "exec": "ask",
    "network": "ask",
    "admin": "deny",
}


def has_shell_metacharacters(command: str) -> bool:
    """Return True if a command string contains shell chaining, redirection, or subshell chars."""
    return any(ch in _SHELL_METACHARS for ch in command) or "$(" in command


def _shell_exact_pattern(cmd: str) -> str:
    digest = hashlib.sha256(cmd.encode("utf-8", errors="replace")).hexdigest()[:16]
    return f"shell_exact:{digest}"


_OVERBROAD_PATTERNS = frozenset(
    {
        "*",
        "**",
        "tool:*",
        "shell:*",
        "run_shell:*",
        "python:*",
        "tool:shell",
        "tool:python",
        "tool:write_file",
        "tool:edit_file",
    }
)


def validate_approval_pattern(pattern: str, tool_name: str) -> tuple[bool, str]:
    """Reject approval patterns that are broader than the call they were approved for.

    Applied on the approval-resolution path and by the exec-policy CRUD API so a single
    click ("always allow") can never silently grant blanket shell/filesystem access.
    """
    clean = (pattern or "").strip()
    if not clean:
        return False, "Pattern cannot be empty."
    if clean.lower() in _OVERBROAD_PATTERNS or clean.endswith(":*") and clean.split(":")[0]=="tool":
        return (
            False,
            f"Pattern '{clean}' is rejected as overly broad; approve a specific command, "
            "path, or host instead.",
        )
    if len(clean) < 4:
        return False, "Pattern must be at least 4 characters long."

    if clean.startswith("argv_prefix:"):
        try:
            head_tokens = json.loads(clean[len("argv_prefix:") :])
        except Exception:
            return False, "argv_prefix pattern must be a JSON array of tokens."
        if not isinstance(head_tokens, list) or not head_tokens:
            return False, "argv_prefix pattern must be a non-empty JSON array of tokens."
        head = posixpath.basename(str(head_tokens[0])).lower()
        if head in _CODE_EXEC_ARGV_HEADS:
            return (
                False,
                f"Interpreter/executable '{head}' can run arbitrary code from extra "
                "arguments; approve an exact command (shell_exact) instead of a prefix.",
            )

    if clean.startswith("path_glob:"):
        rest = clean[len("path_glob:") :]
        _tool_part, _, glob_pat = rest.partition(":")
        if glob_pat in ("*", "**", "", "./**"):
            return (
                False,
                "A blanket path glob over the whole workspace is rejected; approve the "
                "specific file or a directory subtree instead.",
            )

    return True, "Valid structured pattern."


def suggest_structured_pattern(tool_name: str, args: dict[str, Any]) -> str:
    """Build a structured, non-regex approval pattern for a proposed tool call.

    The suggestion is deliberately narrow (least privilege): interpreters, package
    managers, VCS/network binaries and anything containing shell metacharacters get an
    exact-command hash instead of an argv prefix, and file tools get the exact path
    instead of a wildcard.
    """
    if tool_name == "shell":
        cmd = str(args.get("command", "")).strip()
        if not cmd or has_shell_metacharacters(cmd):
            return _shell_exact_pattern(cmd)
        try:
            tokens = shlex.split(cmd)
        except ValueError:
            return _shell_exact_pattern(cmd)
        if not tokens:
            return _shell_exact_pattern(cmd)
        head = posixpath.basename(tokens[0]).lower()
        # `./script.sh`, `/usr/bin/env`, interpreter invocations, and anything with
        # `VAR=value` assignments must be approved exactly, never by prefix.
        if (
            head in _DANGEROUS_ARGV_HEADS
            or tokens[0].startswith(("./", "../", "/"))
            or any("=" in tok for tok in tokens)
        ):
            return _shell_exact_pattern(cmd)
        # Safe read-only utilities: a 1-2 token prefix is acceptable (metachars already
        # rejected above, so no chaining/redirection/substitution can ride along).
        prefix = tokens[:2] if len(tokens) >= 2 else tokens[:1]
        return f"argv_prefix:{json.dumps(prefix, separators=(',', ':'))}"

    if tool_name == "python":
        code = str(args.get("code", "")).strip()
        digest = hashlib.sha256(code.encode("utf-8", errors="replace")).hexdigest()[:16]
        return f"python_exact:{digest}"

    if tool_name in ("read_file", "write_file", "edit_file", "list_dir", "glob", "grep"):
        raw_path = str(args.get("path", ".")).replace("\\", "/").strip()
        norm = posixpath.normpath(raw_path).lstrip("/")
        if not norm or norm == ".":
            return f"path_glob:{tool_name}:**"
        if _has_hidden_or_sensitive_segments(norm.split("/")):
            # Never auto-suggest a wildcard for dotfiles / VCS-internal paths
            return f"path_glob:{tool_name}:{norm}"
        return f"path_glob:{tool_name}:{norm}"

    if tool_name in ("fetch_url", "youtube_transcript"):
        raw_url = str(args.get("url") or args.get("video_url") or "")
        host = (urlparse(raw_url).hostname or "").lower()
        if host:
            return f"host_allowlist:{tool_name}:{host}"
        return f"host_allowlist:{tool_name}:*"

    if tool_name == "web_search":
        return "host_allowlist:web_search:*"

    return f"tool:{tool_name}"


def match_structured_pattern(pattern: str, tool_name: str, args: dict[str, Any]) -> bool:
    """Deterministically evaluate a structured pattern against a tool call (never regex)."""
    pat = pattern.strip()
    if not pat:
        return False

    # 1. Structured argv_prefix for shell (supports `argv_prefix:[...]` or raw `[...]`)
    if pat.startswith("argv_prefix:") or (pat.startswith("[") and tool_name == "shell"):
        if tool_name != "shell":
            return False
        cmd = str(args.get("command", "")).strip()
        if not cmd or has_shell_metacharacters(cmd):
            return False
        raw_json_list = pat[len("argv_prefix:") :] if pat.startswith("argv_prefix:") else pat
        try:
            allowed_prefix = json.loads(raw_json_list)
            if not isinstance(allowed_prefix, list) or not allowed_prefix:
                return False
            tokens = shlex.split(cmd)
        except Exception:
            return False
        if len(tokens) < len(allowed_prefix):
            return False
        return all(tokens[i] == str(allowed_prefix[i]) for i in range(len(allowed_prefix)))

    # 2. Exact hash match for shell or python
    if pat.startswith("shell_exact:"):
        if tool_name != "shell":
            return False
        cmd = str(args.get("command", "")).strip()
        digest = hashlib.sha256(cmd.encode("utf-8", errors="replace")).hexdigest()[:16]
        return pat == f"shell_exact:{digest}"

    if pat.startswith("python_exact:"):
        if tool_name != "python":
            return False
        code = str(args.get("code", "")).strip()
        digest = hashlib.sha256(code.encode("utf-8", errors="replace")).hexdigest()[:16]
        return pat == f"python_exact:{digest}"

    # 3. Structured path_glob:<tool>:<glob> (segment-aware; `*` never crosses `/`)
    if pat.startswith("path_glob:"):
        rest = pat[len("path_glob:") :]
        t_part, _, glob_pat = rest.partition(":")
        if t_part not in (tool_name, "*"):
            return False
        raw_path = str(args.get("path", ".")).replace("\\", "/").strip()
        if ".." in raw_path.split("/"):
            return False
        norm = posixpath.normpath(raw_path).lstrip("/")
        return _path_pattern_matches(norm, glob_pat)

    # 4. Structured host_allowlist:<tool>:<host>
    if pat.startswith("host_allowlist:"):
        rest = pat[len("host_allowlist:") :]
        t_part, _, allowed_host = rest.partition(":")
        if t_part not in (tool_name, "*"):
            return False
        if allowed_host == "*":
            return True
        raw_url = str(args.get("url") or args.get("video_url") or "")
        host = (urlparse(raw_url).hostname or "").lower()
        if not host:
            return False
        allowed_lower = allowed_host.lower()
        return host == allowed_lower or host.endswith(f".{allowed_lower}")

    if pat == f"tool:{tool_name}":
        return True

    # 5. Legacy <tool_name>:<fnmatch> pattern (still blocks shell metacharacters on allow!)
    target_arg = str(args.get("command") or args.get("path") or args.get("url") or "")
    signature = f"{tool_name}:{target_arg}"
    if tool_name == "shell" and has_shell_metacharacters(target_arg):
        # Allow deny_patterns to match metacharacters, handled by caller
        return fnmatch.fnmatchcase(signature, pat)
    return fnmatch.fnmatchcase(signature, pat)


@dataclass
class ToolPolicyEngine:
    """Enforces privilege, preset, allow/deny rules, and untrusted-content taint in code."""

    risk_modes: dict[ToolRiskLiteral, ApprovalMode] = field(
        default_factory=lambda: dict(DEFAULT_RISK_POLICY)
    )
    allow_patterns: list[str] = field(default_factory=list)
    deny_patterns: list[str] = field(default_factory=list)

    def evaluate(
        self,
        tool: ToolDefinition,
        args: dict[str, Any],
        *,
        user_privileges: frozenset[str],
        tainted_source: str | None = None,
        preset_allowed_tools: set[str] | None = None,
        run_mode: RunModeLiteral = "interactive",
        background_deny_on_ask: bool = False,
        lockdown: bool = False,
    ) -> PolicyDecision:
        """Pure function deciding whether a tool call is auto-approved, asked, or denied.

        Lockdown is enforced here rather than in the UI: callers cannot bypass it by
        posting a tool proposal directly to the API.
        """
        suggested = suggest_structured_pattern(tool.name, args)

        if lockdown and tool.risk in ("exec", "network", "admin"):
            return PolicyDecision(
                decision="deny",
                reason=f"Lockdown mode blocks {tool.risk}-risk tool '{tool.name}'",
                tainted_by_untrusted_source=tainted_source,
                suggested_pattern=suggested,
            )

        # 0. Disabled / future-phase stub check
        if not tool.enabled:
            phase_msg = (
                f" (scheduled for {tool.disabled_until_phase})" if tool.disabled_until_phase else ""
            )
            return PolicyDecision(
                decision="deny",
                reason=f"Tool '{tool.name}' is disabled{phase_msg}",
                tainted_by_untrusted_source=tainted_source,
                suggested_pattern=suggested,
            )

        # 1. Agent preset tool allowlist check
        if preset_allowed_tools is not None and tool.name not in preset_allowed_tools:
            return PolicyDecision(
                decision="deny",
                reason=f"Tool '{tool.name}' is not permitted by the active agent preset",
                tainted_by_untrusted_source=tainted_source,
                suggested_pattern=suggested,
            )

        # 2. Privilege check is absolute: non-admins never get admin tools; exec needs privilege
        is_admin = "admin" in user_privileges
        if tool.risk == "admin" and not is_admin:
            return PolicyDecision(
                decision="deny",
                reason="Admin-risk tools require 'admin' privilege",
                tainted_by_untrusted_source=tainted_source,
                suggested_pattern=suggested,
            )
        if tool.required_privilege not in user_privileges and not is_admin:
            return PolicyDecision(
                decision="deny",
                reason=f"Caller lacks required privilege '{tool.required_privilege}'",
                tainted_by_untrusted_source=tainted_source,
                suggested_pattern=suggested,
            )

        # 3. Explicit deny patterns always win (deny > ask > auto)
        for pat in self.deny_patterns:
            if match_structured_pattern(pat, tool.name, args):
                return PolicyDecision(
                    decision="deny",
                    reason=f"Matched deny pattern '{pat}'",
                    tainted_by_untrusted_source=tainted_source,
                    suggested_pattern=suggested,
                )

        # 4. Base risk / tool default check if explicitly set to deny
        risk_mode = self.risk_modes.get(tool.risk, tool.default_approval)
        if tool.default_approval == "deny" or risk_mode == "deny":
            return PolicyDecision(
                decision="deny",
                reason=f"Tool '{tool.name}' (risk={tool.risk}) is denied by policy",
                tainted_by_untrusted_source=tainted_source,
                suggested_pattern=suggested,
            )
        # Predictable precedence: an operator override applies ONLY to the risk classes
        # they actually changed. Previously a single edited risk class silently discarded
        # every tool's own `default_approval`, which made the effective policy impossible
        # to reason about.
        customized_risks = {
            risk
            for risk, mode in self.risk_modes.items()
            if DEFAULT_RISK_POLICY.get(risk) != mode
        }
        if tool.risk in customized_risks:
            base_mode: ApprovalMode = risk_mode
        else:
            base_mode = tool.default_approval

        # 5. Lethal Trifecta / Taint escalation:
        # If untrusted content is in context, ANY write/exec/network/admin call requires approval
        # even if previously allow-listed!
        if tainted_source is not None and tool.risk in ("write", "exec", "network", "admin"):
            if run_mode == "background" and background_deny_on_ask:
                return PolicyDecision(
                    decision="deny",
                    reason=(
                        f"Background run cannot wait for approval on tainted '{tool.name}' "
                        f"(tainted by {tainted_source})"
                    ),
                    tainted_by_untrusted_source=tainted_source,
                    suggested_pattern=suggested,
                )
            return PolicyDecision(
                decision="ask",
                reason=(
                    f"Requested after reading untrusted source {tainted_source}; "
                    "explicit approval required"
                ),
                tainted_by_untrusted_source=tainted_source,
                suggested_pattern=suggested,
            )

        # 6. Check structured allow patterns (only when not tainted and not admin-risk)
        if tool.risk != "admin":
            target_cmd = str(args.get("command", ""))
            for pat in self.allow_patterns:
                # Never allow a legacy fnmatch pattern to auto-approve shell metacharacter smuggling
                if (
                    tool.name == "shell"
                    and not pat.startswith("shell_exact:")
                    and has_shell_metacharacters(target_cmd)
                ):
                    continue
                if match_structured_pattern(pat, tool.name, args):
                    return PolicyDecision(
                        decision="auto",
                        reason=f"Matched allow pattern '{pat}'",
                        suggested_pattern=suggested,
                    )

        # 7. Fall back to risk-class or tool default
        if base_mode == "ask" and run_mode == "background" and background_deny_on_ask:
            return PolicyDecision(
                decision="deny",
                reason=f"Background run auto-denied '{tool.name}' requiring interactive approval",
                tainted_by_untrusted_source=tainted_source,
                suggested_pattern=suggested,
            )

        return PolicyDecision(
            decision=base_mode,
            reason=f"Default policy for risk='{tool.risk}' is '{base_mode}'",
            tainted_by_untrusted_source=tainted_source,
            suggested_pattern=suggested,
        )
