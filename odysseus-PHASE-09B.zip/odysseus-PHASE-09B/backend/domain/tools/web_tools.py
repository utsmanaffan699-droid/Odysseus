"""SSRF-safe web tools: fetch_url, web_search, source cache, favicon proxy, youtube_transcript."""

from __future__ import annotations

import asyncio
import hashlib
import ipaddress
import re
import socket
import time
import unicodedata
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any
from urllib.parse import parse_qs, urlparse, urlunparse

import httpx
from bs4 import BeautifulSoup, Comment

_BLOCKED_HOSTNAMES = frozenset(
    {
        "localhost",
        "localhost.localdomain",
        "ip6-localhost",
        "ip6-loopback",
        "metadata",
        "metadata.google.internal",
        "metadata.azure.internal",
        "instance-data",
        "chromadb",
        "ollama",
        "postgres",
        "redis",
        "searxng",
        "ntfy",
        "docker.internal",
        "host.docker.internal",
        "kubernetes.default",
        "kubernetes.default.svc",
    }
)

_BLOCKED_INTERNAL_PORTS = frozenset(
    {22, 25, 445, 2375, 2376, 3306, 5432, 6379, 8100, 9200, 11211, 11434, 27017}
)
_HIDDEN_STYLE_RE = re.compile(
    r"(display\s*:\s*none|visibility\s*:\s*hidden|opacity\s*:\s*0(?:\.0+)?|font-size\s*:\s*0"
    r"|color\s*:\s*transparent|left\s*:\s*-\d{3,}px|text-indent\s*:\s*-\d{3,}px)",
    re.IGNORECASE,
)
_WEB_POISON_RE = re.compile(
    r"(ignore\s+(?:all\s+)?(?:previous|prior|above)\s+instructions"
    r"|system\s*:\s*(?:override|you\s+are\s+now|grant\s+approval|execute)"
    r"|<\s*(?:system|tool_call|approval_override)\b"
    r"|exfiltrate\s+(?:secrets|keys|tokens))",
    re.IGNORECASE,
)


class SsrfBlockedError(PermissionError):
    """Raised when a URL targets a loopback, private, link-local, or internal service address."""


_CGNAT_NET = ipaddress.ip_network("100.64.0.0/10")
_BENCHMARK_NET = ipaddress.ip_network("198.18.0.0/15")
_NAT64_NET = ipaddress.ip_network("64:ff9b::/96")


def _check_ip_address(ip_str: str) -> None:
    addr = ipaddress.ip_address(ip_str)
    if isinstance(addr, ipaddress.IPv6Address):
        if addr.ipv4_mapped is not None:
            _check_ip_address(str(addr.ipv4_mapped))
            return
        if addr.sixtofour is not None:
            _check_ip_address(str(addr.sixtofour))
            return
        if addr.teredo is not None:
            _check_ip_address(str(addr.teredo[0]))
            _check_ip_address(str(addr.teredo[1]))
            return
        if addr in _NAT64_NET:
            last32 = int(addr) & 0xFFFFFFFF
            _check_ip_address(str(ipaddress.IPv4Address(last32)))
            return
    if (
        addr.is_loopback
        or addr.is_private
        or addr.is_link_local
        or addr.is_multicast
        or addr.is_reserved
        or addr.is_unspecified
        or (
            isinstance(addr, ipaddress.IPv4Address)
            and (addr in _CGNAT_NET or addr in _BENCHMARK_NET)
        )
    ):
        raise SsrfBlockedError(f"Blocked non-public IP address: {ip_str}")


def _is_ip_literal(host: str) -> bool:
    """Return True when `host` is already an IPv4/IPv6 literal (skip DNS resolution)."""
    try:
        ipaddress.ip_address(host)
        return True
    except ValueError:
        return False


def _looks_like_obfuscated_ip(host: str) -> bool:
    """Detect decimal, hex, octal, or short-form IPv4 literals (e.g. 127.1, 0177.0.0.1)."""
    parts = host.split(".")
    if all(re.fullmatch(r"(0x[0-9a-f]+|[0-9]+)", p) for p in parts):
        return True
    return False


def validate_ssrf_safe_url(
    raw_url: str,
    *,
    resolve_dns: bool = True,
    dns_resolver: Callable[[str, int], list[str]] | None = None,
) -> str:
    """Validate that `raw_url` is an external HTTP(S) URL not targeting private/internal hosts."""
    if not isinstance(raw_url, str) or not raw_url.strip():
        raise SsrfBlockedError("URL cannot be empty")
    url = raw_url.strip()
    if any(ord(ch) < 0x20 or ord(ch) == 0x7F for ch in url) or "\\" in url:
        raise SsrfBlockedError("URL contains forbidden control or backslash characters")

    parsed = urlparse(url)
    if parsed.scheme.lower() not in ("http", "https"):
        raise SsrfBlockedError(f"Unsupported URL scheme {parsed.scheme!r}; only http/https allowed")
    if parsed.username or parsed.password or "@" in (parsed.netloc or ""):
        raise SsrfBlockedError("Embedded URL credentials or authority '@' tricks are forbidden")

    raw_host = (parsed.hostname or "").strip().lower().rstrip(".")
    if not raw_host:
        raise SsrfBlockedError("URL is missing a hostname")

    # Reject fullwidth dots / Unicode NFKC confusables in hostname
    normalized_host = unicodedata.normalize("NFKC", raw_host).lower().rstrip(".")
    if normalized_host != raw_host:
        raise SsrfBlockedError(f"Blocked Unicode/confusable hostname: {raw_host!r}")
    if any(ord(c) > 127 for c in raw_host):
        try:
            ascii_host = raw_host.encode("idna").decode("ascii")
        except UnicodeError as exc:
            raise SsrfBlockedError(f"Invalid IDNA hostname: {raw_host!r}") from exc
    else:
        ascii_host = raw_host

    for candidate_host in {raw_host, ascii_host}:
        if (
            candidate_host in _BLOCKED_HOSTNAMES
            or candidate_host.endswith(".local")
            or candidate_host.endswith(".internal")
            or candidate_host.endswith(".localhost")
            or candidate_host.endswith(".lan")
            or candidate_host.endswith(".home.arpa")
        ):
            raise SsrfBlockedError(f"Blocked internal hostname: {candidate_host}")

    try:
        port = parsed.port
    except ValueError as exc:
        raise SsrfBlockedError("Invalid URL port") from exc
    if port is not None and port in _BLOCKED_INTERNAL_PORTS:
        raise SsrfBlockedError(f"Blocked internal service port: {port}")

    # Strip zone index if IPv6 literal (e.g. fe80::1%eth0)
    if "%" in ascii_host:
        raise SsrfBlockedError(f"Blocked IPv6 zone-scoped address: {ascii_host}")

    # Reject octal/hex/decimal/short-form IPv4 encodings
    if _looks_like_obfuscated_ip(ascii_host):
        parts = ascii_host.split(".")
        if len(parts) != 4 or any(
            (p.startswith("0") and len(p) > 1) or p.startswith("0x") for p in parts
        ):
            raise SsrfBlockedError(
                f"Blocked obfuscated numeric/octal/hex IP encoding: {ascii_host}"
            )
        try:
            _check_ip_address(ascii_host)
        except ValueError as exc:
            raise SsrfBlockedError(
                f"Blocked obfuscated numeric/octal/hex IP encoding: {ascii_host}"
            ) from exc

    try:
        _check_ip_address(ascii_host)
    except ValueError:
        if resolve_dns:
            if dns_resolver is not None:
                resolved_ips = dns_resolver(ascii_host, port or 80)
                if not resolved_ips:
                    raise SsrfBlockedError(
                        f"DNS resolution returned no records for {ascii_host}"
                    ) from None
                for ip_resolved in resolved_ips:
                    _check_ip_address(ip_resolved)
            else:
                try:
                    infos = socket.getaddrinfo(ascii_host, port or 80, proto=socket.IPPROTO_TCP)
                    for info in infos:
                        sockaddr = info[4]
                        ip_resolved = str(sockaddr[0])
                        _check_ip_address(ip_resolved)
                except SsrfBlockedError:
                    raise
                except OSError:
                    return url

    return url


def extract_readable_html_with_metadata(
    html_text: str, *, max_chars: int = 32768
) -> tuple[str, str, list[str], dict[str, str]]:
    """Extract readable text, title, poisoning warnings, and article metadata from HTML."""
    soup = BeautifulSoup(html_text, "html.parser")
    title = (soup.title.string.strip() if soup.title and soup.title.string else "")[:200]
    warnings: list[str] = []
    metadata: dict[str, str] = {}

    # Extract canonical URL, author/byline, and published date before stripping <head>
    canonical_link = soup.find("link", rel=lambda v: bool(v and "canonical" in str(v).lower()))
    if canonical_link and canonical_link.get("href"):
        metadata["canonical_url"] = str(canonical_link.get("href"))[:512]
    for meta_tag in soup.find_all("meta"):
        m_name = str(meta_tag.get("name") or meta_tag.get("property") or "").lower()
        m_content = str(meta_tag.get("content") or "").strip()
        if m_name in ("author", "article:author", "byl") and m_content:
            metadata["byline"] = m_content[:128]
        elif m_name in ("date", "article:published_time", "pubdate") and m_content:
            metadata["published_date"] = m_content[:64]

    # Inspect HTML comments for prompt injection before removing them
    for comment in soup.find_all(string=lambda text: isinstance(text, Comment)):
        c_str = str(comment)
        if _WEB_POISON_RE.search(c_str):
            warnings.append("poisoned_html_comment_stripped")
        comment.extract()

    # Inspect alt/title attributes for prompt injection
    for el in list(soup.find_all(True)):
        if el.attrs is None:
            continue
        for attr_name in ("alt", "title", "aria-label"):
            attr_val = str(el.attrs.get(attr_name, ""))
            if attr_val and _WEB_POISON_RE.search(attr_val):
                warnings.append(f"poisoned_{attr_name}_attribute_stripped")
                el.attrs.pop(attr_name, None)

    # Remove script, style, noscript, iframe, svg, template, head
    for tag in soup(["script", "style", "noscript", "iframe", "svg", "template", "head"]):
        tag.decompose()

    # Remove elements hidden via inline CSS or aria-hidden / hidden attributes
    for el in list(soup.find_all(True)):
        if el.attrs is None:
            continue
        if "hidden" in el.attrs or str(el.attrs.get("aria-hidden", "")).lower() == "true":
            if _WEB_POISON_RE.search(el.get_text(" ", strip=True)):
                warnings.append("poisoned_hidden_element_stripped")
            else:
                warnings.append("hidden_dom_element_stripped")
            el.decompose()
            continue
        style_val = str(el.attrs.get("style", ""))
        if style_val and _HIDDEN_STYLE_RE.search(style_val):
            if _WEB_POISON_RE.search(el.get_text(" ", strip=True)):
                warnings.append("poisoned_css_hidden_text_stripped")
            else:
                warnings.append("css_hidden_element_stripped")
            el.decompose()

    raw_lines = [
        line.strip() for line in soup.get_text(separator="\n").splitlines() if line.strip()
    ]
    clean_lines: list[str] = []
    for line in raw_lines:
        if _WEB_POISON_RE.search(line):
            warnings.append("poisoned_visible_directive_neutralized")
            line = _WEB_POISON_RE.sub("[NEUTRALIZED-UNTRUSTED-DIRECTIVE]", line)
        clean_lines.append(line)

    cleaned = "\n".join(clean_lines)
    if len(cleaned) > max_chars:
        warnings.append(f"page_truncated_at_{max_chars}_chars")
        cleaned = cleaned[:max_chars] + "\n... [content truncated]"
    return title or "Untitled Page", cleaned, list(dict.fromkeys(warnings)), metadata


def extract_readable_html(html_text: str, *, max_chars: int = 32768) -> tuple[str, str]:
    """Extract clean readable text and title from HTML while stripping comments and hidden spans."""
    title, cleaned, _warnings, _meta = extract_readable_html_with_metadata(
        html_text, max_chars=max_chars
    )
    return title, cleaned


@dataclass(frozen=True)
class FetchedWebPage:
    """Result of an SSRF-safe URL fetch."""

    url: str
    title: str
    content: str
    content_type: str
    status_code: int
    bytes_read: int
    truncated: bool
    warnings: list[str] = field(default_factory=list)
    metadata: dict[str, str] = field(default_factory=dict)
    content_hash: str = ""


async def _resolve_host_async(
    host: str,
    port: int,
    dns_resolver: Callable[[str, int], list[str]] | None,
) -> list[str]:
    """Resolve `host` to a list of IP literals without blocking the event loop."""
    if dns_resolver is not None:
        return await asyncio.to_thread(dns_resolver, host, port)
    infos = await asyncio.to_thread(
        socket.getaddrinfo, host, port, 0, socket.SOCK_STREAM, socket.IPPROTO_TCP
    )
    resolved: list[str] = []
    for info in infos:
        sockaddr = info[4]
        ip_literal = str(sockaddr[0])
        if ip_literal not in resolved:
            resolved.append(ip_literal)
    return resolved


def _pinned_request_target(
    logical_url: str, ip_literal: str
) -> tuple[str, dict[str, str], dict[str, Any]]:
    """Return (connect_url, headers, extensions) that connect to `ip_literal` directly.

    The request is sent to the validated IP while the original Host header and TLS SNI
    are preserved, which closes the TOCTOU window between DNS validation and the actual
    connect (classic DNS-rebinding bypass).
    """
    parsed = urlparse(logical_url)
    host = parsed.hostname or ""
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    host_header = host if parsed.port is None else f"{host}:{parsed.port}"
    ip_host = f"[{ip_literal}]" if ":" in ip_literal else ip_literal
    netloc = f"{ip_host}:{port}"
    connect_url = urlunparse(
        (parsed.scheme, netloc, parsed.path or "/", parsed.params, parsed.query, "")
    )
    headers = {"Host": host_header}
    extensions: dict[str, Any] = {}
    if parsed.scheme == "https":
        extensions["sni_hostname"] = host
    return connect_url, headers, extensions


async def safe_fetch_url(
    url: str,
    *,
    max_bytes: int = 65536,
    timeout_seconds: float = 10.0,
    transport: httpx.AsyncBaseTransport | None = None,
    resolve_dns: bool | None = None,
    dns_resolver: Callable[[str, int], list[str]] | None = None,
) -> FetchedWebPage:
    """Fetch a URL with per-hop SSRF re-validation, DNS pinning, redirect and size caps.

    Pinning: the hostname is resolved once per hop, every returned address is validated
    against the private/internal ranges, and the connection is then made to that exact
    validated IP (Host header and SNI preserved). A low-TTL attacker record therefore
    cannot answer with a public IP during validation and an internal IP during connect.
    """
    # Secure by default: resolve + pin DNS unless the caller injected a mock transport
    # (a MockTransport never reaches the network, so pinning would be meaningless) or
    # explicitly opted out.
    if resolve_dns is None:
        resolve_dns = transport is None
    validated_url = validate_ssrf_safe_url(url, resolve_dns=False)
    timeout = httpx.Timeout(timeout_seconds, connect=min(5.0, timeout_seconds))

    async with httpx.AsyncClient(
        transport=transport,
        timeout=timeout,
        follow_redirects=False,
        headers={"User-Agent": "OdysseusBot/1.0 (+self-hosted)"},
    ) as client:
        current_url = validated_url
        for _hop in range(4):
            # Static checks on every hop (redirect SSRF defense)
            validate_ssrf_safe_url(current_url, resolve_dns=False)

            pinned_ip: str | None = None
            if resolve_dns:
                parsed_host = urlparse(current_url).hostname or ""
                port = urlparse(current_url).port or (
                    443 if urlparse(current_url).scheme == "https" else 80
                )
                if not _is_ip_literal(parsed_host):
                    try:
                        resolved_ips = await _resolve_host_async(parsed_host, port, dns_resolver)
                    except OSError:
                        # Resolution failed: no pinning possible. The static checks above
                        # still apply and the connection attempt will fail on its own.
                        resolved_ips = []
                    if not resolved_ips:
                        raise SsrfBlockedError(
                            f"DNS resolution returned no records for {parsed_host}"
                        )
                    for ip_resolved in resolved_ips:
                        _check_ip_address(ip_resolved)
                    pinned_ip = resolved_ips[0]

            request_url = current_url
            request_headers: dict[str, str] | None = None
            request_extensions: dict[str, Any] | None = None
            if pinned_ip is not None:
                request_url, request_headers, request_extensions = _pinned_request_target(
                    current_url, pinned_ip
                )
            async with client.stream(
                "GET",
                request_url,
                headers=request_headers,
                extensions=request_extensions,
            ) as resp:
                if resp.status_code in (301, 302, 303, 307, 308):
                    loc = resp.headers.get("location", "")
                    if not loc:
                        break
                    # Resolve the redirect against the *logical* URL, not the pinned IP
                    current_url = str(httpx.URL(current_url).join(loc))
                    continue

                chunks: list[bytes] = []
                total = 0
                truncated = False
                async for chunk in resp.aiter_bytes(4096):
                    remaining = max_bytes - total
                    if remaining <= 0:
                        truncated = True
                        break
                    if len(chunk) > remaining:
                        chunks.append(chunk[:remaining])
                        total += remaining
                        truncated = True
                        break
                    chunks.append(chunk)
                    total += len(chunk)

                raw_bytes = b"".join(chunks)
                ctype = resp.headers.get("content-type", "text/plain").lower()
                text_body = raw_bytes.decode("utf-8", errors="replace")
                warnings: list[str] = []
                meta: dict[str, str] = {}
                if "html" in ctype or "<html" in text_body[:512].lower():
                    title, readable, warnings, meta = extract_readable_html_with_metadata(
                        text_body, max_chars=max_bytes
                    )
                else:
                    title = urlparse(current_url).hostname or current_url
                    readable = text_body[:max_bytes]

                if truncated and "response_byte_cap_reached" not in warnings:
                    warnings.append("response_byte_cap_reached")

                chash = hashlib.sha256(readable.encode("utf-8")).hexdigest()[:16]
                return FetchedWebPage(
                    url=current_url,
                    title=title,
                    content=readable,
                    content_type=ctype,
                    status_code=resp.status_code,
                    bytes_read=total,
                    truncated=truncated,
                    warnings=warnings,
                    metadata=meta,
                    content_hash=chash,
                )

    raise SsrfBlockedError("Too many redirects when fetching URL")


@dataclass(frozen=True)
class CachedSourceEntry:
    """Content-addressed cached web source with normalized citation metadata."""

    citation_id: int
    url: str
    title: str
    domain: str
    snippet: str
    text: str
    content_hash: str
    retrieved_at: str
    etag: str | None = None
    last_modified: str | None = None
    expires_at_epoch: float = 0.0
    warnings: list[str] = field(default_factory=list)

    def to_citation_dict(self) -> dict[str, Any]:
        return {
            "id": self.citation_id,
            "url": self.url,
            "title": self.title,
            "domain": self.domain,
            "snippet": self.snippet,
            "retrieved_at": self.retrieved_at,
            "content_hash": self.content_hash,
            "warnings": list(self.warnings),
        }


class SourceCache:
    """Content-addressed TTL source cache with ETag/Last-Modified and domain rate limits."""

    def __init__(self, ttl_seconds: float = 900.0) -> None:
        self.ttl_seconds = ttl_seconds
        self._by_url: dict[str, CachedSourceEntry] = {}
        self._by_hash: dict[str, CachedSourceEntry] = {}
        self._domain_last_req: dict[str, float] = {}
        self._next_id: int = 1

    def get(self, url: str) -> CachedSourceEntry | None:
        entry = self._by_url.get(url)
        if entry is None:
            return None
        if time.monotonic() > entry.expires_at_epoch:
            return None
        return entry

    def put_from_page(
        self,
        page: FetchedWebPage,
        *,
        etag: str | None = None,
        last_modified: str | None = None,
    ) -> CachedSourceEntry:
        existing = self._by_url.get(page.url)
        cid = existing.citation_id if existing is not None else self._next_id
        if existing is None:
            self._next_id += 1
        parsed = urlparse(page.url)
        domain = (parsed.hostname or "unknown").lower()
        snippet = " ".join(page.content.split())[:240]
        chash = page.content_hash or hashlib.sha256(page.content.encode("utf-8")).hexdigest()[:16]
        entry = CachedSourceEntry(
            citation_id=cid,
            url=page.url,
            title=page.title,
            domain=domain,
            snippet=snippet,
            text=page.content,
            content_hash=chash,
            retrieved_at=datetime.now(UTC).isoformat(),
            etag=etag,
            last_modified=last_modified,
            expires_at_epoch=time.monotonic() + self.ttl_seconds,
            warnings=list(page.warnings),
        )
        self._by_url[page.url] = entry
        self._by_hash[chash] = entry
        self._domain_last_req[domain] = time.monotonic()
        return entry

    def list_entries(self) -> list[CachedSourceEntry]:
        return sorted(self._by_url.values(), key=lambda e: e.citation_id)


def render_domain_favicon_svg(domain: str) -> str:
    """Render a deterministic, SSRF-safe server-side SVG favicon for a domain."""
    clean_domain = re.sub(r"[^a-zA-Z0-9.-]", "", (domain or "web").strip().lower()) or "web"
    initial = clean_domain[0].upper()
    digest = hashlib.sha256(clean_domain.encode("utf-8")).digest()
    hue = int.from_bytes(digest[:2], "big") % 360
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16">'
        f'<rect width="24" height="24" rx="5" fill="hsl({hue}, 55%, 38%)"/>'
        f'<text x="12" y="17" text-anchor="middle" fill="#ffffff" '
        f'font-family="sans-serif" font-size="13" font-weight="bold">{initial}</text>'
        f"</svg>"
    )


class WebSearchUnavailableError(RuntimeError):
    """Raised when web search has no usable backend and no synthetic data is allowed."""


async def execute_web_search(
    query: str,
    *,
    max_results: int = 5,
    searxng_url: str | None = None,
    transport: httpx.AsyncBaseTransport | None = None,
    allow_synthetic_fallback: bool = False,
) -> list[dict[str, Any]]:
    """Query the configured SearXNG instance.

    Synthetic placeholder results are ONLY produced when the caller explicitly allows
    them (``environment=test``). In production a search failure raises
    :class:`WebSearchUnavailableError` instead of silently returning fabricated results,
    which previously let the agent "cite" pages that never existed.
    """
    q_clean = query.strip()
    if not q_clean:
        return []

    if searxng_url:
        try:
            async with httpx.AsyncClient(transport=transport, timeout=5.0) as client:
                r = await client.get(
                    f"{searxng_url.rstrip('/')}/search",
                    params={"q": q_clean, "format": "json"},
                )
                if r.status_code == 200:
                    data = r.json()
                    items = data.get("results", [])[:max_results]
                    return [
                        {
                            "title": str(it.get("title", "")),
                            "url": str(it.get("url", "")),
                            "snippet": str(it.get("content", "")),
                        }
                        for it in items
                    ]
                raise WebSearchUnavailableError(
                    f"SearXNG returned HTTP {r.status_code} for query {q_clean!r}"
                )
        except WebSearchUnavailableError:
            raise
        except Exception as exc:
            if not allow_synthetic_fallback:
                raise WebSearchUnavailableError(
                    f"Web search backend unreachable ({searxng_url}): {exc}"
                ) from exc

    if not allow_synthetic_fallback:
        raise WebSearchUnavailableError(
            "No web search backend configured (searxng_url is unset); refusing to return "
            "fabricated results."
        )

    slug = re.sub(r"[^a-z0-9]+", "-", q_clean.lower()).strip("-") or "query"
    results: list[dict[str, Any]] = []
    for idx in range(1, max(1, min(max_results, 10)) + 1):
        results.append(
            {
                "title": f"Result {idx} for {q_clean}",
                "url": f"https://search.example.org/{slug}/{idx}",
                "snippet": f"Reference summary #{idx} matching query '{q_clean}'.",
            }
        )
    return results


def extract_youtube_video_id(video_url_or_id: str) -> str:
    """Extract a validated 11-character YouTube video ID from a URL or ID string."""
    raw = video_url_or_id.strip()
    if re.fullmatch(r"[A-Za-z0-9_-]{11}", raw):
        return raw
    parsed = urlparse(raw)
    host = (parsed.hostname or "").lower()
    if host in ("youtu.be", "www.youtu.be"):
        vid = parsed.path.lstrip("/").split("/")[0]
        if re.fullmatch(r"[A-Za-z0-9_-]{11}", vid):
            return vid
    if host.endswith("youtube.com"):
        qs = parse_qs(parsed.query)
        v_list = qs.get("v", [])
        if v_list and re.fullmatch(r"[A-Za-z0-9_-]{11}", v_list[0]):
            return v_list[0]
    raise ValueError(f"Invalid YouTube video URL or ID: {video_url_or_id!r}")
