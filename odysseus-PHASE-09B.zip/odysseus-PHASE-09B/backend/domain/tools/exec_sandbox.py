"""Sandboxed shell and Python execution with process-group isolation and rlimit caps.

Isolation model (fail-closed):

- ``subprocess_rlimit``: **no kernel isolation**. Provides process-group containment,
  rlimits (CPU/FSIZE/NOFILE/NPROC/AS), a scrubbed environment, and output/time caps.
  It does NOT isolate the filesystem or the network, so it is refused in
  ``environment=production`` unless the operator explicitly opts in with
  ``allow_unsandboxed_exec=True``.
- ``bwrap``: bubblewrap namespaces (mount/PID/net/IPC/UTS/cgroup/user) + read-only
  system bind mounts. Requires the ``bwrap`` binary; if it is missing, execution is
  refused instead of silently degrading to an unsandboxed process.
- ``docker``: not implemented yet; selecting it refuses to execute rather than
  silently falling back to an unsandboxed process (previous behaviour).

Network access is blocked at the namespace level (``--unshare-net``): language-level
hooks (``sys.addaudithook``) are NOT a security boundary because they are trivially
bypassed from a child process (``os.system``, ``ctypes``, ``curl``) or via DNS.
"""

from __future__ import annotations

import asyncio
import codecs
import contextlib
import os
import resource
import shutil
import signal
import sys
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

OutputDeltaCallback = Callable[[Literal["stdout", "stderr", "log"], str], Awaitable[None]]
PgidCallback = Callable[[int], Awaitable[None]]


class SandboxUnavailableError(RuntimeError):
    """Raised when the configured sandbox backend cannot provide its isolation guarantees.

    Callers must treat this as a hard failure (fail-closed); never fall back to
    running the command without isolation.
    """


@dataclass(frozen=True)
class SandboxResult:
    """Outcome of a sandboxed subprocess execution."""

    exit_code: int
    stdout: str
    stderr: str
    combined_output: str
    truncated: bool
    timed_out: bool
    duration_ms: int
    pgid: int | None = None


def kill_process_group_safely(pgid: int | None) -> bool:
    """Send SIGKILL to a process group if it still exists.

    Callers MUST only use this while the group leader is known to be un-reaped:
    once the leader has been reaped the PID (and therefore the PGID) may be recycled
    by an unrelated process, and signalling it would kill someone else's processes.
    """
    if pgid is None or pgid <= 1:
        return False
    killed = False
    try:
        os.killpg(pgid, signal.SIGKILL)
        killed = True
    except ProcessLookupError:
        return False
    except PermissionError:
        killed = True
    return killed


async def terminate_process_group_gracefully(
    pgid: int | None, *, grace_seconds: float = 0.25
) -> None:
    """Ask the process group to exit with SIGTERM, then SIGKILL if it ignores the request.

    The docstring/PROCESS model promised SIGTERM -> SIGKILL; jumping straight to SIGKILL
    denied children the chance to flush buffers, close sockets, or clean up scratch files.
    SIGKILL is still the backstop, so a hostile process cannot delay termination for long.
    """
    if pgid is None or pgid <= 1:
        return
    try:
        os.killpg(pgid, signal.SIGTERM)
    except (ProcessLookupError, PermissionError):
        return
    deadline = time.perf_counter() + max(0.0, grace_seconds)
    while time.perf_counter() < deadline:
        if not is_process_group_alive(pgid):
            return
        await asyncio.sleep(0.02)
    try:
        os.killpg(pgid, signal.SIGKILL)
    except (ProcessLookupError, PermissionError):
        return


def is_process_group_alive(pgid: int | None) -> bool:
    """Return True if any process in process group `pgid` is still alive."""
    if pgid is None or pgid <= 1:
        return False
    try:
        os.killpg(pgid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


def _build_minimal_env(workspace_root: Path, tmp_dir: Path) -> dict[str, str]:
    """Construct a clean, secret-free environment dictionary for sandboxed execution.

    Note: no proxy environment variables are set. ``http_proxy``/``NO_PROXY`` are not
    security controls (any tool can ignore them), so they were removed rather than
    left in place as security theatre.
    """
    return {
        "PATH": "/usr/local/bin:/usr/bin:/bin",
        "HOME": str(workspace_root),
        "TMPDIR": str(tmp_dir),
        "TEMP": str(tmp_dir),
        "TMP": str(tmp_dir),
        "LANG": "C.UTF-8",
        "LC_ALL": "C.UTF-8",
        "PYTHONIOENCODING": "utf-8",
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONNOUSERSITE": "1",
    }


def _make_preexec_fn(
    *,
    cpu_seconds: int,
    max_fsize_bytes: int,
    max_nproc: int | None,
    max_nofile: int = 64,
    max_memory_bytes: int | None = None,
) -> Callable[[], None]:
    """Create preexec_fn that starts a dedicated process group and applies POSIX rlimits."""

    def _preexec() -> None:
        os.setsid()
        with contextlib.suppress(ValueError, OSError):
            resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        with contextlib.suppress(ValueError, OSError):
            resource.setrlimit(resource.RLIMIT_CPU, (cpu_seconds, cpu_seconds + 1))
        with contextlib.suppress(ValueError, OSError):
            resource.setrlimit(resource.RLIMIT_FSIZE, (max_fsize_bytes, max_fsize_bytes))
        with contextlib.suppress(ValueError, OSError):
            resource.setrlimit(resource.RLIMIT_NOFILE, (max_nofile, max_nofile))
        if max_memory_bytes is not None and max_memory_bytes > 0:
            with contextlib.suppress(ValueError, OSError):
                resource.setrlimit(
                    resource.RLIMIT_AS, (max_memory_bytes, max_memory_bytes)
                )
        if max_nproc is not None and hasattr(resource, "RLIMIT_NPROC"):
            with contextlib.suppress(ValueError, OSError):
                resource.setrlimit(resource.RLIMIT_NPROC, (max_nproc, max_nproc))

    return _preexec


def _bwrap_argv(workspace_root: Path, tmp_dir: Path, argv: list[str]) -> list[str]:
    """Build a fail-closed bubblewrap argv with mount/PID/net/IPC namespace isolation.

    ``--unshare-all`` already implies ``--unshare-pid``; ``--proc``/``--dev`` are
    required for a functional ``/proc`` and device nodes inside the namespace, and
    ``--new-session`` detaches the controlling terminal.
    """
    return [
        "bwrap",
        "--ro-bind",
        "/usr",
        "/usr",
        "--ro-bind-try",
        "/lib",
        "/lib",
        "--ro-bind-try",
        "/lib64",
        "/lib64",
        "--ro-bind",
        "/bin",
        "/bin",
        "--ro-bind-try",
        "/etc/passwd",
        "/etc/passwd",
        "--ro-bind-try",
        "/etc/group",
        "/etc/group",
        "--bind",
        str(workspace_root),
        str(workspace_root),
        "--bind",
        str(tmp_dir),
        str(tmp_dir),
        "--proc",
        "/proc",
        "--dev",
        "/dev",
        "--tmpfs",
        "/tmp",  # noqa: S108
        "--unshare-all",
        "--cap-drop",
        "ALL",
        "--new-session",
        "--die-with-parent",
        "--chdir",
        str(workspace_root),
        *argv,
    ]


def _resolve_backend_argv(
    backend: str,
    workspace_root: Path,
    tmp_dir: Path,
    argv: list[str],
) -> list[str]:
    """Return the effective argv for a backend, refusing to run when isolation is absent.

    Fail-closed policy: a backend that cannot provide its promised isolation raises
    :class:`SandboxUnavailableError` instead of silently executing without isolation.
    """
    if backend == "subprocess_rlimit":
        return list(argv)
    if backend == "bwrap":
        if shutil.which("bwrap") is None:
            raise SandboxUnavailableError(
                "sandbox backend 'bwrap' selected but the bubblewrap binary is not "
                "installed; refusing to execute without isolation. Install bubblewrap "
                "(apt-get install bubblewrap) or explicitly select another backend."
            )
        return _bwrap_argv(workspace_root, tmp_dir, argv)
    if backend == "docker":
        raise SandboxUnavailableError(
            "sandbox backend 'docker' is not implemented; refusing to execute without "
            "isolation. Use 'bwrap' or the explicitly opted-in 'subprocess_rlimit' mode."
        )
    raise SandboxUnavailableError(f"unknown sandbox backend {backend!r}")


_PYTHON_SANDBOX_PRELUDE = """\
import sys as _sys
def _odysseus_audit_hook(event, args):
    if event in (
        "socket.bind",
        "socket.connect",
        "socket.sendmsg",
        "socket.sendto",
        "urllib.Request",
        "http.client.connect",
    ):
        raise PermissionError(f"Network socket operation '{event}' is blocked in sandbox")
_sys.addaudithook(_odysseus_audit_hook)
"""


async def run_sandboxed_command(
    argv: list[str],
    *,
    workspace_root: Path,
    timeout_seconds: float = 10.0,
    max_output_bytes: int = 65536,
    cpu_seconds: int = 5,
    max_fsize_bytes: int = 10_485_760,
    max_nproc: int | None = None,
    max_memory_bytes: int | None = None,
    backend: Literal["subprocess_rlimit", "bwrap", "docker"] = "subprocess_rlimit",
    env_extra: dict[str, str] | None = None,
    cancel_event: asyncio.Event | None = None,
    on_output_delta: OutputDeltaCallback | None = None,
    on_pgid_started: PgidCallback | None = None,
) -> SandboxResult:
    """Execute `argv` inside an isolated process group with resource, time, and output caps.

    Raises :class:`SandboxUnavailableError` (fail-closed) when the requested backend is
    unavailable or unimplemented — the command is then NOT executed.
    """
    os.makedirs(str(workspace_root), exist_ok=True)
    # Scratch space lives OUTSIDE the user's workspace so agent file tools / glob /
    # listing never see sandbox temporaries.
    tmp_dir = workspace_root.parent / ".sandbox_tmp" / workspace_root.name
    os.makedirs(str(tmp_dir), exist_ok=True)
    # Scratch space can hold partial downloads / compiler output; keep it private.
    with contextlib.suppress(OSError):
        os.chmod(workspace_root.parent / ".sandbox_tmp", 0o700)
        os.chmod(tmp_dir, 0o700)

    env = _build_minimal_env(workspace_root, tmp_dir)
    if env_extra:
        env.update({k: str(v) for k, v in env_extra.items()})

    effective_argv = _resolve_backend_argv(
        backend,
        workspace_root=workspace_root,
        tmp_dir=tmp_dir,
        argv=list(argv),
    )

    start_mono = time.perf_counter()
    proc = await asyncio.create_subprocess_exec(
        *effective_argv,
        cwd=str(workspace_root),
        env=env,
        stdin=asyncio.subprocess.DEVNULL,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        preexec_fn=_make_preexec_fn(
            cpu_seconds=max(1, cpu_seconds),
            max_fsize_bytes=max(4096, max_fsize_bytes),
            max_nproc=max_nproc,
            max_memory_bytes=max_memory_bytes,
        ),
    )

    pgid = proc.pid
    if on_pgid_started is not None and pgid is not None:
        await on_pgid_started(pgid)

    stdout_chunks: list[bytes] = []
    stderr_chunks: list[bytes] = []
    total_captured = 0
    truncated = False
    timed_out = False
    cap_lock = asyncio.Lock()

    # Coalesce output deltas at <= 20 events/s (50ms window) per stream
    coalesce_interval = 0.05

    async def _pump_stream(
        stream: asyncio.StreamReader | None,
        stream_name: Literal["stdout", "stderr"],
        collector: list[bytes],
    ) -> None:
        nonlocal total_captured, truncated
        if stream is None:
            return
        pending_str: list[str] = []
        last_emit = time.perf_counter()
        # Incremental decoder keeps multi-byte UTF-8 characters intact across 4 KiB reads
        decoder = codecs.getincrementaldecoder("utf-8")(errors="replace")

        async def _flush_delta(*, force: bool = False) -> None:
            nonlocal last_emit
            if not pending_str or on_output_delta is None:
                return
            now = time.perf_counter()
            if not force and (now - last_emit) < coalesce_interval:
                return
            text_payload = "".join(pending_str)
            pending_str.clear()
            last_emit = now
            await on_output_delta(stream_name, text_payload)

        while True:
            chunk = await stream.read(4096)
            if not chunk:
                break
            async with cap_lock:
                remaining = max_output_bytes - total_captured
                if remaining <= 0:
                    truncated = True
                    kill_process_group_safely(pgid)
                    break
                if len(chunk) > remaining:
                    chunk = chunk[:remaining]
                    truncated = True
                collector.append(chunk)
                total_captured += len(chunk)
                if truncated:
                    kill_process_group_safely(pgid)

            decoded = decoder.decode(chunk)
            if decoded:
                pending_str.append(decoded)
                await _flush_delta(force=False)
            if truncated:
                break

        tail = decoder.decode(b"", final=True)
        if tail:
            pending_str.append(tail)
        await _flush_delta(force=True)

    pump_task = asyncio.gather(
        _pump_stream(proc.stdout, "stdout", stdout_chunks),
        _pump_stream(proc.stderr, "stderr", stderr_chunks),
    )
    wait_task = asyncio.create_task(proc.wait())

    try:
        deadline = start_mono + timeout_seconds
        while not wait_task.done():
            if cancel_event is not None and cancel_event.is_set():
                await terminate_process_group_gracefully(pgid)
                raise asyncio.CancelledError()
            remaining_sec = deadline - time.perf_counter()
            if remaining_sec <= 0:
                timed_out = True
                await terminate_process_group_gracefully(pgid)
                break
            try:
                await asyncio.wait_for(
                    asyncio.shield(wait_task),
                    timeout=min(0.05, max(0.005, remaining_sec)),
                )
            except TimeoutError:
                continue

        with contextlib.suppress(TimeoutError, Exception):
            await asyncio.wait_for(pump_task, timeout=1.0)
        with contextlib.suppress(TimeoutError, Exception):
            await asyncio.wait_for(wait_task, timeout=1.0)
    finally:
        # SIGKILL the whole process group *while the leader is still un-reaped*.
        # Once the leader has been reaped its PID (and hence the PGID) may be recycled
        # by an unrelated process, so a later killpg could kill a bystander's group.
        for _ in range(3):
            if proc.returncode is not None:
                break
            try:
                os.killpg(pgid, signal.SIGKILL)
            except (ProcessLookupError, PermissionError):
                break
            try:
                await asyncio.wait_for(asyncio.shield(wait_task), timeout=0.25)
            except (TimeoutError, Exception):
                continue
        if not wait_task.done():
            with contextlib.suppress(TimeoutError, asyncio.CancelledError, Exception):
                await asyncio.wait_for(wait_task, timeout=0.5)
        if not wait_task.done():
            wait_task.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await wait_task
        if not pump_task.done():
            pump_task.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await pump_task

    duration_ms = max(0, int((time.perf_counter() - start_mono) * 1000))
    stdout_str = b"".join(stdout_chunks).decode("utf-8", errors="replace")
    stderr_str = b"".join(stderr_chunks).decode("utf-8", errors="replace")
    if truncated:
        marker = f"\n... [OUTPUT TRUNCATED AT {max_output_bytes} BYTES] ..."
        stdout_str += marker
    if timed_out:
        stderr_str += f"\n[Process killed after exceeding {timeout_seconds:.1f}s timeout]"

    combined = stdout_str
    if stderr_str:
        combined = f"{stdout_str}\n[stderr]\n{stderr_str}".strip() if stdout_str else stderr_str

    exit_code = proc.returncode if proc.returncode is not None else (-9 if timed_out else -1)
    return SandboxResult(
        exit_code=exit_code,
        stdout=stdout_str,
        stderr=stderr_str,
        combined_output=combined,
        truncated=truncated,
        timed_out=timed_out,
        duration_ms=duration_ms,
        pgid=pgid,
    )


async def run_sandboxed_shell(
    command: str,
    *,
    workspace_root: Path,
    timeout_seconds: float = 10.0,
    max_output_bytes: int = 65536,
    cpu_seconds: int = 5,
    max_fsize_bytes: int = 10_485_760,
    max_nproc: int | None = None,
    max_memory_bytes: int | None = None,
    backend: Literal["subprocess_rlimit", "bwrap", "docker"] = "subprocess_rlimit",
    cancel_event: asyncio.Event | None = None,
    on_output_delta: OutputDeltaCallback | None = None,
    on_pgid_started: PgidCallback | None = None,
) -> SandboxResult:
    """Execute a shell command in a sandboxed process group with ulimit guards.

    Network isolation is provided by the backend itself (``bwrap --unshare-all``).
    ``subprocess_rlimit`` provides no network isolation — there is no reliable
    language/environment-level substitute, so callers must enforce posture policy.
    """
    fsize_blocks = max(1, max_fsize_bytes // 512)
    nproc_guard = f"ulimit -u {max_nproc} 2>/dev/null || true; " if max_nproc else ""
    wrapped_cmd = f"ulimit -f {fsize_blocks} 2>/dev/null || true; {nproc_guard}{command}"
    return await run_sandboxed_command(
        ["/bin/sh", "-c", wrapped_cmd],
        workspace_root=workspace_root,
        timeout_seconds=timeout_seconds,
        max_output_bytes=max_output_bytes,
        cpu_seconds=cpu_seconds,
        max_fsize_bytes=max_fsize_bytes,
        max_nproc=max_nproc,
        max_memory_bytes=max_memory_bytes,
        backend=backend,
        cancel_event=cancel_event,
        on_output_delta=on_output_delta,
        on_pgid_started=on_pgid_started,
    )


async def run_sandboxed_python(
    code: str,
    *,
    workspace_root: Path,
    allow_network: bool = False,
    timeout_seconds: float = 10.0,
    max_output_bytes: int = 65536,
    cpu_seconds: int = 5,
    max_fsize_bytes: int = 10_485_760,
    max_nproc: int | None = None,
    max_memory_bytes: int | None = None,
    backend: Literal["subprocess_rlimit", "bwrap", "docker"] = "subprocess_rlimit",
    cancel_event: asyncio.Event | None = None,
    on_output_delta: OutputDeltaCallback | None = None,
    on_pgid_started: PgidCallback | None = None,
) -> SandboxResult:
    """Execute Python code in a sandboxed subprocess with audit hook blocking network sockets.

    The audit hook is defense-in-depth only; it is bypassable from child processes and
    via DNS. Real isolation requires the backend (``bwrap --unshare-all`` / containers).
    """
    full_script = code if allow_network else f"{_PYTHON_SANDBOX_PRELUDE}\n{code}"
    return await run_sandboxed_command(
        [sys.executable, "-I", "-B", "-c", full_script],
        workspace_root=workspace_root,
        timeout_seconds=timeout_seconds,
        max_output_bytes=max_output_bytes,
        cpu_seconds=cpu_seconds,
        max_fsize_bytes=max_fsize_bytes,
        max_nproc=max_nproc,
        max_memory_bytes=max_memory_bytes,
        backend=backend,
        cancel_event=cancel_event,
        on_output_delta=on_output_delta,
        on_pgid_started=on_pgid_started,
    )


def sandbox_backend_is_isolated(backend: str) -> bool:
    """Return True if `backend` provides real kernel-level isolation for exec tools."""
    if backend == "bwrap":
        return shutil.which("bwrap") is not None
    return False
