"""Memory service: hybrid vector + BM25 fallback, single privacy gate, dedup, TTL, export/import."""

from __future__ import annotations

import hashlib
import json
import math
import re
import uuid
from datetime import UTC, datetime, timedelta
from typing import Any, Literal

import httpx
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.db import DatabaseManager
from backend.core.models import MemoryRecord
from backend.core.settings import Settings
from backend.core.uow import UnitOfWork, _ensure_utc

MemoryScopeLiteral = Literal["user", "project"]
_TOKEN_RE = re.compile(r"[a-z0-9_]{2,}")


def tokenize_for_bm25(text: str) -> list[str]:
    """Extract lowercase alphanumeric tokens for BM25 and similarity scoring."""
    return _TOKEN_RE.findall(text.lower())


def compute_text_embedding(text: str, dim: int = 64) -> list[float]:
    """Compute a deterministic L2-normalized hashed token/bigram embedding vector."""
    vec = [0.0] * dim
    tokens = tokenize_for_bm25(text)
    if not tokens:
        return vec
    features = list(tokens)
    for i in range(len(tokens) - 1):
        features.append(f"{tokens[i]}_{tokens[i + 1]}")
    for feat in features:
        digest = hashlib.sha256(feat.encode("utf-8")).digest()
        idx = int.from_bytes(digest[:4], "big") % dim
        sign = 1.0 if (digest[4] & 1) == 0 else -1.0
        vec[idx] += sign
    norm = math.sqrt(sum(v * v for v in vec))
    if norm > 0:
        vec = [round(v / norm, 6) for v in vec]
    return vec


def cosine_similarity(a: list[float], b: list[float]) -> float:
    """Compute cosine similarity between two equal-length vectors."""
    if not a or not b or len(a) != len(b):
        return 0.0
    return sum(x * y for x, y in zip(a, b, strict=False))


def compute_bm25_score(
    query_tokens: list[str],
    doc_tokens: list[str],
    *,
    avg_doc_len: float,
    doc_freqs: dict[str, int],
    total_docs: int,
    k1: float = 1.5,
    b: float = 0.75,
) -> float:
    """Compute Okapi BM25 relevance score for a single document."""
    if not query_tokens or not doc_tokens or total_docs <= 0:
        return 0.0
    doc_len = float(len(doc_tokens))
    tf_map: dict[str, int] = {}
    for tok in doc_tokens:
        tf_map[tok] = tf_map.get(tok, 0) + 1

    score = 0.0
    safe_avg = max(1.0, avg_doc_len)
    for q_tok in set(query_tokens):
        tf = tf_map.get(q_tok, 0)
        if tf == 0:
            continue
        df = doc_freqs.get(q_tok, 0)
        idf = math.log(1.0 + (total_docs - df + 0.5) / (df + 0.5))
        denom = tf + k1 * (1.0 - b + b * (doc_len / safe_avg))
        score += idf * ((tf * (k1 + 1.0)) / denom)
    return score


_INVISIBLE_STRIP_RE = re.compile(
    r"[\u200b-\u200f\u202a-\u202e\u2060-\u2064\u2066-\u2069\ufeff\u00ad]"
)
_DELIMITER_SPOOF_RE = re.compile(r"</?untrusted[-_]?(?:data|external)[^>]*>", re.IGNORECASE)


def sanitize_memory_text(text: str) -> str:
    """Neutralize characters/sequences that enable second-order prompt injection.

    Applied on save (not only on recall) so poisoned content never reaches the database in
    a form that could impersonate the harness' untrusted-data envelope.
    """
    cleaned = _INVISIBLE_STRIP_RE.sub("", text)
    cleaned = _DELIMITER_SPOOF_RE.sub("[delimiter removed]", cleaned)
    return cleaned.strip()


def _jaccard_similarity(a_text: str, b_text: str) -> float:
    set_a = set(tokenize_for_bm25(a_text))
    set_b = set(tokenize_for_bm25(b_text))
    if not set_a or not set_b:
        return 1.0 if a_text.strip().lower() == b_text.strip().lower() else 0.0
    return len(set_a & set_b) / len(set_a | set_b)


def _memory_to_dict(rec: MemoryRecord) -> dict[str, Any]:
    return {
        "id": rec.id,
        "user_id": rec.user_id,
        "project_id": rec.project_id,
        "scope": rec.scope,
        "text": rec.text,
        "source_chat_id": rec.source_chat_id,
        "source_run_id": rec.source_run_id,
        "pinned": rec.pinned,
        "confirmed": rec.confirmed,
        "expires_at": _ensure_utc(rec.expires_at).isoformat() if rec.expires_at else None,
        "created_at": _ensure_utc(rec.created_at).isoformat(),
        "updated_at": _ensure_utc(rec.updated_at).isoformat(),
    }


class MemoryService:
    """Semantic + BM25 memory service with a single hard privacy gate and ChromaDB fallback."""

    def __init__(self, db: DatabaseManager, settings: Settings) -> None:
        self.db = db
        self.settings = settings
        self._privacy_enabled: bool = bool(settings.memory_enabled)
        self.degraded_reason: str | None = None
        self.chromadb_healthy: bool = False

    @property
    def privacy_enabled(self) -> bool:
        return self._privacy_enabled and bool(self.settings.memory_enabled)

    def set_privacy_switch(self, enabled: bool) -> None:
        """Single hard privacy switch: when False, nothing is read or written."""
        self._privacy_enabled = bool(enabled)

    def _enforce_privacy_gate(self) -> bool:
        """Centralized privacy enforcement gate used by every read and write method."""
        return self.privacy_enabled

    async def probe_chromadb(self, *, timeout_seconds: float = 0.35) -> bool:
        """Probe ChromaDB heartbeat endpoint and update degraded status if unreachable."""
        url = f"{self.settings.chromadb_url.rstrip('/')}/api/v1/heartbeat"
        try:
            async with httpx.AsyncClient(timeout=timeout_seconds) as client:
                resp = await client.get(url)
                if resp.status_code < 400:
                    self.chromadb_healthy = True
                    self.degraded_reason = None
                    return True
                self.chromadb_healthy = False
                self.degraded_reason = (
                    f"ChromaDB returned HTTP {resp.status_code} at {url}; "
                    "using BM25/keyword fallback"
                )
                return False
        except Exception as exc:
            self.chromadb_healthy = False
            self.degraded_reason = (
                f"ChromaDB unreachable at {self.settings.chromadb_url} "
                f"({type(exc).__name__}); using BM25/keyword fallback"
            )
            return False

    async def save_memory(
        self,
        *,
        user_id: str,
        text: str,
        scope: MemoryScopeLiteral = "user",
        project_id: str | None = None,
        source_chat_id: str | None = None,
        source_run_id: str | None = None,
        pinned: bool = False,
        confirmed: bool = True,
        ttl_seconds: int | None = None,
    ) -> tuple[dict[str, Any] | None, Literal["created", "updated", "pinned"]]:
        """Save or deduplicate/merge a memory entry if the privacy gate is enabled."""
        if not self._enforce_privacy_gate():
            return None, "created"

        cleaned = text.strip()
        if not cleaned:
            raise ValueError("Memory text cannot be empty")
        if len(cleaned) > 8192:
            cleaned = cleaned[:8192]
        # Second-order injection guard: memories are recalled into later prompts, so a
        # payload that was read from an untrusted page (or hallucinated by a model obeying
        # one) must not be able to smuggle invisible characters or close the randomized
        # untrusted-data delimiter that the context builder wraps memories in.
        cleaned = sanitize_memory_text(cleaned)

        now = datetime.now(UTC)
        expires_at = (
            now + timedelta(seconds=ttl_seconds)
            if ttl_seconds is not None and ttl_seconds > 0 and not pinned
            else None
        )
        embedding = compute_text_embedding(cleaned)

        async def _tx(
            sess: AsyncSession,
        ) -> tuple[dict[str, Any], Literal["created", "updated", "pinned"]]:
            uow = UnitOfWork(sess)
            existing_rows = await uow.memories.list_for_user(
                user_id, scope=scope, project_id=project_id
            )
            for row in existing_rows:
                if _jaccard_similarity(row.text, cleaned) >= 0.85:
                    row.text = cleaned
                    row.embedding_json = embedding
                    row.pinned = row.pinned or pinned
                    row.confirmed = row.confirmed or confirmed
                    if expires_at is not None and not row.pinned:
                        row.expires_at = expires_at
                    row.updated_at = now
                    return _memory_to_dict(row), ("pinned" if pinned else "updated")

            mem_id = f"mem_{uuid.uuid4().hex[:20]}"
            rec = MemoryRecord(
                id=mem_id,
                user_id=user_id,
                project_id=project_id,
                scope=scope,
                text=cleaned,
                source_chat_id=source_chat_id,
                source_run_id=source_run_id,
                embedding_json=embedding,
                pinned=pinned,
                confirmed=confirmed,
                expires_at=expires_at,
                created_at=now,
                updated_at=now,
            )
            await uow.memories.add(rec)
            return _memory_to_dict(rec), "created"

        return await self.db.execute_write(_tx)

    async def search_memories(
        self,
        *,
        user_id: str,
        query: str,
        scope: MemoryScopeLiteral | None = None,
        project_id: str | None = None,
        limit: int = 5,
        check_chromadb: bool = True,
    ) -> list[dict[str, Any]]:
        """Search memories using hybrid semantic + BM25 scoring with automatic keyword fallback."""
        if not self._enforce_privacy_gate():
            return []

        if check_chromadb:
            await self.probe_chromadb()

        now = datetime.now(UTC)

        async def _load(sess: AsyncSession) -> list[MemoryRecord]:
            uow = UnitOfWork(sess)
            rows = await uow.memories.list_for_user(
                user_id,
                scope=scope,
                project_id=project_id,
                confirmed_only=True,
            )
            active: list[MemoryRecord] = []
            for r in rows:
                if not r.pinned and r.expires_at is not None and _ensure_utc(r.expires_at) <= now:
                    continue
                active.append(r)
            return active

        records = await self.db.execute_read(_load)
        if not records:
            return []

        q_tokens = tokenize_for_bm25(query)
        q_emb = compute_text_embedding(query)

        doc_tokens_list = [tokenize_for_bm25(r.text) for r in records]
        total_docs = len(records)
        avg_len = sum(len(dt) for dt in doc_tokens_list) / max(1, total_docs)
        doc_freqs: dict[str, int] = {}
        for dt in doc_tokens_list:
            for tok in set(dt):
                doc_freqs[tok] = doc_freqs.get(tok, 0) + 1

        scored: list[tuple[float, MemoryRecord]] = []
        for rec, d_tokens in zip(records, doc_tokens_list, strict=False):
            bm25 = compute_bm25_score(
                q_tokens,
                d_tokens,
                avg_doc_len=avg_len,
                doc_freqs=doc_freqs,
                total_docs=total_docs,
            )
            sem = (
                cosine_similarity(q_emb, rec.embedding_json or []) if self.chromadb_healthy else 0.0
            )
            pin_boost = 0.15 if rec.pinned else 0.0
            combined = bm25 + (sem * 0.5) + pin_boost
            if combined > 0.0 or rec.pinned or not q_tokens:
                scored.append((combined, rec))

        scored.sort(key=lambda pair: pair[0], reverse=True)
        results: list[dict[str, Any]] = []
        for score, rec in scored[: max(1, limit)]:
            d = _memory_to_dict(rec)
            d["score"] = round(score, 4)
            d["retrieval_mode"] = "semantic+bm25" if self.chromadb_healthy else "bm25_fallback"
            results.append(d)
        return results

    async def list_memories(
        self,
        *,
        user_id: str,
        scope: MemoryScopeLiteral | None = None,
        project_id: str | None = None,
    ) -> list[dict[str, Any]]:
        if not self._enforce_privacy_gate():
            return []
        now = datetime.now(UTC)

        async def _load(sess: AsyncSession) -> list[dict[str, Any]]:
            uow = UnitOfWork(sess)
            rows = await uow.memories.list_for_user(user_id, scope=scope, project_id=project_id)
            return [
                _memory_to_dict(r)
                for r in rows
                if r.pinned or r.expires_at is None or _ensure_utc(r.expires_at) > now
            ]

        return await self.db.execute_read(_load)

    async def delete_memory(self, *, memory_id: str, user_id: str) -> bool:
        async def _tx(sess: AsyncSession) -> bool:
            uow = UnitOfWork(sess)
            rec = await uow.memories.get(memory_id)
            if rec is None or rec.user_id != user_id:
                return False
            await uow.memories.delete(rec)
            return True

        return await self.db.execute_write(_tx)

    async def confirm_memory(
        self, *, memory_id: str, user_id: str, pinned: bool | None = None
    ) -> dict[str, Any]:
        now = datetime.now(UTC)

        async def _tx(sess: AsyncSession) -> dict[str, Any]:
            uow = UnitOfWork(sess)
            rec = await uow.memories.get(memory_id)
            if rec is None or rec.user_id != user_id:
                raise LookupError(f"Memory '{memory_id}' not found")
            rec.confirmed = True
            if pinned is not None:
                rec.pinned = pinned
            rec.updated_at = now
            return _memory_to_dict(rec)

        return await self.db.execute_write(_tx)

    async def propose_memories_from_text(
        self,
        *,
        user_id: str,
        user_text: str,
        chat_id: str | None = None,
        run_id: str | None = None,
        project_id: str | None = None,
    ) -> list[dict[str, Any]]:
        """Extract candidate memories from user turns (opt-in confirm or auto per setting)."""
        if not self._enforce_privacy_gate():
            return []
        triggers = ("i prefer ", "remember that ", "my name is ", "always use ", "our stack is ")
        proposed: list[dict[str, Any]] = []
        for sentence in re.split(r"[.!?\n]+", user_text):
            s = sentence.strip()
            low = s.lower()
            if any(t in low for t in triggers) and 8 <= len(s) <= 500:
                item, _op = await self.save_memory(
                    user_id=user_id,
                    text=s,
                    scope="project" if project_id else "user",
                    project_id=project_id,
                    source_chat_id=chat_id,
                    source_run_id=run_id,
                    confirmed=bool(self.settings.memory_auto_confirm),
                )
                if item is not None:
                    proposed.append(item)
        return proposed

    async def export_memories(self, *, user_id: str) -> dict[str, Any]:
        items = await self.list_memories(user_id=user_id)
        return {
            "version": 1,
            "exported_at": datetime.now(UTC).isoformat(),
            "count": len(items),
            "memories": items,
        }

    async def import_memories(
        self,
        *,
        user_id: str,
        payload: dict[str, Any],
        max_bytes: int = 524_288,
    ) -> list[dict[str, Any]]:
        if not self._enforce_privacy_gate():
            return []
        raw_size = len(json.dumps(payload).encode("utf-8"))
        if raw_size > max_bytes:
            raise ValueError(f"Memory import payload ({raw_size} B) exceeds limit ({max_bytes} B)")
        items = payload.get("memories", [])
        if not isinstance(items, list) or len(items) > 500:
            raise ValueError("Memory import must contain a 'memories' list of at most 500 entries")
        imported: list[dict[str, Any]] = []
        for entry in items:
            if not isinstance(entry, dict):
                continue
            txt = str(entry.get("text", "")).strip()
            if not txt:
                continue
            scope_val: MemoryScopeLiteral = "project" if entry.get("scope") == "project" else "user"
            saved, _ = await self.save_memory(
                user_id=user_id,
                text=txt,
                scope=scope_val,
                project_id=entry.get("project_id"),
                pinned=bool(entry.get("pinned", False)),
                confirmed=True,
            )
            if saved is not None:
                imported.append(saved)
        return imported
