"""Agent Loop execution engine: tool batches, policy, approvals, loop breaker, taint."""

from __future__ import annotations

import asyncio
import json
import time
import uuid
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from typing import Any, Literal

import httpx
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.db import DatabaseManager
from backend.core.models import (
    ApprovalRecord,
    ToolCallRecord,
)
from backend.core.settings import Settings
from backend.core.uow import UnitOfWork, _ensure_utc
from backend.domain.events import (
    ApprovalDecisionLiteral,
    ApprovalScopeLiteral,
    EventTypeLiteral,
    RenderHintLiteral,
    ToolRiskLiteral,
)
from backend.domain.memory.service import MemoryService
from backend.domain.skills.service import SkillService
from backend.domain.tools.policy import (
    PolicyDecision,
    RunModeLiteral,
    ToolDefinition,
    ToolPolicyEngine,
)
from backend.domain.tools.provenance import (
    ProvenanceTag,
    RunTaintTracker,
    wrap_untrusted_with_delimiter,
)
from backend.domain.tools.registry import (
    RegisteredTool,
    ToolExecutionContext,
    ToolExecutionOutput,
    ToolRegistry,
    persist_and_truncate_tool_output,
)
from backend.mcp.manager import McpClientManager

EmitEventFn = Callable[[EventTypeLiteral, dict[str, Any]], Awaitable[None]]


@dataclass
class ProposedToolCall:
    """Normalized tool call proposed by a model step (either native or text-fenced)."""

    call_id: str
    name: str
    args: dict[str, Any]


@dataclass
class LoopBreakerState:
    """Tracks repeated identical tool calls within a run to break infinite loops."""

    threshold: int = 3
    call_counts: dict[str, int] = field(default_factory=dict)
    failure_history: list[str] = field(default_factory=list)
    triggered: bool = False
    trigger_summary: str = ""

    def record_call(self, name: str, args: dict[str, Any], *, ok: bool, summary: str) -> str | None:
        """Record a call and return an optional nudge or set `triggered=True` on threshold."""
        canonical_args = json.dumps(args, sort_keys=True, default=str)
        sig = f"{name}:{canonical_args}"
        count = self.call_counts.get(sig, 0) + 1
        self.call_counts[sig] = count
        if not ok:
            self.failure_history.append(f"{name}({canonical_args[:120]}) -> {summary}")

        if count >= self.threshold:
            self.triggered = True
            recent_fails = "; ".join(self.failure_history[-3:]) or summary
            self.trigger_summary = (
                f"I'm stuck: tool '{name}' was called {count} times with identical arguments "
                f"without succeeding. Summary of attempts: {recent_fails}"
            )
            return self.trigger_summary

        if count == self.threshold - 1:
            return (
                f"[Loop Breaker Nudge]: You have called '{name}' with identical arguments "
                f"{count} times. Do not repeat the exact same call again; adapt your parameters "
                "or summarize progress for the user."
            )
        return None


def approval_to_dict(rec: ApprovalRecord) -> dict[str, Any]:
    return {
        "id": rec.id,
        "run_id": rec.run_id,
        "chat_id": rec.chat_id,
        "user_id": rec.user_id,
        "tool_call_id": rec.tool_call_id,
        "tool_name": rec.tool_name,
        "args": rec.args_json,
        "risk": rec.risk,
        "reason": rec.reason,
        "explain_text": rec.explain_text,
        "suggested_pattern": rec.suggested_pattern,
        "tainted_source": rec.tainted_source,
        "spoof_warnings": rec.spoof_warnings_json or [],
        "status": rec.status,
        "decision": rec.decision,
        "scope": rec.scope,
        "pattern": rec.pattern,
        "decided_by": rec.decided_by,
        "requested_at": _ensure_utc(rec.requested_at).isoformat(),
        "expires_at": _ensure_utc(rec.expires_at).isoformat() if rec.expires_at else None,
        "decided_at": _ensure_utc(rec.decided_at).isoformat() if rec.decided_at else None,
    }


def tool_call_to_dict(rec: ToolCallRecord) -> dict[str, Any]:
    return {
        "id": rec.id,
        "run_id": rec.run_id,
        "name": rec.name,
        "args": rec.args_json,
        "risk": rec.risk,
        "policy_decision": rec.policy_decision,
        "policy_reason": rec.policy_reason,
        "approval_id": rec.approval_id,
        "status": rec.status,
        "output_ref": rec.output_ref,
        "output_bytes": rec.output_bytes,
        "truncated": rec.truncated,
        "render_hint": rec.render_hint,
        "summary": rec.summary,
        "duration_ms": rec.duration_ms,
        "started_at": _ensure_utc(rec.started_at).isoformat() if rec.started_at else None,
        "finished_at": _ensure_utc(rec.finished_at).isoformat() if rec.finished_at else None,
        "created_at": _ensure_utc(rec.created_at).isoformat(),
    }


async def load_effective_allow_patterns(
    db: DatabaseManager,
    *,
    user_id: str,
    run_id: str,
    chat_id: str,
    base_allow_patterns: list[str] | None = None,
) -> list[str]:
    """Load structured approval rules matching `always`, this `chat_id`, or this `run_id`."""

    async def _load(sess: AsyncSession) -> list[str]:
        uow = UnitOfWork(sess)
        rules = await uow.approvals.list_rules_for_user(user_id)
        matched: list[str] = list(base_allow_patterns or [])
        for r in rules:
            if r.scope == "always":
                matched.append(r.pattern)
            elif r.scope == "chat" and r.scope_target_id == chat_id:
                matched.append(r.pattern)
            elif r.scope == "run" and r.scope_target_id == run_id:
                matched.append(r.pattern)
        return matched

    return await db.execute_read(_load)


async def execute_agent_tool_batch(
    *,
    proposed_calls: list[ProposedToolCall],
    run_id: str,
    chat_id: str,
    user_id: str,
    user_privileges: frozenset[str],
    settings: Settings,
    db: DatabaseManager,
    tool_registry: ToolRegistry,
    policy_engine: ToolPolicyEngine,
    taint_tracker: RunTaintTracker,
    loop_breaker: LoopBreakerState,
    emit_event: EmitEventFn,
    set_run_status_db: Callable[[str, str], Awaitable[None]],
    wait_for_approval_fn: Callable[[str, float], Awaitable[dict[str, Any] | None]],
    register_pgid_fn: Callable[[str, int], Awaitable[None]],
    cancel_event: asyncio.Event,
    step_index_ref: list[int],
    preset_allowed_tools: set[str] | None = None,
    run_mode: RunModeLiteral = "interactive",
    memory_service: MemoryService | None = None,
    skill_service: SkillService | None = None,
    mcp_manager: McpClientManager | None = None,
    on_discover_tools: Callable[[list[str]], None] | None = None,
    spawn_subagent_fn: Callable[[dict[str, Any]], Awaitable[dict[str, Any]]] | None = None,
    http_transport: httpx.AsyncBaseTransport | None = None,
    resolve_dns: bool = True,
    accumulated_parts: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    """Evaluate policy, handle approvals, and run a batch of tool calls."""
    observations: list[dict[str, Any]] = []
    auto_read_batch: list[tuple[ProposedToolCall, RegisteredTool, PolicyDecision]] = []
    auto_serial_batch: list[tuple[ProposedToolCall, RegisteredTool, PolicyDecision]] = []
    ask_queue: list[tuple[ProposedToolCall, RegisteredTool, PolicyDecision]] = []

    allow_pats = await load_effective_allow_patterns(
        db,
        user_id=user_id,
        run_id=run_id,
        chat_id=chat_id,
        base_allow_patterns=policy_engine.allow_patterns,
    )
    active_engine = ToolPolicyEngine(
        risk_modes=dict(policy_engine.risk_modes),
        allow_patterns=allow_pats,
        deny_patterns=list(policy_engine.deny_patterns),
    )

    sem = asyncio.Semaphore(max(1, settings.agent_max_parallel_read_tools))

    async def _run_single_approved(
        pcall: ProposedToolCall,
        reg_tool: RegisteredTool,
        *,
        use_semaphore: bool,
    ) -> dict[str, Any]:
        if use_semaphore:
            async with sem:
                return await _execute_one_tool_call(
                    pcall=pcall,
                    reg_tool=reg_tool,
                    run_id=run_id,
                    chat_id=chat_id,
                    user_id=user_id,
                    user_privileges=user_privileges,
                    settings=settings,
                    db=db,
                    taint_tracker=taint_tracker,
                    loop_breaker=loop_breaker,
                    emit_event=emit_event,
                    register_pgid_fn=register_pgid_fn,
                    cancel_event=cancel_event,
                    step_index_ref=step_index_ref,
                    memory_service=memory_service,
                    skill_service=skill_service,
                    mcp_manager=mcp_manager,
                    on_discover_tools=on_discover_tools,
                    spawn_subagent_fn=spawn_subagent_fn,
                    http_transport=http_transport,
                    resolve_dns=resolve_dns,
                )
        return await _execute_one_tool_call(
            pcall=pcall,
            reg_tool=reg_tool,
            run_id=run_id,
            chat_id=chat_id,
            user_id=user_id,
            user_privileges=user_privileges,
            settings=settings,
            db=db,
            taint_tracker=taint_tracker,
            loop_breaker=loop_breaker,
            emit_event=emit_event,
            register_pgid_fn=register_pgid_fn,
            cancel_event=cancel_event,
            step_index_ref=step_index_ref,
            memory_service=memory_service,
            skill_service=skill_service,
            mcp_manager=mcp_manager,
            on_discover_tools=on_discover_tools,
            spawn_subagent_fn=spawn_subagent_fn,
            http_transport=http_transport,
            resolve_dns=resolve_dns,
        )

    # Phase 1: Propose every call and partition into deny / auto / ask
    for pcall in proposed_calls:
        if cancel_event.is_set():
            raise asyncio.CancelledError()

        reg_tool = tool_registry.get(pcall.name)
        if reg_tool is None and mcp_manager is not None and pcall.name.startswith("mcp__"):
            reg_tool = await _build_dynamic_mcp_tool(pcall.name, mcp_manager)

        tool_def = (
            reg_tool.definition
            if reg_tool is not None
            else ToolDefinition(
                name=pcall.name,
                risk="exec",
                required_privilege="admin",
                default_approval="deny",
                enabled=False,
            )
        )

        await emit_event(
            "tool.call.proposed",
            {
                "call_id": pcall.call_id,
                "name": pcall.name,
                "args": pcall.args,
                "risk": tool_def.risk,
            },
        )
        if accumulated_parts is not None:
            accumulated_parts.append(
                {
                    "type": "tool_call",
                    "call_id": pcall.call_id,
                    "tool": pcall.name,
                    "args": pcall.args,
                }
            )

        decision = (
            active_engine.evaluate(
                tool_def,
                pcall.args,
                user_privileges=user_privileges,
                tainted_source=taint_tracker.primary_taint_source,
                preset_allowed_tools=preset_allowed_tools,
                run_mode=run_mode,
            )
            if reg_tool is not None
            else PolicyDecision(
                decision="deny",
                reason=f"Unknown tool '{pcall.name}'",
                tainted_by_untrusted_source=taint_tracker.primary_taint_source,
            )
        )

        now = datetime.now(UTC)

        async def _save_tc(
            sess: AsyncSession,
            cid: str = pcall.call_id,
            tname: str = pcall.name,
            targs: dict[str, Any] = pcall.args,
            trisk: str = tool_def.risk,
            pdec: str = decision.decision,
            preason: str = decision.reason,
            now_dt: datetime = now,
        ) -> None:
            uow = UnitOfWork(sess)
            await uow.tool_calls.upsert(
                ToolCallRecord(
                    id=cid,
                    run_id=run_id,
                    name=tname,
                    args_json=targs,
                    risk=trisk,
                    policy_decision=pdec,
                    policy_reason=preason,
                    status="proposed",
                    created_at=now_dt,
                )
            )

        await db.execute_write(_save_tc)

        if decision.decision == "deny":
            await _record_denied_tool_call(
                db=db,
                emit_event=emit_event,
                run_id=run_id,
                user_id=user_id,
                pcall=pcall,
                reason=decision.reason,
            )
            nudge = loop_breaker.record_call(
                pcall.name, pcall.args, ok=False, summary=f"Denied: {decision.reason}"
            )
            obs_txt = f"[Tool Call Denied ({pcall.name})]: {decision.reason}"
            if nudge:
                obs_txt = f"{obs_txt}\n{nudge}"
            observations.append({"role": "tool", "tool_call_id": pcall.call_id, "content": obs_txt})
            if loop_breaker.triggered:
                return observations
            continue

        assert reg_tool is not None
        if decision.decision == "ask":
            ask_queue.append((pcall, reg_tool, decision))
        elif reg_tool.definition.risk == "read" and pcall.name != "spawn_agent":
            auto_read_batch.append((pcall, reg_tool, decision))
        else:
            auto_serial_batch.append((pcall, reg_tool, decision))

    # Phase 2: Execute auto-approved read-only calls in bounded parallel immediately
    if len(auto_read_batch) > 1:
        parallel_obs = await asyncio.gather(
            *[
                _run_single_approved(pcall, reg_tool, use_semaphore=True)
                for pcall, reg_tool, _ in auto_read_batch
            ]
        )
        observations.extend(parallel_obs)
    elif len(auto_read_batch) == 1:
        pcall, reg_tool, _ = auto_read_batch[0]
        observations.append(await _run_single_approved(pcall, reg_tool, use_semaphore=False))

    if loop_breaker.triggered:
        return observations

    # Phase 3: Execute auto-approved serial calls
    for pcall, reg_tool, _ in auto_serial_batch:
        if cancel_event.is_set():
            raise asyncio.CancelledError()
        # Re-check taint escalation if a prior read call tainted the turn!
        if taint_tracker.primary_taint_source is not None and reg_tool.definition.risk in (
            "write",
            "exec",
            "network",
            "admin",
        ):
            re_dec = active_engine.evaluate(
                reg_tool.definition,
                pcall.args,
                user_privileges=user_privileges,
                tainted_source=taint_tracker.primary_taint_source,
                preset_allowed_tools=preset_allowed_tools,
                run_mode=run_mode,
            )
            if re_dec.decision == "ask":
                ask_queue.append((pcall, reg_tool, re_dec))
                continue
        obs = await _run_single_approved(pcall, reg_tool, use_semaphore=False)
        observations.append(obs)
        if loop_breaker.triggered:
            return observations

    # Phase 4: Prompt and execute ask-queued calls sequentially
    for pcall, reg_tool, decision in ask_queue:
        if cancel_event.is_set():
            raise asyncio.CancelledError()
        tool_def = reg_tool.definition
        card = reg_tool.explain(pcall.args)
        approval_id = f"apr_{uuid.uuid4().hex[:16]}"
        timeout_sec = (
            settings.agent_background_approval_timeout_seconds
            if run_mode == "background"
            else settings.agent_approval_timeout_seconds
        )
        now = datetime.now(UTC)
        expires_at = now + timedelta(seconds=timeout_sec)

        async def _save_apr(
            sess: AsyncSession,
            aid: str = approval_id,
            cid: str = pcall.call_id,
            tname: str = pcall.name,
            norm_args: dict[str, Any] = card.normalized_args,
            trisk: str = tool_def.risk,
            preason: str = decision.reason,
            exp_txt: str = card.explain_text,
            sug_pat: str = decision.suggested_pattern,
            taint_src: str | None = decision.tainted_by_untrusted_source,
            warnings: list[str] = card.spoof_warnings,
            now_dt: datetime = now,
            exp_dt: datetime = expires_at,
        ) -> None:
            uow = UnitOfWork(sess)
            await uow.approvals.add(
                ApprovalRecord(
                    id=aid,
                    run_id=run_id,
                    chat_id=chat_id,
                    user_id=user_id,
                    tool_call_id=cid,
                    tool_name=tname,
                    args_json=norm_args,
                    risk=trisk,
                    reason=preason,
                    explain_text=exp_txt,
                    suggested_pattern=sug_pat,
                    tainted_source=taint_src,
                    spoof_warnings_json=warnings,
                    status="pending",
                    requested_at=now_dt,
                    expires_at=exp_dt,
                )
            )
            tc = await uow.tool_calls.get(cid)
            if tc is not None:
                tc.approval_id = aid
                tc.status = "waiting_approval"

        await set_run_status_db(run_id, "waiting_approval")
        await db.execute_write(_save_apr)
        await emit_event(
            "tool.approval.requested",
            {
                "approval_id": approval_id,
                "call_id": pcall.call_id,
                "reason": f"{decision.reason} — {card.explain_text}",
                "suggested_pattern": decision.suggested_pattern or f"tool:{pcall.name}",
                "expires_at": expires_at.isoformat(),
            },
        )
        await emit_event("run.status", {"status": "waiting_approval"})

        resolved = await wait_for_approval_fn(approval_id, timeout_sec)
        await set_run_status_db(run_id, "running")
        await emit_event("run.status", {"status": "running"})

        if resolved is None or resolved.get("decision") != "approve":
            deny_reason = (
                str(resolved.get("reason") or "Denied by user")
                if resolved is not None
                else "Approval request timed out"
            )
            await _record_denied_tool_call(
                db=db,
                emit_event=emit_event,
                run_id=run_id,
                user_id=user_id,
                pcall=pcall,
                reason=deny_reason,
            )
            nudge = loop_breaker.record_call(
                pcall.name, pcall.args, ok=False, summary=f"Denied: {deny_reason}"
            )
            obs_txt = f"[Tool Call Denied ({pcall.name})]: {deny_reason}"
            if nudge:
                obs_txt = f"{obs_txt}\n{nudge}"
            observations.append({"role": "tool", "tool_call_id": pcall.call_id, "content": obs_txt})
            if loop_breaker.triggered:
                return observations
            continue

        obs = await _run_single_approved(pcall, reg_tool, use_semaphore=False)
        observations.append(obs)
        if loop_breaker.triggered:
            break

    return observations


async def _execute_one_tool_call(
    *,
    pcall: ProposedToolCall,
    reg_tool: RegisteredTool,
    run_id: str,
    chat_id: str,
    user_id: str,
    user_privileges: frozenset[str],
    settings: Settings,
    db: DatabaseManager,
    taint_tracker: RunTaintTracker,
    loop_breaker: LoopBreakerState,
    emit_event: EmitEventFn,
    register_pgid_fn: Callable[[str, int], Awaitable[None]],
    cancel_event: asyncio.Event,
    step_index_ref: list[int],
    memory_service: MemoryService | None,
    skill_service: SkillService | None,
    mcp_manager: McpClientManager | None,
    on_discover_tools: Callable[[list[str]], None] | None,
    spawn_subagent_fn: Callable[[dict[str, Any]], Awaitable[dict[str, Any]]] | None,
    http_transport: httpx.AsyncBaseTransport | None,
    resolve_dns: bool,
) -> dict[str, Any]:
    step_idx = step_index_ref[0]
    step_index_ref[0] += 1
    step_id = f"step_{run_id}_tool_{pcall.call_id}"
    step_kind: Literal["tool", "subagent"] = "subagent" if pcall.name == "spawn_agent" else "tool"

    await emit_event(
        "step.started",
        {"step_id": step_id, "index": step_idx, "kind": step_kind},
    )
    await emit_event("tool.started", {"call_id": pcall.call_id})

    start_dt = datetime.now(UTC)
    start_mono = time.perf_counter()

    async def _mark_running(sess: AsyncSession) -> None:
        uow = UnitOfWork(sess)
        tc = await uow.tool_calls.get(pcall.call_id)
        if tc is not None:
            tc.status = "running"
            tc.started_at = start_dt

    await db.execute_write(_mark_running)

    async def _on_delta(stream: Literal["stdout", "stderr", "log"], text: str) -> None:
        await emit_event(
            "tool.output.delta",
            {"call_id": pcall.call_id, "stream": stream, "text": text},
        )

    async def _on_pgid(pgid: int) -> None:
        await register_pgid_fn(pcall.call_id, pgid)

    ctx = ToolExecutionContext(
        run_id=run_id,
        chat_id=chat_id,
        user_id=user_id,
        call_id=pcall.call_id,
        user_privileges=user_privileges,
        settings=settings,
        db=db,
        memory_service=memory_service,
        skill_service=skill_service,
        mcp_manager=mcp_manager,
        cancel_event=cancel_event,
        emit_event=emit_event,
        on_output_delta=_on_delta,
        on_pgid_started=_on_pgid,
        on_discover_tools=on_discover_tools,
        spawn_subagent_fn=spawn_subagent_fn,
        http_transport=http_transport,
        resolve_dns=resolve_dns,
    )

    try:
        timeout_sec = min(
            reg_tool.definition.timeout_seconds,
            settings.tool_default_timeout_seconds,
        )
        out = await asyncio.wait_for(
            reg_tool.handler(ctx, pcall.args),
            timeout=max(1.0, timeout_sec + 2.0),
        )
    except asyncio.CancelledError:
        raise
    except Exception as exc:
        out = ToolExecutionOutput(
            ok=False,
            summary=f"Error in {pcall.name}: {exc}",
            full_output=f"Error executing {pcall.name}: {exc}",
            render_hint="text",
        )

    dur_ms = max(0, int((time.perf_counter() - start_mono) * 1000))
    persisted = persist_and_truncate_tool_output(
        settings.data_dir,
        pcall.call_id,
        out.full_output,
        max_model_bytes=settings.tool_model_view_bytes,
        already_truncated=out.truncated_by_tool,
        owner_user_id=user_id,
    )

    # Record untrusted provenance taint and wrap untrusted output in randomized delimiters
    model_facing = persisted.model_view
    if out.provenance.is_untrusted:
        taint_tracker.record_source(out.provenance)
        model_facing = wrap_untrusted_with_delimiter(
            model_facing,
            source=out.provenance.source,
            run_nonce=taint_tracker.run_nonce,
        )

    for ev_type, ev_data in out.extra_events:
        await emit_event(ev_type, ev_data)

    await emit_event(
        "tool.result",
        {
            "call_id": pcall.call_id,
            "ok": out.ok,
            "summary": out.summary,
            "output_ref": persisted.output_ref,
            "truncated": persisted.truncated,
            "duration_ms": dur_ms,
            "render_hint": out.render_hint,
        },
    )
    await emit_event(
        "step.finished",
        {
            "step_id": step_id,
            "status": "completed" if out.ok else "failed",
            "duration_ms": dur_ms,
        },
    )

    fin_dt = datetime.now(UTC)

    async def _mark_done(sess: AsyncSession) -> None:
        uow = UnitOfWork(sess)
        tc = await uow.tool_calls.get(pcall.call_id)
        if tc is not None:
            tc.status = "completed" if out.ok else "failed"
            tc.output_ref = persisted.output_ref
            tc.output_bytes = persisted.output_bytes
            tc.truncated = persisted.truncated
            tc.render_hint = out.render_hint
            tc.summary = out.summary
            tc.model_view_text = model_facing
            tc.duration_ms = dur_ms
            tc.finished_at = fin_dt

    await db.execute_write(_mark_done)

    nudge = loop_breaker.record_call(pcall.name, pcall.args, ok=out.ok, summary=out.summary)
    if nudge:
        model_facing = f"{model_facing}\n\n{nudge}"
    if loop_breaker.triggered:
        await emit_event(
            "notice",
            {
                "level": "warning",
                "code": "loop_breaker_triggered",
                "text": loop_breaker.trigger_summary,
            },
        )

    return {
        "role": "tool",
        "tool_call_id": pcall.call_id,
        "content": model_facing,
    }


async def _record_denied_tool_call(
    *,
    db: DatabaseManager,
    emit_event: EmitEventFn,
    run_id: str,
    user_id: str,
    pcall: ProposedToolCall,
    reason: str,
) -> None:
    now = datetime.now(UTC)

    async def _tx(sess: AsyncSession) -> None:
        uow = UnitOfWork(sess)
        tc = await uow.tool_calls.get(pcall.call_id)
        if tc is not None:
            tc.status = "denied"
            tc.policy_reason = reason
            tc.summary = f"Denied: {reason}"
            tc.finished_at = now
        await uow.audit.record(
            action="tool.denied",
            resource_type="tool_call",
            resource_id=pcall.call_id,
            actor_user_id=user_id,
            details={
                "run_id": run_id,
                "tool": pcall.name,
                "reason": reason,
            },
        )

    await db.execute_write(_tx)
    await emit_event(
        "tool.denied",
        {"call_id": pcall.call_id, "reason": reason},
    )


async def _build_dynamic_mcp_tool(
    qualified_name: str,
    mcp_manager: McpClientManager,
) -> RegisteredTool | None:
    """Resolve `mcp__<server>__<tool>` into a RegisteredTool wrapping `mcp_manager.call_tool`."""
    parts = qualified_name.split("__", 2)
    if len(parts) != 3:
        return None
    _, server_name, raw_tool_name = parts
    servers = await mcp_manager.list_servers()
    target_srv = next((s for s in servers if s["name"] == server_name), None)
    if target_srv is None:
        return None
    disc = next(
        (t for t in target_srv.get("discovered_tools", []) if t.get("name") == raw_tool_name),
        None,
    )
    risk_raw = str((disc or {}).get("risk", "exec"))
    risk_lit: ToolRiskLiteral = (
        risk_raw  # type: ignore[assignment]
        if risk_raw in ("read", "write", "exec", "network", "admin")
        else "exec"
    )
    desc = str((disc or {}).get("description", f"MCP tool {raw_tool_name} on {server_name}"))

    from pydantic import BaseModel, ConfigDict

    class DynamicMcpArgs(BaseModel):
        model_config = ConfigDict(extra="allow")

    async def _handler(ctx: ToolExecutionContext, args: dict[str, Any]) -> ToolExecutionOutput:
        assert ctx.mcp_manager is not None
        res = await ctx.mcp_manager.call_tool(
            server_name=server_name,
            tool_name=raw_tool_name,
            arguments=args,
        )
        out_str = str(res.get("output", ""))
        return ToolExecutionOutput(
            ok=not bool(res.get("is_error")),
            summary=f"MCP {server_name}.{raw_tool_name} completed: {out_str[:120]}",
            full_output=out_str,
            render_hint="text",
            provenance=ProvenanceTag(
                source=str(res.get("provenance_source", f"mcp:{server_name}:{raw_tool_name}")),
                trust="untrusted",
            ),
        )

    return RegisteredTool(
        definition=ToolDefinition(
            name=qualified_name,
            risk=risk_lit,
            required_privilege="agent",
            default_approval="auto" if risk_lit == "read" else "ask",
            description=desc,
            render_hint="text",
            enabled=bool(target_srv.get("enabled", False)),
        ),
        args_schema=DynamicMcpArgs,
        handler=_handler,
        explain_fn=lambda a: f"Invoke MCP tool '{raw_tool_name}' on server '{server_name}': {a}",
    )


__all__ = [
    "ApprovalDecisionLiteral",
    "ApprovalScopeLiteral",
    "LoopBreakerState",
    "ProposedToolCall",
    "RenderHintLiteral",
    "approval_to_dict",
    "execute_agent_tool_batch",
    "load_effective_allow_patterns",
    "tool_call_to_dict",
]
