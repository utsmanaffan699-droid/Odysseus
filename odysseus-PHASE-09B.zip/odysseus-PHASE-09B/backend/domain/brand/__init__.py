"""Branded non-app surfaces: email templates and export metadata."""

from backend.domain.brand.email import render_transactional_email

__all__ = ["render_transactional_email"]
