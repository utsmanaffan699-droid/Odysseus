"""Offline-safe transactional email templates with HTML and plain-text variants."""

from __future__ import annotations

import html
from dataclasses import dataclass
from typing import Literal

from backend.core.brand import brand_value, load_brand_config

EmailKind = Literal["invite", "two_factor", "digest", "backup_failure"]


@dataclass(frozen=True)
class RenderedEmail:
    subject: str
    html: str
    text: str


def render_transactional_email(
    kind: EmailKind,
    *,
    recipient_name: str = "there",
    action_url: str = "",
    detail: str = "",
) -> RenderedEmail:
    """Render a constrained-client-safe email with no remote assets or tracking pixels."""
    cfg = load_brand_config()
    name = brand_value("productName", "PRODUCT_NAME")
    primary = str(cfg.get("brand", {}).get("primary", "#3F6D68"))
    secondary = str(cfg.get("brand", {}).get("secondary", "#D38B5D"))
    safe_name = html.escape(recipient_name)
    safe_detail = html.escape(detail)
    safe_url = html.escape(action_url, quote=True)
    content: dict[EmailKind, tuple[str, str, str]] = {
        "invite": ("You have been invited", "Open your workspace invitation", "Open invitation"),
        "two_factor": ("Your verification code", "Complete two-factor verification", "Continue verification"),
        "digest": ("Your workspace digest", "A summary of activity in your workspace", "Open workspace"),
        "backup_failure": ("Backup needs attention", "A workspace backup needs attention", "Review backup"),
    }
    subject, heading, button = content[kind]
    text = f"{name}\n\nHello {recipient_name},\n\n{heading}."
    if detail:
        text += f"\n\n{detail}"
    if action_url:
        text += f"\n\n{button}: {action_url}"
    text += f"\n\n{cfg.get('legalLine', 'Self-hosted software for your work, your data, your decisions.')}"
    link = f'<p><a href="{safe_url}" style="display:inline-block;background:{primary};color:#fff;padding:12px 18px;border-radius:8px;text-decoration:none">{html.escape(button)}</a></p>' if action_url else ""
    rendered = f'''<!doctype html><html lang="en"><body style="margin:0;background:#f5f2eb;color:#172522;font-family:Arial,sans-serif"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f5f2eb"><tr><td align="center" style="padding:28px 12px"><table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;background:#fcfaf6;border-top:5px solid {primary}"><tr><td style="padding:24px"><p style="margin:0;color:{primary};font-weight:bold;letter-spacing:.04em">{html.escape(name)}</p><h1 style="font-family:Georgia,serif;font-weight:normal">{html.escape(heading)}</h1><p>Hello {safe_name},</p>{f'<p>{safe_detail}</p>' if detail else ''}{link}<p style="color:{secondary};font-size:12px">{html.escape(str(cfg.get('legalLine', 'Self-hosted software for your work, your data, your decisions.')))}</p></td></tr></table></td></tr></table></body></html>'''
    return RenderedEmail(subject=f"{name}: {subject}", html=rendered, text=text)
