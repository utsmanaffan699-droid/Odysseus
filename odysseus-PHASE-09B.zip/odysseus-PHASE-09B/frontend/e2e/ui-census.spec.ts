import { expect, test } from "@playwright/test";

const matrix = [
  { name: "mobile", width: 390, height: 844 },
  { name: "tablet", width: 768, height: 1024 },
  { name: "laptop", width: 1440, height: 900 },
  { name: "wide", width: 1920, height: 1080 },
];
const themes = ["light", "dark", "high-contrast"];
const locales = ["en", "id", "en-XA"];

test("deterministic UI census", async ({ page }) => {
  test.setTimeout(120_000);
  await page.goto("/");
  await expect(page.locator("main")).toBeVisible();
  const bootstrapPassword = process.env.ODYSSEUS_TEST_ADMIN_PASSWORD;
  if (bootstrapPassword) {
    await page.getByLabel(/username/i).fill("admin");
    await page.getByLabel(/password/i).fill(bootstrapPassword);
    await page.getByTestId("login-submit").click();
    await expect(page.getByTestId("password-change-form")).toBeVisible();
    await page.getByLabel(/current password/i).fill(bootstrapPassword);
    await page.getByLabel(/new password/i).fill("OdysseusCensus!2026");
    await page.getByTestId("password-change-submit").click();
    await expect(page.getByTestId("authenticated-view")).toBeVisible();
  }
  for (const viewport of matrix) {
    await page.setViewportSize({ width: viewport.width, height: viewport.height });
    for (const theme of themes) {
      await page.evaluate((value) => { document.documentElement.dataset.theme = value; }, theme);
      for (const locale of locales) {
        await page.evaluate((value) => { document.documentElement.lang = value; }, locale);
        await page.screenshot({
          path: `../docs/ui-audit/census/home/success/${viewport.name}-${theme}-${locale}.png`,
          fullPage: true,
          animations: "disabled",
        });
      }
    }
  }

  // Authenticated route census: every registered workspace gets a deterministic
  // evidence image in the canonical laptop/light/en state. This prevents the
  // audit from claiming route coverage based only on the boot surface.
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.evaluate(() => { document.documentElement.dataset.theme = "light"; document.documentElement.lang = "en"; });
  const workspaceIds = [
    "chat", "mail", "notes", "calendar", "schedules", "docs", "research", "compare",
    "memory", "skills", "mcp", "projects", "cookbook", "gallery", "voice", "admin",
    "settings", "providers", "storybook",
  ];
  for (const workspaceId of workspaceIds) {
    await page.getByTestId(`workspace-nav-${workspaceId}`).click();
    await expect(page.getByTestId("authenticated-view")).toBeVisible();
    await page.screenshot({
      path: `../docs/ui-audit/census/workspaces/${workspaceId}/success/laptop-light-en.png`,
      fullPage: true,
      animations: "disabled",
    });
  }
});
