import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  build: {
    outDir: "dist",
    sourcemap: false,
    target: "es2022",
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (id.includes("shikiHighlighter")) return "lazy-shiki";
          if (id.includes("katexRenderer")) return "lazy-katex";
          if (id.includes("mermaidRenderer")) return "lazy-mermaid";
          if (id.includes("codemirrorEditor")) return "lazy-codemirror";
          if (id.includes("StorybookCatalog")) return "lazy-storybook";
          if (id.includes("SettingsAndProvidersView")) return "lazy-settings";
          if (id.includes("ArtifactsCanvasPanel")) return "lazy-artifacts";
          if (id.includes("RunHistoryAndPresetsView")) return "lazy-agent-hub";
          return undefined;
        },
      },
    },
  },
  server: {
    host: "0.0.0.0",
    allowedHosts: true,
    port: 5173,
    proxy: {
      "/api": "http://127.0.0.1:8000",
      "/metrics": "http://127.0.0.1:8000",
    },
  },
});
