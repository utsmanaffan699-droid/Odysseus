export interface ThinkingChunk {
  readonly type: "thinking" | "text";
  readonly text: string;
}

/**
 * Streaming parser for local-model <think> output. Callers must pass only
 * assistant-origin text; tool, web, memory, and user content are never parsed.
 * Tags are treated literally when they occur in non-assistant content.
 */
export class AssistantThinkingParser {
  private buffer = "";
  private inside = false;

  push(chunk: string): ThinkingChunk[] {
    this.buffer += chunk;
    const out: ThinkingChunk[] = [];
    while (this.buffer.length > 0) {
      const lower = this.buffer.toLowerCase();
      const open = lower.indexOf("<think>");
      const close = lower.indexOf("</think>");
      if (!this.inside) {
        if (open >= 0) {
          const text = this.buffer.slice(0, open);
          if (text) out.push({ type: "text", text });
          this.buffer = this.buffer.slice(open + 7);
          this.inside = true;
          continue;
        }
        const keep = this.partialTagSuffix(this.buffer, "<think>");
        const text = this.buffer.slice(0, this.buffer.length - keep);
        if (text) out.push({ type: "text", text });
        this.buffer = this.buffer.slice(this.buffer.length - keep);
        break;
      }
      if (close >= 0) {
        const text = this.buffer.slice(0, close);
        if (text) out.push({ type: "thinking", text });
        this.buffer = this.buffer.slice(close + 8);
        this.inside = false;
        continue;
      }
      const keep = this.partialTagSuffix(this.buffer, "</think>");
      const text = this.buffer.slice(0, this.buffer.length - keep);
      if (text) out.push({ type: "thinking", text });
      this.buffer = this.buffer.slice(this.buffer.length - keep);
      break;
    }
    return out;
  }

  finish(): ThinkingChunk[] {
    const out: ThinkingChunk[] = [];
    if (this.buffer) out.push({ type: this.inside ? "thinking" : "text", text: this.buffer });
    this.buffer = "";
    this.inside = false;
    return out;
  }

  private partialTagSuffix(value: string, tag: string): number {
    const lower = value.toLowerCase();
    const wanted = tag.toLowerCase();
    for (let n = Math.min(value.length, wanted.length - 1); n > 0; n -= 1) {
      if (lower.endsWith(wanted.slice(0, n))) return n;
    }
    return 0;
  }
}

export function parseAssistantThinking(text: string): ThinkingChunk[] {
  const parser = new AssistantThinkingParser();
  return [...parser.push(text), ...parser.finish()];
}
