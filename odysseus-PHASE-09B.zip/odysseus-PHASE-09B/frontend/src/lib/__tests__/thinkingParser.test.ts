import { describe, expect, it } from "vitest";
import { AssistantThinkingParser, parseAssistantThinking } from "../thinkingParser";

describe("assistant thinking parser", () => {
  it("parses tags split across chunks", () => {
    const p = new AssistantThinkingParser();
    const chunks = [p.push("before <thi"), p.push("nk>plan"), p.push("</think> after"), p.finish()].flat();
    expect(chunks).toEqual([
      { type: "text", text: "before " },
      { type: "thinking", text: "plan" },
      { type: "text", text: " after" },
    ]);
  });

  it("treats unclosed thinking as an incomplete thinking chunk", () => {
    expect(parseAssistantThinking("<think>partial")).toEqual([{ type: "thinking", text: "partial" }]);
  });

  it("does not parse untrusted content when caller keeps it outside the parser", () => {
    const toolOutput = "tool output <think>not model reasoning</think>";
    expect([{ type: "text", text: toolOutput }]).not.toContainEqual(
      expect.objectContaining({ type: "thinking" }),
    );
  });
});
