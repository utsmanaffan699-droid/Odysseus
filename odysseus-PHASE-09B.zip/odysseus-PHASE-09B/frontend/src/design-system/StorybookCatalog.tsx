import React, { useState } from "react";
import { ToolCallCard } from "../features/agent/tools/renderers";
import { useAppShellStore } from "../lib/store";
import {
  Badge,
  Button,
  Combobox,
  Dialog,
  Drawer,
  IconButton,
  Input,
  Kbd,
  Menu,
  Popover,
  Progress,
  Select,
  Skeleton,
  Slider,
  Switch,
  Table,
  Tabs,
  Tooltip,
  Tree,
} from "./primitives";

export function StorybookCatalog(): React.ReactElement {
  const { theme, palette, density, setTheme, setPalette, setDensity } = useAppShellStore();
  const [activeTab, setActiveTab] = useState("buttons");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [switchOn, setSwitchOn] = useState(true);
  const [sliderVal, setSliderVal] = useState(64);
  const [comboVal, setComboVal] = useState("fake/default");

  return (
    <section className="odysseus-storybook" aria-label="Design System Storybook" data-testid="storybook-view">
      <header className="odysseus-storybook-header">
        <div>
          <h2>Odysseus Design System Catalog (FE-QA-01)</h2>
          <p>20 Accessible Primitives · Tokens · Light / Dark / High-Contrast · RTL & States</p>
        </div>
        <div className="odysseus-storybook-controls">
          <Select
            id="sb-theme-select"
            label="Theme"
            value={theme}
            onChange={(e) => setTheme(e.target.value as "light" | "dark" | "high-contrast")}
            options={[
              { value: "dark", label: "Dark" },
              { value: "light", label: "Light" },
              { value: "high-contrast", label: "High Contrast" },
            ]}
          />
          <Select
            id="sb-palette-select"
            label="Palette"
            value={palette}
            onChange={(e) => setPalette(e.target.value as "slate" | "amber" | "forest")}
            options={[
              { value: "slate", label: "Odysseus Slate" },
              { value: "amber", label: "Solar Amber" },
              { value: "forest", label: "Emerald Forest" },
            ]}
          />
          <Select
            id="sb-density-select"
            label="Density"
            value={density}
            onChange={(e) => setDensity(e.target.value as "comfortable" | "compact")}
            options={[
              { value: "comfortable", label: "Comfortable" },
              { value: "compact", label: "Compact" },
            ]}
          />
        </div>
      </header>

      <Tabs
        ariaLabel="Storybook Component Categories"
        activeId={activeTab}
        onSelect={setActiveTab}
        tabs={[
          { id: "buttons", label: "Buttons & Badges" },
          { id: "inputs", label: "Inputs & Controls" },
          { id: "overlays", label: "Dialogs & Menus" },
          { id: "data", label: "Tables, Trees & RTL" },
        ]}
      />

      <div className="odysseus-storybook-grid">
        <div className="odysseus-card" data-testid="story-buttons">
          <h3>Buttons, IconButtons, Badges & Kbd</h3>
          <div className="odysseus-row-wrap">
            <Button variant="primary">Primary Default</Button>
            <Button variant="secondary">Secondary</Button>
            <Button variant="danger">Danger</Button>
            <Button variant="ghost">Ghost</Button>
            <Button disabled>Disabled</Button>
            <Button loading>Loading</Button>
            <IconButton label="Bookmark message" active={switchOn}>
              ★
            </IconButton>
          </div>
          <div className="odysseus-row-wrap">
            <Badge variant="default">Default</Badge>
            <Badge variant="success">Ready</Badge>
            <Badge variant="warning">Warning 82%</Badge>
            <Badge variant="danger">Critical 97%</Badge>
            <Tooltip text="Keyboard shortcut">
              <Kbd>Ctrl+K</Kbd>
            </Tooltip>
          </div>
        </div>

        <div className="odysseus-card" data-testid="story-inputs">
          <h3>Input, Select, Combobox, Switch, Slider & Progress</h3>
          <Input id="sb-input-ok" label="Standard Input" defaultValue="Odysseus Agent" />
          <Input
            id="sb-input-err"
            label="Error State Input"
            defaultValue="invalid-url"
            error="Endpoint must start with https:// or http://"
          />
          <Combobox
            label="Filter Models"
            value={comboVal}
            onChange={setComboVal}
            options={[
              { value: "fake/default", label: "Fake Default (128k)" },
              { value: "fake/reasoning", label: "Fake Reasoning (128k)" },
              { value: "fake/small-4k", label: "Fake Small (4k)" },
            ]}
          />
          <div className="odysseus-row-wrap">
            <Switch label="Enable Extended Thinking" checked={switchOn} onChange={setSwitchOn} />
          </div>
          <Slider
            id="sb-slider"
            label="Context Budget %"
            value={sliderVal}
            onChange={setSliderVal}
          />
          <Progress value={sliderVal} label="Upload progress" />
        </div>

        <div className="odysseus-card" data-testid="story-overlays">
          <h3>Dialog, Drawer, Popover, Menu & Skeleton</h3>
          <div className="odysseus-row-wrap">
            <Button variant="secondary" onClick={() => setDialogOpen(true)}>
              Open Dialog
            </Button>
            <Button variant="secondary" onClick={() => setDrawerOpen(true)}>
              Open Drawer
            </Button>
            <Popover triggerLabel="Mode options" triggerContent="Open Popover">
              <p>Popover body content with focus support.</p>
            </Popover>
          </div>
          <Menu
            label="Sample Actions Menu"
            items={[
              { id: "rename", label: "Rename chat", onSelect: () => {} },
              { id: "export", label: "Export Markdown", onSelect: () => {} },
              { id: "delete", label: "Delete chat", danger: true, onSelect: () => {} },
            ]}
          />
          <Skeleton lines={2} />
          <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)}>
            <p>Press Escape or click Close to dismiss.</p>
          </Dialog>
          <Drawer open={drawerOpen} onClose={() => setDrawerOpen(false)}>
            <p>Responsive drawer content.</p>
          </Drawer>
        </div>

        <div className="odysseus-card" data-testid="story-data-rtl">
          <h3>Table, Tree, Long Text & RTL State</h3>
          <Table
            caption="Provider Capabilities"
            headers={["Model", "Window", "Tools"]}
            rows={[
              ["fake/default", "128,000", "Native"],
              ["fake/fenced", "8,192", "Fenced"],
            ]}
          />
          <Tree
            ariaLabel="Workspace File Tree"
            nodes={[
              {
                id: "n1",
                label: "src/",
                children: [
                  { id: "n2", label: "runReducer.ts" },
                  { id: "n3", label: "markdown.ts" },
                ],
              },
            ]}
          />
          <p dir="rtl" className="odysseus-rtl-sample" data-testid="rtl-story-sample">
            مرحبا بالعالم — واجهة المستخدم تدعم اللغة العربية والاتجاه من اليمين إلى اليسار
          </p>
        </div>

        <div className="odysseus-card" data-testid="story-phase05-tools">
          <h3>Phase 05 — Tool Output Renderers (Terminal, Diff & JSON)</h3>
          <ToolCallCard
            toolCall={{
              call_id: "sb_tc_1",
              name: "run_shell",
              args: { command: "pytest -q" },
              risk: "exec",
              status: "completed",
              approval_id: null,
              approval_decision: null,
              stdout: "12 passed in 0.42s",
              stderr: "",
              pct: 100,
              progress_label: "done",
              ok: true,
              summary: "All tests passed",
              truncated: false,
              duration_ms: 420,
              render_hint: "terminal",
            }}
          />
          <ToolCallCard
            toolCall={{
              call_id: "sb_tc_2",
              name: "patch_file",
              args: { path: "src/config.ts" },
              risk: "write",
              status: "completed",
              approval_id: null,
              approval_decision: null,
              stdout: "@@ -1,2 +1,2 @@\n-export const TIMEOUT = 1000;\n+export const TIMEOUT = 5000;",
              stderr: "",
              pct: 100,
              progress_label: "done",
              ok: true,
              summary: "Updated timeout",
              truncated: false,
              duration_ms: 15,
              render_hint: "diff",
            }}
          />
        </div>
      </div>
    </section>
  );
}
