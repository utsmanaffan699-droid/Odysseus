import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useAppShellStore } from "../../lib/store";

export type ProductivityMode = "mail" | "notes" | "calendar" | "schedules";

export interface ProductivityWorkspacesViewProps {
  readonly initialMode?: ProductivityMode;
}

interface MailAccountItem {
  readonly id: string;
  readonly email_address: string;
  readonly display_name: string;
  readonly imap_host: string;
  readonly use_tls: boolean;
  readonly auth_method: string;
  readonly status: string;
  readonly status_reason: string | null;
  readonly secret_masked: string;
}

interface MailMessageItem {
  readonly id: string;
  readonly account_id: string;
  readonly folder: string;
  readonly subject: string;
  readonly sender: string;
  readonly recipients: ReadonlyArray<string>;
  readonly date_iso: string;
  readonly snippet: string;
  readonly body_text: string;
  readonly sanitized_html: string;
  readonly remote_resources_blocked: number;
  readonly spoofed_links_blocked: number;
  readonly unread: boolean;
  readonly snoozed_until: string | null;
  readonly triage: {
    readonly urgency: string;
    readonly tags: ReadonlyArray<string>;
    readonly summary: string;
    readonly draft_reply_id: string | null;
    readonly draft_reply_body: string | null;
    readonly injection_detected: boolean;
    readonly suggest_only: boolean;
  } | null;
}

interface NoteRecord {
  readonly id: string;
  readonly title: string;
  readonly content: string;
  readonly folder: string;
  readonly tags: ReadonlyArray<string>;
  readonly pinned: boolean;
  readonly wikilinks: ReadonlyArray<string>;
  readonly backlinks: ReadonlyArray<{ readonly note_id: string; readonly title: string }>;
  readonly version_count: number;
}

interface TodoRecord {
  readonly id: string;
  readonly title: string;
  readonly description: string;
  readonly due_date: string | null;
  readonly priority: string;
  readonly status: string;
  readonly completed: boolean;
  readonly assigned_agent_run_id: string | null;
  readonly agent_status: string | null;
  readonly last_agent_error: string | null;
  readonly linked_artifacts: ReadonlyArray<{ readonly artifact_id: string; readonly title: string }>;
}

interface CalendarEventRecord {
  readonly id: string;
  readonly title: string;
  readonly start_local: string;
  readonly duration_minutes: number;
  readonly timezone: string;
  readonly rrule: string | null;
  readonly etag: string;
  readonly location: string;
}

interface CalConflictRecord {
  readonly conflict_id: string;
  readonly event_id: string;
  readonly local_etag: string;
  readonly remote_etag: string;
  readonly resolved: boolean;
  readonly resolution: string | null;
}

interface ScheduleRecord {
  readonly id: string;
  readonly name: string;
  readonly kind: string;
  readonly cron_expr: string;
  readonly timezone: string;
  readonly prompt_template: string;
  readonly enabled: boolean;
  readonly misfire_policy: string;
  readonly overlap_policy: string;
  readonly consecutive_errors: number;
  readonly flapping: boolean;
  readonly auto_disabled: boolean;
  readonly health_badge: string;
  readonly next_runs: ReadonlyArray<string>;
  readonly delivery_targets?: ReadonlyArray<string>;
}

interface NotificationRecord {
  readonly id: string;
  readonly event_class: string;
  readonly title: string;
  readonly body: string;
  readonly severity: string;
  readonly channels_delivered: ReadonlyArray<string>;
  readonly delivery_latency_ms: number;
  readonly read: boolean;
}

interface ApiTokenItem {
  readonly token_id: string;
  readonly name: string;
  readonly token_prefix: string;
  readonly scopes: ReadonlyArray<string>;
  readonly expires_at: string;
  readonly revoked: boolean;
  readonly plaintext_token_once?: string;
}

interface OutboundWebhookItem {
  readonly webhook_id: string;
  readonly name: string;
  readonly target_url: string;
  readonly enabled: boolean;
}

interface DeadLetterItem {
  readonly delivery_id: string;
  readonly webhook_id: string;
  readonly event_type: string;
  readonly status: string;
  readonly attempts: number;
  readonly last_error: string | null;
}

export function describeCronHumanReadable(cronExpr: string): string {
  const trimmed = cronExpr.trim();
  if (trimmed === "0 9 * * 1-5") return "Weekdays (Mon–Fri) at 09:00";
  if (trimmed === "0 8 * * *") return "Every day at 08:00";
  if (trimmed === "*/15 * * * *") return "Every 15 minutes";
  if (trimmed === "0 0 * * 0") return "Sundays at midnight";
  return `Cron schedule (${trimmed})`;
}

export function extractSanitizedLinks(html: string): ReadonlyArray<{
  readonly href: string;
  readonly text: string;
  readonly spoofed: boolean;
}> {
  const results: Array<{ href: string; text: string; spoofed: boolean }> = [];
  const regex = /<a\b[^>]*href="([^"]*)"[^>]*>([\s\S]*?)<\/a>/gi;
  let match = regex.exec(html);
  while (match !== null) {
    const href = match[1] ?? "";
    const text = (match[2] ?? "").replace(/<[^>]+>/g, "").trim();
    results.push({
      href,
      text: text || href,
      spoofed: href.includes("blocked-spoofed-link"),
    });
    match = regex.exec(html);
  }
  return results;
}

export function ProductivityWorkspacesView({
  initialMode = "mail",
}: ProductivityWorkspacesViewProps): React.ReactElement {
  const { setWorkspace, addToast } = useAppShellStore();
  const [activeTab, setActiveTab] = useState<ProductivityMode>(initialMode);
  const composeSubjectRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    setActiveTab(initialMode);
  }, [initialMode]);

  // --- Mail State (FE-WORK-04) ---
  const [mailAccounts, setMailAccounts] = useState<ReadonlyArray<MailAccountItem>>([]);
  const [mailMessages, setMailMessages] = useState<ReadonlyArray<MailMessageItem>>([]);
  const [selectedMailId, setSelectedMailId] = useState<string>("mail_seed_1");
  const [mailSearchQuery, setMailSearchQuery] = useState<string>("");
  const [mailFolder, setMailFolder] = useState<string>("INBOX");
  const [composeTo, setComposeTo] = useState<string>("team@enterprise.example");
  const [composeSubject, setComposeSubject] = useState<string>("");
  const [composeBody, setComposeBody] = useState<string>("");
  const [pendingOutboxId, setPendingOutboxId] = useState<string | null>(null);

  // --- Notes & Todos State (FE-WORK-05) ---
  const [notes, setNotes] = useState<ReadonlyArray<NoteRecord>>([]);
  const [notesQuery, setNotesQuery] = useState<string>("");
  const [selectedNoteId, setSelectedNoteId] = useState<string | null>(null);
  const [noteTitleDraft, setNoteTitleDraft] = useState<string>("");
  const [noteContentDraft, setNoteContentDraft] = useState<string>("");
  const [todos, setTodos] = useState<ReadonlyArray<TodoRecord>>([]);
  const [todoViewMode, setTodoViewMode] = useState<"kanban" | "list">("kanban");
  const [todoFilter, setTodoFilter] = useState<"all" | "high" | "agent" | "open">("all");
  const [newTodoTitle, setNewTodoTitle] = useState<string>("");
  const [newTodoPriority, setNewTodoPriority] = useState<string>("high");

  // --- Calendar & CalDAV State (FE-WORK-06) ---
  const [calEvents, setCalEvents] = useState<ReadonlyArray<CalendarEventRecord>>([]);
  const [calConflicts, setCalConflicts] = useState<ReadonlyArray<CalConflictRecord>>([]);
  const [calViewMode, setCalViewMode] = useState<"month" | "week" | "day" | "agenda">("week");
  const [calTimezone, setCalTimezone] = useState<string>("America/New_York");
  const [calSyncToken, setCalSyncToken] = useState<string>("sync_initial");
  const [showAgentOverlay, setShowAgentOverlay] = useState<boolean>(true);
  const [quickAddText, setQuickAddText] = useState<string>(
    "Lunch with Sara tomorrow at 12:30pm for 45m",
  );
  const [quickAddPreview, setQuickAddPreview] = useState<{
    readonly title: string;
    readonly start_iso: string;
    readonly duration_minutes: number;
    readonly parsed_by: string;
  } | null>(null);

  // --- Schedules, Notifications, Webhooks & Tokens State (FE-WORK-07, FE-ADMIN-04, FE-AGENT-14) ---
  const [schedules, setSchedules] = useState<ReadonlyArray<ScheduleRecord>>([]);
  const [newSchedName, setNewSchedName] = useState<string>("");
  const [newSchedCron, setNewSchedCron] = useState<string>("0 9 * * 1-5");
  const [newSchedPrompt, setNewSchedPrompt] = useState<string>(
    "Summarize unread urgent mail for {{date}}. Prior: {{last_run_summary}}",
  );
  const [lastScheduleRunStatus, setLastScheduleRunStatus] = useState<string | null>(null);
  const [notifications, setNotifications] = useState<ReadonlyArray<NotificationRecord>>([]);
  const [tokens, setTokens] = useState<ReadonlyArray<ApiTokenItem>>([]);
  const [newTokenName, setNewTokenName] = useState<string>("");
  const [mintedTokenOnce, setMintedTokenOnce] = useState<string | null>(null);
  const [webhooks, setWebhooks] = useState<ReadonlyArray<OutboundWebhookItem>>([]);
  const [deadLetters, setDeadLetters] = useState<ReadonlyArray<DeadLetterItem>>([]);
  const [webhookUrl, setWebhookUrl] = useState<string>("https://hooks.partner.example/odysseus");
  const [webhookError, setWebhookError] = useState<string | null>(null);

  const csrfHeaders = useCallback((): Record<string, string> => {
    const token = useAppShellStore.getState().csrfToken ?? "";
    const hdrs: Record<string, string> = { "Content-Type": "application/json" };
    if (token) {
      hdrs["X-CSRF-Token"] = token;
    }
    return hdrs;
  }, []);

  const loadMail = useCallback(
    async (q = "", folder = "INBOX"): Promise<void> => {
      try {
        const params = new URLSearchParams();
        if (q) params.set("query", q);
        if (folder) params.set("folder", folder);
        const [accRes, msgRes] = await Promise.all([
          fetch("/api/mail/accounts", { credentials: "include" }),
          fetch(`/api/mail/messages?${params.toString()}`, { credentials: "include" }),
        ]);
        if (accRes.ok) {
          const accData = (await accRes.json()) as { accounts: MailAccountItem[] };
          setMailAccounts(accData.accounts);
        }
        if (!msgRes.ok) return;
        const data = (await msgRes.json()) as { messages: MailMessageItem[] };
        setMailMessages(data.messages);
        const firstMsg = data.messages[0];
        if (firstMsg && !data.messages.some((m) => m.id === selectedMailId)) {
          setSelectedMailId(firstMsg.id);
        }
      } catch {
        // Ignore fetch errors in offline mode
      }
    },
    [selectedMailId],
  );

  const loadNotesAndTodos = useCallback(
    async (q = ""): Promise<void> => {
      try {
        const params = new URLSearchParams();
        if (q) params.set("query", q);
        const [nRes, tRes] = await Promise.all([
          fetch(`/api/notes?${params.toString()}`, { credentials: "include" }),
          fetch("/api/todos", { credentials: "include" }),
        ]);
        if (nRes.ok) {
          const nData = (await nRes.json()) as { notes: NoteRecord[] };
          setNotes(nData.notes);
          const firstNote = nData.notes[0];
          if (firstNote && !selectedNoteId) {
            setSelectedNoteId(firstNote.id);
          }
        }
        if (tRes.ok) {
          const tData = (await tRes.json()) as { todos: TodoRecord[] };
          setTodos(tData.todos);
        }
      } catch {
        // Ignore fetch errors
      }
    },
    [selectedNoteId],
  );

  const loadCalendar = useCallback(async (): Promise<void> => {
    try {
      const res = await fetch("/api/calendar/events", { credentials: "include" });
      if (!res.ok) return;
      const data = (await res.json()) as {
        events: CalendarEventRecord[];
        conflicts: CalConflictRecord[];
      };
      setCalEvents(data.events);
      setCalConflicts(data.conflicts);
    } catch {
      // Ignore
    }
  }, []);

  const loadSchedulesAndNotifications = useCallback(async (): Promise<void> => {
    try {
      const [sRes, nRes, tokRes, whRes] = await Promise.all([
        fetch("/api/schedules", { credentials: "include" }),
        fetch("/api/notifications", { credentials: "include" }),
        fetch("/api/tokens", { credentials: "include" }),
        fetch("/api/webhooks/outbound", { credentials: "include" }),
      ]);
      if (sRes.ok) {
        const sData = (await sRes.json()) as { schedules: ScheduleRecord[] };
        setSchedules(sData.schedules);
      }
      if (nRes.ok) {
        const nData = (await nRes.json()) as { notifications: NotificationRecord[] };
        setNotifications(nData.notifications);
      }
      if (tokRes.ok) {
        const tokData = (await tokRes.json()) as { tokens: ApiTokenItem[] };
        setTokens(tokData.tokens);
      }
      if (whRes.ok) {
        const whData = (await whRes.json()) as {
          webhooks: OutboundWebhookItem[];
          dead_letters: DeadLetterItem[];
        };
        setWebhooks(whData.webhooks);
        setDeadLetters(whData.dead_letters);
      }
    } catch {
      // Ignore
    }
  }, []);

  useEffect(() => {
    void loadMail(mailSearchQuery, mailFolder);
    void loadNotesAndTodos(notesQuery);
    void loadCalendar();
    void loadSchedulesAndNotifications();
  }, [
    loadMail,
    loadNotesAndTodos,
    loadCalendar,
    loadSchedulesAndNotifications,
    mailSearchQuery,
    mailFolder,
    notesQuery,
  ]);

  const selectedMail = mailMessages.find((m) => m.id === selectedMailId) ?? mailMessages[0] ?? null;
  const selectedNote = notes.find((n) => n.id === selectedNoteId) ?? notes[0] ?? null;

  const handleMoveMail = useCallback(
    async (messageId: string, targetFolder: string): Promise<void> => {
      const res = await fetch(`/api/mail/messages/${messageId}/move`, {
        method: "POST",
        credentials: "include",
        headers: csrfHeaders(),
        body: JSON.stringify({ target_folder: targetFolder, delete_permanently: false }),
      });
      if (res.ok) {
        addToast({ message: `Moved message to ${targetFolder}`, variant: "info" });
        await loadMail(mailSearchQuery, mailFolder);
      }
    },
    [csrfHeaders, addToast, loadMail, mailSearchQuery, mailFolder],
  );

  // Keyboard Triage (j/k/e/#/r) for FE-WORK-04
  useEffect(() => {
    if (activeTab !== "mail") return undefined;
    const onKeyDown = (ev: KeyboardEvent): void => {
      const target = ev.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === "INPUT" ||
          target.tagName === "TEXTAREA" ||
          target.tagName === "SELECT" ||
          target.isContentEditable)
      ) {
        return;
      }
      if (mailMessages.length === 0) return;
      const idx = Math.max(
        0,
        mailMessages.findIndex((m) => m.id === selectedMail?.id),
      );
      if (ev.key === "j") {
        const nextMsg = mailMessages[Math.min(mailMessages.length - 1, idx + 1)];
        if (nextMsg) setSelectedMailId(nextMsg.id);
      } else if (ev.key === "k") {
        const prevMsg = mailMessages[Math.max(0, idx - 1)];
        if (prevMsg) setSelectedMailId(prevMsg.id);
      } else if (ev.key === "e" && selectedMail) {
        void handleMoveMail(selectedMail.id, "Archive");
      } else if (ev.key === "#" && selectedMail) {
        void handleMoveMail(selectedMail.id, "Trash");
      } else if (ev.key === "r" && selectedMail) {
        ev.preventDefault();
        setComposeTo(selectedMail.sender);
        setComposeSubject(`Re: ${selectedMail.subject}`);
        composeSubjectRef.current?.focus();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [activeTab, mailMessages, selectedMail, handleMoveMail]);

  const handleTriageSelectedMail = async (): Promise<void> => {
    if (!selectedMail) return;
    const res = await fetch(`/api/mail/messages/${selectedMail.id}/triage`, {
      method: "POST",
      credentials: "include",
      headers: csrfHeaders(),
    });
    if (res.ok) {
      const data = (await res.json()) as { triage?: MailMessageItem["triage"] };
      const triage = data.triage;
      if (triage) {
        setMailMessages((messages) =>
          messages.map((message) =>
            message.id === selectedMail.id ? { ...message, triage } : message,
          ),
        );
      }
      addToast({
        message: "AI Triage complete (draft created, never auto-sent)",
        variant: "success",
      });
      await loadMail(mailSearchQuery, mailFolder);
    }
  };

  const handleAllowRemoteSender = async (): Promise<void> => {
    if (!selectedMail) return;
    const res = await fetch(`/api/mail/messages/${selectedMail.id}/allow-remote`, {
      method: "POST",
      credentials: "include",
      headers: csrfHeaders(),
    });
    if (res.ok) {
      addToast({ message: `Allowed remote images from ${selectedMail.sender}`, variant: "info" });
      await loadMail(mailSearchQuery, mailFolder);
    }
  };

  const handleSendMailWithUndo = async (e: React.FormEvent): Promise<void> => {
    e.preventDefault();
    if (!composeSubject.trim()) return;
    const res = await fetch("/api/mail/send", {
      method: "POST",
      credentials: "include",
      headers: csrfHeaders(),
      body: JSON.stringify({
        to: [composeTo.trim() || "team@enterprise.example"],
        subject: composeSubject.trim(),
        body_text: composeBody.trim(),
        undo_window_seconds: 10.0,
      }),
    });
    if (res.ok) {
      const data = (await res.json()) as { outbox_id?: string; status: string };
      if (data.outbox_id) {
        setPendingOutboxId(data.outbox_id);
      }
      setComposeSubject("");
      setComposeBody("");
      addToast({ message: "Message queued in Outbox (10s Undo window active)", variant: "info" });
    }
  };

  const handleUndoSend = async (): Promise<void> => {
    if (!pendingOutboxId) return;
    const res = await fetch(`/api/mail/outbox/${pendingOutboxId}/cancel`, {
      method: "POST",
      credentials: "include",
      headers: csrfHeaders(),
    });
    if (res.ok) {
      setPendingOutboxId(null);
      addToast({ message: "Send cancelled and moved to Drafts", variant: "warning" });
    }
  };

  const handleCreateNote = async (e: React.FormEvent): Promise<void> => {
    e.preventDefault();
    if (!noteTitleDraft.trim()) return;
    const res = await fetch("/api/notes", {
      method: "POST",
      credentials: "include",
      headers: csrfHeaders(),
      body: JSON.stringify({
        title: noteTitleDraft.trim(),
        content: noteContentDraft,
        folder: "Engineering",
        tags: ["phase07"],
      }),
    });
    if (res.ok) {
      const data = (await res.json()) as { note: NoteRecord };
      setNoteTitleDraft("");
      setNoteContentDraft("");
      setSelectedNoteId(data.note.id);
      await loadNotesAndTodos(notesQuery);
    }
  };

  const handleTogglePinNote = async (note: NoteRecord): Promise<void> => {
    const res = await fetch(`/api/notes/${note.id}`, {
      method: "PUT",
      credentials: "include",
      headers: csrfHeaders(),
      body: JSON.stringify({ pinned: !note.pinned }),
    });
    if (res.ok) {
      await loadNotesAndTodos(notesQuery);
    }
  };

  const handleCreateTodo = async (e: React.FormEvent): Promise<void> => {
    e.preventDefault();
    if (!newTodoTitle.trim()) return;
    const res = await fetch("/api/todos", {
      method: "POST",
      credentials: "include",
      headers: csrfHeaders(),
      body: JSON.stringify({
        title: newTodoTitle.trim(),
        priority: newTodoPriority,
        due_date: "2026-10-10",
      }),
    });
    if (res.ok) {
      setNewTodoTitle("");
      await loadNotesAndTodos(notesQuery);
    }
  };

  const handleCompleteTodo = async (todoId: string): Promise<void> => {
    const res = await fetch(`/api/todos/${todoId}/complete`, {
      method: "POST",
      credentials: "include",
      headers: csrfHeaders(),
    });
    if (res.ok) {
      await loadNotesAndTodos(notesQuery);
    }
  };

  const handleAssignTodoToAgent = async (
    todoId: string,
    simulateFailure = false,
  ): Promise<void> => {
    const res = await fetch(`/api/todos/${todoId}/assign-agent`, {
      method: "POST",
      credentials: "include",
      headers: csrfHeaders(),
      body: JSON.stringify({
        agent_instructions: "Execute task and attach deliverable artifact.",
        simulate_failure: simulateFailure,
      }),
    });
    if (res.ok) {
      await loadNotesAndTodos(notesQuery);
    }
  };

  const handleQuickAddPreview = async (commit: boolean): Promise<void> => {
    const res = await fetch("/api/calendar/quick-add", {
      method: "POST",
      credentials: "include",
      headers: csrfHeaders(),
      body: JSON.stringify({
        text: quickAddText,
        timezone: calTimezone,
        commit,
      }),
    });
    if (res.ok) {
      const data = (await res.json()) as {
        preview: {
          title: string;
          start_iso: string;
          duration_minutes: number;
          parsed_by: string;
        };
      };
      setQuickAddPreview(data.preview);
      if (commit) {
        await loadCalendar();
      }
    }
  };

  const handleSyncCalDav = async (): Promise<void> => {
    const res = await fetch("/api/calendar/sync", {
      method: "POST",
      credentials: "include",
      headers: csrfHeaders(),
    });
    if (res.ok) {
      const data = (await res.json()) as { sync_token: string };
      setCalSyncToken(data.sync_token);
      await loadCalendar();
    }
  };

  const handleSimulateCalDavConflict = async (): Promise<void> => {
    const firstEv = calEvents[0];
    if (!firstEv) return;
    await fetch(`/api/calendar/events/${firstEv.id}`, {
      method: "PUT",
      credentials: "include",
      headers: csrfHeaders(),
      body: JSON.stringify({
        title: `${firstEv.title} (Local Edit)`,
        expected_etag: "etag_stale_remote_mismatch",
      }),
    });
    await loadCalendar();
  };

  const handleResolveCalDavConflict = async (
    conflictId: string,
    strategy: "keep_local" | "keep_remote" | "merge",
  ): Promise<void> => {
    const res = await fetch(`/api/calendar/conflicts/${conflictId}/resolve`, {
      method: "POST",
      credentials: "include",
      headers: csrfHeaders(),
      body: JSON.stringify({ strategy }),
    });
    if (res.ok) {
      await loadCalendar();
    }
  };

  const handleCreateSchedule = async (e: React.FormEvent): Promise<void> => {
    e.preventDefault();
    if (!newSchedName.trim()) return;
    const res = await fetch("/api/schedules", {
      method: "POST",
      credentials: "include",
      headers: csrfHeaders(),
      body: JSON.stringify({
        name: newSchedName.trim(),
        kind: "cron",
        cron_expr: newSchedCron.trim(),
        timezone: calTimezone,
        prompt_template: newSchedPrompt,
      }),
    });
    if (res.ok) {
      setNewSchedName("");
      await loadSchedulesAndNotifications();
    }
  };

  const handleToggleSchedule = async (schedId: string, enabled: boolean): Promise<void> => {
    const res = await fetch(`/api/schedules/${schedId}/toggle`, {
      method: "POST",
      credentials: "include",
      headers: csrfHeaders(),
      body: JSON.stringify({ enabled }),
    });
    if (res.ok) {
      await loadSchedulesAndNotifications();
    }
  };

  const handleRunScheduleNow = async (schedId: string): Promise<void> => {
    const res = await fetch(`/api/schedules/${schedId}/run-now`, {
      method: "POST",
      credentials: "include",
      headers: csrfHeaders(),
      body: JSON.stringify({ simulate_error: null }),
    });
    if (res.ok) {
      const data = (await res.json()) as {
        deduplicated?: boolean;
        run?: { status: string; run_id: string };
      };
      const st = data.run?.status ?? "succeeded";
      const rid = data.run?.run_id ?? "srun_manual";
      setLastScheduleRunStatus(`${st} (${rid})`);
      await loadSchedulesAndNotifications();
    }
  };

  const handleMarkNotificationRead = async (notifId: string): Promise<void> => {
    const res = await fetch(`/api/notifications/${notifId}/read`, {
      method: "POST",
      credentials: "include",
      headers: csrfHeaders(),
    });
    if (res.ok) {
      await loadSchedulesAndNotifications();
    }
  };

  const handleMintToken = async (e: React.FormEvent): Promise<void> => {
    e.preventDefault();
    if (!newTokenName.trim()) return;
    const res = await fetch("/api/tokens", {
      method: "POST",
      credentials: "include",
      headers: csrfHeaders(),
      body: JSON.stringify({
        name: newTokenName.trim(),
        scopes: ["chats:write", "todos:write", "mail:read"],
        expires_in_days: 30,
      }),
    });
    if (res.ok) {
      const data = (await res.json()) as { token: ApiTokenItem };
      setMintedTokenOnce(data.token.plaintext_token_once ?? null);
      setNewTokenName("");
      await loadSchedulesAndNotifications();
    }
  };

  const handleRevokeToken = async (tokenId: string): Promise<void> => {
    const res = await fetch(`/api/tokens/${tokenId}`, {
      method: "DELETE",
      credentials: "include",
      headers: csrfHeaders(),
    });
    if (res.ok) {
      await loadSchedulesAndNotifications();
    }
  };

  const handleRegisterOutboundWebhook = async (e: React.FormEvent): Promise<void> => {
    e.preventDefault();
    setWebhookError(null);
    const res = await fetch("/api/webhooks/outbound", {
      method: "POST",
      credentials: "include",
      headers: csrfHeaders(),
      body: JSON.stringify({
        name: "Automation Hook",
        target_url: webhookUrl.trim(),
      }),
    });
    if (!res.ok) {
      const err = (await res.json()) as { detail?: string };
      setWebhookError(err.detail ?? "Webhook blocked by SSRF guard");
      return;
    }
    addToast({ message: "Outbound webhook registered", variant: "success" });
    await loadSchedulesAndNotifications();
  };

  const handleSimulateWebhookDlq = async (webhookId: string): Promise<void> => {
    const res = await fetch(`/api/webhooks/outbound/${webhookId}/dispatch`, {
      method: "POST",
      credentials: "include",
      headers: csrfHeaders(),
      body: JSON.stringify({
        event_type: "run.completed",
        payload: { run_id: "run_dlq_demo" },
        simulate_failures: 3,
      }),
    });
    if (res.ok) {
      await loadSchedulesAndNotifications();
    }
  };

  const handleReplayDeadLetter = async (deliveryId: string): Promise<void> => {
    const res = await fetch(`/api/webhooks/dead-letters/${deliveryId}/replay`, {
      method: "POST",
      credentials: "include",
      headers: csrfHeaders(),
    });
    if (res.ok) {
      await loadSchedulesAndNotifications();
    }
  };

  const filteredTodos = useMemo(() => {
    return todos.filter((td) => {
      if (todoFilter === "high") return td.priority === "high" || td.priority === "urgent";
      if (todoFilter === "agent") return Boolean(td.assigned_agent_run_id);
      if (todoFilter === "open") return !td.completed;
      return true;
    });
  }, [todos, todoFilter]);

  const extractedLinks = useMemo(
    () => (selectedMail ? extractSanitizedLinks(selectedMail.sanitized_html) : []),
    [selectedMail],
  );

  const switchMode = (nextMode: ProductivityMode): void => {
    setActiveTab(nextMode);
    setWorkspace(nextMode);
  };

  return (
    <div className="odysseus-stack" data-testid="productivity-workspaces-view">
      {/* Top Workspace Sub-Navigation */}
      <div className="odysseus-card">
        <div className="odysseus-row-between">
          <h2>Odysseus Productivity Suite</h2>
          <div className="odysseus-row-wrap" role="tablist" aria-label="Productivity Workspaces">
            <button
              type="button"
              role="tab"
              aria-selected={activeTab === "mail"}
              className={`odysseus-btn odysseus-btn-sm ${
                activeTab === "mail" ? "odysseus-btn-primary" : "odysseus-btn-secondary"
              }`}
              onClick={() => switchMode("mail")}
              data-testid="prod-tab-mail"
            >
              Email & Triage
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={activeTab === "notes"}
              className={`odysseus-btn odysseus-btn-sm ${
                activeTab === "notes" ? "odysseus-btn-primary" : "odysseus-btn-secondary"
              }`}
              onClick={() => switchMode("notes")}
              data-testid="prod-tab-notes"
            >
              Notes & Todos
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={activeTab === "calendar"}
              className={`odysseus-btn odysseus-btn-sm ${
                activeTab === "calendar" ? "odysseus-btn-primary" : "odysseus-btn-secondary"
              }`}
              onClick={() => switchMode("calendar")}
              data-testid="prod-tab-calendar"
            >
              Calendar & CalDAV
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={activeTab === "schedules"}
              className={`odysseus-btn odysseus-btn-sm ${
                activeTab === "schedules" ? "odysseus-btn-primary" : "odysseus-btn-secondary"
              }`}
              onClick={() => switchMode("schedules")}
              data-testid="prod-tab-schedules"
            >
              Schedules, Webhooks & Tokens
            </button>
          </div>
        </div>
      </div>

      {/* 1. EMAIL WORKSPACE (FE-WORK-04) */}
      {activeTab === "mail" ? (
        <div className="odysseus-stack" data-testid="mail-workspace-pane">
          <div className="odysseus-card" data-testid="mail-accounts-bar">
            <div className="odysseus-row-between">
              <div className="odysseus-row-wrap">
                <span className="odysseus-badge" data-testid="mail-keyboard-triage-chip">
                  ⌨️ Keyboard Triage: j / k / e (Archive) / # (Trash) / r (Reply)
                </span>
                {mailAccounts.map((acc) => (
                  <span key={acc.id} className="odysseus-badge">
                    {acc.email_address} ({acc.use_tls ? "IMAPS/TLS" : "Non-TLS"} · {acc.status})
                  </span>
                ))}
              </div>
              <div className="odysseus-row-wrap">
                {(["INBOX", "Sent", "Drafts", "Archive", "Spam", "Trash"] as const).map((f) => (
                  <button
                    key={f}
                    type="button"
                    className={`odysseus-btn odysseus-btn-xs ${
                      mailFolder === f ? "odysseus-btn-primary" : "odysseus-btn-secondary"
                    }`}
                    onClick={() => setMailFolder(f)}
                    data-testid={`mail-folder-${f.toLowerCase()}`}
                  >
                    {f}
                  </button>
                ))}
                <input
                  aria-label="Search mail"
                  className="odysseus-input"
                  placeholder="Search mail (from:cto is:unread)…"
                  value={mailSearchQuery}
                  onChange={(e) => setMailSearchQuery(e.target.value)}
                  data-testid="mail-search-input"
                />
              </div>
            </div>
          </div>

          <div className="odysseus-settings-grid">
            {/* Thread List */}
            <section className="odysseus-card" aria-label="Mailbox messages">
              <h3>
                {mailFolder} Messages ({mailMessages.length})
              </h3>
              <div className="odysseus-stack">
                {mailMessages.map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    className={`odysseus-btn ${
                      selectedMail?.id === m.id ? "odysseus-btn-primary" : "odysseus-btn-secondary"
                    }`}
                    onClick={() => setSelectedMailId(m.id)}
                    data-testid={`mail-row-${m.id}`}
                  >
                    <strong>{m.subject}</strong> — <span>{m.sender}</span>
                  </button>
                ))}
              </div>
            </section>

            {/* Safe Sandboxed Reader + AI Triage Drawer */}
            <section className="odysseus-card" aria-label="Email reader">
              {selectedMail ? (
                <div className="odysseus-stack" data-testid="mail-reader-card">
                  <div className="odysseus-row-between">
                    <div>
                      <h3 data-testid="mail-reader-subject">{selectedMail.subject}</h3>
                      <p className="odysseus-text-muted">
                        From: {selectedMail.sender} | Folder: {selectedMail.folder}
                      </p>
                    </div>
                    <div className="odysseus-row-wrap">
                      <button
                        type="button"
                        className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                        onClick={() => void handleMoveMail(selectedMail.id, "Archive")}
                        data-testid="mail-archive-btn"
                      >
                        Archive (e)
                      </button>
                      <button
                        type="button"
                        className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
                        onClick={() => void handleTriageSelectedMail()}
                        data-testid="mail-triage-btn"
                      >
                        Run AI Triage (Draft Only)
                      </button>
                    </div>
                  </div>

                  {selectedMail.remote_resources_blocked > 0 ? (
                    <div
                      className="odysseus-row-between"
                      role="status"
                      data-testid="mail-remote-blocked-banner"
                    >
                      <span>
                        🛡️ Blocked {selectedMail.remote_resources_blocked} remote tracking image(s)
                        by default.
                      </span>
                      <button
                        type="button"
                        className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                        onClick={() => void handleAllowRemoteSender()}
                        data-testid="mail-allow-remote-btn"
                      >
                        Load Remote Images for Sender
                      </button>
                    </div>
                  ) : null}

                  <iframe
              title="Sandboxed content preview"
                    sandbox=""
                    srcDoc={selectedMail.sanitized_html}
                    style={{
                      width: "100%",
                      minHeight: "140px",
                      border: "1px solid var(--border-subtle)",
                      borderRadius: "var(--radius-sm)",
                      background: "var(--bg-surface)",
                    }}
                    data-testid="mail-sanitized-iframe"
                  />

                  {extractedLinks.length > 0 ? (
                    <div className="odysseus-row-wrap" data-testid="mail-link-inspector">
                      <span className="odysseus-text-muted">Verified Link Destinations:</span>
                      {extractedLinks.map((lnk, idx) => (
                        <code key={`${lnk.href}_${idx}`}>
                          {lnk.text} → {lnk.href}
                        </code>
                      ))}
                    </div>
                  ) : null}

                  {selectedMail.triage ? (
                    <div className="odysseus-card" data-testid="mail-triage-result">
                      <h4>
                        AI Triage ({selectedMail.triage.urgency.toUpperCase()}) — Suggest Only:{" "}
                        {String(selectedMail.triage.suggest_only)}
                      </h4>
                      <p>{selectedMail.triage.summary}</p>
                      <p>
                        Tags: <code>{selectedMail.triage.tags.join(", ")}</code> | Draft Reply ID:{" "}
                        <code>{selectedMail.triage.draft_reply_id}</code>
                      </p>
                    </div>
                  ) : null}
                </div>
              ) : (
                <p className="odysseus-text-muted">Select a message to read.</p>
              )}
            </section>
          </div>

          {/* Compose & Undo-Send */}
          <section className="odysseus-card" aria-label="Compose email">
            <h3>Compose Email (Idempotent Outbox + Undo-Send)</h3>
            <form onSubmit={(e) => void handleSendMailWithUndo(e)} className="odysseus-stack">
              <div className="odysseus-row-wrap">
                <input
                  aria-label="Recipient email"
                  className="odysseus-input"
                  value={composeTo}
                  onChange={(e) => setComposeTo(e.target.value)}
                  data-testid="mail-compose-to"
                />
                <input
                  ref={composeSubjectRef}
                  aria-label="Email subject"
                  className="odysseus-input"
                  placeholder="Subject…"
                  value={composeSubject}
                  onChange={(e) => setComposeSubject(e.target.value)}
                  data-testid="mail-compose-subject"
                />
                <input
                  aria-label="Email body"
                  className="odysseus-input"
                  placeholder="Write message…"
                  value={composeBody}
                  onChange={(e) => setComposeBody(e.target.value)}
                  data-testid="mail-compose-body"
                />
                <button
                  type="submit"
                  className="odysseus-btn odysseus-btn-primary odysseus-btn-sm"
                  data-testid="mail-send-btn"
                >
                  Send Mail
                </button>
                {pendingOutboxId ? (
                  <button
                    type="button"
                    className="odysseus-btn odysseus-btn-danger odysseus-btn-sm"
                    onClick={() => void handleUndoSend()}
                    data-testid="mail-undo-send-btn"
                  >
                    Undo Send ({pendingOutboxId})
                  </button>
                ) : null}
              </div>
            </form>
          </section>
        </div>
      ) : null}

      {/* 2. NOTES & TODOS WORKSPACE (FE-WORK-05) */}
      {activeTab === "notes" ? (
        <div className="odysseus-stack" data-testid="notes-todos-workspace-pane">
          <div className="odysseus-settings-grid">
            {/* Markdown Notes + [[wikilinks]] & Backlinks */}
            <section className="odysseus-card" aria-label="Markdown Notes">
              <div className="odysseus-row-between">
                <h3>Markdown Notes ({notes.length})</h3>
                <div className="odysseus-row-wrap">
                  <input
                    aria-label="Search notes"
                    className="odysseus-input"
                    placeholder="Search notes…"
                    value={notesQuery}
                    onChange={(e) => setNotesQuery(e.target.value)}
                    data-testid="notes-search-input"
                  />
                  <a
                    href="/api/notes/export/zip"
                    className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                    data-testid="notes-export-zip-link"
                  >
                    Export Notes (.zip)
                  </a>
                </div>
              </div>

              <div className="odysseus-row-wrap">
                {notes.map((n) => (
                  <button
                    key={n.id}
                    type="button"
                    className={`odysseus-btn odysseus-btn-xs ${
                      selectedNote?.id === n.id ? "odysseus-btn-primary" : "odysseus-btn-secondary"
                    }`}
                    onClick={() => setSelectedNoteId(n.id)}
                    data-testid={`note-select-${n.id}`}
                  >
                    {n.pinned ? "📌 " : ""}
                    {n.title}
                  </button>
                ))}
              </div>

              {selectedNote ? (
                <div className="odysseus-stack" data-testid="selected-note-detail">
                  <div className="odysseus-row-between">
                    <h4 data-testid="selected-note-title">
                      {selectedNote.title} (v{selectedNote.version_count})
                    </h4>
                    <button
                      type="button"
                      className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                      onClick={() => void handleTogglePinNote(selectedNote)}
                      data-testid="note-pin-toggle-btn"
                    >
                      {selectedNote.pinned ? "Unpin Note" : "📌 Pin Note"}
                    </button>
                  </div>
                  <pre className="odysseus-code-block">{selectedNote.content}</pre>
                  <div className="odysseus-row-wrap">
                    <span>
                      Tags: <code>{selectedNote.tags.join(", ") || "none"}</code>
                    </span>
                    <span>
                      Wikilinks: <code>{selectedNote.wikilinks.join(", ") || "none"}</code>
                    </span>
                    <span data-testid="selected-note-backlinks">
                      Backlinks:{" "}
                      {selectedNote.backlinks.map((b) => (
                        <button
                          key={b.note_id}
                          type="button"
                          className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
                          onClick={() => setSelectedNoteId(b.note_id)}
                          data-testid={`backlink-btn-${b.note_id}`}
                        >
                          ← [[{b.title}]]
                        </button>
                      ))}
                    </span>
                  </div>
                </div>
              ) : null}

              <form onSubmit={(e) => void handleCreateNote(e)} className="odysseus-row-wrap">
                <input
                  aria-label="New note title"
                  className="odysseus-input"
                  placeholder="Note title…"
                  value={noteTitleDraft}
                  onChange={(e) => setNoteTitleDraft(e.target.value)}
                  data-testid="note-create-title"
                />
                <input
                  aria-label="New note content with wikilinks"
                  className="odysseus-input"
                  placeholder="Markdown with [[Release Roadmap]]…"
                  value={noteContentDraft}
                  onChange={(e) => setNoteContentDraft(e.target.value)}
                  data-testid="note-create-content"
                />
                <button
                  type="submit"
                  className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
                  data-testid="note-create-submit"
                >
                  Save Note
                </button>
              </form>
            </section>

            {/* Todos Kanban & Assign-to-Agent */}
            <section className="odysseus-card" aria-label="Todos and Assign to Agent">
              <div className="odysseus-row-between">
                <h3>Todos & Assign-to-Agent ({filteredTodos.length})</h3>
                <div className="odysseus-row-wrap">
                  {(["all", "open", "high", "agent"] as const).map((flt) => (
                    <button
                      key={flt}
                      type="button"
                      className={`odysseus-btn odysseus-btn-xs ${
                        todoFilter === flt ? "odysseus-btn-primary" : "odysseus-btn-secondary"
                      }`}
                      onClick={() => setTodoFilter(flt)}
                      data-testid={`todo-filter-${flt}`}
                    >
                      {flt.toUpperCase()}
                    </button>
                  ))}
                  <button
                    type="button"
                    className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                    onClick={() => setTodoViewMode(todoViewMode === "kanban" ? "list" : "kanban")}
                    data-testid="todo-view-toggle"
                  >
                    View: {todoViewMode.toUpperCase()}
                  </button>
                </div>
              </div>

              <form onSubmit={(e) => void handleCreateTodo(e)} className="odysseus-row-wrap">
                <input
                  aria-label="New todo title"
                  className="odysseus-input"
                  placeholder="Add task…"
                  value={newTodoTitle}
                  onChange={(e) => setNewTodoTitle(e.target.value)}
                  data-testid="todo-create-title"
                />
                <select
                  aria-label="Todo priority"
                  className="odysseus-select"
                  value={newTodoPriority}
                  onChange={(e) => setNewTodoPriority(e.target.value)}
                  data-testid="todo-create-priority"
                >
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                  <option value="urgent">Urgent</option>
                </select>
                <button
                  type="submit"
                  className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
                  data-testid="todo-create-submit"
                >
                  Add Todo
                </button>
              </form>

              <div className="odysseus-stack" data-testid="todo-items-list">
                {filteredTodos.map((td) => (
                  <div key={td.id} className="odysseus-card" data-testid={`todo-card-${td.id}`}>
                    <div className="odysseus-row-between">
                      <div>
                        <strong>{td.title}</strong>{" "}
                        <span className="odysseus-badge">{td.status}</span>{" "}
                        <span className="odysseus-badge">{td.priority}</span>
                        {td.due_date ? (
                          <span className="odysseus-text-muted"> · Due {td.due_date}</span>
                        ) : null}
                      </div>
                      <div className="odysseus-row-wrap">
                        {!td.completed ? (
                          <button
                            type="button"
                            className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                            onClick={() => void handleCompleteTodo(td.id)}
                            data-testid={`todo-complete-${td.id}`}
                          >
                            ✓ Complete
                          </button>
                        ) : null}
                        <button
                          type="button"
                          className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
                          onClick={() => void handleAssignTodoToAgent(td.id, false)}
                          data-testid={`todo-assign-agent-${td.id}`}
                        >
                          🤖 Assign to Agent
                        </button>
                      </div>
                    </div>
                    {td.assigned_agent_run_id ? (
                      <p className="odysseus-text-muted" data-testid={`todo-agent-run-${td.id}`}>
                        Run: <code>{td.assigned_agent_run_id}</code> ({td.agent_status}) |
                        Artifacts:{" "}
                        {td.linked_artifacts.map((a) => a.title).join(", ") || "none"}
                        {td.last_agent_error ? ` | Error: ${td.last_agent_error}` : ""}
                      </p>
                    ) : null}
                  </div>
                ))}
              </div>
            </section>
          </div>
        </div>
      ) : null}

      {/* 3. CALENDAR & CALDAV WORKSPACE (FE-WORK-06) */}
      {activeTab === "calendar" ? (
        <div className="odysseus-stack" data-testid="calendar-workspace-pane">
          <div className="odysseus-card">
            <div className="odysseus-row-between">
              <div className="odysseus-row-wrap">
                {(["month", "week", "day", "agenda"] as const).map((vm) => (
                  <button
                    key={vm}
                    type="button"
                    className={`odysseus-btn odysseus-btn-xs ${
                      calViewMode === vm ? "odysseus-btn-primary" : "odysseus-btn-secondary"
                    }`}
                    onClick={() => setCalViewMode(vm)}
                    data-testid={`cal-view-${vm}`}
                  >
                    {vm.toUpperCase()}
                  </button>
                ))}
                <button
                  type="button"
                  className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                  onClick={() => void handleSyncCalDav()}
                  data-testid="cal-sync-now-btn"
                >
                  Sync CalDAV ({calSyncToken})
                </button>
                <button
                  type="button"
                  className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                  onClick={() => void handleSimulateCalDavConflict()}
                  data-testid="cal-simulate-conflict-btn"
                >
                  Simulate 2-Way ETag Conflict
                </button>
                <button
                  type="button"
                  className={`odysseus-btn odysseus-btn-xs ${
                    showAgentOverlay ? "odysseus-btn-primary" : "odysseus-btn-secondary"
                  }`}
                  onClick={() => setShowAgentOverlay(!showAgentOverlay)}
                  data-testid="cal-agent-overlay-toggle"
                >
                  Agent Tasks Overlay: {showAgentOverlay ? "ON" : "OFF"}
                </button>
              </div>
              <div className="odysseus-row-wrap">
                <select
                  aria-label="Calendar Timezone"
                  className="odysseus-select"
                  value={calTimezone}
                  onChange={(e) => setCalTimezone(e.target.value)}
                  data-testid="cal-tz-select"
                >
                  <option value="America/New_York">America/New_York</option>
                  <option value="UTC">UTC</option>
                  <option value="Europe/London">Europe/London</option>
                  <option value="Asia/Jakarta">Asia/Jakarta</option>
                  <option value="Asia/Tokyo">Asia/Tokyo</option>
                </select>
                <a
                  href="/api/calendar/export.ics"
                  className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                  data-testid="cal-export-ics-link"
                >
                  Export .ics
                </a>
              </div>
            </div>
          </div>

          {/* 2-Way CalDAV Conflict Resolution Modal / Banner */}
          {calConflicts.some((c) => !c.resolved) ? (
            <section
              className="odysseus-card"
              aria-label="CalDAV 2-way conflict resolution"
              data-testid="cal-conflict-panel"
            >
              <h4>⚠️ CalDAV 2-Way ETag Conflict Detected (Never Silently Overwrites)</h4>
              {calConflicts
                .filter((c) => !c.resolved)
                .map((cf) => (
                  <div key={cf.conflict_id} className="odysseus-row-between">
                    <span>
                      Event <code>{cf.event_id}</code>: Local ETag <code>{cf.local_etag}</code> vs
                      Remote ETag <code>{cf.remote_etag}</code>
                    </span>
                    <div className="odysseus-row-wrap">
                      <button
                        type="button"
                        className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
                        onClick={() =>
                          void handleResolveCalDavConflict(cf.conflict_id, "keep_local")
                        }
                        data-testid="cal-conflict-resolve-keep_local"
                      >
                        Keep Local
                      </button>
                      <button
                        type="button"
                        className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                        onClick={() =>
                          void handleResolveCalDavConflict(cf.conflict_id, "keep_remote")
                        }
                        data-testid="cal-conflict-resolve-keep_remote"
                      >
                        Keep Remote
                      </button>
                      <button
                        type="button"
                        className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                        onClick={() => void handleResolveCalDavConflict(cf.conflict_id, "merge")}
                        data-testid="cal-conflict-resolve-merge"
                      >
                        Merge Both
                      </button>
                    </div>
                  </div>
                ))}
            </section>
          ) : null}

          {/* Natural-Language Quick Add */}
          <section className="odysseus-card" aria-label="Natural language event quick add">
            <h3>Natural-Language Quick-Add (Deterministic Grammar First)</h3>
            <div className="odysseus-row-wrap">
              <input
                aria-label="Natural language event input"
                className="odysseus-input"
                value={quickAddText}
                onChange={(e) => setQuickAddText(e.target.value)}
                data-testid="cal-quick-add-input"
              />
              <button
                type="button"
                className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                onClick={() => void handleQuickAddPreview(false)}
                data-testid="cal-quick-add-preview-btn"
              >
                Preview Parse
              </button>
              <button
                type="button"
                className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
                onClick={() => void handleQuickAddPreview(true)}
                data-testid="cal-quick-add-commit-btn"
              >
                Create Event
              </button>
            </div>
            {quickAddPreview ? (
              <p className="odysseus-text-muted" data-testid="cal-quick-add-preview-card">
                Parsed ({quickAddPreview.parsed_by}): <strong>{quickAddPreview.title}</strong> at{" "}
                <code>{quickAddPreview.start_iso}</code> ({quickAddPreview.duration_minutes}m)
              </p>
            ) : null}
          </section>

          {/* Events & Agent-Scheduled Overlay */}
          <section className="odysseus-card" aria-label="Calendar events">
            <h3>
              {calViewMode.toUpperCase()} View — Events ({calEvents.length}) | Conflicts (
              {calConflicts.filter((c) => !c.resolved).length})
            </h3>
            <div className="odysseus-stack">
              {calEvents.map((ev) => (
                <div key={ev.id} className="odysseus-card" data-testid={`cal-event-${ev.id}`}>
                  <strong>{ev.title}</strong> — <code>{ev.start_local}</code> ({ev.timezone})
                  {ev.rrule ? (
                    <span>
                      {" "}
                      | RRULE: <code>{ev.rrule}</code>
                    </span>
                  ) : null}{" "}
                  | ETag: <code>{ev.etag}</code>
                </div>
              ))}
              {showAgentOverlay
                ? schedules.map((s) => (
                    <div
                      key={`overlay_${s.id}`}
                      className="odysseus-card"
                      data-testid={`cal-agent-overlay-${s.id}`}
                    >
                      🤖 <strong>[Agent Scheduled] {s.name}</strong> — Next:{" "}
                      <code>{s.next_runs[0] ?? "n/a"}</code> ({s.cron_expr})
                    </div>
                  ))
                : null}
            </div>
          </section>
        </div>
      ) : null}

      {/* 4. SCHEDULES, NOTIFICATIONS, WEBHOOKS & API TOKENS (FE-WORK-07, FE-ADMIN-04, FE-AGENT-14) */}
      {activeTab === "schedules" ? (
        <div className="odysseus-stack" data-testid="schedules-workspace-pane">
          <div className="odysseus-settings-grid">
            {/* Cron Schedules & Circuit Breaker */}
            <section className="odysseus-card" aria-label="Schedules and Automations">
              <h3>Scheduled Automations ({schedules.length})</h3>
              <form onSubmit={(e) => void handleCreateSchedule(e)} className="odysseus-stack">
                <div className="odysseus-row-wrap">
                  <input
                    aria-label="Schedule name"
                    className="odysseus-input"
                    placeholder="Schedule name…"
                    value={newSchedName}
                    onChange={(e) => setNewSchedName(e.target.value)}
                    data-testid="sched-create-name"
                  />
                  <input
                    aria-label="Cron expression"
                    className="odysseus-input"
                    value={newSchedCron}
                    onChange={(e) => setNewSchedCron(e.target.value)}
                    data-testid="sched-create-cron"
                  />
                  <input
                    aria-label="Prompt template"
                    className="odysseus-input"
                    value={newSchedPrompt}
                    onChange={(e) => setNewSchedPrompt(e.target.value)}
                    data-testid="sched-create-prompt"
                  />
                  <button
                    type="submit"
                    className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
                    data-testid="sched-create-submit"
                  >
                    Create Schedule
                  </button>
                </div>
                <p className="odysseus-text-muted" data-testid="sched-cron-human-preview">
                  Human Preview: <strong>{describeCronHumanReadable(newSchedCron)}</strong>
                </p>
              </form>

              {lastScheduleRunStatus ? (
                <p role="status" data-testid="sched-last-run-status">
                  Last Manual Trigger: <code>{lastScheduleRunStatus}</code>
                </p>
              ) : null}

              <div className="odysseus-stack">
                {schedules.map((s) => (
                  <div key={s.id} className="odysseus-card" data-testid={`sched-card-${s.id}`}>
                    <div className="odysseus-row-between">
                      <div>
                        <strong>{s.name}</strong> — <code>{s.cron_expr}</code> (
                        {describeCronHumanReadable(s.cron_expr)} · {s.timezone})
                      </div>
                      <div className="odysseus-row-wrap">
                        <span className="odysseus-badge" data-testid={`sched-badge-${s.id}`}>
                          {s.health_badge}
                        </span>
                        <button
                          type="button"
                          className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                          onClick={() => void handleToggleSchedule(s.id, !s.enabled)}
                          data-testid={`sched-toggle-${s.id}`}
                        >
                          {s.enabled ? "Disable" : "Enable"}
                        </button>
                        <button
                          type="button"
                          className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
                          onClick={() => void handleRunScheduleNow(s.id)}
                          data-testid={`sched-run-now-${s.id}`}
                        >
                          ▶ Run Now
                        </button>
                      </div>
                    </div>
                    <p className="odysseus-text-muted">
                      Next 5 runs: <code>{s.next_runs.slice(0, 5).join(", ") || "n/a"}</code> |
                      Misfire: <code>{s.misfire_policy}</code> | Errors: {s.consecutive_errors}
                    </p>
                  </div>
                ))}
              </div>
            </section>

            {/* Notifications Inbox (FE-AGENT-14) */}
            <section className="odysseus-card" aria-label="Notifications Inbox">
              <h3>Notifications Inbox ({notifications.length})</h3>
              <div className="odysseus-stack" data-testid="notifications-inbox-list">
                {notifications.map((n) => (
                  <div key={n.id} className="odysseus-card" data-testid={`notif-item-${n.id}`}>
                    <div className="odysseus-row-between">
                      <strong>
                        [{n.severity.toUpperCase()}] {n.title}
                      </strong>
                      {!n.read ? (
                        <button
                          type="button"
                          className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                          onClick={() => void handleMarkNotificationRead(n.id)}
                          data-testid={`notif-mark-read-${n.id}`}
                        >
                          Mark Read
                        </button>
                      ) : (
                        <span className="odysseus-badge">Read</span>
                      )}
                    </div>
                    <p>{n.body}</p>
                    <p className="odysseus-text-muted">
                      Channels: <code>{n.channels_delivered.join(", ")}</code> (
                      {n.delivery_latency_ms} ms)
                    </p>
                  </div>
                ))}
              </div>
            </section>
          </div>

          <div className="odysseus-settings-grid">
            {/* Scoped API Tokens (FE-ADMIN-04) */}
            <section className="odysseus-card" aria-label="Scoped API Tokens">
              <h3>Scoped Personal API Tokens (Shown Once)</h3>
              <form onSubmit={(e) => void handleMintToken(e)} className="odysseus-row-wrap">
                <input
                  aria-label="New API token name"
                  className="odysseus-input"
                  placeholder="Token name (e.g. Laptop CLI)…"
                  value={newTokenName}
                  onChange={(e) => setNewTokenName(e.target.value)}
                  data-testid="token-create-name"
                />
                <button
                  type="submit"
                  className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
                  data-testid="token-create-submit"
                >
                  Mint Token
                </button>
              </form>
              {mintedTokenOnce ? (
                <div role="status" className="odysseus-card" data-testid="token-shown-once-banner">
                  Copy token now (shown once): <code>{mintedTokenOnce}</code>
                </div>
              ) : null}
              <div className="odysseus-stack">
                {tokens.map((tk) => (
                  <div key={tk.token_id} className="odysseus-row-between">
                    <span>
                      <strong>{tk.name}</strong> (<code>{tk.token_prefix}…</code>) — Scopes:{" "}
                      <code>{tk.scopes.join(", ")}</code>
                    </span>
                    <div className="odysseus-row-wrap">
                      <span className="odysseus-badge">{tk.revoked ? "Revoked" : "Active"}</span>
                      {!tk.revoked ? (
                        <button
                          type="button"
                          className="odysseus-btn odysseus-btn-danger odysseus-btn-xs"
                          onClick={() => void handleRevokeToken(tk.token_id)}
                          data-testid={`token-revoke-${tk.token_id}`}
                        >
                          Revoke
                        </button>
                      ) : null}
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* SSRF-Safe Outbound Webhooks + Dead-Letter Queue Replay */}
            <section className="odysseus-card" aria-label="Outbound Webhooks">
              <h3>SSRF-Safe Outbound Webhooks & Dead-Letter Queue</h3>
              <form
                onSubmit={(e) => void handleRegisterOutboundWebhook(e)}
                className="odysseus-row-wrap"
              >
                <input
                  aria-label="Outbound webhook target URL"
                  className="odysseus-input"
                  value={webhookUrl}
                  onChange={(e) => setWebhookUrl(e.target.value)}
                  data-testid="webhook-target-url-input"
                />
                <button
                  type="submit"
                  className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
                  data-testid="webhook-register-submit"
                >
                  Register Webhook
                </button>
              </form>
              {webhookError ? (
                <p role="alert" className="odysseus-error" data-testid="webhook-ssrf-error">
                  {webhookError}
                </p>
              ) : null}
              <div className="odysseus-stack">
                {webhooks.map((wh) => (
                  <div key={wh.webhook_id} className="odysseus-row-between">
                    <span>
                      <strong>{wh.name}</strong> → <code>{wh.target_url}</code>
                    </span>
                    <button
                      type="button"
                      className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                      onClick={() => void handleSimulateWebhookDlq(wh.webhook_id)}
                      data-testid={`webhook-simulate-dlq-${wh.webhook_id}`}
                    >
                      Simulate 3× Failure (DLQ)
                    </button>
                  </div>
                ))}
                {deadLetters.map((dlq) => (
                  <div
                    key={dlq.delivery_id}
                    className="odysseus-row-between"
                    data-testid={`dlq-item-${dlq.delivery_id}`}
                  >
                    <span>
                      ⚠️ Dead-Letter <code>{dlq.delivery_id}</code> ({dlq.attempts} attempts)
                    </span>
                    <button
                      type="button"
                      className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
                      onClick={() => void handleReplayDeadLetter(dlq.delivery_id)}
                      data-testid="webhook-dlq-replay-btn"
                    >
                      Replay DLQ
                    </button>
                  </div>
                ))}
              </div>
            </section>
          </div>
        </div>
      ) : null}
    </div>
  );
}
