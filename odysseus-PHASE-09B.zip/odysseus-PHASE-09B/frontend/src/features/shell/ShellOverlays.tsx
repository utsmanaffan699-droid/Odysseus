import React, { useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { Button, Dialog, Input } from "../../design-system/primitives";
import type {
  ChatSummaryItem,
  OdysseusApiClient,
  ProjectItem,
  ProviderModelCapability,
} from "../../lib/contracts/api.gen";
import { exportDiagnosticsJson, recordClientDiagnostic } from "../../lib/diagnostics";
import { useAppShellStore } from "../../lib/store";

// Route Error Boundary with "Copy Diagnostics" (FE-SHELL-15, FE-QA-08)
interface ErrorBoundaryState {
  hasError: boolean;
  errorMessage: string;
}

export class RouteErrorBoundary extends React.Component<
  { readonly children: React.ReactNode },
  ErrorBoundaryState
> {
  constructor(props: { readonly children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, errorMessage: "" };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, errorMessage: error.message || "Unexpected UI error" };
  }

  override componentDidCatch(error: Error): void {
    recordClientDiagnostic({
      category: "route_boundary",
      message: error.message,
    });
  }

  override render(): React.ReactNode {
    if (this.state.hasError) {
      return (
        <div className="odysseus-card odysseus-error" role="alert" data-testid="route-error-boundary">
          <h2>Something went wrong in this view</h2>
          <p>{this.state.errorMessage}</p>
          <div className="odysseus-row-wrap">
            <Button
              variant="secondary"
              onClick={() => {
                const bundle = exportDiagnosticsJson();
                if (typeof navigator !== "undefined" && navigator.clipboard) {
                  void navigator.clipboard.writeText(bundle).catch(() => {});
                }
              }}
              data-testid="copy-diagnostics-btn"
            >
              Copy Diagnostics
            </Button>
            <Button
              variant="primary"
              onClick={() => this.setState({ hasError: false, errorMessage: "" })}
            >
              Recover View
            </Button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

// Command Palette (Ctrl/Cmd+K, FE-SHELL-06)
export function CommandPaletteModal({
  open,
  onClose,
  chats,
  models,
  onNewChat,
  onSelectChat,
  onSelectModel,
}: {
  readonly open: boolean;
  readonly onClose: () => void;
  readonly chats: ReadonlyArray<ChatSummaryItem>;
  readonly models: ReadonlyArray<ProviderModelCapability>;
  readonly onNewChat: () => void;
  readonly onSelectChat: (chatId: string) => void;
  readonly onSelectModel: (model: string) => void;
}): React.ReactElement | null {
  const { t } = useTranslation();
  const { setWorkspace, setTheme, theme } = useAppShellStore();
  const [query, setQuery] = useState("");

  const items = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list: Array<{ id: string; label: string; category: string; run: () => void }> = [
      {
        id: "act_new_chat",
        label: "New Chat",
        category: "Action",
        run: () => {
          onNewChat();
          onClose();
        },
      },
      {
        id: "act_toggle_theme",
        label: `Switch Theme (current: ${theme})`,
        category: "Appearance",
        run: () => {
          setTheme(theme === "dark" ? "light" : "dark");
          onClose();
        },
      },
      {
        id: "act_open_settings",
        label: "Open Runtime Settings",
        category: "Navigation",
        run: () => {
          setWorkspace("settings");
          onClose();
        },
      },
      {
        id: "act_open_providers",
        label: "Open Providers & Models",
        category: "Navigation",
        run: () => {
          setWorkspace("providers");
          onClose();
        },
      },
      {
        id: "act_open_storybook",
        label: "Open Design System Storybook",
        category: "Navigation",
        run: () => {
          setWorkspace("storybook");
          onClose();
        },
      },
    ];

    for (const c of chats.slice(0, 15)) {
      list.push({
        id: `chat_${c.id}`,
        label: `Chat: ${c.title}`,
        category: "Recent Chat",
        run: () => {
          onSelectChat(c.id);
          onClose();
        },
      });
    }

    for (const m of models) {
      list.push({
        id: `model_${m.model}`,
        label: `Use Model: ${m.model}`,
        category: "Model",
        run: () => {
          onSelectModel(m.model);
          onClose();
        },
      });
    }

    if (!q) return list;
    return list.filter(
      (item) =>
        item.label.toLowerCase().includes(q) || item.category.toLowerCase().includes(q),
    );
  }, [query, theme, chats, models, onNewChat, onClose, setTheme, setWorkspace, onSelectChat, onSelectModel]);

  return (
    <Dialog
      open={open}
      onClose={onClose}
      testId="command-palette-dialog"
    >
      <Input
        id="cmdk-input"
        placeholder={t("commandPalettePlaceholder")}
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        data-testid="cmdk-input"
      />
      <div className="odysseus-cmdk-list" role="listbox" aria-label="Command results">
        {items.map((item) => (
          <button
            key={item.id}
            type="button"
            role="option"
            aria-selected={false}
            className="odysseus-cmdk-item"
            onClick={item.run}
            data-testid={`cmdk-item-${item.id}`}
          >
            <span>{item.label}</span>
            <span className="odysseus-badge">{item.category}</span>
          </button>
        ))}
      </div>
    </Dialog>
  );
}

// Keyboard Shortcuts Cheat-Sheet Overlay (`?`, FE-SHELL-07)
export function ShortcutsOverlayModal({
  open,
  onClose,
}: {
  readonly open: boolean;
  readonly onClose: () => void;
}): React.ReactElement | null {
  const { keybindings } = useAppShellStore();

  return (
    <Dialog
      open={open}
      onClose={onClose}
      testId="shortcuts-modal"
    >
      <ul className="odysseus-shortcuts-list">
        <li>
          <span>New Chat</span> <kbd className="odysseus-kbd">{keybindings["newChat"] ?? "Alt+N"}</kbd>
        </li>
        <li>
          <span>Command Palette</span> <kbd className="odysseus-kbd">Ctrl+K</kbd>
        </li>
        <li>
          <span>Focus Composer</span> <kbd className="odysseus-kbd">/</kbd>
        </li>
        <li>
          <span>Next / Previous Message</span> <kbd className="odysseus-kbd">j / k</kbd>
        </li>
        <li>
          <span>In-Chat Find</span> <kbd className="odysseus-kbd">Ctrl+F</kbd>
        </li>
        <li>
          <span>Stop Active Run</span> <kbd className="odysseus-kbd">Esc</kbd>
        </li>
        <li>
          <span>Keyboard Shortcuts Help</span> <kbd className="odysseus-kbd">?</kbd>
        </li>
      </ul>
    </Dialog>
  );
}

// Projects Manager View (FE-SHELL-04)
export function ProjectsManagerView({
  apiClient,
  projects,
  onProjectsRefresh,
  onSelectProjectChat,
}: {
  readonly apiClient: OdysseusApiClient;
  readonly projects: ReadonlyArray<ProjectItem>;
  readonly onProjectsRefresh: () => Promise<void>;
  readonly onSelectProjectChat: (projectId: string) => void;
}): React.ReactElement {
  const { t } = useTranslation();
  const { addToast } = useAppShellStore();
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [instructions, setInstructions] = useState("");
  const [budget, setBudget] = useState(2048);

  const handleCreate = async (e: React.FormEvent): Promise<void> => {
    e.preventDefault();
    if (!name.trim()) return;
    try {
      await apiClient.createProject({
        name: name.trim(),
        description: description.trim(),
        instructions: instructions.trim(),
        token_budget: budget,
      });
      setName("");
      setDescription("");
      setInstructions("");
      await onProjectsRefresh();
      addToast({ message: "Project created", variant: "success" });
    } catch (err) {
      addToast({
        message: err instanceof Error ? err.message : "Failed to create project",
        variant: "error",
      });
    }
  };

  return (
    <section className="odysseus-projects-page" data-testid="projects-view">
      <div className="odysseus-card">
        <h2>{t("newProject")} (FE-SHELL-04)</h2>
        <form onSubmit={(e) => void handleCreate(e)} className="odysseus-settings-grid">
          <Input
            id="proj-name"
            label="Project Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            data-testid="project-name-input"
          />
          <Input
            id="proj-desc"
            label="Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
          <Input
            id="proj-instr"
            label="Project System Instructions"
            value={instructions}
            onChange={(e) => setInstructions(e.target.value)}
            data-testid="project-instructions-input"
          />
          <Input
            id="proj-budget"
            label="Context Token Budget"
            type="number"
            value={String(budget)}
            onChange={(e) => setBudget(Number.parseInt(e.target.value, 10) || 2048)}
          />
          <div className="odysseus-row-wrap">
            <Button type="submit" variant="primary" data-testid="project-create-submit">
              Create Project
            </Button>
          </div>
        </form>
      </div>

      <div className="odysseus-card">
        <h3>{t("projectsHeading")} ({projects.length})</h3>
        <div className="odysseus-model-list" data-testid="projects-list">
          {projects.map((p) => (
            <div key={p.id} className="odysseus-model-card" data-testid={`project-card-${p.id}`}>
              <div>
                <strong>{p.name}</strong>
                {p.description ? <p>{p.description}</p> : null}
                {p.instructions ? (
                  <p className="odysseus-text-muted">Instructions: {p.instructions}</p>
                ) : null}
              </div>
              <div className="odysseus-row-wrap">
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => onSelectProjectChat(p.id)}
                  data-testid={`project-open-btn-${p.id}`}
                >
                  Open Project Chats
                </Button>
                <Button
                  variant="danger"
                  size="sm"
                  onClick={() =>
                    void apiClient.deleteProject(p.id).then(() => onProjectsRefresh())
                  }
                >
                  Delete
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
