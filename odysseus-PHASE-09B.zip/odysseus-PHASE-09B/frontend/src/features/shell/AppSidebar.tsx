import React, { useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import type { ChatSummaryItem, OdysseusApiClient } from "../../lib/contracts/api.gen";
import { type WorkspaceRoute, useAppShellStore } from "../../lib/store";

export interface AppSidebarProps {
  readonly apiClient: OdysseusApiClient;
  readonly chats: ReadonlyArray<ChatSummaryItem>;
  readonly activeChatId: string | null;
  readonly username: string;
  readonly onNewChat: (temporary?: boolean) => Promise<void>;
  readonly onSelectChat: (chatId: string) => void;
  readonly onRefreshChats: () => Promise<void>;
  readonly onLogout: () => Promise<void>;
}

function groupChatDateBucket(isoStr: string): "today" | "yesterday" | "prev7" | "prev30" | "older" {
  const ts = Date.parse(isoStr);
  if (Number.isNaN(ts)) return "today";
  const diffDays = (Date.now() - ts) / (1000 * 60 * 60 * 24);
  if (diffDays < 1) return "today";
  if (diffDays < 2) return "yesterday";
  if (diffDays < 7) return "prev7";
  if (diffDays < 30) return "prev30";
  return "older";
}

export function AppSidebar({
  apiClient,
  chats,
  activeChatId,
  username,
  onNewChat,
  onSelectChat,
  onRefreshChats,
  onLogout,
}: AppSidebarProps): React.ReactElement | null {
  const { t } = useTranslation();
  const {
    sidebarOpen,
    sidebarWidth,
    activeWorkspace,
    pendingDeleteChats,
    setWorkspace,
    softDeleteChat,
    undoDeleteChat,
    addToast,
  } = useAppShellStore();

  const [searchQuery, setSearchQuery] = useState("");
  const [searchHits, setSearchHits] = useState<
    ReadonlyArray<{ message_id: string | null; chat_id: string; role: string; snippet: string }>
  >([]);
  const [renamingChatId, setRenamingChatId] = useState<string | null>(null);
  const [renameTitle, setRenameTitle] = useState("");

  const handleSearchChange = async (q: string): Promise<void> => {
    setSearchQuery(q);
    if (q.trim().length < 2) {
      setSearchHits([]);
      return;
    }
    try {
      const res = await apiClient.searchChats(q.trim());
      setSearchHits(res.results);
    } catch {
      setSearchHits([]);
    }
  };

  const visibleChats = useMemo(
    () => chats.filter((c) => !pendingDeleteChats[c.id] && !c.archived),
    [chats, pendingDeleteChats],
  );

  const pinnedChats = useMemo(
    () => visibleChats.filter((c) => c.pinned),
    [visibleChats],
  );

  const groupedRecents = useMemo(() => {
    const groups: Record<"today" | "yesterday" | "prev7" | "prev30" | "older", ChatSummaryItem[]> = {
      today: [],
      yesterday: [],
      prev7: [],
      prev30: [],
      older: [],
    };
    for (const c of visibleChats) {
      if (c.pinned) continue;
      const bucket = groupChatDateBucket(c.updated_at);
      groups[bucket].push(c);
    }
    return groups;
  }, [visibleChats]);

  const handleDeleteWithUndo = (chat: ChatSummaryItem): void => {
    softDeleteChat(chat.id, chat.title);
    const timer = setTimeout(() => {
      if (useAppShellStore.getState().pendingDeleteChats[chat.id]) {
        void apiClient.deleteChat(chat.id).then(() => onRefreshChats());
      }
    }, 10_000);

    addToast({
      message: `${t("deletedToast")}: "${chat.title}"`,
      variant: "info",
      durationMs: 10_000,
      actionLabel: t("undoAction"),
      onAction: () => {
        clearTimeout(timer);
        undoDeleteChat(chat.id);
      },
    });
  };

  const handleRenameSubmit = async (chatId: string): Promise<void> => {
    if (!renameTitle.trim()) {
      setRenamingChatId(null);
      return;
    }
    await apiClient.updateChat(chatId, { title: renameTitle.trim() });
    setRenamingChatId(null);
    await onRefreshChats();
  };

  if (!sidebarOpen) {
    return null;
  }

  const navItems: Array<{ id: WorkspaceRoute; label: string }> = [
    { id: "chat", label: t("workspaceChat") },
    { id: "mail", label: t("workspaceMail") },
    { id: "notes", label: t("workspaceNotes") },
    { id: "calendar", label: t("workspaceCalendar") },
    { id: "schedules", label: t("workspaceSchedules") },
    { id: "docs", label: t("workspaceDocs") },
    { id: "research", label: t("workspaceResearch") },
    { id: "compare", label: t("workspaceCompare") },
    { id: "memory", label: t("workspaceMemory") },
    { id: "skills", label: t("workspaceSkills") },
    { id: "mcp", label: t("workspaceMcp") },
    { id: "projects", label: t("workspaceProjects") },
    { id: "cookbook", label: t("workspaceCookbook") },
    { id: "gallery", label: t("workspaceGallery") },
    { id: "voice", label: t("workspaceVoice") },
    { id: "admin", label: t("workspaceAdmin") },
    { id: "settings", label: t("workspaceSettings") },
    { id: "providers", label: t("workspaceProviders") },
    { id: "storybook", label: t("workspaceStorybook") },
  ];

  const renderChatRow = (chat: ChatSummaryItem): React.ReactElement => {
    const isActive = chat.id === activeChatId && activeWorkspace === "chat";
    return (
      <div
        key={chat.id}
        className={`odysseus-chat-row ${isActive ? "odysseus-chat-row-active" : ""}`}
        data-testid={`sidebar-chat-item-${chat.id}`}
      >
        {renamingChatId === chat.id ? (
          <input
            aria-label="Rename chat title"
            className="odysseus-input"
            value={renameTitle}
            onChange={(e) => setRenameTitle(e.target.value)}
            onBlur={() => void handleRenameSubmit(chat.id)}
            onKeyDown={(e) => {
              if (e.key === "Enter") void handleRenameSubmit(chat.id);
            }}
            data-testid="sidebar-rename-input"
          />
        ) : (
          <button
            type="button"
            className="odysseus-chat-row-btn"
            onClick={() => {
              setWorkspace("chat");
              onSelectChat(chat.id);
            }}
          >
            <span className="odysseus-chat-row-title">
              {chat.temporary ? "⏳ " : ""}
              {chat.title}
            </span>
          </button>
        )}

        <div className="odysseus-chat-row-actions">
          <button
            type="button"
            className="odysseus-code-btn"
            aria-label={chat.pinned ? t("unpinChat") : t("pinChat")}
            onClick={() =>
              void apiClient
                .updateChat(chat.id, { pinned: !chat.pinned })
                .then(() => onRefreshChats())
            }
            data-testid={`chat-pin-${chat.id}`}
          >
            {chat.pinned ? "★" : "☆"}
          </button>
          <button
            type="button"
            className="odysseus-code-btn"
            aria-label={t("renameChat")}
            onClick={() => {
              setRenamingChatId(chat.id);
              setRenameTitle(chat.title);
            }}
            data-testid={`chat-rename-${chat.id}`}
          >
            ✎
          </button>
          <button
            type="button"
            className="odysseus-code-btn"
            aria-label={t("deleteChat")}
            onClick={() => handleDeleteWithUndo(chat)}
            data-testid={`chat-delete-${chat.id}`}
          >
            🗑
          </button>
        </div>
      </div>
    );
  };

  return (
    <aside
      className="odysseus-sidebar"
      style={{ width: `${sidebarWidth}px` }}
      aria-label="Primary Navigation Sidebar"
      data-testid="app-sidebar"
    >
      <div className="odysseus-sidebar-top">
        <button
          type="button"
          className="odysseus-btn odysseus-btn-primary"
          onClick={() => void onNewChat(false)}
          data-testid="sidebar-new-chat"
        >
          + {t("newChat")}
        </button>
        <button
          type="button"
          className="odysseus-btn odysseus-btn-secondary odysseus-btn-sm"
          onClick={() => void onNewChat(true)}
          data-testid="sidebar-temp-chat"
        >
          ⏳ {t("temporaryChat")}
        </button>
      </div>

      {/* Full-Text Search Input (FE-SHELL-02) */}
      <div className="odysseus-sidebar-search">
        <input
          type="search"
          aria-label={t("searchPlaceholder")}
          placeholder={t("searchPlaceholder")}
          className="odysseus-input"
          value={searchQuery}
          onChange={(e) => void handleSearchChange(e.target.value)}
          data-testid="sidebar-search-input"
        />
        {searchHits.length > 0 ? (
          <div className="odysseus-search-results" data-testid="sidebar-search-results">
            {searchHits.map((hit, i) => (
              <button
                key={hit.message_id ?? `${hit.chat_id}_${i}`}
                type="button"
                className="odysseus-search-hit"
                onClick={() => {
                  setWorkspace("chat");
                  onSelectChat(hit.chat_id);
                  if (hit.message_id) {
                    window.location.hash = `#m=${hit.message_id}`;
                  }
                  setSearchHits([]);
                }}
              >
                <small>{hit.role}</small>
                <span>{hit.snippet.replaceAll("<mark>", "").replaceAll("</mark>", "")}</span>
              </button>
            ))}
          </div>
        ) : null}
      </div>

      {/* Workspace Switcher (FE-SHELL-08) */}
      <nav className="odysseus-workspace-nav" aria-label="Workspaces">
        {navItems.map((w) => (
          <button
            key={w.id}
            type="button"
            className={`odysseus-ws-btn ${activeWorkspace === w.id ? "odysseus-ws-btn-active" : ""}`}
            onClick={() => setWorkspace(w.id)}
            data-testid={`workspace-nav-${w.id}`}
          >
            {w.label}
          </button>
        ))}
      </nav>

      {/* Pinned & Recent Chats List (FE-SHELL-01, 03) */}
      <div className="odysseus-sidebar-chats" data-testid="sidebar-chats-list">
        {pinnedChats.length > 0 ? (
          <div className="odysseus-chat-group">
            <h4 className="odysseus-group-heading">{t("pinnedChats")}</h4>
            {pinnedChats.map(renderChatRow)}
          </div>
        ) : null}

        {(
          [
            ["today", t("groupToday")],
            ["yesterday", t("groupYesterday")],
            ["prev7", t("groupPrev7Days")],
            ["prev30", t("groupPrev30Days")],
            ["older", t("groupOlder")],
          ] as const
        ).map(([bucket, label]) => {
          const items = groupedRecents[bucket];
          if (items.length === 0) return null;
          return (
            <div key={bucket} className="odysseus-chat-group">
              <h4 className="odysseus-group-heading">{label}</h4>
              {items.map(renderChatRow)}
            </div>
          );
        })}
      </div>

      <footer className="odysseus-sidebar-footer">
        <span className="odysseus-user-pill" data-testid="sidebar-username">
          👤 {username}
        </span>
        <button
          type="button"
          className="odysseus-code-btn"
          onClick={() => void onLogout()}
          data-testid="logout-btn"
        >
          {t("logoutButton")}
        </button>
      </footer>
    </aside>
  );
}
