import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import { setAppLocale, type SupportedLocale } from "../../i18n";
import type { OdysseusApiClient, ProviderModelCapability } from "../../lib/contracts/api.gen";
import { useAppShellStore } from "../../lib/store";
import { Icon } from "../../brand/Icon";
import { brand } from "../../brand/config";

export interface AppTopBarProps {
  readonly apiClient: OdysseusApiClient;
  readonly chatId: string | null;
  readonly chatTitle: string;
  readonly isTemporaryChat: boolean;
  readonly capabilities: ReadonlyArray<ProviderModelCapability>;
  readonly onRenameTitle: (newTitle: string) => Promise<void>;
  readonly runningRunsCount?: number;
  readonly pendingApprovalsCount?: number;
  readonly onOpenAgentHub?: (tab: "runs" | "presets" | "policies") => void;
  readonly onToggleArtifactsPanel?: () => void;
  readonly artifactsPanelOpen?: boolean;
}

export function AppTopBar({
  apiClient,
  chatId,
  chatTitle,
  isTemporaryChat,
  capabilities,
  onRenameTitle,
  runningRunsCount = 0,
  pendingApprovalsCount = 0,
  onOpenAgentHub,
  onToggleArtifactsPanel,
  artifactsPanelOpen = false,
}: AppTopBarProps): React.ReactElement {
  const { t } = useTranslation();
  const {
    sidebarOpen,
    inspectorOpen,
    theme,
    locale,
    selectedModel,
    connectionStatus,
    degradedServices,
    toggleSidebar,
    toggleInspector,
    setTheme,
    setLocale,
    setSelectedModel,
    setWorkspace,
    setCommandPaletteOpen,
    setShortcutsOpen,
  } = useAppShellStore();

  const [editingTitle, setEditingTitle] = useState(false);
  const [titleDraft, setTitleDraft] = useState(chatTitle);

  const handleExport = async (format: "md" | "json" | "html" | "pdf"): Promise<void> => {
    if (!chatId) return;
    if (format === "pdf") {
      window.print();
      return;
    }
    try {
      const apiFormat = format === "md" ? "markdown" : format;
      const res = await apiClient.exportChat(chatId, apiFormat);
      const blob = new Blob([res.content], { type: "text/plain;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${(res.title || "chat").replace(/[^a-z0-9-_]/gi, "_")}.${format}`;
      a.click();
      URL.revokeObjectURL(url);
    } catch {
      // Export failed
    }
  };

  const handleLocaleChange = (nextLocale: SupportedLocale): void => {
    setLocale(nextLocale);
    void setAppLocale(nextLocale);
  };

  const cycleTheme = (): void => {
    const next = theme === "dark" ? "light" : theme === "light" ? "high-contrast" : "dark";
    setTheme(next);
  };

  return (
    <header className="odysseus-topbar" data-testid="app-topbar">
      <div className="odysseus-topbar-left">
        <div className="odysseus-brand-lockup" aria-label={brand.productName}>
          <img src="/brand/logo/glyph.svg" alt="" aria-hidden="true" />
          <strong>{brand.productName}</strong>
        </div>
        <button
          type="button"
          className="odysseus-btn odysseus-btn-secondary odysseus-btn-sm"
          onClick={toggleSidebar}
          aria-expanded={sidebarOpen}
          data-testid="sidebar-toggle"
        >
          <Icon name="menu" /> <span>{t("sidebarToggle")}</span>
        </button>

        {/* Editable Chat Title (FE-SHELL-05) */}
        {editingTitle ? (
          <input
            aria-label="Conversation title"
            className="odysseus-input odysseus-topbar-title-input"
            value={titleDraft}
            onChange={(e) => setTitleDraft(e.target.value)}
            onBlur={() => {
              setEditingTitle(false);
              if (titleDraft.trim()) void onRenameTitle(titleDraft.trim());
            }}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                setEditingTitle(false);
                if (titleDraft.trim()) void onRenameTitle(titleDraft.trim());
              }
            }}
            data-testid="topbar-title-input"
          />
        ) : (
          <button
            type="button"
            className="odysseus-topbar-title-btn"
            onClick={() => {
              setTitleDraft(chatTitle);
              setEditingTitle(true);
            }}
            data-testid="topbar-chat-title"
          >
            <strong>{chatTitle || t("appTitle")}</strong>
            {isTemporaryChat ? (
              <span className="odysseus-badge odysseus-badge-warning" data-testid="temp-chat-badge">
                {t("temporaryChatBadge")}
              </span>
            ) : null}
          </button>
        )}

        {/* Model Selector with Capability Badges (FE-SHELL-05) */}
        <div className="odysseus-model-picker-wrap">
          <span className="odysseus-health-dot odysseus-health-ok" aria-hidden="true" />
          <select
            aria-label={t("modelSelectorLabel")}
            className="odysseus-select odysseus-model-select"
            value={selectedModel}
            onChange={(e) => setSelectedModel(e.target.value)}
            data-testid="model-selector"
          >
            {capabilities.length === 0 ? (
              <option value={selectedModel}>{selectedModel}</option>
            ) : (
              capabilities.map((cap) => (
                <option key={cap.model} value={cap.model}>
                  {cap.model} ({cap.provider} · {Math.round(cap.context_window / 1000)}k)
                </option>
              ))
            )}
          </select>
        </div>
      </div>

      <div className="odysseus-topbar-right">
        {/* Connection & Degraded Services Chip (FE-SHELL-17, Acceptance #8) */}
        <span
          className={`odysseus-conn-chip odysseus-conn-${connectionStatus === "connected" ? "online" : connectionStatus}`}
          role="status"
          data-testid="connection-status-chip"
          data-status={connectionStatus}
        >
          ●{" "}
          {connectionStatus === "connected"
            ? t("statusOnline")
            : connectionStatus === "reconnecting"
              ? t("statusReconnecting")
              : t("statusOffline")}
          {degradedServices.length > 0
            ? ` (${degradedServices.map((d) => d.service).join(", ")})`
            : ""}
        </span>

        {/* Export Menu (FE-MSG-17) */}
        {chatId ? (
          <select
            aria-label={t("exportChat")}
            className="odysseus-select odysseus-export-select"
            value=""
            onChange={(e) => {
              const fmt = e.target.value as "md" | "json" | "html" | "pdf";
              if (fmt) void handleExport(fmt);
            }}
            data-testid="export-chat-select"
          >
            <option value="">{t("exportChat")}…</option>
            <option value="md">{t("exportMarkdown")}</option>
            <option value="json">{t("exportJson")}</option>
            <option value="html">{t("exportHtml")}</option>
            <option value="pdf">{t("exportPdf")}</option>
          </select>
        ) : null}

        {/* Background Runs & Pending Approvals Tray (FE-AGENT-05, 14) */}
        {onOpenAgentHub ? (
          <>
            <button
              type="button"
              className="odysseus-btn odysseus-btn-secondary odysseus-btn-sm"
              onClick={() => onOpenAgentHub("runs")}
              data-testid="background-runs-tray-btn"
            >
              Running ({runningRunsCount})
            </button>
            {pendingApprovalsCount > 0 ? (
              <button
                type="button"
                className="odysseus-btn odysseus-btn-danger odysseus-btn-sm"
                onClick={() => onOpenAgentHub("policies")}
                data-testid="pending-approvals-tray-btn"
              >
                <Icon name="approval" /> Pending approvals ({pendingApprovalsCount})
              </button>
            ) : null}
            <button
              type="button"
              className="odysseus-btn odysseus-btn-secondary odysseus-btn-sm"
              onClick={() => onOpenAgentHub("presets")}
              data-testid="agent-hub-trigger-btn"
            >
              Agents & History
            </button>
          </>
        ) : null}

        {/* Artifacts Canvas Toggle (FE-ART-01) */}
        {onToggleArtifactsPanel ? (
          <button
            type="button"
            className="odysseus-btn odysseus-btn-secondary odysseus-btn-sm"
            aria-expanded={artifactsPanelOpen}
            onClick={onToggleArtifactsPanel}
            data-testid="artifacts-toggle-btn"
          >
            Canvas
          </button>
        ) : null}

        {/* Notifications Inbox Trigger (FE-AGENT-14) */}
        <button
          type="button"
          className="odysseus-btn odysseus-btn-secondary odysseus-btn-sm"
          onClick={() => setWorkspace("schedules")}
          aria-label="Open Notifications and Automations"
          data-testid="notifications-bell-btn"
        >
          <Icon name="health" /> Alerts
        </button>

        {/* Command Palette Trigger */}
        <button
          type="button"
          className="odysseus-btn odysseus-btn-secondary odysseus-btn-sm"
          onClick={() => setCommandPaletteOpen(true)}
          aria-label="Open Command Palette"
          data-testid="cmdk-trigger-btn"
        >
          ⌘K
        </button>

        {/* Shortcuts Help Trigger */}
        <button
          type="button"
          className="odysseus-btn odysseus-btn-secondary odysseus-btn-sm"
          onClick={() => setShortcutsOpen(true)}
          aria-label="Keyboard Shortcuts"
          data-testid="shortcuts-trigger-btn"
        >
          ?
        </button>

        {/* Theme Switcher (FE-SHELL-10) */}
        <button
          type="button"
          className="odysseus-btn odysseus-btn-secondary odysseus-btn-sm"
          onClick={cycleTheme}
          data-testid="theme-toggle"
        >
          {t("themeToggle")}: {theme}
        </button>

        {/* Locale Switcher (FE-SHELL-18: en, id, en-XA) */}
        <select
          aria-label={t("localeLabel")}
          className="odysseus-select odysseus-locale-select"
          value={locale}
          onChange={(e) => handleLocaleChange(e.target.value as SupportedLocale)}
          data-testid="locale-select"
        >
          <option value="en">EN</option>
          <option value="id">ID</option>
          <option value="en-XA">en-XA</option>
        </select>

        {/* 3rd-Pane Inspector Toggle (FE-SHELL-14) */}
        <button
          type="button"
          className="odysseus-btn odysseus-btn-secondary odysseus-btn-sm"
          onClick={toggleInspector}
          aria-expanded={inspectorOpen}
          data-testid="inspector-toggle-btn"
        >
          <Icon name="activity" label="Inspector" />
        </button>
      </div>
    </header>
  );
}
