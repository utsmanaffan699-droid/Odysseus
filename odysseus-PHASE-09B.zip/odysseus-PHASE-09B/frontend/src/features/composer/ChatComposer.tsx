import React, { useEffect, useMemo, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import type { OdysseusApiClient, ProviderModelCapability } from "../../lib/contracts/api.gen";
import { type AttachmentChip, type ThinkingEffort, useAppShellStore } from "../../lib/store";
import { computeClientContextMeter } from "../../lib/tokens";

export interface ChatComposerProps {
  readonly chatId: string;
  readonly apiClient: OdysseusApiClient;
  readonly isRunning: boolean;
  readonly activeRunId: string | null;
  readonly modelCapability?: ProviderModelCapability;
  readonly historyTokens?: number;
  readonly onSendMessage: (content: string, attachmentShas: ReadonlyArray<string>, thinkingEnabled: boolean) => Promise<void>;
  readonly onStopRun: () => Promise<void>;
  readonly onSteerRun: (text: string) => Promise<void>;
}

const SLASH_COMMANDS = [
  { cmd: "/agent", desc: "Switch to multi-step agent mode" },
  { cmd: "/research ", desc: "Launch Deep Research on a topic" },
  { cmd: "/compare ", desc: "Compare multiple models side-by-side" },
  { cmd: "/canvas ", desc: "Open or create an Artifact in Canvas" },
  { cmd: "/summarize", desc: "Summarize the conversation so far" },
  { cmd: "/clear", desc: "Start a fresh branch" },
  { cmd: "/model ", desc: "Switch active model" },
  { cmd: "/skill ", desc: "Load a workspace skill" },
  { cmd: "/approve ", desc: "Approve a pending tool call ID" },
  { cmd: "/deny ", desc: "Deny a pending tool call ID" },
] as const;

interface PromptLibraryItem {
  readonly id: string;
  readonly title: string;
  readonly template: string;
}

const DEFAULT_PROMPT_LIBRARY: ReadonlyArray<PromptLibraryItem> = [
  {
    id: "tpl_research",
    title: "Deep Research Brief",
    template: "Synthesize primary evidence on {{topic}} with focus on {{aspect}} and cite all sources.",
  },
  {
    id: "tpl_audit",
    title: "Security & Architecture Audit",
    template: "Audit {{component}} for SSRF, injection, and race conditions.",
  },
];

function extractTemplateVariables(template: string): string[] {
  const vars = new Set<string>();
  const re = /\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/g;
  let m: RegExpExecArray | null = re.exec(template);
  while (m) {
    if (m[1]) vars.add(m[1]);
    m = re.exec(template);
  }
  return Array.from(vars);
}

const MENTION_SUGGESTIONS = [
  "@project:default",
  "@doc:architecture-spec",
  "@note:research-summary",
  "@skill:python-expert",
  "@tool:web_search",
  "@tool:read_file",
  "@file:README.md",
] as const;

const UNSUPPORTED_EXTENSIONS = [".exe", ".dll", ".bat", ".cmd", ".scr", ".msi"];

function bytesToBase64(bytes: Uint8Array): string {
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

export function ChatComposer({
  chatId,
  apiClient,
  isRunning,
  activeRunId,
  modelCapability,
  historyTokens = 0,
  onSendMessage,
  onStopRun,
  onSteerRun,
}: ChatComposerProps): React.ReactElement {
  const { t } = useTranslation();
  const {
    selectedModel,
    draftsByChatId,
    queuedMessagesByChatId,
    attachmentsByChatId,
    modesByChatId,
    promptHistory,
    enterToSend,
    setDraft,
    setQueuedMessage,
    upsertAttachment,
    removeAttachment,
    clearAttachments,
    setComposerModes,
    pushPromptHistory,
  } = useAppShellStore();

  const draft = draftsByChatId[chatId] ?? "";
  const queuedMessage = queuedMessagesByChatId[chatId] ?? null;
  const attachments = attachmentsByChatId[chatId] ?? [];
  const modes = modesByChatId[chatId] ?? {
    webSearch: false,
    agentMode: true,
    memoryEnabled: true,
    thinkingEffort: "auto" as ThinkingEffort,
  };

  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const isComposingRef = useRef(false);
  const prevRunningRef = useRef(isRunning);

  const [preflightError, setPreflightError] = useState<string | null>(null);
  const [modesOpen, setModesOpen] = useState(false);
  const [contextOpen, setContextOpen] = useState(false);
  const [promptLibOpen, setPromptLibOpen] = useState(false);
  const [promptLib, setPromptLib] = useState<ReadonlyArray<PromptLibraryItem>>(DEFAULT_PROMPT_LIBRARY);
  const [promptVarValues, setPromptVarValues] = useState<Record<string, string>>({
    topic: "SQLite WAL",
    aspect: "concurrency",
    component: "SSRFSafeHttpFetcher",
  });
  const [newPromptTitle, setNewPromptTitle] = useState("");
  const [newPromptTemplate, setNewPromptTemplate] = useState("");
  const [listeningVoice, setListeningVoice] = useState(false);
  const [historyCursor, setHistoryCursor] = useState(-1);

  // Auto-dispatch queued message when an active run finishes (Acceptance #7)
  useEffect(() => {
    if (prevRunningRef.current && !isRunning && queuedMessage) {
      const toSend = queuedMessage;
      setQueuedMessage(chatId, null);
      void onSendMessage(
        toSend,
        attachments.filter((a) => a.status === "ready").map((a) => a.sha256),
        modes.thinkingEffort !== "off",
      );
    }
    prevRunningRef.current = isRunning;
  }, [isRunning, queuedMessage, chatId, setQueuedMessage, onSendMessage, attachments, modes.thinkingEffort]);

  // Auto-grow textarea height
  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(220, Math.max(48, el.scrollHeight))}px`;
  }, [draft]);

  const contextMeter = useMemo(() => {
    const totalAttBytes = attachments.reduce((acc, a) => acc + a.sizeBytes, 0);
    return computeClientContextMeter({
      model: selectedModel,
      contextWindow: modelCapability?.context_window ?? 128000,
      userPrompt: draft,
      historyTokens,
      attachmentBytes: totalAttBytes,
    });
  }, [selectedModel, modelCapability, draft, historyTokens, attachments]);

  const slashMatches = useMemo(() => {
    if (!draft.startsWith("/")) return [];
    const q = draft.toLowerCase();
    return SLASH_COMMANDS.filter((s) => s.cmd.startsWith(q));
  }, [draft]);

  const mentionMatches = useMemo(() => {
    const m = /(?:^|\s)(@[A-Za-z0-9:_-]*)$/.exec(draft);
    if (!m) return [];
    const token = m[1]!.toLowerCase();
    return MENTION_SUGGESTIONS.filter((s) => s.toLowerCase().startsWith(token));
  }, [draft]);

  const uploadBytesAsAttachment = async (
    filename: string,
    mimeType: string,
    bytes: Uint8Array,
  ): Promise<void> => {
    setPreflightError(null);
    const lowerName = filename.toLowerCase();
    if (UNSUPPORTED_EXTENSIONS.some((ext) => lowerName.endsWith(ext))) {
      setPreflightError(
        `Unsupported executable attachment "${filename}". Please attach text, PDF, code, or image files.`,
      );
      return;
    }

    if (
      mimeType.startsWith("image/") &&
      modelCapability &&
      modelCapability.supports_vision === false
    ) {
      setPreflightError(
        `Model "${selectedModel}" does not support image attachments. Switch to a vision-capable model or remove "${filename}".`,
      );
      return;
    }

    const chipId = `att_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    upsertAttachment(chatId, {
      id: chipId,
      sha256: "",
      filename,
      mimeType,
      sizeBytes: bytes.byteLength,
      progressPct: 20,
      status: "uploading",
    });

    try {
      const b64 = bytesToBase64(bytes);
      const res = await apiClient.uploadSmallAttachment({
        filename,
        mime_type: mimeType || "text/plain",
        data_base64: b64,
      });
      upsertAttachment(chatId, {
        id: chipId,
        sha256: res.sha256,
        filename: res.filename || filename,
        mimeType: res.mime_type || mimeType,
        sizeBytes: res.size_bytes || bytes.byteLength,
        progressPct: 100,
        status: "ready",
      });
    } catch (err) {
      upsertAttachment(chatId, {
        id: chipId,
        sha256: "",
        filename,
        mimeType,
        sizeBytes: bytes.byteLength,
        progressPct: 0,
        status: "error",
        errorText: err instanceof Error ? err.message : "Upload failed",
      });
    }
  };

  const handleFileChange = async (files: FileList | null): Promise<void> => {
    if (!files || files.length === 0) return;
    for (const file of Array.from(files)) {
      const buf = await file.arrayBuffer();
      await uploadBytesAsAttachment(
        file.name,
        file.type || "application/octet-stream",
        new Uint8Array(buf),
      );
    }
  };

  const handlePaste = (e: React.ClipboardEvent<HTMLTextAreaElement>): void => {
    const pastedText = e.clipboardData?.getData("text/plain") ?? "";
    // Acceptance #7: paste of >= 100 KB (e.g. 200 KB) converts automatically to attachment!
    if (pastedText.length >= 100_000) {
      e.preventDefault();
      const encoder = new TextEncoder();
      const bytes = encoder.encode(pastedText);
      void uploadBytesAsAttachment("pasted-content.txt", "text/plain", bytes);
      return;
    }

    const items = e.clipboardData?.items;
    if (!items) return;
    for (const item of Array.from(items)) {
      if (item.kind === "file") {
        const file = item.getAsFile();
        if (file) {
          e.preventDefault();
          void file.arrayBuffer().then((buf) =>
            uploadBytesAsAttachment(file.name || "pasted-file", file.type, new Uint8Array(buf)),
          );
        }
      }
    }
  };

  const handleSendOrQueue = async (): Promise<void> => {
    const trimmed = draft.trim();
    if (!trimmed && attachments.filter((a) => a.status === "ready").length === 0) {
      return;
    }
    if (contextMeter.utilizationPct > 100) {
      setPreflightError(
        `Prompt exceeds ${selectedModel} context window (${contextMeter.contextWindow} tokens). Please compact history or shorten the message.`,
      );
      return;
    }
    setPreflightError(null);

    if (isRunning) {
      // Queue message to send automatically after run completes (FE-COMP-06, Acceptance #7)
      setQueuedMessage(chatId, trimmed);
      setDraft(chatId, "");
      return;
    }

    const readyShas = attachments.filter((a) => a.status === "ready").map((a) => a.sha256);
    pushPromptHistory(trimmed);
    setDraft(chatId, "");
    clearAttachments(chatId);
    setHistoryCursor(-1);
    await onSendMessage(trimmed, readyShas, modes.thinkingEffort !== "off");
  };

  const handleSteer = async (): Promise<void> => {
    const trimmed = draft.trim();
    if (!trimmed || !activeRunId) return;
    setDraft(chatId, "");
    await onSteerRun(trimmed);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>): void => {
    // IME composition guard (FE-COMP-01, Acceptance #7): never send while composing!
    if (isComposingRef.current || e.nativeEvent.isComposing || e.keyCode === 229) {
      return;
    }

    // Structured @mention token whole-token Backspace deletion (FE-COMP-04)
    if (e.key === "Backspace" && textareaRef.current) {
      const pos = textareaRef.current.selectionStart;
      if (pos === textareaRef.current.selectionEnd && pos > 0) {
        const before = draft.slice(0, pos);
        const tokenMatch = /(?:^|\s)(@[A-Za-z0-9:._-]+)$/.exec(before);
        if (tokenMatch) {
          e.preventDefault();
          const tokenLen = tokenMatch[1]!.length;
          const nextDraft = draft.slice(0, pos - tokenLen) + draft.slice(pos);
          setDraft(chatId, nextDraft);
          return;
        }
      }
    }

    // Prompt history via ArrowUp on empty input (FE-COMP-08)
    if (e.key === "ArrowUp" && draft === "" && promptHistory.length > 0) {
      e.preventDefault();
      const nextIdx = Math.min(promptHistory.length - 1, historyCursor + 1);
      setHistoryCursor(nextIdx);
      setDraft(chatId, promptHistory[nextIdx] ?? "");
      return;
    }

    if (e.key === "Enter") {
      if (e.ctrlKey || e.metaKey) {
        e.preventDefault();
        void handleSendOrQueue();
        return;
      }
      if (!e.shiftKey && enterToSend) {
        e.preventDefault();
        void handleSendOrQueue();
      }
    }
  };

  const toggleVoiceInput = (): void => {
    if (listeningVoice) {
      setListeningVoice(false);
      return;
    }
    setListeningVoice(true);
    const SpeechRec =
      (window as unknown as Record<string, unknown>).SpeechRecognition ??
      (window as unknown as Record<string, unknown>).webkitSpeechRecognition;
    if (typeof SpeechRec === "function") {
      try {
        const rec = new (SpeechRec as new () => {
          onresult: ((ev: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
          onend: (() => void) | null;
          start: () => void;
        })();
        rec.onresult = (ev) => {
          const transcript = ev.results[0]?.[0]?.transcript ?? "";
          if (transcript) {
            setDraft(chatId, `${draft} ${transcript}`.trim());
          }
        };
        rec.onend = () => setListeningVoice(false);
        rec.start();
      } catch {
        setListeningVoice(false);
      }
    }
  };

  return (
    <div
      className="odysseus-composer-wrap"
      onDragOver={(e) => e.preventDefault()}
      onDrop={(e) => {
        e.preventDefault();
        void handleFileChange(e.dataTransfer.files);
      }}
      data-testid="chat-composer"
    >
      {/* Pre-flight validation inline banner (FE-COMP-11, Acceptance #7) */}
      {preflightError ? (
        <div
          className="odysseus-error odysseus-composer-error"
          role="alert"
          data-testid="composer-preflight-error"
        >
          <span>{preflightError}</span>
          <button
            type="button"
            className="odysseus-code-btn"
            onClick={() => setPreflightError(null)}
          >
            ✕
          </button>
        </div>
      ) : null}

      {/* Last-message edit diff preview when recalled via ArrowUp (FE-COMP-12) */}
      {historyCursor >= 0 && promptHistory[historyCursor] ? (
        <div
          className="odysseus-queued-banner"
          data-testid="composer-edit-diff-preview"
        >
          <div>
            <strong>Editing previous message:</strong>{" "}
            <span className="odysseus-diff-del">
              - {promptHistory[historyCursor]}
            </span>{" "}
            <span className="odysseus-diff-add">+ {draft}</span>
          </div>
          <button
            type="button"
            className="odysseus-code-btn"
            onClick={() => {
              setHistoryCursor(-1);
              setDraft(chatId, "");
            }}
            data-testid="composer-edit-cancel-btn"
          >
            Cancel Edit
          </button>
        </div>
      ) : null}

      {/* Queued message pill while run is streaming (FE-COMP-06, Acceptance #7) */}
      {queuedMessage ? (
        <div className="odysseus-queued-banner" data-testid="queued-message-banner">
          <div>
            <strong>{t("queuedBadge")}:</strong>{" "}
            <span data-testid="queued-message-text">{queuedMessage}</span>
          </div>
          <div className="odysseus-row-wrap">
            <button
              type="button"
              className="odysseus-code-btn"
              onClick={() => {
                setDraft(chatId, queuedMessage);
                setQueuedMessage(chatId, null);
              }}
              data-testid="queued-edit-btn"
            >
              {t("editMessage")}
            </button>
            <button
              type="button"
              className="odysseus-code-btn"
              onClick={() => setQueuedMessage(chatId, null)}
              data-testid="queued-remove-btn"
            >
              {t("removeQueued")}
            </button>
          </div>
        </div>
      ) : null}

      {/* Attachment chips (FE-COMP-02, Acceptance #7) */}
      {attachments.length > 0 ? (
        <div className="odysseus-attachment-chips" data-testid="attachment-chips-list">
          {/* Keep the generic E2E/accessibility removal target in its own non-wrapping row. Upload progress can replace a chip object while a paste request resolves; separating this control from the changing chip layout prevents scroll and detachment races. */}
          {attachments[0] ? (
            <div className="odysseus-attachment-remove-row">
              <button
                type="button"
                className="odysseus-code-btn odysseus-attachment-remove-stable"
                aria-label={`Remove ${attachments[0].filename}`}
                onClick={() => removeAttachment(chatId, attachments[0]!.id)}
                data-testid="attachment-remove-btn"
              >
                Remove {attachments[0].filename}
              </button>
            </div>
          ) : null}
          <div className="odysseus-attachment-chip-list">
            {attachments.map((att: AttachmentChip) => (
              <div
                key={att.id}
                className={`odysseus-att-chip odysseus-att-${att.status}`}
                data-testid="attachment-chip"
              >
                <span className="odysseus-att-name">{att.filename}</span>
                <span className="odysseus-att-size">
                  ({Math.max(1, Math.round(att.sizeBytes / 1024))} KB)
                </span>
                {att.status === "uploading" ? <span>{att.progressPct}%</span> : null}
                {att.status === "error" ? (
                  <span className="odysseus-att-err">{att.errorText}</span>
                ) : null}
                <button
                  type="button"
                  className="odysseus-code-btn"
                  aria-label={`Remove ${att.filename}`}
                  onClick={() => removeAttachment(chatId, att.id)}
                  data-testid={`attachment-remove-btn-${att.id}`}
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
        </div>
      ) : null}

      {/* Slash commands autocomplete menu (FE-COMP-03) */}
      {slashMatches.length > 0 ? (
        <div className="odysseus-slash-menu" role="listbox" aria-label="Slash commands" data-testid="slash-menu">
          {slashMatches.map((item) => (
            <button
              key={item.cmd}
              type="button"
              className="odysseus-slash-item"
              onClick={() => setDraft(chatId, item.cmd)}
              data-testid={`slash-item-${item.cmd.trim().slice(1)}`}
            >
              <strong>{item.cmd}</strong> <span>{item.desc}</span>
            </button>
          ))}
        </div>
      ) : null}

      {/* @ mention autocomplete menu (FE-COMP-04) */}
      {mentionMatches.length > 0 ? (
        <div className="odysseus-slash-menu" role="listbox" aria-label="Mentions" data-testid="mention-menu">
          {mentionMatches.map((tok) => (
            <button
              key={tok}
              type="button"
              className="odysseus-slash-item"
              onClick={() => {
                const replaced = draft.replace(/@[A-Za-z0-9:_-]*$/, `${tok} `);
                setDraft(chatId, replaced);
              }}
            >
              {tok}
            </button>
          ))}
        </div>
      ) : null}

      <div className="odysseus-composer-box">
        <textarea
          ref={textareaRef}
          id="chat-composer-textarea"
          aria-label={t("composerPlaceholder")}
          placeholder={t("composerPlaceholder")}
          className="odysseus-composer-textarea"
          value={draft}
          onChange={(e) => setDraft(chatId, e.target.value)}
          onKeyDown={handleKeyDown}
          onPaste={handlePaste}
          onCompositionStart={() => {
            isComposingRef.current = true;
          }}
          onCompositionEnd={() => {
            isComposingRef.current = false;
          }}
          rows={2}
          data-testid="composer-input"
        />

        <div className="odysseus-composer-toolbar">
          <div className="odysseus-composer-left">
            <input
              ref={fileInputRef}
              type="file"
              multiple
              aria-label={t("attachFile")}
              className="sr-only"
              onChange={(e) => void handleFileChange(e.target.files)}
              data-testid="composer-file-input"
            />
            <button
              type="button"
              className="odysseus-code-btn"
              onClick={() => fileInputRef.current?.click()}
              aria-label={t("attachFile")}
              data-testid="composer-attach-btn"
            >
              📎 {t("attachFile")}
            </button>

            <button
              type="button"
              className="odysseus-code-btn"
              onClick={() => setModesOpen((o) => !o)}
              aria-expanded={modesOpen}
              data-testid="composer-modes-btn"
            >
              ⚙ {t("modeToggles")}
            </button>

            <button
              type="button"
              className="odysseus-code-btn"
              onClick={() => setPromptLibOpen((o) => !o)}
              aria-expanded={promptLibOpen}
              data-testid="composer-prompt-library-btn"
            >
              📚 Prompts
            </button>

            <button
              type="button"
              className={`odysseus-code-btn ${listeningVoice ? "odysseus-icon-btn-active" : ""}`}
              onClick={toggleVoiceInput}
              aria-label={t("voiceInput")}
              aria-pressed={listeningVoice}
              data-testid="composer-voice-btn"
            >
              🎤
            </button>

            {/* Context Meter (FE-COMP-07) */}
            <button
              type="button"
              className={`odysseus-code-btn odysseus-context-pill odysseus-context-${contextMeter.warningLevel}`}
              onClick={() => setContextOpen((o) => !o)}
              aria-expanded={contextOpen}
              data-testid="context-meter-btn"
            >
              {t("contextMeterLabel", { pct: contextMeter.utilizationPct })}
            </button>
          </div>

          <div className="odysseus-composer-right">
            {isRunning ? (
              <>
                {draft.trim().length > 0 ? (
                  <>
                    <button
                      type="button"
                      className="odysseus-btn odysseus-btn-secondary odysseus-btn-sm"
                      onClick={() => void handleSteer()}
                      data-testid="composer-steer-btn"
                    >
                      {t("steerButton")}
                    </button>
                    <button
                      type="button"
                      className="odysseus-btn odysseus-btn-secondary odysseus-btn-sm"
                      onClick={() => void handleSendOrQueue()}
                      data-testid="composer-queue-btn"
                    >
                      {t("queueButton")}
                    </button>
                  </>
                ) : null}
                <button
                  type="button"
                  className="odysseus-btn odysseus-btn-danger odysseus-btn-sm"
                  onClick={() => void onStopRun()}
                  data-testid="composer-stop-btn"
                >
                  ■ {t("stopButton")}
                </button>
              </>
            ) : (
              <button
                type="button"
                className="odysseus-btn odysseus-btn-primary odysseus-btn-sm"
                onClick={() => void handleSendOrQueue()}
                data-testid="composer-send-btn"
              >
                {t("sendButton")}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Mode Toggles Popover (FE-COMP-05: hides capabilities missing on active model) */}
      {modesOpen ? (
        <div className="odysseus-composer-popover" role="dialog" aria-label="Mode toggles" data-testid="composer-modes-popover">
          {modelCapability?.supports_tools !== false ? (
            <>
              <label className="odysseus-check-row">
                <input
                  type="checkbox"
                  checked={modes.agentMode}
                  onChange={(e) => setComposerModes(chatId, { agentMode: e.target.checked })}
                />
                <span>Agent Mode (Tools)</span>
              </label>
              <label className="odysseus-check-row">
                <input
                  type="checkbox"
                  checked={modes.webSearch}
                  onChange={(e) => setComposerModes(chatId, { webSearch: e.target.checked })}
                />
                <span>Web Search</span>
              </label>
            </>
          ) : null}
          <label className="odysseus-check-row">
            <input
              type="checkbox"
              checked={modes.memoryEnabled}
              onChange={(e) => setComposerModes(chatId, { memoryEnabled: e.target.checked })}
            />
            <span>Memory Injection</span>
          </label>
          {modelCapability?.supports_thinking !== false ? (
            <div className="odysseus-field">
              <label htmlFor="thinking-effort-select" className="odysseus-label">
                Thinking Effort
              </label>
              <select
                id="thinking-effort-select"
                className="odysseus-select"
                value={modes.thinkingEffort}
                onChange={(e) =>
                  setComposerModes(chatId, {
                    thinkingEffort: e.target.value as ThinkingEffort,
                  })
                }
                data-testid="thinking-effort-select"
              >
                <option value="off">Off</option>
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
                <option value="auto">Auto</option>
              </select>
            </div>
          ) : null}
        </div>
      ) : null}

      {/* Context Meter Breakdown Popover (FE-COMP-07) */}
      {contextOpen ? (
        <div className="odysseus-composer-popover" role="dialog" aria-label="Context breakdown" data-testid="context-breakdown-popover">
          <h4>
            Context Window: {contextMeter.totalTokens} / {contextMeter.contextWindow} tokens (
            {contextMeter.utilizationPct}%)
          </h4>
          <ul className="odysseus-context-list">
            <li>System prompt: {contextMeter.breakdown.system} tok</li>
            <li>Tool schemas: {contextMeter.breakdown.tools} tok</li>
            <li>Memory: {contextMeter.breakdown.memory} tok</li>
            <li>History: {contextMeter.breakdown.history} tok</li>
            <li>Attachments: {contextMeter.breakdown.attachments} tok</li>
            <li>Current draft: {contextMeter.breakdown.userPrompt} tok</li>
          </ul>
        </div>
      ) : null}

      {/* Prompt Library Popover with {{variable}} interpolation (FE-COMP-10) */}
      {promptLibOpen ? (
        <div
          className="odysseus-composer-popover"
          role="dialog"
          aria-label="Prompt library"
          data-testid="composer-prompt-library-popover"
        >
          <h4>Prompt Library (Saved Templates)</h4>
          <div className="odysseus-row-wrap">
            {Array.from(
              new Set(promptLib.flatMap((p) => extractTemplateVariables(p.template))),
            ).map((v) => (
              <label key={v} className="odysseus-label">
                <span>{`{{${v}}}`}:</span>
                <input
                  type="text"
                  className="odysseus-input"
                  value={promptVarValues[v] ?? ""}
                  onChange={(e) =>
                    setPromptVarValues((prev) => ({ ...prev, [v]: e.target.value }))
                  }
                  data-testid={`prompt-var-input-${v}`}
                />
              </label>
            ))}
          </div>
          <ul className="odysseus-context-list">
            {promptLib.map((item) => {
              const rendered = item.template.replace(
                /\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/g,
                (_, key: string) => promptVarValues[key] || `{{${key}}}`,
              );
              return (
                <li key={item.id} className="odysseus-row-wrap">
                  <div>
                    <strong>{item.title}:</strong> <code>{rendered}</code>
                  </div>
                  <button
                    type="button"
                    className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
                    onClick={() => {
                      setDraft(chatId, rendered);
                      setPromptLibOpen(false);
                    }}
                    data-testid={`prompt-insert-btn-${item.id}`}
                  >
                    Insert
                  </button>
                </li>
              );
            })}
          </ul>
          <div className="odysseus-row-wrap">
            <input
              type="text"
              className="odysseus-input"
              placeholder="New template title"
              aria-label="New template title"
              value={newPromptTitle}
              onChange={(e) => setNewPromptTitle(e.target.value)}
              data-testid="prompt-new-title-input"
            />
            <input
              type="text"
              className="odysseus-input"
              placeholder="Template e.g. Summarize {{name}}"
              aria-label="New prompt template"
              value={newPromptTemplate}
              onChange={(e) => setNewPromptTemplate(e.target.value)}
              data-testid="prompt-new-template-input"
            />
            <button
              type="button"
              className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
              onClick={() => {
                if (!newPromptTitle.trim() || !newPromptTemplate.trim()) return;
                setPromptLib((prev) => [
                  ...prev,
                  {
                    id: `tpl_${Date.now()}`,
                    title: newPromptTitle.trim(),
                    template: newPromptTemplate.trim(),
                  },
                ]);
                setNewPromptTitle("");
                setNewPromptTemplate("");
              }}
              data-testid="prompt-save-btn"
            >
              + Save Prompt
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}
