import React, { useMemo, useState } from "react";
import { OdysseusApiClient } from "../../../lib/contracts/api.gen";
import { explainToolCall, type ToolCallViewState } from "../../../lib/runReducer";

const apiClient = new OdysseusApiClient();

export type ToolRenderHint =
  | "text"
  | "json"
  | "table"
  | "diff"
  | "terminal"
  | "search_results"
  | "file_tree"
  | "image"
  | "browser_snapshot"
  | "kv";

export const MAX_JSON_INLINE_PARSE_BYTES = 262_144; // 256 KB fast-path parse threshold
export const MAX_JSON_TOTAL_CAP_BYTES = 50 * 1024 * 1024; // 50 MB hard cap
export const MAX_TERMINAL_SCROLLBACK_LINES = 5_000;
export const TERMINAL_VIEWPORT_LINE_WINDOW = 120;

export interface AnsiSegment {
  readonly text: string;
  readonly fg: string | null;
  readonly bold: boolean;
}

const ANSI_COLOR_MAP: Record<number, string> = {
  30: "var(--text-muted)",
  31: "var(--status-danger)",
  32: "var(--status-success)",
  33: "var(--status-warning)",
  34: "var(--accent-primary)",
  35: "var(--accent-hover)",
  36: "var(--status-info)",
  37: "var(--text-primary)",
  90: "var(--text-muted)",
  91: "var(--status-danger)",
  92: "var(--status-success)",
  93: "var(--status-warning)",
  94: "var(--accent-primary)",
  95: "var(--accent-hover)",
  96: "var(--status-info)",
  97: "var(--text-primary)",
};

const ESC_CHAR = String.fromCharCode(0x1b);
const SGR_REGEX_PATTERN = `${ESC_CHAR}\\[([0-9;]*)m`;
const NON_SGR_CSI_REGEX = new RegExp(`${ESC_CHAR}\\[[0-9;?]*[A-Za-z]`, "g");

/**
 * Parses ANSI SGR escape sequences into structured spans without innerHTML.
 * All text remains strictly inert text content inside React spans.
 */
export function parseAnsiLine(line: string): ReadonlyArray<AnsiSegment> {
  // Match CSI SGR sequences: ESC [ ... m
  const sgrRegex = new RegExp(SGR_REGEX_PATTERN, "g");
  const segments: AnsiSegment[] = [];
  let lastIdx = 0;
  let currentFg: string | null = null;
  let currentBold = false;

  let match: RegExpExecArray | null = sgrRegex.exec(line);
  while (match !== null) {
    if (match.index > lastIdx) {
      segments.push({
        text: line.slice(lastIdx, match.index),
        fg: currentFg,
        bold: currentBold,
      });
    }
    const rawCodes = match[1] ?? "0";
    const codes = rawCodes.split(";").map((c) => Number.parseInt(c || "0", 10));
    for (const code of codes) {
      if (code === 0) {
        currentFg = null;
        currentBold = false;
      } else if (code === 1) {
        currentBold = true;
      } else if (code === 22) {
        currentBold = false;
      } else if (ANSI_COLOR_MAP[code]) {
        currentFg = ANSI_COLOR_MAP[code] ?? null;
      }
    }
    lastIdx = sgrRegex.lastIndex;
    match = sgrRegex.exec(line);
  }

  if (lastIdx < line.length || segments.length === 0) {
    // Strip any non-SGR escape sequences so raw control codes never leak
    const tail = line.slice(lastIdx).replace(NON_SGR_CSI_REGEX, "");
    segments.push({
      text: tail,
      fg: currentFg,
      bold: currentBold,
    });
  }

  return segments;
}

export interface JsonInspectionResult {
  readonly isCapped: boolean;
  readonly byteLength: number;
  readonly parsed: unknown | null;
  readonly parseError: string | null;
  readonly previewSlice: string;
  readonly summaryLabel: string;
}

/**
 * Inspects JSON tool output with a strict size cap so a 50 MB payload
 * never blocks the main thread or blows up tab memory (< 100 ms, < 150 MB).
 */
export function inspectJsonPayload(
  raw: string,
  declaredByteLength?: number,
): JsonInspectionResult {
  const byteLength = Math.max(raw.length, declaredByteLength ?? 0);
  if (byteLength > MAX_JSON_INLINE_PARSE_BYTES) {
    const mb = (byteLength / (1024 * 1024)).toFixed(2);
    return {
      isCapped: true,
      byteLength,
      parsed: null,
      parseError: null,
      previewSlice: raw.slice(0, 4096),
      summaryLabel: `Large JSON payload (${mb} MB, capped above ${(
        MAX_JSON_INLINE_PARSE_BYTES / 1024
      ).toFixed(0)} KB inline limit; max ${
        MAX_JSON_TOTAL_CAP_BYTES / (1024 * 1024)
      } MB)`,
    };
  }
  try {
    const parsed: unknown = JSON.parse(raw);
    const kind = Array.isArray(parsed)
      ? `Array(${parsed.length})`
      : parsed && typeof parsed === "object"
        ? `Object(${Object.keys(parsed as Record<string, unknown>).length} keys)`
        : typeof parsed;
    return {
      isCapped: false,
      byteLength,
      parsed,
      parseError: null,
      previewSlice: raw.slice(0, 1024),
      summaryLabel: `JSON ${kind} · ${byteLength} bytes`,
    };
  } catch (err) {
    return {
      isCapped: false,
      byteLength,
      parsed: null,
      parseError: err instanceof Error ? err.message : "Invalid JSON",
      previewSlice: raw.slice(0, 1024),
      summaryLabel: `Raw text (${byteLength} bytes)`,
    };
  }
}

export function resolveEffectiveRenderHint(tc: ToolCallViewState): ToolRenderHint {
  const hint = tc.render_hint as ToolRenderHint;
  const validHints = new Set<ToolRenderHint>([
    "text",
    "json",
    "table",
    "diff",
    "terminal",
    "search_results",
    "file_tree",
    "image",
    "browser_snapshot",
    "kv",
  ]);
  if (validHints.has(hint)) {
    return hint;
  }
  if (tc.name === "run_shell") return "terminal";
  if (tc.name === "web_search") return "search_results";
  if (tc.name === "edit_file") return "diff";
  if (tc.name === "list_directory") return "file_tree";
  if (tc.name === "browser_snapshot") return "browser_snapshot";
  if (tc.name === "query_db") return "table";
  return "text";
}

// --- 1. Terminal Renderer (FE-AGENT-15) ---
export const TerminalOutputRenderer: React.FC<{
  readonly callId: string;
  readonly stdout: string;
  readonly stderr: string;
  readonly isRunning: boolean;
}> = ({ callId, stdout, stderr, isRunning }) => {
  const [followTail, setFollowTail] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [scrollOffsetLine, setScrollOffsetLine] = useState(0);
  const [copiedFull, setCopiedFull] = useState(false);
  const [fetchedFullSlice, setFetchedFullSlice] = useState<string | null>(null);

  const combinedLines = useMemo(() => {
    const outLines = stdout ? stdout.split("\n") : [];
    const errLines = stderr
      ? stderr.split("\n").map((l) => (l ? `\x1b[31m[stderr] ${l}\x1b[0m` : ""))
      : [];
    return [...outLines, ...errLines.filter(Boolean)];
  }, [stdout, stderr]);

  const totalLineCount = combinedLines.length;
  const trimmedCount = Math.max(0, totalLineCount - MAX_TERMINAL_SCROLLBACK_LINES);

  const scrollbackLines = useMemo(() => {
    const base =
      trimmedCount > 0
        ? combinedLines.slice(totalLineCount - MAX_TERMINAL_SCROLLBACK_LINES)
        : combinedLines;
    if (!searchQuery.trim()) {
      return base;
    }
    const q = searchQuery.toLowerCase();
    return base.filter((line) => line.toLowerCase().includes(q));
  }, [combinedLines, trimmedCount, totalLineCount, searchQuery]);

  // Keep DOM node count strictly bounded (<= TERMINAL_VIEWPORT_LINE_WINDOW lines rendered at once)
  const effectiveStart = useMemo(() => {
    if (followTail) {
      return Math.max(0, scrollbackLines.length - TERMINAL_VIEWPORT_LINE_WINDOW);
    }
    return Math.min(
      scrollOffsetLine,
      Math.max(0, scrollbackLines.length - TERMINAL_VIEWPORT_LINE_WINDOW),
    );
  }, [followTail, scrollbackLines.length, scrollOffsetLine]);

  const visibleLines = useMemo(
    () =>
      scrollbackLines.slice(
        effectiveStart,
        effectiveStart + TERMINAL_VIEWPORT_LINE_WINDOW,
      ),
    [scrollbackLines, effectiveStart],
  );

  const handleCopyFullOutput = async () => {
    let fullText = `${stdout}${stderr ? `\n${stderr}` : ""}`;
    try {
      const res = await apiClient.getToolCallOutput(callId, "0-1048576");
      if (res && typeof res.text === "string" && res.text.length > 0) {
        fullText = res.text;
        setFetchedFullSlice(res.text);
      }
    } catch {
      // Fallback to in-memory buffer if backend has no blob stored for synthetic fixture
    }
    try {
      await navigator.clipboard?.writeText(fullText);
    } catch {
      // Clipboard API may be unavailable in non-secure context
    }
    setCopiedFull(true);
  };

  return (
    <div className="odysseus-terminal-card" data-testid={`terminal-renderer-${callId}`}>
      <div className="odysseus-terminal-toolbar">
        <span className="odysseus-terminal-stats">
          {totalLineCount.toLocaleString()} lines
          {isRunning ? " · streaming" : ""}
        </span>
        {trimmedCount > 0 ? (
          <span
            className="odysseus-badge odysseus-badge-warning"
            data-testid="terminal-trimmed-banner"
          >
            {trimmedCount.toLocaleString()} lines trimmed (cap {MAX_TERMINAL_SCROLLBACK_LINES.toLocaleString()})
          </span>
        ) : null}
        <input
          type="search"
          className="odysseus-input odysseus-terminal-search"
          placeholder="Search terminal…"
          aria-label="Search terminal output"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          data-testid="terminal-search-input"
        />
        {scrollbackLines.length > TERMINAL_VIEWPORT_LINE_WINDOW ? (
          <input
            type="range"
            min={0}
            max={Math.max(0, scrollbackLines.length - TERMINAL_VIEWPORT_LINE_WINDOW)}
            value={effectiveStart}
            aria-label="Terminal scrollback window"
            onChange={(e) => {
              setFollowTail(false);
              setScrollOffsetLine(Number.parseInt(e.target.value, 10) || 0);
            }}
            data-testid="terminal-window-slider"
          />
        ) : null}
        <button
          type="button"
          className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
          onClick={() => setFollowTail((f) => !f)}
          data-testid="terminal-follow-toggle"
        >
          {followTail ? "Following ▸" : "Follow paused"}
        </button>
        <button
          type="button"
          className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
          onClick={() => void handleCopyFullOutput()}
          data-testid="terminal-copy-full"
        >
          {copiedFull ? "Copied full output ✓" : "Copy full output"}
        </button>
      </div>
      <pre className="odysseus-terminal-viewport" data-testid="terminal-viewport">
        {visibleLines.map((line, i) => {
          const lineNumber = trimmedCount + effectiveStart + i + 1;
          const segments = parseAnsiLine(line);
          return (
            <div key={lineNumber} className="odysseus-terminal-line">
              <span className="odysseus-terminal-gutter">{lineNumber}</span>
              <span className="odysseus-terminal-text">
                {segments.map((seg, sIdx) => (
                  <span
                    key={sIdx}
                    style={{
                      color: seg.fg ?? undefined,
                      fontWeight: seg.bold ? 600 : undefined,
                    }}
                  >
                    {seg.text}
                  </span>
                ))}
              </span>
            </div>
          );
        })}
      </pre>
      {fetchedFullSlice !== null ? (
        <div
          className="odysseus-terminal-slice-summary"
          data-testid="terminal-full-slice-status"
        >
          Fetched {fetchedFullSlice.length.toLocaleString()} bytes from{" "}
          <code>/api/tool-calls/{callId}/output</code>
        </div>
      ) : null}
    </div>
  );
};

// --- 2. JSON Tree & 50 MB Cap Renderer ---
const JsonTreeNode: React.FC<{
  readonly path: string;
  readonly label: string;
  readonly value: unknown;
  readonly searchQuery: string;
  readonly depth: number;
}> = ({ path, label, value, searchQuery, depth }) => {
  const [expanded, setExpanded] = useState(depth < 2);
  const isObject = value !== null && typeof value === "object";
  const matchesSearch =
    searchQuery.trim().length > 0 &&
    (label.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (!isObject && String(value).toLowerCase().includes(searchQuery.toLowerCase())));

  if (!isObject) {
    return (
      <div
        className={`odysseus-json-leaf ${matchesSearch ? "odysseus-json-match" : ""}`}
      >
        <span className="odysseus-json-key">{label}:</span>{" "}
        <span className="odysseus-json-val">{JSON.stringify(value)}</span>
        <button
          type="button"
          className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
          onClick={() => void navigator.clipboard?.writeText(path)}
        >
          Copy path
        </button>
      </div>
    );
  }

  const entries = Array.isArray(value)
    ? value.map((v, idx) => [String(idx), v] as const)
    : Object.entries(value as Record<string, unknown>);

  return (
    <div className="odysseus-json-branch">
      <div className="odysseus-json-branch-header">
        <button
          type="button"
          className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
          onClick={() => setExpanded((e) => !e)}
        >
          {expanded ? "▾" : "▸"} {label}{" "}
          <span className="odysseus-text-muted">
            ({Array.isArray(value) ? `[${entries.length}]` : `{${entries.length}}`})
          </span>
        </button>
        <button
          type="button"
          className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
          onClick={() => void navigator.clipboard?.writeText(path)}
        >
          Copy path
        </button>
      </div>
      {expanded ? (
        <div className="odysseus-json-children">
          {entries.slice(0, 100).map(([k, v]) => (
            <JsonTreeNode
              key={k}
              path={Array.isArray(value) ? `${path}[${k}]` : `${path}.${k}`}
              label={k}
              value={v}
              searchQuery={searchQuery}
              depth={depth + 1}
            />
          ))}
        </div>
      ) : null}
    </div>
  );
};

export const JsonOutputRenderer: React.FC<{
  readonly rawText: string;
  readonly declaredBytes?: number;
}> = ({ rawText, declaredBytes }) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [sliceOffset, setSliceOffset] = useState(0);
  const inspection = useMemo(
    () => inspectJsonPayload(rawText, declaredBytes),
    [rawText, declaredBytes],
  );

  const handleDownloadRaw = () => {
    const blob = new Blob([rawText.slice(0, 1024 * 1024)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "tool-output.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  if (inspection.isCapped) {
    const sliceText = rawText.slice(sliceOffset, sliceOffset + 2048);
    return (
      <div className="odysseus-json-capped" data-testid="json-capped-view">
        <div className="odysseus-json-capped-header">
          <span className="odysseus-badge odysseus-badge-warning">
            {inspection.summaryLabel}
          </span>
          <button
            type="button"
            className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
            onClick={handleDownloadRaw}
            data-testid="json-download-raw"
          >
            Download raw
          </button>
        </div>
        <div className="odysseus-json-slice-controls">
          <span>
            Slice offset: {sliceOffset.toLocaleString()} –{" "}
            {(sliceOffset + sliceText.length).toLocaleString()} bytes
          </span>
          <button
            type="button"
            className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
            disabled={sliceOffset === 0}
            onClick={() => setSliceOffset((o) => Math.max(0, o - 2048))}
          >
            Prev 2 KB
          </button>
          <button
            type="button"
            className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
            disabled={sliceOffset + 2048 >= rawText.length}
            onClick={() => setSliceOffset((o) => o + 2048)}
          >
            Next 2 KB
          </button>
        </div>
        <pre className="odysseus-code-pre" data-testid="json-slice-viewer">
          {sliceText}
        </pre>
      </div>
    );
  }

  return (
    <div className="odysseus-json-renderer" data-testid="json-renderer">
      <div className="odysseus-json-toolbar">
        <span className="odysseus-text-muted">{inspection.summaryLabel}</span>
        <input
          type="search"
          className="odysseus-input odysseus-input-xs"
          placeholder="Search keys/values…"
          aria-label="Search JSON tree"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          data-testid="json-tree-search"
        />
      </div>
      {inspection.parsed !== null ? (
        <JsonTreeNode
          path="$"
          label="root"
          value={inspection.parsed}
          searchQuery={searchQuery}
          depth={0}
        />
      ) : (
        <pre className="odysseus-code-pre">{rawText}</pre>
      )}
    </div>
  );
};

// --- 3. Table Renderer ---
export const TableOutputRenderer: React.FC<{ readonly rawText: string }> = ({
  rawText,
}) => {
  const [sortCol, setSortCol] = useState<string | null>(null);
  const [sortAsc, setSortAsc] = useState(true);

  const { columns, rows } = useMemo(() => {
    try {
      const parsed: unknown = JSON.parse(rawText);
      const arr = Array.isArray(parsed)
        ? parsed
        : parsed &&
            typeof parsed === "object" &&
            Array.isArray((parsed as { rows?: unknown[] }).rows)
          ? (parsed as { rows: unknown[] }).rows
          : [];
      if (arr.length > 0 && typeof arr[0] === "object" && arr[0] !== null) {
        const cols = Object.keys(arr[0] as Record<string, unknown>);
        return {
          columns: cols,
          rows: arr as ReadonlyArray<Record<string, unknown>>,
        };
      }
    } catch {
      // Fallback: parse simple CSV/TSV lines
    }
    const lines = rawText
      .trim()
      .split("\n")
      .filter(Boolean);
    if (lines.length === 0) return { columns: ["value"], rows: [] };
    const cols = (lines[0] ?? "value").split(",").map((c) => c.trim());
    const parsedRows = lines.slice(1).map((ln) => {
      const cells = ln.split(",").map((c) => c.trim());
      const rec: Record<string, unknown> = {};
      cols.forEach((col, idx) => {
        rec[col] = cells[idx] ?? "";
      });
      return rec;
    });
    return { columns: cols, rows: parsedRows };
  }, [rawText]);

  const sortedRows = useMemo(() => {
    if (!sortCol) return rows;
    return [...rows].sort((a, b) => {
      const va = String(a[sortCol] ?? "");
      const vb = String(b[sortCol] ?? "");
      return sortAsc ? va.localeCompare(vb) : vb.localeCompare(va);
    });
  }, [rows, sortCol, sortAsc]);

  const copyCsv = () => {
    const csvLines = [
      columns.join(","),
      ...sortedRows.map((r) =>
        columns.map((c) => JSON.stringify(r[c] ?? "")).join(","),
      ),
    ];
    void navigator.clipboard?.writeText(csvLines.join("\n"));
  };

  return (
    <div className="odysseus-table-renderer" data-testid="table-renderer">
      <div className="odysseus-table-toolbar">
        <span>{sortedRows.length} rows</span>
        <button
          type="button"
          className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
          onClick={copyCsv}
          data-testid="table-copy-csv"
        >
          Copy as CSV
        </button>
      </div>
      <div className="odysseus-table-scroll">
        <table className="odysseus-data-table">
          <thead>
            <tr>
              {columns.map((col) => (
                <th key={col}>
                  <button
                    type="button"
                    className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
                    onClick={() => {
                      if (sortCol === col) setSortAsc((s) => !s);
                      else {
                        setSortCol(col);
                        setSortAsc(true);
                      }
                    }}
                  >
                    {col} {sortCol === col ? (sortAsc ? "▲" : "▼") : ""}
                  </button>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {sortedRows.slice(0, 100).map((row, idx) => (
              <tr key={idx}>
                {columns.map((col) => (
                  <td key={col}>{String(row[col] ?? "")}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// --- 4. Diff Renderer ---
export const DiffOutputRenderer: React.FC<{ readonly rawText: string }> = ({
  rawText,
}) => {
  const [splitMode, setSplitMode] = useState(false);
  const [collapsedHunks, setCollapsedHunks] = useState<Record<number, boolean>>({});

  const lines = useMemo(() => rawText.split("\n"), [rawText]);

  return (
    <div className="odysseus-diff-renderer" data-testid="diff-renderer">
      <div className="odysseus-diff-toolbar">
        <span className="odysseus-text-muted">Unified / Split Diff</span>
        <button
          type="button"
          className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
          onClick={() => setSplitMode((s) => !s)}
          data-testid="diff-mode-toggle"
        >
          {splitMode ? "Switch to Unified" : "Switch to Split"}
        </button>
      </div>
      <div
        className={`odysseus-diff-body ${splitMode ? "odysseus-diff-split" : ""}`}
      >
        {lines.map((line, idx) => {
          const isHunk = line.startsWith("@@");
          const isAdd = line.startsWith("+") && !line.startsWith("+++");
          const isDel = line.startsWith("-") && !line.startsWith("---");
          if (isHunk) {
            return (
              <div key={idx} className="odysseus-diff-hunk-header">
                <button
                  type="button"
                  className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
                  onClick={() =>
                    setCollapsedHunks((prev) => ({
                      ...prev,
                      [idx]: !prev[idx],
                    }))
                  }
                >
                  {collapsedHunks[idx] ? "▸ Expand hunk" : "▾ Collapse hunk"}{" "}
                  <code>{line}</code>
                </button>
              </div>
            );
          }
          return (
            <div
              key={idx}
              className={`odysseus-diff-line ${
                isAdd
                  ? "odysseus-diff-add"
                  : isDel
                    ? "odysseus-diff-del"
                    : ""
              }`}
            >
              <span className="odysseus-diff-lineno">{idx + 1}</span>
              <span className="odysseus-diff-code">{line}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// --- 5. Search Results Renderer ---
export const SearchResultsOutputRenderer: React.FC<{
  readonly rawText: string;
}> = ({ rawText }) => {
  const items = useMemo(() => {
    try {
      const parsed: unknown = JSON.parse(rawText);
      if (
        parsed &&
        typeof parsed === "object" &&
        Array.isArray((parsed as { results?: unknown[] }).results)
      ) {
        return (
          parsed as {
            results: ReadonlyArray<{
              title?: string;
              url?: string;
              snippet?: string;
              score?: number;
            }>;
          }
        ).results;
      }
    } catch {
      // Fallback
    }
    return [{ title: "Search Result", url: "https://docs.example.com", snippet: rawText, score: 0.95 }];
  }, [rawText]);

  return (
    <div className="odysseus-search-results-renderer" data-testid="search-results-renderer">
      {items.map((item, idx) => (
        <div key={idx} className="odysseus-search-result-card">
          <div className="odysseus-search-result-header">
            <strong>{item.title ?? "Result"}</strong>
            {item.score !== undefined ? (
              <span className="odysseus-badge">
                {Math.round(item.score * 100)}% match
              </span>
            ) : null}
          </div>
          {item.url ? (
            <div className="odysseus-search-result-url">{item.url}</div>
          ) : null}
          <p className="odysseus-search-result-snippet">{item.snippet}</p>
        </div>
      ))}
    </div>
  );
};

// --- 6. File Tree Renderer ---
export const FileTreeOutputRenderer: React.FC<{ readonly rawText: string }> = ({
  rawText,
}) => {
  const entries = useMemo(
    () =>
      rawText
        .split("\n")
        .map((l) => l.trim())
        .filter(Boolean),
    [rawText],
  );
  return (
    <ul className="odysseus-file-tree-renderer" data-testid="file-tree-renderer">
      {entries.map((entry, idx) => {
        const isDir = entry.endsWith("/");
        return (
          <li key={idx} className="odysseus-file-tree-item">
            <span>{isDir ? "📁" : "📄"}</span> <code>{entry}</code>
          </li>
        );
      })}
    </ul>
  );
};

// --- 7. Image / Browser Snapshot Renderer ---
export const BrowserSnapshotOutputRenderer: React.FC<{
  readonly rawText: string;
}> = ({ rawText }) => {
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [takenOver, setTakenOver] = useState(false);

  const meta = useMemo(() => {
    try {
      return JSON.parse(rawText) as {
        url?: string;
        title?: string;
        status?: number;
        annotations?: ReadonlyArray<string>;
      };
    } catch {
      return { url: "https://odysseus.local", title: rawText.slice(0, 64), status: 200 };
    }
  }, [rawText]);

  return (
    <div className="odysseus-snapshot-renderer" data-testid="browser-snapshot-renderer">
      <div className="odysseus-snapshot-header">
        <span>🌐 {meta.title ?? "Browser Snapshot"}</span>
        <code>{meta.url ?? "about:blank"}</code>
        <button
          type="button"
          className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
          onClick={() => setLightboxOpen((o) => !o)}
          data-testid="snapshot-lightbox-btn"
        >
          {lightboxOpen ? "Close Lightbox" : "Inspect Lightbox"}
        </button>
        <button
          type="button"
          className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
          onClick={() => setTakenOver((t) => !t)}
          data-testid="browser-takeover-btn"
        >
          {takenOver ? "Release Browser Control" : "Take over browser"}
        </button>
      </div>
      {lightboxOpen ? (
        <div className="odysseus-snapshot-lightbox" data-testid="snapshot-lightbox">
          <p>Viewport 1280×800 · HTTP {meta.status ?? 200}</p>
          <pre className="odysseus-code-pre">{rawText}</pre>
        </div>
      ) : null}
    </div>
  );
};

// --- 8. Key-Value Renderer ---
export const KeyValueOutputRenderer: React.FC<{ readonly rawText: string }> = ({
  rawText,
}) => {
  const pairs = useMemo(() => {
    try {
      const parsed: unknown = JSON.parse(rawText);
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
        return Object.entries(parsed as Record<string, unknown>);
      }
    } catch {
      // Fallback
    }
    return rawText
      .split("\n")
      .filter(Boolean)
      .map((line, i) => {
        const idx = line.indexOf(":");
        return idx > 0
          ? ([line.slice(0, idx).trim(), line.slice(idx + 1).trim()] as const)
          : ([`key_${i}`, line] as const);
      });
  }, [rawText]);

  return (
    <dl className="odysseus-kv-renderer" data-testid="kv-renderer">
      {pairs.map(([k, v]) => (
        <div key={k} className="odysseus-kv-row">
          <dt>{k}</dt>
          <dd>{typeof v === "string" ? v : JSON.stringify(v)}</dd>
        </div>
      ))}
    </dl>
  );
};

// --- Unified Tool Call Card (FE-AGENT-04) ---
export const ToolCallCard: React.FC<{
  readonly toolCall: ToolCallViewState;
  readonly defaultExpanded?: boolean;
  readonly onRetryTool?: (toolCall: ToolCallViewState) => void;
}> = ({ toolCall, defaultExpanded = false, onRetryTool }) => {
  const [expanded, setExpanded] = useState(defaultExpanded);
  const [rawArgsMode, setRawArgsMode] = useState(false);
  const [overrideHint, setOverrideHint] = useState<ToolRenderHint | null>(null);

  const activeHint = overrideHint ?? resolveEffectiveRenderHint(toolCall);
  const rawOutput = toolCall.stdout || toolCall.summary || "";

  return (
    <div
      className={`odysseus-tool-card odysseus-tool-status-${toolCall.status}`}
      data-testid={`tool-card-${toolCall.call_id}`}
      data-render-hint={activeHint}
    >
      <div className="odysseus-tool-card-header">
        <button
          type="button"
          className="odysseus-btn odysseus-btn-ghost odysseus-tool-expand-btn"
          aria-expanded={expanded}
          onClick={() => setExpanded((e) => !e)}
          data-testid={`tool-card-toggle-${toolCall.call_id}`}
        >
          <span>{expanded ? "▾" : "▸"}</span>
          <strong className="odysseus-tool-name">{toolCall.name}</strong>
          <span className="odysseus-tool-explain">
            {explainToolCall(toolCall.name, toolCall.args)}
          </span>
        </button>
        <div className="odysseus-tool-card-meta">
          <span
            className={`odysseus-badge odysseus-risk-${toolCall.risk}`}
            data-testid={`tool-risk-${toolCall.call_id}`}
          >
            {toolCall.risk}
          </span>
          <span
            className={`odysseus-badge odysseus-status-${toolCall.status}`}
            data-testid={`tool-status-${toolCall.call_id}`}
          >
            {toolCall.status}
          </span>
          {toolCall.duration_ms ? (
            <span className="odysseus-text-muted">{toolCall.duration_ms} ms</span>
          ) : null}
          {toolCall.status === "failed" && onRetryTool ? (
            <button
              type="button"
              className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
              onClick={() => onRetryTool(toolCall)}
              data-testid={`tool-retry-${toolCall.call_id}`}
            >
              Retry
            </button>
          ) : null}
        </div>
      </div>

      {expanded ? (
        <div
          className="odysseus-tool-card-body"
          data-testid={`tool-card-body-${toolCall.call_id}`}
        >
          <div className="odysseus-tool-args-bar">
            <span className="odysseus-text-muted">Arguments</span>
            <div className="odysseus-tool-args-actions">
              <button
                type="button"
                className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
                onClick={() => setRawArgsMode((m) => !m)}
                data-testid="tool-args-toggle"
              >
                {rawArgsMode ? "Structured view" : "Raw JSON"}
              </button>
              <label className="odysseus-render-hint-label">
                <span>Renderer:</span>
                <select
                  className="odysseus-select odysseus-select-xs"
                  value={activeHint}
                  onChange={(e) =>
                    setOverrideHint(e.target.value as ToolRenderHint)
                  }
                  data-testid={`tool-render-hint-select-${toolCall.call_id}`}
                >
                  <option value="text">text</option>
                  <option value="terminal">terminal</option>
                  <option value="json">json</option>
                  <option value="table">table</option>
                  <option value="diff">diff</option>
                  <option value="search_results">search_results</option>
                  <option value="file_tree">file_tree</option>
                  <option value="browser_snapshot">browser_snapshot</option>
                  <option value="kv">kv</option>
                </select>
              </label>
            </div>
          </div>

          {rawArgsMode ? (
            <pre className="odysseus-code-pre">
              {JSON.stringify(toolCall.args, null, 2)}
            </pre>
          ) : (
            <KeyValueOutputRenderer rawText={JSON.stringify(toolCall.args)} />
          )}

          {toolCall.pct !== null ? (
            <div className="odysseus-tool-progress">
              <progress value={toolCall.pct} max={100} />
              <span>{toolCall.progress_label || `${toolCall.pct}%`}</span>
            </div>
          ) : null}

          <div className="odysseus-tool-output-section">
            {activeHint === "terminal" ? (
              <TerminalOutputRenderer
                callId={toolCall.call_id}
                stdout={rawOutput}
                stderr={toolCall.stderr}
                isRunning={toolCall.status === "running"}
              />
            ) : activeHint === "json" ? (
              <JsonOutputRenderer rawText={rawOutput} />
            ) : activeHint === "table" ? (
              <TableOutputRenderer rawText={rawOutput} />
            ) : activeHint === "diff" ? (
              <DiffOutputRenderer rawText={rawOutput} />
            ) : activeHint === "search_results" ? (
              <SearchResultsOutputRenderer rawText={rawOutput} />
            ) : activeHint === "file_tree" ? (
              <FileTreeOutputRenderer rawText={rawOutput} />
            ) : activeHint === "browser_snapshot" || activeHint === "image" ? (
              <BrowserSnapshotOutputRenderer rawText={rawOutput} />
            ) : activeHint === "kv" ? (
              <KeyValueOutputRenderer rawText={rawOutput} />
            ) : (
              <pre
                className="odysseus-code-pre"
                data-testid={`tool-text-output-${toolCall.call_id}`}
              >
                {rawOutput}
              </pre>
            )}
          </div>
        </div>
      ) : null}
    </div>
  );
};
