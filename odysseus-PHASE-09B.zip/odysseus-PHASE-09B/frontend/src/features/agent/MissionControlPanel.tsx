import React, { useMemo, useState } from "react";
import type { RunViewState } from "../../lib/runReducer";

type PanelTab = "summary" | "reasoning" | "context" | "queue" | "trust";

interface MissionControlPanelProps {
  readonly run: RunViewState;
  readonly onClose?: () => void;
}

const labels: Record<PanelTab, string> = {
  summary: "Summary",
  reasoning: "Reasoning",
  context: "Context",
  queue: "Queue",
  trust: "Trust",
};

export function MissionControlPanel({ run, onClose }: MissionControlPanelProps): React.ReactElement {
  const [tab, setTab] = useState<PanelTab>("summary");
  const [query, setQuery] = useState("");
  const reasoning = useMemo(
    () => Object.values(run.reasoning).filter((item) => !query || item.text.toLowerCase().includes(query.toLowerCase())),
    [run.reasoning, query],
  );
  const summary = run.summary;
  return (
    <aside className="odysseus-mission-panel" aria-label="Mission control" data-testid="mission-control-panel">
      <header className="odysseus-panel-heading">
        <div><p className="odysseus-eyebrow">Run mission control</p><h3>{run.status === "running" ? "In progress" : "Run summary"}</h3></div>
        {onClose ? <button type="button" className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs" onClick={onClose} aria-label="Close mission control">Close</button> : null}
      </header>
      <nav className="odysseus-segmented" aria-label="Run panels">
        {(Object.keys(labels) as PanelTab[]).map((key) => (
          <button type="button" key={key} className={tab === key ? "is-selected" : ""} aria-pressed={tab === key} onClick={() => setTab(key)}>{labels[key]}</button>
        ))}
      </nav>
      <div className="odysseus-panel-body">
        {tab === "summary" ? (
          <section data-testid="run-summary-panel">
            <div className="odysseus-summary-stats"><span>{run.ordered_step_ids.length} steps</span><span>{run.ordered_tool_call_ids.length} tools</span><span>{run.usage.output.toLocaleString()} tokens</span></div>
            {summary ? Object.entries(summary.sections).map(([name, bullets]) => bullets.length ? <div key={name}><h4>{name.replaceAll("_", " ")}</h4><ul>{bullets.map((bullet) => <li key={bullet}>{bullet}</li>)}</ul></div> : null) : <p className="odysseus-text-muted">A deterministic summary will appear as the run produces events.</p>}
          </section>
        ) : null}
        {tab === "reasoning" ? (
          <section data-testid="reasoning-panel"><label htmlFor="reasoning-search">Search reasoning</label><input id="reasoning-search" className="odysseus-input" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Find in reasoning…" />{reasoning.length ? reasoning.map((item) => <article className="odysseus-reasoning-segment" key={item.segment_id}><strong>{item.kind === "summary" ? "Reasoning summary" : item.kind === "redacted" ? "Reasoning hidden by provider" : "Reasoning"}</strong><span>{item.duration_ms ? ` · ${(item.duration_ms / 1000).toFixed(1)} s` : ""}</span><p>{item.kind === "redacted" ? "The provider did not expose reasoning text." : item.text}</p></article>) : <p className="odysseus-text-muted">No reasoning segments match this search.</p>}</section>
        ) : null}
        {tab === "context" ? <section data-testid="context-panel"><p><strong>{run.context_snapshot?.window.toLocaleString() ?? "—"}</strong> token model window</p>{run.context_snapshot?.items.map((item) => <div className="odysseus-context-row" key={item.id}><span>{item.kind}</span><span>{item.tokens.toLocaleString()} tokens</span></div>) ?? <p className="odysseus-text-muted">Context snapshot unavailable.</p>}</section> : null}
        {tab === "queue" ? <section data-testid="queue-panel"><p className="odysseus-text-muted">No queued messages or background runs.</p></section> : null}
        {tab === "trust" ? <section data-testid="trust-panel"><div className="odysseus-egress-badge" role="status">Local · prompt stays in this workspace</div><p className="odysseus-text-muted">Tool approvals, provenance, and provider routing are recorded in the timeline.</p></section> : null}
      </div>
    </aside>
  );
}
