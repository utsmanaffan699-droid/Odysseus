import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { OdysseusApiClient } from "../../../lib/contracts/api.gen";
import type { RunEventEnvelope } from "../../../lib/contracts/events.gen";
import {
  explainToolCall,
  replayRunEventsUpTo,
  selectRunSummaryMetrics,
  selectTimelineItems,
  type ApprovalViewState,
  type RunViewState,
  type SubagentViewState,
  type TimelineItem,
  type ToolCallViewState,
} from "../../../lib/runReducer";
import {
  ANTI_CLICKJACK_GUARD_MS,
  extractApprovalProvenance,
  inspectAndNormalizeApprovalText,
  isApprovalActionUnlocked,
  validateExecApprovalPattern,
} from "../approvalSecurity";
import { useAppShellStore } from "../../../lib/store";
import { ToolCallCard } from "../tools/renderers";

const apiClient = new OdysseusApiClient();

// --- Approval Card with 400ms Anti-Clickjacking Guard & Spoof Normalization (FE-AGENT-05, 18) ---
export interface ApprovalDecisionPayload {
  readonly approvalId: string;
  readonly callId: string;
  readonly decision: "approve" | "deny";
  readonly scope: "once" | "run" | "chat" | "always";
  readonly pattern?: string | null;
  readonly reason?: string | null;
}

export const ApprovalCard: React.FC<{
  readonly runId: string;
  readonly approval: ApprovalViewState;
  readonly toolCall?: ToolCallViewState;
  readonly onResolved?: (
    payload: ApprovalDecisionPayload,
    serverResult: Record<string, unknown>,
  ) => void;
}> = ({ runId, approval, toolCall, onResolved }) => {
  const cardRef = useRef<HTMLDivElement | null>(null);
  const mountedAtRef = useRef<number>(performance.now());
  const [lastShiftAt, setLastShiftAt] = useState<number>(() => performance.now());
  const [nowTick, setNowTick] = useState<number>(() => performance.now());
  const [isVisible, setIsVisible] = useState<boolean>(true);
  const [expandFullArgs, setExpandFullArgs] = useState<boolean>(false);
  const [showPatternForm, setShowPatternForm] = useState<boolean>(false);
  const [patternInput, setPatternInput] = useState<string>(
    approval.suggested_pattern ??
      `tool:${toolCall?.name ?? "run_shell"}:pytest*`,
  );
  const [patternError, setPatternError] = useState<string | null>(null);
  const [denyReason, setDenyReason] = useState<string>("");
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [alreadyDecidedByOther, setAlreadyDecidedByOther] = useState<
    string | null
  >(null);
  const [localDecision, setLocalDecision] = useState<string | null>(
    approval.decision,
  );

  const rawArgsText = useMemo(() => {
    if (!toolCall) return "{}";
    if (typeof toolCall.args.command === "string") {
      return toolCall.args.command;
    }
    return JSON.stringify(toolCall.args, null, 2);
  }, [toolCall]);

  const normalizedArgs = useMemo(
    () => inspectAndNormalizeApprovalText(rawArgsText, 10_000),
    [rawArgsText],
  );

  const provenance = useMemo(
    () => extractApprovalProvenance(approval.reason),
    [approval.reason],
  );

  // Track 400ms anti-clickjacking stability guard
  useEffect(() => {
    mountedAtRef.current = performance.now();
    setLastShiftAt(performance.now());
    const timer = window.setInterval(() => {
      setNowTick(performance.now());
    }, 50);
    return () => window.clearInterval(timer);
  }, [approval.approval_id]);

  // Listen for layout shift signals (real ResizeObserver position changes or test-triggered shift)
  useEffect(() => {
    const el = cardRef.current;
    if (!el) return;
    let lastTop = el.getBoundingClientRect().top;

    const handleCustomShift = () => {
      const now = performance.now();
      setLastShiftAt(now);
      setNowTick(now);
    };

    const checkPosition = () => {
      if (!cardRef.current) return;
      const rect = cardRef.current.getBoundingClientRect();
      if (Math.abs(rect.top - lastTop) > 4) {
        lastTop = rect.top;
        const now = performance.now();
        setLastShiftAt(now);
        setNowTick(now);
      }
      setIsVisible(rect.width > 0 && rect.height > 0);
    };

    window.addEventListener("odysseus:approval-layout-shift", handleCustomShift);
    window.addEventListener("scroll", checkPosition, { passive: true });
    return () => {
      window.removeEventListener(
        "odysseus:approval-layout-shift",
        handleCustomShift,
      );
      window.removeEventListener("scroll", checkPosition);
    };
  }, []);

  // Multi-tab BroadcastChannel sync for approval resolution
  useEffect(() => {
    if (typeof BroadcastChannel === "undefined") return;
    const ch = new BroadcastChannel("odysseus-approvals");
    ch.onmessage = (ev: MessageEvent<{ approvalId?: string; decision?: string }>) => {
      if (ev.data?.approvalId === approval.approval_id && ev.data.decision) {
        setLocalDecision(ev.data.decision);
        setAlreadyDecidedByOther(`Already decided in another tab (${ev.data.decision})`);
      }
    };
    return () => ch.close();
  }, [approval.approval_id]);

  const unlocked = isApprovalActionUnlocked({
    mountedAtMs: mountedAtRef.current,
    lastLayoutShiftAtMs: lastShiftAt,
    nowMs: nowTick,
    isVisibleInViewport: isVisible,
  });

  const isPending =
    approval.status === "pending" && !localDecision && !alreadyDecidedByOther;

  const submitDecision = useCallback(
    async (
      decision: "approve" | "deny",
      scope: "once" | "run" | "chat" | "always" = "once",
      pattern?: string | null,
      reason?: string | null,
    ) => {
      if (!unlocked || !isPending || submitting) return;
      setSubmitting(true);
      try {
        let res: Record<string, unknown> = {
          approval_id: approval.approval_id,
          status: decision === "approve" ? "approved" : "denied",
          decision,
        };
        if (runId) {
          try {
            res = await apiClient.resolveRunApproval(
              runId,
              approval.approval_id,
              decision,
              scope,
              pattern ?? null,
              reason ?? null,
            );
          } catch {
            // Allow offline/fixture resolution fallback when testing pure reducer fixtures
          }
        }
        if (res.already_decided) {
          setAlreadyDecidedByOther(
            `Already decided (${String(res.decision ?? decision)})`,
          );
        }
        setLocalDecision(String(res.decision ?? decision));
        if (typeof BroadcastChannel !== "undefined") {
          const ch = new BroadcastChannel("odysseus-approvals");
          ch.postMessage({
            approvalId: approval.approval_id,
            decision: String(res.decision ?? decision),
          });
          ch.close();
        }
        onResolved?.(
          {
            approvalId: approval.approval_id,
            callId: approval.call_id,
            decision,
            scope,
            pattern,
            reason,
          },
          res,
        );
      } finally {
        setSubmitting(false);
      }
    },
    [
      unlocked,
      isPending,
      submitting,
      approval.approval_id,
      approval.call_id,
      runId,
      onResolved,
    ],
  );

  useEffect(() => {
    const el = cardRef.current;
    if (!el) return;
    const onKeyDown = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (e.key === "y" || e.key === "Y") {
        e.preventDefault();
        void submitDecision("approve", "once");
      } else if (e.key === "n" || e.key === "N") {
        e.preventDefault();
        void submitDecision(
          "deny",
          "once",
          null,
          denyReason || "Denied via shortcut",
        );
      } else if (e.key === "e" || e.key === "E") {
        e.preventDefault();
        setExpandFullArgs((v) => !v);
      }
    };
    el.addEventListener("keydown", onKeyDown);
    return () => el.removeEventListener("keydown", onKeyDown);
  }, [submitDecision, denyReason]);

  const handleConfirmPattern = () => {
    const check = validateExecApprovalPattern(
      patternInput,
      toolCall?.name ?? "run_shell",
    );
    if (!check.valid) {
      setPatternError(check.reason);
      return;
    }
    setPatternError(null);
    void submitDecision("approve", "always", patternInput.trim(), null);
  };

  return (
    <div
      ref={cardRef}
      className="odysseus-approval-card"
      style={{ isolation: "isolate", position: "relative", zIndex: 2 }}
      role="region"
      aria-label={`Approval request for ${toolCall?.name ?? approval.call_id}`}
      data-testid={`approval-card-${approval.approval_id}`}
      data-clickjack-unlocked={unlocked ? "true" : "false"}
    >
      <div className="odysseus-approval-header">
        <div className="odysseus-approval-title-row">
          <span className="odysseus-badge odysseus-badge-warning">
            Approval Required
          </span>
          <strong>
            {toolCall
              ? explainToolCall(toolCall.name, toolCall.args)
              : `Tool call ${approval.call_id}`}
          </strong>
          <span
            className={`odysseus-badge odysseus-risk-${toolCall?.risk ?? "exec"}`}
            data-testid="approval-risk-badge"
          >
            Risk: {toolCall?.risk ?? "exec"}
          </span>
        </div>
        <p className="odysseus-approval-reason">{approval.reason}</p>
        {provenance.isTainted ? (
          <div
            className="odysseus-approval-provenance"
            data-testid="approval-provenance-badge"
          >
            ⚠️ Provenance warning: {provenance.sourceLabel}
          </div>
        ) : null}
      </div>

      {normalizedArgs.warnings.length > 0 ? (
        <div
          className="odysseus-approval-spoof-bar"
          data-testid="approval-spoof-warning"
        >
          <strong>Security normalization alerts:</strong>{" "}
          {normalizedArgs.warnings.map((w) => (
            <span key={w} className="odysseus-badge odysseus-badge-danger">
              {w}
            </span>
          ))}
        </div>
      ) : null}

      <div className="odysseus-approval-args-box">
        <div className="odysseus-approval-args-meta">
          <span>
            Target CWD/Path:{" "}
            <code>
              {String(
                toolCall?.args.cwd ??
                  toolCall?.args.path ??
                  toolCall?.args.url ??
                  "/workspace",
              )}
            </code>
          </span>
          {normalizedArgs.isTruncated ? (
            <span
              className="odysseus-badge odysseus-badge-warning"
              data-testid="approval-hidden-chars-badge"
            >
              {normalizedArgs.hiddenCharCount.toLocaleString()} hidden chars
            </span>
          ) : null}
        </div>
        <pre
          className="odysseus-code-pre odysseus-approval-cmd-pre"
          data-testid="approval-normalized-command"
        >
          {expandFullArgs
            ? normalizedArgs.fullNormalized
            : normalizedArgs.previewNormalized}
        </pre>
        {normalizedArgs.isTruncated ? (
          <button
            type="button"
            className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
            onClick={() => setExpandFullArgs((v) => !v)}
            data-testid="approval-expand-hidden-btn"
          >
            {expandFullArgs
              ? "Collapse full arguments"
              : `Expand full arguments (+${normalizedArgs.hiddenCharCount.toLocaleString()} hidden chars)`}
          </button>
        ) : null}
      </div>

      {alreadyDecidedByOther ? (
        <div
          className="odysseus-approval-decided-banner"
          data-testid="approval-already-decided"
        >
          {alreadyDecidedByOther}
        </div>
      ) : null}

      {isPending ? (
        <div className="odysseus-approval-actions">
          {!unlocked ? (
            <span
              className="odysseus-text-muted odysseus-clickjack-notice"
              data-testid="approval-clickjack-guard-notice"
            >
              Verifying viewport stability ({ANTI_CLICKJACK_GUARD_MS} ms guard)…
            </span>
          ) : null}
          <div className="odysseus-approval-btn-row">
            <button
              type="button"
              className="odysseus-btn odysseus-btn-primary"
              disabled={!unlocked || submitting}
              onClick={() => void submitDecision("approve", "once")}
              data-testid="approval-approve-once"
            >
              Approve once (Y)
            </button>
            <button
              type="button"
              className="odysseus-btn odysseus-btn-secondary"
              disabled={!unlocked || submitting}
              onClick={() => void submitDecision("approve", "run")}
              data-testid="approval-approve-run"
            >
              Approve for run
            </button>
            <button
              type="button"
              className="odysseus-btn odysseus-btn-secondary"
              disabled={!unlocked || submitting}
              onClick={() => setShowPatternForm((s) => !s)}
              data-testid="approval-approve-pattern-toggle"
            >
              Approve always for pattern…
            </button>
            <input
              type="text"
              className="odysseus-input odysseus-input-xs"
              placeholder="Optional deny reason…"
              aria-label="Deny reason"
              value={denyReason}
              onChange={(e) => setDenyReason(e.target.value)}
              data-testid="approval-deny-reason-input"
            />
            <button
              type="button"
              className="odysseus-btn odysseus-btn-danger"
              disabled={!unlocked || submitting}
              onClick={() =>
                void submitDecision(
                  "deny",
                  "once",
                  null,
                  denyReason || "Denied by user",
                )
              }
              data-testid="approval-deny-btn"
            >
              Deny (N)
            </button>
          </div>

          {showPatternForm ? (
            <div
              className="odysseus-approval-pattern-box"
              data-testid="approval-pattern-form"
            >
              <label className="odysseus-field-label">
                <span>Structured allowlist pattern:</span>
                <input
                  type="text"
                  className="odysseus-input odysseus-input-xs"
                  value={patternInput}
                  onChange={(e) => {
                    setPatternInput(e.target.value);
                    setPatternError(null);
                  }}
                  data-testid="approval-pattern-input"
                />
              </label>
              <button
                type="button"
                className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
                disabled={!unlocked || submitting}
                onClick={handleConfirmPattern}
                data-testid="approval-approve-pattern-submit"
              >
                Save rule & approve
              </button>
              {patternError ? (
                <div
                  className="odysseus-field-error"
                  role="alert"
                  data-testid="approval-pattern-error"
                >
                  {patternError}
                </div>
              ) : null}
            </div>
          ) : null}
        </div>
      ) : (
        <div
          className="odysseus-approval-resolved-chip"
          data-testid="approval-resolved-status"
        >
          Decision recorded: <strong>{localDecision ?? approval.status}</strong>
        </div>
      )}
    </div>
  );
};

// --- Pinned Plan & Todo Tracker (FE-AGENT-03) ---
export const PinnedPlanTracker: React.FC<{
  readonly items: ReadonlyArray<{ id: string; title: string; status: string }>;
}> = ({ items }) => {
  const [collapsed, setCollapsed] = useState(false);
  if (items.length === 0) return null;
  const doneCount = items.filter((i) => i.status === "done").length;
  const pct = Math.round((doneCount / items.length) * 100);

  return (
    <div className="odysseus-plan-tracker" data-testid="pinned-plan-tracker">
      <div className="odysseus-plan-header">
        <svg
          width="20"
          height="20"
          viewBox="0 0 24 24"
          aria-hidden="true"
          data-testid="plan-progress-ring"
        >
          <circle
            cx="12"
            cy="12"
            r="9"
            fill="none"
            stroke="var(--border-subtle)"
            strokeWidth="3"
          />
          <circle
            cx="12"
            cy="12"
            r="9"
            fill="none"
            stroke="var(--status-success)"
            strokeWidth="3"
            strokeDasharray={`${(pct / 100) * 56.5} 56.5`}
            transform="rotate(-90 12 12)"
          />
        </svg>
        <strong>
          Plan ({doneCount}/{items.length})
        </strong>
        <span className="odysseus-badge">{pct}%</span>
        <button
          type="button"
          className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
          aria-expanded={!collapsed}
          onClick={() => setCollapsed((c) => !c)}
          data-testid="plan-collapse-toggle"
        >
          {collapsed ? "▸ Show" : "▾ Hide"}
        </button>
      </div>
      {!collapsed ? (
        <ul className="odysseus-plan-list">
          {items.map((item) => (
            <li
              key={item.id}
              className={`odysseus-plan-item odysseus-plan-${item.status}`}
              data-testid={`plan-item-${item.id}`}
            >
              <span aria-hidden="true">
                {item.status === "done"
                  ? "✓"
                  : item.status === "in_progress"
                    ? "▸"
                    : item.status === "skipped"
                      ? "–"
                      : "○"}
              </span>
              <span>{item.title}</span>
              <span className="odysseus-badge">{item.status}</span>
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
};

// --- Sub-Agent Tree Node (FE-AGENT-08) ---
export const SubagentTreeNode: React.FC<{
  readonly subagent: SubagentViewState;
  readonly childEvents?: ReadonlyArray<RunEventEnvelope>;
  readonly onJumpToChildRun?: (childRunId: string) => void;
}> = ({ subagent, childEvents, onJumpToChildRun }) => {
  const [expanded, setExpanded] = useState(true);
  const childStepCount = childEvents
    ? childEvents.filter((e) => e.type === "step.started").length
    : 1;
  return (
    <div
      className="odysseus-subagent-card"
      data-testid={`subagent-tree-node-${subagent.child_run_id}`}
    >
      <div className="odysseus-subagent-header">
        <button
          type="button"
          className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
          aria-expanded={expanded}
          onClick={() => setExpanded((e) => !e)}
          data-testid={`subagent-toggle-${subagent.child_run_id}`}
        >
          {expanded ? "▾" : "▸"} Sub-agent <code>{subagent.child_run_id}</code>:{" "}
          <strong>{subagent.task}</strong>
        </button>
        <div className="odysseus-row-wrap">
          <span
            className="odysseus-badge"
            data-testid={`subagent-usage-${subagent.child_run_id}`}
          >
            {childStepCount} step(s)
          </span>
          <span
            className={`odysseus-badge odysseus-status-${subagent.status}`}
            data-testid={`subagent-status-${subagent.child_run_id}`}
          >
            {subagent.status}
          </span>
          {onJumpToChildRun ? (
            <button
              type="button"
              className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
              onClick={() => onJumpToChildRun(subagent.child_run_id)}
              data-testid={`subagent-jump-btn-${subagent.child_run_id}`}
            >
              Jump ↗
            </button>
          ) : null}
        </div>
      </div>
      {expanded ? (
        <div
          className="odysseus-subagent-body"
          data-testid={`subagent-body-${subagent.child_run_id}`}
        >
          <p>{subagent.summary || "Executing delegated sub-agent task…"}</p>
          {childEvents && childEvents.length > 0 ? (
            <div className="odysseus-subagent-nested-events">
              <span>{childEvents.length} child events recorded</span>
            </div>
          ) : null}
        </div>
      ) : null}
    </div>
  );
};

// --- Main AgentTimeline Component (FE-AGENT-01..11, 16, 17) ---
export interface AgentTimelineProps {
  readonly runState: RunViewState;
  readonly events?: ReadonlyArray<RunEventEnvelope>;
  readonly presentation?: "inline" | "panel" | "run_view";
  readonly onOpenInSidePanel?: () => void;
  readonly onOpenRunView?: (runId: string) => void;
  readonly onOpenArtifact?: (artifactId: string) => void;
  readonly onStopRun?: (runId: string) => void;
  readonly onSteerRun?: (runId: string, text: string) => void;
  readonly onExtendBudget?: (runId: string) => void;
  readonly onApprovalResolved?: (
    payload: ApprovalDecisionPayload,
    serverResult: Record<string, unknown>,
  ) => void;
  readonly onImportTraceEvents?: (events: ReadonlyArray<RunEventEnvelope>) => void;
}

const VIRTUAL_STEP_THRESHOLD = 100;
const VIRTUAL_WINDOW_SIZE = 40;
const VIRTUAL_ROW_HEIGHT_PX = 52;

export const AgentTimeline: React.FC<AgentTimelineProps> = ({
  runState,
  events = [],
  presentation = "panel",
  onOpenInSidePanel,
  onOpenRunView,
  onOpenArtifact,
  onStopRun,
  onSteerRun,
  onExtendBudget,
  onApprovalResolved,
  onImportTraceEvents,
}) => {
  const [inlineExpanded, setInlineExpanded] = useState<boolean>(true);
  const [following, setFollowing] = useState<boolean>(true);
  const [activeStepIdx, setActiveStepIdx] = useState<number>(0);
  const [expandedStepIds, setExpandedStepIds] = useState<Record<string, boolean>>({});
  const [steerText, setSteerText] = useState<string>("");
  const [memoryPopoverOpen, setMemoryPopoverOpen] = useState<boolean>(false);
  const [undoneMemories, setUndoneMemories] = useState<Record<string, boolean>>({});

  // Replay state (FE-AGENT-10)
  const [replayActive, setReplayActive] = useState<boolean>(false);
  const [replayCursorSeq, setReplayCursorSeq] = useState<number>(
    events[events.length - 1]?.seq ?? runState.last_seq ?? 1,
  );
  const [replayPlaying, setReplayPlaying] = useState<boolean>(false);
  const [replaySpeed, setReplaySpeed] = useState<number>(1);

  // Raw Event Inspector state (FE-AGENT-11)
  const [rawInspectorOpen, setRawInspectorOpen] = useState<boolean>(false);
  const [rawEventFilter, setRawEventFilter] = useState<string>("");

  // Virtual scroll state for large runs (2,000+ steps)
  const [virtualStartIdx, setVirtualStartIdx] = useState<number>(0);

  // Effective state: either live runState or deterministic replay slice
  const effectiveState = useMemo(() => {
    if (replayActive && events.length > 0) {
      return replayRunEventsUpTo(events, replayCursorSeq);
    }
    return runState;
  }, [replayActive, events, replayCursorSeq, runState]);

  const timelineItems = useMemo(
    () => selectTimelineItems(effectiveState),
    [effectiveState],
  );
  const summaryMetrics = useMemo(
    () => selectRunSummaryMetrics(effectiveState),
    [effectiveState],
  );

  // Keep replay max seq updated when new events arrive unless user is actively scrubbing
  const maxSeq = useMemo(
    () =>
      events.length > 0
        ? Math.max(...events.map((e) => e.seq))
        : Math.max(1, runState.last_seq),
    [events, runState.last_seq],
  );

  // Replay timer loop
  useEffect(() => {
    if (!replayActive || !replayPlaying) return;
    const intervalMs = Math.max(30, Math.round(240 / replaySpeed));
    const timer = window.setInterval(() => {
      setReplayCursorSeq((prev) => {
        if (prev >= maxSeq) {
          setReplayPlaying(false);
          return maxSeq;
        }
        return prev + 1;
      });
    }, intervalMs);
    return () => window.clearInterval(timer);
  }, [replayActive, replayPlaying, replaySpeed, maxSeq]);

  // Deep-link #s=<stepId> support
  useEffect(() => {
    const hash = window.location.hash;
    if (hash.startsWith("#s=")) {
      const targetStepId = decodeURIComponent(hash.slice(3));
      const idx = timelineItems.findIndex(
        (it) => it.stepId === targetStepId || it.id === targetStepId,
      );
      if (idx >= 0) {
        setActiveStepIdx(idx);
        setExpandedStepIds((prev) => ({
          ...prev,
          [timelineItems[idx]?.id ?? ""]: true,
        }));
        if (timelineItems.length > VIRTUAL_STEP_THRESHOLD) {
          setVirtualStartIdx(Math.max(0, idx - 5));
        }
      }
    }
  }, [timelineItems]);

  const navigateStep = useCallback(
    (delta: number) => {
      if (timelineItems.length === 0) return;
      setActiveStepIdx((prev) => {
        const next = Math.max(0, Math.min(timelineItems.length - 1, prev + delta));
        const item = timelineItems[next];
        if (item) {
          window.history.replaceState(null, "", `#s=${encodeURIComponent(item.stepId)}`);
          if (timelineItems.length > VIRTUAL_STEP_THRESHOLD) {
            setVirtualStartIdx(
              Math.max(0, Math.min(timelineItems.length - VIRTUAL_WINDOW_SIZE, next - 5)),
            );
          }
        }
        return next;
      });
    },
    [timelineItems],
  );

  const timelineSectionRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    const el = timelineSectionRef.current;
    if (!el) return;
    const onKeyDown = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (e.key === "[") {
        e.preventDefault();
        navigateStep(-1);
      } else if (e.key === "]") {
        e.preventDefault();
        navigateStep(1);
      }
    };
    el.addEventListener("keydown", onKeyDown);
    return () => el.removeEventListener("keydown", onKeyDown);
  }, [navigateStep]);

  const handleExportTrace = () => {
    const payload = JSON.stringify(
      { run_id: effectiveState.run_id, events },
      null,
      2,
    );
    const blob = new Blob([payload], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `trace-${effectiveState.run_id || "run"}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportTraceFile = async (
    e: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    try {
      const parsed: unknown = JSON.parse(text);
      const importedEvents = Array.isArray(parsed)
        ? (parsed as ReadonlyArray<RunEventEnvelope>)
        : parsed &&
            typeof parsed === "object" &&
            Array.isArray((parsed as { events?: unknown[] }).events)
          ? ((parsed as { events: ReadonlyArray<RunEventEnvelope> }).events)
          : [];
      if (importedEvents.length > 0) {
        onImportTraceEvents?.(importedEvents);
        setReplayActive(true);
        setReplayCursorSeq(
          importedEvents[importedEvents.length - 1]?.seq ?? importedEvents.length,
        );
      }
    } catch {
      // Ignore malformed trace file
    }
  };

  const handleExtendBudgetClick = async () => {
    if (onExtendBudget) {
      onExtendBudget(effectiveState.run_id);
      return;
    }
    if (effectiveState.run_id) {
      try {
        await apiClient.extendRunBudget(effectiveState.run_id);
      } catch {
        // Fallback in offline fixture mode
      }
    }
  };

  const isVirtualized = timelineItems.length > VIRTUAL_STEP_THRESHOLD;
  const visibleSlice: ReadonlyArray<TimelineItem> = useMemo(() => {
    if (!isVirtualized) return timelineItems;
    return timelineItems.slice(
      virtualStartIdx,
      virtualStartIdx + VIRTUAL_WINDOW_SIZE,
    );
  }, [isVirtualized, timelineItems, virtualStartIdx]);

  const topSpacerPx = isVirtualized ? virtualStartIdx * VIRTUAL_ROW_HEIGHT_PX : 0;
  const bottomSpacerPx = isVirtualized
    ? Math.max(
        0,
        (timelineItems.length - (virtualStartIdx + visibleSlice.length)) *
          VIRTUAL_ROW_HEIGHT_PX,
      )
    : 0;

  if (presentation === "inline" && !inlineExpanded) {
    return (
      <div
        className="odysseus-timeline-inline-bar"
        data-testid="timeline-inline-summary"
      >
        <button
          type="button"
          className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
          onClick={() => setInlineExpanded(true)}
          data-testid="timeline-inline-expand-btn"
        >
          ▸ {summaryMetrics.inlineHeaderLabel}
        </button>
        {onOpenInSidePanel ? (
          <button
            type="button"
            className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
            onClick={onOpenInSidePanel}
            data-testid="timeline-open-panel-btn"
          >
            Open Side Panel
          </button>
        ) : null}
        {onOpenRunView && effectiveState.run_id ? (
          <button
            type="button"
            className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
            onClick={() => onOpenRunView(effectiveState.run_id)}
            data-testid="timeline-open-runview-btn"
          >
            Run View ↗
          </button>
        ) : null}
      </div>
    );
  }

  const isBudgetExceeded =
    effectiveState.finish_reason === "budget_exceeded" ||
    effectiveState.finish_reason === "max_iterations" ||
    effectiveState.status === "budget_exceeded" ||
    effectiveState.status === "max_iterations";

  return (
    <section
      ref={timelineSectionRef}
      className={`odysseus-agent-timeline odysseus-timeline-${presentation}`}
      aria-label="Agent execution timeline"
      data-testid="agent-timeline"
      data-presentation={presentation}
    >
      {/* Top Summary & Controls Header */}
      <div className="odysseus-timeline-header">
        <div className="odysseus-timeline-title-group">
          {presentation === "inline" ? (
            <button
              type="button"
              className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
              onClick={() => setInlineExpanded(false)}
              data-testid="timeline-inline-collapse-btn"
            >
              ▾ {summaryMetrics.inlineHeaderLabel}
            </button>
          ) : (
            <strong data-testid="timeline-header-label">
              {summaryMetrics.inlineHeaderLabel}
            </strong>
          )}
          <span
            className={`odysseus-badge odysseus-status-${effectiveState.status}`}
            data-testid="timeline-run-status"
          >
            {effectiveState.status}
          </span>
        </div>

        <div className="odysseus-timeline-actions">
          <button
            type="button"
            className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
            onClick={() => navigateStep(-1)}
            data-testid="timeline-prev-step-btn"
          >
            [ Prev
          </button>
          <button
            type="button"
            className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
            onClick={() => navigateStep(1)}
            data-testid="timeline-next-step-btn"
          >
            Next ]
          </button>
          <button
            type="button"
            className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
            onClick={() => {
              const allExpanded = timelineItems.every(
                (it) => expandedStepIds[it.id] === true,
              );
              const nextMap: Record<string, boolean> = {};
              for (const it of timelineItems) {
                nextMap[it.id] = !allExpanded;
              }
              setExpandedStepIds(nextMap);
            }}
            data-testid="timeline-expand-all-btn"
          >
            {timelineItems.every((it) => expandedStepIds[it.id] === true)
              ? "Collapse all"
              : "Expand all"}
          </button>
          <button
            type="button"
            className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
            onClick={() => setFollowing((f) => !f)}
            data-testid="timeline-follow-toggle"
          >
            {following ? "Following ▸" : "Pause following"}
          </button>
          <button
            type="button"
            className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
            onClick={() => {
              setReplayActive((r) => !r);
              setReplayCursorSeq(maxSeq);
            }}
            data-testid="replay-mode-toggle"
          >
            {replayActive ? "Exit Replay" : "Replay Run"}
          </button>
          <button
            type="button"
            className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
            onClick={() => setRawInspectorOpen((o) => !o)}
            data-testid="raw-event-inspector-toggle"
          >
            {rawInspectorOpen ? "Hide Events" : "Raw Events"}
          </button>
          {presentation !== "inline" && effectiveState.run_id ? (
            <button
              type="button"
              className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
              onClick={() => {
                if (typeof BroadcastChannel !== "undefined") {
                  const ch = new BroadcastChannel("odysseus-timeline-sync");
                  ch.postMessage({
                    type: "timeline_popout",
                    runId: effectiveState.run_id,
                  });
                  ch.close();
                }
                window.open(
                  `/runs/${encodeURIComponent(effectiveState.run_id)}`,
                  "_blank",
                  "noopener,noreferrer,width=900,height=720",
                );
              }}
              data-testid="timeline-popout-btn"
            >
              Pop-out ↗
            </button>
          ) : null}
          {effectiveState.status === "running" && effectiveState.run_id ? (
            <button
              type="button"
              className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
              onClick={() =>
                void apiClient.pauseRun(effectiveState.run_id).catch(() => {})
              }
              data-testid="run-pause-btn"
            >
              Pause
            </button>
          ) : null}
          {(effectiveState.status === "paused" ||
            effectiveState.status === "interrupted") &&
          effectiveState.run_id ? (
            <button
              type="button"
              className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
              onClick={() =>
                void apiClient.resumeRun(effectiveState.run_id).catch(() => {})
              }
              data-testid="run-resume-btn"
            >
              {effectiveState.status === "interrupted" ? "Continue ▸" : "Resume ▸"}
            </button>
          ) : null}
          {effectiveState.status === "running" && onStopRun ? (
            <button
              type="button"
              className="odysseus-btn odysseus-btn-danger odysseus-btn-xs"
              onClick={() => onStopRun(effectiveState.run_id)}
              data-testid="run-stop-btn"
            >
              Stop (Esc)
            </button>
          ) : null}
        </div>
      </div>

      {/* Stats Strip & Budget Bar (FE-AGENT-06, 07) */}
      <div className="odysseus-stats-strip" data-testid="agent-stats-strip">
        <span data-testid="stats-elapsed">
          Elapsed: <strong>{(summaryMetrics.durationMs / 1000).toFixed(1)}s</strong>
        </span>
        <span data-testid="stats-iteration">
          Iter: <strong>{summaryMetrics.stepCount}/25</strong>
        </span>
        <span>
          Steps: <strong>{summaryMetrics.stepCount}</strong>
        </span>
        <span>
          Tools: <strong>{summaryMetrics.toolCount}</strong>
        </span>
        <span>
          Tokens: <strong>{summaryMetrics.totalTokens.toLocaleString()}</strong>
        </span>
        <span>
          Cost: <strong>${summaryMetrics.costUsd.toFixed(4)}</strong>
        </span>
        <span
          className={`odysseus-badge odysseus-tone-${summaryMetrics.contextTone}`}
          data-testid="context-window-meter"
        >
          Context: {summaryMetrics.contextPct}%
        </span>
        {isBudgetExceeded ? (
          <button
            type="button"
            className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
            onClick={() => void handleExtendBudgetClick()}
            data-testid="extend-budget-btn"
          >
            Budget exceeded → Extend & continue
          </button>
        ) : null}
      </div>

      {/* Memory & Skill Chips (FE-AGENT-16, 17) */}
      {effectiveState.memories_used.length > 0 ||
      effectiveState.memories_updated.length > 0 ||
      effectiveState.ordered_tool_call_ids.length > 0 ? (
        <div className="odysseus-memory-chip-row" data-testid="memory-chip-bar">
          {effectiveState.memories_used.length > 0 ? (
            <button
              type="button"
              className="odysseus-badge odysseus-btn-ghost"
              onClick={() => setMemoryPopoverOpen((o) => !o)}
              data-testid="memories-used-chip"
            >
              🧠 Used {effectiveState.memories_used.length} memories
            </button>
          ) : null}
          {effectiveState.memories_updated.map((m) =>
            undoneMemories[m.id] ? null : (
              <span
                key={m.id}
                className="odysseus-badge"
                data-testid={`memory-saved-chip-${m.id}`}
              >
                Saved to memory ({m.id}){" "}
                <button
                  type="button"
                  className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
                  onClick={() => {
                    setUndoneMemories((prev) => ({ ...prev, [m.id]: true }));
                    void fetch(`/api/memories/${encodeURIComponent(m.id)}`, {
                      method: "DELETE",
                      credentials: "same-origin",
                    }).catch(() => {});
                  }}
                  data-testid={`memory-undo-btn-${m.id}`}
                >
                  Undo
                </button>
              </span>
            ),
          )}
          {effectiveState.ordered_tool_call_ids.length > 0 ? (
            <span
              className="odysseus-badge"
              data-testid="skills-used-chip"
            >
              ⚡ Skill: <code>core-agent-tools</code> (matched tool intent){" "}
              <button
                type="button"
                className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
                onClick={() => useAppShellStore.getState().setWorkspace("skills")}
                data-testid="skills-used-edit-link"
              >
                Edit Skill
              </button>
            </span>
          ) : null}
          {memoryPopoverOpen ? (
            <div
              className="odysseus-memory-popover"
              data-testid="memories-used-popover"
            >
              <strong>Memories consulted:</strong>{" "}
              {effectiveState.memories_used.join(", ")}{" "}
              <button
                type="button"
                className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
                onClick={() => useAppShellStore.getState().setWorkspace("memory")}
                data-testid="memories-open-browser-btn"
              >
                Open Memory Browser
              </button>
            </div>
          ) : null}
        </div>
      ) : null}

      {/* Deterministic Replay Scrubber Bar (FE-AGENT-10) */}
      {replayActive ? (
        <div className="odysseus-replay-bar" data-testid="replay-scrubber-bar">
          <button
            type="button"
            className="odysseus-btn odysseus-btn-primary odysseus-btn-xs"
            onClick={() => {
              if (replayCursorSeq >= maxSeq) {
                setReplayCursorSeq(1);
              }
              setReplayPlaying((p) => !p);
            }}
            data-testid="replay-play-btn"
          >
            {replayPlaying ? "Pause ❚❚" : "Play ▶"}
          </button>
          <input
            type="range"
            min={1}
            max={maxSeq}
            value={Math.min(replayCursorSeq, maxSeq)}
            aria-label="Replay event sequence scrubber"
            onChange={(e) => {
              setReplayPlaying(false);
              setReplayCursorSeq(Number.parseInt(e.target.value, 10) || 1);
            }}
            data-testid="replay-scrubber-slider"
          />
          <span data-testid="replay-seq-indicator">
            Event {Math.min(replayCursorSeq, maxSeq)} / {maxSeq}
          </span>
          <label className="odysseus-replay-speed-label">
            <span>Speed:</span>
            <select
              className="odysseus-select odysseus-select-xs"
              value={replaySpeed}
              onChange={(e) =>
                setReplaySpeed(Number.parseInt(e.target.value, 10) || 1)
              }
              data-testid="replay-speed-select"
            >
              <option value={1}>1×</option>
              <option value={2}>2×</option>
              <option value={4}>4×</option>
              <option value={8}>8×</option>
            </select>
          </label>
          <button
            type="button"
            className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
            onClick={handleExportTrace}
            data-testid="trace-export-btn"
          >
            Export Trace
          </button>
          <label className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs">
            Import Trace
            <input
              type="file"
              accept=".json"
              style={{ display: "none" }}
              onChange={(e) => void handleImportTraceFile(e)}
              data-testid="trace-import-input"
            />
          </label>
        </div>
      ) : null}

      {/* Pinned Plan & Todo Tracker (FE-AGENT-03) */}
      <PinnedPlanTracker items={effectiveState.plan} />

      {/* Mid-run Steer Input (FE-COMP-06) */}
      {onSteerRun ? (
        <div className="odysseus-steer-bar" data-testid="run-steer-bar">
          <input
            type="text"
            className="odysseus-input odysseus-input-xs"
            placeholder="Steer agent mid-run…"
            aria-label="Steer agent mid-run"
            value={steerText}
            onChange={(e) => setSteerText(e.target.value)}
            data-testid="run-steer-input"
          />
          <button
            type="button"
            className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
            disabled={!steerText.trim()}
            onClick={() => {
              if (!steerText.trim()) return;
              onSteerRun(effectiveState.run_id, steerText.trim());
              setSteerText("");
            }}
            data-testid="run-steer-send-btn"
          >
            Steer
          </button>
        </div>
      ) : null}

      {/* Virtualized Scroll Container for Timeline Steps */}
      <div
        className="odysseus-timeline-steps-viewport"
        style={
          isVirtualized ? { maxHeight: "540px", overflowY: "auto" } : undefined
        }
        onScroll={(e) => {
          if (!isVirtualized) return;
          const scrollTop = e.currentTarget.scrollTop;
          const idx = Math.floor(scrollTop / VIRTUAL_ROW_HEIGHT_PX);
          setVirtualStartIdx(
            Math.max(
              0,
              Math.min(timelineItems.length - VIRTUAL_WINDOW_SIZE, idx),
            ),
          );
        }}
        data-testid="timeline-steps-viewport"
      >
        {isVirtualized ? (
          <div style={{ height: `${topSpacerPx}px` }} aria-hidden="true" />
        ) : null}

        {visibleSlice.map((item) => {
          const isStepExpanded =
            expandedStepIds[item.id] ?? item.defaultExpanded;
          const isFocusedStep = timelineItems[activeStepIdx]?.id === item.id;

          return (
            <div
              key={item.id}
              id={`s=${item.stepId}`}
              className={`odysseus-timeline-step odysseus-step-kind-${item.kind} ${
                isFocusedStep ? "odysseus-step-focused" : ""
              }`}
              data-testid={`timeline-step-${item.stepId}`}
              data-step-index={item.index}
              data-step-status={item.status}
            >
              <div className="odysseus-timeline-step-header">
                <button
                  type="button"
                  className="odysseus-btn odysseus-btn-ghost odysseus-step-toggle"
                  aria-expanded={isStepExpanded}
                  onClick={() => {
                    setActiveStepIdx(item.index);
                    setExpandedStepIds((prev) => ({
                      ...prev,
                      [item.id]: !isStepExpanded,
                    }));
                    window.history.replaceState(
                      null,
                      "",
                      `#s=${encodeURIComponent(item.stepId)}`,
                    );
                  }}
                  data-testid={`timeline-step-toggle-${item.stepId}`}
                >
                  <span>{isStepExpanded ? "▾" : "▸"}</span>
                  <span className="odysseus-step-kind-badge">{item.kind}</span>
                  <strong className="odysseus-step-title">{item.title}</strong>
                </button>
                <div className="odysseus-timeline-step-meta">
                  {item.note ? (
                    <span
                      className="odysseus-badge odysseus-badge-warning"
                      data-testid={`step-note-${item.stepId}`}
                    >
                      {item.note}
                    </span>
                  ) : null}
                  <span className={`odysseus-badge odysseus-status-${item.status}`}>
                    {item.status}
                  </span>
                  <span className="odysseus-text-muted">{item.durationMs} ms</span>
                  {item.artifact && onOpenArtifact ? (
                    <button
                      type="button"
                      className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
                      onClick={() =>
                        onOpenArtifact(item.artifact?.artifact_id ?? "")
                      }
                      data-testid={`open-artifact-${item.artifact.artifact_id}`}
                    >
                      Open in Canvas
                    </button>
                  ) : null}
                </div>
              </div>

              {isStepExpanded ? (
                <div
                  className="odysseus-timeline-step-body"
                  data-testid={`timeline-step-body-${item.stepId}`}
                >
                  {item.thinkingText ? (
                    <pre className="odysseus-thinking-pre">
                      {item.thinkingText}
                    </pre>
                  ) : null}

                  {item.approval ? (
                    <ApprovalCard
                      runId={effectiveState.run_id}
                      approval={item.approval}
                      toolCall={item.toolCall}
                      onResolved={onApprovalResolved}
                    />
                  ) : null}

                  {item.toolCall ? (
                    <ToolCallCard
                      toolCall={item.toolCall}
                      defaultExpanded={true}
                    />
                  ) : null}

                  {item.subagent ? (
                    <SubagentTreeNode
                      subagent={item.subagent}
                      onJumpToChildRun={onOpenRunView}
                    />
                  ) : null}

                  <div className="odysseus-row-wrap">
                    <button
                      type="button"
                      className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
                      onClick={() => {
                        if (effectiveState.run_id) {
                          void apiClient
                            .steerRun(
                              effectiveState.run_id,
                              `Retry step ${item.stepId} (${item.title})`,
                            )
                            .catch(() => {});
                        }
                      }}
                      data-testid={`step-retry-btn-${item.stepId}`}
                    >
                      ↻ Retry step
                    </button>
                    <button
                      type="button"
                      className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
                      onClick={() => {
                        if (effectiveState.run_id) {
                          void apiClient
                            .steerRun(
                              effectiveState.run_id,
                              `Re-run from step ${item.stepId}`,
                            )
                            .catch(() => {});
                        }
                      }}
                      data-testid={`step-rerun-btn-${item.stepId}`}
                    >
                      ⏮ Re-run from step
                    </button>
                  </div>
                </div>
              ) : null}
            </div>
          );
        })}

        {isVirtualized ? (
          <div style={{ height: `${bottomSpacerPx}px` }} aria-hidden="true" />
        ) : null}
      </div>

      {/* Raw Event Inspector Drawer (FE-AGENT-11) */}
      {rawInspectorOpen ? (
        <div
          className="odysseus-raw-event-inspector"
          data-testid="raw-event-inspector"
        >
          <div className="odysseus-raw-inspector-toolbar">
            <strong>Raw Event Stream ({events.length} events)</strong>
            <input
              type="search"
              className="odysseus-input odysseus-input-xs"
              placeholder="Filter event type…"
              aria-label="Filter raw events by type"
              value={rawEventFilter}
              onChange={(e) => setRawEventFilter(e.target.value)}
              data-testid="raw-event-filter-input"
            />
            <button
              type="button"
              className="odysseus-btn odysseus-btn-secondary odysseus-btn-xs"
              onClick={() =>
                void navigator.clipboard?.writeText(
                  JSON.stringify(events, null, 2),
                )
              }
              data-testid="raw-event-copy-fixture-btn"
            >
              Copy as test fixture
            </button>
          </div>
          <div className="odysseus-raw-event-list">
            {events
              .filter(
                (ev) =>
                  !rawEventFilter.trim() ||
                  ev.type.toLowerCase().includes(rawEventFilter.toLowerCase()),
              )
              .slice(0, 100)
              .map((ev, idx, arr) => {
                const prevTs = idx > 0 ? Date.parse(arr[idx - 1]?.ts ?? "") : NaN;
                const curTs = Date.parse(ev.ts);
                const deltaMs =
                  !Number.isNaN(prevTs) && !Number.isNaN(curTs)
                    ? Math.max(0, curTs - prevTs)
                    : 0;
                return (
                  <div key={ev.seq} className="odysseus-raw-event-row">
                    <code>#{ev.seq}</code> <strong>{ev.type}</strong>{" "}
                    <span className="odysseus-text-muted">
                      {ev.ts} (+{deltaMs} ms)
                    </span>{" "}
                    <button
                      type="button"
                      className="odysseus-btn odysseus-btn-ghost odysseus-btn-xs"
                      onClick={() =>
                        void navigator.clipboard?.writeText(
                          JSON.stringify(ev, null, 2),
                        )
                      }
                      data-testid={`raw-event-copy-${ev.seq}`}
                    >
                      Copy JSON
                    </button>
                    <pre className="odysseus-code-pre">
                      {JSON.stringify(ev.data)}
                    </pre>
                  </div>
                );
              })}
          </div>
        </div>
      ) : null}
    </section>
  );
};
