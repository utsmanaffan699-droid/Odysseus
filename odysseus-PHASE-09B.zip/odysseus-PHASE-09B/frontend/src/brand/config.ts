export const brand = {
  "productName": "Odysseus",
  "tagline": "A quiet workspace for consequential work.",
  "legalLine": "Self-hosted software for your work, your data, your decisions.",
  "markPath": "/brand/logo/mark.svg",
  "glyphPath": "/brand/logo/glyph.svg",
  "version": "0.1.0"
} as const;
