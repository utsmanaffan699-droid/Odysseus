import React from "react";

export const iconNames = [
  "activity","agent","approval","archive","artifact","attachment","audio","automation","backup","calendar","checkpoint","chat","check","chevron-down","chevron-left","chevron-right","chevron-up","clock","close","code","compare","copy","database","document","download","edit","email","error","external","file","folder","gallery","globe","graph","health","help","history","home","info","key","knowledge","link","lock","memory","menu","model","more","note","pause","play","plus","provider","refresh","research","run","search","send","settings","shield","spark","stop","success","tool","trash","upload","voice",
] as const;
export type IconName = (typeof iconNames)[number];
export interface IconProps extends React.SVGProps<SVGSVGElement> { readonly name: IconName; readonly label?: string; }
export function Icon({ name, label, className = "", ...props }: IconProps): React.ReactElement {
  return <svg viewBox="0 0 24 24" aria-hidden={label ? undefined : true} aria-label={label} role={label ? "img" : undefined} className={`odysseus-icon ${className}`.trim()} {...props}><use href={`/brand/icons/${name}.svg#${name}`} /></svg>;
}
