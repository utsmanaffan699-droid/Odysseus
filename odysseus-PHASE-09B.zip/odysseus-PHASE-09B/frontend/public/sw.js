const CACHE_NAME = "product-name-shell-v2";
const SHELL_ASSETS = ["/", "/index.html", "/offline.html", "/manifest.webmanifest", "/favicon.svg", "/icon-192.png", "/brand/logo/glyph.svg"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(SHELL_ASSETS)).catch(() => {}),
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((k) => k !== CACHE_NAME)
          .map((k) => caches.delete(k)),
      ),
    ),
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET" || req.url.includes("/api/")) {
    return;
  }
  event.respondWith(
    fetch(req).catch(() => caches.match(req).then((cached) => cached || (req.mode === "navigate" ? caches.match("/offline.html") : caches.match("/index.html")))),
  );
});
