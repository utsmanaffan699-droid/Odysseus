import config from "./brand.config.json";
export default config;
export type BrandConfig = typeof config;
