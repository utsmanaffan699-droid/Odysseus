# Font policy

PHASE-09A ships no remote font request. The runtime stack uses metric-stable system fallbacks (`Inter`, `Source Serif 4`, and `IBM Plex Mono` when installed, then system equivalents) so clean/offline deployments remain functional. Before bundling font files, obtain and commit the exact SIL OFL license and a subset manifest here; do not download fonts at runtime.
