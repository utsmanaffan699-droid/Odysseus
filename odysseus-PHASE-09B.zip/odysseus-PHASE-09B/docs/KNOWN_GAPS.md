# Known Gaps (`docs/KNOWN_GAPS.md`)

This document tracks features belonging to future phases and dependencies that require an external operator. Security controls described here are implemented in the current PHASE-08 tree; they are not claims that optional external services are available in every deployment.

| ID / Area | Phase Target | Current Status | Notes |
|---|---|---|---|
| Productivity Suite tools (`notes_*`, `todos_*`, `calendar_*`, `email_*`) and workspaces (`FE-WORK-04..07`, `FE-ADMIN-04`, `FE-AGENT-14`) | PHASE-07 | Completed | All 18 productivity tools are enabled and backed by the corresponding domain services. |
| Microsoft 365 / Outlook Live Azure AD Tenant OAuth | PHASE-07 | Completed (Mock + XOAUTH2 SASL) | Live Azure AD tenant authentication still requires operator-supplied `M365_OAUTH_CLIENT_ID` / `M365_OAUTH_CLIENT_SECRET`. |
| Gallery / Image Editor, Cookbook & Hardware Advisor, Voice Mode, and Admin Ops Dashboards | PHASE-08 | Completed | CPU/test-fixture paths are implemented and tested. |
| Physical NVIDIA / AMD / Apple Metal GPU hardware and optional Kokoro-82M ONNX weights | PHASE-08 | Environment-dependent | CI is a CPU VM. CPU GGUF serving, 24 hardware fixtures, and optional-runtime detection are tested; physical GPU acceleration and real Kokoro weights require host hardware/assets. |
| Docker execution backend | PHASE-02/03 | Intentionally unavailable unless hardened backend is present | The execution registry refuses `docker` when no implementation is configured. `bwrap` is also fail-closed when absent; the default subprocess backend is not advertised as a container or filesystem/network jail. Deployments must install/configure the hardened backend before enabling unsandboxed execution. |
| DNS-pinned web fetch | PHASE-03/06 | Implemented for real network transport | `web_tools.fetch_web_page` and research fetches resolve and validate addresses by default when using the real transport, and revalidate redirects. Injected test transports intentionally skip network DNS pinning. |
| External mail providers and outbound delivery | PHASE-07 | Integration boundary | Mail parsing, sanitization, ownership, OAuth/XOAUTH2 construction, and outbox behavior are tested. Actual IMAP/SMTP connectivity requires operator configuration and credentials. |
| GPU/browser/clamd/Postgres availability | Deployment | Environment-dependent | The application fails closed or reports the dependency unavailable where required; local tests use explicit fixtures or the configured test service. |

## PHASE-09A verification blockers (2026-10-05)

- `make verify` with `.venv`: 370 backend tests pass, but coverage is 85.09% versus the required 85%; gate fails and was not lowered.
- Latest full Playwright rerun: 15 passed / 0 failed: attachment-remove DOM detach, two serious color-contrast findings, and `mail-triage-result` after `mail-triage-btn`.
- Docker build dan acceptance smoke lulus setelah membersihkan Docker build cache: image `odysseus:phase09a`, readiness 200, CSP header, dan offline asset terverifikasi.
- The repository lint configuration still has broad legacy/utility ignores; this is technical debt, not a completed quality gate.
- Tag `phase-09a` exists; PHASE-09B remains intentionally out of scope until separately authorized.

## PHASE-09B (in progress, 2026-10-05)

- The first audit infrastructure pass is present: `make ui-census` emits the initial 36-image boot/auth matrix, `make ui-lint` and `make ui-score` are wired.
- The census now covers the authenticated workspace routes in addition to the 36-image boot/auth matrix (55 deterministic images total). Full per-route state variants and the complete R8 matrix remain open.
- `docs/ui-audit/FINDINGS.md` contains the 120-item first-pass review. P1/P2 closure, after-census comparisons, and the 20 competitive journeys remain open.
- FE-X mandatory features (reasoning/privacy/parser fuzz, deterministic summaries, context inspector, checkpoints/revert, queue, model routing transparency, lockdown policy enforcement, trust surfaces, import/export, notifications, education, and polish) are not yet claimed complete.
- Protocol v1.1 additive fixtures, reducer coverage, Storybook states, cross-browser matrix, A1-A15 audit evidence, and final visual baselines remain open.
- `phase-09b` must not be created until all required features and verification gates pass.
- Lockdown enforcement now has a server-side policy-engine primitive and unit coverage; session persistence, UI banner, exact disabled-tool list, and raw-request integration coverage remain open.
- The initial FE-X panel is mounted in the run inspector, but queue actions, checkpoint/revert operations, secret scanning, egress provider warnings, and backend persistence are not yet complete.
