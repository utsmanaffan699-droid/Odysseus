# Odysseus Design System (`docs/DESIGN.md`)

## 1. Core Principles

1. **Zero Hard-Coded Colors Outside `tokens.css`:**
   - Every color in the application is defined as a semantic CSS custom property in `frontend/src/design-system/tokens.css`.
   - Automated Vitest verification (`contractsAndSecurity.test.ts`) scans all `.css`, `.ts`, and `.tsx` files outside `tokens.css` and fails CI if any raw hex (`#...`) or `rgb(...)` literal is introduced.
2. **Three Curated Palettes × Three Theme Modes:**
   - Themes: `dark` (default), `light`, and `high-contrast` (WCAG AAA ≥ 10:1).
   - Palettes: `slate` (Odysseus Indigo/Slate), `amber` (Solar Amber), and `forest` (Emerald Forest).
   - Density: `comfortable` and `compact`; Message Width: `narrow` (`48rem`) and `wide` (`68rem`).
   - Applied via `data-theme`, `data-palette`, `data-density`, `data-font-size`, and `data-message-width` attributes on `document.documentElement` so theme/density transitions happen in 0 ms without layout shift on closed Markdown blocks.
3. **Accessibility First (`FE-QA-01`, `FE-QA-02`):**
   - Minimum `44×44 px` touch target (`--touch-target: 44px`) on interactive buttons and controls.
   - High-visibility `:focus-visible` ring (`--focus-ring`) across all 20 primitives.
   - `@media (prefers-reduced-motion: reduce)` zeroes out transition/animation durations and disables cosmetic stream smoothing.

## 2. Primitive Inventory (`frontend/src/design-system/primitives.tsx`)

All 20 catalog primitives (`FE-QA-01`) are implemented and showcased in `StorybookCatalog.tsx` (`#/storybook` and static build `frontend/storybook-static/`):
- `Button`, `IconButton`, `Input`, `Select`, `Combobox`, `Tabs`, `Dialog` (focus-trapped), `Drawer`, `Popover`, `Tooltip`, `ToastRegion` (polite live region + undo action), `Menu` (roving `tabIndex` with `ArrowUp`/`ArrowDown`), `Table`, `Tree`, `Skeleton`, `Badge`, `Progress`, `Switch`, `Slider`, `Kbd`.

## 7. PHASE-09A Brand Layer

The visual identity is **Waypoint Loop**, an original measured loop with a waypoint. Its source of truth is `brand/brand.config.json`, with authored SVG in `brand/logo/`, semantic token JSON in `brand/tokens/`, and generated runtime assets in `frontend/public/`. The product name remains the safe placeholder `PRODUCT_NAME` until the operator supplies a name. `make brand-assets` regenerates the PWA/favicon set; `make brand-sheets` renders contact sheets; `make brand-verify` checks required mark sizes and the maskable safe zone; `make icons` validates the 66-icon manifest; `make brand-contrast` writes the AA table.

The runtime uses mineral teal, terracotta, warm paper, and deep ink. No runtime CDN assets are introduced. All semantic surfaces use CSS variables; status colors remain separate from the brand accent. The mark has an open top-left interruption, a square waypoint, and a construction diagram in `brand/construction/`.
