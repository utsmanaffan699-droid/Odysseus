# Odysseus Architecture (`docs/ARCHITECTURE.md`)

## 1. System Overview

Odysseus is a self-hosted, single-binary/container-deployable AI workspace with an integrated agent runtime, durable event log, strict security boundary, and offline-capable React 19 frontend served directly by the FastAPI backend.

```mermaid
flowchart TB
    subgraph Client["Browser / PWA Client (React 19 + Vite, Strict CSP)"]
        UI["UI Shell & Views"]
        Reducer["Pure Event Reducer\nreduceRunState(events)"]
        APIClient["Generated Typed API Client\n(openapi.json + event-schema.json)"]
        UI --> APIClient
        APIClient -->|SSE /api/runs/:id/events| Reducer
        Reducer --> UI
    end

    subgraph Edge["Security & Observability Middleware"]
        MW1["Trusted Proxy & Host Validator"]
        MW2["Header/Body Limits & Read Timeout"]
        MW3["Rate Limiter (IP + Route)"]
        MW4["CSRF Double-Submit + Session/Bearer Auth"]
        MW5["Strict CSP + Security Headers + Structlog/Metrics"]
        MW1 --> MW2 --> MW3 --> MW4 --> MW5
    end

    subgraph Backend["FastAPI Backend (backend/app + backend/core)"]
        Routers["REST & SSE Routers\n(Enforced by ROUTE_POLICIES)"]
        Auth["Auth Service\n(Argon2id, TOTP 2FA, Sessions, API Tokens)"]
        Audit["Tamper-Evident Audit Log\n(SHA-256 Hash Chain)"]
        Vault["Envelope Encryption Vault\n(AES-256-GCM + Master Key)"]
        Supervisor["Durable Job & Run Supervisor\n(Leases, Heartbeats, Retries, Dead-Letter)"]
        Providers["LLM Provider Layer\n(FakeProvider DSL + Real Adapters)"]
    end

    subgraph Storage["Persistence & Optional Services"]
        DB[("SQLite (WAL + FK + BusyTimeout)\nor PostgreSQL 17")]
        Opt["Optional Services\n(ChromaDB, SearXNG, ntfy)"]
    end

    APIClient ==> Edge ==> Routers
    Routers --> Auth
    Routers --> Audit
    Routers --> Vault
    Routers --> Supervisor
    Supervisor --> Providers
    Auth --> DB
    Audit --> DB
    Vault --> DB
    Supervisor --> DB
    Routers -.->|Graceful Degradation| Opt
```

## 2. Core Principle: Durable Runs, Thin Connections

An **agent run executes on the server independently of any HTTP connection**:

1. **Append-Only Event Log (`run_events`):** Every observable state change (`run.started`, `step.started`, `message.text.delta`, `tool.call.proposed`, `tool.approval.requested`, `usage.updated`, `run.finished`, etc.) is assigned a strictly increasing per-run sequence number (`seq = 1, 2, ...`) and persisted to `run_events`. A database uniqueness constraint plus bounded retry handles concurrent appenders; callers should still treat a failed append as an operational error rather than assuming delivery.
2. **Resumable SSE Subscriptions:** Clients connect to `GET /api/runs/{id}/events?after=<seq>` (or send `Last-Event-ID: <seq>`). Multiple browser tabs or devices can watch the same run simultaneously.
3. **Deterministic State Reconstruction:** Both backend and frontend derive run state via `reduceRunState(events)`. Reloading a tab mid-stream replays events from `seq=0` (or from a snapshot cursor via `stream.resync` if a client falls behind `ODYSSEUS_SSE_MAX_LAG_EVENTS`).
4. **Crash & Restart Resilience:** On server shutdown or after an ungraceful crash (`kill -9`), the startup recovery hook and `JobSupervisor` detect expired job leases (`leased_until <= now`), re-lease unfinished jobs without double execution, and transition any mid-flight `running` runs to `interrupted` while appending a durable `run.status{"status": "interrupted"}` event so the user can resume them cleanly.

## 3. Defense-in-Depth Security Model

- **Route Policy Registry (`ROUTE_POLICIES`):** Every FastAPI endpoint is registered with an explicit policy (`public`, `authenticated`, or a specific privilege flag such as `admin`, `chat`, `agent`). An automated test walks `app.routes` and fails if any route is missing from the registry.
- **Session & Token Hardening:** Pre-login session IDs are never accepted; login mints a fresh CSPRNG session token (stored as `sha256` hash in DB) and binds a CSRF token. Unsafe cookie-authenticated requests require matching `X-CSRF-Token`. Scoped `Authorization: Bearer ody_...` API tokens bypass CSRF but enforce token expiry and scope privileges.
- **Envelope Encryption:** Secrets at rest (`EncryptedSecret` and user TOTP secrets) are encrypted with per-record 256-bit AES-GCM Data Encryption Keys (DEKs) wrapped by a master Key Encryption Key (`data/master.key`, mode `0600`).
- **Tamper-Evident Audit Chain:** Every security event appends a row to `audit_log` linked to the previous row's `record_hash`. Any out-of-band DB modification is detected by `verify_audit_chain()`.
