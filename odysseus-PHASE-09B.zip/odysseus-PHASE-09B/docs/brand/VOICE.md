# Voice and tone

Write like a calm operator: short, specific, and useful. Say what happened, why it matters, and what the person can do next. Avoid hype, blame, anthropomorphic claims, and vague reassurance.

- Good: “The provider did not respond. Check its health or choose another model.”
- Avoid: “Oops! Something went wrong — please try again.”
- Empty states explain what the surface is, why it is empty, and one primary action.
- Indonesian uses “ruang kerja”, “percakapan”, “berkas”, “penyedia”, “izin”, and “jalankan” consistently.

## Glossary
| English | Bahasa Indonesia |
|---|---|
| workspace | ruang kerja |
| run | proses |
| approval | persetujuan |
| provider | penyedia |
| attachment | lampiran |
| artifact | artefak |
| checkpoint | titik pemulihan |
| tool | alat |
| memory | memori |
| egress | lalu lintas keluar |
