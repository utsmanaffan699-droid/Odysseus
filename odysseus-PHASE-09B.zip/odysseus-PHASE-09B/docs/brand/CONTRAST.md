# Brand contrast table

| Theme | Foreground | Background | Ratio | Result |
|---|---|---|---:|---|
| light | ink | canvas | 14.18 | PASS |
| light | ink | surface | 15.21 | PASS |
| light | primary | canvas | 6.90 | PASS |
| light | primary | surface | 7.40 | PASS |
| light | secondary | canvas | 4.55 | PASS |
| light | focus | canvas | 5.17 | PASS |
| dark | ink | canvas | 15.87 | PASS |
| dark | ink | surface | 14.18 | PASS |
| dark | primary | canvas | 9.49 | PASS |
| dark | primary | surface | 8.48 | PASS |
| dark | secondary | canvas | 8.01 | PASS |
| dark | focus | canvas | 9.60 | PASS |
| highContrast | ink | canvas | 21.00 | PASS |
| highContrast | ink | surface | 19.91 | PASS |
| highContrast | primary | canvas | 16.68 | PASS |
| highContrast | primary | surface | 15.81 | PASS |
| highContrast | secondary | canvas | 13.28 | PASS |
| highContrast | focus | canvas | 21.00 | PASS |
