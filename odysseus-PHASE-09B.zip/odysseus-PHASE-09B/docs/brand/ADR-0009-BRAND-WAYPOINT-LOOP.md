# ADR-0009: Waypoint Loop brand system

- **Status:** Accepted
- **Context:** PHASE-09A needs a distinctive, swappable identity without copying an existing AI product or relying on runtime assets.
- **Options:** Waypoint Loop; Threshold Pair; Ledger Line.
- **Decision:** Waypoint Loop, scored 27/30 for distinctiveness, 16px legibility, monochrome survival, ownability, tone fit, and implementation cost. Keep the other two in `brand/alternatives/` and do not wire them into the product.
- **Resemblance check:** It may evoke generic wayfinding, loading loops, and editorial indexing, but its open squared geometry, offset waypoint, palette, and construction are distinct from pins, chat bubbles, robots, brains, circuits, and gradient AI marks.
- **Consequences:** Brand config is the switch point; generated assets and semantic tokens must not hard-code the placeholder name. A future rebrand changes config and the generated asset command, not feature components.
