# Brand strategy: Waypoint Loop

## Essence
`PRODUCT_NAME` is a self-hosted workspace for private, accountable work: a calm place where conversations become decisions, runs leave evidence, and tools stay under the operator's control.

## Audience and personality
Technical power users, privacy-minded individuals, and small teams. The personality is calm rather than loud, precise rather than austere, and warm rather than playful. Five principles: **quiet confidence**, **visible accountability**, **measured motion**, **human-readable defaults**, and **local control**.

## Visual territory
The identity uses a measured open loop with a waypoint: an ordered path that can pause and resume. It avoids brains, circuits, robots, sparkles, chat bubbles, gradient orbs, and nautical mythology. Mineral teal signals continuity; terracotta marks decisions and attention; warm paper keeps dense information humane.

## Three directions
| Direction | Idea | Score / 30 | Decision |
|---|---|---:|---|
| Waypoint Loop | Open measured path with a square waypoint; survives interruption and reads at 16 px. | 27 | **Recommended** |
| Threshold Pair | Two offset gates; a visual metaphor for approval and controlled egress. | 23 | Archive |
| Ledger Line | Monoline index and stepped record; emphasizes evidence and auditability. | 22 | Archive |

## Resemblance check
The closest associations are generic map pins, loading loops, and editorial wayfinding systems. This mark is different because it is an open squared path with a deliberate gap and a small offset waypoint, not a pin, circle, star, robot, or speech bubble. It uses a mineral/terracotta palette rather than a familiar AI blue-purple gradient. The construction, wordmark, and icon geometry are original to this project.
