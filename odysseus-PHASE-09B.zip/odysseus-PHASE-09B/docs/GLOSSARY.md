# Product glossary

| en | id | Usage |
|---|---|---|
| workspace | ruang kerja | A bounded product area, not a filesystem workspace unless stated. |
| run | proses | One agent execution and its timeline. |
| approval | persetujuan | Human decision required by tool policy. |
| provider | penyedia | A model endpoint or local model. |
| artifact | artefak | A generated document, file, or canvas output. |
| checkpoint | titik pemulihan | Durable point from which work can be restored. |
| egress | lalu lintas keluar | Data leaving the local deployment. |
