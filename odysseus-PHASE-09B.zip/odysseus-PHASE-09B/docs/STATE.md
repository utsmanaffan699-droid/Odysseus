# Project State (`docs/STATE.md`)

- **Current Phase:** PHASE-09A — **IN PROGRESS** (brand foundation, authored SVG system, tokens, icon lint, and frontend restyle layer landed)
- **Previous Phase:** PHASE-08 (`phase-08` tag) — **COMPLETED**
- **Next Phase:** PHASE-09B (fresh-eyes UI audit/polish)

## 1. Delivered in Phase 01 (`phase-01`)

1. **Repository, Security & Core Foundation (`backend/core/`, `backend/app/`):**
   - Layered `pydantic-settings` config (`Settings`, 28 bad-config cases, UTF-8 BOM/CRLF `.env` parser, runtime DB settings override).
   - Async SQLAlchemy 2 + Alembic (`0001_initial_foundation`), SQLite WAL + PostgreSQL 17 support.
   - Auth & Security: Argon2id password hashing, first-boot admin bootstrap, hashed opaque sessions, TOTP 2FA + recovery codes, scoped `ody_...` API tokens, login throttling, `ROUTE_POLICIES` privilege enforcement, strict CSP, CSRF double-submit, body/header/timeout caps, `ENOSPC` 507 handling, AES-256-GCM envelope encryption, hash-chained audit log, and `JobSupervisor`.
2. **Contract Machinery & Frontend Skeleton:**
   - 35 v1 event types (`backend/domain/events.py`), state reducers (`backend/domain/runs/reducer.py`, `frontend/src/lib/runReducer.ts`), `FakeProvider`, OpenAPI/JSON Schema/TS codegen, and React 19 + Vite + TypeScript strict + Playwright Chromium E2E.

## 2. Delivered in Phase 02 (`phase-02`)

1. **Provider Layer (`backend/providers/`):**
   - Unified `stream_chat(request) -> AsyncIterator[ProviderEvent]` and `ClassifiedProviderError` taxonomy (`auth`, `rate_limit`, `overloaded`, `context_length`, `content_filter`, `invalid_request`, `network`, `timeout`, `unknown`).
   - Concrete streaming adapters: `OpenAICompatibleAdapter` (`/v1/chat/completions` & `/v1/responses`, native + `text_fenced` tool parsing), `AnthropicMessagesAdapter` (thinking blocks, tool use, prompt caching headers), `GeminiAdapter`, and `FakeProviderAdapter` + mock HTTP servers.
   - Capabilities matrix, conservative `text_fenced` default for local `/v1`, tri-state `supports_tools` override, live endpoint probing, exponential backoff + full jitter honoring `Retry-After`, per-provider circuit breaker, fallback chains, secret redaction, and dev-only AES-256-GCM encrypted raw exchange capture.
2. **Message Tree, Attachments, Projects & Chat Service (`backend/domain/chats/`):**
   - Branching message tree (`parent_id`, `branch_index`, `active_leaf_id`): append, edit-and-resubmit, regenerate, fork chat, delete subtree, activate branch, `<10 ms` 10k-node active path resolution, and Hypothesis tree-invariant property tests.
   - Resumable chunked uploads (`POST /api/uploads`, `GET /api/attachments/{sha}`), SHA-256 content addressing, MIME sniffing, ClamAV hook, PDF text extraction (`pypdf`), and image thumbnails (`Pillow`).
   - Projects CRUD (`/api/projects`), `PromptBuilder` with deterministic section ordering and per-section token budgets, background title generation, rolling chat summarization, and FTS search (`GET /api/chats/search`).
3. **Durable Run Engine, Usage Accounting & Debug Stream (`backend/domain/runs/`):**
   - `RunManager` single-writer `append_event(run_id, type, data) -> seq`, in-process pub/sub fan-out, SSE replay + live handoff (`GET /api/runs/{id}/events?after=<seq>` & `Last-Event-ID`), delta coalescing & `<= 8 KB` UTF-8 chunking, slow-reader `stream.resync`, `cancel`/`pause`/`resume`/`steer`, `kill -9` crash recovery + zero-duplicate resume, budgets, fair queueing, `Idempotency-Key`, `usage_ledger` Decimal cost rollups (`GET /api/usage`), `POST /api/tokens/estimate`, `/debug/stream`, and 13 golden fixtures.

## 3. Delivered in Phase 03 (`phase-03`)

1. **Agent Loop & Sub-Agents (`backend/domain/agents/`):**
   - Explicit step state machine (`plan? → model_step → (tool_calls → policy → [approval] → execute → observe)* → finalize`), dual tool transports (native JSON Schema + tolerant Hypothesis-fuzzed `parse_fenced_tool_calls` with 1-step repair re-ask), bounded parallel read vs. serialized write/exec execution, repeated-identical-call detection (nudge then abort), steering, pause/cancel/resume, and bounded `spawn_agent` child runs (`subagent.started/finished`, depth cap `<= 2`, fan-out cap `<= 3`).
2. **Tool Framework, Policy Engine & Approvals (`backend/domain/tools/`, `backend/tools/`):**
   - 22 built-in tools + 4 Phase-07 stubs: `web_search`, SSRF-safe `fetch_url`, `youtube_transcript`, workspace-jailed `read_file`/`write_file`/`edit_file`/`list_dir`/`glob`/`grep`, process-group + `rlimit` sandboxed `shell` & `python` with live `tool.output.delta`, `memory_search`/`memory_save`, `load_skill`, `update_plan`, `create_artifact`/`update_artifact`, `spawn_agent`, `read_tool_output`, and `discover_tools`.
   - Pure `ToolPolicyEngine` (`deny > ask > auto`), structured approval patterns (`argv_prefix`, `path_glob`, `host_allow`, `tool_exact`), homoglyph/BiDi anti-spoofing (`normalize_and_flag_approval_args`), and resolution via API (`POST /api/approvals/{id}/resolve`), slash command (`/approve <id>`), and CLI (`odysseus approvals`).
3. **MCP, Skills, Memory, Context Budgeter & Red-Team Defense (`backend/mcp/`, `backend/domain/skills/`, `backend/domain/memory/`):**
   - `McpClientManager` (`stdio`, `sse`, `streamable_http`), auto-restart health checks, description sanitization, and bundled `filesystem_server` & `fetch_server`.
   - Progressive-disclosure Markdown skills (`SKILL.md`, user/project/global scopes, untrusted zip/URL review flag, versioning + diff).
   - Hybrid semantic + Okapi BM25 memory service with ChromaDB fallback (`/api/health/degraded`) and single hard privacy switch (`memory_enabled`).
   - `ContextBudgeter` across 5 profiles (`4k`, `8k`, `16k`, `32k`, `large`), dynamic top-k tool selection, reversible history compaction (`context.compacted`) preserving needle facts, provenance taint tracking (`<untrusted_data_{nonce}>`), Markdown exfiltration sanitization, and a 105-case red-team injection corpus (`test_injection_corpus.py`).

## 4. Delivered in Phase 04 (`phase-04`)

1. **Frontend Architecture & Core Libraries (`frontend/src/lib/`, `frontend/src/workers/`):**
   - Generated OpenAPI client (`api.gen.ts`) & 35 v1 event types (`events.gen.ts`) with single-source CI drift checks.
   - Resilient `fetch` + `ReadableStream` SSE client (`sse.ts`) with `Last-Event-ID`, cursor tracking, exponential backoff + jitter, `stream.resync`, and offline/online recovery.
   - Pure, total, immutable $O(1)$ `runReducer` (`runReducer.ts`) verified against all 13 golden fixtures.
   - Incremental streaming Markdown splitter & sanitizer (`markdown.ts` + `markdown.worker.ts`) with FNV-1a closed-block memoization, `requestAnimationFrame` open-block coalescing, 2,000-run `fast-check` chunking invariance proof, and 220-payload XSS corpus verification.
   - Focused Zustand slices (`ui`, `composer`, `settings`, `runs`) + `BroadcastChannel` cross-tab sync (`broadcast.ts`).
2. **Design System & Storybook (`frontend/src/design-system/`, `docs/DESIGN.md`):**
   - Complete CSS custom property token system (`tokens.css`: 3 palettes × light/dark + high-contrast, fluid typography, 4 px spacing grid, motion tokens, z-index map) with zero hard-coded colors outside `tokens.css`.
   - 20 accessible primitives and static Storybook build (`npm run build-storybook`).
3. **App Shell, Composer, Virtualized Message List & Settings (`frontend/src/features/`):**
   - App Shell (`FE-SHELL-01…12, 14…18`), Composer (`FE-COMP-01…09, 11`), Message List (`FE-MSG-01…15, 17, 18`), and Settings & Providers (`FE-ADMIN-01, 02`).

## 5. Delivered in Phase 05 (`phase-05`)

1. **Agent Timeline, Plan, Stats, Sub-Agents & Replay (`frontend/src/features/agent/timeline/AgentTimeline.tsx`, `frontend/src/lib/runReducer.ts`):**
   - Presentational timeline fed solely by memoized `selectTimelineItems(state)` and `selectRunSummaryMetrics(state)` across inline message cards, 3rd-pane side panel, and `/runs/:id` `#s=` deep links (`FE-AGENT-01, 02`).
   - Virtualized timeline (`@tanstack/react-virtual` tested at `2,000` steps with `<= 60` DOM nodes), `[` / `]` keyboard step navigation, `"Following ▸ / Pause following"` toggle, Pinned Plan checklist (`FE-AGENT-03`), stats strip + `"Extend & continue"` (`FE-AGENT-06`), run controls (`FE-AGENT-07`), recursive Sub-agent tree (`FE-AGENT-08`), memory/compaction chips (`FE-AGENT-16, 17`), raw event inspector (`FE-AGENT-11`), and deterministic Replay Scrubber (`1x..8x`, `replayRunEventsUpTo`, Export/Import trace JSON, `FE-AGENT-10`).
   - Verified under a 100-interleaving Race Lab and out-of-order / duplicate / sequence-gap event observer (`phase05AgentCore.test.ts`).
2. **Tool-Call Renderers & Deceptive Approval UX (`frontend/src/features/agent/tools/renderers.tsx`, `frontend/src/features/agent/approvalSecurity.ts`):**
   - 9-mode `render_hint` registry (`text`, `json` with 50 MB size cap & slice viewer, `table` sortable/CSV, `diff` unified/split, `terminal` ANSI parser without `innerHTML`, `<= 2,000` DOM nodes on 100k lines & range slice endpoint `/api/tool-calls/{id}/output?range=`, `search_results`, `file_tree`, `image`/`browser_snapshot` with takeover, `kv`) (`FE-AGENT-04, 15`).
   - Approval UX (`FE-AGENT-05, 18`, `FE-ADMIN-05`): inline card + global pending banner, normalized display of RTL overrides (`[RTL:U+202E]`), zero-width chars, Cyrillic/Greek homoglyphs, multiline newlines, and long args (`"N hidden chars"` expand toggle), provenance warning badge, pattern validator rejecting `*` or bare `rm`, 400 ms anti-clickjacking stability guard (`odysseus:approval-layout-shift`), keyboard `Y`/`N`/`E`, and multi-tab idempotent race lock (`already_decided`).
3. **Artifacts / Canvas, Run History, Presets & Exec Policies (`frontend/src/features/artifacts/ArtifactsCanvasPanel.tsx`, `frontend/src/features/agent/RunHistoryAndPresetsView.tsx`):**
   - Resizable/fullscreen/pop-out (`BroadcastChannel`) Artifacts side panel (`FE-ART-01…09`, `FE-SHELL-13`), multi-type rendering (Markdown, CodeMirror 6, HTML, sanitized SVG, Mermaid, CSV, JSON, Image, React micro-app), strict sandboxed preview (`sandbox="allow-scripts"`, CSP `connect-src 'none'`, console capture), user-locked live streaming (`🔒 Locked by user edit`), version diff/restore, tracked-change AI suggestions with per-hunk Accept/Reject + Undo/Redo, code execution, selection quick actions (`FE-MSG-16`), composer last-message edit diff preview (`FE-COMP-12`), Run History table (`FE-AGENT-12`), Agent Presets CRUD (`FE-AGENT-13`), `"Running (n)"` tray (`FE-AGENT-14`), and Exec Policy Editor (`FE-ADMIN-05`).

## 6. Delivered in Phase 06 (`phase-06`)

1. **SSRF-Safe Web Search, Fetcher, Favicon Proxy & Citation Verifier (`backend/domain/tools/web_tools.py`, `backend/domain/research/citations.py`, `config/searxng/settings.yml`):**
   - Hardened internal SearXNG configuration (`config/searxng/settings.yml`), pluggable search providers (`SearxngSearchProvider`, `BraveSearchProvider`, `TavilySearchProvider`, `DeterministicSearchProvider`), and `SourceCache` (SHA-256 content addressing, TTL, `ETag`/`Last-Modified`).
   - `SSRFSafeHttpFetcher` and `validate_url_against_ssrf` verified against 84+ adversarial SSRF vectors + DNS rebinding per redirect hop + `/api/knowledge/favicon` SVG proxy.
   - `PromptBuilder` sequential `[n]` citation registry and `verify_citations_and_quotes` post-processor: strips dangling citations (`[n] > K` with `notice`), verifies every quoted claim strictly against the cited source `[n]` itself (defeating citation laundering), flags fabricated quotes (`[UNVERIFIED QUOTE]`), and strips hostile page prompt-injection directives (`sanitize_untrusted_page_text`).
2. **Structure-Aware Hybrid RAG (`backend/domain/rag/service.py`):**
   - Structure-aware chunker (`chunk_document_structure_aware`) preserving heading hierarchy (`H1 > H2 > H3`), fenced code blocks, and Markdown tables with exact `char_start`/`char_end` passage offsets.
   - Incremental SHA-256 hash re-index, cascading delete, query rewriting (`rewrite_query_for_retrieval`), hybrid Vector + Okapi BM25 retrieval fused via Reciprocal Rank Fusion (`RRF`) + Maximal Marginal Relevance (`MMR`), graceful `bm25_degraded` mode when vector store is offline, `@file:`/`@doc:` mention resolution, and hard query-time per-user ACL enforcement (`0.9600` hybrid recall@5 vs `0.4700` vector-only and `0.5000` BM25-only over 100 Q/A pairs; `p95 <= 400 ms` at 5,000 documents).
3. **Deep Research, Multi-Model Blind Compare, Documents & Memory/Skills/MCP Workspaces (`backend/domain/{research,compare,documents}/`, `backend/app/routers/knowledge.py`, `frontend/src/features/knowledge/KnowledgeWorkspacesView.tsx`):**
   - 9-stage Deep Research pipeline (`clarify` → `final_report`, `FE-WORK-02`) with depth presets (`quick`/`standard`/`deep`), hard search/source/token budgets, mid-run steering, contradiction & domain diversity checks, sanitized HTML report under `script-src 'none'` CSP (`REPORT_STRICT_CSP`), export to MD/HTML/PDF/DOCX, and `"Send to Documents"`.
   - Multi-model Blind Compare (`FE-WORK-03`) hiding model identities until vote, Elo / Bradley-Terry leaderboard, order-invariant LLM Judge (`100%` `(A,B)` vs `(B,A)` swap consistency), attributed synthesis, and single-column failure isolation.
   - Documents & Sheets workspace (`FE-WORK-01`, `FE-ART-06`): version history + unified diffs, tags/folders, multi-format import/export, 100,000-row virtualized CSV grid (`< 2 s` load/scroll/sort + formulas), ETag `409` 3-way conflict merge, AI tracked-edit suggestions, line-cited Q&A, and `doc_read`/`doc_search`/`doc_propose_edit` agent tools.
   - Memory Browser (`FE-WORK-10`), Skills Manager (`FE-WORK-11`) with static `curl ... | sh` security analyzer & review gate, and MCP Manager (`FE-WORK-12`) with tool-poisoning detector (`[REDACTED-SUSPICIOUS-DIRECTIVE]`), disabled-until-reviewed gate, and test-call console.

## 7. Delivered in Phase 07 (`phase-07`)

1. **Email & Triage (`backend/domain/mail/service.py`, `scripts/bench_mail.py`, `FE-WORK-04`):**
   - Multi-account IMAP/SMTP with vault credential isolation, TLS enforcement (`tls_required` on non-TLS non-loopback), Gmail OAuth 2.0 + Microsoft 365 `XOAUTH2` SASL framing, `UIDVALIDITY`/`UIDNEXT`/`MODSEQ` incremental sync with `UIDVALIDITY` cache invalidation, 20k-message bounded-memory sync (`< 50 MB` delta), IMAP IDLE push (`< 3 s`), and latency-aware prefetching (`scripts/bench_mail.py` at 50/200/800 ms RTT).
   - `nh3` strict HTML sanitizer (`sanitize_email_html`) verified against 155 XSS/CSS-exfil/homograph/tracking-pixel vectors (`0` executable scripts, `0` remote leaks by default, `cid:` validation, `<iframe sandbox="">` rendering).
   - Idempotent outbox send queue (`idempotency_key` + `Message-ID`), undo-send window, human-supervised AI triage (`suggest_only=True`, never auto-sends, untrusted email provenance taint), and tools `email_search`, `email_read`, `email_draft_reply`, `email_send` (`risk=exec`, always asks), `email_tag`.
2. **Notes & Todos (`backend/domain/notes/service.py`, `FE-WORK-05`):**
   - Markdown notes with folders, tags, pin, `[[wikilinks]]` + backlinks index, version history, FTS + semantic search, and Markdown/ZIP import/export.
   - Todos with status (`todo`/`in_progress`/`done`/`blocked`), priority, due dates, subtasks, recurrence, saved filters, Kanban + list views, **Assign to Agent** (`assign_todo_to_agent` spawning a run and linking output artifact/comment; failure leaves todo open with error), and tools `notes_search/read/create/update`, `todos_list/create/update/complete`.
3. **Calendar & CalDAV (`backend/domain/calendar/service.py`, `FE-WORK-06`):**
   - CalDAV discovery (`/.well-known/caldav`), incremental `sync-token`/`ctag` sync, ETag optimistic concurrency with 2-way conflict resolution (`keep_local`/`keep_remote`/`merge`), offline edit queue replay, RFC 5545 `RRULE` + `EXDATE` + `RECURRENCE-ID` expansion across 40 IANA timezones (verified across 30 zones over spring-forward & fall-back DST edges), `.ics` import/export with `ODYSSEUS_ICS_MAX_BYTES`, deterministic natural-language quick-add + fallback, and tools `calendar_list/create/update/delete` + free/busy helper.
4. **Scheduler, Notifications, Webhooks, Scoped API Tokens & CLI (`backend/domain/schedules/service.py`, `backend/domain/notifications/service.py`, `backend/cli.py`, `FE-WORK-07`, `FE-ADMIN-04`, `FE-AGENT-14`):**
   - `croniter` + `ZoneInfo` scheduler with 10× restart-storm deduplication (1 execution per window), misfire (`skip`/`run_once`/`catch_up`) and overlap policies, `flapping` badge at 3 errors & auto-disable circuit breaker with notification, template interpolation (`{{date}}`, `{{last_run_summary}}`), and deny-on-timeout background approvals.
   - `< 5 s` notifications across `in_app`, `web_push` (VAPID), `ntfy`, and `email_digest`; HMAC-SHA256 inbound webhooks with timestamp/nonce replay defense; SSRF-safe outbound webhooks with exponential backoff & Dead-Letter Queue replay; scoped personal API tokens (`odys_tok_...`, shown once, SHA-256 hashed, rate-limited, revocable); and `odysseus` CLI.

## 8. Delivered in Phase 08 (`phase-08`)

1. **Cookbook & Local Model Manager (`backend/domain/cookbook/`, `FE-WORK-09`, `docs/COOKBOOK.md`, `docs/COOKBOOK_FAILURES.md`):**
   - `hwfit` hardware detection + container GPU passthrough diagnostics (`docker/gpu.nvidia.yml`, `docker/gpu.rocm.yml`) + 24 deterministic hardware fixtures (`HARDWARE_FIXTURES_24` across Apple M1–M3 Ultra, RTX 3060–4090, A100/H100, AMD RX 7900 XTX / MI300X, CPU-only, and container passthrough).
   - Memory-fit calculator matching 30 published GGUF/KV-cache reference configurations within `±5%` (`compute_memory_fit`, `0` misclassifications), 0–100 recommendation score ranker, and `jinja2.sandbox.SandboxedEnvironment` chat template renderer blocking SSTI (`__class__`/`__mro__`/`__subclasses__`/`popen`) while rendering ChatML, Llama-3, Mistral, and Gemma-2 templates.
   - Resumable byte-range (`Range: bytes=...`) downloads with `statvfs` disk-space preflight (`1.2x` headroom), SHA-256 verification, and 2 GB streaming download resilience across mid-stream TCP drops.
   - Prebuilt engine installer (`llama.cpp`, `ollama`, `vllm`, `mlx-lm`) with `--dry-run` preflight and atomic symlink swap (`current -> v2`) preserving `v1` on mid-unpack failure.
   - Real CPU GGUF serve lifecycle (`tiny_gguf_server.py`) with completion health probe (`POST /v1/chat/completions`), automatic Provider registration/deregistration, crash-loop detector (3 crashes in 60 s -> `crash_loop`), 3-context benchmark runner (`2048`/`8192`/`32768`), TOFU SSH remote manager with host-key change blocker, and 32-rule `FailureReport` classifier.
2. **Gallery & Non-Destructive Tiled Image Editor (`backend/domain/gallery/`, `FE-WORK-08`):**
   - Upload safety pipeline (`inspect_and_sanitize_image_upload`): magic-byte MIME sniffing, `100 MP` header decompression-bomb guard (rejecting 10,000 MP PNG bombs in `< 12 ms` and `< 5 MB` RSS), HTML/JS polyglot rejection, SVG `<script>`/`onload`/`foreignObject` sanitizer, and automatic EXIF/GPS stripping on export (`stripped_exif_gps=True`).
   - Non-destructive tiled operation-log editor (`<= 2048x2048` tiles): crop, rotate, resize, levels/exposure, blur, sharpen, annotate, and client mask feathering with `>= 200` undo/redo operations (`< 50 ms` per op), 50 MP peak memory `< 600 MB`, and byte-deterministic golden export hashes.
3. **Voice Input, Streaming TTS & Voice Conversation Mode (`backend/domain/voice/`, `FE-COMP-09`):**
   - STT (`transcribe_audio`) with duration/byte caps (`413` on oversized uploads), deterministic fixture transcripts (`WER = 0.00 <= 0.15`), and structured microphone-denied fallback guidance.
   - Sentence-level streaming TTS (`stream_tts_For_token_stream`) emitting audio for sentence 1 before sentence 2 token generation finishes, optional Kokoro-82M ONNX runtime detector (`detect_kokoro_runtime()`), and full-screen Voice Conversation Mode (`listen → think → speak`) with **`<= 150 ms` barge-in** (`barge_in()`).
4. **Admin Console, Operations, Privacy & Guided Tours (`backend/domain/admin_ops/`, `FE-ADMIN-02..09`, `FE-SHELL-16`, `FE-QA-09`):**
   - Usage & Cost dashboard with **Demo-Mode Redaction** masking chat titles and emails, Exec Policy pattern tester, Health & **Secret-Scrubbed Support Bundle** scrubbing all 22 planted secret formats (`0` leaks), Audit Log cryptographic SHA-256 hash-chain verifier, Consistent Backup & Restore with SHA-256 manifest + passphrase encryption + **Restore Dry-Run**, GDPR Privacy (**Export All My Data** `.zip` with `0` residual rows after **Delete All My Data** cascade + `VACUUM`, plus zero unapproved external egress proof), Users privilege preview matrix, per-module **Guided Tours**, and `scripts/seed_demo.py`.


## 9A. PHASE-09A Work in Progress

- Brand source: `brand/brand.config.json`, JSON schema, Waypoint Loop strategy/voice/ADR, construction SVG, concept boards, logo/glyph/wordmark/loader/favicon, and 12 spot illustrations.
- Asset pipeline: `scripts/brand_assets.py`, `brand_sheets.py`, `brand_verify.py`, `icon_lint.py`, and `contrast_table.py`; generated PWA icons, ICO, Apple icon, manifest, and contact sheets.
- Frontend layer: brand semantic CSS tokens, responsive brand treatment in the shell, custom 66-icon manifest and typed React `Icon`, reduced-motion and print rules, removal of native title tooltips and sidebar raw HTML.
- Verified: frontend typecheck, ESLint, Vitest (35 tests), Vite build, Storybook build, UI default-look lint, icon lint, contrast table, and asset verification.
- Remaining before tagging `phase-09a`: non-app email/export/CLI surfaces, complete screen census and default-look closure across all feature surfaces, full rebrand sweep, accessibility/axe and screenshot matrix, and report/known-gap review.

## 9. How to Run & Verify

- **Run full verification suite:** `make verify` (358 backend tests, 35 frontend unit/property/adversarial tests, 15 Playwright Chromium E2E + `@axe-core/playwright` tests, Storybook static build, 0 audit vulnerabilities)
- **Regenerate contracts & real-engine fixtures:** `python3 scripts/gen_contracts.py`

## PHASE-09A verification update (2026-10-05)

PHASE-09A verification gates passed and the phase is tagged `phase-09a`. Brand utility checks, frontend builds, targeted backend tests, and acceptance integration pass. Full Playwright is 14/15 passing; email triage remains failing. `make verify` reaches tests with the project virtualenv: 370 tests pass, but coverage is 85.09% against the 85% gate. Docker acceptance is pending. Do not begin PHASE-09B.
