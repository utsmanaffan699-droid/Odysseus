# PHASE-09A accessibility evidence

- All frontend unit tests pass with the existing 35-test suite.
- `npm run lint` includes `jsx-a11y` and passes with zero errors.
- `scripts/ui_census.py` checks the shipped TSX census for native dialogs, raw HTML outside the vetted Markdown renderer, and hover-only title tooltips.
- Focus-visible rings, 44px touch targets, reduced-motion tokens, forced-colors mapping, semantic status tokens, print rules, and iframe accessible names are in the design system.
- Remaining evidence for the completion gate: Playwright axe scan on every authenticated workspace route, manual keyboard walkthrough recordings, and Lighthouse cold-load filmstrips. These require the phase QA harness and are tracked in `docs/KNOWN_GAPS.md` until run.
