# UI content inventory

The existing i18n catalog in `frontend/src/i18n/index.ts` remains the source for shipped feature copy. PHASE-09A adds the brand voice baseline and audits the high-risk generic surfaces below; 09B must complete the route-wide inventory.

| Key | en | id | Surface | Tone check |
|---|---|---|---|---|
| brand.tagline | A quiet workspace for consequential work. | Ruang kerja tenang untuk pekerjaan yang penting. | boot / metadata | calm, concrete |
| error.providerUnavailable | The provider did not respond. Check its health or choose another model. | Penyedia tidak merespons. Periksa kesehatannya atau pilih model lain. | provider error | what / why / next |
| empty.search | No matching conversations yet. Try a different phrase. | Belum ada percakapan yang cocok. Coba frasa lain. | search empty | direct, actionable |
| offline.banner | You are offline. Drafts stay local and will resume when connected. | Anda sedang luring. Draf tetap lokal dan akan dilanjutkan saat tersambung. | offline | reassuring without hype |
