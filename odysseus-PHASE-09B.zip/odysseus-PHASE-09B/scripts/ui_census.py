#!/usr/bin/env python3
"""Run the deterministic Playwright screenshot census against a clean seeded server."""
from __future__ import annotations
import os, re, shutil, subprocess, sys, tempfile, time
from pathlib import Path
import httpx
ROOT=Path(__file__).resolve().parent.parent
PYTHON=str(ROOT/".venv/bin/python") if (ROOT/".venv/bin/python").exists() else sys.executable
BOOTSTRAP_RE=re.compile(r"Temporary password \(must_change=true\): (\S+)")
def main()->int:
    out=ROOT/"docs/ui-audit/census"; out.mkdir(parents=True,exist_ok=True)
    for old in out.rglob("*.png"): old.unlink()
    tmp=Path(tempfile.mkdtemp(prefix="odysseus_census_")); port=8016; base=f"http://127.0.0.1:{port}"
    log=tmp/"server.log"; env=os.environ.copy(); env.update({"ODYSSEUS_ENVIRONMENT":"test","ODYSSEUS_BIND_HOST":"127.0.0.1","ODYSSEUS_PORT":str(port),"ODYSSEUS_DATA_DIR":str(tmp/"data"),"ODYSSEUS_LOGS_DIR":str(tmp/"logs"),"ODYSSEUS_DATABASE_URL":f"sqlite+aiosqlite:///{tmp/'data'/'census.db'}","ODYSSEUS_ALLOWED_HOSTS":"[\"127.0.0.1\",\"localhost\"]","ODYSSEUS_ALLOWED_ORIGINS":f"[\"{base}\"]","ODYSSEUS_RATE_LIMIT_REQUESTS_PER_MINUTE":"100000","ODYSSEUS_RATE_LIMIT_BURST":"10000","PYTHONUNBUFFERED":"1"})
    with log.open("w") as lf:
        proc=subprocess.Popen([PYTHON,"-m","uvicorn","backend.app.main:app","--host","127.0.0.1","--port",str(port)],cwd=ROOT,env=env,stdout=lf,stderr=subprocess.STDOUT)
    try:
        deadline=time.monotonic()+20
        while time.monotonic()<deadline:
            try:
                if httpx.get(base+"/api/health/ready",timeout=1).status_code==200: break
            except httpx.HTTPError: time.sleep(.2)
        match=BOOTSTRAP_RE.search(log.read_text())
        if not match: print(log.read_text(),file=sys.stderr); return 1
        pwenv=os.environ.copy(); pwenv.update({"PLAYWRIGHT_BASE_URL":base,"ODYSSEUS_TEST_ADMIN_PASSWORD":match.group(1)})
        result=subprocess.run(["npx","playwright","test","e2e/ui-census.spec.ts","--workers=1"],cwd=ROOT/"frontend",env=pwenv,check=False)
        files=sorted(str(p.relative_to(ROOT)) for p in out.rglob("*.png"))
        (out/"index.json").write_text(__import__('json').dumps({"version":2,"routes":["home","chat","mail","notes","calendar","schedules","docs","research","compare","memory","skills","mcp","projects","cookbook","gallery","voice","admin","settings","providers","storybook"],"states":["success"],"viewports":["mobile","tablet","laptop","wide"],"themes":["light","dark","high-contrast"],"locales":["en","id","en-XA"],"screenshots":files},indent=2)+"\n")
        print(f"ui-census: {len(files)} screenshots -> {out/'index.json'}")
        return result.returncode
    finally:
        proc.terminate(); proc.wait(timeout=5); shutil.rmtree(tmp,ignore_errors=True)
if __name__=="__main__": raise SystemExit(main())
