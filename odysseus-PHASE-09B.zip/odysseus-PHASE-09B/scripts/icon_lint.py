#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parent.parent/'brand/icons'; errors=[]
for p in sorted(root.glob('*.svg')):
    s=p.read_text();
    if 'viewBox="0 0 24 24"' not in s: errors.append(f'{p.name}: missing square 24 viewBox')
    if '<image' in s or '<foreignObject' in s or 'href="http' in s: errors.append(f'{p.name}: forbidden external/raster content')
manifest=json.loads((root/'manifest.json').read_text()); names={p.stem for p in root.glob('*.svg')}
for n in manifest['icons']:
    if n not in names: errors.append(f'{n}: missing file')
if errors: print('\n'.join(errors)); sys.exit(1)
print(f'brand icon lint: {len(manifest["icons"])} icons clean')
