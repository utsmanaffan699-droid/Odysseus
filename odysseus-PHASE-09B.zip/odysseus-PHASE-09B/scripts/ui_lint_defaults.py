#!/usr/bin/env python3
"""Detect unsafe browser-default patterns in shipped frontend code."""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent / "frontend/src"
errors: list[str] = []
patterns = [
    (r"\b(alert|confirm|prompt)\s*\(", "native dialog"),
    (r"\btitle\s*=", "title tooltip"),
    (r"emoji-as-icon", "emoji icon marker"),
]

for path in ROOT.rglob("*.tsx"):
    source = path.read_text(encoding="utf-8")
    for pattern, label in patterns:
        if label == "title tooltip" and 'title="Sandboxed content preview"' in source:
            continue
        if re.search(pattern, source):
            errors.append(f"{path.relative_to(ROOT)}: {label}")

for path in ROOT.rglob("*.tsx"):
    if "dangerouslySetInnerHTML" in path.read_text() and path.name not in {
        "StreamingMarkdownMessage.tsx"
    }:
        errors.append(f"{path.relative_to(ROOT)}: raw HTML")

if errors:
    print("\n".join(errors))
    sys.exit(1)
print("ui default-look lint: clean")
