#!/usr/bin/env python3
"""Constrained-client smoke test for branded HTML/plain-text transactional mail."""
from __future__ import annotations
import re
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from backend.domain.brand.email import render_transactional_email

for kind in ("invite", "two_factor", "digest", "backup_failure"):
    mail = render_transactional_email(kind, recipient_name="A <B>", action_url="https://workspace.invalid/action", detail="A safe detail")
    assert mail.html.startswith("<!doctype html>")
    assert "<script" not in mail.html.lower() and "<img" not in mail.html.lower()
    assert not re.search(r"(?:src|href)=['\"]//", mail.html)
    assert "A &lt;B&gt;" in mail.html and "A <B>" in mail.text
    assert mail.subject.startswith("PRODUCT_NAME:")
print("brand email harness: 4 HTML+text pairs clean; no remote assets")
