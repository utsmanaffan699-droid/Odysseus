#!/usr/bin/env python3
"""Render authored mark at required sizes and check maskable icon safe zone."""
from __future__ import annotations
import subprocess,sys
from pathlib import Path
from PIL import Image, ImageChops, ImageFilter, ImageOps
ROOT=Path(__file__).resolve().parent.parent; out=ROOT/'docs/brand/sheets/rendered'; out.mkdir(parents=True,exist_ok=True)
for size in (16,24,32,48,64,180,512):
 p=out/f'mark-{size}.png'; subprocess.run(['convert','-background','none',str(ROOT/'brand/logo/mark.svg'),'-resize',f'{size}x{size}',str(p)],check=True)
 im=Image.open(p).convert('RGBA'); alpha=im.getchannel('A'); bbox=alpha.getbbox()
 if bbox is None or bbox[2]-bbox[0] < max(4,size//4): raise SystemExit(f'empty/illegible mark at {size}px')
# all non-background maskable pixels must be in central 409x409 safe zone of 512.
im=Image.open(ROOT/'frontend/public/icon-512-maskable.png').convert('RGB'); bg=Image.new('RGB',im.size,im.getpixel((0,0))); diff=ImageChops.difference(im,bg).convert('L'); bbox=diff.point(lambda p: 255 if p>8 else 0).getbbox(); safe=(51,51,461,461)
if bbox and not (bbox[0]>=safe[0] and bbox[1]>=safe[1] and bbox[2]<=safe[2] and bbox[3]<=safe[3]): raise SystemExit(f'maskable art outside safe zone: {bbox}')
if im.getextrema()[0] is None: raise SystemExit('invalid maskable image')
print('brand verify: mark renders at 16/24/32/48/64/180/512; maskable safe-zone PASS')
