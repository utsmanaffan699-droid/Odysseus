#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path

def lum(hexv:str)->float:
 c=[int(hexv[i:i+2],16)/255 for i in (1,3,5)]
 c=[v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in c]
 return .2126*c[0]+.7152*c[1]+.0722*c[2]
def ratio(a:str,b:str)->float:
 x,y=lum(a),lum(b); return (max(x,y)+.05)/(min(x,y)+.05)
data=json.loads(Path('brand/tokens/colors.json').read_text()); rows=['# Brand contrast table','','| Theme | Foreground | Background | Ratio | Result |','|---|---|---|---:|---|']
for theme in ('light','dark','highContrast'):
 c=data[theme]
 for fg,bg in [('ink','canvas'),('ink','surface'),('primary','canvas'),('primary','surface'),('secondary','canvas'),('focus','canvas')]:
  r=ratio(c[fg],c[bg]); result='PASS' if r>=4.5 else 'FAIL'; rows.append(f'| {theme} | {fg} | {bg} | {r:.2f} | {result} |')
  if result=='FAIL': raise SystemExit('\n'.join(rows))
Path('docs/brand/CONTRAST.md').write_text('\n'.join(rows)+'\n')
print('\n'.join(rows))
