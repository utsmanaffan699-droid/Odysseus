#!/usr/bin/env python3
"""Deterministic PHASE-09A brand asset generator. Uses only Pillow and ImageMagick."""
from __future__ import annotations
import json, shutil, subprocess
from pathlib import Path
from PIL import Image, ImageDraw
ROOT=Path(__file__).resolve().parent.parent
BRAND=ROOT/'brand'; PUBLIC=ROOT/'frontend/public'; PUBLIC.mkdir(exist_ok=True)
config=json.loads((BRAND/'brand.config.json').read_text())
frontend_brand=ROOT/'frontend/src/brand/config.ts'
frontend_brand.write_text('export const brand = '+json.dumps({'productName':config['productName'],'tagline':config['tagline'],'legalLine':config['legalLine'],'markPath':config['assets']['mark'],'glyphPath':config['assets']['glyph'],'version':'0.1.0'},indent=2)+' as const;\n')
index_template=ROOT/'frontend/index.template.html'
index_path=ROOT/'frontend/index.html'
if index_template.exists():
    import re
    index=index_template.read_text(encoding='utf-8').replace('PRODUCT_NAME', str(config['productName']))
    index=re.sub(r'<title>.*?</title>', f'<title>{config["productName"]} — {config["tagline"]}</title>', index, count=1)
    index_path.write_text(index, encoding='utf-8')
for surface_name in ('offline.html', 'maintenance.html'):
    template=ROOT/'brand'/'templates'/surface_name
    if template.exists():
        (PUBLIC/surface_name).write_text(template.read_text(encoding='utf-8').replace('PRODUCT_NAME', str(config['productName'])), encoding='utf-8')
MARK=(BRAND/'logo'/'mark.svg').read_text()
# The favicon remains SVG; raster set is generated from the same geometric source.
(PUBLIC/'favicon.svg').write_text((BRAND/'logo'/'favicon.svg').read_text())
# Publish authored SVGs for offline same-origin use; no CDN or runtime fetch is introduced.
for source_dir, target_dir in [(BRAND/'logo', PUBLIC/'brand'/'logo'), (BRAND/'icons', PUBLIC/'brand'/'icons')]:
    target_dir.mkdir(parents=True, exist_ok=True)
    for source in source_dir.glob('*.svg'):
        (target_dir/source.name).write_text(source.read_text())
for size,name in [(192,'icon-192.png'),(512,'icon-512.png'),(512,'icon-512-maskable.png'),(180,'apple-touch-icon.png')]:
    im=Image.new('RGBA',(size,size),(245,242,235,255)); d=ImageDraw.Draw(im)
    pad=int(size*.22 if name=='icon-512-maskable.png' else size*.16)
    d.rounded_rectangle((pad,pad,size-pad,size-pad),radius=int(size*.18),outline=(63,109,104,255),width=max(2,size//16))
    q=int(size*.25); d.rounded_rectangle((q,q,size-q,size-q),radius=int(size*.05),fill=(211,139,93,255))
    im.convert('RGB').save(PUBLIC/name,optimize=True)
# favicon.ico with standard sizes
ims=[]
for s in (16,32,48):
    im=Image.new('RGBA',(s,s),(245,242,235,255)); d=ImageDraw.Draw(im); p=max(1,s//8)
    d.rounded_rectangle((p,p,s-p,s-p),radius=max(1,s//6),outline=(63,109,104,255),width=max(1,s//8)); q=max(2,s//3); d.rectangle((q,q,s-q,s-q),fill=(211,139,93,255)); ims.append(im)
ims[0].save(PUBLIC/'favicon.ico',sizes=[(16,16),(32,32),(48,48)])
manifest={'name':f'{config["productName"]} — {config["tagline"]}','short_name':config['productName'],'description':str(config.get('meta', {}).get('description', 'A self-hosted AI workspace for private, accountable work.')),'start_url':'/','display':'standalone','background_color':'#F5F2EB','theme_color':'#3F6D68','icons':[{'src':'/icon-192.png','sizes':'192x192','type':'image/png','purpose':'any'},{'src':'/icon-512.png','sizes':'512x512','type':'image/png','purpose':'any'},{'src':'/icon-512-maskable.png','sizes':'512x512','type':'image/png','purpose':'maskable'}]}
(PUBLIC/'manifest.webmanifest').write_text(json.dumps(manifest,indent=2)+'\n')
