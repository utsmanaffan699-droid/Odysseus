#!/usr/bin/env python3
"""Start a clean Odysseus server, capture bootstrap password, and run Playwright E2E tests."""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parent.parent
BOOTSTRAP_RE = re.compile(r"Temporary password \(must_change=true\): (\S+)")


def main() -> int:
    tmp_dir = Path(tempfile.mkdtemp(prefix="odysseus_e2e_"))
    port = 8015
    base_url = f"http://127.0.0.1:{port}"
    log_file = tmp_dir / "server.log"

    env = os.environ.copy()
    env.update(
        {
            "ODYSSEUS_ENVIRONMENT": "test",
            "ODYSSEUS_BIND_HOST": "127.0.0.1",
            "ODYSSEUS_PORT": str(port),
            "ODYSSEUS_DATA_DIR": str(tmp_dir / "data"),
            "ODYSSEUS_LOGS_DIR": str(tmp_dir / "logs"),
            "ODYSSEUS_DATABASE_URL": f"sqlite+aiosqlite:///{tmp_dir / 'data' / 'e2e.db'}",
            "ODYSSEUS_ALLOWED_HOSTS": '["127.0.0.1","localhost"]',
            "ODYSSEUS_ALLOWED_ORIGINS": f'["{base_url}"]',
            "ODYSSEUS_RATE_LIMIT_REQUESTS_PER_MINUTE": "100000",
            "ODYSSEUS_RATE_LIMIT_BURST": "10000",
            "PYTHONUNBUFFERED": "1",
        }
    )

    with log_file.open("w", encoding="utf-8") as lf:
        proc = subprocess.Popen(
            [
                sys.executable,
                "-m",
                "uvicorn",
                "backend.app.main:app",
                "--host",
                "127.0.0.1",
                "--port",
                str(port),
            ],
            cwd=str(ROOT),
            env=env,
            stdout=lf,
            stderr=subprocess.STDOUT,
        )

    try:
        # Wait up to 15s for /api/health/ready
        deadline = time.monotonic() + 15.0
        ready = False
        while time.monotonic() < deadline:
            try:
                resp = httpx.get(f"{base_url}/api/health/ready", timeout=1.0)
                if resp.status_code == 200:
                    ready = True
                    break
            except Exception:
                time.sleep(0.2)

        if not ready:
            print("ERROR: Server failed to become ready within 15s", file=sys.stderr)
            print(log_file.read_text(encoding="utf-8"), file=sys.stderr)
            return 1

        server_output = log_file.read_text(encoding="utf-8")
        match = BOOTSTRAP_RE.search(server_output)
        if not match:
            print("ERROR: Did not find bootstrap admin password in server stdout", file=sys.stderr)
            print(server_output, file=sys.stderr)
            return 1

        admin_pw = match.group(1)
        pw_env = os.environ.copy()
        pw_env["PLAYWRIGHT_BASE_URL"] = base_url
        pw_env["ODYSSEUS_TEST_ADMIN_PASSWORD"] = admin_pw
        if Path("/usr/bin/chromium").exists():
            pw_env["PLAYWRIGHT_CHROMIUM_PATH"] = "/usr/bin/chromium"

        res = subprocess.run(
            ["npx", "playwright", "test"],
            cwd=str(ROOT / "frontend"),
            env=pw_env,
            check=False,
        )
        if res.returncode != 0:
            print("=== SERVER LOG TAIL ===", file=sys.stderr)
            for line in log_file.read_text(encoding="utf-8").splitlines():
                if "/api/chats" in line or "/api/runs" in line or "/api/mail" in line or "error" in line.lower():
                    print(line, file=sys.stderr)
        return res.returncode
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
        shutil.rmtree(tmp_dir, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
