#!/usr/bin/env python3
"""Small deterministic CVD palette sanity check; charts must also use labels/patterns."""
from __future__ import annotations
import json, math
from pathlib import Path
p=json.loads(Path('brand/tokens/colors.json').read_text())['chart']
def rgb(h): return tuple(int(h[i:i+2],16) for i in (1,3,5))
def dist(a,b): return math.sqrt(sum((x-y)**2 for x,y in zip(rgb(a),rgb(b))))
# A conservative minimum in source RGB catches accidental near-duplicates before simulation.
minimum=min(dist(a,b) for i,a in enumerate(p) for b in p[i+1:])
assert minimum >= 30, f'chart palette has near duplicate colors: {minimum:.1f}'
print(f'cvd palette check: {len(p)} colors, minimum source distance {minimum:.1f}; labels/patterns required for chart semantics')
