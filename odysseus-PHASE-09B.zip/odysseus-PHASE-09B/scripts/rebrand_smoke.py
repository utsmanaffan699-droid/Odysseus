#!/usr/bin/env python3
"""Build-time smoke test for the config-driven product name and generated surfaces."""
from __future__ import annotations
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent.parent
cfg_path = ROOT / "brand" / "brand.config.json"
original = cfg_path.read_text(encoding="utf-8")
try:
    cfg = json.loads(original)
    cfg["productName"] = "Delta Test Workspace"
    cfg_path.write_text(json.dumps(cfg, indent=2) + "\n", encoding="utf-8")
    subprocess.run(["python3", "scripts/brand_assets.py"], cwd=ROOT, check=True, capture_output=True)
    manifest = (ROOT / "frontend/public/manifest.webmanifest").read_text(encoding="utf-8")
    generated = (ROOT / "frontend/src/brand/config.ts").read_text(encoding="utf-8")
    index = (ROOT / "frontend/index.html").read_text(encoding="utf-8")
    assert "Delta Test Workspace" in manifest
    assert "Delta Test Workspace" in generated
    assert "Delta Test Workspace" in index
    print("rebrand smoke: generated manifest and frontend config switched to dummy brand")
finally:
    cfg_path.write_text(original, encoding="utf-8")
    subprocess.run(["python3", "scripts/brand_assets.py"], cwd=ROOT, check=True, capture_output=True)
