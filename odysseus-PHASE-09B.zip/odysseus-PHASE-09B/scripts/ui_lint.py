#!/usr/bin/env python3
"""Deterministic static UI audit for token, accessibility, icon and unsafe-copy regressions."""
from __future__ import annotations
import json, re
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "frontend/src"
errors: list[str] = []
metrics = {"files": 0, "raw_colors": 0, "raw_spacing": 0, "z_indexes": 0, "icon_buttons": 0, "undefined_literals": 0}
for p in sorted(SRC.rglob("*.tsx")):
    metrics["files"] += 1
    text = p.read_text(encoding="utf-8")
    rel = p.relative_to(ROOT)
    # Brand/token source files are the sole definition sites; tests may fixture raw values.
    if p.name not in {"tokens.css", "config.ts"}:
        metrics["raw_colors"] += len(re.findall(r"#[0-9a-fA-F]{3,8}\b", text))
    metrics["raw_spacing"] += len(re.findall(r"(?<![A-Za-z])(?:padding|margin|gap|width|height)\s*:\s*\d+px", text))
    metrics["z_indexes"] += len(re.findall(r"zIndex\s*:\s*\d+", text))
    metrics["icon_buttons"] += len(re.findall(r"<button\b[^>]*>\s*<Icon\b[^>]*/>\s*</button>", text, re.S))
    metrics["undefined_literals"] += len(re.findall(r">\s*(?:undefined|null|NaN)\s*<", text))
    if re.search(r"\b(?:alert|confirm|prompt)\s*\(", text): errors.append(f"{rel}: native dialog")
    if re.search(r"\btitle\s*=", text) and "Sandboxed content preview" not in text: errors.append(f"{rel}: title tooltip")
for p in sorted(SRC.rglob("*.tsx")):
    if "dangerouslySetInnerHTML" in p.read_text(encoding="utf-8") and p.name != "StreamingMarkdownMessage.tsx":
        errors.append(f"{p.relative_to(ROOT)}: unapproved raw HTML")
if metrics["undefined_literals"]: errors.append("rendered undefined/null/NaN literal")
report = ROOT / "docs/ui-audit"
report.mkdir(parents=True, exist_ok=True)
(report / "lint-metrics.json").write_text(json.dumps(metrics, indent=2, sort_keys=True)+"\n")
if errors:
    print("\n".join(errors)); raise SystemExit(1)
print("ui-lint: clean")
print(json.dumps(metrics, sort_keys=True))
