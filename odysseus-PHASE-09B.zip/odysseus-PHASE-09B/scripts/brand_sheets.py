#!/usr/bin/env python3
"""Build deterministic contact sheets from the authored SVG assets."""
from __future__ import annotations
import subprocess
from pathlib import Path
from PIL import Image, ImageDraw
ROOT=Path(__file__).resolve().parent.parent; OUT=ROOT/'docs/brand/sheets'; OUT.mkdir(parents=True,exist_ok=True)
svgs=sorted((ROOT/'brand/logo').glob('*.svg')) + sorted((ROOT/'brand/illustrations').glob('*.svg'))
for svg in svgs:
    png=OUT/(svg.stem+'.png')
    subprocess.run(['convert','-background','none',str(svg),'-resize','512x512',str(png)],check=True)
# composite board on four backgrounds
canvas=Image.new('RGB',(1024,768),(245,242,235)); d=ImageDraw.Draw(canvas)
for i,bg in enumerate([(245,242,235),(23,37,34),(63,109,104),(128,128,128)]):
    x=(i%2)*512; y=(i//2)*384; d.rectangle((x,y,x+512,y+384),fill=bg)
    p=Image.open(OUT/'mark.png').convert('RGBA'); p.thumbnail((240,240)); canvas.paste(p,(x+136,y+80),p)
canvas.save(OUT/'brand-mark-contact-sheet.png',optimize=True)
